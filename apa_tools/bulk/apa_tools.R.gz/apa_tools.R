
## packages that should always be installed:
## biocLite, Starr, combinat, RColorBrewer, SPIA, AffyQCReport, rJava, xlsx, ape, 

## creating this package: package.skeleton(name = "apa_tools", unlist(apa.names), path = "U:/apa/R/apa_tools_package")
## revising this package: package.skeleton(name = "apa_tools2", unlist(apa.names), path = "U:/apa/R/apa_tools_package", force=TRUE)

### source("/n/projects/apa/R/apa_tools.R")
### source("U:/apa/R/apa_tools.R")

library(methods)  # if being called from Rscript, ensure this is loaded

apa.path <- switch(
    Sys.info()[["sysname"]], 
    "Windows"="U:/apa/R",  #####  legacy version only!  #####
    "Linux"="/home/apa/local/bin",  # active version
#    "Darwin"="/Volumes/home/apa/local/bin",  # active version
    "Darwin"="/Volumes/unixhomes/apa/local/bin",  # active version
    NA
)
if (is.na(apa.path)) warning(paste("Cannot source additional files: unknown system type '",Sys.info()[["sysname"]],"'!  Must be Windows, Linux, or Darwin\n",sep=""))
if (!file.exists(apa.path)) warning(paste("Cannot resolve source path '",apa.path,"'!  Some support files will be unavailable.  Check mapped drives / mount points.\n",sep=""))
utils.path <- ifelse(apa.path=="U:/apa/R",apa.path,paste0(apa.path,"/scriptutils"))  # if not legacy, then stuff is in /scriptutils subdirectory
kegg.root <- "/n/data1/KEGG/"            # MUST END W/ SLASH
idx.root <- "/n/data1/genomes/indexes/"  # MUST END W/ SLASH
.HOSTNAME <- ifelse(Sys.info()[["sysname"]]=="Linux", sub(".sgc.loc$","",system("hostname",intern=TRUE)), NA)
options(warn=1)  # print warnings in real time, instead of printing everything at end of function
#apa.path <- "http://bioinfo/n/projects/apa/R"  # platform-independent path?
#cat(apa.path,"\n"); flush.console()




########## LIST OF ALL FUNCTIONS AND OBJECTS LOADED BY THIS SCRIPT:
apa.names <- list(hacks=c("apa.names","apa.path","utils.path"), general=c(), graphics=c(), plots=c(), dev=c(), microarray=c())
########## TO REMOVE ALL FUNCTIONS FROM NAMESPACE, RUN "rm.apa.tools()"




source(paste(apa.path,"bio.seq.dev.R",sep="/"))
source(paste(apa.path,"chipseq_heatmap_functions.R",sep="/"))
source(paste(apa.path,"functional_functions.new.R",sep="/"))
source(paste(apa.path,"functional_functions.old.R",sep="/"))
#source(paste(apa.path,"seqLogo2.R",sep="/"))

#source("S:/Genomics/Molbio_Users/APA/R_Things/match.coords.R")
#source("match.coords.R")

apa.names$hacks <- c(apa.names$hacks, "rm.apa.tools")
rm.apa.tools <- function() suppressWarnings(rm(list=unlist(apa.names), envir=.GlobalEnv))


##### BOXPLOTS: NEED OUTPUT WIDTH SCALING WITH NUMBER OF ARRAYS
##### INVERT.LIST2: ADD SUBLIST ELEMENT HANDLING
##### BREAKOUT: HANDLE N GROUPING COLS
##### PAIRS2SUBGRAPHS: CONN.MAT SWITCH
##### BIO.SEQ.QC: BASE CLUSTERING REPORT?
##### IS SUBSET.MARG NECESSARY?
##### AUGMENT.FIT: USING DECIDETESTS2?
##### "ALL.QC.PLOTS" INSTEAD OF THREE SEPARATE PLATFORMS?



#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################



apa.names$hacks <- c(apa.names$hacks, "%nin%")
"%nin%" <- function(x, table) match(x, table, nomatch = 0) == 0  # the logical opposite of "%in%", but without having to write it as "!(x %in% y)"


apa.names$hacks <- c(apa.names$hacks, "%within%")
"%within%" <- function(x, range) x>=range[1] & x<=range[2]       # simpler to write one logical instead of two


apa.names$hacks <- c(apa.names$hacks, "ternary")
ifelse2 <- ternary <- function (test, expr1, expr2, return.value=TRUE) {
    
    ## Is this seriously R's first proper ternary operator??
    ## Not ifelse(), which is unable to return anything other than vectors of length 1.
    
    if (!is.logical(test)) stop("test condition must evaluate to TRUE/FALSE!\n")
    if (test) {
        if (return.value) {
            return(eval({expr1}))
        } else {
            eval({expr1})
            try(stop(),silent=TRUE)		# blocks return values
        }
    } else {
        if (return.value) {
            return(eval({expr2}))
        } else {
            eval({expr2})
            try(stop(),silent=TRUE)		# blocks return values
        }
    }
}


apa.names$hacks <- c(apa.names$hacks, "execute")
execute <- function (cmd, echo=TRUE, stopIfErr=TRUE) {
    ## Runs a system command, captures exit code, also reports code if non-zero
    ## If desired, dies on non-zero exit codes
    ## If desired, echoes command to screen
    if (echo) message(cmd)
    code <- system(cmd)
    if (code>0) {
        message(paste0("Command: '",cmd,"' had exit status ",ex,"!"))
        if (stopIfErr) stop("Halting.\n")
    }
}


apa.names$hacks <- c(apa.names$hacks, "ls.size")
ls.size <- function (envir=.GlobalEnv, human=FALSE, sort.by.size=FALSE) {
    
    ## object sizes for ls(envir)
    ## auto-subtracts 'apa.names' from base envir, at least until apa_tools.R becomes a formal package
    ## 'sort.by.size' sorts entries by size
    ## 'human' format numbers a la "df -h"
    
    if (deparse(substitute(envir)) == ".GlobalEnv") {
        x <- setdiff(ls(envir), unlist(apa.names))
    } else {
        x <- ls(envir)
    }
    y <- sapply(x, function(i){object.size(get(i))[[1]]})
    if (sort.by.size) { y <- sort(y, decreasing=TRUE) }
    
    humanize <- function(n) {
        if (n/1E12 >= 10) {
            paste(round(n/1E12,0),"T",sep="")
        } else if (n/1E12 >= 1) {
            paste(round(n/1E12,1),"T",sep="")
        } else if (n/1E9 >= 1) {
            paste(round(n/1E9,0),"G",sep="")
        } else if (n/1E6 >= 1) {
            paste(round(n/1E6,0),"M",sep="")
        } else if (n/1E3 >= 1) {
            paste(round(n/1E3,0),"K",sep="")
        } else {
            paste(n,"B",sep="")
        }
    }
    
    if (human) {
        data.frame(BYTES=sapply(y,humanize))
    } else {
        data.frame(BYTES=y)
    }
}


apa.names$hacks <- c(apa.names$hacks, "is.ndfl")
is.ndfl <- function (x) {
    
    ## is.non.data.frame.list()
    
    is.list(x) & !is.data.frame(x)
}


apa.names$hacks <- c(apa.names$hacks, "is.nlv")
is.nlv <- function (x) {
    
    ## is.non.list.vector()
    
    is.vector(x) & !is.list(x)
}


apa.names$hacks <- c(apa.names$hacks, "is.decimal")
is.decimal <- function (x) {
    
    ## do any numbers have any nonzero decimals
    
    x-trunc(x) != 0
}


apa.names$hacks <- c(apa.names$hacks, "as.numeric")
as.numeric <- function (x) {
    
    ## name-preserving as.numeric

    y <- base:::as.numeric(x)
    names(y) <- names(x)
    y
}


apa.names$hacks <- c(apa.names$hacks, "as.complex")
as.complex <- function (x) {
    
    ## name-preserving as.complex

    y <- base:::as.complex(x)
    names(y) <- names(x)
    y
}


apa.names$hacks <- c(apa.names$hacks, "as.logical")
as.logical <- function (x) {
    
    ## name-preserving as.logical

    y <- base:::as.logical(x)
    names(y) <- names(x)
    y
}


apa.names$hacks <- c(apa.names$hacks, "as.character")
as.character <- function (x) {
    
    ## name-preserving as.character

    y <- base:::as.character(x)
    names(y) <- names(x)
    y
}


apa.names$hacks <- c(apa.names$hacks, "npaste")
npaste <- function (..., sep=" ", collapse=NULL, which.names=1) {
    
    ## paste function that preserves names
    ## if multiple objects in '...' have names, 'which.names=rank' gives the rank of the object whose names will be used
    ##  - NOTE: this is not the rank of the object in '...', but the rank in the NAMED objects in '...'
    
    x <- paste(..., sep=sep, collapse=collapse)  # unnamed paste result
    L <- list(...)  # list of pasted things
    named <- which(sapply(L, function(l) length(names(l))>0 ))  # these things have names
    names(x) <- names(L[[ named[which.names] ]])
    x
}


apa.names$hacks <- c(apa.names$hacks, "npaste0")
npaste0 <- function (..., collapse=NULL, which.names=1) {
    
    npaste(..., sep="", collapse=collapse, which.names=which.names)
}


apa.names$hacks <- c(apa.names$hacks, "message2")
message2 <- function (..., domain = NULL, appendLF = TRUE, handle = stderr()) 
{
    args <- list(...)
    cond <- if (length(args) == 1L && inherits(args[[1L]], "condition")) {
        if (nargs() > 1L) 
            warning("additional arguments ignored in message()")
        args[[1L]]
    }
            else {
                msg <- .makeMessage(..., domain = domain, appendLF = appendLF)
                call <- sys.call()
                simpleMessage(msg, call)
            }
    defaultHandler <- function(c) {
        cat(conditionMessage(c), file = handle, sep = "")
    }
    withRestarts({
        signalCondition(cond)
        defaultHandler(cond)
    }, muffleMessage = function() NULL)
    invisible()
}


apa.names$hacks <- c(apa.names$hacks, "IM")
IM <- function (..., handle=stderr()) {
    
    ## "Instant Message", fastest way to report messages in real-time
    
    msg <- paste(unlist(list(...)), collapse=" ")
    message2(msg,handle=handle); flush.console()
}


apa.names$hacks <- c(apa.names$hacks, "report.index")
report.index <- function(i, n, N=NULL, msg=NULL, timestamp=FALSE) {
    
    ## Reports iteration i, every nth iteration of i.
    ## Optional message and/or timestamp can be appended
    
    fmt <- paste0("%",nchar(N),"i/",N)  # won't work without N
    if( !(i %% n) ) {
        rept <- ifelse(!is.null(N), sprintf(fmt,i), i)
        if (timestamp) msg <- paste(c(msg,paste0(": ",as.character(Sys.time()))),collapse=" | ")  # using collapse prevents extra ' | ' if no msg
        message(paste(rept,msg))
    }
}


apa.names$hacks <- c(apa.names$hacks, "sum.na")
sum.na <- function(x) {
    
    sum(is.na(x))
}


apa.names$hacks <- c(apa.names$hacks, "zapdiag")
zapdiag <- function(mat, value=NA) {
    
    diag(mat) <- value
    mat
}


apa.names$hacks <- c(apa.names$hacks, "maco")
maco <- function(x) {
    
    matrix(colnames(x))
}


apa.names$hacks <- c(apa.names$hacks, "maro")
maro <- function(x) {
    
    matrix(rownames(x))
}


apa.names$hacks <- c(apa.names$hacks, "mana")
mana <- function(x) {
    
    matrix(names(x))
}


apa.names$hacks <- c(apa.names$hacks, "mtable")
mtable <- function(x, order=FALSE, percent=FALSE) {
    
    y <- as.matrix(table(x))
    if (order) y <- y[rev(order(y[,1])),,drop=FALSE]
    if (percent) y <- cbind(N=y, Pct=y/sum(y))
    y
}


apa.names$hacks <- c(apa.names$hacks, "tabify.1")
tabify.1 <- function(x) {
    
    ## Adds tab to the first element of a vector, for spacing colnames correctly (since R cannot figure out how to align colnames when printing rownames as well)
    
    y <- x
    y[1] <- paste("\t",x[1],sep="")
    y
}


apa.names$hacks <- c(apa.names$hacks, "stabilize.integer")
stabilize.integer <- function(x) {
    
    ## prevents certain integers from writing to file in scientific format
    ## i.e., written value is "1000000" not "1e+06"
    ## values in sci format will break bedtools, samtools, etc.
    ## WARNING: values become character, not numeric.  Use ONLY for writing to file.
    
    gsub(" ","",format(x,scientific=FALSE))  ### numbers have now become character strings!!!
}


apa.names$hacks <- c(apa.names$hacks, "xemacs")
xemacs <- function(file) {
    
    ## Base emacs() does not run emacs in bkg; R session hangs in the meantime.
    ## xemacs() expects X window env and runs in bkg.
    
    system(paste("emacs",file,"&"))
}


apa.names$hacks <- c(apa.names$hacks, "gthumb")
gthumb <- function(file) {
    
    ## Expects X / Gnome; view image

    if (grepl("\\.pdf$",file,TRUE)) {
        system(paste("evince",file,"&"))
    } else {
        if (.HOSTNAME %in% qw(rho,aspen,aspen-0,lepus)) {  # hosts currently running CentOS6
            system(paste("gthumb",file,"&"))
        } else {  # else assumed to be a CentOS7 host
            system(paste("gwenview",file,"2>/dev/null &"))
        }
    }
}


apa.names$hacks <- c(apa.names$hacks, "muscle")
muscle <- function(input, output=NULL, flat=NULL, params=NULL, as.matrix=FALSE, silent=FALSE, fix.terminals=c("none","DNA","AA")) {
    
    ## Runs muscle on two fasta sequences
    ## 'input' can be a file, or results from read.fasta() -- basically a named vector of DNA/AA strings
    ## 'output' file can be specified, if not a temp file will be made.
    ## 'flat', if specified (must be a filename), creates a flattened multialignment file for easier viewing
    ## returns the multialigned fasta sequences as vector, or as matrix if "as.matrix=TRUE"
    ## 'fix.terminals', if not "none", will ensure that M/ATG and */{TAA,TAG,TGA} are shifted to first/last columns where possible.
    
    fix.terminals <- match.arg(fix.terminals)
    infile <- tempfile()
    if (is.nlv(input) & length(input)>1) {
        input <- gsub("\\*","Z",input)               # currently, "Z" is not an AA or NT character -- substitute for stops
        write.fasta(input, infile)
    } else if (file.exists(input)) {
        input2 <- gsub("\\*","Z",read.fasta(input))  # currently, "Z" is not an AA or NT character -- substitute for stops
        write.fasta(input2, infile)
    } else {
        stop("'input' is neither a vector nor a file!")
    }
    if (is.null(output)) output <- tempfile()
    if (silent) {
        cmd <- paste("muscle -in",infile,"-out",output,params," 2> /dev/null")
    } else {
        cmd <- paste("muscle -in",infile,"-out",output,params)
    }
    IM("Running:",cmd)
    system(cmd)
    aln <- gsub("Z","*",read.fasta(output))  # put stop codons back
    if (fix.terminals != "none") {
        start <- ifelse(fix.terminals=="AA", "M", "ATG")
        end   <- ifelse(fix.terminals=="AA", "\\*", "(TGA|TAA|TAG)")
        aln <- sub(paste0("^(-*)",start),paste0(start,"\\1"),aln)
        aln <- sub(paste0("(",end,")(-*)$"),paste0("\\2","\\1"),aln)
   }
    write.fasta(aln, output)
    if (!is.null(flat)) {
        system(paste("/home/apa/local/bin/flattenMultialign -i",output,"--flat >",flat))
    }
    if (as.matrix) {
        do.call(rbind, lapply(read.fasta(output), function(x) unlist(strsplit(x,"")) ))
    } else {
        read.fasta(output)
    }
}


apa.names$hacks <- c(apa.names$hacks, "mgrep")
mgrep <- function(patterns, x, ignore.case=FALSE, perl=FALSE, value=FALSE, fixed=FALSE, useBytes=FALSE, invert=FALSE) {

    ## multi-grep; greps > 1 pattern at once

    if (invert) stop("Cannot use 'invert' yet, sorry!\n")
    w <- lapply(patterns, function(p) grep(p, x, ignore.case, perl, value, fixed, useBytes, invert) )
    w[listLengths(w)==0] <- NA
    return(unlist(w))
}


apa.names$hacks <- c(apa.names$hacks, "mgrepl")
mgrepl <- function(patterns, x, ignore.case=FALSE, perl=FALSE, fixed=FALSE, useBytes=FALSE) {
    
    ## multi-grepl; grepls > 1 pattern at once
    
    w <- sapply(patterns, function(p) grepl(p, x, ignore.case, perl, fixed, useBytes) )
    if (length(dim(w))==0) {  # vector return
        any(w)
    } else {  # w is a matrix with length(x) rows and length(patterns) columns
        apply(w, 1, any)
    }
}


apa.names$hacks <- c(apa.names$hacks, "fullpath")
fullpath <- function(x) {
    
    ## returns the full path of a file; multi-platform  ### WINDOWS COMMAND HAS PROBLEMS ON NETWORK DRIVES
    
    y <- switch(
        .Platform$OS.type, 
        "linux" = system(paste("readlink -f",x), intern=TRUE),
        "windows" = system(paste(Sys.getenv("COMSPEC")," /Q /C FOR %I IN (",x,") DO echo %~dpnxI",sep=""), intern=TRUE)
    )
    y
}


apa.names$hacks <- c(apa.names$hacks, "fixpath")
fixpath <- function(x, absolute=TRUE, trailing.slash=TRUE, mkdir=TRUE, clobber=c("ignore","no","yes")) {
    
    ## 'absolute' converts "path" to "/full/path/to/path"; only works if path currently exists
    ## 'trailing.slash' ensures "path" is "path/", to simplify "paste0(path,filename)" statements
    ## 'mkdir' makes the dir, if doesn't already exist
    ## 'clobber' values: 'yes' means existing dir gets rebooted, 'no' means death if dir already exists, 'ignore' does neither.
    
    clobber <- match.arg(clobber)
    if (!dir.exists(x)) {
        if (mkdir) {
            system(paste("mkdir -p",x))
        } else {
            if (absolute) x <- fullpath(x)   # this works on non-existant directories -- uses Linux 'readlink -f' -- has issues on Mac/Win
        }
    } else {
        if (absolute) x <- normalizePath(x)  # this only works on existing directories -- no OS issues
        if (clobber=="yes") {
            system(paste("rm -rf",x))
            system(paste("mkdir -p",x))
        } else if (clobber=="no") {
            stop("Directory '",x,"' already exists and 'clobber=no'!\n")
        }
    }
    if (trailing.slash & !grepl("/$",x)) x <- paste0(x,"/")
    
    x
}


apa.names$hacks <- c(apa.names$hacks, "fs.legal")
fs.legal <- function(x, convert='_', win2k=TRUE, linux=TRUE, whitespace=FALSE) {
    
    ## Takes a string x and converts all filesystem-illegal characters.
    ## "convert" specifies the replacement character for any illegal characters.
    ## "win2k=T" converts for windows platforms.
    ## "linux=T" converts for linux platforms.
    ## "whitespace=F" converts whitespace as well; otherwise gets left alone.
    ## Deprecated: "consecutive=T" leaves multiple consecutive converteds as-is; FALSE collapses them into a single convert char.
    
    whites <- c(" ","\t","\r","\n")
    chars <- unlist(strsplit(x,''))
    if (win2k) {
        illegal.first <- c(" ")
        illegal.any <- c(":","*","?","\"","<",">","/","\\","|")
        if (chars[1] %in% illegal.first) chars[1] <- convert
        chars[chars %in% illegal.any] <- convert
    }
    if (linux) {
        illegal.first <- c("-","~")
        illegal.any <- c("!","?","$","&",";","<",">","(",")","{","}","*","/","\\","|","\"","'","`")
        if (chars[1] %in% illegal.first) chars[1] <- convert
        chars[chars %in% illegal.any] <- convert
    }
    if (!whitespace) chars[chars %in% whites] <- convert
    y <- paste(chars, collapse='')
    y
}


apa.names$hacks <- c(apa.names$hacks, "trim.white")
trim.white <- function(x) {
    
    ## trims leading and trailing whitespace from a vector of strings
    
    sapply( sapply(x, function(s1){ sub("^[[:blank:]]+","",s1) }), function(s2){ sub("[[:blank:]]+$","",s2) })
}


apa.names$hacks <- c(apa.names$hacks, "calculate.margin.width")
calculate.margin.width <- function(x) {
    
    ## Calculates minimum margin width value to accommodate vector of axis-label strings 'x'
    ## ASSUMES R DEFAULT FONT -- working as of R3.2.2/CentOS7
    ## ONLY TESTED FOR PNG (but the others should be very similar)
    ## Currently fixed for cex=1.2.  In future, range of cex possible?   ## PROBABLY NOT -- char width behavior not remotely linear when changing cex value in test script, see code at head of acsii_dimensions.txt
    
    cex <- 1.2      # required for now -- only scaling factor calculated
    start <- 1      # effective margin value where label starts
    extra <- 1      # "insurance" space to add
    factors <- c(   # scaling factor values 1-30, for cex values 0.1-3.0  (ONLY 1.2 IS POPULATED)
        1,1,1,1,1,1,1,1,1,1,        # 0.1 - 1.0  (1-10)
        1,18.5/17,1,1,1,1,1,1,1,1,  # 1.1 - 2.0  (11-20)
        1,1,1,1,1,1,1,1,1,1         # 2.1 - 3.0  (21-30)
    )
    asc <- read.delim(paste0(utils.path,"/ascii_dimensions.txt"), as.is=TRUE, comment.char="#")
    rel <- sapply(x, function(y) sum(asc[match(unlist(strsplit(y,"")),asc[,1]),2]) )
    fac.idx <- as.integer(round(cex*10,0))
    max(rel) * factors[fac.idx] + start + extra
}


apa.names$hacks <- c(apa.names$hacks, "calculate.mono.width")
calculate.mono.width <- function(x, cex=1) {
    
    ## calculates minimum width in pixels to accomodate the largest element from a vector of strings 'x', when plotted with par(family="mono")
    ## holds for cex = { 0.8 1.0 1.2 1.4 1.6 } using png()
    ## tested on R2.14.1/Win7 and R3.1.0/CentOS6&Mac
    
    if (cex < 0.8 | cex > 1.6) message("WARNING: cex value outside 0.8-1.6 range: result may not be accurate!\n")
    pix.per.char <- 5.4 + round((cex-1)/0.2,0)   # empirically determined mean pixels per char when family="mono", see limitations above
    pix.per.char * max(nchar(x))
}


apa.names$hacks <- c(apa.names$hacks, "calculate.barplot.xmax")
calculate.barplot.xmax <- function(x, beside=FALSE) {
    
    ## calculates max x value when calling "barplot(x)"
    ## used when you want to auto-adjust x limits in the "barplot(x)" call,
    ##  without having to call "barplot(x)" first just to see what they are.
    
    if (is.vector(x)) {
        ## vector
        (length(x)-1)*1.2+0.7
    } else if (!beside) {
        ## matrix treated as a vector of stacked values
        (ncol(x)-1)*1.2+0.7
    } else {
        ## matrix, NOT stacked
        (nrow(x)*ncol(x)-1)+1.5+(ncol(x)-1)
    }
}


apa.names$hacks <- c(apa.names$hacks, "extend.xylim")
extend.xylim <- function(x, amount, percent=TRUE) {
    
    if (percent) amount <- abs(diff(range(x)))*amount
    c( min(x)-amount, max(x)+amount )
}


apa.names$hacks <- c(apa.names$hacks, "suffix.duplicates")
suffix.duplicates <- function(x, alpha=FALSE) {
    
    ## "removes" duplicates by suffixing them with numbers (or letters)
    
    w1 <- which(duplicated(x))
    for (u in unique(x[w1])) {
        wu <- which(x == u)
        n <- length(wu)
        if (alpha) {
            if (n > 26) {
                reps <- ceiling(n/26)
                amat <- matrix("", ncol=reps, nrow=26*reps)
                for (i in 1:reps) {
                    amat[(26*(i-1)+1):(26*reps),i] <- letters
                }
                suff <- apply(amat[1:n,], 1, paste, collapse="")
            } else {
                suff <- letters[1:n]
            }
        } else {
            suff <- 1:n
        }
        x[wu] <- paste(x[wu],suff,sep=".")
    }
    x
}


apa.names$hacks <- c(apa.names$hacks, "head.list")
head.list <- function(lst, n=6) {
    
    ## Provides "head" method for list objects, especially with matrices / dataframes.
    
    named <- length(names(lst)) > 0
    for (i in 1:length(lst)) { 
        cap <- capture.output(head(lst[[i]], n=n))
        name <- ifelse(named, paste("$`",names(lst)[i],"`",sep=""), paste("[[",i,"]]",sep=""))
        message(name)
        for (j in 1:(n+1)) message(cap[j])
        message("\n")
    }
}


apa.names$hacks <- c(apa.names$hacks, "tail.list")
tail.list <- function(lst, n=6) {
    
    ## Provides "tail" method for list objects, especially with matrices / dataframes.
    
    named <- length(names(lst)) > 0
    for (i in 1:length(lst)) { 
        cap <- capture.output(tail(lst[[i]], n=n))
        name <- ifelse(named, paste("$`",names(lst)[i],"`",sep=""), paste("[[",i,"]]",sep=""))
        message(name)
        for (j in 1:(n+1)) message(cap[j])
        message("\n")
    }
}


apa.names$hacks <- c(apa.names$hacks, "head.list2")
head.list2 <- function(lst, max.depth=NA) {
    
    ## Provides a much more useful "head" method for list objects.
    ## "max.depth" sets max recursion depth.  "0" prevents recursion.  "NA" allows unlimited recursion.
    
    recurse <- function(lst, depth.now, max.depth) {
        depth.now = depth.now + 1
        for (i in 1:length(lst)) { 
            if (is.ndfl(lst[[i]])) {
                if (depth.now < max.depth) {	# then we can go one more level
                    heads[[i]] <- recurse(lst[[i]], depth.now, max.depth)
                } else {
                    IM("Max recurson depth",max.depth,"reached!")
                }
            } else {
                heads[[i]] <- capture.output(head(lst[[i]]))
            }
        }
    }
    
    if (is.na(max.depth)) { max.depth <- .Options$expressions }	# current recursion limit
    heads <- recurse(lst, 0, max.depth)
    print(heads, quote=FALSE)
}


apa.names$hacks <- c(apa.names$hacks, "slice.list")
slice.list <- function(lst, N, method=c("elem","cols","rows")) {
    
    ## Subsets each element of a list to create a new list from the subsets
    ## subset method must be one of "rows" or "cols" (if elements are dfs/mats) or "elem" (if elements are lists)
    ## 'N' is a vector specifying which rows/cols/elements are in each subset
    
    method <- match.arg(method)
    slc <- lst
    for (i in 1:length(lst)) {
        if (method == "elem") {
            declassified <- lst[[i]]
            suppressWarnings(class(declassified) <- "list")  # breaks method restrictions for list-like objects with exotic classes
            slc[i] <- declassified[N]
        } else if (method == "cols") {
            slc[i] <- if (length(lst[[i]])==0) { lst[i] } else { list(lst[[i]][,N]) }
        } else if (method == "rows") {
            slc[i] <- if (length(lst[[i]])==0) { lst[i] } else { list(lst[[i]][N,]) }
        }
    }
    slc
}


apa.names$hacks <- c(apa.names$hacks, "unpack.list")
unpack.list <- function(x, delim=".") {
    
    ## Converts a 2-level list (list where each element is a list with non-list elements)
    ##   into a 1-level list (where all elements are non-line elements)
    ## Example:
    ## unpack.list(list( A=list(x,y), B=list(z,w) )) => list( A.1=x, A.2=y, B.1=z, B.2=w )
    
    L <- length(x)
    ll <- listLengths(x)
    for (i in 1:L) if (length(names(x[[i]]))==0) names(x[[i]]) <- 1:length(x[[i]])
    out <- vector("list", length=sum(ll))
    j <- 0
    for (i in 1:L) {
        out[(j+1):(j+length(x[[i]]))] <- x[[i]]
        j <- j+length(x[[i]])
    }
    names(out) <- paste0(rep(names(x),times=ll),delim,unlist(lapply(x,names)))
    out
}


apa.names$hacks <- c(apa.names$hacks, "new.list")
new.list <- function(names, elements=NULL) {
    
    ## Shortcut function to create an empty, named list from a vector of names
    ## "elements", if not null, will assign "elements" to each element of the new list (e.g., additional empty list structure, empty matrix, etc.)
    
    if (is.null(elements)) { 
        nl <- vector("list", length=length(names))
    } else {
        nl <- lapply(names, FUN=function(x){elements})
    }
    names(nl) <- names
    nl
}


apa.names$hacks <- c(apa.names$hacks, c("named.list","named.vector"))
named.list <- named.vector <- function(x, xnames) {
    
    ## Shortcut function to create a named list from a list object and a names vector
    
    names(x) <- xnames
    x
}


apa.names$hacks <- c(apa.names$hacks, "new.vector")
new.vector <- function(names, values=NA) {
    
    ## Shortcut function to create an empty, named vector from a vector of names
    ## "values" will be the vector values.  Can be length=1 (all vector = same values) or length > 1; gets recycled if length < length(names).
    
    LN <- length(names)
    LV <- length(values)
    
    if (LV==LN) {
        nv <- values
    } else if (LV==1) {
        nv <- rep(values, LN)
    } else {
        times <- ceiling(LN / LV)
        if (LN %% LV != 0) warning(paste("'names' length [",LN,"] is not a multiple of 'values' length [",LV,"]!",sep=""))
        nv <- rep(values, times)[1:LN]
    }
    names(nv) <- names
    nv
}


apa.names$hacks <- c(apa.names$hacks, "data.frame2")
data.frame2 <- function(types.list, nrows=0, dim.names=NULL) {
    
    ## Shortcut function to create an empty, named dataframe
    ## 'types.list' should be a list of type chars (like used in scan()), e.g. list("",0,T) for char, num, log
    ## 'types.list' can also be named if colnames desired.
    
    if (is.data.frame(types.list)) {
        df <- types.list[rep(1,nrows),]
        modes <- sapply(df, mode)
        for (i in 1:ncol(df)) df[,i] <- NA
        for (i in 1:ncol(df)) mode(df[[i]]) <- modes[i]
    } else {
        if (length(names(types.list))==0) { 
            names(types.list) <- paste("V",1:length(types.list),sep="") 
        }
        for (i in 1:length(types.list)) {
            types.list[[i]] <- rep(types.list[[i]], nrows)
        }
        types.list[[i+1]] <- FALSE
        names(types.list)[[i+1]] <- "stringsAsFactors"
        df <- do.call(data.frame, types.list)
        if (length(dim.names)>0) { 
            row.names(df) <- dim.names[[1]] 
            names(df) <- dim.names[[2]] 
        }
    }
    df
}


apa.names$hacks <- c(apa.names$hacks, "as.data.frame2")
as.data.frame2 <- function(..., stringsAsFactors=.Options$stringsAsFactors) {
    
    ## Shortcut function to make as.data.frame() share the vector-expanding abilities of cbind()
    
    pre <- list(...)  # matrices, dfs and/or vectors of any length
    x <- list(c()); n <- 0
    for (i in 1:length(pre)) {
        if (is.null(ncol(pre[[i]]))) {
            n <- n + 1
            x[[n]] <- pre[[i]]
        } else if (is.na(ncol(pre[[i]]))) {
            n <- n + 1
            x[[n]] <- pre[[i]]
        } else {   # must have columns?
            for (j in 1:ncol(pre[[i]])) {
                n <- n + 1
                x[[n]] <- pre[[i]][,j]
            }
        }
    }
    y <- x
    L <- listLengths(x)
    u <- unique(L)
    M <- max(L)
    rem <- M %% u
    if (any(rem>0)) {
        stop("Some vectors cannot be evenly recycled into max vector length!\n")
    }
    times <- M / L
    for (i in which(L<M)) { 
        y[[i]] <- rep(x[[i]], times=times[i]) 
    }
    as.data.frame(y, stringsAsFactors=stringsAsFactors)
}


apa.names$hacks <- c(apa.names$hacks, "real", "real.only")   # 'real' for legacy purposes
real <- real.only <- function(obj, logical=FALSE) {
    
    ## Removes NA, NaN, Inf, -Inf entries from an object
    ## "logical=T" returns a logical object instead
    ## IF CHARACTER: removes NA, "" entries
    
    unreal <- list(
        "logical"=c(NA),
        "character"=c(NA,""),
        "numeric"=c(NA,NaN,-Inf,Inf)
    )
    
    ok <- obj
    if (is.list(obj)) {
        for (i in 1:length(obj)) {
            keep <- !(obj[[i]] %in% unreal[[ mode(obj[[i]]) ]])
            if (logical) {
                ok[[i]] <- keep
            } else {
                ok[[i]] <- obj[[i]][keep]
            }
        }
    } else {
        keep <- !(obj %in% unreal[[mode(obj)]])
        if (logical) {
            ok <- keep
        } else {
            ok <- ok[keep]
        }
    }
    return(ok)
}


apa.names$hacks <- c(apa.names$hacks, "is.real")
is.real <- function(x) {
    
    !is.na(x) & !is.infinite(x) & !is.complex(x)
    
}


apa.names$general <- c(apa.names$general, "translate")
translate <- function(vec, x, y) {
    
    ## R port of Perl's tr/// function
    ## vec = input to translate x values into y values
    ## x=from, y=to, length(x)=length(y)
    ## x cannot have duplicate values, but y can
		
		new <- vec
		for (i in 1:length(x)) new[vec==x[i]] <- y[i]
		new
}


apa.names$general <- c(apa.names$general, "convert")
convert <- function(x, ids, column=1, na.action=c("ignore","remove","NA"), multi.action=c("first","concat"), delim=";") {
		
                                        # converts entries in x[,column] from values in ids[,1] to values in ids[,2], where possible
                                        # na.action indicates handling of unconvertibles: 
                                        #  "ignore" (leave unchanged), "drop" (drop row), or "NA" (convert to NA)
                                        # multi.action controls replacement by ids[,2] values when ids[,1] is not singular:
                                        #  "first" takes first matching value (default match() behavior), "concat" concatenates unique ids[,2] values with 'delim'
		
		na.action <- match.arg(na.action)
		multi.action <- match.arg(multi.action)
		w <- x[,column] %in% ids[,1]
		if (sum(w)==0) stop("No ids were matched!\n")
		if (multi.action == "first") {
        x[w,column] <- ids[match(x[w,column],ids[,1]),2]
		} else if (multi.action == "concat") {
        w2 <- which(ids[,1] %in% x[,column])
        ids2 <- breakout(lapply(split(ids[w2,2], ids[w2,1]), function(x) paste(sort(unique(x)), collapse=delim) ), reverse=TRUE)
        ids2 <- ids2[match(ids[w2,1],ids2[,1]),]
        x[w,column] <- ids2[match(x[w,column],ids2[,1]),2]
		}
		if (sum(w)<nrow(x)) {
        if (na.action == "ignore") {
            x
        } else if (na.action == "remove") {
            x[w,]
        } else if (na.action == "NA") {
            x[!w,2] <- NA
            x
        }
		} else {
        x
		}
}


apa.names$hacks <- c(apa.names$hacks, "NULL2NA")
NULL2NA <- function(x) {
    
    ## Converts any length-0 returns (incl. NULL) to NA
    
    if (length(x)==0) {
        NA
    } else {
        x
    }
}


apa.names$hacks <- c(apa.names$hacks, "NAfy")
NAfy <- function(obj, include=c(NaN,Inf,-Inf), add=NULL) {
    
    ## Converts all NaN, Inf, -Inf (or whatever is in 'include') to NA
    ## "add", if specified, is a vector of additional things to convert to NA (so don't have to re-enter the original list)
    
    include <- c(include, add)
    if (is.list(obj)) {		# mainly for data.frames
        for (i in 1:length(obj)) {
            obj[[i]][falsify(obj[[i]]%in%include)] <- NA 
        }
    } else {
        obj[falsify(obj%in%include)] <- NA
    }
    return(obj)
}


apa.names$hacks <- c(apa.names$hacks, "valuate")
valuate <- function(x, value) {
    
    ## Converts all NA/NaN, to 'value' 
    
    x[is.na(x)] <- value
    return(x)
}


apa.names$hacks <- c(apa.names$hacks, "numberize")
numberize <- function(x, sort=FALSE) {
    
    ## converts character levels to numbers
    
    ternary(sort, as.numeric(factor(x)), as.numeric(factor2(x)))
}


apa.names$hacks <- c(apa.names$hacks, "blankify")
blankify <- function(x) {
    
    ## Converts any length-0 subset, e.g. which(1:3==4), to an empty vector
    
    if (length(x)==0) {
        c()
    } else {
        x
    }
}


apa.names$hacks <- c(apa.names$hacks, "falsify")
falsify <- function(obj) {
    
    ## Converts all NA entries in logical obj to FALSE
    
    if (is.list(obj)) {		# mainly for data.frames
        for (i in 1:length(obj)) {
            obj[[i]][is.na(obj[[i]])] <- FALSE
        }
    } else {
        obj[is.na(obj)] <- FALSE
    }
    return(obj)
}


apa.names$hacks <- c(apa.names$hacks, "truthify")
truthify <- function(obj) {
    
    ## Converts all NA entries in logical obj to TRUE
    
    if (is.list(obj)) {		# mainly for data.frames
        for (i in 1:length(obj)) {
            obj[[i]][is.na(obj[[i]])] <- TRUE
        }
    } else {
        obj[is.na(obj)] <- TRUE
    }
    return(obj)
}


apa.names$hacks <- c(apa.names$hacks, "zerofy")
zerofy <- function(obj) {
    
    ## Numeric objects: convert NA, NaN to 0
    ## Character objects: convert NA, NaN to ""
    
    if (any(is.na(obj))) {
        if (is.list(obj)) {
            for (i in 1:length(obj)) {
                if (mode(obj[[i]]) == "character") {
                    obj[[i]][is.na(obj[[i]])] <- ""
                } else {
                    obj[[i]][is.na(obj[[i]])] <- 0
                }
            }
        } else {
            if (mode(obj) == "character") {
                                        #				for (i in 1:ncol(obj)) { obj[is.na(obj[,i]),i] <- "" }   # looping over columns here, because can crash trying to index very lg. objs all at once
                obj[is.na(obj)] <- ""
            } else {
                                        #				for (i in 1:ncol(obj)) { obj[is.na(obj[,i]),i] <- 0 }
                obj[is.na(obj)] <- 0
            }
        }
    }
    return(obj)
}


apa.names$hacks <- c(apa.names$hacks, "nonzero")
nonzero <- function(obj, na.rm=FALSE) {
    
    ## returns a vector of nonzero entries of 'obj'

    if (na.rm) {
        obj[falsify(obj!=0)]
    } else {
        obj[obj!=0]
    }
}


apa.names$general <- c(apa.names$general, "threshold")
threshold <- function(x, thresh, method=c("gt","ge","lt","le"), absolute=FALSE, replace.with=NULL, quantile=FALSE) {
    
    ## thresholds the values in an object (up or down, depending on "method")
    ## by default, thresholded values are changed to the threshold value.
    ## 'absolute=TRUE' will threshold +-thresh, preserving sign,
    ##  e.g. 'thresh=2, method="lt", absolute=T, replace.with=0' will cause values on (-2:2) to become 0.
    ##  e.g. 'thresh=2, method="ge", absolute=T, replace.with=0' will cause values on (-Inf,-2] and [2,Inf) to become 0.
    ## 'replace.with' will replace thresholded values with this value.
    ## 'quantile=TRUE' interprets 'thresh' as a quantile value (on [0,1])
    
    method <- match.arg(method)
    do.replace <- length(replace.with)>0
    greater <- grepl("^g",method)
    comp <- switch( method, gt=get(">"), ge=get(">="), lt=get("<"), le=get("<=") )
    rcomp <- switch( method, gt=get("<"), ge=get("<="), lt=get(">"), le=get(">=") )
    
    ## FIXME WORKING ON QUANTILE
    
    if (is.nlv(x) | is.matrix(x)) {
        if (absolute) {
            if (greater) {
                x[comp(x,thresh)] <- ifelse(do.replace, replace.with, thresh)
                x[rcomp(x,-thresh)] <- ifelse(do.replace, replace.with, -thresh)
            } else {
                x[rcomp(x,0) & comp(x,thresh)] <- ifelse(do.replace, replace.with, 0)
                x[comp(x,0) & rcomp(x,-thresh)] <- ifelse(do.replace, replace.with, 0)
            }
        } else {
            x[comp(x,thresh)] <- ifelse(do.replace, replace.with, thresh)
        }
    } else if (is.list(x) | is.data.frame(x)) {
        for (i in 1:ncol(x)) {
            if (absolute) {
                if (greater) {
                    x[comp(x[,i],thresh),i] <- ifelse(do.replace, replace.with, thresh)
                    x[rcomp(x[,i],-thresh),i] <- ifelse(do.replace, replace.with, -thresh)
                } else {
                    x[rcomp(x[,i],0) & comp(x[,i],thresh),i] <- ifelse(do.replace, replace.with, 0)
                    x[comp(x[,i],0) & rcomp(x[,i],-thresh),i] <- ifelse(do.replace, replace.with, 0)
                }
            } else {
                x[comp(x[,i],thresh),i] <- ifelse(do.replace, replace.with, thresh)
            }
        }
    } else {
        stop("Object to 'threshold' must be a numeric vector, list of numeric vectors, matrix, or data.frame!\n")
    }
    
    x
}


apa.names$hacks <- c(apa.names$hacks, "suniq")
suniq <- function(vec) {
    sort(unique(vec))
}


apa.names$hacks <- c(apa.names$hacks, "luniq")
luniq <- function(vec) {
    length(unique(vec))
}


apa.names$hacks <- c(apa.names$hacks, "linter")
linter <- function(...) {
#    length(intersect2(...))
    length(intersect(...))
}


apa.names$hacks <- c(apa.names$hacks, "lsetd")
lsetd <- function(...) {
#    length(setdiff2(...))
    length(setdiff(...))
}


apa.names$hacks <- c(apa.names$hacks, "expectation")
expectation <- function(x, round=NA) {
    ## 'x' is a numeric matrix
    ## returns expectation matrix for obs/exp calculations
    ## 'round' rounds output to that number of digits
    
    rp <- rowSums(x)/sum(x)
    cp <- colSums(x)/sum(x)
    y <- outer(rp,cp,"*")*sum(x)
    if (!is.na(round)) {
        round(y,round)
    } else {
        y
    }
}


apa.names$hacks <- c(apa.names$hacks, "duplicated2")
duplicated2 <- function(x) {
    
    ## broader version of duplicated()
    ## instead of asking, which entries *are duplicates*, asks: which entries *have duplicates*
    ## this is the set of all duplicates + all originals which have duplicates
    
    dup <- duplicated(x)
    x %in% x[duplicated(x)]
}


apa.names$general <- c(apa.names$general, "shift.case")
shift.case <- function(x, case) {
    
    ## changes case of the input (character) vector
    ## 'case' must be "upper", "lower", or "flip", indicating desired output case ('flip' flips all cases)
    
    if (!case %in% c("upper","lower","flip")) { stop("'case' must be one of 'upper', 'lower', or 'flip'!\n") }
    u2l <- cbind(LETTERS, letters)
    y <- x
    if (case == "upper") {
        lc <- match(x, u2l[,2])
        lcp <- which(!is.na(lc))
        y[lcp] <- u2l[lc[lcp],1]
    } else if (case == "lower") {
        uc <- match(x, u2l[,1])
        ucp <- which(!is.na(uc))
        y[ucp] <- u2l[uc[ucp],2]
    } else if (case == "flip") {
        lc <- match(x, u2l[,2])
        lcp <- which(!is.na(lc))
        uc <- match(x, u2l[,1])
        ucp <- which(!is.na(uc))
        y[lcp] <- u2l[lc[lcp],1]
        y[ucp] <- u2l[uc[ucp],2]
    }
    return(y)
}


apa.names$general <- c(apa.names$general, "qw")
qw <- function(...) {
	
    ## Similar to Perl's qw// operator: take an arbitrary number of literals and convert them to a character vector (so you don't have to type twice as many "s)
    ## Not perfect, however, due to R's rules for argument handling.  Basically R assumes the args must be legal symbol names or numeric values, so:
    ##  If any symbol is NOT a valid number or a valid R object name, it will fail:
    ##   Symbols with whitespace will fail (well, interpretation of whitespace will vary and may cause failure).
    ##   Symbols with numeric appearance will be evaluated first, thus the symbol 1.2.3 looks like an incorrect decimal and will fail.
    ##   Symbols with operators will usually fail.
    ##   Alphanumeric symbols which start with a number are neither numbers nor valid symbol names, and will fail.
    ## So it works well for words and most alphanumeric strings, but caveat emptor. 
    
    x <- as.character(deparse(substitute(list(...)),width.cutoff=500))
    if (length(x) > 1) {	# args > 500 bytes: deparse() will break them into multiple blocks
        for (i in 2:length(x)) { x[i] <- sub("^    ","",x[i]) }   # deparse adds 4 spaces for visual effect; remove them
    }
    y <- unlist(strsplit(gsub(" ","",gsub('\\"',"",sub("^list\\(","",sub("\\)$","",x)))), " *, *"))
    return(y)
}


apa.names$hacks <- c(apa.names$hacks, "rename")
rename <- function(x, names.list) {
	
	## changes dimnames of x using the list of names 'names.list'; names.list = list(rownames, colnames)
	
	if (length(names.list[[1]])>0) rownames(x) <- names.list[[1]]
	if (length(names.list[[2]])>0) colnames(x) <- names.list[[2]]
	x
}


apa.names$hacks <- c(apa.names$hacks, "dimnames2")
dimnames2 <- function(x, n) {
	
	## Competent version of dimnames() that can support NULL rownames or colnames on matrices
	
	ldx <- length(dim(x))
	if (length(n) != ldx) stop(paste("Length of dim names (",length(n),") not equal to number of dims (",ldx,")!",sep=""))
	if (ldx>2) {
		dimnames(x) <- n
	} else {
		rownames(x) <- n[[1]]
		colnames(x) <- n[[2]]
	}
	x
}


apa.names$hacks <- c(apa.names$hacks, "nameless")
nameless <- function(x, dims="ALL") {
	
	## Removes the names from an object
	## 'dims' is a vector of dimensions to remove names from (1=Rows, 2=cols; 3=Higher, arrays only)
	## 'dims=="ALL" strips names from all dimensions
	
	N <- length(dim(x))
	if (N == 0) {
		names(x) <- NULL
	} else {
		if (length(dims)==1) {
			if (dims=="ALL") {
				dims <- 1:N
			}
		}
		if (is.data.frame(x)) {
			if (1%in%dims) { rownames(x) <- NULL }
			if (2%in%dims) { colnames(x) <- paste("V", 1:ncol(x), sep="") }	# the "default" data.frame colnames
		} else {
			dimnames(x)[dims] <- list(NULL)
		}
	}
	return(x)
}


apa.names$hacks <- c(apa.names$hacks, "rownameless")
rownameless <- function(x, dims="ALL") {
	
	## Removes the rownames from an object
	
	rownames(x) <- NULL
	return(x)
}


apa.names$hacks <- c(apa.names$hacks, "colnameless")
colnameless <- function(x, dims="ALL") {
	
	## Removes the colnames from an object
	
	colnames(x) <- NULL
	return(x)
}


apa.names$hacks <- c(apa.names$hacks, "name")
name <- function(x, x.names) {
	
	## Sets names on an vector/list AND RETURNS OBJECT
	
	names(x) <- x.names
	return(x)
}


apa.names$hacks <- c(apa.names$hacks, "rowname")
rowname <- function(x, row.names) {
	
	## Sets rownames on an object AND RETURNS OBJECT
	
	rownames(x) <- row.names
	return(x)
}


apa.names$hacks <- c(apa.names$hacks, "colname")
colname <- function(x, col.names) {
	
	## Sets colnames on an object AND RETURNS OBJECT
	
	colnames(x) <- col.names
	return(x)
}


apa.names$hacks <- c(apa.names$hacks, "rename.list")
rename.list <- function(to, from) {
	
	## Applies names from one list to another
	
	names(to) <- names(from)
	to
}


apa.names$hacks <- c(apa.names$hacks, "rownamed.matrix")
rownamed.matrix <- function(df, class="numeric", stay.df=FALSE) { 
	
	## converts a data.frame with names in column 1 (and numeric data in cols 2:N) to a numeric matrix with rownames from col 1
    ## 'stay.df=TRUE' just a hack to return a rownamed data.frame with one less column
    
	rownames(df) <- df[,1]
    x <- df[,2:ncol(df),drop=FALSE]
    if (!stay.df) {
        x <- as.matrix(x)
        mode(x) <- class
    }
	x
}


apa.names$hacks <- c(apa.names$hacks, "matrix2dataframe")
matrix2dataframe <- function(mat, colname1="rownames") { 
		 
	## converts a matrix with rownames to a data.frame with rownames in column 1
	## basically the inverse of rownamed.matrix()

	df <- as.data.frame(mat)
	df <- cbind(rownames(mat), df)
	colnames(df)[1] <- colname1
	rownames(df) <- NULL
	df
}


apa.names$hacks <- c(apa.names$hacks, "zerofy.numeric")
zerofy.numeric <- function(mat) { 
	
	for (i in ncol(mat)) mat[,i] <- gsub("%","",gsub(",","",mat[,i]))  # strip commas and percent signs
	mode(mat) <- "numeric"
	zerofy(mat)
}


apa.names$general <- c(apa.names$general, "downcast")
downcast <- function(x, verbose=c(0,1,2)) { 
	
	## Attempts the following operations on a vector's storage mode:
	## Downcast Character to Complex, Numeric, or Logical.
	## Downcast Complex to Numeric or Logical.
	## Downcast Numeric to Logical.
	## Only returns downcast vector if there is no detectable loss of data; otherwise returns original.
	
	if (length(verbose)>1) verbose <- verbose[1]
	recastings <- list(character=c("complex","logical"), complex="numeric", numeric="logical")
	
	test <- function(v, m) {  
		## v = vector, m = new mode
		## Function to compare recast values to originals and test success of recasting
		## Designed to test ONLY these recastings: character->complex, character->logical, complex->numeric, numeric->logical
		##  - ANY OTHER RECASTING MAY FAIL THE TESTS, either obviously or otherwise...
		v2 <- suppressWarnings(as(v, m))
		if (mode(v)=="character") {
			if (m=="logical") {
				## character to logical: test for change in N unique values
				## recasting only succeeds for certain strings.
				okT <- sum(v2)==sum(v %in% c("TRUE","true","T"))
				okF <- sum(!v2)==sum(v %in% c("FALSE","false","F"))
				okN <- sum(is.na(v2))==sum(is.na(v))
				agree <- okT & okF & okN
				if (verbose>0) message(paste(mode(v),m,agree,":",okT,okF,okN))
			} else {  
				## character to complex: test for change in NA content
				## anything not recognizable as a number will become NA
				## however, NaNs are also picked up with is.na(), which will confuse things
				nav <- which(v=="NA")
				nav2 <- which(is.na(v2) & !is.nan(v2))
				agree <- length(nav)==length(nav2) & all(nav==nav2)
				if (verbose>0) message(paste(mode(v),m,agree,":",length(nav),length(nav2),all(nav==nav2)))
			}
		} else if (mode(v)=="complex") {
			## complex to numeric: test for loss of nonzero imaginary components
			i0 <- v2-v==0
			agree <- length(v)==length(v2) & all(i0)
			if (verbose>0) message(paste(mode(v),m,agree,":",length(v),length(v2),all(i0)))
		} else if (mode(v)=="numeric") { 
			## numeric to logical: test for binary-ness of numeric data
			## because any nonzero numeric will recast to TRUE, although only { 0 1 NA } are really "logical"
			agree <- all(v %in% c(0,1,NA))
			if (verbose>0) message(paste(mode(v),m,agree))
		}
		ifelse (agree, TRUE, FALSE)
	}
	
	recast <- function(v) {
		## v = vector
		## Function to test downcast options and return lowest successful storage mode
		m1 <- m2 <- mode(v)  # initialize recast mode as original mode
		## Test to see if v can be downcast 
		if (m1 == "character") {
			if (test(v, "logical")) {  # steepest downcast -- test this first
				m2 <- "logical"
			} else if (test(v, "complex")) {  # otherwise, might be some kind of number
				m2 <- "complex"
			}
		} else if (m1 == "complex") {  # may be real not imaginary
			if (test(v, "numeric")) m2 <- "numeric"
		} else if (m1 == "numeric") {  # may be recastable as logical (i.e. numeric but binary)
			if (test(v, "logical")) m2 <- "logical"
		} else if (m1 == "logical") {  # lowest-information storage mode; can't downcast further
			m2 <- "logical"
		}
		## Recasting only "downcasts" mode one level; may be able to go further if m2 is complex or numeric
		if (m1 != m2 & m2 %in% c("complex","numeric")) {
			## If m2 == "complex", then recast from character.  May be able to go to numeric.
			## If m2 == "numeric", then recast from complex.  May be able to go to logical.
			if (test(v, recastings[[m2]])) m2 <- recastings[[m2]]  # additional downcast was successful
		}
		m2
	}
	
	y <- x
	
	if (is.list(x)) {  # list/data.frame
		for (i in 1:length(x)) {
			new.mode <- recast(x[[i]])
			if (new.mode != mode(x[[i]])) y[[i]] <- as(x[[i]], new.mode)
			if (verbose>1) message("Downcast column ",i," from ",mode(x[[i]])," to ",new.mode)
		}
	} else if (is.atomic(x)) {  # vector/matrix/array
		new.mode <- recast(x)
		if (new.mode != mode(x)) {
			y <- as(x, new.mode)
			if (verbose>1) message("Downcast from ",mode(x)," to ",new.mode)
		}
	} else {
		warn("Can only downcast 'list' and 'atomic' objects!\n")
	}
	
	y
}


apa.names$general <- c(apa.names$general, "remode")
remode <- function(x,m) {
    
    ## changes storage mode on a vector or matrix

    if (length(dim(x))>0) x <- as.matrix(x)  # may be pulled from a dataframe
    mode(x) <- m
    x
}


apa.names$general <- c(apa.names$general, "deattribute")
deattribute <- function(x, rmv=NULL, grep=FALSE) {
    
    ## removes attributes on an object
    ## 'rmv' provides a list of attribute names to remove (default: all)
    ## 'grep' will grep strings in 'rmv' instead of exact-matching them into attribute names
    
    if (length(rmv)==0) {
        attributes(x) <- NULL
    } else {
        if (grep) {
            w.rmv <- mgrep(rmv,names(attributes(x)),value=TRUE)
        } else {
            w.rmv <- which(names(attributes(x)) %in% rmv)
        }
        for (i in w.rmv) attributes(x)[i] <- NULL
    }
    x
}


apa.names$hacks <- c(apa.names$hacks, "factor2")
factor2 <- function(vec, ord) { 
    
    ## Converts to a factor with correct ordering, i.e. the order presented in the vector
    
    vec2 <- vec
    levs <- unique(vec[!is.na(vec)])   # preserves order of appearance
    LL <- length(levs)
    LV <- length(vec)
    flevs <- 1:LL
    whichlev <- matrix(0, nrow=LL, ncol=LV)
    for (i in 1:LL) whichlev[i,falsify(vec2==levs[i])] <- i
    whichlev[1,is.na(vec)] <- NA
    fac <- as.factor(colSums(whichlev))
    levels(fac) <- levs
    return(fac)
}


apa.names$general <- c(apa.names$general, "show.factor")
show.factor <- function(x, ...) {
    
    ## displays character and numeric versions of factor
    ## '...' are optional supplementary vectors to display (e.g. name vector that factor was derived from)
    ## 
    ## example: mat.fac <- factor2(sub("_[0-9]+$","",colnames(mat)))
    ##          show.factor(mat.fac)
    ##          show.factor(mat.fac, colnames=colnames(mat))
    
    y <- list(...)
    Y <- length(y)
    z <- data.frame(Labels=as.character(x), Levels=as.numeric(x))
    if (Y>0) {
        if (length(names(y))==0) names(y) <- paste0("V",1:Y)
        for (i in 1:length(y)) z <- cbind(z, y[i])
    }
    z
}


apa.names$general <- c(apa.names$general, "defactor")
defactor <- function(df, verbose=FALSE) { 
	
	## Converts factors to original values in a dataframe
	
	types <- c("logical","complex","numeric","character")  # no methods for binary, but your df probably doesn't have any anyway.
	if (all(sapply(df, is.list))) {    # mangled "data frame", as per t(sapply(data.frame)) which sapply cannot figure out.  But you should have used do.call(rbind,lapply(data.frame))
		new <- new.list(names(df))
		for (i in 1:ncol(df)) {
			new[[i]] <- unlist(df[,i])
		}
		df <- as.data.frame(new)
	} else {
		for (i in which(sapply(df, is.list))) {    # mangled "data frame", as per t(sapply(data.frame)) which sapply cannot figure out.  But you should have used do.call(rbind,lapply(data.frame))
			df[,i] <- unlist(df[,i])
		}
	}
	for (i in which(sapply(df, is.factor))) {
		levs <- levels(df[,i])
		vec <- as.vector(df[,i])
		for (type in types) {
			as.type <- levs
			suppressWarnings( mode(as.type) <- type )
			if (all(falsify(levs == as.type))) {	# matched datatype
				if (verbose) { IM("Column",i,"is",type) }
				df[,i] <- as(vec,type)
				break
			} else {
#				if (verbose) { IM("Column",i,"is not",type) }
			}
		}
		if (verbose) { if (is.factor(df[,i])) { IM("Failed to defactor column",i) } }
	}
	return(df)
}


apa.names$general <- c(apa.names$general, "err.ord")
err.ord <- function(vec, zap=NA) { 
	
	## Returns orders-of-magnitude of measurement error (i.e. min, max number of decimals for any number in a vector)
	## "zap": curb error magnitude by rounding at 'zap' decimals
	
	if (!is.nlv(vec)) { stop("Input must be a non-list vector!\n") }
	errs <- as.numeric(sapply(as.character(vec), simplify=TRUE, FUN=function(x){strsplit(x,".",fixed=TRUE)[[1]][2]}))	# getting decimals this way controls arithmetical error
	errs[is.na(errs)] <- 0	# these were integers
	if (!is.na(zap)) { errs <- round(errs, zap) }
	is.dec <- errs != 0
	if (any(is.dec)) {	# some decimals
		ndec <- sapply(errs, simplify=TRUE, nchar)
		ord.min <- ifelse(sum(is.dec) == length(is.dec), min(ndec), 0)	# if any integers, min ord = 0
		ord.max <- max(ndec)
		return( c(ord.min, ord.max) )
	} else {		# all integers
		return( c(0,0) )
	}
}


apa.names$hacks <- c(apa.names$hacks, "now.seed")
now.seed <- function() {
	
	## Creates a unique random seed from the current date and time
	
    x <- strsplit(gsub("[A-Z: -]", "", Sys.time()), "")[[1]]
    y <- as.numeric(paste(sample(rev(x), 8), collapse = ""))
	z <- y * sample(c(-1,1), 1)
    return(z)
}


apa.names$general <- c(apa.names$general, "centered.window")
centered.window <- function(x,y,width) { 
	
	start <- min(x,y)
	end <- max(x,y)
	mid <- start+(end-start+1)/2
	c(mid-width/2,mid+width/2-1)
}


apa.names$general <- c(apa.names$general, "factorize")
factorize <- function(N, flag.primes=FALSE, primes.only=FALSE, extended=FALSE) {
	
	## Returns the modulus space for number N, i.e., all numbers that evenly divide N.
	## 'flag.primes=T' adds a logical column indicating prime factors.
	## 'primes.only=T' goes one step further and returns ONLY the prime factors.
	##	PRIME OPTIONS GET TIME-EXPENSIVE FOR LARGE N!
	## 'extended=T' returns not only the value of N/factor, but the power of the factor (# successive divisions) + remainder
	##	'extended' was developed for use by LCD()
	
	all.names <- c("factor","times","div.pwr","div.pwr.rem")
	prime.name <- "is.prime"
	
	division.power <- function(fac, N) {
		if (is.na(fac)) {
			return(c(NA, NA))
		} else if (fac == 0) {
			return(c(NA, NA))
		} else if (fac == 1) {
			return(c(NA, NA))
		} else if (fac > N) {
			return(c(0,N))
		} else if (fac == N) {
			return(c(1,0))
		} else {
			rem <- NA
			pwr <- 0
			current <- N
			while (is.na(rem)) {
				val <- current / fac
				if (is.decimal(val)) {
					rem <- current
				} else {
					pwr <- pwr + 1
					current <- val
				}
			}
			return(c(pwr,rem))
		}
	}
	
	if (is.na(N) | is.infinite(N)) {
		stop("Cannot factor NA or Inf entries!\n")
	} else if (N == 0) {
		if (extended) {
			y <- matrix(NA, ncol=2)
			names(y) <- all.names[1:2]
		} else {
			y <- matrix(NA, ncol=4)
			names(y)[1:4] <- all.names
		}
	} else {
		x <- which(sapply(1:N, FUN=function(x,i){i%%x==0},N))
		y <- as.data.frame(cbind(x,rev(x)))
		names(y) <- all.names[1:2]
		if (flag.primes | primes.only) { prime.col <- sapply(y[,1], is.prime) }
		if (flag.primes) {
			if (extended) {
				y <- cbind(y, t(sapply(y[,1], division.power, N)), prime.col)
				names(y) <- c(all.names[1:4], prime.name)
			} else {
				y <- cbind(y, prime.col)
				names(y) <- c(all.names[1:2], prime.name)
			}
		} else {
			if (primes.only) { y <- y[prime.col,] }
			if (extended) {
				y <- cbind(y, t(sapply(y[,1], division.power, N)))
				names(y) <- all.names[1:4]
			} else {
				names(y) <- all.names[1:2]
			}
		}
	}
	return(y)
}


apa.names$general <- c(apa.names$general, "is.prime")
is.prime <- function(vec, brute=FALSE, negatives=FALSE) {
    
    ## returns T/F for primeness.
    ## it is slow, due to "%in%" lookups.  The required prime list is loaded only once per R session.
    ## one prime list is used, taken from: http://primes.utm.edu/lists/small/
    ##	1. all primes <= 100K (    9,592 total,  65 Kb)		## DEPRECATED.
    ##	2. all primes <=   1M (   78,498 total, 603 Kb)		## DEPRECATED.
    ##	3. all primes <=  10M (  664,578 total,   6 Mb)		## DEPRECATED.
    ##	4. all primes <= 100M (5,761,456 total,  55 Mb)		## For simplicity only the largest list is loaded -> logical vector of length 1E8 @ 400MB, FYI.
    ## 
    ## The below used to be true, but then I converted to one master primes list and abolished stepped lookups:
    ##  "stepped lookup is used to keep runtimes short; longer lists loaded only if required.
    ##  N > 100M gets factorized by brute force if 'brute=TRUE', watch out!!!!!!!!!!!!!!!
    ##    otherwise, testing N > 100M fails: too large to bother with in this tool kit."
    
    if (!exists("apa_tools.primes.upto.100M")) {
        IM("One-time loading of primes list <= 1E8 @ 55MB...\n (into global object 'apa_tools.primes.upto.100M')")
        temp <- rep(F, 1E8)
        temp[as.numeric(scan(paste(utils.path,"primes/primes_up_to_100M.txt",sep="/"), what=0))] <- TRUE
        apa_tools.primes.upto.100M <<- temp    #####  GLOBAL  !!!!!
        attr(apa_tools.primes.upto.100M,"source") <<- "apa_tools"
        apa.names$data <<- unique(c(apa.names$data,"apa_tools.primes.upto.100M"))    #####  GLOBAL  !!!!!
    } else {
        src <- attributes(apa_tools.primes.upto.100M)$source
        fail <- FALSE
        if (length(src)==0) {
            fail <- TRUE
        } else if (src != "apa_tools") {
            fail <- TRUE
        }
        if (fail) {
            ## not the bona fide object, apparently
            ## somehow this name was chosen for an object already??
            ## will not overwrite someone else's object
            stop("Sorry, but somehow a different object named 'apa_tools.primes.upto.100M' already exists!  Will not overwrite.")
        }
    }
    
    brute.factor <- function(i)	{
        ## *Try hard to avoid using this*, since it isn't in C or Fortran (and even if it was...)
        ## Test for primeness via full factorization of number
        ## Only used if number exceeds 100M, since lookup table runs from 1-100M.
        ##  Arguably, this is the worst use case for this function.
        ## Insanely slow with very large numbers, but otherwise works well
        ms <- factorize(i)
        ifelse (nrow(ms) - 2 == 0, TRUE, FALSE)  # no divisors besides i and 1?
    }

    neg <- vec<0
    zero <- vec==0
    over <- vec>1E8
    float <- zapsmall(vec)!=as.integer(vec)
    posint <- !float&!neg&!zero&!over
    negint <- !float&neg
    is.p <- rep(FALSE, length(vec))
    is.p[posint] <- apa_tools.primes.upto.100M[vec[posint]]
    if (negatives) is.p[negint] <- apa_tools.primes.upto.100M[abs(vec[negint])]
    is.p[over] <- NA
    
    if (sum(over)>0) {
        if (brute) {
            is.p[over] <- sapply(vec[over], brute.factor)
        } else {
            IM("At least one number exceeded 1E8: will not test these unless 'brute=TRUE'!\n")
        }
    }
    
    names(is.p) <- vec
    is.p
}


apa.names$general <- c(apa.names$general, "LCD")
LCD <- function(vec, nmax=1E7) {
	
	## returns lowest common denominator for a vector of numbers (fractions of course...  but integers won't break it)
	## nmax = max allowed denominator when converting floats to fractions; passed to fractions() as max.denominator;
	##   if 'nmax' too low, sequence set will have lower granularity than given fractions in 'vec',
	##   if 'nmax' too high, algo adjusts to max 'nmax' required for representative granularity, so GENERALLY the runtime will not blow up
	##   but: beware float issues with R -- VERY high nmax (> 1E8) might get a denom size capable of resolving spurious float errors...
	##        this will definitely make your runtime explode!
	
	vec <- real(vec)		# no NA, Inf
	denoms <- unique(as.numeric(sapply(vec, FUN=function(x){ strsplit(attr(fractions(x, cycles=1000, max.denominator=nmax), 'frac'), '/')[[1]][2] })))
	denoms <- denoms[!is.na(denoms)]  # these NAs from integers, which all get denom 1 -- contribute nothing to calculation
	if (length(denoms) == 1) {
		lcd <- denoms[1]
	} else {
		facs <- vector("list", length=length(denoms))
		for (i in 1:length(denoms)) { facs[[i]] <- factorize(denoms[i], primes.only=TRUE, extended=TRUE)[,c(1,3)] }
		facs <- do.call(rbind, facs)   		# all factors w/ powers for all Ns in vec
		uf <- unique(facs[,1])
		ufacs <- cbind(uf, rep(0, length(uf)))	# unique factors with max powers observed for any N
		for (u in 1:length(uf)) { ufacs[u,2] <- max(facs[facs[,1]==ufacs[u],2]) }
		lcd <- prod(ufacs[,1] ^ ufacs[,2])	# product of unique factors raised to max powers
	}	
	return(lcd)
}


apa.names$general <- c(apa.names$general, "GCF")
GCF <- function(vec) {
	
	## returns greatest common factor for a vector of integers
	
	if (any(sapply(vec,is.decimal))) { stop("All values must be integers!\n") }
	facs <- vector("list", length=length(vec))
	for (i in 1:length(vec)) { facs[[i]] <- factorize(vec[i])[,1] }
	gcf <- max(intersect2(facs))
	return(gcf)
}


apa.names$general <- c(apa.names$general, "nCr")
nCr <- function(n, r) {
	
	if (r > n) { stop("r must be <= n!\n") }
	total <- factorial(n) / ( factorial(r)*factorial(n-r) )
	return(total)
}


apa.names$general <- c(apa.names$general, "nPr")
nPr <- function(n, r) {
	
	if (r > n) { stop("r must be <= n!\n") }
	total <- factorial(n) / factorial(n-r)
	return(total)
}


apa.names$hacks <- c(apa.names$hacks, "permn2")
permn2 <- function(n, r, replacement=FALSE) {
    
    ## Provides all n-permute-r sets, with or without replacement
    
	pass <- require("combinat")
	if (!pass) { stop("Cannot load required library 'combinat'!\n") }
	
	if (r == 1) {
		perms2 <- 
			if (length(n)>1) {
				as.matrix(sort(n))
			} else {
				as.matrix(1:n)
			}
	} else {
		revalue <- FALSE
		if (length(n)>1) {   # a custom distribution
			basis <- sort(n)
			n <- length(n)   # REPLACE 'n'
			revalue <- TRUE
		}
		if (r > n & !replacement) stop("Cannot have r > n unless replacement=TRUE!\n")
		
		if (replacement) {
			distrib <- rep(1:n, each=r)
			combs <- unique(t(apply(t(combn(n*r, r)), 1, function(x){distrib[x]})))
			perms <- unique(do.call(rbind,lapply(1:nrow(combs), function(i){do.call(rbind,permn(combs[i,]))})))
		} else {
			combs <- t(combn(n, r))   # first get unique combinations to permute
			perms <- do.call(rbind,lapply(1:nrow(combs), function(i){do.call(rbind,permn(combs[i,]))}))
		}
		if (revalue) {
			perms2 <- t(apply(perms, 1, function(x){basis[x]}))
		} else {
			perms2 <- perms
		}
		perms2 <- perms2[do.call(order,as.list(as.data.frame(perms2))),]
	}
	return(perms2)
}


apa.names$hacks <- c(apa.names$hacks, "combn2")
combn2 <- function(n, r, replacement=FALSE) {
    
	## Provides all n-choose-r sets, with or without replacement
     
	revalue <- FALSE
	if (length(n)>1) {  # a custom distribution
		basis <- sort(n)
		n <- length(n)
		revalue <- TRUE
	}
	if (r > n) { replacement <- TRUE }  # requires replacement, so ignores value of 'replacement' arg
	
	if (replacement) {
		combs <- unique(t(apply(permn2(n,r), 1, function(y){sort(y)})))  # unique sorted permutations = unique combinations
	} else {
		combs <- t(combn(n,r))
	}
	if (revalue) {
		combs2 <- t(apply(combs, 1, function(x){basis[x]}))
	} else {
		combs2 <- combs
	}
	return(combs2)
}


apa.names$general <- c(apa.names$general, "shannon.weaver")
shannon.weaver <- function(x) {
	
	## Shannon-Weaver Index (complexity) for a character vector
	
	-sum(sapply(unique(x), function(i){ p=sum(x==i)/length(x); p*log(p) }))
}


apa.names$general <- c(apa.names$general, "dot.product")
dot.product <- function(x, y) {
    
    ## http://stackoverflow.com/questions/15162741/what-is-rs-crossproduct-function
    
    x[1]*y[1] + x[2]*y[2]
}


apa.names$general <- c(apa.names$general, "cross.product")
cross.product <- function(x, y) {
    
    ## http://stackoverflow.com/questions/15162741/what-is-rs-crossproduct-function
    
    x[1]*y[2] - x[2]*y[1]
}


apa.names$general <- c(apa.names$general, "intersect.lines")
intersect.lines <- function(m1, b1, m2, b2) {
    
    ## point of intersection of two lines.
    ## lines 1 and 2 are indicated by their m (slope) and b (intercept) values.
    
    x <- (b2-b1)/(m1-m2)
    y <- m1*x+b1
    c(x,y)
}


apa.names$general <- c(apa.names$general, "visible.segment")
visible.segment <- function(m, b, xlim, ylim, point=NULL) {
    
    ## calculates where, if at all, a given straight line passes through the plot area.
    ## the line is given by its 'm' (slope) and 'b' (intercept) values.
    ## 'xlim' and 'ylim' are the limits of the plot (each a vector of length 2)
    ## 'point', if given, is a vector c(x,y).  *** Only required when 'm' is infinite ***
    ## 
    ## output is a vector of length 5:
    ##   values 1-4 are for sides 1-4 (per par(), etc): either there is a value indicating the point of intersection, or NA to indicate no intersection.
    ##   value 5 is the length of the line contained within the plot limits (or NA).
    ## NOTE: this calculates the intersection with x and y limits, NOT the intersection with the PLOT BOX, which is always just outside the limits!!!
    ##   to better visualize the points of intersection on the plot, run "abline(b, m); abline(h=ylim, v=xlim, lty=3)"
    
    if (m==0) {
        if (b %within% ylim) {
            ## horizontal line inside plot
            c(0, b, 0, b, diff(ylim))
        } else {
            ## horizontal line outside plot
            rep(NA,5)
        }
    } else if (is.infinite(m)) {
        if (length(point)==0) stop("the slope is infinite, and 'point' was not specified: cannot place your line!\n")
        if (point[1] %within% xlim) {
            ## vertical line inside plot
            c(point[1], 0, point[1], 0, diff(xlim))
        } else {
            ## vertical line outside plot
            rep(NA,5)
        }
    } else {
        xcross <- c( ylim[1]-b, ylim[2]-b )/m
        ycross <- c( m*xlim[1]+b, m*xlim[2]+b )
        hits <- c(
            side1=ifelse(xcross[1] %within% xlim, xcross[1], NA),  # if hits side 1, point of crossing, else NA
            side2=ifelse(ycross[1] %within% ylim, ycross[1], NA),  # if hits side 2...
            side3=ifelse(xcross[2] %within% xlim, xcross[2], NA),  # if hits side 3...
            side4=ifelse(ycross[2] %within% ylim, ycross[2], NA),  # if hits side 4...
            length=NA
        )
        ## calculate line distance within x,y limits
        if (all(!is.na(hits[c(1,3)]))) {
            x1 <- hits[1]; x2 <- hits[3]
            y1 <- ylim[1]; y2 <- ylim[2]
        } else if (all(!is.na(hits[c(2,4)]))) {
            x1 <- xlim[1]; x2 <- xlim[2]
            y1 <- hits[2]; y2 <- hits[4]
        } else {
            x1 <- ifelse(!is.na(hits[1]), hits[1], hits[3])
            x2 <- ifelse(!is.na(hits[2]), xlim[1], xlim[2])
            y1 <- ifelse(!is.na(hits[2]), hits[2], hits[4])
            y2 <- ifelse(!is.na(hits[1]), ylim[1], ylim[2])
        }
        hits[5] <- sqrt((x2-x1)^2+(y2-y1)^2)
        hits
    }
}


apa.names$dev <- c(apa.names$dev, "plot.vector")
plot.vector <- function(x, pch=1, col=1, lty=1, origin=NULL) {
    
    ## plots point 'x' as a vector.
    ## ADDS TO AN EXISTING PLOT.
    ## 'origin' is the origin (where vector line originates from), which is all 0 unless otherwise specified.
    
    if (length(origin)==0) {
        origin <- rep(0,length(x))
    } else {
        if (length(origin) != length(x)) stop("'x' and 'origin' must have same length!\n")
    }
    
    points(x[1], x[2], col=col, pch=pch)
    segments(origin[1],origin[2], x[1],x[2], col=col, lty=lty)
}


apa.names$dev <- c(apa.names$dev, "plot.polygon")
plot.polygon <- function(x, add=FALSE, pch=1, col=1, lty=1, ...) {
    
    ## plots a 2-column matrix of points (col 1 = x, col 2 = y)
    ## '...' are other args passed to plot.default

    if (add) {
        points(x, pch=pch, col=col, ...)
    } else {
        plot(x, pch=pch, col=col, ...)
    }
    if (length(col)==1) col <- rep(col, nrow(x))
    if (length(lty)==1) lty <- rep(lty, nrow(x))
    seg.arg <- list(...)
    for (i in 1:nrow(x)) {
        j <- ifelse(i<nrow(x), i+1, 1)
        do.call(segments, c(seg.arg, x0=x[i,1],y0=x[i,2], x1=x[j,1],y1=x[j,2], col=col[i], lty=lty[i]))
    }
}


apa.names$dev <- c(apa.names$dev, "hull.stats")
hull.stats <- function(x, y, col=1, lty=1, vertices=NULL, formulae=NULL, tolerance=1, plot.tolerance=NULL) {
    
    ## ADDS TO AN EXISTING PLOT ONLY
    ## plots and returns the convex hull, with a bunch of edge/vertex stats.
    ## 'vertices' toggles plotting numbered vertices; value is a color.
    ## 'formulae' toggles plotting of line formulae for each edge, as a legend.
    ##   value of 'formulae' is an 'x' position argument from legend() (e.g. "topleft", "bottomright", etc.)
    ##   ** edge formulae will be in the output data.frame regardless.
    ## 'tolerance' allows edge-point detection to be more flexible, as a scalar multiple of the empirical base tolerance 0.002203.
    ##   'tolerance=0' turns it off, requiring exact value matching (not recommended due to floating point issues).
    ## 'plot.tolerance' is a color value; if given, edge-matching points will be replotted in this color.
    ## output is  alist with vertex data and edge data.
    ##   vertex data contains the hull point indexes, x and y coords.
    ##   edge data contains from and to vertices and three other stats:
    ##    'density': the number of points that lie on the edge from vertex N to N+1.
    ##    'm', 'b': the slope and intercept of the edge from vertex N to N+1.
    
    x <- signif(real(x),8)  # remove NAs, infinites, and strip (most) floating-point issues
    y <- signif(real(y),8)  # "
    hull <- chull(x,y)
    H <- length(hull)
    I <- 1:H
    J <- c(2:H,1)
    titles <- rep("", H)
    out <- list(
        vertices=data.frame(pos=hull, x=x[hull], y=y[hull], density=0),
        edges=data.frame(from=I, to=J, m=0, b=0, density=0, tolerance=0)
    )
    ## 'tolerance' value allows you to scale how tolerant you want things to be, starting with the empirical base value of 0.002205
    ## for points "on an edge" the distance from the strict edge must not exceed 'tolerance' * 0.002205 * longest perpendicular line visual length (as a normalizer for the scale of the data)
    ## Example: tolerance on the plot diagonal: if x,y ranges are equal and diagonal length is 5, then tolerance will be ~0.01, so points must be this close to the diagonal to be considered "on" it.
    tscale <- 0.002205 * tolerance
    
    ## plot polygon
    for (i in I) {
        j <- J[i]
        segments(x[hull[i]], y[hull[i]], x[hull[j]], y[hull[j]], col=col, lty=lty)
    }
    ## calculate edge formulae (even if not plotted)
    ## also calculate point density per edge
    edge.points <- vertex.points <- list()
    for (i in I) {
        j <- J[i]
        xi <- x[hull[i]]; xj <- x[hull[j]]; yi <- y[hull[i]]; yj <- y[hull[j]]
        out$edges$m[i] <- m <- (yj-yi)/(xj-xi)
        out$edges$b[i] <- b <- yi-m*xi
        if (m==0) {
            titles[i] <- paste0("E",i,"-",j,":       horizontal at y=",ifelse(yi<0,"-"," "),abs(signif(yi,4)))
            out$edges$tolerance[i] <- tol <- tscale * diff(range(y))
            edge.points[[i]] <- which( abs(y-yi) <= tol )
        } else if (is.infinite(m)) {
            titles[i] <- paste0("E",i,"-",j,":       vertical at x=",ifelse(xi<0,"-"," "),abs(signif(xi,4)))
            out$edges$tolerance[i] <- tol <- tscale * diff(range(x))
            edge.points[[i]] <- which( abs(x-xi) <= tol )
        } else {
            titles[i] <- paste0("E",i,"-",j,": y=",ifelse(m<0,"-"," "),abs(signif(m,4)),"x",ifelse(b<0,"-","+"),abs(signif(b,4)))
            perpm <- -1/m
            perpb <- mean(c(yi,yj))-perpm*mean(c(xi,xj))  # perpendicular line running through midpoint of edge
            out$edges$tolerance[i] <- tol <- tscale * visible.segment(perpm, perpb, range(x), range(y))[5]   # tolerance perpendicular to edge
            edge.points[[i]] <- which( abs(y-signif(m*x+b,8)) <= tol )
        }
    }
    ## AFTER all edge points have been celculated, intersect them to get vertex points
    for (i in I) {
        j <- J[i]
        vertex.points[[i]] <- intersect( edge.points[[i]], edge.points[[j]] )
        out$vertices$density[i] <- length(vertex.points[[i]])
        ## not plotting vertex points, yet
    }
    ## then subtract vertex points from edges
    for (i in I) {
        j <- J[i]
        edge.points[[i]] <- setdiff( edge.points[[i]], c(vertex.points[[i]], vertex.points[[j]]) )
        out$edges$density[i] <- length(edge.points[[i]])
        if (plot.tolerance) points(x[edge.points[[i]]], y[edge.points[[i]]], pch=1, cex=1, col=plot.tolerance)
    }
    ## plot formulae if requested
    if (length(formulae)>0) legend(formulae, bty="n", legend=titles)
    ## number vertices LAST
    if (length(vertices)>0) for (i in 1:H) points(x[hull[i]], y[hull[i]], pch=paste0(i,""), col=vertices)
    ## last reporting blurb
    nV <- length(unlist(vertex.points))
    nE <- length(unlist(edge.points))
    message(paste0(nV," vertex points | ",nE," edge points | ",nV+nE," combined (",round(100*(nV+nE)/length(x),2),"% total)"))
    
    invisible(out)
}


apa.names$general <- c(apa.names$general, "winding")
winding <- function(pts, hull) {
    
    ## tests points for containment by a convex hull
    ## 'pts'=test point, 'hull'=ORDERED polygon, e.g. from perimiterize() or chull().  Ordering can be clockwise or counter.
    ##  for the above, rows are points, and columns are dimensions of measurement
    ## returns 1|0|-1; 1=contained, 0=on perimiter, -1=outside
    ## based on: https://www.engr.colostate.edu/~dga/dga/papers/point_in_polygon.pdf
    
    if (!is.matrix(pts)) pts <- matrix(pts, nrow=1)
    if (ncol(pts) != ncol(hull)) stop("'pts' and 'hull' have differing numbers of columns!\n")
    K <- ncol(pts)
    if (K != 2) stop("This algorithm can only handle 2D points and polygons!\n")
    
    wnum <- data.frame("Containment"=rep(NaN,nrow(hull)), "WindingNumber"=rep(NaN,nrow(hull)), "Path"=rep("",nrow(hull)))
    for (i in 1:nrow(pts)) {
        x <- pts[i,]
        path <- c()
        if (any(apply(hull, 1, function(x) all(x==pts[i,]) ))) {
            ## pts[i,] is also a vertex of 'hull'
            num <- NA
            path <- c(NA)
        } else {
            ihull <- hull
            for (k in 1:K) ihull[,k] <- ihull[,k]-x[k]  # translate ihull such that point x is the origin
            x <- rep(0,K)  # point x is now the origin
            num <- 0
            for (j1 in 1:nrow(ihull)) {
                j2 <- ifelse(j1==nrow(ihull),1,j1+1)
                rise <- ihull[j2,2]-ihull[j1,2]
                rising.sign <- sign(rise)
                run <- ihull[j2,1]-ihull[j1,1]
                
                increment <- NA  # the default increment, in case loop is broken
                
                if (rise==0) {
                    ## edge is parallel to x-axis
                    if (ihull[j1,2]==0) {
                        ## current edge contained by x-axis, but not necessarily the positive side
                        if (sign(ihull[j1,1]) + sign(ihull[j2,1]) == 0) {
                            ## edge crosses origin, thus pts[i,] is contained by edge; we are done
                            break
                        } else {
                            ## edge did not cross origin; ignore
                            increment <- 0
                        }
                    } else {
                        ## did not interact with x-axis at all
                        increment <- 0
                    }
                } else if (ihull[j1,2] == 0) {
                    ## leaving x-axis, but not necessarily the positive side
                    if (ihull[j1,1]>0) {
                        ## it was the positive side
                        increment <- rising.sign/2
                    } else {
                        ## not the positive side
                        increment <- 0
                    }
                } else if (ihull[j2,2] == 0) {
                    ## landing on x-axis, but not necessarily the positive side
                    if (ihull[j2,1]>0) {
                        ## it was the positive side
                        increment <- rising.sign/2
                    } else {
                        ## not the positive side
                        increment <- 0
                    }
                } else if (sign(ihull[j1,2]) + sign(ihull[j2,2]) == 0) {
                    ## x-axis was crossed, but not necessarily the positive side
                    if (run==0) {
                        ## edge parallel to y-axis
                        if (ihull[j1,1]==0) {
                            ## current edge sits on the y-axis, thus crosses origin, thus pts[i,] is contained by edge; we are done
                            break
                        } else if (ihull[j1,1]>0 & ihull[j2,1]>0) {
                            ## on positive side
                            increment <- rising.sign
                        } else {
                            ## not the positive side
                            increment <- 0
                        }
                    } else {
                        ## do the -b/m test, which resolves all other cases
                        m <- rise/run
                        b <- ihull[j1,2]-m*ihull[j1,1]
                        if (b==0) {
                            ## passed through origin, thus pts[i,] is contained by edge; we are done
                            break
                        } else if (-b/m>0) {
                            ## we crossed + side
                            increment <- rising.sign
                        } else {
                            ## we crossed - side
                            increment <- 0
                        }
                    }
                } else {
                    ## x-axis was not interacted with in any way
                    increment <- 0
                }
                num <- num + increment
                path <- c(path,increment)
            }
            if (is.na(increment)) {
                ## loop was broken; point was contained by edge
                num <- NA
                path <- c(path,NA)
            }
        }
        wnum[i,] <- list(ifelse(is.na(num),0,ifelse(num==0,-1,1)), num, paste(path,collapse=","))
    }
    wnum
}


apa.names$general <- c(apa.names$general, "polygon.overlap")
polygon.overlap <- function(x, detail=FALSE, strict=FALSE) {
    
    ## 'x' is a list of numeric matrices, each with 2 columns, containing 2D polygon coordinates.
    ## in each, rows represent points in 2D space.
    ## returns a square matrix of dimension=length(x), with values 1|0|-1 indicating polygons i,j intersect|touch|do not intersect

    ## FUNCTION 1
    vertex.containment.separating <- function(hull1, hull2) {
        ## separating axis method: http://content.gpwiki.org/index.php/Polygon_Collision#Separating_Axis
        ## ######### does not appear to be working completely right...
        if (nrow(hull1) <= nrow(hull2)) {
            ref <- hull1
            non <- hull2
        } else {
            ref <- hull2
            non <- hull1
        }
        V <- nrow(ref)
        cross <- new.list(1:V)
        tests <- rep(1,V)  # init all as non-intersecting
        for (v1 in 1:V) {
            v2 <- ifelse (v1<V, v1+1, 1)
            edge <- ref[v2,]-ref[v1,]  # edge vector
            perp <- c(-edge[2],edge[1])  # perpendicular vector
            perp <- perp/c(dist(rbind(c(0,0),perp)))  # unit length
#            IM(i,j,v); IM(edge); IM(perp)
            ref.proj <- ref %*% perp
            non.proj <- non %*% perp
#            segments(ref[v2,1],ref[v2,2], ref[v1,1],ref[v1,2], col=i+1, lty=v1)
#            segments(0,0, perp[1],perp[2], col=i+4, lty=v)
            cross[[v]] <-
                if (mean(ref.proj)<mean(non.proj)) {
                    outer(c(non.proj),c(ref.proj),"-")
                } else {
                    outer(c(ref.proj),c(non.proj),"-")
                }
            tests[v1] <- sign(min(cross[[v1]]))
        }
        tests  # -1, 0, or 1
    }
    
    ## FUNCTION 2
    vertex.containment.winding <- function(hull1, hull2) winding(hull1, hull2)  # -1, 0, or 1
    
    ## FUNCTION 3
    edge.intersection <- function(hull1, hull2, strict=FALSE) {
        ## edge intersection: http://stackoverflow.com/questions/563198/how-do-you-detect-where-two-line-segments-intersect
        ## point-line distance: https://en.wikipedia.org/wiki/Distance_from_a_point_to_a_line
        ## if 'strict=TRUE': touching edges or vertices are considered intersecting (1).  Otherwise, 'touching' (0).
        nr1 <- nrow(hull1)
        nr2 <- nrow(hull2)
        test <- class <- matrix(NA, nr1, nr2)
        for (v1 in 1:nr1) {
            v2 <- ifelse(v1<nr1, v1+1, 1)
            p <- hull1[v1,]
            p2 <- hull1[v2,]
            r <- p2-p
            for (w1 in 1:nr2) {
                w2 <- ifelse(w1<nr2, w1+1, 1)
                q <- hull2[w1,]
                q2 <- hull2[w2,]
                s <- q2-q
                coterminal <- all(p==q) | all(p==q2) | all(p2==q) | all(p2==q2)
                rxs <- cross.product(r, s)
                t <- cross.product(q-p, s/rxs)
                u <- cross.product(q-p, r/rxs)
                if (rxs==0) {
                    ## parallel
                    if (cross.product(q-p, r)==0) {
                        ## parallel collinear
                        ## NOW MUST TEST IF SEGMENTS OVERLAP OR NOT
                        rdr <- dot.product(r, r)
                        sdr <- dot.product(r, r)
                        t0 = dot.product(q-p, r/rdr)
                        t1 = dot.product(q+s-p, r/rdr)
                        t.overlap <- ifelse( (t0>0&t0<1) | (t1>0&t1<1), TRUE, FALSE )  # RETURNS FALSE IF ONLY COTERMINAL
                        if (t.overlap) {
                            ## parallel collinear, overlapping
                            test.value <- ifelse(strict, 1, 0)
                            class.value <- 0
                        } else if (coterminal) {
                            ## parallel collinear, coterminal (one segments ends where the other begins)
                            test.value <- ifelse(strict, 1, 0)
                            class.value <- 1
                        } else {
                            ## parallel collinear, disjoint
                            test.value <- -1
                            class.value <- 2
                        }
                    } else {
                        ## parallel non-collinear
                        test.value <- -1
                        class.value <- 3
                    }
                } else {
                    ## non-parallel
                    if (coterminal) {
                        ## non-parallel, but share a vertex
                        test.value <- ifelse(strict, 1, 0)
                        class.value <- 4
                    } else if (t>=0 & t<=1 & u>=0 & u<=1) {
                        ## non-parallel intersecting
                        ## NOW MUST TEST IF LINE 1 ENDS AT LINE 2, OR IF LINE 1 ACTUALLY CROSSES LINE 2
                        ## problem: using below point-line distance model, all values are identical...  (was this fixed?)
                        v1d <- abs((q2[2]-q[2])*p[1]-(q2[1]-q[1])*p[2]+q2[1]*q[2]-q2[2]*q[1])/sqrt((q2[2]-q[2])^2+(q2[1]-q[1])^2)    # v1 dist from w1->w2
                        v2d <- abs((q2[2]-q[2])*p2[1]-(q2[1]-q[1])*p2[2]+q2[1]*q[2]-q2[2]*q[1])/sqrt((q2[2]-q[2])^2+(q2[1]-q[1])^2)  # v2 dist from w1->w2
                        w1d <- abs((p2[2]-p[2])*q[1]-(p2[1]-p[1])*q[2]+p2[1]*p[2]-p2[2]*p[1])/sqrt((p2[2]-p[2])^2+(p2[1]-p[1])^2)    # w1 dist from v1->v2
                        w2d <- abs((p2[2]-p[2])*q2[1]-(p2[1]-p[1])*q2[2]+p2[1]*p[2]-p2[2]*p[1])/sqrt((p2[2]-p[2])^2+(p2[1]-p[1])^2)  # w2 dist from v1->v2
                        test.value <- ifelse(any(c(v1d,v2d,w1d,w2d)==0), ifelse(strict, 1, 0), 1)
                        class.value <- 5
                    } else {
                        ## non-parallel non-intersecting
                        test.value <- -1
                        class.value <- 6
                    }
                }
                test[v1,w1] <- test.value
                class[v1,w1] <- class.value
            }
        }
        list(test=test, class=class)
    }
    
    hulls <- lapply(x, function(y) y[chull(y),] )
    H <- length(hulls)
    
    v.test <- e.test <- combo <- matrix(NA,H,H,FALSE,list(names(hulls),names(hulls)))  # vertex-containment, edge-intersection tests; 'combo' is combination
    v.det <- e.det <- new.list(names(hulls), elem=new.list(names(hulls)))
    for (i in 1:H) {
        for (j in 1:H) {
            ##v.cont[i,j] <- vertex.containment.separating(hulls[[i]], hulls[[j]])
            e.det[[i]][[j]] <- edge.intersection(hulls[[i]], hulls[[j]], strict=strict)
            v.det[[i]][[j]] <- vertex.containment.winding(hulls[[i]], hulls[[j]])
            if (strict) v.det[[i]][[j]][v.det[[i]][[j]]==0] <- 1
            e.test[i,j] <- ifelse(all(e.det[[i]][[j]]$test==0), 1, max(e.det[[i]][[j]]$test))  # if all == 0, then polygon is identical to hull (so = 1)
            v.test[i,j] <- ifelse(all(v.det[[i]][[j]][,1]==0), 1, max(v.det[[i]][[j]][,1]))  # if all == 0, then polygon is embedded in hull (so = 1)
        }
    }
    for (i in 1:H) {
        for (j in 1:H) {
            combo[i,j] <- max(c(e.test[i,j],v.test[i,j],e.test[j,i],v.test[j,i]), na.rm=TRUE)  # make 'combo' symmetric
        }
    }
    
    output <- list(combined=combo, edge.summary=e.test, vertex.summary=v.test)
    if (detail) output <- c(output, list(edge.detail=e.det, vertex.detail=v.det))
    output
}


apa.names$general <- c(apa.names$general, "chrom.ord")
chrom.ord <- function(x) {
	
	## 'x' is a list of chromosome names
	## returns the ordered list, the way I typically order things
	
	y <- data.frame(BEFORE=x,AFTER=sub("^chr","",x),SET="",RANK=0)
	
	## classify
	suppressWarnings(y[!is.na(as.numeric(y[,2])) & !grepl("_",y[,2]),3] <- "nums")  # numeric chromosomes
	suppressWarnings(y[is.na(as.numeric(y[,2])) & !grepl("_",y[,2]),3]  <- "alps")  # alpha chromosomes
	odds <- grep("_",y[,2])                                    # randoms, or other things with underscores
	y[odds[grepl("^[0-9]",y[odds,2])],3] <- "odds.n"           # randoms associated with numerics
	y[odds[!grepl("^[0-9]",y[odds,2])],3] <- "odds.c"          # randoms NOT associated with numerics
	
	## rank
	offset <- 0
	w <- which(y[,3]=="nums")
	if (length(w)>0) y[w[order(as.numeric(y[w,2]))],4] <- 1:length(w)+offset
	offset <- offset + length(w)
	
	w <- which(y[,3]=="alps")
	if (length(w)>0) y[w[order(y[w,2])],4] <- 1:length(w)+offset
	offset <- offset + length(w)
	
	w <- which(y[,3]=="odds.n")
	if (length(w)>0) y[w[order(as.numeric(sub("_.*$","",y[w,2])), sub("^[^_]+_","",y[w,2]))],4] <- 1:length(w)+offset
	offset <- offset + length(w)
	
	w <- which(y[,3]=="odds.c")
	if (length(w)>0) y[w[order(y[w,2])],4] <- 1:length(w)+offset
	offset <- offset + length(w)
	
	y[order(y[,4]),1]
}


apa.names$hacks <- c(apa.names$hacks, "standardize")
standardize <- function(vec, na.rm=FALSE) {
    
    ## Remaps a vector into Z-score space
    ## "na.rm" same as in other functions
    
    if (na.rm) { vec <- real(vec) }
    x <- ( vec - mean(vec) ) / sd(vec)
    return(x)
}


apa.names$hacks <- c(apa.names$hacks, "zscore")
zscore <- function(x, value=NULL, na.rm=FALSE) {
    
    ## Converts a vector or matrix to z-scores.
    ## If 'value' is specified, returns the z-score for 'value', given 'x' as the distribution.
    ## "na.rm" as usual, only applies if 'value' used.

    if (length(value)>0) {
        ## unusual case -- using distrib 'x' to give a z-score to point 'value'
        ( value - mean(x,na.rm=na.rm) ) / sd(x,na.rm=na.rm)
    } else {
        ## usual case -- convert object 'x' to z-scores
        ## if matrix, converts along ROWS NOT COLUMNS
        if (is.list(x)) {
            stop("'x' must be a numeric matrix or vector!\n")
        } else if (is.matrix(x)) {
            t(scale(t(x)))
        } else {
            scale(x)
        }
    }
}


apa.names$hacks <- c(apa.names$hacks, "get.MA")
get.MA <- function(x, y=NULL, pseudo=0) {
    
    ## Converts two vectors (or 2-col matrix/df) to MA values
    ## 'pseudo' is an optional pseudocount to adjust values with prior to MA calculations
    
    if (ncol(x)==2) {
        if (length(y)>0) stop("Do not specify 'y' if 'x' has 2 columns.")
    } else if (length(y)>0) {
        if (length(x)==length(y)) {
            x <- cbind(x,y)
        } else {
            stop("'x' and 'y' are not the same length!")
        }
    }
    x <- x+pseudo
    data.frame(A=log2(sqrt(x[,1]*x[,2])),M=log2(x[,1]/x[,2]))
}


apa.names$hacks <- c(apa.names$hacks, "absmax")
absmax <- function(x, signed=FALSE, na.rm=FALSE) {
    
    r <- range(x, na.rm=na.rm)
    if (signed) {
        ifelse(abs(r[1])>abs(r[2]), r[1], r[2])
    } else {
        max(abs(r))
    }
}


apa.names$hacks <- c(apa.names$hacks, "absmin")
absmin <- function(x, signed=FALSE, na.rm=FALSE) {
    
    r <- range(x, na.rm=na.rm)
    if (signed) {
        ifelse(abs(r[1])<abs(r[2]), r[1], r[2])
    } else {
        min(abs(r))
    }
}


apa.names$hacks <- c(apa.names$hacks, "signlog")
signlog <- function(x, adjust=0, logfun=log2) {
    
    ## Converts absolute values into log
    ## Then signs the log values based on the originals
    
    #base <- as.numeric(sub("log","",deparse(substitute(logfun))))
    if (adjust<0) stop("Cannot adjust raw values with a negative number!")
    if (adjust>0 & adjust<1) stop("Cannot adjust raw values with a number smaller than 1!")
    y <- logfun(abs(x)+adjust)
    y[x<0] <- -y[x<0]
    y
}


apa.names$general <- c(apa.names$general, "percentify")
percentify <- function(vec, range=FALSE, na.rm=FALSE) {
    
    ## Converts a vector to a percent.
    ##  - "range=FALSE": values as percent of sum; intuitive treatment.
    ##  - "range=TRUE":  values as percent of range; basically, subtracts minimum value and divides by the remaining maximum.
    ## 'range' may also be c(min,max), indicating some other range.  If specified, converts vec to percent based on this range.
    ## "na.rm" same as in other functions.
    
    if (length(range)==1) {
        if (!is.logical(range)) {
            warning("'range' must be T/F or a length-2 numeric vector!")
            return()
        } else if (range) {
            if (length(vec)>1) {
                vec <- vec - min(vec, na.rm=na.rm)
                vec <- vec / max(vec, na.rm=na.rm)
            } else {
                vec <- 1
            }
        } else {
            if (length(vec)>1) {
                vec <- vec / sum(vec, na.rm=na.rm)
            } else {
                vec <- 1
            }
        }
    } else if (length(range)==2) {
        vec <- vec - range[1]
        vec <- vec / (range[2]-range[1])
    } else {
        warning("'range' cannot have length 0!")
        return()
    }
    return(vec)
}


apa.names$general <- c(apa.names$general, "row.norm")
row.norm <- function(mat, med=FALSE, divSD=FALSE, na.rm=FALSE) {
    
    ## Subtracts each row in a matrix by its row mean.
    ##  unless 'med=T', in which median is used, not mean.
    ## "na.rm" same as in other functions.
    ## "divSD=T" further divides rows by SD, converting to z-scores
    
    if (med) {
        x <- x - rowMedians(x, na.rm=na.rm)
    } else {
        x <- x - rowMeans(x, na.rm=na.rm)
    }
    if (divSD) x <- x / rowSDs(x, na.rm=na.rm)
    x
}


apa.names$general <- c(apa.names$general, "sdpop")
sdpop <- function(x, na.rm=FALSE) {
    
    ## population sd (i.e. divisor is N not N-1)
    
    sqrt( sum((mean(x)-x)^2)/length(x) )
}


apa.names$general <- c(apa.names$general, "CV")
CV <- function(x, na.rm=FALSE) {
    
    ## Returns the coefficient of variation (CV) for a vector.
    ## na.rm same as in other functions.
    
    if (na.rm) x <- x[!is.na(x)]
    sd(x) / abs(mean(x))
}


apa.names$general <- c(apa.names$general, "CVpop")
CVpop <- function(x, na.rm=FALSE) {
    
    ## Returns the population coefficient of variation (CV) for a vector.
    ## Uses sdpop() not sd().
    ## na.rm same as in other functions.
    
    if (na.rm) x <- x[!is.na(x)]
    sdpop(x) / abs(mean(x))
}


apa.names$general <- c(apa.names$general, "MAD")
MAD <- function(x, na.rm=FALSE) {
    
    ## Mean Absolute Deviation
    ## alternative to Standard Deviation
    
    if (na.rm) x <- x[!is.na(x)]
    sum(abs(x-mean(x))) / length(x)
}


apa.names$general <- c(apa.names$general, "SEM")
SEM <- function(x, na.rm=FALSE) {
    
    ## Returns the Standard Error of the Mean for a vector.
    ## na.rm same as in other functions.
    
    if (na.rm) x <- x[!is.na(x)]
    sd(x) / sqrt(length(x))
}


apa.names$general <- c(apa.names$general, "SEM")
SEMpop <- function(x, na.rm=FALSE) {
    
    ## Returns the population Standard Error of the Mean for a vector.
    ## uses sdpop() not sd().
    ## na.rm same as in other functions.
    
    if (na.rm) x <- x[!is.na(x)]
    sdpop(x) / sqrt(length(x))
}


apa.names$general <- c(apa.names$general, "dimStats")
dimStats <- function(obj, dim.num, func, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    
    ## Generic row/column summarizer; backend for { row col } + { Sums Means Medians SDs CVs }
    ##  -- or anything else you want to plug into it; df- and array-compatible too
    ## "nonzero.only=T" supercedes "na.rm" in that it removes NA/NaNs AND zeroes. 
    ## "real=T" also supercedes "na.rm" in that it removes NA/NaNs AND +/-Inf.
    
    if (is.data.frame(obj)) obj <- as.matrix(obj)
    if (nonzero.only) { 
        obj[obj==0] <- NA 
        na.rm <- TRUE
    }
    if (real.only) { 
        obj[is.infinite(obj)] <- NA 
        na.rm <- TRUE
    }

    if (is.array(obj) || is.matrix(obj)) {
        apply(obj, dim.num, func, na.rm=na.rm)  # used to be wrapped in as.vector?
    } else {   # obj = single row/col = vector?
        sapply(obj, func, na.rm=na.rm)
    }
}


apa.names$general <- c(apa.names$general, "deciles")
deciles <- function(x, na.rm=FALSE) {
    quantile(x,seq(0,1,0.1),na.rm=na.rm)
}


apa.names$general <- c(apa.names$general, "percentiles")
percentiles <- function(x, na.rm=FALSE) {
    quantile(x,seq(0,1,0.01),na.rm=na.rm)
}


apa.names$general <- c(apa.names$general, "permilles")
permilles <- function(x, na.rm=FALSE) {
    quantile(x,seq(0,1,0.001),na.rm=na.rm)
}


apa.names$hacks <- c(apa.names$hacks, "quot")
quot <- function(x, na.rm=FALSE) { 
    Reduce("/", x)   # base has prod() for products, but nothing for quotients...
}


apa.names$hacks <- c(apa.names$hacks, "rowSums")
rowSums <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 1, base::sum, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "colSums")
colSums <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 2, base::sum, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "rowMeans")
rowMeans <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 1, base::mean, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "colMeans")
colMeans <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 2, base::mean, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "rowMedians")
rowMedians <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 1, stats::median, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "colMedians")
colMedians <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 2, stats::median, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "rowSDs")
rowSDs <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE, population=FALSE) {
    func <- if (population) { sdpop } else { sd }
    dimStats(obj, 1, func, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "colSDs")
colSDs <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE, population=FALSE) {
    func <- if (population) { sdpop } else { sd }
    dimStats(obj, 2, func, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "rowCVs")
rowCVs <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE, population=FALSE) { 
    func <- if (population) { CVpop } else { CV }
    dimStats(obj, 1, func, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "colCVs")
colCVs <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE, population=FALSE) { 
    func <- if (population) { CVpop } else { CV }
    dimStats(obj, 2, func, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "rowMax")
rowMax <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 1, base::max, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "colMax")
colMax <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 2, base::max, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "rowMin")
rowMin <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 1, base::min, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "colMin")
colMin <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 2, base::min, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "absMin")
absMin <- function(x, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) {
       if (real.only) x <- real(x)
       if (nonzero.only) x <- x[truthify(x>0)]
       min(abs(x),na.rm=na.rm)
}


apa.names$hacks <- c(apa.names$hacks, "absMax")
absMax <- function(x, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) {
       if (real.only) x <- real(x)
       if (nonzero.only) x <- x[truthify(x>0)]
       max(abs(x),na.rm=na.rm)
}


apa.names$general <- c(apa.names$general, "midpoints")
midpoints <- function(vec) { 
	
	# treats 'vec' as a vector of breakpoints, and returns the midpoints
	
	N <- length(vec)
	apply(cbind(vec[1:(N-1)],vec[2:N]), 1, mean)
}


apa.names$general <- c(apa.names$general, "colrep")
colrep <- function(col, n) { 
	
	## Just like rep(), but using columns.  Returns a matrix.
	
	mat <- matrix(nrow=length(col), ncol=n)
	if (!is.null(names(col))) rownames(mat) <- names(col)
	for (i in 1:n) mat[,i] <- col
	return(mat)
}


apa.names$general <- c(apa.names$general, "rowrep")
rowrep <- function(row, n) { 
	
	## Just like rep(), but using rows.  Returns a matrix or dataframe.
	
	if (is.nlv(row)) {
		mat <- matrix(nrow=n, ncol=length(row))
		if (!is.null(names(row))) colnames(mat) <- names(row)
		for (i in 1:n) mat[i,] <- row
		mat
	} else if (is.data.frame(row)) {
		do.call(rbind,new.list(1:n, elem=row))
	} else {
		stop("row is not a non-list vector or data.frame: cannot reshape!\n")
	}
}


apa.names$hacks <- c(apa.names$hacks, "rbind2")
rbind2 <- function(...) { 
    
    ## rbind() without the colnames matching
    
    ldot <- list(...)
    cnames <- colnames(ldot[[1]])
    x <- do.call(rbind, lapply(ldot, function(y){
        if (is.matrix(y) | is.data.frame(y)) {
            colnames(y)=1:ncol(y)
            y
        } else {
            names(y)=1:length(y)
            t(as.matrix(y))
        }
    }))
    colnames(x) <- cnames
    x
}


apa.names$general <- c(apa.names$general, "ragged.cbind")
ragged.cbind <- function(..., named=FALSE) { 
    
    ## cbind() for vectors of uneven length
    
    x <- list(...)
    if (length(x)==1) x <- x[[1]]
    N <- length(x)
    xnames <- names(x)
    if (length(xnames)==0) xnames <- 1:N
    y <- vector("list", length=N)
    names(y) <- xnames
    if (named) {
        all.names <- sort(unique(unlist(lapply(x,names))))
        blank <- rep(NA,length(all.names))
        names(blank) <- all.names
        for (i in 1:N) {
            y[[i]] <- blank
            y[[i]][match(names(x[[i]]),all.names)] <- x[[i]]
        }
    } else {
        longest <- max(sapply(x,length),na.rm=TRUE)
        for (i in 1:N) {
            y[[i]] <- rep(NA,longest)
            y[[i]][1:length(x[[i]])] <- x[[i]]
        }
    }
    do.call(cbind, y)
}


apa.names$hacks <- c(apa.names$hacks, "rows.same")
rows.same <- function(mat) { 
	
	## Returns T/F for all rows in 'mat' being same
	
	all(apply(mat, 2, luniq)==1)
}


apa.names$hacks <- c(apa.names$hacks, "cols.same")
cols.same <- function(mat) { 
	
	## Returns T/F for all cols in 'mat' being same
	
	all(apply(mat, 1, luniq)==1)
}


apa.names$hacks <- c(apa.names$hacks, "unlist2")
unlist2 <- function(x, delim=NA) { 
	
	## unlist() without screwing up the names -- uses original names (what a concept!)
	## unless 'delim' specified: then attaches padded numeric extensions, 'delim'-delimited
	
	L <- listLengths(x)
	NAMES <- sort(detable(L))
	U <- unlist(x)   # THIS SORTS BY NAME
	if (!is.na(delim)) {
		for (n in names(L)) {
			w <- which(NAMES==n)
			fmt <- paste(n,delim,"%0",nchar(length(w)),"i",sep="")
			NAMES[w] <- sprintf(fmt, 1:length(w))
		}
	}
	names(U) <- NAMES
	U
}


apa.names$general <- c(apa.names$general, "upper.triangle.fill")
upper.triangle.fill <- function(mat) {
	## mirrors lower-triangular matrix and optionally fills diagonal
	as.matrix(as.dist(mat))
}

apa.names$general <- c(apa.names$general, "listLengths")
listLengths <- function(lst, method=length, ...) { 
	
	## Returns a vector with the lengths of each element (must be ALL vectors or ALL matrices) in a list.  A small shortcut function.
	## Very useful inside a 'table' call.
	## "mat.len" switch only works if list elements are matrices: 
	##  mat.len="length": length = nrow*ncol.
	##  mat.len="nrow": length = nrow.
	##  mat.len="ncol": length = ncol.
	##  mat.len="sum" is used when list elements are logical vectors and only the sum of these vectors (i.e. TRUE elements) is desired; "na.rm=T" used.
	
	if (is.character(method)) method <- get(method)
	method.name <- deparse(substitute(method))
	if (length(lst)==0) {
		IM("Error: list of length 0\n")
		return(NULL)
	} else {
		v <- sapply(lst, method, ...)  # '...' may include na.rm=TRUE, e.g.
	}
    if (is.list(v)) {  # missing entries; get NULL
        for (i in 1:length(v)) if (is.null(v[[i]])) v[[i]] <- 0
        v <- unlist(v)
    }
	return(v)
}


apa.names$general <- c(apa.names$general, "access.list")
access.list <- function(lst, path) {
	
	# 'lst' is a list and 'path' is a numeric vector specifying, recursively, the list elements.
	# E.g. path=c(3,1,2) accesses lst[[3]][[1]][[2]]
	
	path2 <- paste("[[",path,"]]",sep="")
	eval(parse(text=paste(c("lst",path2),collapse="")))
}


apa.names$hacks <- c(apa.names$hacks, "intersect2")
intersect2 <- function(..., method=c("all","any")) {
	
	## N-way intersection, instead of intersect() with is strictly 2-way
	
	method <- match.arg(method)
	if (method == "all") {
		Reduce("intersect", list(...))
	} else if (method == "any") {
		x <- unlist(list(...))
		t <- table(x)
		i <- names(t)[t>1]
		mode(i) <- mode(x)
		i
	}
}


apa.names$hacks <- c(apa.names$hacks, "disjunc2")
disjunc2 <- function(...) {
	
	## N-way disjunction, i.e. returns all elements found in only one set
	
	x <- unlist(list(...))
	t <- table(x)
	d <- names(t)[t==1]
	mode(d) <- mode(x)
	d
}


apa.names$hacks <- c(apa.names$hacks, "setdiff2")
setdiff2 <- function(...) {
	
	## N-way setdiff, instead of setdiff() with is strictly 2-way
	
	x <- list(...)
	setdiff(x[[1]], unlist(x[2:length(x)]))
}


apa.names$hacks <- c(apa.names$hacks, "union2")
union2 <- function(...) {
	
	## N-way union, unstead of union() which is strictly 2-way
	
	unique(unlist(list(...)))
}


apa.names$general <- c(apa.names$general, "files.access")
files.access <- function(vec, bin=FALSE) {
	
	## Takes a vector of files and returns tabulated file.access() results for all 4 modes
	## "bin=T" converts 0 => 1 and -1 => 0
	
	mat <- matrix(data=NA, nrow=length(vec), ncol=4)
	rownames(mat) <- vec
	colnames(mat) <- c("Exist","Execute","Write","Read")
	j <- 0
	for (i in c(0,1,2,4)) { j <- j+1; mat[,j] <- file.access(vec, i) }
	if (bin == TRUE) {
		mat[mat == 0] <- 1
		mat[mat == -1] <- 0
	}
	print(return(mat))
}


apa.names$hacks <- c(apa.names$hacks, "write.vector")
write.vector <- function(x, file, sep="\t", quote=FALSE, names=FALSE, ...) {
	
	## wrapper for write.table() with defaults set for vector (not table) writing
	
	write.table(x, file=file, sep=sep, quote=quote, row.names=ternary(names, names(x), FALSE), col.names=FALSE, ...)
}


apa.names$hacks <- c(apa.names$hacks, "write.table2")
write.table2 <- function (x, file="", quote=FALSE, sep="\t", row.head=NULL, col.names=TRUE, row.names=FALSE, ...) {
    
    ## Wrapper that tabs colnames over properly if rownames are being printed,
    ##  and prints a colname for the rownames column (given by 'row.head')
    
    write.table.args <- c(list(file=file, quote=quote, sep=sep), list(...))

    if (length(row.names)==0) row.names <- rownames(x)
    if (length(col.names)==0) col.names <- colnames(x)
    
    if (identical(row.names[1],TRUE)) {
        use.row.names <- TRUE
        row.names <- rownames(x)
    } else if (identical(row.names[1],FALSE)) {
        use.row.names <- ifelse(length(row.head)>0, TRUE, FALSE)
        if (use.row.names) row.names <- rownames(x)
    } else if (length(row.names)==0) {
        use.row.names <- FALSE
    } else if (length(row.names)!=nrow(x)) {
        stop("Length of row.names is not equal to rows of 'x'!")
    } else {
        use.row.names <- TRUE
        if (length(row.names)==0) row.names <- rownames(x)
    }
    
    if (identical(col.names[1],FALSE) | length(col.names)==0) {
        use.col.names <- FALSE
    } else if (identical(col.names[1],TRUE)) {
        use.col.names <- TRUE
        col.names <- colnames(x)
    } else if (length(col.names)!=ncol(x)) {
        stop("Length of col.names is not equal to cols of 'x'!")
    } else {
        use.col.names <- TRUE
        if (length(col.names)==0) col.names <- colnames(x)
    }
    
    if (use.row.names) {
        write.table.args <- c(write.table.args, list(row.names=row.names))
        if (length(row.head)==0) row.head <- ""
    } else {
        write.table.args <- c(write.table.args, row.names=FALSE)
    }
    
    if (use.col.names) {
        if (length(row.head)>0) {
            if (quote) {
                col.names[1] <- paste("\"", row.head, "\"", sep, col.names[1], sep="")
            } else {
                col.names[1] <- paste(row.head, col.names[1], sep=sep) 
            }
        }
        write.table.args <- c(write.table.args, list(col.names=col.names))
    } else {
        write.table.args <- c(write.table.args, col.names=FALSE)
    }
    
    do.call(write.table, c(list(x=x), write.table.args))
}


apa.names$general <- c(apa.names$general, "read.bed")
read.bed <- function(x, bed6=FALSE) {
    
    ## reads BED format, and can force bed6
    
    bed <- read.delim(x, as.is=TRUE, header=FALSE)
    NC <- ncol(bed)
    if (NC==1) {
        stop("Supplied BED data has only one column!  Cannot proceed.\n")
    } else if (NC==2) {
        message("Supplied BED data has less than the minimum of 3 columns!  Assuming one-based single-bp data.\n")
        bed <- bed[,c(1,2,2)]
        bed[,2] <- bed[,2]-1
    }
    if (bed6) {
        if (NC==3) {
            bed <- cbind(bed,1:nrow(bed),1,"+")
        } else if (NC==4) {
            bed <- cbind(bed,1,"+")
        } else if (NC==5) {
            bed <- cbind(bed,"+")
        } else if (NC==6) {
            ## nothing to do
        } else if (NC>6) {
            message(paste("Supplied BED data has",NC,"columns: truncating to 6."))
            bed <- bed[,1:6]
        }
        colnames(bed) <- qw(Chrom,Start,End,Name,Score,Strand)
    }
    bed
}


apa.names$general <- c(apa.names$general, "write.bed")
write.bed <- function(x, file, score1=FALSE, bed6=FALSE, one.based=FALSE) {
	
    ## ensures that start, end positions are written as integers, not "6e+05" stuff
    ## also can auto-fill columns 5 & 6 as needed, and correct 1-based starts
    
    NC <- ncol(x)
    if (NC<3) stop("Supplied data has less than the minimum of 3 columns: cannot proceed!\n")
    if (one.based) x[,2] <- x[,2]-1
    if (score1 & NC>=5) x[,5] <- 1
    if (bed6) {
        if (NC==3) {
            x <- cbind(x,1:nrow(x),1,"+")
        } else if (NC==4) {
            x <- cbind(x,1,"+")
        } else if (NC==5) {
            x <- cbind(x,"+")
        } else if (NC==6) {
            ## nothing to do
        } else if (NC>6) {
            message(paste("Supplied data has",NC,"columns: truncating to 6"))
            x <- x[,1:6]
        }
    }
    
    y <- x
    for (i in c(2,3,5)) y[,i] <- stabilize.integer(y[,i])  # becomes character
    write.table(y, file=file, sep="\t", quote=FALSE, row.names=FALSE, col.names=FALSE)
    
    invisible(x)  # return version with numeric coords, not char
}


apa.names$general <- c(apa.names$general, "write.heatmap.bed")
write.heatmap.bed <- function(x, file, geno, window=10000, bad.win=c("drop","crop"), summits=NULL, no.mito=FALSE, debug=FALSE, one.based=FALSE) {
    
    ## Takes an input bed 'x' and modifies it to be used with coverageView()
    ## Basically, converts coords to windows of width 'window', centered at peak midpoint, and writes as new bed.
    ## x: bed data.frame
    ## file: output filename
    ## geno: /n/data1/genomes/indexes genome name
    ## window: window bp; will be centered on peak midpoint
    ## bad.win: if window start < 0, or end > chrlen, do what?  "drop"=remove region, "crop"=cut back to fit on chrom
    ## summits: optional vector of 0-BASED GENOMIC POSITIONS for peak summits, SAME ORDER AS 'x'.  Will center windows on summits, instead of peak midpoints.
    ## no.mito: exclude known mitochondrial chromosomes?
    ## debug: return intermediate data columns?  (for debugging 'bad.win' coords)
    ## one.based: input coords are 1-based?
    
    bad.win <- match.arg(bad.win)
    if (window %% 2 == 1) {
        message(paste0("Window size '",window,"' is not even!  Reducing to '",window-1,"' bp"))
        window <- window - 1
    }
    chrsz <- paste0("/n/data1/genomes/indexes/",geno,"/",geno,".chrom.sizes")
    if (file.exists(chrsz)) {
        chrsz <- read.delim(chrsz,as.is=TRUE,header=FALSE)
        ectopic <- sort(setdiff(x[,1],chrsz[,1]))
        if (length(ectopic)>0) stop(paste0("Bed data contains chromosomes which are not from '",geno,"'!  ",paste(ectopic,collapse=", "),"\n"))
        if (no.mito) {
            chrdat <- paste0("/n/data1/genomes/indexes/",geno,"/",geno,".chrom_data.txt")
            if (file.exists(chrdat)) {
                chrdat <- read.delim(chrdat,as.is=TRUE)
                mito <- chrdat[chrdat$Content=="mitochondrion",1]
                message("Excluding mitochondrial chroms: ",paste(mito,collapse=" "))
            } else {
                stop(paste0("Genome '",geno,"' has not chrom_data.txt file!  Cannot determine mitochondrial chroms."))
            }
        } else {
            mito <- c()
        }
    } else {
        stop(paste0("Genome name '",geno,"' does not exist in /n/data1/genomes/indexes!"))
    }
    if (length(x)==1) {
        if (file.exists(x)) {
            x <- read.bed(x)
        } else {
            stop(paste0("Argument x '",x,"' looks like a filename but no such file exists!"))
        }
    }
    y <- mat.split(x, x[,1])  # split on chrom
    y <- do.call(rbind, y[real(match(chrsz[,1],names(y)))])  # 'y' is now 'x', with chroms in 'chrsz' order
    if (ncol(y)<4) y <- data.frame(y,paste0("Coord",1:nrow(y)))
    if (ncol(y)<5) y <- data.frame(y,1)
    if (ncol(y)<6) y <- data.frame(y,"+")
    colnames(y) <- c("chrom","start","end","name","score","strand")
    y <- cbind(y, OK=TRUE, chrlen=chrsz[match(y[,1],chrsz[,1]),2], overshoot=0, orig.start=y[,2], orig.end=y[,3])  # extended intermediate dataset BEFORE altering coords: must retain originals
    rownames(y) <- NULL
    if (one.based) y[,2] <- y[,2]-1
    if (length(summits)==0) summits <- trunc(rowMeans(y[,2:3]))  # substitute peak midpoints
    y[,2:3] <- cbind(summits-window/2, summits+window/2)
    y$overshoot[which(y[,2]<0)] <- y[which(y[,2]<0),2]                               ## It is expected that a single coord will either
    y$overshoot[which(y[,3]>y$chrlen)] <- c(y[,3]-y$chrlen)[which(y[,3]>y$chrlen)]   ##   have start<0 OR end>chrlen, but not both.
    y$OK <- y$overshoot==0
    is.mito <- y[,1] %in% mito
    y$OK[is.mito] <- FALSE
    msg <- paste(sum(y$OK),"ok,",sum(!y$OK),"not")
    
    if (any(!y$OK)) {
        worst.n <- min(y$overshoot)
        worst.p <- max(y$overshoot)
        worst.n.msg <- ifelse( worst.n==0, "", paste0(" (worst=",worst.n," under)") )
        worst.p.msg <- ifelse( worst.p==0, "", paste0(" (worst=",worst.p," over)") )
        mito.msg <- ifelse( no.mito & any(is.mito), paste0(", ",sum(is.mito)," mitochondrial"), "" )
        msg <- paste0(msg,": ",sum(y[,2]<0)," < 0",worst.n.msg,", ",sum(y[,3]>y$chrlen)," > max",worst.p.msg,mito.msg)
        message(msg)
        if (bad.win=="drop") {
            write.bed(y[y$OK,1:6], file)
        } else if (bad.win=="crop") {
            y2 <- y[,1:6]
            y2[y[,2]<0,2] <- 0
            y2[y[,3]>y$chrlen,3] <- y$chrlen[y[,3]>y$chrlen]
            write.bed(y2, file)
        }
    } else {
        message(msg)
        write.bed(y[,1:6], file)
    }
    if (debug) {
        invisible(y)
    } else {
        invisible(y[,1:7])  # only retaining extra "OK" column
    }
}


apa.names$general <- c(apa.names$general, "sort.bed")
sort.bed <- function(x, method=c("lexicographic","UCSC","Ensembl")) {

    method <- match.arg(method)
    if (method=="lexicographic") {
        to.ord <- list(x[,1], x[,2], x[,3])
    } else if (method=="UCSC") {
        A <- grep("^chr[0-9]",x[,1])   # numeric chrs
        As <- A[grep("_",x[A,1])]      # numeric chrs, with suffixes
        A <- setdiff(A,As)
        B <- grep("^chr[^0-9U]",x[,1]) # character chrs, not "Un"
        Bs <- B[grep("_",x[B,1])]      # character chrs, not "Un", with suffixes
        B <- setdiff(B,Bs)
        C <- grep("^chrU",x[,1])       # chrU[n]-type "chrs"
        D <- grep("^chr",x[,1],invert=TRUE) # non-chrs
        ABAsAs2BsCD <- rep(c("A","As","B","Bs","C","D"),times=c(length(A),length(B),length(As),length(Bs),length(C),length(D)))
        chrA <- chrB <- chrC <- chrD <- chrAs <- chrAs2 <- chrBs <- rep(NA,nrow(x))
        chrA[A] <- as.numeric(sub("^chr","",x[A,1]))
        chrB[B] <- x[B,1]
        chrC[C] <- x[C,1]
        chrD[D] <- x[D,1]
        chrAs[As] <- as.numeric(sub("_.*$","",sub("^chr","",x[As,1])))  # numeric portion
        chrAs2[As] <- sub("^chr[0-9]+","",x[As,1])  # non-numeric suffixes
        chrBs[Bs] <- x[Bs,1]
        to.ord <- list(ABAsAs2BsCD, chrA, chrB, chrAs, chrAs2, chrBs, chrC, chrD, x[,2], x[,3])
    } else if (method=="Ensembl") {
        A <- grep("^[0-9]+$",x[,1])           # all-numeric chr names
        B <- grep("[0-9]",x[,1],invert=TRUE)  # all-character chr names
        C <- setdiff(1:nrow(x), c(A,B))       # mixed chr names
        ABC <- rep(c("A","B","C"),times=c(length(A),length(B),length(C)))
        chrA <- chrB <- chrC <- rep(NA,nrow(x))
        chrA[A] <- as.numeric(x[A,1])
        chrB[B] <- x[B,1]
        chrC[B] <- x[C,1]
        to.ord <- list(ABC, chrA, chrB, chrC, x[,2], x[,3])
    }
    if (ncol(x)>=6) to.ord <- c(to.ord, list(x[,6]))
    to.ord <- c(to.ord, na.last=TRUE, decreasing=FALSE)
    x[do.call(order,to.ord),]
}


apa.names$general <- c(apa.names$general, "read.xlsx.simple")
read.xlsx.simple <- function (file, header=TRUE, silent=TRUE) {
    
    require("XLConnect")
    conn <- loadWorkbook(file)
    xlsx <- new.list(getSheets(conn))
    for (i in 1:length(xlsx)) {
        x <- try(readWorksheet(conn, i, startCol=1, header=header), silent=silent)
        if (grepl("^Error : IllegalArgumentException (Java):",x[1]) | grepl("does not contain any data!\n$",x[1])) { 
                                        # blank sheet -- ignore
        } else {
            xlsx[[i]] <- x
        }
    }
    xlsx
}


apa.names$hacks <- c(apa.names$hacks, "WriteXLS2")
WriteXLS2 <- function (x, ExcelFileName = "R.xls", SheetNames = NULL, perl = "perl", 
                       verbose = FALSE, Encoding = c("UTF-8", "latin1"), row.names = FALSE, 
                       AdjWidth = FALSE, AutoFilter = FALSE, BoldHeaderRow = FALSE, 
                       FreezeRow = 0, FreezeCol = 0, envir = parent.frame(), nolim=FALSE,
                       CopyFormat = FALSE) {   # last arg is hacked in
    
    ## WriteXLS (requires package of same name be loaded)
    ## hacked to take a list of *actual dataframes*, not a (pathetic) length-1 list of dataframe NAMES
    ## also added: 'nolim' which prevents old-excel row/col number checks (i.e. allows writes of tables exceeding 65535 x 256)
    ## also added ability to write as xlsx
    
    ## ## BEGIN HACK 1
    require("WriteXLS")
    ExcelFileTmp <- paste0(tempdir(),"/out.xls")
    if (is.data.frame(x) | is.matrix(x)) {
        DF.LIST <- list(x)
        names(DF.LIST) <- deparse(substitute(x))
    } else if (is.list(x)) {
        DF.LIST <- x
        if (is.null(names(DF.LIST))) { names(DF.LIST) <- paste("Sheet",1:length(x),sep="") }
        ## ## END HACK 1
    } else if (length(x) == 1) {
        TMP <- get(as.character(x), envir = envir)
        if ((is.list(TMP)) & (!is.data.frame(TMP))) {
            DF.LIST <- TMP
        } else {
            DF.LIST <- list(TMP)
            names(DF.LIST) <- x
        }
    } else {
        DF.LIST <- sapply(as.character(x), function(x) get(x, envir = envir), simplify = FALSE)
        names(DF.LIST) <- x
    }
#    if (!all(sapply(DF.LIST, is.data.frame))) { stop("One or more of the objects named in 'x' is not a data frame or does not exist") }
    if (!nolim) {
        if (!falsify(all(sapply(DF.LIST, function(x) (nrow(x) <= 65535) & (ncol(x) <= 256))))) { stop("One or more of the data frames named in 'x' exceeds 65535 rows or 256 columns") }
    }
    Encoding <- match.arg(Encoding)
    if (!is.null(SheetNames)) {
        if (any(duplicated(SheetNames))) {
            message("At least one entry in 'SheetNames' is duplicated. Excel worksheets must have unique names.")
            return(invisible(FALSE))
        }
        if (length(DF.LIST) != length(SheetNames)) {
            message("The number of 'SheetNames' specified does not equal the number of data frames in 'x'")
            return(invisible(FALSE))
        }
        if (any(nchar(SheetNames) > 31)) {
            message("At least one of 'SheetNames' is > 31 characters, which is the Excel limit")
            return(invisible(FALSE))
        }
        if (any(grep("\\[|\\]|\\*|\\?|:|/|\\\\", SheetNames))) {
            message("Invalid characters found in at least one entry in 'SheetNames'. Invalid characters are: []:*?/\\")
            return(invisible(FALSE))
        }
        names(DF.LIST) <- SheetNames
    } else {
        if (any(duplicated(substr(names(DF.LIST), 1, 31)))) {
            message("At least one data frame name in 'x' is duplicated up to the first 31 characters. Excel worksheets must have unique names.")
            return(invisible(FALSE))
        }
        if (any(grep("\\[|\\]|\\*|\\?|:|/|\\\\", names(DF.LIST)))) {
            message("Invalid characters found in at least one data frame name in 'x'. Invalid characters are: []:*?/\\")
            return(invisible(FALSE))
        }
    }
    Perl.Path <- file.path(path.package("WriteXLS"), "Perl")
    Fn.Path <- file.path(Perl.Path, "WriteXLS.pl")
    Tmp.Dir <- file.path(tempdir(), "WriteXLS")
    clean.up <- function() {
        if (verbose) { cat("Cleaning Up Temporary Files and Directory\n\n") }
        unlink(Tmp.Dir, recursive = TRUE)
    }
    on.exit(clean.up())
    if (file.exists(Tmp.Dir)) {
        if (verbose) { cat("Cleaning Up Temporary Files and Directory From Prior Run\n\n") }
        unlink(Tmp.Dir, recursive = TRUE)
    }
    if (verbose) { cat("Creating Temporary Directory for CSV Files: ", Tmp.Dir, "\n\n") }
    dir.create(Tmp.Dir, recursive = TRUE)
    for (i in seq(along = DF.LIST)) {
        if (verbose) { cat("Creating CSV File: ", i, ".csv", "\n", sep = "") }
        if (row.names) {
            write.table(DF.LIST[[i]], file = paste(Tmp.Dir, "/", 
                                          i, ".csv", sep = ""), sep = ",", quote = TRUE, 
                        na = "", row.names = TRUE, col.names = NA)
        } else {
            write.table(DF.LIST[[i]], file = paste(Tmp.Dir, "/", 
                                          i, ".csv", sep = ""), sep = ",", quote = TRUE, 
                        na = "", row.names = FALSE)
        }
    }
    x <- paste(Tmp.Dir, "/", seq(length(DF.LIST)), ".csv", sep = "")
    write(as.matrix(x), file = paste(Tmp.Dir, "/FileNames.txt", sep = ""))
    if (verbose) { cat("Creating SheetNames.txt\n") }
    namesfile <- paste(Tmp.Dir, "/SheetNames.txt", sep = "")   ##### HACK: trackable sheet names file
    write(as.matrix(names(DF.LIST)), file = namesfile)
    if (verbose) { cat("\n") }
    message("Writing...")
    ## ## BEGIN HACK 2
    if (verbose) print(listLengths(DF.LIST))
    if (verbose) print(x)
    if (verbose) print(namesfile)
    if ( any(listLengths(DF.LIST,nrow)>=65534) | any(listLengths(DF.LIST,ncol)>=255) ) {
        already.xlsx <- TRUE
        ExcelFileTmp <- paste0(ExcelFileTmp,"x")  # ExcelFileTmp is .xlsx this time
        cmd <- paste("/home/apa/local/bin/txt2xlsx",shQuote(ExcelFileTmp),paste(x,collapse=" "),"--csv -n",namesfile)
        if (FreezeRow>0|FreezeCol>0) {
            freeze <- c(0,0)
            if (FreezeRow>0) freeze[1] <- FreezeRow
            if (FreezeCol>0) freeze[2] <- FreezeCol
            freeze <- paste(freeze,collapse=",")
            cmd <- paste(cmd,"-f",freeze)
        }
        if (AdjWidth) cmd <- paste(cmd,"--adjust")
        if (BoldHeaderRow) cmd <- paste(cmd,"--bold-header")
        if (AutoFilter) message("WARNING: AutoFilter is TRUE, but sheets too large to use default WriteXLS methods: ignoring AutoFilter")
        if (Encoding!="UTF-8") message("WARNING: Encoding is not UTF-8, but sheets too large to use default WriteXLS methods: Encoding will become UTF-8")
    } else {
        already.xlsx <- FALSE
        ## this was the original function
        cmd <- paste(perl, " -I", shQuote(Perl.Path), " ", shQuote(Fn.Path), 
                     " --CSVPath ", shQuote(Tmp.Dir), " --verbose ", verbose, 
                     " --AdjWidth ", AdjWidth, " --AutoFilter ", AutoFilter, 
                     " --BoldHeaderRow ", BoldHeaderRow, " --FreezeRow ", 
                     FreezeRow, " --FreezeCol ", FreezeCol, " --Encoding ", 
                     Encoding, " ", shQuote(ExcelFileTmp), sep = "")  ##### HACK: exchanged ExcelFileName for ExcelFileTmp
    }
    ## ## END HACK 2
    if (verbose) print(cmd)
    Result <- system(cmd)
    if (Result != 0) {
        if (already.xlsx) {
            message("The Perl script 'txt2xlsx' failed to run successfully.")
        } else {
            message("The Perl script 'WriteXLS.pl' failed to run successfully.")
        }
        return(invisible(FALSE))
    } else {
        ## ## BEGIN HACK 3
        if (grepl("\\.xlsx",ExcelFileName)) {
            if (already.xlsx) {
                system(paste("mv -f",ExcelFileTmp,ExcelFileName))
            } else {
                xlsx.cmd <- paste("/home/apa/local/bin/xls2xlsx -i",ExcelFileTmp)
                freeze <- c( ifelse(FreezeRow>0,FreezeRow,''), ifelse(FreezeCol>0,FreezeCol,'') )
                if (FreezeRow>0||FreezeCol>0) xlsx.cmd <- paste0(xlsx.cmd," -f ",freeze[1],",",freeze[2])
                if (!CopyFormat) xlsx.cmd <- paste(xlsx.cmd,"--no-cell-formatting")
                Result2 <- system(xlsx.cmd)
                if (Result2 != 0) {
                    message("The Perl script 'xls2xlsx' failed to run successfully.")
                    return(invisible(FALSE))
                } else {
                    system(paste0("mv -f ",ExcelFileTmp,"x ",ExcelFileName))
                }
            }
        } else {
            system(paste("mv -f",ExcelFileTmp,ExcelFileName))
        }
        system(paste0("chmod a+x ",ExcelFileName))  # in keeping with our FS defaults
        ## ## END HACK 3
        return(invisible(TRUE))
    }
}


apa.names$hacks <- c(apa.names$hacks, "t.test2")
t.test2 <- function (x, y = NULL, alternative = c("two.sided", "less", "greater"), mu = 0, paired = FALSE, var.equal = FALSE, conf.level = 0.95, ...) {
    
    ## Removes the idiotic failure requirement if the data are invariant.  There is no law against t-testing invariant data.
    
    alternative <- match.arg(alternative)
    if (!missing(mu) && (length(mu) != 1 || is.na(mu))) 
        stop("'mu' must be a single number")
    if (!missing(conf.level) && (length(conf.level) != 1 || !is.finite(conf.level) || 
                                     conf.level < 0 || conf.level > 1)) 
        stop("'conf.level' must be a single number between 0 and 1")
    if (!is.null(y)) {
        dname <- paste(deparse(substitute(x)), "and", deparse(substitute(y)))
        if (paired) 
            xok <- yok <- complete.cases(x, y)
        else {
            yok <- !is.na(y)
            xok <- !is.na(x)
        }
        y <- y[yok]
    }
    else {
        dname <- deparse(substitute(x))
        if (paired) 
            stop("'y' is missing for paired test")
        xok <- !is.na(x)
        yok <- NULL
    }
    x <- x[xok]
    if (paired) {
        x <- x - y
        y <- NULL
    }
    nx <- length(x)
    mx <- mean(x)
    vx <- var(x)
    estimate <- mx
    if (is.null(y)) {
        if (nx < 2) 
            stop("not enough 'x' observations")
        df <- nx - 1
        stderr <- sqrt(vx/nx)
        if (stderr < 10 * .Machine$double.eps * abs(mx)) 
            warning("data are essentially constant")
        tstat <- (mx - mu)/stderr
        method <- ifelse(paired, "Paired t-test", "One Sample t-test")
        names(estimate) <- ifelse(paired, "mean of the differences", 
                                  "mean of x")
    }
    else {
        ny <- length(y)
        if (nx < 1 || (!var.equal && nx < 2)) 
            stop("not enough 'x' observations")
        if (ny < 1 || (!var.equal && ny < 2)) 
            stop("not enough 'y' observations")
        if (var.equal && nx + ny < 3) 
            stop("not enough observations")
        my <- mean(y)
        vy <- var(y)
        method <- paste(if (!var.equal) 
                            "Welch", "Two Sample t-test")
        estimate <- c(mx, my)
        names(estimate) <- c("mean of x", "mean of y")
        if (var.equal) {
            df <- nx + ny - 2
            v <- 0
            if (nx > 1) 
                v <- v + (nx - 1) * vx
            if (ny > 1) 
                v <- v + (ny - 1) * vy
            v <- v/df
            stderr <- sqrt(v * (1/nx + 1/ny))
        }
        else {
            stderrx <- sqrt(vx/nx)
            stderry <- sqrt(vy/ny)
            stderr <- sqrt(stderrx^2 + stderry^2)
            df <- stderr^4/(stderrx^4/(nx - 1) + stderry^4/(ny - 
                                                                1))
        }
        if (stderr < 10 * .Machine$double.eps * max(abs(mx), 
                                                    abs(my))) 
            warning("data are essentially constant")
        tstat <- (mx - my - mu)/stderr
    }
    if (alternative == "less") {
        pval <- pt(tstat, df)
        cint <- c(-Inf, tstat + qt(conf.level, df))
    }
    else if (alternative == "greater") {
        pval <- pt(tstat, df, lower.tail = FALSE)
        cint <- c(tstat - qt(conf.level, df), Inf)
    }
    else {
        pval <- 2 * pt(-abs(tstat), df)
        alpha <- 1 - conf.level
        cint <- qt(1 - alpha/2, df)
        cint <- tstat + c(-cint, cint)
    }
    cint <- mu + cint * stderr
    names(tstat) <- "t"
    names(df) <- "df"
    names(mu) <- if (paired || !is.null(y)) 
                     "difference in means"
                 else "mean"
    attr(cint, "conf.level") <- conf.level
    rval <- list(statistic = tstat, parameter = df, p.value = pval, 
                 conf.int = cint, estimate = estimate, null.value = mu, 
                 alternative = alternative, method = method, data.name = dname)
    class(rval) <- "htest"
    return(rval)
}


apa.names$hacks <- c(apa.names$hacks, "parse_args2")
parse_args2 <- function (object, args = commandArgs(trailingOnly = TRUE), print_help_and_exit = TRUE, positional_arguments = FALSE) {
	
	## Hacked parse_args() from optparse, which uses the hack getopt2()
	
	require(optparse)
    n_options <- length(object@options)
    spec <- matrix(NA, nrow = n_options, ncol = 5)
    for (ii in seq(along = object@options)) {
        spec[ii, ] <- optparse:::.convert_to_getopt(object@options[[ii]])
    }
    if (positional_arguments) {
        os_and_n_arg <- optparse:::.get_option_strings_and_n_arguments(object)
        original_arguments <- args
        args <- NULL
        arguments_positional <- character(0)
        is_taken <- FALSE
        for (argument in original_arguments) {
            if (is_taken) {
                args <- c(args, argument)
                is_taken <- FALSE
            } else {
                if (optparse:::.is_option_string(argument, object)) {
                  args <- c(args, argument)
                  if (optparse:::.requires_argument(argument, object)) is_taken <- TRUE
                } else {
                  arguments_positional <- c(arguments_positional, argument)
                }
            }
        }
    }
    options_list <- list()
    if (length(args)) {
        opt <- getopt2(spec = spec, opt = args)
    } else {
        opt <- list()
    }
    for (ii in seq(along = object@options)) {
        option <- object@options[[ii]]
        option_value <- opt[[sub("^--", "", option@long_flag)]]
        if (!is.null(option_value)) {
            if (option@action == "store_false") {
                options_list[[option@dest]] <- FALSE
            } else {
                options_list[[option@dest]] <- option_value
            }
        } else {
            if (!is.null(option@default) & is.null(options_list[[option@dest]]))  options_list[[option@dest]] <- option@default
        }
    }
    if (options_list[["help"]] & print_help_and_exit) {
        print_help(object)
        quit(status = 1)
    }
    if (positional_arguments) {
        return(list(options = options_list, args = arguments_positional))
    } else {
        return(options_list)
    }
}


apa.names$hacks <- c(apa.names$hacks, "getopt2")
getopt2 <- function (spec = NULL, opt = commandArgs(TRUE), command = get_Rscript_filename(), usage = FALSE, debug = FALSE) {
	
	## Hacked version of getopt's getopt(), which actually works.
	## I.e. does not think that unambiguous short flags are ambiguous.
	
    if (exists("argv", where = .GlobalEnv, inherits = FALSE)) opt = get("argv", envir = .GlobalEnv)
    ncol = 4
    maxcol = 6
    col.long.name = 1
    col.short.name = 2
    col.has.argument = 3
    col.mode = 4
    col.description = 5
    flag.no.argument = 0
    flag.required.argument = 1
    flag.optional.argument = 2
    result = list()
    result$ARGS = vector(mode = "character")
    if (is.null(spec)) {
        stop("argument \"spec\" must be non-null.")
    } else if (!is.matrix(spec)) {
        if (length(spec)/4 == as.integer(length(spec)/4)) {
            warning("argument \"spec\" was coerced to a 4-column (row-major) matrix.  use a matrix to prevent the coercion")
            spec = matrix(spec, ncol = ncol, byrow = TRUE)
        } else {
            stop("argument \"spec\" must be a matrix, or a character vector with length divisible by 4, rtfm.")
        }
    } else if (dim(spec)[2] < ncol) {
        stop(paste("\"spec\" should have at least \",ncol,\" columns.", sep = ""))
    } else if (dim(spec)[2] > maxcol) {
        stop(paste("\"spec\" should have no more than \",maxcol,\" columns.", sep = ""))
    } else if (dim(spec)[2] != ncol) {
        ncol = dim(spec)[2]
    }
    if (length(unique(spec[, col.long.name])) != length(spec[, col.long.name])) {
        stop(paste("redundant long names for flags (column ", col.long.name, ").", sep = ""))
    }
    if (length(na.omit(unique(spec[, col.short.name]))) != length(na.omit(spec[, col.short.name]))) {
        stop(paste("redundant short names for flags (column ", col.short.name, ").", sep = ""))
    }
    if (usage) {
        ret = ""
        ret = paste(ret, "Usage: ", command, sep = "")
        for (j in 1:(dim(spec))[1]) {
            ret = paste(ret, " [-[-", spec[j, col.long.name], "|", spec[j, col.short.name], "]", sep = "")
            if (spec[j, col.has.argument] == flag.no.argument) {
                ret = paste(ret, "]", sep = "")
            } else if (spec[j, col.has.argument] == flag.required.argument) {
                ret = paste(ret, " <", spec[j, col.mode], ">]", sep = "")
            } else if (spec[j, col.has.argument] == flag.optional.argument) {
                ret = paste(ret, " [<", spec[j, col.mode], ">]]", sep = "")
            }
        }
        if (ncol >= 5) {
            max.long = max(apply(cbind(spec[, col.long.name]), 1, function(x) length(strsplit(x, "")[[1]])))
            ret = paste(ret, "\n", sep = "")
            for (j in 1:(dim(spec))[1]) {
                ret = paste(ret, sprintf(paste("    -%s|--%-", 
                  max.long, "s    %s\n", sep = ""), spec[j, col.short.name], spec[j, col.long.name], spec[j, col.description]),  sep = "")
            }
        } else {
            ret = paste(ret, "\n", sep = "")
        }
        return(ret)
    }
    i = 1
    while (i <= length(opt)) {
        if (debug) print(paste("processing", opt[i]))
        current.flag = 0
        optstring = opt[i]
        if (substr(optstring, 1, 2) == "--") {
            if (debug) print(paste("  long option:", opt[i]))
            optstring = substring(optstring, 3)
            this.flag = NA
            this.argument = NA
            kv = strsplit(optstring, "=")[[1]]
            if (!is.na(kv[2])) {
                this.flag = kv[1]
                this.argument = paste(kv[-1], collapse = "=")
            } else {
                this.flag = optstring
            }
            rowmatch = grep(this.flag, spec[, col.long.name], fixed = TRUE)
            if (length(rowmatch) == 0) {
                stop(paste("long flag \"", this.flag, "\" is invalid", sep = ""))
            } else if (length(rowmatch) > 1) {
                rowmatch = which(this.flag == spec[, col.long.name])
                if (length(rowmatch) == 0) stop(paste("long flag \"", this.flag, "\" is ambiguous", sep = ""))
            }
            if (!is.na(this.argument)) {
                if (spec[rowmatch, col.has.argument] == flag.no.argument) {
                  stop(paste("long flag \"", this.flag, "\" accepts no arguments", sep = ""))
                } else {
                  storage.mode(this.argument) = spec[rowmatch, col.mode]
                  result[spec[rowmatch, col.long.name]] = this.argument
                  i = i + 1
                  next
                }
            } else {
                result[spec[rowmatch, col.long.name]] = TRUE
                current.flag = rowmatch
            }
        } else if (substr(optstring, 1, 1) == "-") {
            if (debug) print(paste("  short option:", opt[i]))
            these.flags = strsplit(optstring, "")[[1]]
            done = FALSE
            for (j in 2:length(these.flags)) {
                this.flag = these.flags[j]
##                rowmatch = grep(paste("^",this.flag,sep=""), spec[, col.short.name], fixed = TRUE)
#                rowmatch = which(spec[, col.short.name] == this.flag)
                rowmatch = grep(paste("^",this.flag,sep=""), spec[, col.short.name], fixed = FALSE)
                if (length(rowmatch) == 0) {
                  stop(paste("short flag \"", this.flag, "\" is invalid", sep = ""))
                } else if (length(rowmatch) > 1) {
                 stop(paste("short flag \"", this.flag, "\" is ambiguous:", sep = ""))
                } else if (j < length(these.flags) & spec[rowmatch, 
                  col.has.argument] == flag.required.argument) {
                  stop(paste("short flag \"", this.flag, "\" requires an argument, but has none", sep = ""))
                } else if (spec[rowmatch, col.has.argument] == flag.no.argument) {
                  result[spec[rowmatch, col.long.name]] = TRUE
                  done = TRUE
                } else {
                  result[spec[rowmatch, col.long.name]] = TRUE
                  current.flag = rowmatch
                  done = FALSE
                }
            }
            if (done) {
                i = i + 1
                next
            }
        }
        if (current.flag == 0) {
            stop(paste("\"", optstring, "\" is not a valid option, or does not support an argument", sep = ""))
        } else if (current.flag > 0) {
            if (debug) print("    dangling flag")
            if (length(opt) > i) {
                peek.optstring = opt[i + 1]
                if (debug) print(paste("      peeking ahead at: \"", peek.optstring, "\"", sep = ""))
                if ( substr(peek.optstring, 1, 1) != "-" | 
					(substr(peek.optstring, 1, 1) == "-" & regexpr("^-[0123456789]*\\.?[0123456789]+$", peek.optstring) > 0 & spec[current.flag, col.mode] ==  "double") | 
					(substr(peek.optstring, 1, 1) ==  "-" & regexpr("^-[0123456789]+$", peek.optstring) >  0 & spec[current.flag, col.mode] == "integer") ) {
                  if (debug) print(paste("        consuming argument *", peek.optstring, "*", sep = ""))
				  storage.mode(peek.optstring) = spec[current.flag, col.mode]
				  result[spec[current.flag, col.long.name]] = peek.optstring
				  i = i + 1
                } else if (substr(peek.optstring, 1, 1) == "-" & length(strsplit(peek.optstring, "")[[1]]) ==  1) {
                  if (debug) print("        consuming \"lone dash\" argument")
                  storage.mode(peek.optstring) = spec[current.flag, col.mode]
                  result[spec[current.flag, col.long.name]] = peek.optstring
                  i = i + 1
                } else {
                  if (debug) print("        no argument!")
                  if (spec[current.flag, col.has.argument] ==  flag.required.argument) {
                    stop(paste("flag \"", this.flag, "\" requires an argument",  sep = ""))
                  } else if (spec[current.flag, col.has.argument] ==  flag.optional.argument | spec[current.flag,  col.has.argument] == flag.no.argument) {
                    x = TRUE
                    storage.mode(x) = spec[current.flag, col.mode]
                    result[spec[current.flag, col.long.name]] = x
                  } else {
                    stop(paste("This should never happen.", "Is your spec argument correct?  Maybe you forgot to set",  "ncol=4, byrow=TRUE in your matrix call?"))
                  }
                }
            } else if (spec[current.flag, col.has.argument] ==  flag.required.argument) {
                stop(paste("flag \"", this.flag, "\" requires an argument",  sep = ""))
            } else if (spec[current.flag, col.has.argument] ==  flag.optional.argument) {
                x = TRUE
                storage.mode(x) = spec[current.flag, col.mode]
                result[spec[current.flag, col.long.name]] = x
            } else if (spec[current.flag, col.has.argument] ==  flag.no.argument) {
                x = TRUE
                storage.mode(x) = spec[current.flag, col.mode]
                result[spec[current.flag, col.long.name]] = x
            } else {
                stop("this should never happen (2).  please inform the author.")
            }
        } else {
        }
        i = i + 1
    }
    return(result)
}


apa.names$general <- c(apa.names$general, "fisherize")
fisherize <- function(obj, tails=2, workspace=2E05, adj="BH") {
    
    ## Given a vector = c(foreground.with, foreground.without, background.with, background.without), return a vector:
    ##  c(original vector, fg.ratio, bg.ratio, log2FC, enrichment, raw.p, NA)  where NA is the adjusted-pvalue placeholder
    ## Given a matrix/df where each row = vectors as formatted above, return a matrix/df where each row is:
    ##  c(original row, fg.ratio, bg.ratio, log2FC, enrichment, raw.p, adj.p)
    ##
    ## "tails" = 1 or 2 indicating fisher.test "alternative" values of (greater|lesser) or two-tailed, respectively.
    ##  in the 1-tailed case, the choice of tail automatically adjusts to the FG/BG ratio.  In the trivial case where FGR=BGR, tails=2.
    ## "workspace" is passed to fisher.test as is.
    ## "adj" specified p-adjustment method; only meaningful if "obj" is a matrix/df.
    
    fishers <- function(vec) {
        fgr <- vec[1]/sum(vec[1:2])
        bgr <- vec[3]/sum(vec[3:4])
        lfc <- zerofy(log2(fgr/bgr))  # occasionally, get 0/0
        enrich <- sign(lfc)
        alt <- ifelse(tails==2|lfc==0, "two.sided", ifelse(fgr>bgr, "greater", "less"))
        raw.p <- fisher.test(matrix(vec,nrow=2), alternative=alt, workspace=workspace)[[1]]
        return(c(vec,fgr,bgr,lfc,enrich,raw.p,NA))
    }
    
    if (is.nlv(obj)) {
        if (length(obj)!=4) { stop("'obj' must have length 4: c(foreground.with, foreground.without, background.with, background.without)\n") }
        return( fishers(obj) )
    } else if (is.matrix(obj) || is.data.frame(obj)) {
        if (ncol(obj)!=4) { stop("'obj' must have 4 columns: c(foreground.with, foreground.without, background.with, background.without)\n") }
        x <- t(apply(obj, 1, fishers))
        x[,10] <- p.adjust(x[,9], method=adj)
        colnames(x) <- qw(FG.W,FG.WO,BG.W,BG.WO,FG.PCT,BG.PCT,LOG2FC,ENRICH,RAW.P,ADJ.P)
        return(x)
    } else {
        stop("'obj' must be a non-list vector, matrix, or dataframe!\n")
    }
}


	

#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################


apa.names$general <- c(apa.names$general, "show.funcs")
show.funcs <- function(func, missing.only=FALSE) {
	
	## shows all functions called within the function 'func'
	## TO-DO: detect and remove any locally-defined functions
	
    x <- unlist(lapply(as.character(body(func)), function(w){ gsub(" ?\\(","(",w) }))
    y <- unlist(lapply(x, function(w){ unlist(strsplit(w,"[[:space:]]+")) }))
    y2 <- mgrepf("\\(",y)
    z <- unlist(lapply(y2, function(w){ unlist(strsplit(sub("\\([^\\(]*$","(",w),"\\(")) }))
    calls <- real(sapply(z, function(w){ sub("^.*[^[:alpha:]._]+","",w) }))
    if (missing.only) calls <- calls[!sapply(calls,existsFunction)]
    suniq(calls)
}


apa.names$general <- c(apa.names$general, "NA.interpolate")
NA.interpolate <- function(v) {
    ## v is a vector with NAs
    ## interpolates NA values from non-NA neighbors of NA positions
    ## terminal NAs are handled by taking the slope of the two non-NA neighbors and continuing that slope through the terminal NAs
    ## runs of single or 2+ NAs are all given same value (mean of non-NA neighbors)
    
    if (any(is.na(v))) {
        nav <- find.runs(is.na(v), terminal=FALSE)
        nav <- nav[names(nav)=="TRUE"]
        nav1 <- nav[listLengths(nav)==1]
        navM <- nav[listLengths(nav)>1]
        v2 <- v
        for (n in 1:length(nav)) {
            is <- nav[[n]]
            ir <- range(is)
            if (ir[1]==1 & ir[2]==length(v)) {
                ## entire vector was NA; nothing to do
            } else if (ir[1]==1) {
                m <- diff(v2[c(ir[2]+1,ir[2]+2)])
                for (j in rev(is)) v2[j] <- v2[j+1] - m
            } else if (ir[2]==length(v)) {
                m <- diff(v2[c(ir[1]-1,ir[1]-2)])
                for (j in is) v2[j] <- v2[j-1] - m
            } else {
                v2[is] <- mean(v2[c(ir[1]-1,ir[2]+1)])
            }
        }
        v2
    } else {
        v
    }
}


apa.names$general <- c(apa.names$general, "mov.avg")
mov.avg <- function(vec, win, func=mean, loop=FALSE, na.rm=FALSE, interpolate=FALSE) {
    
    ## takes a moving average of a vector, given a window size
    ## does this using apply() and not a loop -- may overrun mem limits for very large window size
    ## "loop=TRUE" makes it loop instead -- trades low mem for high runtime
    
    MA <- rep(NA, length(vec))
    len <- length(vec)-win
    start <- round(win/2,0)
    end <- start+len
    if (loop) {
        MA <- sapply(start:end, function(i){ func(vec[(i-start+1):(i-start+win)]) })  # actually, avoided the loop -- is this faster than loop=FALSE?
    } else {
        mat <- matrix(0, ncol=win, nrow=len+1)
        for (i in 1:win) mat[,i] <- vec[i:(len+i)]
        MA[start:end] <- apply(mat, 1, func, na.rm=na.rm)
    }
    if (interpolate) {
        NA.interpolate(MA)
    } else {
        MA
    }
}


apa.names$general <- c(apa.names$general, "lowess2")
lowess2 <- function(x, y=NULL, f=2/3, iter=3, delta=0.01*diff(range(x,na.rm=na.rm)), na.rm=FALSE) {
    
    ## same as lowess(), but allows for na.rm.  Lowesses non-NA values, then interpolates values for NA positions.
    
    nz <- is.na(x)
    if (length(y)>0) nz <- nz|is.na(y)
    
    if (na.rm & any(nz)) {
        x2 <- x[!nz]
        if (length(y)>0) {
            y2 <- y[!nz]
            ## Lowess with 'y'
            z <- lowess(x=x[!nz], y=y[!nz], f=f, iter=iter, delta=delta)
            ## Put 'x' values back in place (re-introduce NAs)
            z$x <- z$x[match(1:length(x),which(!nz))]
            ## Interpolate 'x' values
            z$x <- NA.interpolate(z$x)
        } else {
            ## Lowess with no 'y'
            z <- lowess(x=x[!nz], f=f, iter=iter, delta=delta)
            ## Replace 'x' values
            z$x <- 1:length(x)
        }
        ## put 'y' values back in place (re-introduce NAs)
        z$y <- z$y[match(1:length(x),which(!nz))]
        ## Interpolate 'y' values
        z$y <- NA.interpolate(z$y)
        z
    } else {
        lowess(x=x, y=y, f=f, iter=iter, delta=delta)
    }
}


apa.names$general <- c(apa.names$general, "thetacon")
thetacon <- function(vec, input, output) {
		
    ## converts between "thetas": slopes, degrees, and radians (= 'input' and 'output' types)
    ## 'input' is automatically converted to radians, then to 'output' value
    
    input <- tolower(input)
    output <- tolower(output)
    
    conv.fun <- function(x, input, output) {
        temp <- switch(input, deg=, degree=, degrees=x*pi/180, rad=, radian=, radians=x, m=, slope=atan(x))
        if (is.null(temp)) { stop("Unrecognized type for 'input'!\n") }
        
        if (round(temp,16)==pi/2 & output %in% c("m","slope")) {
            out <- Inf    # because R's tan() interpolates and doesn't get it quite right
        } else if (round(temp,16)==3*pi/2 & output %in% c("m","slope")) {
            out <- -Inf   # because R's tan() interpolates and doesn't get it quite right
        } else {
            out <- switch(output, deg=, degree=, degrees=temp*180/pi, rad=, radian=, radians=temp, m=, slope=tan(temp))
            if (is.null(out)) { stop("Unrecognized type for 'output'!\n") }
            if (out < 0) { out <- switch(output, deg=, degree=, degrees=360+out, rad=, radian=, radians=2*pi+out, m=, slope=out) }
        }
        return(out)
    }
    
    sapply(vec, conv.fun, input, output)
}


apa.names$general <- c(apa.names$general, "xy2polar")
xy2polar <- function(x) {
    
    ## Takes 'x' = cartesian (x,y) pair and returns polar (r,theta) pair
    
    r <- sqrt(x[1]^2+x[2]^2)
    if (x[1]>=0&x[2]>=0) {         # Q1
        th <- atan(x[2]/x[1])
    } else if (x[1]<0&x[2]>0) {    # Q2
        th <- pi - abs(atan(x[2]/x[1]))  # atan < 0
    } else if (x[1]<=0&x[2]<=0) {  # Q3
        th <- pi + abs(atan(x[2]/x[1]))  # abs to catch points where x=0 & y<0
    } else {                       # Q4
        th <- 2*pi - abs(atan(x[2]/x[1]))  # atan < 0
    }
    return(c(r=r,theta=th))
}


apa.names$general <- c(apa.names$general, "rebase")
rebase <- function(x, base=10, inbase=NULL, verbose=FALSE) {
	
	## converts a number x from one base to another
	## input base 'inbase' is decimal if x is numeric; else tries to guess binary or hex, else fails.
	## output base is 'base'
	## will return in charset [0-9] if b < 10; else uses [0-F] or [0-?] a la hex.  E.g. base 36 uses [0-Z]
	
	convert.base <- function(x, base, inbase, verbose) {
		extended <- data.frame(extended=LETTERS,decimal=10:35,stringsAsFactors=FALSE)
		digits <- unlist(strsplit(as.character(x), ''))
		lower <- which(digits %in% letters)
		if (length(lower)>0) { digits[lower] <- toupper(digits[lower]) }
		if (is.null(inbase)) {
			if (is.numeric(x)) { 
				inbase <- 10
			} else if (any(LETTERS[1:6] %in% digits)) {
				inbase <- 16
			} else if (any(LETTERS %in% digits)) {
				stop("Supradecimal digits in excess of 'F' detected, but 'inbase' has not been specified!\n")
			} else {
				stop("Number with base < 10 detected, but 'inbase' has not been specified!\n")
			}
		}
		baserange <- 2:36
		if (!(base %in% baserange & inbase %in% baserange)) { stop("'base' and 'inbase' must be between 2-36!\n") }
		extra <- inbase - 10
		
		if (verbose) { IM(digits) }
		if (inbase != 10) {
			if (inbase > 10) {
				for (i in 1:extra) {
					digits[digits==extended[i,1]] <- extended[i,2]
				}
			}
			if (verbose) { IM("Digits:",digits) }
			digits <- as.numeric(digits)
			places <- inbase ^ c((nchar(x)-1):0)
			if (verbose) { IM("Places:",places) }
			values <- digits * places
			if (verbose) { IM("Values:",values) }
			decimal <- sum(values)
			if (verbose) { IM("Decimal:",decimal) }
		} else {
			decimal <- x
			values <- as.numeric(digits)
		}
		
		maxdig <- min(c(base, 9))  # largest numerical digit useable
		if (verbose) { IM("maxdig = ",maxdig) }
		if (base == 10) {
			return(decimal)
		} else {
			newdigits <- rep(NA, floor(log(decimal)/log(base))+1)
			for (i in 1:length(newdigits)) {
				rem <- decimal %% base
				if (decimal < maxdig) { 
					newdigits[i] <- decimal
					if (verbose) { IM(i, decimal, rem, ":", 1, ":", newdigits[i]) }
				} else if (decimal < base) {
					newdigits[i] <- extended[extended[,2]==decimal,1] 
					if (verbose) { IM(i, decimal, rem, ":", 2, ":", newdigits[i]) }
				} else if (rem < maxdig) {
					newdigits[i] <- rem
					if (verbose) { IM(i, decimal, rem, ":", 3, ":", newdigits[i]) }
				} else if (rem < base) {
					newdigits[i] <- extended[extended[,2]==rem,1]
					if (verbose) { IM(i, decimal, rem, ":", 4, ":", newdigits[i]) }
				}
				decimal <- trunc(decimal/base)
			}
			newdigits <- rev(newdigits)
		}
		
		return(paste(newdigits,collapse=''))
	}
	
	if (length(x)>1 & is.null(inbase)) {
		stop("'inbase' must be specified if converting vectors!\n")
	}
	sapply(x, convert.base, base, inbase, verbose)
}


# apa.names$general <- c(apa.names$general, "find.quantile")
# find.quantile <- function(x, distrib, accuracy=.Options$digits, max.iter=100) {
    
    # ## inverse of the quantile() function: find the quantile for a given value 'x' in the distribution 'dist'
	# ## returns -Inf if quantile < 0 or Inf if quantile > 1.
    # ## "accuracy" indicates how many significant decimal places to calculate accuracy to.  May exceed ".Options$digits", but your return value won't.  "NA" deactivates (requires maximal accuracy)
	
	# zap <- ifelse(is.na(accuracy), FALSE, TRUE)
    # recurse <- function(target, distrib, iter, breaks) {
		# iter <- iter + 1
        # for (i in 1:length(breaks)) {
            # q <- quantile(distrib, breaks[i])[[1]]
# #			IM(iter,"i",i,"lb",length(breaks),"b-1",breaks[i-1],"b",breaks[i],"t",target,"q",q)
			# if (zap) q <- round(q, accuracy)
            # if (q == target) {    # direct hit
                # return(breaks[i])
            # } else if (q > target) {  # gone too far; backtrack
				# breaks2 <- seq(breaks[i-1], breaks[i], length=11)   # divide up current quantile window
				# y <- recurse(target, distrib, iter, breaks2)
				# return(y)
            # } else if (iter == max.iter) { 
				# message("Warning: failed to converge in ",max.iter," iterations!")
				# return(breaks[i])
            # } else { 
                # # q < target; continue
            # }
        # }
    # }
	
	# y <- x
	# y[x>max(distrib)] <- Inf
	# y[x<min(distrib)] <- -Inf
	# test <- which(!is.infinite(y))
	# y[test] <- sapply(x[test], function(i){ recurse(i, distrib, 0, seq(0,1,length=11)) })   # divide up full quantile range 
	# return(y)
# }


apa.names$general <- c(apa.names$general, "find.quantile")
find.quantile <- function(x, distrib) {
    
    ## inverse of the quantile() function: find the quantile for a given value 'x' in the distribution 'dist'
	
	ecdf(distrib)(x)
}


apa.names$general <- c(apa.names$general, "quantize")
quantize <- function (input, levels, tiebreak=c("random","up","down"), breaks=FALSE, na.rm=FALSE, indices=FALSE) {
	
	## Converts elements in the 'input' vector to their nearest values from the 'levels' vector.
	## i.e. vector-quantizes signal 'input' per codebook 'levels'.
	## "tiebreak" controls tie breaking; values can be "up", "down", or "random".
	## "breaks=T" treats 'levels' as a vector of bin breaks, and assigns 'input' values to one of these bins.
	##            Return vector contains values from 0:N (where N = length(levels)) indicating bin assignment (0 and N are flanks).
	##            'tiebreak' also acts on values which match bin breakpoints.
	## NOTE: infinites are quantized to the terminal values! (or flank bins)
	## 'indices=TRUE' returns the positions of matching elements in 'levels', not the actual quantized values.
	
	tiebreak <- match.arg(tiebreak)
	
	distfun <- function(x, ulev) {			# finds nearest level for value x
		if (is.na(x)) { 
			return(NA) 
		} else if (x == -Inf) {
			return(ulev[1])
		} else if (x == Inf) {
			return(ulev[length(ulev)])
		}

		dists <- abs(ulev - x)
		d <- which(dists == min(dists))		# cannot exceed 2 results (in case of tie)
		if (length(d) > 1) {			# multiple closest; pick one at random
			d <- switch(tiebreak,
				"random" = sample(d, 1),
				"up" = d[2],
				"down" = d[1]
			)
		}
		if (indices) {
			return(d)
		} else {
			return(ulev[d])
		}
	}
	
	binfun <- function(x, ulev) {			# finds the bin for value x
		if (is.na(x)) { 
			return(NA) 
		} else if (x == -Inf) {
			return(0)
		} else if (x == Inf) {
			return(length(ulev))
		}

		dists <- x - ulev
		if (any(dists == 0)) {			# breakpoint match
			d <- which(dists == 0)
			d <- switch(tiebreak,
				"random" = sample(c(d, d-1), 1),
				"up" = d,
				"down" = d-1
			)
		} else {
			if (all(dists < 0)) {		# left flank value (outside bins)
				d <- 0
			} else if (all(dists > 0)) {	# right flank value (outside bins)
				d <- length(ulev)
			} else {			# we are assuming not all NAs (broken input)
				d <- which(dists == min(dists[dists >= 0]))
			}
		}
		return(d)
	}
	
	dims <- dim(input)
	func <- ternary (breaks, binfun, distfun)
	x <- sapply(input, simplify=TRUE, func, unique(levels))
	y <- ternary (na.rm, x[!is.na(x)], x)
	if (is.null(dims)) {
		return(y)
	} else {
		z <- matrix(y, dims[1], dims[2])
		dimnames(z) <- dimnames(input)
		return(z)
	}
}


apa.names$general <- c(apa.names$general, "bed2gr")
bed2gr <- function(bed, zero.based=TRUE) {
    if (require("GenomicRanges")) {
        for (i in 2:3) bed[[i]] <- as.integer(bed[[i]])
        if (zero.based) {  # bed coords are zero-based: shift to one-based for gr
            bed[,2] <- bed[,2] + 1
        }
        if (ncol(bed)>=6) {
            GRanges(bed[,1], IRanges(bed[,2], bed[,3], bed[,3]-bed[,2]+1, bed[,4]), bed[,6])  # with strand
        } else {
            GRanges(bed[,1], IRanges(bed[,2], bed[,3], bed[,3]-bed[,2]+1, bed[,4]))  # without strand
        }
    } else {
        stop("Could not load library 'GenomicRanges'\n")
    }
}


apa.names$general <- c(apa.names$general, "gr2bed")
gr2bed <- function(gr, zero.based=FALSE, scores=NULL) {
    if (length(gr)==0) {
        message("No data in GenomicRanges object!")
        return() 
    }
    if (require("GenomicRanges")) {
        chr <- as.character(seqnames(gr))
        st <- start(gr)
        en <- end(gr)
        id <- as.character(names(gr))
        if (length(id)==0) id <- 1:length(chr)
        str <- as.character(strand(gr))
        if (zero.based) {  # gr coords are one-based: shift to zero-based if you want correct BED format
            st <- st - 1
        }
        with.scores <- TRUE
        if (length(scores)==0) {  # if you didn't specify your own scores
            scores <- rep(1,length(st))
            with.scores <- FALSE
        }
        if (all(str == "*")) {  # no strand info
            if (with.scores) {
                data.frame(CHR=chr,START=st,END=en,NAME=id,SCORE=scores)  # strands: no | scores: given
            } else {
                data.frame(CHR=chr,START=st,END=en,NAME=id)  # strands: no | scores: not given
            }
        } else {
            data.frame(CHR=chr,START=st,END=en,NAME=id,SCORE=scores,STRAND=str)  # strands: yes | scores: given, or dummy data
        }
    } else {
        stop("Could not load library 'GenomicRanges'\n")
    }
}


apa.names$bio.seq <- c(apa.names$bio.seq, "overlapSizes")
overlapSizes <- function(mat, gr1, gr2, method=c("all","max","min"), multi=TRUE) {
    stop("DEPRECATED: please use findOverlaps2()\n")
}


apa.names$bio.seq <- c(apa.names$bio.seq, "findOverlaps2")
findOverlaps2 <- function(query, subject=NULL, maxgap=0L, minoverlap=1L, type=c("any", "start", "end", "within", "equal"),
                          select=c("all", "first", "last", "arbitrary"), ignore.strand=FALSE, ignore.self=FALSE, only=c("all","smallest","largest")) {
    
    ## returns findOverlaps() result as a matrix, with extra columns
    ## arguments identical to GenomicRanges::findOverlaps(), except for"
    ## - 'ignore.self', which is only used if subject=NULL.
    ## - 'only', which indicates to filter results query-wise for the indicated overlap width
    ##   i.e. only="smallest" returns only the smallest overlap(s) per query; only="largest" the largest, only="all" returns everything.
    
    require(GenomicRanges)
    
    only <- match.arg(only)
    self <- FALSE
    if (length(subject)==0) {
        subject <- query
        self <- TRUE
    }
    ignore.self <- ignore.self & self
    
    ol <- suppressWarnings(findOverlaps(query=query, subject=subject, maxgap=maxgap, minoverlap=minoverlap, type=type, select=select, ignore.strand=ignore.strand))
    if (ignore.self) ol <- ol[attr(ol,"queryHits")!=attr(ol,"subjectHits")]
    olr <- as.matrix(ranges(ol, query@ranges, subject@ranges))
    olm <- as.matrix(ol)
    i <- olm[,1]
    j <- olm[,2]
    
#    output <- data.frame(
#        query=i, subject=j, seqname=as.character(seqnames(query))[i],
#        queryStart=start(query)[i], queryEnd=end(query)[i], queryName=names(query)[i], queryWidth=width(query)[i], queryStrand=as.character(strand(query))[i], 
#        subjectStart=start(subject)[j], subjectEnd=end(subject)[j], subjectName=names(subject)[i], subjectWidth=width(subject)[j], subjectStrand=as.character(strand(subject))[j],
#        overlapStart=olr[,1], overlapEnd=olr[,1]+olr[,2]-1, overlapWidth=as.integer(olr[,2])
#    )
    output <- data.frame(query=i, subject=j, overlapWidth=as.integer(olr[,2]))
    
    ## dups <- union( duplicated2(output[,1]), duplicated2(output[,2]) )
    ## CURRENTLY THIS IS QUERY-CENTRIC
    ## LATER THERE SHOULD BE SUBJECT-CENTRIC AND ACENTRIC (?) MODES (acentric being joint-smallest/largest, but this may not be resolvable for all overlap pairs)
    if (only != "all") {
        which.func <- if (only=="smallest") { which.min } else { which.max }
        keep <- rep(FALSE, nrow(output))
        dups <- which(duplicated2(output[,1]))
        unq <- setdiff(1:nrow(output), dups)
        keep[unq] <- TRUE
        keep[unlist(lapply(unique(output[dups,1]), function(i){ w=which(output[,1]==i); w[which.func(output$overlapWidth[w])] }))] <- TRUE
        output <- output[keep,]
    }
    
    output
}


apa.names$general <- c(apa.names$general, "gr.overlap.table")
gr.overlap.table <- function(gr1, gr2) {
    
    gr12 <- suppressWarnings(reduce(c(gr1,gr2)))
    gr12.ol1 <- as.matrix(findOverlaps(gr12,gr1))
    gr12.ol2 <- as.matrix(findOverlaps(gr12,gr2))
    gr12.olt <- lapply(list(table(gr12.ol1), table(gr12.ol2)), function(x) cbind(MERGE=as.numeric(names(x)),INPUT=c(x)) )
    gr12.1to2 <- matrix(0, length(gr12), 2)
    gr12.1to2[gr12.olt[[1]][,1],1] <- gr12.olt[[1]][,2]
    gr12.1to2[gr12.olt[[2]][,1],2] <- gr12.olt[[2]][,2]
    table(GR1=gr12.1to2[,1],GR2=gr12.1to2[,2])
}


apa.names$general <- c(apa.names$general, "nearest")
nearest <- function(x, vec, direction=c("0","1","-1"), index=FALSE, distance=FALSE) {
   
###### FIXME: direction !=0 no longer works
###### FIXME: if 'vec' contains multiple same nearest values, then pick index at correct side of equal-value run, depending if 'x' is higher or lower than that nearest value
      
    ## For values 'x', find its nearest neighbor in 'vec'
    ## 'direction' values: '-1' for nearest <= x, '1' for nearest >= x, '0' for absolute nearest.
    ## 'index' = whether to return the nearest position in 'vec' (TRUE) or the actual value from 'vec' (FALSE).
    ## 'distance' = whether to return the signed distance to the nearest position in 'vec' (TRUE) or the actual value from 'vec' (FALSE).
    ## if 'distance=T', negative values indicate n < x and positive values indicate n > x.
    ## 'index' and 'distance' cannot both be TRUE.
    
    direction <- as.character(direction)  # so can specify "0" or 0
    direction <- as.numeric(match.arg(direction))  # but lame match.arg() can only consider character vectors; then recast back to numeric
    if (index & distance) stop("'index' and 'distance' cannot both be TRUE!\n")
    if (length(vec)==0) return(NA)
    y <- rep(NA,length(x))
    
    for (i in 1:length(x)) {
        if (!is.na(x[i])) {
            d <- x[i] - vec
            if (direction == 0) {
                n <- which.min(abs(d))
            } else if (direction == 1) {
                gt <- which(d <= 0)
                n <- ifelse(length(gt)>0, gt[which.min(d[gt])], NA)
            } else if (direction == -1) {
                lt <- which(d >= 0)
                n <- ifelse(length(lt)>0, lt[which.max(d[lt])], NA)
            }
            
            if (index) {
                y[i] <- n
            } else if (distance) {
                y[i] <- vec[n]-x[i]
            } else {
                y[i] <- vec[n]
            }
	}
    }
    return(y)
}


apa.names$general <- c(apa.names$general, "minmax")
minmax <- function(targets, positions, values, window, direction=c("0","1","-1"), minmax=c("max","min"), nearest=FALSE) {
	
	## Finds minimum or maximum value(s) within some distance from 'targets'.
	## args as for 'nearest', except:
	##  'values' is a vector of numeric values corresponding to 'positions'.  These will be searched for min/max values.
	##  'window=N' sets a search window of size N, which may be:
	##    centered in targets[i] (distance=0),
	##    upstream of targets[i] (distance=-1),
	##    downstream of targets[i] (distance=1).
	##  'minmax' which indicates search for min or max value
	##  'nearest' which indicates to take only the nearest of N equivalent minima/maxima (nearest in 'positions' to targets[i]).
	
	direction <- as.character(direction)
	direction <- match.arg(direction)
	minmax <- match.arg(minmax)
	ismax <- ifelse(minmax=="max",TRUE,FALSE)
	lt <- length(targets)
	
	find.minmax <- function (x) {
		win <-	if (direction==0) {
					c(x-(window/2), x+(window/2))
				} else if (direction==1) {
					c(x, x+window)
				} else if (direction==-1) {
					c(x-window, x)
				}
		w <- which(positions>=win[1]&positions<=win[2])
		if (length(w)>0) {
			mmi <- w[ternary(ismax,which(values[w]==max(values[w])),which(values[w]==min(values[w])))]
			res <- cbind(Index=mmi, Position=positions[mmi], Value=values[mmi], Distance=zapsmall(positions[mmi]-x))
			if (nearest) res <- res[which(abs(res[,4])==min(abs(res[,4]))),,drop=FALSE]
			res
		} else {
			cbind(Index=NA, Position=NA, Value=NA, Distance=NA)
		}
	}

	lapply(targets, find.minmax)
}


apa.names$general <- c(apa.names$general, "nearest.neighbors")
nearest.neighbors <- function (x, y, direction=c("both","any","up","down"), strand=c("any","same","opp","both"), as.list=FALSE, chr.sizes=NULL, zero.based=FALSE, split.symbol=FALSE) {
    
    ## FIXME #1: OUTPUT CHR.START, CHR.END ENTRIES FOR UNMATCHED PEAKS
    
    ## takes two bed-format data frames or GRanges objects (x, y); must be full 6-column to use strand=c("same","opp").
    ## for each entry in x, returns the nearest neighbor(s) from y.
    ## neighbors can be restricted to upstream ("up"), downstream ("down"), either up or down ("any"), or both up and down ("both").
    ## neighbors can be restricted to the same strand ("same"), the opposite strand ("opp"), either ("any"), or both strands ("both").
    ## there may be > 1 nearest neighbor for a given coordinate, so the return object is a list with length=nrow(x).
    ##  elements of return list are selections from y, with a distance column attached.  Distance values are signed.
    ## NOTE: using strand="both" will double the number of NN column sets.
    
    if (!require("GenomicRanges")) stop("Could not load library 'GenomicRanges'\n")
    if (length(x)==0 | length(y)==0) { 
        message("Both x and y must have data!") 
        return()
    }
    direction <- match.arg(direction)
    strand <- match.arg(strand)
    
    if (length(chr.sizes)>0) {
        if (length(names(chr.sizes))==0 | !is.nlv(chr.sizes)) stop("If specified, 'chr.sizes' must be a vector of chr lengths with names == chr names!\n")
    }
    
    if (class(x)=="GRanges") x <- gr2bed(x)
    if (class(y)=="GRanges") y <- gr2bed(y)
    
    if (ncol(x)<4) x <- cbind(x,1:nrow(x),1,"+")  # fake rest of 6-col BED columns, if necessary
    if (ncol(y)<4) y <- cbind(y,1:nrow(y),1,"+")
    
    if (ncol(x)>6) x <- x[,1:6]  # restrict to 6-col BED columns, if necessary
    if (ncol(y)>6) y <- y[,1:6]
    
    have.strands <- ifelse(ncol(x)>=6 & ncol(y)>=6, TRUE, FALSE)
    if (strand != "any" & !have.strands) stop("Cannot specify strandedness without using 6-column BED format!\n")
    if (zero.based) {  # coords are 0-based; GenomicRanges expects 1-based
        x[,2] <- x[,2] + 1
        y[,2] <- y[,2] + 1
    }
    cnames <- qw(CHR,START,END,NAME,SCORE,STRAND)
    ncx <- ncol(x)
    ncy <- ncol(y)
    colnames(x) <- c(cnames[1],paste(cnames[2:ncx],"1",sep="."))
    colnames(y) <- paste(cnames[1:ncy],"2",sep=".")
    
    x2 <- mat.split(x, x[,1])
    y2 <- mat.split(y, y[,1])
    strands <- c("+","-")
    chr <- suniq(x[,1])
    which.chr.x <- named.list(lapply(chr, function(n) which(x[,1]==n) ), chr)
    which.chr.y <- named.list(lapply(chr, function(n) which(y[,1]==n) ), chr)
    NN <- new.list(x[,4])
    
    cwidth <- max(nchar(chr))
    xwidth <- nchar(nrow(x))
    ywidth <- nchar(nrow(y))
    fmt <- paste0("%-",cwidth,"s : %",xwidth,"i input coords : %",ywidth,"i neighbor pool")
    
    IM("Matching...")
    for (C in chr) {
        
        wCx <- which.chr.x[[C]]
        wCy <- which.chr.y[[C]]
        xC <- x2[[C]]
        yC <- y2[[C]]
        IM(sprintf(fmt, C, length(wCx), length(wCy)))
        
        neighborless <- FALSE
        nn.hit <- new.list(xC[,4])    # direct-hit neighbors; 1 element per input coord (that will be matched to neighbors)
        nn.up.as <- nn.dn.as <- new.list(xC[,4])   # all-strand non-hit neighbors, upstream and downstream
        nn.up.ss <- nn.dn.ss <- new.list(xC[,4])   # same-strand non-hit neighbors, upstream and downstream
        nn.up.os <- nn.dn.os <- new.list(xC[,4])   # opposite-strand non-hit neighbors, upstream and downstream
        
        if (length(yC)==0) {
            
            neighborless <- TRUE
            nn.hit   <- lapply(nn.up.as, function(x) cbind(NA, 0,NA,-1) )  # neighbor, dir, strand, class
            nn.up.as <- lapply(nn.up.as, function(x) cbind(NA,-1,NA,-1) )  # neighbor, dir, strand, class
            nn.dn.as <- lapply(nn.dn.as, function(x) cbind(NA, 1,NA,-1) )  # neighbor, dir, strand, class
            
        } else {
            
            y.gr <- bed2gr(yC)
            y.ir <- IRanges(start=start(y.gr), width=width(y.gr))
            
            if (strand == "any") {
                
                x.gr <- bed2gr(xC)
                x.ir <- IRanges(start=start(x.gr), width=width(x.gr))
                ## returning: neighbor, dir, strand, class
                nn.hit   <- lapply(as.list(suppressWarnings(IRanges::findOverlaps(x.ir,y.ir))),         function(x) cbind(ifelse(is.null(x),NA,x), 0,NA,0) )
                nn.up.as <- lapply(as.list(suppressWarnings(IRanges::follow(x.ir,y.ir,select="all"))),  function(x) cbind(ifelse(is.null(x),NA,x),-1,NA,1) )
                nn.dn.as <- lapply(as.list(suppressWarnings(IRanges::precede(x.ir,y.ir,select="all"))), function(x) cbind(ifelse(is.null(x),NA,x), 1,NA,2) )
                
            } else {
                
                which.str.x <- lapply(strands, function(s) sort(which(xC[,6]==s)) )  # separate input coords by strand
                which.str.y <- lapply(strands, function(s) sort(which(yC[,6]==s)) )  # separate neighbor pool by strand
                
                for (s in 1:2) {  # strands; 1="+", 2="-"
                    
                    wsx <- which.str.x[[s]]
                    wsy <- which.str.y[[s]]
                    if (length(wsx)==0 | length(wsy)==0) next
                    xCs <- xC[wsx,]
                    if (nrow(xCs)==0) next
                    x.gr <- bed2gr(xCs)
                    x.ir <- IRanges(start=start(x.gr), width=width(x.gr))
                    
                    nn.hit[wsx] <- as.list(suppressWarnings(IRanges::findOverlaps(x.ir,y.ir)))
                    all.blank <- wsx[ listLengths(nn.hit[wsx])>0 ]
                    nn.hit[all.blank] <- lapply(nn.hit[all.blank], function(y) cbind(y,0,0,0) )  # neighbor, dir, strand, class
                    
                    if (strand == "both") {
                        
                        yCs <- yC[wsy,]
                        yCs.gr <- bed2gr(yCs)
                        yCs.ir <- IRanges(start=start(yCs.gr), width=width(yCs.gr))
                        opp <- ifelse(s==1,2,1)
                        woy <- which.str.y[[opp]]
                        yCo <- yC[which.str.y[[opp]],]
                        yCo.gr <- bed2gr(yCo)
                        yCo.ir <- IRanges(start=start(yCo.gr), width=width(yCo.gr))
                        
                        ## returning: neighbor, dir, strand, class
                        nn.up.ss[wsx] <- lapply( as.list(suppressWarnings(IRanges::follow(x.ir,yCs.ir,select="all"))), function(y) cbind(ifelse(is.null(y),NA,wsy[y]),-1,s,1) )
                        nn.dn.ss[wsx] <- lapply( as.list(suppressWarnings(IRanges::precede(x.ir,yCs.ir,select="all"))), function(y) cbind(ifelse(is.null(y),NA,wsy[y]),1,s,2) )
                        nn.up.os[wsx] <- lapply( as.list(suppressWarnings(IRanges::follow(x.ir,yCo.ir,select="all"))), function(y) cbind(ifelse(is.null(y),NA,woy[y]),-1,opp,3) )
                        nn.dn.os[wsx] <- lapply( as.list(suppressWarnings(IRanges::precede(x.ir,yCo.ir,select="all"))), function(y) cbind(ifelse(is.null(y),NA,woy[y]),1,opp,4) )
                        
                        ## fill in ss blanks, which will become chr start/end entries
                        up.blank.ss <- wsx[ sapply(nn.up.ss[wsx], ncol)==3 ]
                        dn.blank.ss <- wsx[ sapply(nn.dn.ss[wsx], ncol)==3 ]
                        nn.up.ss[up.blank.ss] <- lapply(up.blank.ss, function(y) cbind(NA,-1,s,11) )  # neighbor, dir, strand, class
                        nn.dn.ss[dn.blank.ss] <- lapply(dn.blank.ss, function(y) cbind(NA, 1,s,12) )  # neighbor, dir, strand, class
                        
                        ## fill in os blanks, which will become chr start/end entries
                        up.blank.os <- wsx[ sapply(nn.up.os[wsx], ncol)==3 ]
                        dn.blank.os <- wsx[ sapply(nn.dn.os[wsx], ncol)==3 ]
                        nn.up.os[up.blank.os] <- lapply(up.blank.os, function(y) cbind(NA,-1,opp,11) )  # neighbor, dir, strand, class
                        nn.dn.os[dn.blank.os] <- lapply(dn.blank.os, function(y) cbind(NA, 1,opp,12) )  # neighbor, dir, strand, class
                        
                        nn.up.as[wsx] <- nn.up.ss[wsx]
                        nn.dn.as[wsx] <- nn.dn.ss[wsx]
                        for (i in wsx) {
                            nn.up.as[[i]] <- do.call(rbind, list(nn.up.ss[[i]], nn.up.os[[i]]))
                            nn.dn.as[[i]] <- do.call(rbind, list(nn.dn.ss[[i]], nn.dn.os[[i]]))
                        }
                        
                    } else {
                        
                        if (strand == "same") {
                            yCs <- yC[wsy, ]
                            str <- s
                        } else if (strand == "opp") {
                            str <- opp <- ifelse(s==1,2,1)
                            yCs <- yC[which.str.y[[opp]], ]
                        }
                        if (nrow(yCs)==0) next
                        yCs.gr <- bed2gr(yCs)
                        yCs.ir <- IRanges(start=start(yCs.gr), width=width(yCs.gr))
                        
                        ## returning: neighbor, dir, strand, class
                        nn.up.as[wsx] <- lapply( as.list(suppressWarnings(IRanges::follow(x.ir,yCs.ir,select="all"))),  function(y) cbind(ifelse(is.null(y),NA,wsy[y]),-1,str,1) )
                        nn.dn.as[wsx] <- lapply( as.list(suppressWarnings(IRanges::precede(x.ir,yCs.ir,select="all"))), function(y) cbind(ifelse(is.null(y),NA,wsy[y]), 1,str,2) )
                        
                        ## fill in blanks, which will become chr start/end entries
                        up.blank <- wsx[ sapply(nn.up.as[wsx], ncol)<=3 ]  # just for .ss; .os handled above if needed
                        dn.blank <- wsx[ sapply(nn.dn.as[wsx], ncol)<=3 ]
                        nn.up.as[up.blank] <- lapply(up.blank, function(y) cbind(NA,-1,str,13))  # neighbor, dir, strand, class
                        nn.dn.as[dn.blank] <- lapply(dn.blank, function(y) cbind(NA, 1,str,14))  # neighbor, dir, strand, class
                    }
                }
            }
        }
        
        for (i in 1:length(wCx)) {   # for each input gene on chr C
            ## Compile all hits for this input coord
            tmp <- list()
            if (nrow(nn.up.as[[i]])>0) tmp <- c( tmp, list( cbind(nn.up.as[[i]][,1:4,drop=FALSE], yC[nn.up.as[[i]][,1],3]-xC[i,2], match(yC[nn.up.as[[i]][,1],6],strands)) ) )
            if (nrow(nn.dn.as[[i]])>0) tmp <- c( tmp, list( cbind(nn.dn.as[[i]][,1:4,drop=FALSE], yC[nn.dn.as[[i]][,1],2]-xC[i,3], match(yC[nn.dn.as[[i]][,1],6],strands)) ) )
            if (nrow(nn.hit[[i]])>0)   tmp <- c( tmp, list( cbind(  nn.hit[[i]][,1:4,drop=FALSE],                               0, match(yC[  nn.hit[[i]][,1],6],strands)) ) )
            if (neighborless) {
                for (j in 1:length(tmp)) {
                    if (ncol(tmp[[j]])<6) tmp[[j]] <- cbind(tmp[[j]], colrep(rep(NA,nrow(tmp[[j]])), 6-ncol(tmp[[j]])))
                }
            }
            tmp <- as.data.frame(do.call(rbind, tmp), stringsAsFactors=FALSE)  # DATA.FRAME CLASS REQUIRED AFTER THIS POINT
            for (j in 1:ncol(tmp)) mode(tmp[[j]]) <- "integer"  # remove any float issues
            colnames(tmp) <- qw(Neighbor, Dir, Strand, Class, Distance, NbStrand)
            ## Flag distances / directions for chr ends
            dist.na.up <- is.na(tmp$Distance) & tmp$Dir < 0
            dist.na.dn <- is.na(tmp$Distance) & tmp$Dir > 0
            if (any(dist.na.up)) tmp$Distance[dist.na.up] <- -Inf
            if (any(dist.na.dn)) tmp$Distance[dist.na.dn] <- Inf
            ## Add actual data for input coord, neighbor(s)
            if (neighborless) {
                neighb.dat <- xC[NA,][1:3,]  # neighborless 'tmp' objects always have 3 rows
                colnames(neighb.dat) <- paste0(sub(".1$","",colnames(neighb.dat)),".2")
            } else {
                neighb.dat <- yC[tmp[,1],]
            }
            tmp <- cbind( rowrep(xC[i,],nrow(tmp)), neighb.dat, tmp[,5,drop=FALSE] )  # from 'tmp' keep only Distance; the other columns were for troubleshooting
            tmp <- tmp[!(is.na(tmp$CHR.2)&falsify(tmp$Distance==0)),]  # drop rows for nonexistent overlap-neighbors
            NN[[ wCx[i] ]] <- tmp[order(tmp$Distance),colnames(tmp)!="CHR.2"]  # sort by distance and drop redundant second chrom column
        }
    }
    
    IM("Collapsing...")
    ## collapse list to data.frame, add column flagging smallest-distance neighbors per input coord
    is.nearest <- function(x) {
        if (any(is.real(x))) {
            abs(x)==min(abs(x),na.rm=TRUE)
        } else {
            rep(FALSE, length(x))
        }
    }
    
    Nearest <- falsify(unlist(lapply(lapply(NN,"[[","Distance"), is.nearest)))
    NNnr <- sum(sapply(NN,nrow))
    NN2 <- NN[[1]][0,]  # rowless data.frame
    offset <- 0
    for (n in 1:length(NN)) {
        ## now avoiding do.call(rbind,NN) because will fail if too many chromosomes (e.g. nemVec1)
        if (nrow(NN[[n]])==0) next
        i <- offset+1
        j <- offset+nrow(NN[[n]])
        NN2[i:j,] <- NN[[n]]
        offset <- j
    }
    NN <- rownameless(cbind(NN2, Nearest=Nearest))
    rm(NN2)
    
    IM("Filtering...")
    if (direction == "both") {
        ## do nothing
    } else if (direction == "any") {
        NN <- NN[NN$Nearest,]  # take only smallest-distance neighbors
    } else if (direction == "up") {
        NN <- NN[NN$Dir<=0,]  # take only upstream or overlap neighbors
    } else if (direction == "down") {
        NN <- NN[NN$Dir>=0,]  # take only downstream or overlap neighbors
    }
    
    IM("Annotating neighborless positions...")
    ## Missing neighbor names mean neighbor == chrom start/end; label as such
    is.chr <- is.infinite(NN$Distance)
    if (any(is.chr)) {
        need.start <- sapply(NN$Distance,identical,-Inf)
        need.end <- sapply(NN$Distance,identical,Inf)
        NN$NAME.2[need.start] <- "CHR.START"
        NN$NAME.2[need.end] <- "CHR.END"
        if (length(chr.sizes)>0) {
            ## add distances to starts/ends if chromosome sizes are available.
            ## we could add start distances no matter what, but for consistency's sake, it's double or nothing.
            chr.ends <- chr.sizes[match(NN$CHR[need.end],names(chr.sizes))]
            NN$START.2[need.start] <- ifelse(zero.based, 0, 1)
            NN$END.2[need.start] <- ifelse(zero.based, 0, 1)
            NN$START.2[need.end] <- chr.ends
            NN$END.2[need.end] <- chr.ends
            NN$Distance[need.start] <- -NN$START.1[need.start]
            NN$Distance[need.end] <- chr.ends-NN$END.1[need.end]
        }
    }
    
    if (split.symbol) {
        IM("Splitting symbols...")
        ## neighbor names are "geneID:symbol"; split into separate columns
        wn2 <- which(colnames(NN)=="NAME.2")
        NN <- NN[,c(1:wn2,wn2:ncol(NN))]
        colnames(NN)[wn2+1] <- "SYMB.2"
        nsplit <- strsplit(NN$NAME.2[!is.chr],":")
        NN$SYMB.2[is.chr] <- ""
        NN$STRAND.2[is.chr] <- "."
        NN$NAME.2[!is.chr] <- sapply(nsplit, '[', 1)
        NN$SYMB.2[!is.chr] <- sapply(nsplit, '[', 2)
    }
    
    if (as.list) NN <- mat.split(NN, NN$NAME.1)
    NN
}


apa.names$general <- c(apa.names$general, "binify")
binify <- function(vec, bins, fun=mean, na.rm=FALSE, drop.short=FALSE, distribute=c("first","last","random","drop")) {
	
	## takes a vector and bins the values into N bins, specified by 'bins'
	## "fun" is the actual function (NOT NAME) used to evaluate bins, e.g. sum, mean, median, sd, etc
	## "na.rm" like it is in other functions
	## "drop.short=T" returns 'NA' for any vector with fewer than 'bins' values
	## "distribute" can be one of c("first","last","random") indicating how leftover positions should be distributed among bins
	
	distribute <- match.arg(distribute)
	L <- length(vec)
	binned <- rep(0, bins)
	if (L >= bins) {   		# long enough to bin
		span <- trunc(L/bins)		# base width per bin
		remainder <- L-span*bins	# leftover positions @ base width
		widths <- rep(span,bins)	# bin width vector
		if (remainder > 0) {
			if (distribute=="first") {
				alloc <- 1:remainder
			} else if (distribute=="last") {
				alloc <- (bins-remainder+1):bins
			} else if (distribute=="random") {
				alloc <- sample(1:bins, remainder)
			} else if (distribute=="drop") {
				alloc <- NULL
			}
#			IM(span, remainder, ':', widths, ':', alloc)
			widths[alloc] <- widths[alloc]+1  # distribute leftovers to first 'remainder' bins
#			IM(widths)
		}
		end <- 0
		for (i in 1:bins) {
			start <- end + 1
			end <- end + widths[i]
			binned[i] <- fun(vec[start:end], na.rm=na.rm)
		}
	} else if (drop.short) {	# too short; drop
		binned <- rep(NA,bins)
	} else {				# too short, but binify it anyway (stretch vector to # bins)
		span <- trunc(bins/L)		# how many bins each position must stretch over (base value)
		remainder <- bins-span*L	# leftover positions need to be placed
		posits <- rep(1:L,each=span)		# vector indicating which bins each position is stretched over
		if (remainder > 0) {
			if (distribute=="first") {
				alloc <- 1:remainder
			} else if (distribute=="last") {
				alloc <- (L-remainder+1):L
			} else if (distribute=="random") {
				alloc <- sample(1:L, remainder)
			}
#			IM(span, remainder, ':', posits, ':', alloc)
			posits <- sort(c(posits, alloc))  # add leftover positions; resort: should now have length == bins
#			IM(posits)
		}
		for (i in 1:bins) {
			binned[i] <- vec[posits[i]]	  # no function applied because no multiple values to summarize
		}
	}
	return(binned)
}



apa.names$general <- c(apa.names$general, "rescale")
rescale <- function(x, to, from=NULL, na.rm=FALSE) {
    
    ## rescales values found in from to values from to
    ## intended so that from[1] <= {all x} <= from[2]; and to is derived from from (in some other scale, e.g.)
    ## the algorithm then finds the relative position of each member of x in from and returns the corresponding relative value from to
    
	if (length(to) == 1) stop("'to' must have >= 2 entries!\n")
	if (length(from) == 1) stop("'from', if specified, must have >= 2 entries!\n")
	
	if (length(from) == 0) {
		if (length(x) == 1) {
			stop("Must specify 'from' if rescaling a single value!\n")
		} else {
			from <- range(x, na.rm=TRUE)  # always TRUE, else may not get a range
		}
	}
	if (length(from) == 2) {  # range
#		if (length(x) == 1) {
			y <- percentify(x, range=from, na.rm=na.rm)
#		} else {
#			y <- percentify(x, range=TRUE, na.rm=na.rm)
#		}
		z <- y * diff(to) + to[1]
	} else {   # distribution
		z <- sapply(x, find.quantile, from)
		z[is.infinite(z)] <- NA
		z[!is.na(z)] <- quantile(to, z[!is.na(z)])
	}
	return(z)
}


apa.names$general <- c(apa.names$general, "chase")
chase <- function (start, vec, value, reverse=FALSE) {
	
	## Finds end position of an unchanging run of values in a vector (assuming it starts in such a run).
	## Initialize at 'start' in 'vec' having value 'value'; finds end of unbroken run of 'value'.
	## "reverse=T" makes the search run backwards instead of forwards.
	
	others <- which(vec != value)
	if (start %in% others) {		# start position does not have the desired value!
		return(start)
	} else if (start > 1 & start < length(vec)) {
		if (vec[(start-1)] != value & vec[(start+1)] != value) {	# non-terminal start which is not in a run!  Nowhere to go.
			return(start)
		}
	}
	if (reverse) {
		flank <- others[which(others < start)]
		return(flank[length(flank)] + 1)
	} else {
		flank <- others[which(others > start)]
		if (length(flank) == 0) {	# ran to the end
			return(length(vec))
		} else {
			return(flank[1] - 1)
		}
	}
}


apa.names$general <- c(apa.names$general, "find.runs")
find.runs <- function(vec, terminal=TRUE, index=TRUE) {
	
	## Returns a list of index ranges (start-end) where contiguous runs of a identical numbers occur in the input vector.
	## Names of the ranges indicate the values for those indexes.
	## 'terminal' returns only the interval endpoints.
	## 'index' indicates whether to return runs as indices (TRUE) or as input values (FALSE)
     
	## difference positions reported by diff() are right-inclusive ONLY.  Take this into account if making changes.
    
    L <- length(vec)
    if (length(unique(vec)) == 1) {
        runs <- vector("list", length=1)
        names(runs) <- vec[1]
        if (terminal) {
            runs[[1]] <- c(1,L)
        } else {
            runs[[1]] <- 1:L
        }
    } else {
        end <- ifelse(falsify(vec[(L-1)] == vec[L]), 1, 0)
        d <- c(diff(vec), end)   # cap runs of 2 or more with a 1 (or, singleton final element gets 0)
        x <- which(d != 0)
        X <- length(x)
        runs <- vector("list", length=X+1)
        names(runs) <- c(vec[x], vec[L])
        for (i in 1:X) {
            if (i == 1) {	               # first entry
                if (terminal) {
                    runs[[i]] <- c(1,x[i])             # must run to beginning of parent vector
                } else {
                    runs[[i]] <- 1:x[i]
                }
            } else if (i == X) {	     # last entry
                if (terminal) {
                    runs[[i]] <- c(x[i-1]+1,x[i])      # add run to the left
                } else {
                    runs[[i]] <- (x[i-1]+1):x[i]
                }
            } else {			          # non-terminal entry
                if (terminal) {
                    runs[[i]] <- c(x[i-1]+1,x[i])
                } else {
                    runs[[i]] <- (x[i-1]+1):x[i]
                }
            }
        }
        if (end == 0) {                    # singleton final index to account for
            if (terminal) {
                runs[[(i+1)]] <- c(L,L)
            } else {
                runs[[(i+1)]] <- L
                runs[[(i+1)]] <- L
            }
            names(runs)[(i+1)] <- vec[L]
        }
        if (length(runs[[X+1]])==0) runs[[X+1]] <- NULL   # remove
    }
    if (index) {
        runs
    } else {
        lapply(runs, FUN=function(x){vec[x]})
    }
}


apa.names$general <- c(apa.names$general, "find.runs2")
find.runs2 <- function(vec, terminal=TRUE, index=TRUE) {
	
	## Returns a list of index ranges (start-end) where contiguous runs of a identical values occur in the input vector.
	## Names of the ranges indicate the values for those indexes.
	## 'terminal' returns only the interval endpoints.
	## 'index' indicates whether to return runs as indices (TRUE) or as values at those indices (FALSE)
     
	## difference positions reported by diff() are for distances to the RIGHT of the ith position.  Take this into account if making changes.
     
	L <- length(vec)
	if (length(unique(vec)) == 1) {
		runs <- vector("list", length=1)
		if (terminal) {
			runs[[1]] <- c(1,L)
		} else {
			runs[[1]] <- 1:L
		}
	} else {
		u <- sort(unique(vec),na.last=TRUE)
		runs.u <- lapply(u, function(i){
			if (is.na(i)) {
				w <- which(is.na(vec))
			} else {
				w <- which(vec==i)
			}
			brk <- which(diff(w)!=1)
			if (length(brk)==0) {
				if (length(w)==1) {
					list(c(w,w))
				} else {
					list(range(w))
				}
			} else {
				tmp <- new.list(1:(length(brk)+1))
				for (j in 1:length(brk)) {
					init <- ifelse(j==1,1,brk[j-1]+1)
					tmp[[j]] <- c(w[init], w[brk[j]])
				}
				tmp[[j+1]] <- c(w[brk[j]+1], w[length(w)])
				tmp
			}
		})
		runs <- new.list(rep(u,times=sapply(runs.u,length)))
		f <- 0
		for (n in 1:length(u)) {
			i <- f + 1
			f <- f + length(runs.u[[n]])
			runs[i:f] <- runs.u[[n]]
		}
		runs <- runs[order(unlist(slice.list(runs,1)))]
		if (!terminal) runs <- lapply(runs, function(x) x[1]:x[2] )
	}	  
    if (index) {
		runs
	} else {
		lapply(runs, FUN=function(x){vec[x]})
	}
}


apa.names$general <- c(apa.names$general, "reorder.matrix")
reorder.matrix <- function(mat, alt=NULL, metric="euclidean", linkage="average", clusters=NULL, col.ord=TRUE) {
    
    ## Reorders a matrix by clustering rows and columns.
    ## 'clusters' is a list with N elements denoting clusters; each element contains row indices
    ##   using 'clusters' will focus reordering on the clusters instead of using the whole matrix
    ## 'col.ord' passed to internal function 'get.order'
    ## if 'alt' is specified, matrix gets reordered using clustering order from 'alt', NOT 'mat'    *** 'alt' option not yet ready to go
    
    if (!is.matrix(mat)) { stop("Object must be a matrix!\n") }
    if (!is.null(clusters) & nrow(mat)!=ncol(mat)) { stop("Matrix must be square to use 'clusters'!\n") }
    if (!is.null(alt)) { 
        if (nrow(mat) == nrow(alt) && ncol(mat) == ncol(alt)) {
            alt.dim <- 3
        } else if (nrow(mat) == nrow(alt)) {
            alt.dim <- 1
        } else if (ncol(mat) == ncol(alt)) {
            alt.dim <- 2
        } else {
            stop("No corresponding dimensions between 'alt' and 'mat'!  Cannot use 'alt' for ordering.\n")
        }
    }
	
    cor.metrics <- c("pearson","spearman","kendall")
    dist.metrics <- c("euclidean","maximum","manhattan","canberra","binary","minkowski")
    distance.metrics <- c("pearson.dist","spearman.dist","kendall.dist")
    ## Test main metric
    if (metric %in% cor.metrics) {
        is.corr <- TRUE; is.dist <- FALSE; is.distance <- FALSE
    } else if (metric %in% dist.metrics) {
        is.corr <- FALSE; is.dist <- TRUE; is.distance <- FALSE
    } else if (metric %in% distance.metrics) {
        dmetric <- sub(".dist$","",metric)
        is.corr <- FALSE; is.dist <- FALSE; is.distance <- TRUE
    } else {
        stop(paste("'",metric,"' is not a recognized correlation or distance metric!\n",sep=""))
    }
    
    get.order <- function(obj, ord.col=col.ord) {      # gets most stuff from outside namespace
        if (is.corr) {
            dist.row <- as.dist(cor(t(obj), method=metric))
            if (ord.col) dist.col <- as.dist(cor(obj, method=metric))
        } else if (is.dist) {
            dist.row <- dist(obj, method=metric)
            if (ord.col) dist.col <- dist(t(obj), method=metric)
        } else if (is.distance) {
            dist.row <- distance(obj, method=dmetric)
            if (ord.col) dist.col <- distance(t(obj), method=dmetric)
        }
        hc.r <- hclust(dist.row, method=linkage)
        if (ord.col) { 
            hc.c <- hclust(dist.col, method=linkage) 
            return( list(ROW=hc.r$order,COL=hc.c$order) )
        } else {
            return(hc.r$order)
        }
    }
    
    if (is.null(clusters)) {
		if (is.null(alt)) {
			ords <- get.order(mat)
		} else {
			ords <- get.order(alt)
		}
		if (col.ord) {
			return(mat[ords$ROW,ords$COL])
		} else {
			return(mat[ords,ords])
		}
	} else {
        N <- length(clusters)
        ## get between-clusters order
        pattern <- breakout(clusters, reverse=TRUE)
		pattern[,1] <- as.numeric(as.factor(pattern[,1]))
        mode(pattern) <- "numeric"
        pattern <- pattern[order(pattern[,2]),]

        means1 <- aggregate(mat, by=list(pattern[,1]), mean)
        rownames(means1) <- means1[,1]; means1 <- means1[,-1]
        means2 <- aggregate(t(means1), by=list(pattern[,1]), mean)
        rownames(means2) <- means2[,1]; means2 <- means2[,-1]
        ord.between <- get.order(means2,ord.col=FALSE)
        ## get within-clusters order
        ord.within <- clusters
        for (i in 1:N) {
            clust.mat <- mat[clusters[[i]],clusters[[i]]]
			ord.within[[i]] <- clusters[[i]]
			if (length(clusters[[i]])>1) ord.within[[i]] <- clusters[[i]][get.order(clust.mat,ord.col=FALSE)]
        }
        ## order matrix
        final.ord <- unlist(ord.within[ord.between])
        return(mat[final.ord,final.ord])
    }
}


apa.names$general <- c(apa.names$general, "export.columns")
export.columns <- function(x, row.names=TRUE, col.names=TRUE, file.names=NULL, prefix=NULL, delim="_") {
	
	## Write all columns from a dataset as individual files
	
    if (!is.matrix(x) & !is.data.frame(x)) { stop("Input must be a matrix or data frame!\n") }
	
	if (length(file.names)==0) {
		if (length(colnames(x))==0) { 
			file.names <- paste("Column",1:ncol(x),sep="")
		} else {
			file.names <- colnames(x)
		}
	} else if (length(file.names)!=ncol(x)) { 
		stop("length(file.names) != ncol(x)\n") 
	}
	
	if (is.null(prefix)) { 
		file.names <- file.names
	} else if (length(prefix) == 1) {
		file.names <- paste(prefix, file.names, sep=delim)
	} else {
		stop("If specified, 'prefix' must have length=1 or length=ncol(x)!\n")
	}
	
	for (i in 1:ncol(x)) {
		if (row.names) {
			df <- data.frame(rownames(x), x[,i])
			if (col.names) { colnames(df) <- c("Row",colnames(x)[i]) }
		} else {
			df <- data.frame(x[,i])
			if (col.names) { colnames(df) <- colnames(x)[i] }
		}
		write.table(df, file=paste(file.names[i],"txt",sep="."), sep="\t", quote=FALSE, row.names=FALSE, col.names=col.names)
	}
}


apa.names$general <- c(apa.names$general, "RPM.norm")
RPM.norm <- function(mat, minimum=0, M=1E6, rescale=FALSE, totals=NULL) {
	
	## Reads-per-million normalizes a matrix of raw read counts, where rows are genes (e.g.) and columns are lanes (e.g.)
	## "subzero" if not null, replaces zeroes with specified value, for example 0.5 (half the smallest positive integer)
	##  - "subzero = NA" will convert zeroes to NAs.
	## "totals" is an optional vector specifying true read totals per lane; otherwise, colSums(mat) is used.
	
	nonlistvector <- ifelse(is.vector(totals) & !is.list(totals), TRUE, FALSE)
	if (!is.matrix(mat)) { stop("Object must be a matrix!  If vector, recast using as.matrix()\n") }
	if (length(minimum) > 1) { stop("'minimum' must be singular!\n") }
	if (!is.null(totals) & !nonlistvector) { stop("If specified, 'totals' must be a vector!\n") }
	if (nonlistvector & (length(totals) != ncol(mat))) { stop("'totals' must be a vector with length = ncol(mat)!\n") }
	
	if (!is.null(minimum)) {
		mat[is.na(mat)] <- minimum
		mat[mat==0] <- minimum
	}
	if (is.null(totals)) { totals <- colSums(mat, na.rm=TRUE) }
	RPM <- t( t(M*mat) / totals)
	return(RPM)
}


apa.names$general <- c(apa.names$general, "anyfc")
anyfc <- function(vec, func=max) {
	
	## Returns the max fold-change between any 2 points fom a vector in log2
	## Or can return min, mean, etc. depending on 'fun'.
	
	n <- length(vec)
	m <- outer(vec, vec, "-")
	func(m, na.rm=TRUE)
}


apa.names$general <- c(apa.names$general, "remap.matrix")
remap.matrix <- function(x, map, func=NULL, delim=NULL, ids=c("rownames","column1"), keep.old=FALSE, return.unmapped=FALSE) {
    
    ## similar to aggregate()
    ## returns a new matrix/df with IDs converted from one set to another, and rows expanded/collapsed accordingly
    ## 'x' is a matrix/df with rownames/column-1 which are IDs
    ## 'ids' indicates if rownames have the IDs, or column 1.
    ## 'map' is a 2-col matrix/df with ID mappings; col 1 corresponds to rownames(x) and col 2 is some other ID set.
    ## - it is assumed that 'map' has many-to-many relationships, but it doesn't have to
    ## 'func' is the aggregating function, if needed: mean, sum, etc.  Just like with aggregate().
    ## 'delim': if 'func' is paste(), then specify the delimiter.
    ## RETURNS A MATRIX: data.frames are converted to matrices, with all the attendant upcasting of datatypes, be forewarned.
    ## if not 'func', then new IDs will be in column 1 of the output -- not as rownames, since not guaranteed to be unique without an aggregating 'func'.
    
    
    ## #### FUTURE: able to return matrix including old ID column, with rows showing complete many->many mappings
    
    
    ## Prep 'x'
    ids <- match.arg(ids)
    if (ids=="rownames") {
        xids <- rownames(x)
    } else if (ids=="column1") {
        xids <- x[,1]
        x <- x[,2:ncol(x),drop=FALSE]
    }
    xnames <- colnames(x)
    x <- nameless(as.matrix(x))
    
    ## remove incomplete mappings
    incomplete <- apply(is.na(map)|map=="",1,any)
    if (sum(incomplete)>0) {
        map <- map[!incomplete,]
        message(paste(sum(incomplete),"incomplete ID pairs removed"))
    }
    ## remove unmapped rows
    unmapped <- !(xids %in% map[,1])
    unmapped.ids <- sort(unique(xids[unmapped]))
    if (sum(unmapped)>0) {
        x <- x[!unmapped,,drop=FALSE]
        xids <- xids[!unmapped]
        message(paste(sum(unmapped),"unmappable rows removed"))
    }
    ## remove IDs not in dataset
    irrelevant <- !(map[,1] %in% xids)
    if (sum(irrelevant)>0) {
        map <- map[!irrelevant,]
        message(paste(sum(irrelevant),"irrelevant ID pairs removed"))
    }
    nrx <- nrow(x)
    ncx <- ncol(x)
    
    if (is.null(func)) {
        
        ## no aggregation function; output is complete many:many mapping
        
        message("Remapping ",length(unique(xids))," ids / ",nrx," rows")
        map2 <- split(map[,2], map[,1])  # new IDs, split by old IDs
        mapx <- split(1:nrx, xids)   # 'x' row numbers, split by old IDs
        M <- length(map2)
        x2 <- lapply(1:M, function(i) {
            report.index(i,10000,M)
            m2i <- map2[[i]]
            ##xi <- cbind("",x[xids==map[i,1],,drop=FALSE])  # 40 SEC PER 1000
            xi <- cbind("",x[mapx[[map[i,1]]],,drop=FALSE])  # 24000 IN 15 SEC !!!!!
            xix <- do.call(rbind, lapply(1:length(m2i), function(j) xi ))
            xix[,1] <- rep(m2i,each=nrow(xi))
            xix
        })
        y <- unique(do.call(rbind,x2))
        cny <- "New.ID"
        if (keep.old) {
            y <- y[,c(1,1:ncol(y))]
            cny <- c(cny,"Old.ID")
            y[,2] <- rep(names(map1),times=listLengths(map2))
        }
        colnames(y) <- c(cny,xnames)
        if (ids=="rownames") {
            rownames(y) <- y[,1]
            y <- y[,2:ncol(y)]
        }
        
    } else {
        
        ## have aggregation function
        
        ## ID mappings
        ## 'mapx' = one row per input row; only one TRUE value per row, in the column of the output mapping type
        ## colnames: o=one, m=many, first=input IDs, second=output IDs
        mapx <- matrix(FALSE, nrow(map), 4, FALSE, list(c(),c("o2o","o2m","m2o","m2m")))
        mapx[!duplicated2(map[,1]) & !duplicated2(map[,2]),"o2o"] <- TRUE  # 1:1 mappings
        many2many.1 <- duplicated2(map[,1]) & duplicated2(map[,2])
        many2many <- map[,1] %in% map[many2many.1,1] | map[,2] %in% map[many2many.1,2]
        mapx[many2many,"m2m"] <- TRUE    # M:M mappings
        mapx[!many2many & duplicated2(map[,1]) & !duplicated2(map[,2]),"o2m"] <- TRUE   # 1:M mappings  # the 'one' must be present in multiple copies, corresponding to the 'many'
        mapx[!many2many & !duplicated2(map[,1]) & duplicated2(map[,2]),"m2o"] <- TRUE   # M:1 mappings  # ditto, in the other direction
        if (nrow(map)!=sum(colSums(mapx))) stop("Mappings do not add up!")  ###### FIXME: need to improve this message...
        
        ## output matrix
        newids <- sort(unique(map[,2]))
        y <- matrix(NA, length(newids), ncx, FALSE, list(newids,c()))
        
        ## 1:1 mappings
        if (sum(mapx[,"o2o"])>0) {
            y[match(map[mapx[,"o2o"],2],rownames(y)),] <- x[match(map[mapx[,"o2o"],1],xids),,drop=FALSE]   # copy over 1:1 rows
        }
        ## Many:1 mappings
        if (sum(mapx[,"m2o"])>0) {
            if (length(delim)>0) {
                m2o <- aggregate(x[match(map[mapx[,"m2o"],1],xids),,drop=FALSE], list(map[mapx[,"m2o"],2]), func, collapse=delim)  # aggregate M:1 rows
            } else {
                m2o <- aggregate(x[match(map[mapx[,"m2o"],1],xids),,drop=FALSE], list(map[mapx[,"m2o"],2]), func)  # aggregate M:1 rows
            }
            y[match(m2o[,1],rownames(y)),] <- as.matrix(m2o[,2:(ncx+1)])      # add aggregated M:1 rows
        }
        ## 1:Many mappings
        if (sum(mapx[,"o2m"])>0) {
            o2m <- map[which(mapx[,"o2m"])[order(map[mapx[,"o2m"],1])],]   # o2m mappings
            y[match(o2m[,2],rownames(y)),] <- x[match(o2m[,1],xids),,drop=FALSE]  # add multiple copies of 1:M rows
        }
        ## Many:Many mappings
        if (sum(mapx[,"m2m"])>0) {
            if (length(delim)>0) {
                m2m <- aggregate(x[match(map[mapx[,"m2m"],1],xids),,drop=FALSE], list(map[mapx[,"m2m"],2]), func, collapse=delim)  # aggregate M:M rows
            } else {
                m2m <- aggregate(x[match(map[mapx[,"m2m"],1],xids),,drop=FALSE], list(map[mapx[,"m2m"],2]), func)  # aggregate M:M rows
            }
            y[match(m2m[,1],rownames(y)),] <- as.matrix(m2m[,2:(ncx+1)])  # add aggregated M:M rows
        }
        
        colnames(y) <- xnames
        if (keep.old) {
            oldids <- sapply(newids, function(x) paste(sort(map[map[,2]==x,1],collapse=";")))
            y <- data.frame(Old.ID=oldids, y)
        }
        if (ids=="rownames") {
            rownames(y) <- newids
        } else if (ids=="column1") {
            y <- data.frame(New.ID=newids, y)  # this way, new IDs are in column 1 regardless if keep.old or not.
        }
        
    }
    
    message(paste(nrow(y),"rows remaining"))
    if (return.unmapped) {
        list(y, unmapped.ids)
    } else {
        y
    }
}


apa.names$general <- c(apa.names$general, "aggregate2")
aggregate2 <- function(obj, by, func, na.rm=FALSE) {
    
    ## Like aggregate() but doesn't fail with large numbers
    
    NR <- length(obj)
    if (length(by)==0) {
        stop("'by' has length 0!\n")
    } else {
        for (i in 1:length(by)) {
            if (length(by[[i]]) != NR) stop("'by' element",i,"has length != length(obj)!\n")
        }
    }
    B <- length(by)
    if (length(names(by))==0) names(by) <- paste("Factor",1:B,sep="")
    by.mat <-  matrix(0, NR, B)
    for (i in 1:B) by.mat[,i] <- as.character(by[[i]])
    agg.grps <- apply(by.mat, 1, paste, collapse="-")
    ugrps <- sort(unique(agg.grps))
    NG <- length(ugrps)
    output <- rep(0,NG)
    for (i in 1:NG) output[i] <- func(as.numeric(obj[which(agg.grps==ugrps[i])]), na.rm=na.rm)
    nameless(data.frame(ugrps,output))
}


apa.names$general <- c(apa.names$general, "aggregate.cols")
aggregate.cols <- function(obj, by, func, na.rm=FALSE) {
    
    ## Like aggregate() but works on columns not rows
    
    if (class(obj)=="data.frame") obj <- as.matrix(obj)
    mode(obj) <- "numeric"  # avoid integer overflows
    fname <- deparse(substitute(func))
    NC <- ncol(obj)
    if (length(by)==0) {
        stop("'by' has length 0!\n")
    } else {
        for (i in 1:length(by)) {
            if (length(by[[i]]) != NC) stop("'by' element",i,"has length != ncol(obj)!\n")
        }
    }
    B <- length(by)
    if (length(names(by))==0) names(by) <- paste("Factor",1:B,sep="")
    by.mat <-  matrix(0, B, NC)
    for (i in 1:B) by.mat[i,] <- as.character(by[[i]])
    agg.grps <- apply(by.mat, 2, paste, collapse="-")
    ugrps <- unique(agg.grps)
    NG <- length(ugrps)
    output <- matrix(NA, nrow(obj), NG, F, list(rownames(obj),ugrps))
    for (i in 1:NG) {
        x <- which(agg.grps==ugrps[i])
        if (length(x)>1) {
            output[,i] <- switch(
                fname,
                "mean"=rowMeans(obj[,x], na.rm=na.rm),
                "median"=rowMedians(obj[,x], na.rm=na.rm),
                "min"=rowMin(obj[,x], na.rm=na.rm),
                "max"=rowMax(obj[,x], na.rm=na.rm),
                "sd"=rowSDs(obj[,x], na.rm=na.rm),
                "CV"=rowCVs(obj[,x], na.rm=na.rm),
                apply(obj[,x], 1, func, na.rm=na.rm)
            )
        } else {
            output[,i] <- obj[,x]
        }
    }
    output
}


apa.names$general <- c(apa.names$general, "as.fasta")
as.fasta <- function(x, vectors=FALSE, upper=TRUE, comments=c("#")) {
    
    ## converts the contents of a fasta file, as a character vector output from 'scan', broken on newlines, into "fasta" format.
    ##  - "fasta" format is a named character vector, names = fasta headers, values = single strings representing newline-free sequence.
    ## 'vectors' controls whether the sequence is recorded as a vector of separate characters (TRUE) 
    ##   or a length-1 vector with the whole sequence (FALSE)
    ## 'comments' is a vector of characters which, if found at line starts, cause those lines to be skipped
    
    x <- gsub("\r","",x)   # in case windows newlines
    comm <- c()
    if (length(comments)>0) for (i in 1:length(comments)) comm <- c(comm, grep(paste0("^",comments[i]), x))
    if (length(comm) > 0) x <- x[-comm]
    y <- rep(0, length(x))
    heads <- grep("^>", x)
    y[heads] <- 1:length(heads)
    noseq <- which(diff(heads)==1)
    blocks <- find.runs(y)
    B <- length(blocks)
    if (length(blocks[[B]])==0) blocks <- blocks[1:(B-1)]  # sometimes gets null last element
    blocks <- do.call(rbind, blocks)
    if (length(noseq)>0) {
        noseq.y <- which(y %in% noseq)
        noseq.b <- which(blocks[,1] %in% noseq.y)
        for (b in rev(noseq.b)) {  # MUST OPERATE BACKWARDS to preserve positions in noseq.b
            blocks <- blocks[c(1:b,b:nrow(blocks)),]
            blocks[b+1,] <- c(0,0)  # there is no sequence, so not 'x' positions
            rownames(blocks)[b+1] <- 0  # but we pretend there is, so 'fasta' will get an empty element here
        }
    }
    z <- which(rownames(blocks) == 0)
#    return(list(blocks,z))
    fasta <- apply(blocks[z,], 1, function(i) paste(x[i[1]:i[2]],collapse="") )
    if (vectors) fasta <- strsplit(fasta,"")
    names(fasta) <- sub("^>","",x[heads])
    if (upper) fasta <- toupper(fasta)
    return(fasta)
}


apa.names$general <- c(apa.names$general, "read.fasta")
read.fasta <- function(file, vectors=FALSE, upper=TRUE, comments="#") {
    
    ## *Actually* reads a fasta file into a named vector format, unlike ape's read.dna() which only claims to.
    ## arguments are passed to 'as.fasta' as-is.
    
    if (grepl("\\.gz$",file)) {
        gzf <- gzfile(file, open="R")
        x <- as.fasta(scan(gzf, what="", sep="\n"), vectors=vectors, upper=upper, comments=comments)
        close(gzf)
    } else {
        x <- as.fasta(scan(file, what="", sep="\n"), vectors=vectors, upper=upper, comments=comments)
    }
    x
}


apa.names$general <- c(apa.names$general, "write.fasta")
write.fasta <- function(vec, filename, names=NULL, linewidth=50, na.rm=FALSE) {
    
    ## Writes a fasta in named-vector format (e.g. from read.fasta() above) to file
    ## 'filename' is the file name to write to: if ends in '.gz', writes to compressed file
    ## 'names', if not null, will become fasta headers, regardless of 'vec' names
    ## 'linewidth' sets # characters per line
    ## 'na.rm', if TRUE, will omit any NA, length-0, or otherwise empty sequences
    
    vec[listLengths(vec)==0] <- ""  # convert NULL entries to prevent sapplies below from complaining
    empty <- is.na(vec) | nchar(vec)==0 | !grepl("[[:alpha:]]",vec) | grepl("^Sequence ?U",vec,ignore.case=TRUE)  # last one targets "Sequence Unavailable"
    if (na.rm) { vec <- vec[!empty] }
    
    if (is.null(names(vec))) { 
        if (is.null(names)) {
            headers <- paste(">", 1:length(vec), sep="")   # generic names: "1"-"N"
        } else {
            headers <- paste(">", names, sep="")
        }
    } else if (is.null(names)) {
        headers <- paste(">", names(vec), sep="")
    } else {
        headers <- paste(">", names, sep="")
    }
    
    blockify <- function(x, w) {
        N <- nchar(x)
        if (N > w) {
            chars <- unlist(strsplit(x,''))
            cmax <- w*trunc(N/w)
            lines <- apply(matrix(chars[1:cmax], ncol=w, byrow=TRUE), 1, paste, collapse="")
            if (cmax < N) {
                last <- paste(chars[(cmax+1):N], collapse="")
                return(c("",lines,last))
            } else {
                return(c("",lines))
            }
        } else {
            return(c("",x))
        }
    }
    
    blocks <- lapply(vec, blockify, linewidth)
    for (i in 1:length(blocks)) {
    	blocks[[i]][1] <- headers[i]  # first slot in each block is left open for header
    }
    
    if (grepl("\\.gz$",filename)) {
        gzf <- gzfile(filename, open="W")
        write.table(unlist(blocks), gzf, sep="\n", quote=FALSE, row.names=FALSE, col.names=FALSE)
        close(gzf)
    } else {
        write.table(unlist(blocks), filename, sep="\n", quote=FALSE, row.names=FALSE, col.names=FALSE)
    }
}


apa.names$general <- c(apa.names$general, "read.fastq")
read.fastq <- function(file) {
    
    ## reads in a fastq file into a 3-col matrix: header, seq, qual
    
    x <- scan(file, what="", sep="\n")
    headers1 <- seq(1, length(x)-3, 4)
    sequence <- seq(2, length(x)-2, 4)
#    headers2 <- seq(3, length(x)-1, 4)
    quality <- seq(4, length(x), 4)
    return(matrix(c(sub("^@","",x[headers1]),x[sequence],x[quality]), ncol=3))
}


apa.names$general <- c(apa.names$general, "write.fastq")
write.fastq <- function(fq.mat, filename) {
    
    ## writes a 3-col matrix (e.g. from read.fastq()) to file
    ## if 'filename' ends in '.gz', writes to compressed file
    
    header.at <- grepl("^@",fq.mat[1,1])  # do headers appear to have "@" prefixes already?
    if (!header.at) fq.mat[,1] <- paste0("@",fq.mat[,1])  # add if not
    
    if (FALSE) {
        vec <- rep("", nrow(fq.mat)*4)
        headers <- seq(1, length(vec)-3, 4)
        sequence <- seq(2, length(vec)-2, 4)
        headers2 <- seq(3, length(vec)-1, 4)
        quality <- seq(4, length(vec), 4)
        
        vec[headers] <- fq.mat[,1]
        vec[sequence] <- fq.mat[,2]
        vec[headers2] <- "+"
        vec[quality] <- fq.mat[,3]
    }
    
    fq.mat <- fq.mat[,c(1:3,3)]
    fq.mat[,3] <- "+"
    
    if (grepl("\\.gz$",filename)) {
        gzf <- gzfile(filename, open="W")
        write.table(c(t(fq.mat)), gzf, sep="\n", quote=FALSE, row.names=FALSE, col.names=FALSE)
        close(gzf)
    } else {
        write.table(c(t(fq.mat)), filename, sep="\n", quote=FALSE, row.names=FALSE, col.names=FALSE)
    }
}


apa.names$general <- c(apa.names$general, "read.sff.quals")
read.sff.quals <- function(file) {
    
    ## Reads an sff quality "fasta" file into a list of quality-score vectors
    
    x <- sub("\r","",scan(file, what="", sep="\n"))  # in case windows newlines
    y <- rep(0, length(x))
    heads <- grep("^>", x)
    y[heads] <- 1:length(heads)
    blocks <- find.runs(y)
    z <- which(names(blocks) == 0)
    fasta <- sapply(blocks[z], FUN=function(i){ as.numeric(unlist(strsplit(paste(x[i[1]:i[2]], collapse=" ")," "))) })
    names(fasta) <- sub("^>","",x[heads])
    return(fasta)    
}


apa.names$general <- c(apa.names$general, "qual2int")
qual2int <- function(qual, encoding=c("Sanger","Illumina-1.3","Illumina-1.0")) {
	
	## converts quality ASCII strings into integer vectors
	## ascii.lookup <- as.matrix(sfsmisc:::chars8bit(1:255))
	
	encoding <- match.arg(encoding)
    encdat <- switch(encoding, `Sanger`=c(33,126,0,93), `Illumina-1.3`=c(64,126,0,62), `Illumina-1.0`=c(59,126,-5,62))  # ascii min, ascii max, score min, score max
	
	to.int <- function(x) {
		y <- unlist(strsplit(x,""))
		z <- match(y, ascii.lookup[,1])-encdat[1]
		if (any(z<encdat[3])) warning("Some qualities are below the minimum quality",encdat[3],"!")
		if (any(z>encdat[4])) warning("Some qualities exceed the maximum quality",encdat[4],"!")
		return(z)
	}
	
	if (length(qual)==1) {
		scores <- to.int(qual)
	} else {
		scores <- lapply(qual, to.int)
	}
	return(scores)
}
	


apa.names$general <- c(apa.names$general, "read.gmt")
read.gmt <- function(file) { 
	
	## reads a GMT (Gene Matrix Transposed) format file (e.g. exported GSEA gene sets from Broad's MSigDB)
	
	x <- scan(file, what="", sep="\n")
	com <- grep("^#",x)
	if (length(com)>0) x <- x[-com]  # don't do this with length-0 index vectors: deletes all data
	y <- lapply(x, function(i){unlist(strsplit(i,"\t"))})
	name <- sapply(y, function(i){i[1]})
	desc <- sub("> ","",sapply(y, function(i){i[2]}))
	genes <- lapply(y, function(i){i[3:length(i)]})
	return(list(name=name,desc=desc,genes=genes))
}
	


apa.names$general <- c(apa.names$general, "write.gmt")
write.gmt <- function(x, filename) { 
	
	## writes a GMT (Gene Matrix Transposed) format file
	## requires an object with same format as read.gmt() output
	
	subs <- !grepl("^> ",x$desc)
	x$desc[subs] <- paste("> ", x$desc[subs])
	y <- sapply(1:length(x), function(i){paste(x$name[i], x$desc[i], x$genes[[i]], sep="\t")})
	write.vector(y, filename)
}


apa.names$general <- c(apa.names$general, "read.psl")
read.psl <- function(file, header=TRUE) {

    ## Assumes standard 5-row PSL header
    
    if (header) {
        x <- read.delim(file, as.is=TRUE, header=FALSE, skip=5)
        h <- read.delim(file, as.is=TRUE, header=FALSE, skip=2)[1:2,]
        colnames(x) <- gsub(" ","",apply(h,2,paste,collapse=""))
        x
    } else {
        read.delim(file, as.is=TRUE, header=FALSE)
    }
}


apa.names$general <- c(apa.names$general, "write.psl")
write.psl <- function(x, file, blockSizes=NULL, qStarts=NULL, tStarts=NULL, custom.header=FALSE) {
    
    ## 'x' is a dataframe with PSL data; may have extra columns (i.e. cols 22-N)
    ## blockSizes, qStart, tStarts are optional lists-of-vectors which will be properly formatted and added/replaced to 'x'
    
    numerics <- c(1:8,11:13,15:18)
    for (n in numerics) x[[n]] <- gsub(" ","",format(x[[n]],scientific=FALSE))
    
    if (length(blockSizes)>0) x[[19]] <- sapply(blockSizes, function(z) paste0(paste(gsub(" ","",format(z,scientific=FALSE)),collapse=","),",") )
    if (length(qStarts)>0) x[[20]] <- sapply(qStarts, function(z) paste0(paste(gsub(" ","",format(z,scientific=FALSE)),collapse=","),",") )
    if (length(tStarts)>0) x[[21]] <- sapply(tStarts, function(z) paste0(paste(gsub(" ","",format(z,scientific=FALSE)),collapse=","),",") )
    
    header <- c("psLayout version 3","")
    if (custom.header) {
        ## row 3 = custom colnames; row 4 = blank
        header <- c(header, paste(colnames(x),collapse="\t"), "")
    } else {
        ## rows 3 and 4 as usual
        header <-
            c(
                header,
                "match\tmis- \trep. \tN's\tQ gap\tQ gap\tT gap\tT gap\tstrand\tQ        \tQ   \tQ    \tQ  \tT        \tT   \tT    \tT  \tblock\tblockSizes \tqStarts\t tStarts",
                "     \tmatch\tmatch\t   \tcount\tbases\tcount\tbases\t      \tname     \tsize\tstart\tend\tname     \tsize\tstart\tend\tcount"
            )
    }
    header <-
        c(
            header,
            "---------------------------------------------------------------------------------------------------------------------------------------------------------------"
        )

    y <- c(header, apply(x, 1, paste, collapse="\t"))
    write.vector(
        y,
        file
    )
    invisible(x)
}


apa.names$general <- c(apa.names$general, "detable")
detable <- function(obj, interpolate=FALSE) { 
	
	## Reverses 'table' function, i.e. takes a table object or equivalent matrix (see below) and reverts it to the original vector
	## 'interpolate=T' not yet ready : checks for and corrects 
	## INPUT CAN BE: 
	## 1. The output of a 'table' call or something equivalent (named numeric vector),
	## 2. 1-col matrix/df: col 1 = values; rownames = names
	## 3. 2-col matrix/df: col 1 = names; col 2 = values
	
	if (is(obj, "table")) obj <- as.matrix(obj)	# convert real table() output to matrix
	
	if (is.nlv(obj)) {
		
		temp <- vector("list", length=length(obj))
		for (i in 1:length(temp)) temp[[i]] <- rep(names(obj)[i], obj[i])
		output <- unlist(temp)
		
		if (interpolate) {
			x <- sort(as.numeric(names(obj)))
			y <- x[1]:x[length(x)]
			extra <- length(y) > length(x)
			if (extra > 0) output <- c(output, y[which(!y %in% x)])	# gaps in x
		}
		
	} else {	# df or matrix, hopefully
		
		if (ncol(obj) == 1) {
			if (is.null(rownames(obj))) stop("1-column object must have rownames!\n")
			labels <- rownames(obj)
			data <- obj
		} else if (ncol(obj) == 2) {
			labels <- obj[,1]
			data <- obj[,2]
		} else {
			stop("Cannot take objects with > 2 columns!\n")
		}
		
		temp <- vector("list", length=nrow(obj))
		for (i in 1:length(temp)) temp[[i]] <- rep(labels[i], data[i])
		output <- unlist(temp)
		
#		if (interpolate) {
#			x <- sort(as.numeric(labels))
#			y <- x[1]:x[length(x)]
#			extra <- length(y) > length(x)
#			if (extra > 0) output <- c(output, y[which(!(y %in% x))])	# gaps in x
#		}
	}
	
	return(output)
}


apa.names$general <- c(apa.names$general, "merge.table.list")
merge.table.list <- function(tables, sort=FALSE, expand=FALSE) { 
    
    ## merge.table.list takes a list made of outputs of the table() function, and merges them into master table.
    ## each element in the 'tables' is the output of a single table() call.
    ## names(tables) become the rownames; colnames are taken from the union of all table names (each element of 'tables').
    ## if tabulated data is numeric or (single-char) alphabetical, 'expand=T' will ensure one column for each possible value within the observed range
    
    if (!is.list(tables)) stop("Input must be a list!\n")
    
    T <- length(tables)
    table.types <- table.nrows <- new.vector(names(tables))
    table.rownames <- table.colnames <- new.list(names(tables))
    for (i in 1:T) {
        if (length(tables[[i]])==0) {
            table.nrows[i] <- 0
        } else if (class(tables[[i]]) %in% c("matrix","data.frame")) {
            table.types[i] <- "matrix"
            table.nrows[i] <- nrow(tables[[i]])
            table.rownames[[i]] <- paste0(names(tables)[i],".",rownames(tables[[i]]))
            table.colnames[[i]] <- colnames(tables[[i]])
        } else {  # assuming table or named vector
            table.types[i] <- "vector"
            table.nrows[i] <- 1
            table.rownames[[i]] <- names(tables)[i]
            table.colnames[[i]] <- names(tables[[i]])
        }
    }
    columns <- unique(unlist(table.colnames))
    if (sort) columns <- sort(columns)
    
    if (length(columns)==0) {
        warning("Failed to get names for frequencies!\n")
        return(c())
    } else {
        master <- matrix(data=0, nrow=sum(table.nrows), ncol=length(columns), F, list(unlist(table.rownames),columns))
        
        k <- 0
        for (i in 1:T) {
            if (table.nrows[i]>0) {
                cols <- match(table.colnames[[i]], colnames(master))
                if (table.types[i]=="matrix") {
                    master[(k+1):(k+table.nrows[i]),cols] <- as.matrix(tables[[i]])
                } else {
                    master[(k+1):(k+table.nrows[i]),cols] <- as.vector(tables[[i]])
                }
                k <- k + table.nrows[i]
            }
        }
        
        if (sum(is.na(suppressWarnings(as.numeric(colnames(master)))))==0) {
            ## 'master' has numeric colnames, apparently
            master <- master[,order(as.numeric(colnames(master))),drop=FALSE]
            if (expand) {
                ancm <- as.numeric(colnames(master))
                col.range <- min(ancm):max(ancm)
                master <- master[,match(col.range,ancm),drop=FALSE]
                colnames(master) <- col.range
            }
        } else if (expand) {
            ## non-numeric column expansion
            if (all(colnames(master) %in% LETTERS)) {
                cml <- LETTERS[min(match(colnames(master),LETTERS)):max(match(colnames(master),LETTERS))]
                master <- master[,match(cml,colnames(master)),drop=FALSE]
                colnames(master) <- cml
            } else if (all(colnames(master) %in% letters)) {
                cml <- letters[min(match(colnames(master),letters)):max(match(colnames(master),letters))]
                master <- master[,match(cml,colnames(master)),drop=FALSE]
                colnames(master) <- cml
            }
        }
        
        master[is.na(master)] <- 0
        return(master)
    }
}


apa.names$general <- c(apa.names$general, "table2histo")
table2histo <- function(x, expand=FALSE) { 
    
    ## converts a vector (or table of a vector) into a 2-col histogram object (matrix if 'x' is numeric; data.frame if otherwise)
    ## 'expand' only meaningful if 'x' is numeric or (single-letter) alphabetical: 
    ##   'expand=T' ensures that all values from min(x) to max(x) get a row in the output matrix; 'expand=F' only returns rows for existing values
    
    num <- is(x,"numeric")
    if (!is(x,"table")) x <- table(x)
    
    if (num) {
        h <- cbind(Value=as.numeric(names(x)), Times=x)
    } else {
        h <- data.frame(Value=names(x), Times=x)
    }
    
    if (expand) {
        if (num) {
            h1range <- min(h[,1]):max(h[,1])
            h <- h[match(h1range,h[,1]),]
            h[,1] <- h1range
            h[is.na(h[,2]),2] <- 0
        } else if (all(x %in% LETTERS)) {
            h1range <- LETTERS[min(match(x,LETTERS)):max(match(x,LETTERS))]
            h <- h[match(h1range,h[,1]),]
            h[,1] <- h1range
            h[is.na(h[,2]),2] <- 0
        } else if (all(x %in% letters)) {
            h1range <- letters[min(match(x,letters)):max(match(x,letters))]
            h <- h[match(h1range,h[,1]),]
            h[,1] <- h1range
            h[is.na(h[,2]),2] <- 0
        }
    }
    rownames(h) <- NULL
    h
}


apa.names$general <- c(apa.names$general, "tally.combinations")
tally.combinations <- function(mat, delim="+", sort.names=FALSE, allcombo=FALSE, subcombo=FALSE) { 
	
	## example usage:
	## input a binary matrix where rows are peaks and columns are motifs; cells are 1/0 (or T/F) for motif presence
	## returns a table of all motif combinations per peak and how many peaks had each combo
	## 'delim' specifies the delimiter to use when concatenating motif names into combo names
	## "sort.names=T" will sort columns or 'mat' so they are in alphabetical order, so that motif names in combos will also be in alphabetical order
	## "allcombo=T" means that all possible motif combinations are enumerated, whether or not any peaks with that combo ocurred
	## "subcombo=T" will assign each peak to all possible combinations of motifs found in that peak:
	##   For instance, peak X has motifs A, B, C.  subcombo=F adds 1 to "A+B+C".  subcombo=T adds 1 to "A", "B", "C", "A+B", "A+C", "B+C", and "A+B+C"
	## If subcombo=T and allcombo=F: all combos in all peaks will be discovered as though subcombo=F; during tallying, only already-discovered subcombos will get counts:
	##   For instance, peak X is as above, and peak Y has only A, B.  Peak X will then count to "A+B+C" and also "A+B", since "A+B" is known from peak Y.
	## If subcombo=F and allcombo=T: all possible combos will be represented, but each peaks only counts once, e.g. peak X only counts to "A+B+C"
	
	if (is.data.frame(mat)) mat <- as.matrix(mat)
	if (!is.matrix(mat)) stop("'mat' must be a matrix!\n")
	if (mode(mat)=="numeric") mode(mat) <- "logical"
	
	N <- ncol(mat)
	motif.names <- colnames(mat)
	if (N==0) stop("'mat' must have column names!\n")
	
	if (sort.names) mat <- mat[,order(colnames(mat))]
	
	umat <- unique(mat)
	mat.index <- rowSums(t( t(mat)*2^(0:(N-1)) ))   # binary index values per OBSERVED combination
	unq.index <- rowSums(t( t(umat)*2^(0:(N-1)) ))  # unique combo indexes
	unq.names <- apply(umat, 1, function(x){ paste(motif.names[as.logical(x)],collapse=delim) })  # unique combo names
	
	if (allcombo | subcombo) {
		IM("Generating combinations...")
		combo.PA <- permn2(0:1, N, replacement=TRUE)
		combo.index <- rowSums(t( t(combo.PA)*2^(0:(N-1)) ))  # binary index values per POSSIBLE combination
		combo.names <- apply(combo.PA, 1, function(x){ paste(motif.names[as.logical(x)],collapse=delim) })  # names per POSSIBLE combination
	} else {
		combo.index <- unq.index
		combo.names <- unq.names
	}
	combo.tally <- rep(0, length(combo.index))
	
	if (subcombo) {
		IM("Sub-indexing...")
		sub.index <- apply(mat, 1, function(x){ unique(rowSums(t( t(permn2(0:1,sum(x),replace=TRUE))*2^c(0:(N-1))[x] ))) })  # all possible subcombos per row // unique() due to bug in permn2
		for (i in 1:length(sub.index)) {
			w <- match(sub.index[[i]],combo.index)
			combo.tally[w] <- combo.tally[w] + 1
		}
		IM("Filtering...")
		if (!allcombo) {
			w <- match(unq.index,combo.index)
			combo.tally <- combo.tally[w]  # filter out novel subcombos
			combo.names <- combo.names[w]
		}
	} else {
		mat.tally <- table(mat.index)
		combo.tally[match(names(mat.tally),combo.index)] <- mat.tally
	}
	
	rownameless(data.frame(COMBO=combo.names,N=combo.tally,stringsAsFactors=FALSE))
}


apa.names$general <- c(apa.names$general, "listFilter")
listFilter <- function(list, regexp, keep=TRUE, fixed, noempty=FALSE) { 
	
	## Filters a list of atomics or vectors for anything matching a regular expression (or vector of regular expressions)
	## "regexp" is a single reg exp, or a vector of them.
	## "keep" indicates what to do with matched elements, a la grep's "invert" parameter:
	## keep = T: retains ONLY matches (default)
	## keep = F: removes matches; retains non-matches
	## "fixed" is a logical or vector of logicals, length=length(regexp), which toggles the grep "fixed" parameter for each regexp
	## "noempty" switch, if TRUE, will block removal of subelements ONLY if they are ALL flagged for removal.
	
	if (length(regexp) == 0) stop("Mandatory parameter 'regexp' must contain a regular expression!\n")
	if (length(fixed) == 0) stop("Mandatory parameter 'fixed' must contain one or more logicals!\n")
	
	filterfunc <- function(elem, expressions, fixed, keep) {
		
		# each expression gets its own element of 'matches'.  Each element contains match the indices for subelement(s) of "elem".
		# 'hits' contains all subelements that matched anything.
		
		idx <- 1:length(expressions)
		if (length(fixed == 1)) fixed <- rep(fixed, length(idx))
		
		matches <- lapply(idx, FUN=function(i,x,exp,fix){ grep(exp[i],x,fixed=fix[i]) }, elem, expressions, fixed )
		hits <- unique(unlist(matches))
		if (length(hits) == 0) {
			if (keep == T) {
				ternary ( noempty == T, results <- elem, results <- NA )
			} else {
				results <- elem
			}
		} else {
			if (keep == T) {
				results <- elem[hits]
			} else {
				ternary ( noempty == T & length(hits) == length(elem), results <- elem, results <- elem[-hits] )
			}
		}
		return(results)
	}
	
	v <- lapply(list, FUN=filterfunc, regexp, fixed, keep)
	return(v)
}


apa.names$general <- c(apa.names$general, "listMerge")
listMerge <- function(list1, list2, mode="union", na.rm=TRUE, sorting=FALSE) {
	
	## Returns a single named list which is produced from two NAMED lists.  Lists may contain ONLY vectors and atoms.
	##  List elements with the same name are operated on to produce the output element.  Operation is specified with 'mode'.
	## 'na.rm' = NA exclusion
	## 'sorting' = apply alphabetical sorting to each vector in the output list?
	## 'mode' determines the set operation to use:
	## Modes returning sets/subsets:
	## Mode = "union": nonredundant union (proper union).
	## Mode = "total": redundant union (concatenation).
	## Mode = "intersect": intersection (also nonredundant).
	## Mode = "disjunc": disjunction (union - intersection)
	## Mode = "setdiff": set diff as list1 - list2.
	## Modes returning logicals (T/F):
	## Mode = "equal": is list1 == list2 ? (redundancy ignored)
	## Mode = "requal": is list1 == list2 ? (redundancy NOT ignored)
	## Mode = "any": is intersect(list1,list2) nonzero ?
	## Mode = "subset": is list2 a proper subset of list1 ?
	
	nametest <- function(listX) { 
		x <- c(length(listX[[1]])>0, length(listX[[2]])>0)
		return( c(x, sum(x)) ) 
	}
	cleanup <- function(vecX, na.rm, sorting) {
		if (is.null(vecX) == T) { 
			return(vecX) 
		} else {
			vecY <- c()
			ternary (na.rm == TRUE, vecY <- vecX[which(!is.na(vecX))], vecY <- vecX)
			if (length(vecY) == 0) {
				return(c())
			} else {
				if (sorting == TRUE) { vecY <- sort(vecY, na.last=TRUE) }
			}
			return(vecY)
		}
	}
	
	names1 <- names(list1)
	names2 <- names(list2)
	y <- nametest(c(names1, names2))
	if (y[3] == 2) {	# both have names; intended situation
		# pass
	} else if (y[3] == 0) {	# neither have names; use indices instead (cheap/risky... but you should have named the lists!)
		names(list1) <- names1 <- 1:length(list1)
		names(list2) <- names2 <- 1:length(list2)
	} else {		# only one has names: can't connect any element of list 1 to list 2
		stop( "Only one list has names: cannot continue!" )	# die
	}
	names3 <- union(names1, names2)
	
	if (mode == "union") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) { 
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- union( list1[[name]], list2[[name]] )
			} else {
				z <- x[[which(y == 1)[1]]]	# if only one usable element, just return it
			}
			w <- cleanup(z, na.rm, sorting); return(w)
		}
		
	} else if (mode == "total") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- c( list1[[name]], list2[[name]] )
			} else {
				z <- x[[which(y == 1)[1]]]	# if only one usable element, just return it
			}
			w <- cleanup(z, na.rm, sorting); return(w)
		}
		
	} else if (mode == "intersect") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- intersect( list1[[name]], list2[[name]] )
			}
			w <- cleanup(z, na.rm, sorting); return(w)
		}
		
	} else if (mode == "disjunc") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- union( list1[[name]], list2[[name]] )[ -intersect( list1[[name]], list2[[name]] ) ]
			} else {
				z <- x[[which(y == 1)[1]]]	# if only one usable element, just return it
			}
			w <- cleanup(z, na.rm, sorting); return(w)
		}
		
	} else if (mode == "setdiff") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list(L1=list1[[name]], L2=list2[[name]])
			y <- nametest(x)
			if (y[3] == 2) {
				z <- setdiff( list1[[name]], list2[[name]] )
			} else if (y[1] == 1) {
				z <- list1[[name]]		# if list1 had the only one usable element, just return it
			} else {
				z <- c()			# if list2 had the only one usable element, return nothing
			}
			w <- cleanup(z, na.rm, sorting); return(w)
		}
		
	} else if (mode == "equal") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- setequal( list1[[name]], list2[[name]] )
			}
			return(z)
		}
		
	} else if (mode == "requal") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- setequal( list1[[name]], list2[[name]] )
			}
			if (z == TRUE) {
				ternary ( length(list1[[name]]) == length(list2[[name]]), return(TRUE), return(FALSE) )
			} else {
				return(z)
			}
		}
		
	} else if (mode == "any") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- intersect( list1[[name]], list2[[name]] )
			}
			if (is.null(z)) {
				return(z)
			} else {
				ternary (length(z) == 0, return(FALSE), return(TRUE))
			}
		}
		
	} else if (mode == "subset") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- setdiff( list2[[name]], list1[[name]] )
			}
			if (is.null(z)) {
				return(z)
			} else {
				ternary (length(z) == 0, return(TRUE), return(FALSE))
			}
		}
		
	} else {
		
		stop( paste("Unknown mode value '",mode,"'!  Nothing to do.",sep="") )
		
	}
	
	list3 <- lapply(names3, FUN=FUNC, list1, list2, na.rm, sorting)
	names(list3) <- names3
	return(list3)
}


apa.names$general <- c(apa.names$general, "list.concatenate")
list.concatenate <- function(list1, names.delim=".") { 
	
	## concatenates a list of lists into a single-level list
	## The list, and all sub-lists, MUST HAVE NAMES
	
	list2 <- new.list(paste(rep(names(list1),times=listLengths(list1)),unlist(lapply(list1,names)),sep=names.delim))
	k <- 0
	for (i in 1:length(list1)) {
		for (j in 1:length(list1[[i]])) {
			k <- k + 1
			list2[[k]] <- list1[[i]][[j]]
		}
	}
	list2
}


apa.names$general <- c(apa.names$general, "invert.list", "list.invert")
list.invert <- invert.list <- function(list1, null.rm=TRUE, by.names=TRUE) { 
	
	## NOT FULLY TESTED
	
	## Inverts either a list of vectors, or a list of lists of vectors.  The list must have names.
	## 
	## If 'by.names' is TRUE:
	##  The second level of the list must also have names.
	##  Inverted list will have one element for each unique sub-lists/vector name found in the original list.
	##  Example:
	##   list( X=list(A=c(1,2), B=2, C=3), Y=list(A=4, B=5, C=6), Z=list(A=7, B=8, D=0) )
	##  Inverts to:
	##   list( A=list(X=c(1,2), Y=4, Z=7), B=list(X=2, Y=5, Z=8), C=list(X=3, Y=6), D=list(Z=0) )
	## 
	## IF 'by.names' is FALSE:
	##  The second level of the list does not need names; they will be ignored anyway.
	##  The values of the second level will become new list names, while the names of the first level will become the new list values.
	##  Example:
	##   list( X=c(1,2,3), Y=5, Z=c(1,2,4) )
	##  Inverts to:
	##   list( `1`=c("X","Z"), `2`=c("X","Z"), `3`="X", `4`="Z", `5`="Y" )
	## 
	## "null.rm" controls removal of NULL elements in the inverted list.
	## 
    
    vectors <- is.atomic(list1[[1]])
    names1 <- names(list1)
    
    if (by.names) {
        names2 <- sort(unique(unlist(lapply(list1, names))))  # names from sub-lists/vectors
        if (vectors) {
            list2 <- list2names <- new.list(names2)
            for (i in 1:length(list1)) {
                if (length(list1[[i]])==0) next
                for (j in 1:length(list1[[i]])) {
                    jname <- names(list1[[i]])[j]
                    k <- match(jname, names2)
                    list2[[k]] <- c(list2[[k]], list1[[i]][j])
                    list2names[[k]] <- c(list2names[[k]], jname)
                }
            }
            for (i in 1:length(list2)) names(list2[[i]]) <- list2names[[i]]
        } else {
            list2 <- new.list(names2, elem=new.list(names1))
            for (i in 1:length(list1)) {
                if (length(list1[[i]])==0) next
                for (j in 1:length(list1[[i]])) {
                    if (length(list1[[i]][[j]])==0) next
                    k <- match(names(list1[[i]])[j], names2)
                    list2[[k]][[i]] <- c(list2[[k]][[i]], list1[[i]][[j]])
                }
            }
        }
    } else {
        if (!vectors) list1 <- lapply(list1, function(x) unique(unlist(x)) )  # since names are ignored, just dump each sub-list into a vector
        names2 <- sort(unique(unlist(list1)))
        list2 <- new.list(names2)
        for (i in 1:length(list1)) {
            if (length(list1[[i]])>0) {
                m <- match(list1[[i]], names2)
                for (j in m[!is.na(m)]) list2[[j]] <- c(list2[[j]], names(list1)[i])
            }
        }
        list2 <- lapply(list2, function(x) sort(unique(x)) )
    }
    return(list2)
}


apa.names$general <- c(apa.names$general, "breakout")
breakout <- function(object, reverse=FALSE, unique=NULL) { 
    
    ## Using reverse=F converts a matrix to a list:
    ##   Takes 2-column matrices or data frames ONLY.  Requires object[,1] be a grouping vector and object[,2] be the data points.
    ##   Returns a list with one vector for each grouping value; vector contains the data points associated with that grouping value.
    ## Using "reverse=T" reverses the above process, making a list into a 2-column matrix.  Takes lists of vectors ONLY.
    ## Using "unique" provides duplicate entry control:
    ##  "unique=local": removes duplicate entries within groups (reduced to one instance each).
    ##  "unique=global": removes ALL ENTRIES which are present > 1 times, regardless of group (no instances remain).  
    ##   - If single instances of each entry were retained, they would be arbitrarily assigned to only one group, which is probably not what you wanted.
    ##  "unique=NULL": leaves object as-is.
    
    if (is.null(unique)) { 
        unique <- ""   # testable but empty value
    } else {
        match.arg(unique, c('local','global')) 
    }
    if (!is.logical(reverse)) { stop("'reverse' must be TRUE or FALSE!\n") }
    if (is.null(names(object))) { names(object) <- 1:length(object) }
    
    if (!reverse) {	# matrix -> list
        
        if (!is.matrix(object) & !is.data.frame(object)) { stop("Error: object must be a matrix or data frame!\n") }
        if (unique == "local") { object <- unique(object) }
        if (unique == "global") { 
            x <- unique(object[duplicated(object[,2]),2])
            y <- object[,2] %in% x
            object <- object[!y,]
        }
        
        if (is.null(dim(object)) == T) { stop("Error: object must be a matrix!\n") }
        if (ncol(object) != 2) { stop("Error: matrix must have only 2 columns!\n") }
        
        func <- function (val, mat) {
            iv <- which(mat[,1] == val)
            return ( mat[iv,2] )
        }
        
        u <- sort(unique(object[,1]))
        out <- lapply(u, func, object)
        names(out) <- u
        
    } else if (reverse) {	# list -> matrix
        
        if (!is.list(object)) { stop("Error: object must be a list!\n") }
        if (unique == "local") { 
            for (i in 1:length(object)) { object[[i]] <- unique(object[[i]]) }
        }
        if (unique == "global") {
            allentries <- unlist(object)
            x <- unique(allentries[duplicated(allentries)])
            for (i in 1:length(object)) {
                y <- object[[i]] %in% x
                object[[i]] <- object[[i]][!y]
            }
        }
        
        u <- listLengths(object)
        out <- matrix(data=0, nrow=sum(u), ncol=2)
        out[,1] <- unlist(sapply(1:length(u), FUN=function(x,n,u){rep(n[x],u[x])}, names(u), u))
        x <- unlist(object)
        names(x) <- c()
        out[,2] <- x
        
    }
    
    return(out)
}


apa.names$general <- c(apa.names$general, "mat.split")
mat.split <- function(x, f, bycol=FALSE, sort=TRUE, delim=":") {
    
    ## like 'split', but operates on rows/cols of matrices/dataframes
    ## 'bycol' splits by columns instead of rows
    ## short 'f' vector will get recycled, if it can be recycled evenly
    ## 'sort' will sort output list by name
    ## 'delim' is a delimiter (for the concatenated values that make up element names) when 'f' is a list with length > 1
    
    NR <- nrow(x)
    NC <- ncol(x)
    if (is.list(f) & length(f) == 1) f <- f[[1]]
    
    if (is.nlv(f)) {
        
        F <- length(f)
        f <- as.character(f)
        f[is.na(f)] <- "NA"
        U <- unique(f)
        if (sort) U <- sort(U)
        
        if (bycol) {
            if (F == NC) {
                L <- lapply(U, function(i) x[,f==i,drop=FALSE] ) 
            } else if (NC %% F == 0) {
                f <- rep(f, times=NC/F)
                L <- lapply(U, function(i) x[,f==i,drop=FALSE] ) 
            } else {
                stop("ncol(x) is not a multiple of length(f): cannot split!\n")
            }
        } else if (F == NR) {
            L <- lapply(U, function(i) x[f==i,,drop=FALSE] ) 
        } else if (NR %% F == 0) {
            f <- rep(f, times=NR/F)
            L <- lapply(U, function(i) x[f==i,,drop=FALSE] ) 
        } else {
            stop("nrow(x) is not a multiple of length(f): cannot split!\n")
        }
        names(L) <- U
        
    } else if (is.list(f)) {
        
        if (length(unique(listLengths(f))) != 1) stop("All vectors in 'f' must have same length!\n")
        F <- length(f[[1]])
        UF <- apply(do.call(cbind,f),1,paste,collapse=delim)
        UFF <- as.numeric(factor2(UF))  ## USE 'factor2': MUST NOT SORT LEVELS DURING NUMBERING PROCESS
        
        if (bycol) {
            if (F == NC) {
                L <- lapply(unique(UFF), function(i){ x[,UFF==i,drop=FALSE] }) 
            } else if (NC %% F == 0) {
                UF <- rep(UF, times=NC/F)
                UFF <- as.numeric(factor2(UF))
                L <- lapply(unique(UFF), function(i){ x[,UFF==i,drop=FALSE] }) 
            } else {
                stop("ncol(x) is not a multiple of length(f): cannot split!\n")
            }
        } else if (F == NR) {
            L <- lapply(unique(UFF), function(i){ x[UFF==i,,drop=FALSE] }) 
        } else if (NR %% F == 0) {
            UF <- rep(UF, times=NR/F)
            UFF <- as.numeric(factor2(UF))
            L <- lapply(unique(UFF), function(i){ x[UFF==i,,drop=FALSE] }) 
        } else {
            stop("nrow(x) is not a multiple of length(f): cannot split!\n")
        }
        names(L) <- unique(UF)
        
    } else {
        
        stop("'f' must be a vector, or a list of vectors!\n")
        
    }
    return(L)
}


apa.names$general <- c(apa.names$general, "merge.coords")
merge.coords <- function(obj, type="generic", strand=FALSE) {
	
	## Takes a dataframe or matrix of coordinates (start, end) and merges overlaps.
	## "type"s = row types: "generic" = c(start, end, [else]); "genomic" = c(chr, start, end, strand, [else]).
	## "strand": it type="genomic" and strand=TRUE, rows are separated by strand prior to merging.  No cross-strand merges.
	## return object is a length-2 list:
	##   [[1]]: the merged coordinate set.
	##   [[2]]: a list (matched to rows of [[1]]) containing original rows that got merged.
	
	if (!is.data.frame(obj) & ! is.matrix(obj)) { stop("Object must be a matrix or dataframe!\n") }
	if (ncol(obj) < 2) { stop("Object must contain at least 2 cols!\n") }
	if (ncol(obj) < 4 & type == "genomic") { stop("Object must contain at least 4 cols for type 'genomic'!\n") }
	
	flatten <- function(coords, annots) {
		sets <- vector("list", length=nrow(coords))
		sizes <- rep(0, nrow(coords))
		merged <- matrix(data=0, nrow=nrow(coords), ncol=2)
		prev.i <- prev.j <- NA
		size <- 0
		for (i in 1:nrow(coords)) {
			if (is.na(prev.i)) {		# no pending merging
				j <- which(annots[,1] == coords[i,1] & annots[,2] == coords[i,2])
				sets[[i]] <- annots[j,]
				if (i < nrow(coords)) {
					if (coords[i,2] >= coords[(i+1),1]-1) {	# downstream overlap
						prev.i <- i
						prev.j <- j
						size <- size + 1
						boundaries <- coords[i,]
						clear <- FALSE
					} else {
						clear <- TRUE
					}
				} else {
					clear <- TRUE
				}
				if (clear) { 				# no downstream overlap
					merged[i,] <- coords[i,] 
					sizes[i] <- length(j)
				}
			} else {			# rows pending merging
				j <- which(annots[,1] == coords[i,1] & annots[,2] == coords[i,2])
				if (sum(j != prev.j) == 0) {	# for rows with identical coordinates -- different handling...
					uniq <- FALSE
				} else {
					sets[[prev.i]] <- rbind(sets[[prev.i]], annots[j,])
					uniq <- TRUE
				}
				boundaries <- c(boundaries, coords[i,])
				sb <- sort(unlist(boundaries))
				boundaries <- sb[c(1,length(sb))]
				if (i < nrow(coords)) {
					if (boundaries[2] >= coords[(i+1),1]-1) {	# downstream overlap
						# DO NOT RESET prev.i
						prev.j <- j
						if (uniq) { size <- size + length(j) }	# not if this row is a duplicate!
						clear <- FALSE
					} else {
						clear <- TRUE
					}
				} else {
					clear <- TRUE
				}
				if (clear) {					# no downstream overlap
					merged[prev.i,] <- boundaries[c(1,length(boundaries))]
					sizes[prev.i] <- size
					prev.i <- prev.j <- NA
					size <- 0
					boundaries <- c()
				}
			}
		}
		
		drop <- which(rowSums(merged) == 0)
		length(drop)
		merged <- merged[-drop,]
		sets <- sets[-drop]
		sizes <- sizes[-drop]
		return(list(coords=merged, annots=sets, sizes=sizes))
	}
	
	if (type == "generic") {
		
		inputs <- as.matrix(obj[,1:2])
		ternary (ncol(obj) > 2, annots <- obj, annots <- NA)
		output <- flatten(inputs, annots)
		
	} else if (type == "genomic") {
		
		chrs <- unique(obj[,1])
		if (strand) { 
			strs <- unique(obj[,4]) 
			flat <- vector("list", length=length(chrs)*length(strs))
		} else {
			flat <- vector("list", length=length(chrs))
		}
		
		idx <- 0
		for (i in 1:length(chrs)) {
			x <- which(obj[,1] == chrs[i])
			if (strand) {
				for (j in 1:length(strs)) {
					idx <- idx + 1
					y <- which(ojb[x,4] == strs[j])
					inputs <- as.matrix(obj[y,2:3])
					ternary (ncol(obj) > 4, annots <- obj[y,], annots <- NA)
					flat[[idx]] <- flatten(inputs, annots)
				}
			} else {
				idx <- idx + 1
				inputs <- as.matrix(obj[x,2:3])
				ternary (ncol(obj) > 4, annots <- obj[x,], annots <- NA)
				flat[[idx]] <- flatten(inputs, annots)
			}
		}
		
		flat2 <- invert.list(flat)
		coords <- do.call(rbind, flat2$coords)
		for (i in 1:length(flat2$annots)) { flat2$annots[[i]] <- flat2$annots[[i]][[1]] }	# squeeze list
		
		return(list(coords=coords, merge.sets=sets))
		
	} else {
		stop("'type' must be either 'generic' or 'genomic'!\n") 
	}
}


apa.names$general <- c(apa.names$general, "combine.names")
combine.names <- function(vec.list, delim="_", dataframe=FALSE) {
	
	## Creates a new names vector from the "cross product" of two or more other names vectors.
	## The lowest vector (vec.list[1]) is the outermost iterator and the highest vector (vec.list[N]) is the innermost iterator.
	## "delim" speficies the delimiter when stringing names together.  Use "" or NA for no delimiter.  Ignored if dataframe=T.
	## "dataframe" indicates whether to return the combinations as a data frame (TRUE) or as a vector (FALSE).
	
	if (!is.list(vec.list)) { stop("Input must be a list of vectors!\n") }
	if (length(vec.list) < 2) { stop("Input list must have length > 1!\n") }
	if (is.na(delim)) { delim <- "" }
	vec.list <- rev(vec.list)  # enter as outer->inner, but build as inner->outer
	
	vlen <- length(vec.list)
	vlen1 <- vlen - 1
	tot.len <- 1	# total number of resulting names
	
	for (i in 1:vlen) { tot.len <- tot.len * length(vec.list[[i]]) }
	ilens <- listLengths(vec.list)		# num names in each vector
	
	blocks <- c(1, rep(0, vlen1))
	prenames <- matrix(data="", nrow=tot.len, ncol=vlen)
	for (i in 1:vlen) {
		temp <- c()
		if (i > 1) { blocks[i] <- blocks[(i-1)] * ilens[(i-1)] }
		for (j in unique(vec.list[[i]])) { temp <- c(temp, rep(j, blocks[i])) }
		reps <- tot.len / ( blocks[i] * ilens[i] )
		prenames[,i] <- rep(temp, reps)
	}
	
	if (dataframe) {
		allnames <- as.data.frame(prenames[,vlen:1])
	} else {
		allnames <- apply(prenames, 1, FUN=function(x,delim){paste(rev(x),collapse=delim)}, delim)
	}
	return(allnames)
}


apa.names$general <- c(apa.names$general, "sprintf.rownames")
sprintf.rownames <- function(obj, sep=" ", justify=NULL) {
	
	## Takes a matrix, dataframe, or dataframe-conformable list and merges rows into strings via sprintf
	## "sep" gives the field separator
	## "justify" sets left or right justification per column as a vector of 1s & -1s, length=ncol
	
	if (is.ndfl(obj)) { obj <- as.data.frame(obj) }	# this could fail, so re-test for d.f below
	
	if (is.data.frame(obj) | is.matrix(obj)) {
		# ok
	} else {
		stop("object must be a matrix, dataframe, or dataframe-conformable list!\n")
	}
	
	if (is.null(justify)) { 
		justify <- rep(-1, ncol(obj)) 
	} else {
		if (length(justify) != ncol(obj)) { stop("'justify' vector must have length = ncol 'obj'!\n") }
	}
	
	typeconv <- matrix(c("character","s", "numeric","d", "integer","d", "double","d", "complex","s", "float","f"), ncol=2, byrow=TRUE) # float not a mode, but decided prior to conversion
	
	lens <- apply(obj, 2, nchar)
	maxlen <- apply(lens, 2, max)
	datatypes <- apply(obj, 2, mode)
	prefloat <- which(datatypes!="character" & datatypes!="complex")
	floats <- prefloat[which(apply(obj, 2, FUN=function(x){any(grep("\\.",x))}))]
	datatypes[floats] <- "float"
	formats <- typeconv[match(datatypes,typeconv[,1]),2]
	prefixes <- gsub("1","",paste("%",justify,sep=""))
	format.str <- paste(paste(prefixes,maxlen,formats,sep=""),collapse=sep)
#	IM(maxlen)
#	IM(datatypes)
#	IM(formats)
#	IM(format.str)
	string <- apply(obj, 1, FUN=function(x){do.call(sprintf, as.list(c(format.str,x)))})
	return(string)
}


apa.names$general <- c(apa.names$general, "multi.index")
multi.index <- function(..., names=NULL, na.rm=FALSE) {
	
	## Essentially, multi.index produces an N-way outer join table (na.rm=F) or an N-way inner join table (na.rm=T).
	## "vectorlist" is a list object containing two or more UNIQUED vectors from tables to join (e.g. rowname vectors -- no duplicate entries).
	## Output: one matrix with ncol=length(vectorlist), nrow=length(union(vectorlist)), rownames=sort(union(vectorlist)), and colnames=names(vectorlist).
	## Each unique identifier in union(vectorlist) gets a row (i) in output matrix; each column entry is the index for that identifier in vector (j)
	## In many cases there will be NA entries: na.rm=T will strip any rows which possess any NA entries.
	
	vectorlist <- list(...)
	if (length(vectorlist) == 1) { vectorlist <- vectorlist[[1]] }	# input was a single list
	vlen <- length(vectorlist)
	if (vlen < 2) { stop("Need at least two vectors (= list of length 2) to join!\n") }
#	for (i in 1:length(vectorlist)) { vectorlist[[i]] <- as.character(vectorlist[[i]]) }	# incoming might be factors
	
	nuniq <- c()
	for (i in 1:length(vectorlist)) { 
		if (any(duplicated(vectorlist[[i]]))) { nuniq <- c(nuniq, i) }
	}
	if (length(nuniq) > 0) { stop(paste(c("Vectors",nuniq,"have redundant entries!  Cannot index redundancies.\n"),collapse=" ")) }
	
	ternary (is.null(names), vnames <- names(vectorlist), vnames <- names)
	vunion <- c()
	for (i in 1:vlen) { vunion <- union(vunion, vectorlist[[i]]) }
	vunion <- sort(vunion, na.last=TRUE)
	
	join.mat <- matrix(data=NA, nrow=length(vunion), ncol=vlen)
	rownames(join.mat) <- vunion; colnames(join.mat) <- vnames
	
	for (j in 1:ncol(join.mat)) { join.mat[,j] <- match(vunion, vectorlist[[j]]) }
	if (na.rm) {
		keep <- which(!is.na(rowSums(join.mat)))
		join.mat <- join.mat[keep,]
	}
	
	return(join.mat)
}


apa.names$general <- c(apa.names$general, "match.multi")
match.multi <- function(x, y) {
	
	## Extension of base match() to match on multiple columns simultaneously
	## 'x' and 'y' are matrices or dataframes with the same number of columns (not necessarily rows)
	## returns match vector for 'x' in 'y'
	
	x2 <- apply(x,1,paste,collapse="\t")
	y2 <- apply(y,1,paste,collapse="\t")
	match(x2, y2)
}


apa.names$general <- c(apa.names$general, "join.tables")
join.tables <- function(mat1, mat2, join, key1=1, key2=1, dup.rm=TRUE, spacer=NA, sort=TRUE) {
	
	## DB-style table joins for two matrices or dataframes
	## key1, key2 indicate column numbers for keys in mat1, mat2 respectively
	## join: { 1=Outer, 2=Inner, 3=Left, 4=Right, 5=Disjoin }
	## dup.rm: discard duplicate rows?
	## spacer: missing (null) values represented by this spacer
	## sort: separate rows into joined/unjoined sets or leave in mat1 (+mat2) order?
	
	if (!join %in% 1:5) { stop("'join' must be an integer from 1-5!\n") }
	
#	df.out <- FALSE
#	if (is.data.frame(mat1)) { df.out <- TRUE }
#	if (is.data.frame(mat2)) { df.out <- TRUE }
	
	keyname <- colnames(mat1)[key1]
	k1 <- mat1[,key1]
	k2 <- mat2[,key2]
	all <- sort(union(k1, k2))
	int <- intersect(k1, k2)
	int.v1 <- match(int, k1)
	int.v2 <- match(int, k2)
	sd1 <- setdiff(k1, k2)
	sd2 <- setdiff(k2, k1)
	sd1.v1 <- match(sd1, k1)
	sd2.v2 <- match(sd2, k2)
	
	mat1 <- mat1[,-key1]	# remove keys
	mat2 <- mat2[,-key2]	# remove keys
	
	spacer1 <- matrix(data=spacer, nrow=length(sd2), ncol=ncol(mat1))
	colnames(spacer1) <- colnames(mat1)
	spacer2 <- matrix(data=spacer, nrow=length(sd1), ncol=ncol(mat2))
	colnames(spacer2) <- colnames(mat2)
	joinreport <- c()
	
	joined <- switch(as.character(join),
		"1" = rbind(
				nameless(cbind(sd1, mat1[sd1.v1,], spacer2)),
				nameless(cbind(int, mat1[int.v1,], mat2[int.v2,])),
				nameless(cbind(sd2, spacer1,       mat2[sd2.v2,]))
			),
		"2" = cbind( int, mat1[int.v1,], mat2[int.v2,] ),
		"3" = rbind( 
				nameless(cbind(sd1, mat1[sd1.v1,], spacer2)),
				nameless(cbind(int, mat1[int.v1,], mat2[int.v2,]))
			),
		"4" = rbind( 
				nameless(cbind(int, mat1[int.v1,], mat2[int.v2,])), 
				nameless(cbind(sd2, spacer1,       mat2[sd2.v2,]))
			),
		"5" = rbind( 
				nameless(cbind(sd1, mat1[sd1.v1,], spacer2)), 
				nameless(cbind(sd2, spacer1,       mat2[sd2.v2,])) 
			)
	)
	colnames(joined) <- c(keyname, colnames(spacer1), colnames(spacer2))
	
	if (sort) joined <- joined[match(all, joined[,1]),]
	
	if (dup.rm) {
		if (is.matrix(joined)) {
			cats <- apply(joined, 1, FUN=function(x){paste(x, collapse=".")})
		} else {
			cats <- apply(as.matrix.data.frame(joined), 1, FUN=function(x){paste(x, collapse=".")})
		}
		drop <- which(duplicated(cats))
		if (length(drop > 0)) { joined <- joined[-drop,] }
	}
	
#	if (df.out) { joined <- defactor(as.data.frame.matrix(joined)) }
	
#	IM(joinreport)
	return (joined)	
}


apa.names$general <- c(apa.names$general, "modes")
modes <- function(vec, dir="pos", inflections=FALSE, infer=TRUE, use.density=TRUE, strict=FALSE, error="plus1", global=FALSE, merge.adjacent=TRUE, plot=FALSE, na.zero=FALSE, na.rm=TRUE, dens.n=512, main=NULL, ...) {
    
    ## Returns positions and heights of all modes (or inflection points) from a vector, given the conditions below:
    ## "dir": what direction to look for modes.  Can be "pos", "neg", or "both".
    ## "inflections=T" will look for inflection points INSTEAD OF minima/maxima. 
    ## "infer": if TRUE, modes will be inferred (e.g. by density).  If FALSE, exact modes (numbers present > 1 times) will be returned.  Automatically TRUE if "inflections=T".
    ## "use.density": control how modes/inflection points are found (not used if "infer=F"):
    ##	    TRUE means, input is any old vector of values; infer modes using density().
    ##	    FALSE means, input is an ordered numerical series representing a function output (e.g. sine, polynomial); infer modes WITHOUT using density().
    ## "strict": TRUE returns nearest values from the input vector; FALSE returns "true" values.
    ##	     If "kernel=F" or "use.density=T" then strict=T automatically, unless adjacent modes are found.
    ##	     "strict=T" also affects the position of the mode if "merge.adjacent=T".
    ## "error": if strict=F, how much measurement error in the estimate of the mode to allow?
    ##	    Values: "plus1" (round to 1 greater than input error), "same" (round to input error), "none" (round to integer), "any" (raw estimate).
    ## "global=T" returns only the extremum (unless > 1 at most extreme height).  Not used if "inflections=T".
    ## "merge.adjacent=T" will merge N adjacent modes (if any adjacencies found; think step functions) by taking their midpoint.
    ## "plot=T" plots the input vector (or its density, if "use.density=T"), along with mode position(s).
    ## "na.zero" converts NAs to zeroes.
    ## "na.rm" operates as usual AND TAKES PRECEDENCE OVER "na.zero".
    ## "main" is for the plot, if plot=TRUE.  It does have defaults chosen internally.
    ## "...": other arguments passed to density(), like 'kernel' or 'adjust'.
    
    
    ## You Can:
    ## Infer modes without density (sine, polynomial)
    ## Infer inflection points without density (ditto)
    ## Infer modes with density (any old vector)
    ## Infer inflection points with density (ditto)
    ## Get "true" modes (inference disallowed), i.e.: which(table(x) > 1)
    
    if (length(vec)<3) stop("Cannot process vector with < 3 elements!\n")
    xname <- deparse(substitute(vec))
    match.arg(dir, c("pos", "neg", "both"))
    match.arg(error, c("plus1", "same", "any", "none"))
    if (na.rm) vec <- vec[which(!is.na(vec))]
    if (na.zero) vec[which(is.na(vec))] <- 0
    
    strict.w <- table(vec)
    strict.y.vals <- as.vector(strict.w)
    strict.x.vals <- as.numeric(names(strict.w))
    
    if (inflections) {
        if (global) {
            IM("'global' and 'inflections' cannot both be TRUE.  Setting 'global' to FALSE.") 
            global <- FALSE
        }
        if (!infer) {
            IM("Use of 'inflections' requires inference.  Setting 'infer' to TRUE.") 
            infer <- TRUE
        }
    }
    
    if (infer) {
        if (use.density) {
            dens.args <- list(...)
            dens.args$x <- vec
            dens.args$n <- dens.n
            dens <- do.call(density, dens.args)
            y.vals <- zapsmall(dens$y)
            x.vals <- dens$x
        } else {
            x.vals <- 1:length(vec)
            y.vals <- vec
        }
    } else {
        kernel <- NULL
        w <- table(vec)
        y.vals <- as.vector(w)
        x.vals <- as.numeric(names(w))
    }
    
    results <- list(pos=c(), neg=c())
    
    export <- function(pos) {	# get { x.vals, y.vals, strict } from parent namespace
        if (length(pos) > 1) {
            ternary (merge.adjacent, pos1 <- (pos[1]+pos[length(pos)])/2, pos1 <- pos)	# if interp required, take mean position of run
        } else {
            pos1 <- pos
        }
        if (strict) {
            pos2 <- quantize(x.vals[pos1], strict.x.vals)
            return(list( matrix(c(pos2, strict.y.vals[which(strict.x.vals==pos2)]), 1, 2, F, list(c(),c("Mode","Height"))) ))
        } else {
            return(list( matrix(c(x.vals[pos1], y.vals[pos1]), 1, 2, F, list(c(),c("Mode","Height"))) ))
        }
    }
    
    signswitch <- function(signs) {
        temp <- list(pos=c(), neg=c())
        last_sign <- 0
        skip <- c()
        for (i in 2:length(signs)-1) {
            if (i %in% skip) next				# this base is part of an already-analyzed mode run
            if (falsify(signs[i] == 0)) {		# zero slope (extended max or min)
                j <- chase(i, signs, 0)
                skip <- c(skip, i:j)			# handling the run here -- do not re-analyze further bases in this mode run
                if (last_sign == 1) {			# extended maximum
                    temp$pos <- c(temp$pos, export(pos))
                } else if (last_sign == -1) {		# extended minimum
                    temp$neg <- c(temp$neg, export(pos))
                }
            } else {
                last_sign <- signs[i]
                pos <- i + 1
                if (falsify(signs[i] == 1) & falsify(signs[(i+1)] == -1)) {		# sign switch (maximum)
                    temp$pos <- c(temp$pos, export(pos))
                } else if (falsify(signs[i] == -1) & falsify(signs[(i+1)] == 1)) {	# sign switch (minimum)
                    temp$neg <- c(temp$neg, export(pos))
                }
            }
        }
        if (length(temp$pos)>0) {
            temp$pos <- do.call(rbind, temp$pos)
        } else {
            temp$pos <- c()
        }
        if (length(temp$neg)>0) {
            temp$neg <- do.call(rbind, temp$neg)
        } else {
            temp$neg <- c()
        }
        return(temp)
    }
    
    if (infer) {
        if (global) {
            if (dir == "pos") {
                pos <- which(y.vals == max(y.vals))
                results$pos <- matrix(export(pos)[[1]], 1, 2, F, list(c(),c("Mode","Height")))
            }
            if (dir == "neg") {
                pos <- which(y.vals == min(y.vals))
                results$neg <- matrix(export(pos)[[1]], 1, 2, F, list(c(),c("Mode","Height")))
            }
        } else if (inflections) {	# get inflection points
            temp <- signswitch(sign(diff(diff(y.vals))))
            results$pos <- temp$neg
            results$neg <- temp$pos
        } else {			# get minima/maxima
            results <- signswitch(sign(diff(y.vals)))
        }
    } else {
        hi.y.vals <- which(y.vals > 1)
        if (length(hi.y.vals) == 0) {
            IM("No modes!\n")
            return(results)
        } else {
            ternary ( global, pos <- which(y.vals == max(y.vals)), pos <- hi.y.vals )
            results$pos <- export(pos)[[1]]
        }
    }
    
    if (!strict) {
        eov <- err.ord(vec)
        eoe <- err.ord(unlist(results))
        decs <- switch(error, "plus1" = eov[2]+1, "same" = eov[2], "any" = eoe[2], "none" = 0)
        if (!is.null(results$pos)) {
            results$pos[,1] <- round(results$pos[,1], decs)
        }
        if (!is.null(results$neg)) {
            results$neg[,1] <- round(results$neg[,1], decs)
        }
    }
    
    if (plot) {
        if (is.null(main)) {
            main <- ifelse(inflections, "Inflection Points", "Maxima and Minima")
        }
        ymin <- ifelse (use.density, 0, min(real(y.vals)))
        hist(x.vals, col=0, bord=0, freq=FALSE, ylim=c(ymin, max(y.vals)), xlab=xname, main=main)
        lines(x.vals, y.vals)
        if (length(results$pos) > 0) abline(v=results$pos[,1], col=2)
        if (length(results$neg) > 0) abline(v=results$neg[,1], col=4)
    }
    
    return(lapply(results,as.data.frame))
}


apa.names$general <- c(apa.names$general, "saddlepoint")
saddlepoint <- function(vec, plot=FALSE) {
    
    ## An add-on to modes() above, looking for A SINGLE "optimal" saddle-point.
    ## Assumes a generally bimodal distribution...
    ## General strategy: find two highest "separate" modes, then find lowest antimode between them.
    ## What makes positive modes "separate"?  The density() 'adjust' param, see below.
    
    ## 1. if only 1 mode, fail
    ## 2. if exactly 2 modes, find lowest anti; done
    ## 3. if > 2 modes, winnow:
    ##    A. restrict to modes > median
    
    adj <- 1
    m <- modes(vec)  # initial test
    if (nrow(m$pos)==1) {
        stop("Distribution is unimodal: no obvious saddlepoints here!\n")
    } else if (nrow(m$pos)==2) {
        ## ok, continue
    } else {
        ## too many modes; ratchet up density() 'adjust' param until only two remain
        message("Smoothing distribution down to two modes, please stand by...")
        m.adj <- c()
        while (length(m.adj)==0) {
            adj <- adj+0.1
            ##if (round(adj,1)==adj) message(paste(" Adjust =",adj))
            m.adj <- modes(vec, adjust=adj)
            if (nrow(m.adj$pos)!=2) m.adj <- c()  ## only retain value if exactly two modes
        }
        ## final modes will not be the same as initial modes; find nearest initial modes to final modes
        p1 <- nearest(m.adj$pos$Mode[1], m$pos$Mode, index=TRUE)
        p2 <- nearest(m.adj$pos$Mode[2], m$pos$Mode, index=TRUE)
        n1 <- nearest(m.adj$neg$Mode, m$neg$Mode, index=TRUE)
        m$pos <- m$pos[c(p1,p2),]  # keep only nearest initial modes
        m$neg <- m$neg[n1,]        # keep only nearest initial antimode
    }
    
    if (plot) {
        mcols <- ifelse(adj>1,3,2)
        par(mfrow=c(1,mcols), las=1)
        ignore <- modes(vec, plot=TRUE, main="Initial Modes")
        if (adj>1) ignore <- modes(vec, adjust=adj, plot=TRUE, main=paste0("Smoothed Modes, adjust=",adj))
        dhist(vec, main="Saddle Point (Blue)", legend=NA)
        abline(v=c(m$pos$Mode,m$neg$Mode), lty=c(3,3,1), col=c(2,2,4))
    }
    m$neg$Mode
}
##Saddlepoint testing...
##x=c(rnorm(1E4,1,2),rnorm(1E4,10,2),runif(1E3,0,4),runif(1E3,6,9),rbeta(1E3,1,2,0)); dhist(x)   # cleanly bimodal
##x=c(x,rnorm(2E3,-2,0.5),rnorm(2E3,14,0.7)); dhist(x)                                           # uncleanly bimodal
##x=c(x, rnorm(1E3,-1,0.3),rnorm(5E3,4,0.5),rnorm(5E2,8,0.4),rnorm(1E3,14,0.5),rep(c(-8,-6),each=50)); dhist(x)  # uglimodal  
##modes(x,plot=TRUE)
##saddlepoint(x,plot=TRUE)


apa.names$general <- c(apa.names$general, "is.monotonic")
is.monotonic <- function(vec, decreasing=FALSE, tolerance=NA, t.pct=NA, gain=NA, g.pct=NA) {
	
	## Returns T/F for whether a vector is monotonically increasing
	## "decreasing=T" tests for monotonically decreasing
	## "gain" discards 'weakly' changing vectors, judging if the absolute change from first to last element is not >= gain
	## "g.pct" causes gain values to be interpreted as a percentages.
	## g.pct="mean" causes gain value to be a percentage of the vector mean
	##  thus if vector mean = 50, gain=0.1, g.pct="mean" then if the vector does not change by at least 5 over its length, it fails.
	## g.pct="median" behaves similarly; g.pct=NA disables the parameter.
	## "tolerance" allows slopes to break the requested trend (increasing, decreasing) within a tolerance limit and still pass.
	##   "tolerance" is effectively the noise threshold, so all slopes within [-tolerance,+tolerance] will be tolerated.
	##   "tolerance=NA" deactivates, while "tolerance=0" allows invariant slopes to pass.  However, a vector will still fail if all slopes == 0.
	## "t.pct" is identical to "g.pct" but applies to "tolerance", not "gain".
	
## OLD TOLERANCE DEF
##	## "tolerance" behaves like "gain" and allows for flexibility in calling a increase.
##	##   if the vector actually decreases between points n and n+1, the "tolerance" parameter can rescue it if the absolute decrease is less than "tolerance".
##	##   "tolerance=NA" deactivates, while "tolerance=0" sets tolerance to the minimum passing slope: 
##	##   thus if decreasing=F and minimum increasing slope = 0.1, then decreasing slopes >= -0.1 will be tolerated.
##	##   this because the minimum passing slope will be interpreset as the noise threshold, so all slopes within [-noise,+noise] will be tolerated
	
	if (any(is.na(vec))|length(vec)<2) return(NA)  # can't evaluate vectors with NAs, or less than two elements
	
	## Survived to reach the gain filter, if any
	if (!is.na(gain)) {
		if (!is.na(g.pct)) g.pct <- get(g.pct)  # convert to function
		min.gain <- abs(gain) * ifelse(is.function(g.pct), get(g.pct)(vec), 1)  # convert relative gain to minimum required gain for this particular vector
		max.gain <- abs(diff(range(vec)))  # actual gain for this vector (max gain between any two points)
		if (max.gain < min.gain) return(FALSE)  # failed gain filter, regardless of direction
	}
	
	## Survived to reach the tolerance filter, if any
	slopes <- diff(vec)
	if (is.na(tolerance)|is.infinite(tolerance)|tolerance==0) {
		if (decreasing) {
			tol.pass <- ifelse(falsify(tolerance==0), all(slopes<=0)&any(slopes<0), all(slopes<0))
		} else {
			tol.pass <- ifelse(falsify(tolerance==0), all(slopes>=0)&any(slopes>0), all(slopes>0))
		}
	} else {
		if (!is.na(t.pct)) t.pct <- get(t.pct)  # convert to function
		tolerance <- abs(tolerance) * ifelse(is.function(t.pct), get(t.pct)(vec), 1)  # convert relative tolerance to absolute tolerance for this particular vector
		tol.pass <- ifelse(decreasing, max(slopes)<=tolerance, min(slopes)>=tolerance)
## OLD TOLERANCE DEFINITION
##		if (tolerance == 0) {
##			tolerance <- ifelse(decreasing, max(slopes[slopes<0]),  min(slopes[slopes>0]))  # t.pct ignored; get largest negative or smallest positive slope
##		} else {
##			tolerance <- abs(tolerance) * ifelse(is.function(t.pct), get(t.pct)(vec), 1)  # convert relative tolerance to absolute tolerance for this particular vector
##		}
	}
	return(tol.pass)
}


apa.names$general <- c(apa.names$general, "conn.mat.subgraphs")
conn.mat.subgraphs <- function(obj, threshold=1, remove="lt") {
	
	## Extracts all distinct subgraphs from a connectivity matrix.
    ## A wrapper for pairs2subgraphs().
    ## "threshold" can be used to remove entries prior to subgraph identification, provided a "remove" criterion.
    ## "remove" sets the removal criterion relative to "threshold"; these are same as Perl's string equalities:
    ##  "ge" = greater than or equal to (threshold),
    ##  "gt" = greater than,
    ##  "le" = less than or equal to,
    ##  "lt" = less than,
    ##  "eq" = equal to.
    
	if (is.matrix(obj)) {
        # ok
	} else if (is.data.frame(obj)) {
        obj <- as.matrix(obj)
	} else if (is(obj, "dist")) {
        obj <- as.matrix(obj)
    } else {
        stop ("Object must be a matrix or dataframe!\n")
    }
    if (!is.numeric(threshold) & !is.infinite(threshold)) { stop("'threshold' must be a number (infinity inclusive)\n") }
    match.arg(remove, c("gt","ge","lt","le","eq"))
    if (length(obj)<=1) { IM("Object has no data!\n"); return() }

    switch(remove,
        gt={ obj[obj>threshold] <- NA },
        ge={ obj[obj>=threshold] <- NA },
        lt={ obj[obj<threshold] <- NA },
        le={ obj[obj<=threshold] <- NA },
        eq={ obj[obj==threshold] <- NA }
    )
    
    nr <- nrow(obj)
    nc <- ncol(obj)
    pairs <- vector("list", length=length(obj))
    n <- 0
    for (i in 1:nr) {
        for (j in 1:nc) {
            n <- n + 1
            if (i < j) {   # only need to process one triangle
                if (!is.na(obj[i,j])) {
                    pairs[[n]] <- c(i,j)
                }
            }
        }
    }
    pairs <- pairs[listLengths(pairs)>0]
    if (length(pairs) > 0) {
        return(pairs2subgraphs(pairs))
    } else {
        IM("No connected pairs at given thresholds!\n"); return()
    }
}


apa.names$general <- c(apa.names$general, "pairs2subgraphs")
pairs2subgraphs <- function(obj) {
	
	## Extracts all distinct subgraphs from a collection of paired elements (either as a list or a matrix)
	
	if (is.list(obj)) {
		x <- listLengths(obj) != 2
		if (any(x)) { stop("Each list element must be a vector of length 2!\n") }
	} else if (is.matrix(obj)) {
		if (ncol(obj) != 2) { stop("Matrix must have two columns!\n") }
		y <- apply(obj, 1, FUN=function(x){list(x[1],x[2])})
		obj <- lapply(y, unlist)	# replace matrix with list
	} else {
		stop("Object must be a 2-column matrix or a list of length-2 vectors!\n")
	}
	
	all <- sort(unique(unlist(obj)))
	N <- length(all)
	connect <- vector("list", length=N)
	names(connect) <- all
	
	for (i in 1:length(obj)) {
		xo <- match(obj[[i]], all)
		connect[[xo[1]]] <- c(connect[[xo[1]]], obj[[i]][2])
		connect[[xo[2]]] <- c(connect[[xo[2]]], obj[[i]][1])
	}
	
	for (i in 1:N) { connect[[i]] <- unique(c(all[i],connect[[i]])) }
	
	cdata <- list(i=all[1], root=all[1], already=c(), subgraphs=vector("list", length=N))	# i=pending element, root=originating element.
	conn.path <- function(cdata) {		
		R <- which(all == cdata$root)						# find index for root element
		I <- which(all == cdata$i)						# find index for pending element
#		cat("Root:",R," I:",I,"\nA:",cdata$already,"\n"); flush.console()	### reporter
		if (!I %in% cdata$already) {						# ignore if already analyzed
			cdata$already <- c(cdata$already, I)				# add this row to the already-analyzed set
			cdata$subgraphs[[R]] <- c(cdata$subgraphs[[R]], connect[[I]])		# add connectivity to pool for the originating row
			for (j in connect[[I]]) {					# for each connected sub-element: 
				J <- which(all == j)					# find index for upcoming element
				if (J != I) {						#   don't repeat the pending step
					if (!J %in% cdata$already) { 			#   don't repeat a previous analysis
#						cat("Root:",R," I:",I," J:",J,"\nA:",cdata$already,"\nP:",cdata$subgraphs[[R]],"\n\n"); flush.console()	### reporter
						cdata$i <- j				#   j becomes new pending element
						cdata <- conn.path(conn.path(cdata)) 	#   repeat process with the sub-element as a new row (recursively)
					}
				}
			}
			return(cdata)
		} else {
			return(cdata)
		}
	}
	
	for (i in 1:N) {
		cdata$i <- cdata$root <- all[i]
		cdata <- conn.path(cdata)
#		cat("\nFinished:",i,all[i],"\n\n"); flush.console()	### reporter
	}
	
	subgraphs <- vector("list", length=length(!is.null(cdata$subgraphs)))
	p <- 0
	for (i in 1:N) {
		if (!is.null(cdata$subgraphs[[i]])) { 
			p <- p + 1
			subgraphs[[p]] <- sort(unique(cdata$subgraphs[[i]])) 
		}
	}
	subgraphs <- subgraphs[order(listLengths(subgraphs),decreasing=TRUE)]  # largest subgraphs first
	
	return(subgraphs)
}


apa.names$general <- c(apa.names$general, "sets2subgraphs")
sets2subgraphs <- function(x) {
    
    ## Extracts all distinct subgraphs from a collection ('x', a list) of sets (elements of 'x'), where each set should be 2+ elements long
    ## Any two sets with at least one element in common will be merged
    ## Output is a list of final merged sets
    
    ## First pass: merge elements into initial subgraphs
    x <- x[listLengths(x)>0]  # drop empty sets
    ##IM(length(x))
    subgraphs <- x[1]  # initialize with first set
    x <- x[-1]
    while (length(x)>0) {
        for (i in 1:length(subgraphs)) {   # SUBGRAPHS FIRST
            lx <- length(x)
            keep <- rep(TRUE, lx)
            for (j in 1:lx) {   # REMAINING SETS SECOND
                if (any(x[[j]] %in% subgraphs[[i]])) {
                    subgraphs[[i]] <- unique(c(subgraphs[[i]], x[[j]]))
                    keep[j] <- FALSE
                }
            }
            x <- x[keep]  # remaining unmerged
        }
        subgraphs <- c(subgraphs, x[1])  # after each merging pass, start new subgraph with next unmerged set
    }
    ## Second pass: merge any overlapping subgraphs
    subgraphs <- lapply(subgraphs[rev(order(sapply(subgraphs,length)))], sort)
    S <- length(subgraphs)
    for (i in 1:S) names(subgraphs[[i]]) <- NULL
    S1 <- 0  # init
    ##IM(S); print(table(listLengths(subgraphs)))
    while (S!=S1) {
        S <- length(subgraphs)  # BEFORE
        for (i in 1:(S-1)) {
            if (length(subgraphs[[i]])==0) next
            for (j in (i+1):S) {
                if (length(subgraphs[[j]])==0) next
                li <- length(intersect(subgraphs[[i]],subgraphs[[j]]))
                ##IM(i,j,length(subgraphs[[i]]),length(subgraphs[[j]]),li)
                if (li>0) {
                    subgraphs[[i]] <- unique(c(subgraphs[[i]],subgraphs[[j]]))
                    subgraphs[j] <- list(c())
                }
            }
        }
        subgraphs <- subgraphs[listLengths(subgraphs)>0]
        S1 <- length(subgraphs)  # AFTER
        ##IM(S1); if (S1>0) print(table(listLengths(subgraphs)))
    }
    lapply(subgraphs[rev(order(sapply(subgraphs,length)))], sort)
}


apa.names$general <- c(apa.names$general, "draw.pairs.graph")
draw.pairs.graph <- function (mat, type, title="Graph1", geometry="ellipse", overlap=FALSE, directional=FALSE, redundant=TRUE, image.prefix=NULL) {
	
	# "type" is one of:
	#   "cm" for square connectivity matrix;
	#   "2m" for 2-col matrix (nodeA, NodeB), rows imply connectivity;
	#   "4m" for 4-col matrix (clusterA, nodeA, clusterB, nodeB), rows imply connectivity;
	# connectivity in connectivity matrices is represented by nonzero, non-NA values
	# "title" is a graph title
	# "geometry" = { box, circle, diamond, plaintext } indicating node shape
	# "directional" specifies dir or undir graph
	# "redundant=T" allows > 1 edge per node pair.  If FALSE, get only one edge
	# "image.prefix" specifes a filename prefix to write "prefix.graph" and "prefix.png" files
	
	# mention directionality assumptions in matrix encoding
	
	if (directional) {
		arrow <- "normal"
	} else {
		arrow <- "none"
	}
	
	if (type == "cm") {
		mat[is.na(mat)] <- 0
		if (is.null(dimnames(mat))) { dimnames(mat) <- list(1:nrow(mat), 1:ncol(mat)) }
		nodes <- unique(unlist(dimnames(mat)))
		edges <- rep("",sum(mat!=0))
		E <- 0
		for (i in 1:nrow(mat)) {
			for (j in 1:ncol(mat)) {
				if (mat[i,j] != 0) {
					E <- E + 1
					if (directional) {   # preserve order
						nodeA <- nodes[i]
						nodeB <- nodes[j]
					} else {   # homogenize order to prevent duplicate edges (so, no A->B AND B->A)
						snodes <- sort(nodes[c(i,j)])
						nodeA <- snodes[1]
						nodeB <- snodes[2]
					}
					edges[E] <- paste("\t",nodeA,esymb,nodeB,";",sep="")
				}
			}
		}
	} else if (type == "2m") {
		edges <- rep("",nrow(mat))
		for (i in 1:nrow(mat)) {
			if (directional) {   # preserve order
				nodeA <- mat[i,1]
				nodeB <- mat[i,2]
			} else {   # homogenize order to prevent duplicate edges (so, no A->B AND B->A)
				snodes <- sort(mat[i,])
				nodeA <- snodes[1]
				nodeB <- snodes[2]
			}
			edges[i] <- paste("\t",nodeA,esymb,nodeB,";",sep="")
		}
	} else if (type == "4m") {
		edges <- rep("",nrow(mat))
		nodes <- rep("", nrow(mat)*2)
		subs.1 <- sort(unique(c(mat[,c(1,3)])))
		subs <- vector("list", length=length(subs.1))  # can use "color=", "label=" for "subgraph clusterX { }" blocks
		for (i in 1:nrow(mat)) {
			if (directional) {   # preserve order
				clustA <- mat[i,1]
				nodeA <- mat[i,2]
				clustB <- mat[i,3]
				nodeB <- mat[i,4]
#				ord <- order(mat[i,c(1,3)])   # sort on node name
#				nodeA <- mat[i,c(2,4)[ord[1]]]
#				clustA <- mat[i,c(1,3)[ord[1]]]
#				nodeB <- mat[i,c(2,4)[ord[2]]]
#				clustB <- mat[i,c(1,3)[ord[2]]]
			} else {   # homogenize order to prevent duplicate edges (so, no A->B AND B->A)
				ord <- order(mat[i,c(2,4)])   # sort on node name
				nodeA <- mat[i,c(2,4)[ord[1]]]
				clustA <- mat[i,c(1,3)[ord[1]]]
				nodeB <- mat[i,c(2,4)[ord[2]]]
				clustB <- mat[i,c(1,3)[ord[2]]]
			}
			nodes[i] <- paste("\t",nodeA," [];",sep="")
			edges[i] <- paste("\t",nodeA,esymb,nodeB,";",sep="")
#			edges[i] <- paste( paste("\t",clustA,esymb,nodeA,";",sep=""), paste("\t",nodeA,esymb,nodeB,";",sep=""), paste("\t",nodeB,esymb,clustB,";",sep=""), collapse="\n")
		}
	}
	graph <- c(paste("digraph",title,"{"), float, paste("\tnode [shape=",geometry,"];",sep=""), edges, "}")
	if (!redundant) { graph <- unique(graph) }
	if (is.null(image.prefix)) {
		return(graph)
	} else {
		graphfile <- paste(image.prefix,"graph",sep=".")
		pngfile <- paste(image.prefix,"png",sep=".")
		write.vector(graph, graphfile)
		if (grepl(.Platform$OS.type,"unix")) { 
			system(paste("dot -Tpng -o",pngfile,graphfile));
		} else {
			IM("Cannot create png image on Windows, sorry.  But we wrote the graph file.\n")
		}
	}
}


apa.names$general <- c(apa.names$general, "draw.cell.graph")
draw.cell.graph <- function (mat, type, title="Graph1", geometry="ellipse", overlap=FALSE, directional=FALSE, redundant=TRUE, image.prefix=NULL) {
	
	# "mat" must be a 4-col matrix (clusterA, nodeA, clusterB, nodeB), rows imply connectivity;
	# connectivity in connectivity matrices is represented by nonzero, non-NA values
	# "title" is a graph title
	# "geometry" = { box, circle, diamond, plaintext } indicating node shape
	# "directional" specifies dir or undir graph
	# "redundant=T" allows > 1 edge per node pair.  If FALSE, get only one edge
	# "image.prefix" specifes a filename prefix to write "prefix.graph" and "prefix.png" files
	
	# mention directionality assumptions in matrix encoding
	
	prog <- "dot"
	gtype <- "digraph"
	float <- ifelse(overlap, "\tlabelfloat=true", "\tlabelfloat=false")
	if (directional) {
#		esymb <- "->"
#		prog <- "dot"
#		gtype <- "digraph"
		arrow <- "normal"
	} else {
#		esymb <- "--"
#		prog <- "neato"
#		gtype <- "graph"
#		float <- ifelse(overlap, "\toverlap=true", "\toverlap=scale")
		arrow <- "none"
	}
	
	if (type == "cm") {
		mat[is.na(mat)] <- 0
		if (is.null(dimnames(mat))) { dimnames(mat) <- list(1:nrow(mat), 1:ncol(mat)) }
		nodes <- unique(unlist(dimnames(mat)))
		edges <- rep("",sum(mat!=0))
		E <- 0
		for (i in 1:nrow(mat)) {
			for (j in 1:ncol(mat)) {
				if (mat[i,j] != 0) {
					E <- E + 1
					if (directional) {   # preserve order
						nodeA <- nodes[i]
						nodeB <- nodes[j]
					} else {   # homogenize order to prevent duplicate edges (so, no A->B AND B->A)
						snodes <- sort(nodes[c(i,j)])
						nodeA <- snodes[1]
						nodeB <- snodes[2]
					}
					edges[E] <- paste("\t",nodeA,esymb,nodeB,";",sep="")
				}
			}
		}
	} else if (type == "2m") {
		edges <- rep("",nrow(mat))
		for (i in 1:nrow(mat)) {
			if (directional) {   # preserve order
				nodeA <- mat[i,1]
				nodeB <- mat[i,2]
			} else {   # homogenize order to prevent duplicate edges (so, no A->B AND B->A)
				snodes <- sort(mat[i,])
				nodeA <- snodes[1]
				nodeB <- snodes[2]
			}
			edges[i] <- paste("\t",nodeA,esymb,nodeB,";",sep="")
		}
	} else if (type == "4m") {
		edges <- rep("",nrow(mat))
		subs.1 <- sort(unique(c(mat[,c(1,3)])))
		subs <- vector("list", length=length(subs.1))  # can use "color=", "label=" for "subgraph clusterX { }" blocks
		for (i in 1:nrow(mat)) {
			if (directional) {   # preserve order
#				clustA <- mat[i,1]
#				nodeA <- mat[i,2]
#				clustB <- mat[i,3]
#				nodeB <- mat[i,4]
				ord <- order(mat[i,c(1,3)])   # sort on node name
				nodeA <- mat[i,c(2,4)[ord[1]]]
				clustA <- mat[i,c(1,3)[ord[1]]]
				nodeB <- mat[i,c(2,4)[ord[2]]]
				clustB <- mat[i,c(1,3)[ord[2]]]
			} else {   # homogenize order to prevent duplicate edges (so, no A->B AND B->A)
				ord <- order(mat[i,c(2,4)])   # sort on node name
				nodeA <- mat[i,c(2,4)[ord[1]]]
				clustA <- mat[i,c(1,3)[ord[1]]]
				nodeB <- mat[i,c(2,4)[ord[2]]]
				clustB <- mat[i,c(1,3)[ord[2]]]
			}
#			edges[i] <- paste("\t",nodeA,esymb,nodeB,";",sep="")
			edges[i] <- paste( paste("\t",clustA,esymb,nodeA,";",sep=""), paste("\t",nodeA,esymb,nodeB,";",sep=""), paste("\t",nodeB,esymb,clustB,";",sep=""), collapse="\n")
		}
	}
	graph <- c(paste(gtype,title,"{"), float, paste("\tnode [shape=",geometry,"];",sep=""), edges, "}")
	if (!redundant) { graph <- unique(graph) }
	if (is.null(image.prefix)) {
		return(graph)
	} else {
		graphfile <- paste(image.prefix,"graph",sep=".")
		pngfile <- paste(image.prefix,"png",sep=".")
		write.vector(graph, graphfile)
		if (grepl(.Platform$OS.type,"unix")) { 
			system(paste(prog,"-Tpng -o",pngfile,graphfile));
		} else {
			IM("Cannot create png image on Windows, sorry.  But we wrote the graph file.\n")
		}
	}
}


apa.names$general <- c(apa.names$general, "squeeze")
squeeze <- function (obj, independent=FALSE, recursive=FALSE) {
	 
	## "squeeze" (a la matlab) removes unnecessary dimensions, i.e.:
	##	Lists: sublists of length 1 are converted into vectors (main objective of this function).
	##	Arrays / Matrixes: empty dimensions are dropped.
	## If 'obj' is a list:
	##  "independent": should empty list dimensions be dropped on an element-by-element basis (T) or only if ALL elements have the same empty dimension (F) ?
	##  "recursive": should 'squeeze' descend into list structure?  Otherwise, only squeezes first level.
	
	if (is.list(obj)) {
		if (length(obj) == 1 && !is.ndfl(obj[[1]])) {
			squeezed <- obj[[1]]
		} else {
			if (!independent) { obj2 <- obj }
			nulls <- rep(0, length(obj))
			for (i in 1:length(obj)) {
				if (is.ndfl(obj[[i]]) & length(obj[[i]]) == 1) {
					if (independent) {
						if (recursive & is.ndfl(obj[[i]])) { obj[[i]] <- squeeze(obj[[i]], recursive=recursive, independent=independent) }
						if (is.ndfl(obj[[i]]) & length(obj[[i]]) == 1) { obj[[i]] <- obj[[i]][[1]] }	# post-recursion squeeze
					} else {
						nulls[i] <- 1
						if (recursive & is.ndfl(obj2[[i]])) { obj2[[i]] <- squeeze(obj2[[i]], recursive=recursive, independent=independent) }
						if (is.ndfl(obj2[[i]]) & length(obj2[[i]]) == 1) { obj2[[i]] <- obj2[[i]][[1]] }	# post-recursion squeeze
					}
				}
			}
			ternary (!independent & sum(nulls) == length(nulls), squeezed <- obj2, squeezed <- obj)
		}
	} else if (is.array(obj)) { 
		x <- dim(obj)
		if (any(x == 1)) {		# empty dimensions
			y <- which(x == 1)
			z <- x[which(x != 1)]
			if (length(z) > 2) {			# remain array
				squeezed <- array(obj, dim=z)
			} else if (length(z) == 2) {		# reduce to matrix
				squeezed <- matrix(obj, dim=z)
			} else if (length(z) < 2) {		# reduce to vector
				squeezed <- as.vector(obj)
			}
		} else {
			if (length(x) == 2) {			# reduce to matrix
				squeezed <- matrix(obj, dim=z)
			} else if (length(x) < 2) {		# reduce to vector
				squeezed <- as.vector(obj)
			}
		}
	} else if (is.matrix(obj)) { 
		x <- dim(obj)
		if (any(x == 1)) {
			y <- which(x == 1)
			z <- x[which(x != 1)]
			if (length(z) < 2) {			# reduce to vector
				squeezed <- as.vector(obj)
			}
		} else {
			if (length(x) < 2) {			# reduce to vector
				squeezed <- as.vector(obj)
			}
		}
	} else {
		stop("Only lists, arrays and matrixes accepted!\n") 
	}
	
	if (length(squeezed) == 0) {		# no data?
		squeezed <- new(class(obj))
	}
	
	return(squeezed)
}


apa.names$general <- c(apa.names$general, "wring")
wring <- function(obj, rmv=0) {
	
	## Removes empty rows/cols from a matrix or array
	## "empty" can be defined as all-zero, all-NA, all-"", etc,.
	## put "empty" value(s) into the 'rmv' vector.
	
	if (length(rmv)==0) {
		message("'rmv' empty: nothing to remove")
		return(obj)
	} else if (is.matrix(obj)) {
		dim.rmv <- list()
		for (i in 1:nrow(obj)) {
			if (all(obj[i,]) %in% rmv) dim.rmv[[1]] <- c(dim.rmv[[1]], i)
		}
		for (j in 1:ncol(obj)) {
			if (all(obj[,j]) %in% rmv)  dim.rmv[[2]] <- c(dim.rmv[[2]], j)
		}
		if (length(dim.rmv[[1]])>0) {
			obj <- obj[-dim.rmv[[1]],]
		}
		if (length(dim.rmv[[2]])>0) {
			obj <- obj[,-dim.rmv[[2]]]
		}
	} else if (is.array(obj)) {
		d <- dim(obj)
		interp <- rep("",2*d-1)
		interp[seq(2,d-1,2)] <- ","
		dim.j <- seq(1,d,2)
		for (i in 1:length(d)) {  # for each dimension i
			rmv.j <- c()
			for (j in 1:d[i]) {  # for each j in dimension i
				interp.j <- interp
				interp.j[dim.j[i]] <- j   # to index
				dimstr <- paste(interp.j,collapse="")  # creates dim string for array, e.g. ",,3,"
				if (all(eval(parse(text=paste("obj[",dimstr,"]",sep=""))) %in% rmv)) rmv.j <- c(rmv.j, j)
			}
			if (length(rmv.j)>0) {
				interp.j2 <- interp
				interp.j2[dim.j[i]] <- paste("-c(",paste(rmv.j,collapse=","),")",sep="")  # vector of removals for this dim
				rmvstr <- paste(interp.j2,collapse="") # creates dim anti-selection string for array, e.g. ",,-c(1,3,4),"
				obj <- eval(parse(text=paste("obj[",rmvstr,"]",sep="")))
			}
		}
	}
	obj
}


apa.names$general <- c(apa.names$general, "extract.calls")
extract.calls <- function(func, full=TRUE, max.depth=NA) {
	
	## Extracts all function calls used by the function
	## DOES NOT WORK ON INTERNALS OR PRIMITIVES
	## 'func' is either the function or the function name
	## 'full=T' returns the entire call; 'full=F' returns only the names of the functions
	
	stop("UNDER CONSTRUCTION")  ##### critical problem: functions defined within functions are represented as integer vectors, not actual source code
	
	if (is.character(func)) func <- get(func)
	if (is.na(max.depth)) max.depth <- .Options$expressions	# current recursion limit
	
	recurse <- function(x, j) {
		IM(j, length(x))
		y <- vector("list", length=length(x))
		for (i in 1:length(x)) {
			if (length(x[[i]])>1) {
				if (all(sapply(x[[i]],length)==1)) {
					IM(i, x[[i]])
					y[[i]] <- x[[i]][[1]]
				} else {
					y[[i]] <- recurse(x[[i]], j+1)
				}
			}
		}
		y
	}
	
	if (length(body(func))==0) {
		NA
	} else {
		calls <- unique(unlist(recurse(as.list(body(func)),0)))
		return(calls)
		if (full) {
			calls2 <- sort(calls)
		} else {
			calls2 <- sort(unique(sapply(calls), function(x) sub("\\(.*","",x) ))
		}
		setdiff(calls2, c("+","=","==","!=","-","/",">","<","<-","<<-","*","%%","%in%","%*%","%/%","^"))
	}
}


apa.names$general <- c(apa.names$general, "grok")
grok <- function(obj, max.depth=0, trace=FALSE) {
	
	## Attempts to deparse all useful information about an object into a list, which can also become a list representation of the object.
	## "max.depth" sets max recursion depth.  "0" prevents recursion.  "NA" allows unlimited recursion.
	## "trace" reports a bunch of messages which track the current (recursion) position in the object
	
	listCapture <- function(lst) {
		cap <- vector("list", length=length(lst))
		names(cap) <- names(lst)
		for (i in 1:length(lst)) { cap[[i]] <- capture.output(lst[[i]]) }
		return(cap)
	}
	
	getBasic <- function(x) {
		basic <- list()
		basic$length <- ifelse(is.null(length(x)), NA, length(x))
		ternary (is.null(dim(x)), basic$dim <- NA, basic$dim <- dim(x))
		ternary (is.null(names(x)), basic$names <- NA, basic$names <- names(x))
		ternary (is.null(dimnames(x)), basic$dimnames <- NA, basic$dimnames <- dimnames(x))
		basic$typeof <- typeof(x)
		basic$storage.mode <- storage.mode(x)
		basic$mode <- mode(x)
		basic$class <- class(x)
		basic$is.vector <- is.vector(x)
		basic$is.atomic <- is.atomic(x)
		basic$is.S4 <- isS4(x)
		if (class(x) == "data.frame") {
			if (ncol(x) > 0) {
				basic$column.types <- matrix("", nrow=3, ncol=ncol(x))
				colnames(basic$column.types) <- colnames(x)
				rownames(basic$column.types) <- c("storage.mode","mode","class")
				for (i in 1:ncol(x)) { 
					basic$column.types[1,i] <- storage.mode(x[,i])
					basic$column.types[2,i] <- mode(x[,i])
					basic$column.types[3,i] <- class(x[,i])
				}
			}
		}
		basic$object.size <- object.size(x)
		basic$env.size <- 0			# fill later (maybe)
		basic$total.size <- object.size(x)	# increase later (maybe)
		basic$depth <- 1			# increase later (maybe)
		basic$classRepresentation <- getClass(class(x))
		basic$.NAMES <- c(".NAMES", names(basic), "this.depth")	# last gets added later
		basic <- basic[c(length(basic),2:length(basic)-1)]	# put .NAMES in front
		return(basic)
	}
	
	getAdvanced <- function(x) {
		advanced <- slot.attributes <- list()
		advanced$.NAMES <- c()			# fill later
		
		y <- getClass(class(x))
		z <- attributes(x)
		advanced$"@access "<- y@access
		advanced$"@className" <- y@className
		advanced$"@package" <- y@package
		advanced$"@contains" <- y@contains
		advanced$"@slots" <- y@slots
		advanced$"@prototype" <- y@prototype
		advanced$"@subclasses" <- y@subclasses
		advanced$"@virtual" <- y@virtual
		advanced$slotsFromS3 <- slotsFromS3(x)
		if (length(z) > 0) { advanced$attributes <- listCapture(z) }
		
		if (length(y@slots) > 0) {
			z1 <- y@slots
			zn <- intersect(names(z1), names(z))	# class attributes (slots)
			if (length(zn) > 0) {
				z1 <- z1[match(zn, names(z1))]
				z1 <- z1[order(names(z1))]
				z <- z[match(zn, names(z))]
				z <- z[order(names(z))]
				
				slot.attributes <- vector("list", length=length(zn))	# redefine, if actually being used
				names(slot.attributes) <- zn
				for (i in 1:length(zn)) {
					slot.attributes[[i]]$class <- z1[[i]]
					slot.attributes[[i]]$data <- capture.output(z[[i]])
				}
			}		
		}
		
# ??		advanced$methods <- (x)
# !		advanced$labels <- labels(x)	# reclass (?) these things so it only shows head (initially) and not all?
		advanced$.NAMES <- c(".NAMES", names(advanced))
		advanced <- advanced[c(length(advanced),2:length(advanced)-1)]	# put .NAMES in front
		return( list(advanced, slot.attributes) )
	}
	
	getEnvironment <- function(x) {
		envir <- list()
		envir$.NAMES <- c()			# fill later
		envir$name <-  environmentName(x)
		envir$address <- x
		envir$object.size <- object.size(as.list.environment(x))
		envir$ls <- ls(envir=x)
		envir$env.profile <- env.profile(x)
		envir$.NAMES <- c(".NAMES", names(envir))
		envir <- envir[c(length(envir),2:length(envir)-1)]	# put .NAMES in front
		return(envir)
	}
	
	investigate <- function(obj, depth.now, max.depth) {
		
		# recurses to max object depth and constructs list representation of the object
		
		depth.now <- depth.now + 1
		if (trace) { IM(depth.now, ":Start") }
		temp.depth <- env.size <- 0
		this <- list()
		if (trace) { IM(depth.now, ":Basic") }
		this$basic <- getBasic(obj)
		if (trace) { IM(depth.now, ":Adv") }
		adv <- getAdvanced(obj)
		if (trace) { IM(depth.now, ":Post") }
		this$class <- adv[[1]]
		if (length(adv[[2]]) > 0) { this$slot.attributes <- adv[[2]] }
		if (is.environment(obj)) { 
			if (trace) { IM(depth.now,":Env") }
			this$environment <- getEnvironment(obj)
			env.size <- this$environment$object.size
		} else {
			if (is.ndfl(obj) & length(obj) > 0) {			# recurse through subelements
				if (trace) { IM(depth.now,":ndfl") }
				this$elems <- vector("list", length=length(obj))
				names(this$elems) <- names(obj)
				if (depth.now < max.depth) {	# then we can go one more level
					for (i in 1:length(obj)) {
						if (trace) { IM(depth.now, names(obj)[i]) }
						result <- investigate(obj[[i]], depth.now, max.depth)
						this$elems[[i]] <- result[[1]]					# Returned subdata
						env.size <- env.size + result[[2]]				# Returned env.size
						if (result[[3]] > temp.depth) { temp.depth <- result[[3]] }	# Returned depth
					}
				}
			}
			if (length(this$class$"@slots") > 0) {	# recurse through slots
				if (trace) { IM(depth.now,":slots") }
				this$slots <- vector("list", length=length(this$class$"@slots"))
				names(this$slots) <- names(this$class$"@slots")
				if (depth.now < max.depth) {	# then we can go one more level
					z <- attributes(obj)
					for (i in 1:length(z)) {
						if (names(z)[i] != "class") {	# redundant
							if (trace) IM(depth.now, names(z)[i])
							result <- investigate(z[[i]], depth.now, max.depth)
							this$slots[[i]] <- result[[1]]					# Returned subdata
							env.size <- env.size + result[[2]]				# Returned env.size
							if (result[[3]] > temp.depth) temp.depth <- result[[3]]	# Returned depth
						}
					}
				}
			}
		}
		if (trace) IM(depth.now,":End")
		temp.depth <- temp.depth + 1	# account for 'this' itself (thus min depth always = 1)
		this$basic$this.depth <- depth.now
		this$basic$depth <- temp.depth
		this$basic$env.size <- env.size
		return ( list(this, env.size, temp.depth) )
	}
	
	if (is.na(max.depth)) max.depth <- .Options$expressions	# current recursion limit
	data <- investigate(obj, 0, max.depth)
	return( data[[1]] )
}


#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################


apa.names$graphics <- c(apa.names$graphics, "show.styles")
show.styles <- function() {
    
    ## Plots pch, font, lty, lwd styles

    par(mar=c(1,1,2,1))
    null.plot(xlim=c(0.6,5), ylim=c(0,26))
    points(rep(1.1,26), 0:25, pch=25:0, col=1)
    text(rep(1.1,26), 25:0, labels=0:25, pos=2)
    rect(0.82, -0.5, 1.18, 4.5, col=NA, border=1)
    text(0.63, 2, labels="Have\n'bg'")
    
    text(rep(2.5,6), seq(16,24,2)+1, labels=paste("Font",5:1), font=5:1)
    
    segments(rep(2,6), seq(1,11,2), rep(3,6), seq(1,11,2), lty=6:1)
    text(rep(2,6), seq(1,11,2), labels=6:1, pos=2)

    lwds <- c(11:1,0.5,0.1)
    segments(rep(4,6), seq(1,25,2), rep(5,6), seq(1,25,2), lty=1, lwd=lwds)
    text(rep(4,6), seq(1,25,2), labels=lwds, pos=2)
    text(4, -0.25, "...", font=2, pos=2)
    
    text(c(1.1,2.5,2.5,4.5), c(26.5,26.5,13,26.5), labels=paste(c("PCH","FONT","LTY","LWD"),"STYLES"), font=2)
}


apa.names$graphics <- c(apa.names$graphics, "null.plot")
null.plot <- function(main="", xlab="", ylab="", ...) {
	
	## Plots a completely blank plot (spacer plot to use in multi-plot images)
	## Use '...' to pass in other parameters to "plot", if desired
#	## Can include a title, if it is useful to mark a grid position for unplottable data
#	## Also use "x" and "y" if dimensions matter, e.g. blank plot as backdrop for preformatted text with x/y coords, etc.
	
	plot(x=c(0,1), y=c(0,1), col=0, axes=FALSE, main=main, xlab=xlab, ylab=ylab, ...)
}


apa.names$graphics <- c(apa.names$graphics, "view.image")
view.image <- function(imgfile) {
	com <- switch(Sys.info()[["sysname"]], 
		"Windows"=paste(Sys.getenv("COMSPEC"), "/c", imgfile),
		"Linux"=paste("gthumb", imgfile, "&"),
		"Darwin"=paste("open", imgfile, "&"),
		NA
		)
	if (is.na(imgfile)) {
		stop(paste("Image file '",imgfile,"' not valid!\n",sep=""))
	} else if (is.na(com)) {
		stop(paste("Unknown system type '",Sys.info()[["sysname"]],"'!  Must be Windows, Linux, or Darwin\n",sep=""))
	} else {
		system(com)
	}
}


apa.names$graphics <- c(apa.names$graphics, "view.colormap")
view.colormap <- function() {
	view.image(paste(utils.path,"RColorMap.png",sep="/"))
}


apa.names$graphics <- c(apa.names$graphics, "viewPalette")
viewPalette <- function (ramp=palette(), main=NULL, ranges=NULL, labels=NULL, bgcol=0, fontcol=1, cex=1, rgb.mcv=FALSE, values=TRUE) {
    
    ## Visualizes an arbitrary palette, with or without an associated numeric range.
    ## ramp = char vector of hex values for palette.
    ## ranges = num vector of length 2, i.e. c(start, end) of numeric ranges to be associated with color breaks.
    ## ann = T/F, show axis annotations? (supercedes showranges).
    ## title = character string; a title for the plot.
    ## bgcol = color name or default palette number; changes background color.  
    ## fontcol = color name or default palette number; changes text color.  
    
    showranges <- ifelse(length(ranges)==0, FALSE, TRUE)
    ramp <- rev(ramp)
    N <- length(ramp)
    yvar <- 1/N
    yvals <- vector("numeric", length=2*N)
    breaks <- seq(0, 1, by=yvar)       # color block edges, range labels
    label.y <- breaks[1:N] + yvar/2    # all other labels
    
    if (length(labels)>0) {
        if (length(labels) != N) stop("Length of 'labels' and 'ramp' must be equal!\n")
        labels <- rev(labels)
    } else {
        labels <- ramp
    }
    
    ## There will be 3 general columns: Left=ranges (may be hidden); Center=color blocks; Right=labels & values (4 sprintf-ed columns)
    ## Separating between blocks and annotations given by 'anngap'
    ## Careful when modifying; these are hard-wired config settings for an expected plot layout 
    anngap <- 0.1  # gap between color blocks and block names
    cgap <- "   "  # gap between sprintf-ed columns
    block.x <- 1:2
    annot.x <- block.x[2]+anngap
    range.x <- 1-3:1*anngap
    xlim <- c(1,ifelse(values,7,3))
    
    if (showranges) {
        if (length(ranges)-1 == length(ramp)) {
            ## expectedsituation
            range.labs <- ranges
        } else if (length(ranges)==2) {
            ## gave range start-end, apparently?  interpolate breaks.
            range.labs <- seq(ranges[1], ranges[2], length=N+1)
        } else {
            ## give up
            stop("Length of 'ranges' not conformable to length of 'ramp'!")
        }
        
        range.vec <- c("Ranges",ranges)
#        range.labs <- sprintf(paste("%-",max(nchar(range.vec)),"s",sep=""), range.vec)
        xlim[1] <- 0  # make room for ranges on left side
    }
    
    labs1 <- as.matrix(do.call(cbind, list(
        Labels=c("Labels",labels),
        Hex=c("Hex",rgb2(col2rgb(ramp))),
        RGB=c("RGB",apply(col2rgb(ramp),2,function(x) sprintf("%03d,%03d,%03d",x[1],x[2],x[3]))),
        HSV=c("HSV",apply(round(col2hsv(ramp),3),2,function(x) sprintf("%4.3f,%4.3f,%4.3f",x[1],x[2],x[3])))
    )))
    
    if (rgb.mcv) {
        labs1[,3] <- c("RGB (M,CV)",apply(col2rgb(ramp),2,function(x) sprintf("%03d,%03d,%03d (%03d,%3.2f)",x[1],x[2],x[3],round(mean(x),0),CV(x))))
        colnames(labs1)[3] <- "RGB (M,CV)"
    }
    
    labw <- sapply(1:ncol(labs1), function(i) max(nchar(c(names(labs1)[i],labs1[,i]))) )
    labs <- sapply(1:nrow(labs1), function(i){
        x <- labs1[i,]
        rampi <- i-1
        if (rampi>0) if (is.na(ramp[rampi])) x[2:4] <- NA  # because labs1[1,] is the header and labs1[2:nrow,] correspond to ramp
        if (values) {
            sprintf(paste0("%-",labw[1],"s",cgap,"%-",labw[2],"s",cgap,"%-",labw[3],"s",cgap,"%-",labw[4],"s"), x[1], x[2], x[3], x[4])
        } else {
            sprintf(paste0("%-",labw[1],"s"), x[1])
        }
    })
    label.headers <- labs[1]
    labs <- labs[2:length(labs)]
    
    ## Plot color blocks
    par(mar=c(1,0,ifelse(length(main)>0,3,1),0), family="mono", bg=bgcol, yaxs="i")
    null.plot(xlim=xlim, col.main=fontcol, cex.main=2)
    for (i in 1:N) {
        ternary(is.na(ramp[i]), dens <- 10, dens <- NULL)
        rect(block.x[1], breaks[i], block.x[1]+1, breaks[i+1], density=dens, col=ramp[i], border=FALSE)
    }
    
    ## Annotate plot
    if (length(main)>0) mtext(main, 3, 1.5, FALSE, mean(xlim), NA, NA, cex, 1, 2, las=1)  # surrogate plot 'main'
    mtext('Color', 3, 0, FALSE, mean(block.x), NA, NA, cex, fontcol, 2, las=1)            # color block column header
    mtext(label.headers, 3, 0, FALSE, annot.x, 0, NA, cex, fontcol, 2, las=1)             # annotations column header
    text(annot.x, label.y, adj=c(0,0.5), col=fontcol, labels=labs, cex=cex)               # annotations column labels & values
    
    if (showranges) {
        segments(range.x[3], breaks[1], range.x[3], breaks[N+1], col=fontcol)                                     # vertical tick baseline
        for (i in 1:(N+1)) segments(range.x[3], breaks[i], range.x[2], breaks[i], col=fontcol)                    # ticks
        text(range.x[1], breaks, adj=c(1,0.5), col=fontcol, labels=format(range.labs, digits=2), cex=cex, las=2)  # range labels
        text(range.x[1], col.header.y, adj=c(1,0.5), col=fontcol, labels="Ranges", cex=cex, font=2, las=2)        # ranges column header
    }
}


apa.names$graphics <- c(apa.names$graphics, "palettizer")
palettizer <- function (palette=NULL, n.colors=NA, interpolate=NULL, halves=NULL, reverse=FALSE) {
    
    ## Custom & RColorBrewer palette support for functions in apa_tools.R
    ## "n.colors=NA" returns the ramp function itself; othwerise the specified number of ramp colors
    ##  Note: the system color functions { rainbow heat.colors topo.colors terrain.colors } cannot be reversed until actualized as a palette.
    ## 'halves' is for working with centered color ranges, and returns 2 half-palettes instead of 1 full palette.  Arg value is length-2 vector with resolution depth for each half.
    
    if (!is.na(n.colors)) {
        if (n.colors > 512) {
            message("n.colors may not exceed 512!  Setting to 512.\n")
            n.colors <- 512
        }
    }
    interp <- function(default) ifelse(is.null(interpolate), default, interpolate)
    
    ## Define multiple-use colorsets here
    
    rb6 <- rev(c("red","orange","yellow","green","blue","purple3"))  #aka ROYGBP; basis for some other palettes below
    col17 <- c("deeppink2","magenta","red","red4","darkorange","yellow","gold3","chartreuse","green3","green4","cyan","darkcyan","dodgerblue","blue","purple3","sienna4","grey30")
   
    ## Define palettes here -- add new palettes to 'allramps' unless they require special construction, then add below
    
    rcb.reds <- c("#FFF5F0","#FEE0D2","#FCBBA1","#FC9272","#FB6A4A","#EF3B2C","#CB181D","#A50F15","#67000D")   # RColorBrewer "Reds"
    rcb.greens <- c("#F7FCF5","#E5F5E0","#C7E9C0","#A1D99B","#74C476","#41AB5D","#238B45","#006D2C","#00441B") # RColorBrewer "Greens"
    rcb.blues <- c("#F7FBFF","#DEEBF7","#C6DBEF","#9ECAE1","#6BAED6","#4292C6","#2171B5","#08519C","#08306B")  # RColorBrewer "Blues"
    
    ## Default palette set in 'allramps' declaration; built with every call.
    ## Additional palettes defined below that, but not built/loaded unless called for.
    ## Each element in 'allramps' is c(color scheme, default interpolation, palette type, description)
    
    allramps <- list(
        
        ## Sequential Palettes
        BY=list(c("blue","yellow"), interp("linear"), "seq", "Blue Yellow"),
        KBY=list(c("black","blue","yellow"), interp("linear"), "seq", "Black Blue Yellow"),
        KPBY=list(c("black","purple3","blue","yellow"), interp("linear"), "seq", "Black Purple Blue Yellow"),
        KPBG=list(c("black","purple3","blue","green"), interp("linear"), "seq", "Black Purple Blue Green"),
        BCGY=list(c("blue","cyan","green","yellow"), interp("linear"), "seq", "Blue Cyan Green Yellow"),
        RYG=list(c("red","yellow","green"), interp("spline"), "seq", "Red Yellow Green"),
        ROYGC=list(c("red","darkorange","yellow","green","cyan"), interp("spline"), "seq", "Red Yellow Green Cyan"),
        RGB=list(c("red","green","blue"), interp("spline"), "seq", "Red Green Blue"),
        KW=list(c("white","black"), interp("linear"), "seq", "Black White"),
        rainblo=list(rb6, interp("spline"), "seq", "ROYGBP"),
        rainblo.k=list(c("black",rb6), interp("spline"), "seq", "ROYGBP Black"),
        
        ## Sequential System Palettes & Their Derivatives
        grey=list(grey.colors(2), interp("linear"), "seq", "system"),
        gray=list(gray.colors(2), interp("linear"), "seq", "system"),
        rainbow=list(rainbow, "", "seq", "system"),
        topo=list(topo.colors, "", "seq", "system"),
        terrain=list(terrain.colors, "", "seq", "system"),
        terrain.plus=list(c("blue",terrain.colors(7),"white"), interp("linear"), "seq", "Blue [terrain.colors] White"),
        heat=list(heat.colors, "", "seq", "system"),
        heat.plus=list(c(heat.colors(5),"lemonchiffon","white"), interp("linear"), "seq", "[heat.colors] Lemonchiffon White"),
        
        ## Modified Sequential RColorBrewer Palettes
        Reds0=list(c("white",rcb.reds), interp("linear"), "seq", "RColorBrewer 'Reds', terminates in white"),
        Greens0=list(c("white",rcb.greens), interp("linear"), "seq", "RColorBrewer 'Greens', terminates in white"),
        Blues0=list(c("white",rcb.blues), interp("linear"), "seq", "RColorBrewer 'Blues', terminates in white"),
        
        ## Diverging Palettes
        cm=list(cm.colors, "", "div", "system"),							# system palette
        cm2=list(cm.colors(3), interp("linear"), "div", "system, but with linear interpolation"),
        CKY=list(c("cyan","black","yellow"), interp("spline"), "div", "Cyan Black Yellow"),
        CWY=list(c("cyan","white","yellow"), interp("spline"), "div", "Cyan White Yellow"),
        RKG=list(c("green3","black","red"), interp("spline"), "div", "Red Black Green"),
        RWG=list(c("green3","white","red"), interp("spline"), "div", "Red White Green"),
        RKB=list(c("blue","black","red"), interp("spline"), "div", "Red Black Blue"),
        RWB=list(c("blue","white","red"), interp("spline"), "div", "Red White Blue"),
        VKA=list(c("gold","black","magenta2"), interp("spline"), "div", "Violet Black Amber"),
        VWA=list(c("gold","white","magenta2"), interp("spline"), "div", "Violet White Amber"),
        GCWYR=list(c("green",5,"white",7,2), interp("linear"), "div", "Green Cyan White Yellow Red"),
        
        ## Definitions for various user-requested odds and ends
        ROYGm=list(c("firebrick3","darkorange","gold","forestgreen"), interp("spline"), "seq", "Red Orange Yellow Green (muted)"),
        heatm=list(c("firebrick3","darkorange","gold","white"), interp("linear"), "seq", "[heat.colors]-ish muted, fade to white"),
        heatb1=list(c("firebrick3","darkorange","gold","black"), interp("linear"), "seq", "[heat.colors]-ish muted, fade to black"),
        heatb2=list(c("firebrick3","darkorange","gold","forestgreen","black"), interp("linear"), "seq", "[heat.colors]-ish muted, fade to green, black"),
        
        ## Categorical Palettes
        super18=list(c(rb6, hsv.tweak(rb6,s=-0.6), hsv.tweak(rb6,v=-0.6)), "", "cat", "18 colors: {bright ROYGBP} + {pale ROYGBP} + {dark ROYGBP}"),
        super34=list(c(col17, hsv.tweak(col17,s=-0.5,v=-0.1)), "", "cat", "34 colors: {col-17} + {greyed col-17}")
        
    )
    
    ## Palettes with special handling go here
    
    if (length(palette) == 0) {

        pnames <- names(allramps)
        types <- unlist(slice.list(allramps,3))
        descs <- unlist(slice.list(allramps,4))
        fmt <- paste0(" %-",max(nchar(c(pnames,"Aparna.Reds","blackbody.2","blackbody.10"))),"s   %s")
        
        message(paste(c(
            "\nNo name or value for 'palette' given!\nAvailable built-in palette names:",
            "\n Sequential:",
            sapply(which(types=="seq"), function(i) sprintf(fmt, pnames[i], descs[i]) ),
            sprintf(fmt, "Aparna.Reds", "RColorBrewer 'Reds', blued up slightly"),
            sprintf(fmt, "blackbody.2", "CIE 1931 2-degree CMFs w/ Judd-Voss Corrections"),
            sprintf(fmt, "blackbody.10", "CIE 1964 10-degree CMFs"),
            "\n Diverging:",
            sapply(which(types=="div"), function(i) sprintf(fmt, pnames[i], descs[i]) ),
            "\n Categorical:",
            sapply(which(types=="cat"), function(i) sprintf(fmt, pnames[i], descs[i]) ),
            "\n And all RColorBrewer palette names\n"
        ),collapse="\n"))
        return()
        
    } else {
        
        ## 'Aparna.Reds' -- only create if invoked
        ## A slightly blued-up version of RColorBrewer's "Reds"; more cherry-red than blood-red
        if (palette[1] == "Aparna.Reds") {
            if (!require("RColorBrewer")) stop("Palette 'Aparna.Reds' requires the RColorBrewer library, but it couldn't be loaded.\n")
            RCB.Reds <- colorRampPalette( brewer.pal(brewer.pal.info[match("Reds",rownames(brewer.pal.info)),1],"Reds"), interp("spline") )
            Aparna.Reds <- col2rgb(RCB.Reds(256))
            Aparna.Reds[2,] <- round(Aparna.Reds[2,]-10,0)  # reduce green
            Aparna.Reds[3,] <- round(Aparna.Reds[3,]+10,0)  # boost blue
            Aparna.Reds[Aparna.Reds<0] <- 0
            Aparna.Reds[Aparna.Reds>255] <- 255
            allramps$Aparna.Reds=list(c("white",rgb(t(Aparna.Reds)/255)), interp("linear"), "seq", "RColorBrewer 'Reds', blued up slightly")
        }
        
        ## 'Blackbody.*' -- only load (from file) if invoked
        if (grepl("^blackbody",palette[1])) {
            if (!exists("blackbody.colors")) {
                ## blackbody radiation colors, taken from tables at http://www.vendian.org/mncharity/dir3/blackbody/UnstableURLs/bbr_color.html
                temp <- read.delim(paste(utils.path,"blackbody_colors.txt",sep="/"), sep="\t", as.is=TRUE, skip=1)
                #####  GLOBAL ASSIGN  !!!!!
                blackbody.colors <<- list(CIE2deg=temp[temp[,2]=="1931 2 deg",c(1,3)], CIE10deg=temp[temp[,2]=="1964 10 deg",c(1,3)])
                #####  GLOBAL ASSIGN !!!!!
                apa.names$data <<- unique(c(apa.names$data,"blackbody.colors"))
            }
            ## blackbody radation colors, CIE 1931 2-degree CMFs w/ Judd-Voss Corrections
            allramps$blackbody.2 <- list(blackbody.colors$CIE2deg[,2], interp("linear"), "seq", "CIE 1931 2-degree CMFs w/ Judd-Voss Corrections")
            ## blackbody radation colors, CIE 1964 10-degree CMFs
            allramps$blackbody.10 <- list(blackbody.colors$CIE10deg[,2], interp("linear"), "seq", "CIE 1964 10-degree CMFs")
        }
        
        if (length(palette) > 1) {
            
            ## Custom palette vector, NOT a name
            
            ColorRamp <- 
                if (reverse) { 
                    colorRampPalette(rev(palette), interpolate=interp("linear"))
                } else {
                    colorRampPalette(palette, interpolate=interp("linear"))
                }
            ## assume diverging if odd num colors.  At least, can treat as diverging.
            paltype <- ifelse(length(palette) %% 1 == 0, 'div', 'seq')
            
        } else {
            
            ## Named palette
            
            oknames <- paste(names(allramps), collapse="', '")
            diemsg <- paste("Palette name must be one of:\n '",oknames,"'\n Also supports RColorBrewer palette names, if library is loaded.\n",sep="")
            
            if (!is.character(palette)) { 
                
                ## what?
                stop(diemsg) 
                
            } else if (palette %in% names(allramps)) {
                
                ## Palette name found in 'allramps'
                ramp <- allramps[[palette]]
                if (is.function(ramp[[1]])) {
                    ## system palette functions
                    ColorRamp <- ramp[[1]]
                    paltype <- 'func'
                } else if (ramp[[3]] == "cat") {
                    if (length(ramp[[1]]) < n.colors) stop(paste0("Requested colors (",n.colors,") exceeds categorical Palette '",palette,"' maximum (",length(ramp[[1]]),")!"))
                    ColorRamp <- ramp[[1]]
                    paltype <- ramp[[3]]
                } else {
                    ## color vectors to convert into functions
                    ColorRamp <- 
                        if (reverse) { 
                            colorRampPalette(rev(ramp[[1]]), interpolate=ramp[[2]])
                        } else {
                            colorRampPalette(ramp[[1]], interpolate=ramp[[2]])
                        }
                    paltype <- ramp[[3]]
                }
                
            } else {
                
                ## Palette name not found; check RColorBrewer
                if (require("RColorBrewer")) {
                    RCB.ok <- match(palette, rownames(brewer.pal.info))
                    if (is.na(RCB.ok)) {
                        ## RColorBrewer loaded, but does not contain your palette
                        stop(diemsg)
                    } else {
                        ## RColorBrewer loaded and your palette was found
                        rcb.ncol <- brewer.pal.info[RCB.ok,1]
                        paltype <- as.character(brewer.pal.info[RCB.ok,2])
                        if (paltype == "qual") {
                            if (rcb.ncol < n.colors) stop(paste0("Requested colors (",n.colors,") exceeds categorical RColorBrewer palette '",palette,"' maximum (",rcb.ncol,")!"))
                            ColorRamp <- brewer.pal(rcb.ncol,palette)
                            paltype <- "cat"
                        } else {
                            ## OK palette to convert
                            ColorRamp <- 
                                if (reverse) {
                                    colorRampPalette( rev(brewer.pal(rcb.ncol,palette)), interpolate=interp("spline") )
                                } else {
                                    colorRampPalette( brewer.pal(rcb.ncol,palette), interpolate=interp("spline") ) 
                                }
                        }
                    }
                } else {
                    stop("Unknown palette name, and couldn't check RColorBrewer because library couldn't be loaded.\n")
                }
                
            }
        }
    }
    
    if (length(halves)==2) {
        
        ## Usually used for divergent palette, centered at zero, but applied to imbalanced data range.  Create two half-palette functions.
        
        if (paltype != "div") stop("Halves are only returned for diverging palettes!\n")
        realized <- ColorRamp(257)  # always realize at maximum resolution (> max because we need an odd number)
        half.ramps <- list( LOWER=colorRampPalette(realized[1:128]), CENTER=colorRampPalette(realized[129]), UPPER=colorRampPalette(realized[130:257]) )  # midpoint color MUST BE SEPARATE
        if (is.na(n.colors)) {
            half.ramps
        } else {
            list( LOWER=half.ramps$LOWER(halves[1]), CENTER=half.ramps$CENTER(1), UPPER=half.ramps$UPPER(halves[2]) )
        }
        
    } else if (length(halves)==2) {
        
        stop("'halves' value must be an integer vector of length 2!\n")
        
    } else {
        
        ## Normal palette handling
        
        if (is.na(n.colors)) {
            ColorRamp
        } else if (paltype == 'func') {
            ## if actualizing a system color function, we can reverse it here
            ternary(reverse, rev(ColorRamp(n.colors)), ColorRamp(n.colors))
        } else if (paltype == "cat") {
            ## categorical palettes are not interpolated
            ColorRamp[1:n.colors]
        } else {
            ColorRamp(n.colors)
        }
    }
}


apa.names$graphics <- c(apa.names$graphics, "mask.palette")
mask.palette <- function (base.col="grey50", levels=2, alpha.min=0, alpha.max=0.75) {
    
    ## Creates a transparency palette for masking myImagePlotUltra, heat.map, etc (using image(add=T))
    
    ColorRamp <- colorRampPalette(c(base.col,"white"), interpolate="linear")
    amin.255 <- round(255 * alpha.min, 0)
    amax.255 <- round(255 * alpha.max, 0)
    alpha.grad <- as.hexmode(seq(amax.255, amin.255,length.out=levels)[1:(levels-1)])
    ramp <- ColorRamp(levels)
    ramp[levels] <- amin.255
    ramp[1:(levels-1)] <- paste(ramp[1:(levels-1)], alpha.grad, sep="")
    return(ramp)
}


apa.names$graphics <- c(apa.names$graphics, "rgb2")
rgb2 <- function(x, pct=FALSE) {
    
    ## Modified rgb() function designed to handle col2rgb() output directly, instead of in pieces; also single vectors.
    ## Example: Create an RGB matrix with col2rgb(), then try to convert back using rgb() on the matrix.
    ##          Doesn't work!  Must input 3-4 rows separately: rgb2() fixes this.
    ## 		Also cannot process atomic vectors with rgb(): rgb2() fixes this.
    ## x = 1. a 3-4 component vector as c(R,G,B) or c(R,G,B,alpha), or 
    ##     2. a 3-4 row matrix, e.g. col2rgb() output or something like it (rows 1,2,3 = R,G,B; 1 col per color; optional row 4 = alpha).
    ## pct = T/F: either 'x' has integers on [0,255] and "pct=F", or 'x' has decimals on [0,1] with "pct=T"
    
    if (!pct) {
        if (any(zapsmall(x)!=trunc(x))) {
            stop("Non-integer 'x' detected, but 'pct' is FALSE.  Stopping.")
        } else if (max(x) <= 1 & !all(c(x)==0)) {
            warning("Input values are on [0,1], but 'pct' is FALSE: are you sure?\n", call. = TRUE, immediate. = TRUE)
        }
        x <- x / 255	# normalize to [0,1]; rgb() assumes maxColorValue==1
    }
    if (is.null(dim(x))) {
        if (length(x) == 4) {		# alpha-containing vector
            rgb(x[1],x[2],x[3],alpha=x[4])
        } else if (length(x) == 3) {	# plain RGB vector
            rgb(x[1],x[2],x[3])
        } else {
            stop("Input vector was not of length 3 or 4!\n")
        }
    } else {
        if (nrow(x) == 4) {		# alpha-containing matrix
            apply(x, 2, FUN=function(v) rgb(v[1],v[2],v[3],alpha=v[4]) )
        } else if (nrow(x) == 3) {	# plain RGB matrix
            apply(x, 2, FUN=function(v) rgb(v[1],v[2],v[3]) )
        } else {
            stop("Input matrix was not of dimension 3xN or 4xN!\n")
        }
    }
}


apa.names$graphics <- c(apa.names$graphics, "hsv2")
hsv2 <- function(x) {
    
    ## Modified hsv() function designed to handle rgb2hsv() output directly, instead of in pieces; also single vectors.
    ## Example: Create an HSV matrix with rgb2hsv(), then try to convert back using hsv() on the matrix.
    ##          Doesn't work!  Must input 3-4 rows separately.  hsv2() fixes this.
    ## 		Also cannot process atomic vectors with hsv().  hsv2() fixes this.
    ## x = 1. a 3-4 component vector as c(H,S,V) or c(H,S,V,alpha), or 
    ##     2. a 3-4 row matrix, e.g. rgb2hsv() output or something like it (rows 1,2,3 = H,S,V; 1 col per color; optional row 4 = alpha).
    
    if (is.null(dim(x))) {
        if (length(x) == 4) {		# alpha-containing vector
            hsv(x[1], x[2], x[3], alpha=x[4])
        } else if (length(x) == 3) {	# plain HSV vector
            hsv(x[1], x[2], x[3]) 
        } else {			# what?
            stop("Input vector was not of length 3 or 4!\n")
        }
    } else {
        if (nrow(x) %in% 3:4) {
            apply(x, 2, hsv2)
        } else {
            stop("Input matrix was not of dimension 3xN or 4xN!\n")
        }
    }
}


apa.names$graphics <- c(apa.names$graphics, "rgb2hsv2")
rgb2hsv2 <- function(x, maxColorValue=255) { 
    
    ## Standard rgb2hsv doesn't support 4-channel (alpha-specified) RGB values, but rgb2hsv2 does.
    ## x = 1. a 4-component vector as c(R,G,B,alpha), or 
    ##     2. a 4 row matrix, e.g. col2rgb(X, alpha=T) output or something like it (rows 1,2,3,4 = R,G,B,alpha; 1 col per color).
    ## gamma = pass-in to rgb2hsv() call; see ?rgb2hsv.
    ## maxColorValue = pass-in to rgb2hsv() call; see ?rgb2hsv.
    
    if (is.null(dim(x))) {
        if (length(x) %in% 3:4) {
            result <- rbind(rgb2hsv(x[1], x[2], x[3]))
            if (length(x) == 4) result <- rbind(result, alpha=x[4]/maxColorValue)
        } else {
            stop("Input vector was not of length 3 or 4!\n")
        }
    } else {
        if (nrow(x) %in% 3:4) {
            result <- rgb2hsv(x[1:3,])
            if (nrow(x) == 4) result <- rbind(result, alpha=x[4,]/maxColorValue)
        } else {
            stop("Input matrix was not of dimension 3xN or 4xN!\n")
        }
    }
    result 
}


apa.names$graphics <- c(apa.names$graphics, "col2hsv")
col2hsv <- function(x, alpha=FALSE) { 
    
    ## Because base R apparently didn't think of that.
    ## Works as col2rgb()
    
    rgb2hsv2(col2rgb(x,alpha=alpha))
}


apa.names$graphics <- c(apa.names$graphics, "hsv2rgb")
hsv2rgb <- function(h, s=NULL, v=NULL, alpha=NULL) { 
    
    ## No standard HSV -> RGB conversion function in R.  This saves a few steps.  Handles vector, matrix, or h,s,v (separate) inputs.
    ## h = 1. hue value on [0,1], or
    ##     2. a 3-4 component vector as c(H,S,V) or c(H,S,V,alpha), or 
    ##     3. a 3-4 row matrix, e.g. rgb2hsv() output or something like it (rows 1,2,3 = H,S,V; 1 col per color; optional row 4 = alpha).
    ## s = saturation value on [0,1].
    ## v = value value on [0,1].
    ## alpha = transparency value on [0,1].  *** IGNORED if h is an object with existing alpha components
    
    use.alpha <- FALSE
    if (is.null(s) & is.null(v)) {
        if (is.null(dim(h))) {
            if (length(h) == 4) {		# alpha-containing vector
                x <- h
                use.alpha <- TRUE
            } else if (length(h) == 3) {	# plain HSV vector
                use.alpha <- !is.null(alpha)
                x <- if (use.alpha) { h } else { c(h,alpha) }
            } else {				# what?
                stop("Input vector was not of length 3 or 4!\n")
            }
        } else {
            if (nrow(h) == 4) {			# alpha-containing matrix
                x <- h
                use.alpha <- TRUE
            } else if (nrow(h) == 3) {	# plain HSV matrix
                use.alpha <- !is.null(alpha)
                x <- if (use.alpha) { h } else { rbind(h,rep(alpha,ncol(h))) }
            } else {					# what?
                stop("Input matrix was not of dimension 3xN or 4xN!\n")
            }
        }
    } else {
        if (s < 0) {
            stop(paste("Invalid s value",s,"!\n"))
        } else if (v < 0) {
            stop(paste("Invalid v value",v,"!\n"))
        } else {
            use.alpha <- !is.null(alpha)
            x <- if(use.alpha) { c(h,s,v) } else { c(h,s,v,alpha) }
        }
    }
    col2rgb(hsv2(x), alpha=use.alpha)
    
} 


apa.names$graphics <- c(apa.names$graphics, "hsv.tweak")
hsv.tweak <- function(colors, s.adj=0, v.adj=0, a.adj=0) {
    
    ## Shortcut function to adjust saturation, value, and alpha (opacity) values for colors not in HSV format.
    ## 'colors' is a vector of names, numbered, or hex colors
    ## 's.adj','v.adj','a.adj' are adjustments to saturation, value, alpha respectively.
    ##   adjustment values must be on [0,1] and are added (thus if negative, get subtracted).
    ##   if adjustments result in values outside [0,1], these are re-adjusted to be 0 or 1.
    
    if (!is.atomic(colors)) { stop("'colors' must be an atomic vector!\n") }
    
    alphas <- rep(0,length(colors))
    is.hex <- grepl("^#",colors)
    if (any(is.hex)) alphas[is.hex] <- strtoi(sapply(colors[is.hex],substr,8,9),base=16)/255
    any.alphas <- any(alphas!=0)
    alphas[alphas==0]  <- 1
    
    adjusted <- rgb2hsv(col2rgb(colors))
    adjusted[2,] <- adjusted[2,] + s.adj
    adjusted[3,] <- adjusted[3,] + v.adj
    if (any.alphas | a.adj != 0) {
        adjusted <- rbind(adjusted, alphas)
        adjusted[4,] <- adjusted[4,] + a.adj
    }
    adjusted[adjusted < 0] <- 0
    adjusted[adjusted > 1] <- 1
    out <- hsv2(adjusted)
    out[is.na(colors)] <- NA
    out
}


apa.names$graphics <- c(apa.names$graphics, "hsv.spectrum")
hsv.spectrum <- function(h=c(0,1), s=c(0,1), v=c(0,1), rotate=0, gradient=100) {
    
    ## Generates annotated HSV color maps.
    ## h = hue, single number or c(min,max).  Values on [0,1].
    ## s = saturation, single number or c(min,max).  Values on [0,1].
    ## v = value, single number or c(min,max).  Values on [0,1].
    ## overlap = T/F: cause s and v gradients to overlap?  
    ##           "F" creates a diverging map with s,v maxima in the middle and minima at the edges.
    ##           overlap is set to "F" internally if s or v are single-valued, for obvious reasons.
    ## rotate = shift spectrum by this many degrees (degrees > 0 = shift right, degrees < 0 = shift left).
    
    h <- zapsmall(h)
    s <- zapsmall(s)
    v <- zapsmall(v)
    if (length(h)==1) h <- c(h,h)
    if (length(s)==1) s <- c(s,s)
    if (length(v)==1) v <- c(v,v)
    overlap <- s[1]==s[2] | v[1]==v[2]
    nxlabs <- 10  # ALWAYS 10 AXIS LABELS
    
    xgradient <- gradient  # N hue columns
    xaxdif <- diff(1:xgradient)[1]/2
    xbound <- cbind(c(1:xgradient)-xaxdif, c(1:xgradient)+xaxdif)
    xaxpos <- seq(1, xgradient, length.out=nxlabs)
    
    yrows <- ifelse(!overlap & gradient%%2==0, gradient+1, gradient)
    ygradient <- ifelse(overlap, yrows, trunc(yrows/2))
    yaxdif <- diff(1:yrows)[1]/2
    ybound <- cbind(c(1:yrows)-yaxdif, c(1:yrows)+yaxdif)
    
    if (h[1]>h[2]) {  # wraps around red
        neg <- 1 - h[1]
        hues <-        seq(0, h[2]+neg, length.out=xgradient)
        xlab <- signif(seq(0, h[2]+neg, length.out=nxlabs   ),3)
        hues <- hues - neg
        xlab <- xlab - neg
        h0 <- which(hues>=0)[1]  # MUST TEST HERE: first hues value after (or exactly on) 0/1 boundary
        hues[hues<0] <- hues[hues<0] + 1
        xlab[xlab<0] <- xlab[xlab<0] + 1
        hues[hues==1] <- 0
        xlab[xlab==1] <- 0
        if (hues[h0]==0) {
            vline <- h0
        } else {
            vline <- h0 - hues[h0] / diff(hues[h0:(h0+1)])
        }
    } else {
        hues <- seq(h[1], h[2], length.out=xgradient)
        xlab <- signif(seq(h[1], h[2], length.out=nxlabs),3)
        vline <- NULL
    }

    interval <- trunc(360/xgradient)
    even <- ifelse(rotate%%interval==0, TRUE, FALSE)
    shift <- trunc(xgradient*rotate/360)
    if (shift<0) shift <- xgradient+shift
    if (shift>0) {	# cannot be < 0 at this point
        shift <- gradient - shift
        rotated <- c(shift:gradient,1:(shift-1))
        hues <- hues[rotated]
    }
    
    if (overlap) {
        sats  <- signif(seq(s[1], s[2], length.out=gradient), 3)
        vals  <- signif(seq(v[1], v[2], length.out=gradient), 3)
        slabs <- signif(seq(s[1], s[2], length.out=nxlabs), 3)
        vlabs <- signif(seq(v[1], v[2], length.out=nxlabs), 3)
        nylabs <- nxlabs
    } else {
        if (gradient %% 2 == 0) gradient <- gradient + 1  # MUST BE ODD
        gradient1 <- gradient - 1
        halfgr <- zapsmall((gradient1 / 2) + 1)
        halfnl <- nxlabs / 2
        sats  <- signif(c(seq(s[1], s[2], length.out=halfgr), rep(1,halfgr-1)), 3)
        vals  <- signif(c(rep(1,halfgr-1), seq(v[2], v[1], length.out=halfgr)), 3)
        slabs <- signif(c(seq(s[1], s[2], length.out=halfnl+1), rep(1, halfnl)), 3)
        vlabs <- signif(c(rep(1, halfnl), seq(v[2], v[1], length.out=halfnl+1)), 3)
        nylabs <- nxlabs+1
    }
    yaxpos <- seq(1, yrows, length.out=nylabs)
    
    fmt <- paste0("%-",max(nchar(sats)),"s  %-",max(nchar(vals)),"s")
    ylabs <- sprintf(fmt, format(slabs), format(vlabs))
    yhead <- c(rep("", length(ylabs)), sprintf(fmt,"Sat","Val"))
    
    cellcol <- matrix(NA, yrows, xgradient)
    for (i in 1:xgradient) cellcol[,i] <- hsv2(rbind(hues[i],sats,vals))
    cellcol <- cellcol[nrow(cellcol):1,]  # otherwise prints upside down
    
    par(mar=c(5,8,3,1), las=1, cex=1.2, family="mono")
    plot(1, 1, pch="", xlim=range(xbound), ylim=range(ybound), axes=FALSE, ylab="", xlab="", font.lab=2, main="HSV Spectrum")
    axis(1, xaxpos, format(xlab), font=2, las=2)
    axis(2, yaxpos, rev(ylabs), font=2)
    mtext("Hue", 1, 1, FALSE, min(xaxpos)-diff(xaxpos)[1]*0.75, NA, 1, 1.2, 1, 2, las=2)
    mtext(yhead, 2, 1, FALSE, max(yaxpos)+diff(yaxpos)[1]*0.75, NA, 1, 1.2, 1, 2, las=2)
    for (i in 1:nrow(cellcol)) for (j in 1:ncol(cellcol)) rect(xbound[j,1],ybound[i,1], xbound[j,2],ybound[i,2], col=cellcol[i,j], border=NA)
    if (length(vline)>0) abline(v=vline, lty=3)
}


apa.names$graphics <- c(apa.names$graphics, "nearest.named.color")
nearest.named.color <- function(x, color=c("hex","rgb","hsv"), space=c("rgb","hsv"), nearest=TRUE) {
    
    ## takes a color in hex, rgb, or hsv and find the closes R-base-named color to it.
    ## color may contain alpha channel, but it will be ignored
    ## 'color' indicates incoming value of color 'x'
    ## 'space' indicates to calculate distance in rgb or hsv colorspace
    ## 'nearest=TRUE' returns only nearest color(s).
    ## 'nearest=FALSE' returns entire named distance vector.
    
    color <- match.arg(color)
    space <- match.arg(space)
    xrgb <- switch( color, hex=col2rgb(x), rgb=x, hsv=hsv2rgb(c(x)) )
    
    if (space == "rgb") {
        d <- as.matrix(dist(rbind(c(xrgb), t(sapply(colors(), col2rgb)))))
    } else if (space == "hsv") {
        xhsv <- rgb2hsv(xrgb)
        d <- as.matrix(dist(rbind(c(xhsv), t(sapply(colors(), function(y) rgb2hsv(col2rgb(y)) )))))
    }
    
    d <- zapsmall(d[2:nrow(d),1])
    if (nearest) {
        d[d==min(d)]
    } else {
        d
    }
    
}


apa.names$graphics <- c(apa.names$graphics, "colorNeighborhood")
colorNeighborhood <- function(col=NULL, h=c(0,1), s=c(0,1), v=c(0,1), sort=NULL, neutrals=TRUE) {
    
    ## Displays named R colors within predefined HSV ranges.
    ## "col=<colorname>" overrides h,s,v entries.
    ## "sort" can be "h", "s", or "v"; visual sort order by HSV values.
    ## "neutrals=F" eliminates all proper neutrals (but not necessarily the output category).
    
    IM("0")
    if (length(h) != 2) stop("'h' must be a vector of length 2!\n")
    if (length(s) != 2) stop("'s' must be a vector of length 2!\n")
    if (length(v) != 2) stop("'v' must be a vector of length 2!\n")
    ## sat.lim, val.lim define cutoffs below which a color is "pale" or "dark", respectively.
    sat.lim <- 0.5
    val.lim <- 0.6
    val.med <- 0.81
    sat.lo <- 0.2
    wht.lim <- 0.2
    sorts <- list(h=1, s=2, v=3)
    allcolors.rgb <- col2rgb(colors())
    allcolors <- rgb2hsv(allcolors.rgb)
    all.neutrals <- which(colSDs(allcolors.rgb) == 0)
    near.neutrals <- setdiff(which(colCVs(allcolors.rgb) <= 0.05), all.neutrals)
    gray.block <- c(153:253)
    gray.blocks <- c(gray.block,261:361)
    if (!is.null(col)) {
        match.arg(col, c("red","orange","yellow","green","cyan","blue","purple","violet","magenta","brown","white","grey","gray"))
        s <- v <- c(0,1)
        
        if (col == "grey" | col == "gray") {	# special case
            w <- c()
        } else if (col == "white") {
            h <- c(0,1)
            s <- c(0,0.1)
            v <- c(0.9,1)
        } else {
            h <- switch(
                col, 
                "red"=c(0.95,0.05),
                "orange"=c(0.05,0.11),
                "yellow"=c(0.11,0.2),
                "green"=c(0.2,0.45),
                "cyan"=c(0.45,0.55),
                "blue"=c(0.55,0.72),
                "purple"=,
                "violet"=c(0.72,0.87),
                "magenta"=c(0.83,0.94),
                "brown"=c(0.05,0.15)
            )
        }
    } else {
        col <- ""	# dummy value
    }
    
    hues <- sats <- vals <- vector("list", length=2)
    hues[[1]] <- h; sats[[1]] <- s; vals[[1]] <- v
    if (h[2] < h[1]) {		# break across 0/1
        hues[[1]] <- c(h[1], 1)
        hues[[2]] <- c(0, h[2])
    }
    
#	Later will support 0/1-split s, v ranges
#	if (s[2] < s[1]) {
#		sats[[1]] <- c(s[1], 1)
#		sats[[2]] <- c(0, s[2])
#	}
#	if (v[2] < v[1]) {
#		vals[[1]] <- c(v[1], 1)
#		vals[[2]] <- c(0, v[2])
#	}
    
    matches <- list(Neutral=c(),Dim=c(),Pale=c(),Light=c(),Bright=c(),Medium=c(),Dark=c())
    
    for (i in 1:length(hues)) {
        if (col != "grey" & col != "gray") {	# grey colors skip this
            x <- which(allcolors[1,] >= hues[[i]][1] & allcolors[1,] <= hues[[i]][2])
            x <- setdiff(x, gray.blocks)	# remove giant grey/gray blocks
            if (!neutrals) { x <- setdiff(x, all.neutrals) }	# remove all neutrals, period.
            y <- x[which(allcolors[2,x] >= s[1] & allcolors[2,x] <= s[2])]
            z <- x[which(allcolors[3,x] >= v[1] & allcolors[3,x] <= v[2])]
            w <- intersect(y,z)
        }
        lslmv <- w[which(allcolors[2,w] < sat.lim & allcolors[3,w] < val.med)]
        greys <- lslmv[which(allcolors[2,lslmv] <= sat.lo)]
        dims <- setdiff(lslmv, greys)
        lshv <- w[which(allcolors[2,w] < sat.lim & allcolors[3,w] >= val.med)]
        hslv <- w[which(allcolors[2,w] >= sat.lim & allcolors[3,w] < val.lim)]
        hsmv <- w[which(allcolors[2,w] >= sat.lim & allcolors[3,w] >= val.lim & allcolors[3,w] < val.med)]
        hshv <- w[which(allcolors[2,w] >= sat.lim & allcolors[3,w] >= val.med)]
        pale <- lshv[which(abs(allcolors[2,lshv]-1+allcolors[3,lshv]) <= wht.lim)]
        lshv <- setdiff(lshv, pale)
        matches$Neutral <- c(matches$Neutral, greys)
        matches$Dim <- c(matches$Dim, dims)
        matches$Pale <- c(matches$Pale, pale)
        matches$Light <- c(matches$Light, lshv)
        matches$Bright <- c(matches$Bright, hshv)
        matches$Medium <- c(matches$Medium, hsmv)
        matches$Dark <- c(matches$Dark, hslv)
    }
    
    if (col == "brown") {	# eliminate too-strong colors
        pre <- unlist(matches[3:6])	# Pale, Light, Bright, Medium
        drop1 <- pre[which(allcolors[2,pre] > 0.85 & allcolors[3,pre] > 0.85)]
        drop2 <- pre[which(allcolors[2,pre] <= 0.2 & allcolors[3,pre] > 0.99)]
        drop3 <- pre[which(allcolors[2,pre] > 0.4 & allcolors[3,pre] > 0.93)]
        drop.34 <- c(drop2, drop3)
        drop.56 <- c(drop1)
        for (i in 3:4) { matches[[i]] <- setdiff(matches[[i]], drop.34) }
        for (i in 5:6) { matches[[i]] <- setdiff(matches[[i]], drop.56) }
        if (is.null(sort)) { sort13 <- "v"; sort47 <- "s" }
    } else {
        if (is.null(sort)) { sort13 <- "v"; sort47 <- "h" }
    }
    
    matches$Neutral <- matches$Neutral[order(allcolors[sorts[[sort13]],matches$Neutral])]
    matches$Dim <- matches$Dim[order(allcolors[sorts[[sort13]],matches$Dim])]
    matches$Pale <- matches$Pale[order(allcolors[sorts[[sort13]],matches$Pale])]
    matches$Light <- matches$Light[order(allcolors[sorts[[sort47]],matches$Light])]
    matches$Bright <- matches$Bright[order(allcolors[sorts[[sort47]],matches$Bright])]
    matches$Medium <- matches$Medium[order(allcolors[sorts[[sort47]],matches$Medium])]
    matches$Dark <- matches$Dark[order(allcolors[sorts[[sort47]],matches$Dark])]
    
    message(paste(length(unlist(matches)),"colors found.\n"))
    ok <- which(listLengths(matches) > 0)
    if (length(ok) > 0) {
        par(mfrow=c(1,length(ok)), mar=c(1,1,2,6), las=2)
        for (i in ok) { 
            x <- matches[[i]]
            y <- t(as.matrix(length(x):1))
            image(y, col=colors()[x], main=names(matches)[i], axes=FALSE) 
            axis(4, col=0, tick=FALSE, line=-0.8, cex=0.9, at=seq(0,1,length.out=length(x)), labels=colors()[x[length(x):1]], las=2)
        }
        invisible(matches)
    } else {
        stop("No colors found in that range!\n")
    }
}


apa.names$graphics <- c(apa.names$graphics, "colorNeighborhood2")
colorNeighborhood2 <- function(color=NULL, hues=c(0,1), sats=c(0,1), vals=c(0,1), sort=NULL, cex=1, pmar=0) {

    ## UNDER CONSTRUCTION -- see /n/projects/apa/R/hsv_explore.R for dev work
    ## Improved colorNeighborhood, also with neutral color support.
    ## Displays named R colors within predefined HSV ranges.
    ## "color=<colorname>" overrides hues/sats/vals entries.
    ## "sort" can be "h", "s", or "v"; visual sort order by HSV values.
    
    if (is.null(color)) color <- ""
    neutral.names <- c("white","black","grey","gray","true-neutral")
    color.names <- c("red","orange","yellow","green","cyan","blue","purple","violet","magenta","brown")
    match.arg(color, c("",color.names,neutral.names))
    
    if (length(hues) != 2) stop("'hues' must be c(min,max)!\n")
    if (length(sats) != 2) stop("'sats' must be c(min,max)!\n")
    if (length(vals) != 2) stop("'vals' must be c(min,max)!\n")
    
    ## named-color stats
    all.col <- colors()
    all.rgb <- col2rgb(all.col)
    all.hsv <- rgb2hsv(all.rgb)
    all.cv <- zerofy(colCVs(all.rgb))
    all.mn <- colMeans(all.rgb)
    neut <- all.hsv[2,]==0
    col.col <- all.col[!neut]
    col.hsv <- all.hsv[,!neut]
    col.rgb <- all.rgb[,!neut]
    sv.mn <- colMeans(col.hsv[2:3,])
    col.cv <- all.cv[!neut]
    col.mn <- all.mn[!neut]
    
    ## core color intervals, by hue (left-closed, i.e. x>=first and x<second)
    h.ranges <- list(
            red=list( c(0.00,0.05), c(0.95,1.00) ),
         orange=list( c(0.05,0.11) ),
         yellow=list( c(0.11,0.20) ),
          green=list( c(0.20,0.437) ),
           cyan=list( c(0.437,0.54) ),
           blue=list( c(0.54,0.72) ),
         purple=list( c(0.73,0.87) ),
         violet=list(),
        magenta=list( c(0.83,0.94) ),
          brown=list( c(0.05,0.15) )
    )
    h.ranges$violet <- h.ranges$purple
    which.hue <- lapply(h.ranges, function(x) unlist(lapply(x, function(y) which(col.hsv[1,]>=y[1] & col.hsv[1,]<y[2]) )))
    
    ## some specific definitions
    is.truegreen <- col.hsv[1,]>=0.32 & col.hsv[1,]<=0.34  # green hue +- 0.01
    is.trueblue  <- col.hsv[1,]>=0.65 & col.hsv[1,]<=0.67   # blue hue +- 0.01
    is.bluepur <- col.hsv[1,]>=h.ranges$blue[[1]][1] & col.hsv[1,]<=h.ranges$purple[[1]][2]
    bluepur.deval <- is.bluepur & col.hsv[3,]<0.9
    
    ## neutral and near-neutral definitions
    gray.blocks <- list(153:253,261:361)   # positions of giant gray/grey0-100 blocks
    ghsv <- rgb2hsv(col2rgb(colors()[gray.blocks[[1]]]))  # all sat == 0 !
    true.neutrals <- which(all.hsv[2,] == 0)   ## these are the only true neutrals, all the others are near-neutral
    neuts <- list(   ## ALL THESE ARE NEAR-NEUTRAL // NO TRUE NEUTRALS (except black and white)
        black=which(col.mn<=40 | (is.bluepur & col.mn<=50) ),
        white=which(col.mn>=240),
        greyL=which(col.cv <= 0.3 & col.hsv[3,]<=0.4),
        greyML=which(col.cv <= 0.3 & col.hsv[3,]>0.4 & col.hsv[3,]<=0.8 & col.hsv[2,]>0.2),
        greyMH=which(col.cv <= 0.3 & col.hsv[3,]>0.4 & col.hsv[3,]<=0.8 & col.hsv[2,]<=0.2),
        greyH=which(col.cv <= 0.3 & col.hsv[3,]>0.7 & col.hsv[3,]>0.8 & col.hsv[2,]<=0.2)
    )
    for (i in 1:length(neuts)) neuts[[i]] <- setdiff(neuts[[i]], true.neutrals)
    neuts$black <- c(neuts$black, which(colors()=="black"))
    neuts$white <- c(neuts$white, which(colors()=="white"))
    length(true.neutrals); listLengths(neuts)
    
    ## named-colorspace fault lines
    satlines <- c(0.36,0.64,0.97)
    vallines <- c(0.67,0.89)
    satlines1 <- c(-0.02,satlines,1.03)  # with min/max  # *lines1 intended for use with col.hsv NOT all.hsv
    vallines1 <- c(0.27,vallines,1.03)   # with min/max
    sv.blocks <- named.list(unlist(lapply(length(vallines1):2, function(v) lapply(2:length(satlines1), function(s){
        w <- which(col.hsv[3,]<vallines1[v] & col.hsv[3,]>vallines1[v-1] & col.hsv[2,]>satlines1[s-1] & col.hsv[2,]<satlines1[s])
#        IM(v,vallines1[v-1],vallines1[v],":",s,satlines1[s-1],satlines1[s],":",length(w))
        w
    })), recursive=FALSE), 1:12)
#    listLengths(sv.blocks); sum(listLengths(sv.blocks)); sum(listLengths(sv.blocks))+length(neut)
    ## 1=pal, 2=lit, 3=brt, 4=brt, 5=pal, 6=lit, 7=med, 8=med, 9=dim, 10=dim, 11=drk, 12=drk
    sets <- list(
        neutral=c(),
        dim=sort(unlist(sv.blocks[c(5,9)])),
        pale=sort(unlist(sv.blocks[c(1)])),
        light=sort(unlist(sv.blocks[c(2,6)])),
        bold=sort(unlist(sv.blocks[c(3,4)])),
        medium=sort(unlist(sv.blocks[c(7,8)])),
        dark=sort(unlist(sv.blocks[c(10,11,12)]))
    )
    sets$neutral
#    listLengths(sets)
    ### NOTES:
    ## red: P/L ok; Dm/Dk ol
    ## orange: P/L ol, Dm/Dk ol
    ## yellow: P/L ol, Dm/Dk ol
    ## green: 
    ## cyan: 
    ## blue: 
    ## purple: 
    ## magenta: 
    
    if (color %in% neutral.names) {
        
        if (color == "grey" | color == "gray" | color == "Neutral") {
            matches$`Grays-1` <- graysLo
            matches$`Grays-2` <- graysML
            matches$`Grays-3` <- graysMH
            matches$`Grays-4` <- graysHi
            if (color == "Neutral") matches <- list(`Near-White`=neuts[whites], matches, `Near-Black`=neuts[blacks])
        } else if (color == "white") {
            matches$`Near-White` <- neuts[whites]
        } else if (color == "black") {
            matches$`Near-Black` <- neuts[blacks]
        }
        
    } else {
        
        matches <- lapply(sets, function(x) intersect(x, which.hue) )
        
        if (color == "brown") {	  # eliminate vivid colors (these will be oranges and yellows)
            pre <- unlist(matches[3:6])	  # Pale, Light, Bold, Medium
            drop1 <- pre[which(col.hsv[2,pre] > 0.85 & col.hsv[3,pre] > 0.85)]
            drop2 <- pre[which(col.hsv[2,pre] <= 0.2 & col.hsv[3,pre] > 0.99)]
            drop3 <- pre[which(col.hsv[2,pre] > 0.4 & col.hsv[3,pre] > 0.93)]
            drop.34 <- c(drop2, drop3)
            drop.56 <- c(drop1)
            for (i in 3:4) matches[[i]] <- setdiff(matches[[i]], drop.34)
            for (i in 5:6) matches[[i]] <- setdiff(matches[[i]], drop.56)
        }
    }
    
#    sorts <- list(h=1, s=2, v=3)
#    if (length(sort)>0) {
#        for (i in 1:7) matches[[i]] <- matches[[i]][order(col.hsv[sorts[[sort]],matches[[i]]])]
#    } else {
#        sort13 <- "v"
#        sort47 <- ifelse(color=="brown", "s", "h")
#        for (i in 1:3) matches[[i]] <- matches[[i]][order(col.hsv[sorts[[sort13]],matches[[i]]])]
#        for (i in 4:7) matches[[i]] <- matches[[i]][order(col.hsv[sorts[[sort47]],matches[[i]]])]
#    }
    
    message(paste(length(unlist(matches)),"colors found.\n"))
    ok <- which(listLengths(matches) > 0)
    if (length(ok) > 0) {
        par(mfrow=c(1,length(ok)), mar=c(0,0,2,pmar), las=2, cex=cex)
        for (i in ok) {
            x <- col.col[matches[[i]]]
            x <- x[order(col.hsv[1,matches[[i]]])]
            if (length(x)<4) x <- c(x, rep(NA,4-length(x)))
            L <- length(x)
            y <- t(as.matrix(L:1))
            xh <- col.hsv[1,matches[[i]]]
            xs <- col.hsv[2,matches[[i]]]
            xv <- col.hsv[3,matches[[i]]]
            image(y, col=x, main=names(matches)[i], axes=FALSE)
            x[is.na(x)] <- ""  # remove color "name" after imaging
            if (pmar>0) {
                axis(4, col=0, tick=FALSE, line=-0.8, at=seq(0,1,length.out=L), labels=x[L:1], las=2)
            } else {
                if (all(xh>=0.54 & xh<=0.87)) {
                    lowval <- xs>0.4 & xv<0.6   # devalued blues/purples are visually much darker than other colors
                    lowval <- lowval | (abs(xh-0.66)<=0.01 & xv>0.9)  # also include high-valued true-blues 
                } else {
                    lowval <- xv<0.55   # all other colors
                }
                textcol <- 1  # default
#                textcol <- c("black","white")[lowval+1]
#                textcol <- ifelse(names(matches)[i]=="dark", "white", "black")
                ##text(-1, seq(0,1,length.out=L), x[L:1], pos=4, col=rev(textcol))  # print left-justified
                text(0, seq(0,1,length.out=L), x[L:1], col=rev(textcol))  # print centered
            }
        }
        invisible(matches)
    } else {
        stop("No colors found in that range!\n")
    }
}


#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################


apa.names$plots <- c(apa.names$plots, "masked.map")
masked.map <- function(map, data, type, alpha.max=0.85, base.col="grey50") {
	
	## "type = sets" means 'data' is a list of length=k, each element being a vector of row indexes.
	## "type = map" means 'data' is a vector of cluster membership numbers with length = nrow(map).
	
	if (type == "map") {
		unq <- unique(data)
		clusters <- vector("list", length=length(unq))
		for (i in 1:length(unq)) { clusters[[i]] <- which(data == unq[i]) }
	} else if (type == "sets") {
		clusters <- data
	} else {
		stop("Unknown data type!  Must be one of 'map' or 'sets'.\n")
	}
	rowmap <- unlist(clusters)
	newmap <- map[rowmap,rowmap]
	mask <- matrix(data=0, nrow=nrow(newmap), ncol=ncol(newmap))
	for (clust in clusters) {
		for (i in 1:length(clust)) {
			for (j in 1:length(clust)) {
				mask[clust[i],clust[j]] <- 1	
			}
		}
	}
	mask <- mask[rowmap,rowmap]
	mask.ramp <- mask.palette(base.col=base.col, alpha.max=alpha.max)
	myImagePlotUltra(newmap, mask=mask, mask.ramp=mask.ramp)
}


apa.names$plots <- c(apa.names$plots, "tree.cuts")
tree.cuts <- function(map, yrange, horiz=FALSE, lty=1, lwd=1) {
	
	## 'map' is an integer grouping vector for clusters on a dendrogram, e.g. cutree() output.  Any NA entries will be ignored.
	##  - could also use kmeans() output, but this is often discontiguous on a dendrogram.
	##  - EITHER WAY, MAP MUST BE IN DENDROGRAM ORDER!!!!
	## 'yrange' is the y range bounding where the rectangle or bar is drawn.  Look at the y-axis of the dendrogram and decide.
	##  - if cutree() was used, it is most best to set yrange=c(0,h) where 'h' was the height of the cut (if known).
	## set 'horiz' = TRUE if you used "horiz=T" in your plot call.
	## 'lty', 'lwd' as usual.
	## !!! Assumes dendrogram has already been plotted in an active device.  This adds the rect() calls to that plot.
	
	cu <- real(unique(map))
	cl <- new.list(cu)
	N <- length(cu)
	contig <- rep(TRUE, length(cu))
	cols <- rainbow(N+1)[1:N]
	for (i in 1:N) {
		cl[[i]] <- which(map==cu[i])
		if (!all(diff(cl[[i]])==1)) contig[i] <- FALSE
	}
	if (all(contig)) {   # all clusters contiguous -- plot rectangles
		for (i in 1:N) {
			rect(min(cl[[i]]), yrange[1], max(cl[[i]]), yrange[2], col=NA, bord=cols[i], lty=lty, lwd=lwd)
		}
	} else {   # some clusters discontiguous -- plot color bar
		for (i in 1:N) {
			for (j in 1:length(cl[[i]])) segments(cl[[i]][j], yrange[1], cl[[i]][j], yrange[2], col=cols[i], lty=lty, lwd=lwd)
		}
	}
}


apa.names$plots <- c(apa.names$plots, "pairs.basic")
pairs.basic <- function(obj, col=1, pch=1, ab.col=2, cex.pch=1, cex.text=1) {
	N <- ncol(obj)
	par(mfrow=c(N,N), mar=c(1,1,1,1), oma=c(3,3,3,3), las=1, xaxt="n", yaxt="n")
	for (i in 1:N) { for (j in 1:N) {
		if (i == j) {
			null.plot(frame.plot=TRUE)
			text(0.5, 0.5, colnames(obj)[i], cex=cex.text)
		} else {
			plot(obj[,j], obj[,i], col=col, pch=pch, cex=cex.pch)
			abline(0,1,col=ab.col)
		}
	} }
}

apa.names$plots <- c(apa.names$plots, "plot.fc.lines")
plot.fc.lines <- function(folds, slope=1, reg.vecs=NULL, stdev=NULL, color.bands=NULL, col=1, lty=1, lwd=1, col.diag=col, lty.diag=lty, lwd.diag=lwd, col.reg=col, lty.reg=lty, lwd.reg=lwd) {
    
    ## Plots fold-change lines on a diagonal scatterplot.
    ## "folds" is a vector of fold-change positions to plot.  MAKE SURE THIS IS IN THE PROPER SCALE FOR THE PLOT...
    ## "slope" allows changing of the slope of the diagonal (and therefore fold-change lines) if for some reason it is not 1.
    ## "reg.vecs=list(x,y)" plots a regression line for the x/y scatter.
    ## "stdev", if non-null, uses this stdev value to plot standard deviation lines, not fold-change lines
    ## "color.bands" controls the replacement of lines with bands of point colors.  If specified it must be a list of 1-2 elements:
    ##   [[1]] must be a 2-col matrix with points plotted (REQUIRED), [[2]] must be a vector of colors for the bands (OPTIONAL).
    ## col, lty, lwd are the normal parameters.
    ## col.diag, lty.diag, lwd.diag are versions for the diagonal ONLY.  Only apply if the diagonal itself is in 'folds'.
    ## col.reg, lty.reg, lwd.reg are versions for the regression line ONLY.  Only apply if 'reg.vecs' is non-null.
    
    ## # color.bands NOT READY TO GO YET
    
    theta <- thetacon(slope, "slope", "radians")	# from apa_functions.R
    fac <- ifelse (is.null(stdev), 1, stdev)
    scale <- fac / cos(theta)
    if (is.nan(scale)) scale <- 1
    ##IM(theta, scale)
    
    if (is.null(color.bands)) {
        for (i in 1:length(folds)) { 
            if (folds[i] == 0) {
                abline(folds[i]*scale, slope, col=col.diag, lty=lty.diag, lwd=lwd.diag) 
            } else {
                abline(folds[i]*scale, slope, col=col, lty=lty, lwd=lwd) 
            }
        }
    } else {
        x <- color.bands[[1]][,1]
        y <- color.bands[[1]][,2]
        if (length(color.bands)==2) {
            band.cols <- color.bands[[2]]
        } else {
            band.cols <- c(1,4,3,2,5,6,7)	# supports differential coloring up to 6 bands
        }
        band.max <- length(band.cols)
        band.sets <- fc.sets(x, y, max(fc.lines), slope)
        band.pcts <- rep(0, length(band.sets))
        for (f in 1:length(band.sets)) { 
            points(x[band.sets[[f]]], y[band.sets[[f]]], pch=pch, col=band.cols[f]) 
            band.pcts[f] <- round(100 * length(band.sets[[f]]) / length(ok), 1)
        }
        fcl.col <- 8
      	legend(x="bottomright", bty="n", text.col=band.cols, legend=paste(band.pcts,"%",sep=""))
    }
    if (!is.null(reg.vecs)) { 
        linm <- lm(reg.vecs[[2]] ~ reg.vecs[[1]])
        abline(linm[[1]][1], linm[[1]][2], col=col.reg, lty=lty.reg, lwd=lwd.reg) 
        invisible(linm) 
    }
}


apa.names$plots <- c(apa.names$plots, "plot.contours")
plot.contours <- function(x, k=10, cols=NULL, n=100, ltys=1, lwds=1) {
    ## adds contour lines to an existing plot
    ## 'x' is a 2-col matrix with col 1 = x, col 2 = y coords
    require(MASS)
    z <- kde2d(x[,1], x[,2], n=n)
    if (length(cols)==0) cols <- rainbow(k+1)[1:k]
    if (length(ltys)==1) ltys <- rep(ltys,k)
    if (length(lwds)==1) lwds <- rep(lwds,k)
    levs <- seq(min(z$z),max(z$z),length.out=k+1)[1:k]
    levs <- levs+diff(levs)[1]/2
    contour(z, drawlabels=FALSE, levels=levs, col=rev(cols), lty=ltys, lwd=lwds, add=TRUE)
    invisible(z)
}


apa.names$plots <- c(apa.names$plots, "butterfly.plot")
butterfly.plot <- function(x, border=1, ...) {
	
	## Butterflied boxplots; i.e. + and - fold-change sets get boxplotted separately in the same column.  Zeroes are assigned to positive side.
	## 'x' is an object to be boxplotted
	## 'border' is a vector of length 1 or 2 indicating color(s) for + and - boxplots, respectively.  Try 'border=c(2,4)'.  Overrides any 'border' value in '...'.
	## '...' are all other args passed to graphics::boxplot()
	
	pos.args <- neg.args <- list(...)
	
	if (is.list(x)) {  # or data.frame
		pos <- lapply(x, function(n){n[n>=0]})
		neg <- lapply(x, function(n){n[n<0]})
	} else if (is.nlv(x)) {
		pos <- x[x>=0]
		neg <- x[x<0]
	} else if (is.matrix(x)) {
		pos <- apply(x, 2, function(n){n[n>=0]})
		neg <- apply(x, 2, function(n){n[n<0]})
	} else {
		stop("'x' must be a list, data.frame, matrix, or numeric vector!\n")
	}
	
	if (length(border)==1) border[2] <- border[1]
	
	pos.args$x <- pos
	pos.args$border <- border[1]
	neg.args$x <- neg
	neg.args$border <- border[2]
	neg.args$add=TRUE
	neg.args$names=NA
	neg.args$axes=F
	
	do.call(boxplot, pos.args)
	do.call(boxplot, neg.args)
	invisible(list(pos=pos,neg=neg))
}


apa.names$plots <- c(apa.names$plots, "half.butterfly.plot")
half.butterfly.plot <- function(obj, shared=FALSE, cols=c("firebrick3","dodgerblue3","white"), dirlabels=c("Up Terms","Down Terms"), scorelabel="-Log10(p)", main=NULL, xseq=NULL, cex=1, pmar=c(2,2)) {
    
    ## 'obj' is a 2-3 column ROWNAMED matrix:
    ##  - col 1 = score; rownames are descriptors for the score (see description below)
    ##  - col 2 = 1|-1 (which side of plot they go to)
    ##  - optional col 3 = N units contributing to score
    ## initially designed for displaying selected GO terms from mut/wt comparisons:
    ##  - col 1 is -log10(p-value) for GO terms for mut/wt sig-DE genes (row names are the GO terms themselves)
    ##  - col 2 is sign of fold-change for mut/wt gene set (i.e. upreg, downreg) to which GO term pertains
    ##  - col 3 is N genes contributing to sig GO term call
    ## MA data is also an obvious candidate, which would not use column 3
    
    x <- obj
    scores <- x[,1]
    scores[x[,2]<0] <- -1 * scores[x[,2]<0]
    x <- x[order(scores),]
    scores <- scores[order(scores)]
    scores2 <- c(NA,scores,NA)
    cols2 <- c(NA, rep(cols[2],sum(scores<0)), rep(cols[1],sum(scores>0)), NA)
    space <- 0.35  # barplot 'space' arg
    
    segx <- round(range(scores),0)  # initially, anyway
    bar.xlim <- c( min(min(scores),segx[1]), max(max(scores),segx[2]) )
    chars.per.unit <- 26/(10.2*cex)  # scaled to units of default X11 window size, family="mono"
    units.per.row <- t(sapply(1:nrow(x), function(i){ tx=x[i,2] * nchar(rownames(x)[i])/chars.per.unit + x[i,1]; c(scores[i],nchar(rownames(x)[i]),tx,scores[i]+tx) }))
	names(units.per.row) <- NULL
    text.range <- range(units.per.row[,4])
    dimnames(units.per.row) <- list(rownames(x),c("Score","Nchar","Text","Sum"))
#    return(units.per.row)
    
    par(mar=c(2,pmar[1],2,pmar[2]), family="mono", cex=cex)
    
    if (shared) {
		
		## plot +, - bars with same title on same line
		
        unames <- sort(unique(rownames(x)))
        u <- matrix(NA, length(unames), 4, F, list(unames,c("Score.Dn","N.Dn","Score.Up","N.Up")))
        for (i in 1:nrow(u)) {
            w.d <- rownames(x)==unames[i] & x[,2]==-1
            w.u <- rownames(x)==unames[i] & x[,2]==1
            if (any(w.d)) u[i,1:2] <- x[w.d,c(1,3)]
            if (any(w.u)) u[i,3:4] <- x[w.u,c(1,3)]
        }
        
        o1 <- which(!is.na(u[,1]) & is.na(u[,3]))
        o2 <- which(!is.na(u[,1]) & !is.na(u[,3]))
        o3 <- which(is.na(u[,1]) & !is.na(u[,3]))
#        uord <- c( o1[rev(order(u[o1,1]))], o2[rev(order(rowSums(u[o2,c(1,3)])))], o3[rev(order(u[o3,3]))] )  # order shared by sum score
        uord <- c( o1[rev(order(u[o1,1]))], o2[rev(order(u[o2,1]))], o3[rev(order(u[o3,3]))] )  # order shared by down score
#        uord <- c( o1[rev(order(u[o1,1]))], o2[rev(order(u[o2,3]))], o3[rev(order(u[o3,3]))] )  # order shared by up score
        u <- u[rev(uord),]
        u[,1] <- -1*u[,1]

        b <- (1:nrow(u))-0.5+(1:nrow(u))*space
        barplot(u[,1], col=cols[2], border=cols[2], space=space, beside=TRUE, horiz=TRUE, axes=FALSE, xlab="", ylab="", names=NA, xlim=text.range, ylim=c(-2,max(b)+0.5), main=main)
        barplot(u[,3], col=cols[1], border=cols[1], space=space, beside=TRUE, horiz=TRUE, axes=FALSE, xlab="", ylab="", names=NA, add=TRUE)
        segments(0,0, 0,max(b)+0.5)
        
        w.dn <- which(!is.na(u[,1]))
        w.up <- which(is.na(u[,1]))
        for (i in w.dn) {
            text(u[i,1]-0.5, b[i], pos=2, labels=rownames(u)[i])
            text(-0.65, b[i], labels=u[i,2], col=cols[3], font=2)
            if (!is.na(u[i,3])) text(0.65, b[i], labels=u[i,4], col=cols[3], font=2)
        }
        for (i in w.up) {
            text(u[i,3]+0.5, b[i], pos=4, labels=rownames(u)[i])
            text(0.65, b[i], labels=u[i,4], col=cols[3], font=2)
        }
        
        gap <- 0.5+space
        last.pos <- which(is.na(u[,1]))[1]
        segy <- 0
        if (length(xseq)>0) {
            scale <- xseq
            nticks <- length(xseq)
            segx <- range(scale)
        } else {
            nticks <- 7
            scale <- trunc(seq(segx[1],segx[2],length=nticks))
        }
        tick.ht <- gap*space
        
        text(0, b[length(b)]+gap*1.5, pos=2, labels=dirlabels[2], col=cols[2])
        text(0, b[length(b)]+gap*1.5, pos=4, labels=dirlabels[1], col=cols[1])
        text(0, segy-tick.ht*5, pos=1, labels=scorelabel)
        
        segments(segx[1],segy, segx[2],segy)
        for (i in 1:nticks) {
            segments(scale[i],segy, scale[i],segy-tick.ht)
            text(scale[i], segy-tick.ht*3, labels=abs(scale[i]))
        }
        
    } else {
		
		## plot +, - bars with same title on separate lines
        
        b <- barplot(scores2, col=cols2, border=cols2, space=space, xlim=text.range, beside=TRUE, horiz=TRUE, axes=FALSE, xlab="", ylab="", names=NA, main=main)
        for (i in 1:length(scores)) text(scores2[i+1], b[i+1], pos=ifelse(scores2[i+1]<0,2,4), labels=rownames(x)[i])
        
        gap <- diff(b)[1]
        last.pos <- match(1,x[,2])
        segy <- b[last.pos]+gap*0.5
        if (length(xseq)>0) {
            scale <- xseq
            nticks <- length(xseq)
            segx <- range(scale)
        } else {
            nticks <- 7
            scale <- trunc(seq(segx[1],segx[2],length=nticks))
#            scale <- c(-7,-5,-3,-1,0,1,3)  # hardcoded for Paternal KEGG
        }
#        message(segx); message(paste(seq(segx[1],segx[2],length=nticks))); message(scale)
        tick.ht <- gap*space
        
        text(0, b[1]-tick.ht/2, pos=2, labels=dirlabels[2], col=cols[2])
        text(0, b[length(b)]+tick.ht/2, pos=4, labels=dirlabels[1], col=cols[1])
        text(mean(scale[scale<=0]), segy+tick.ht*4, pos=3, labels=scorelabel)
        text(mean(scale[scale>=0]), segy-tick.ht*4, pos=1, labels=scorelabel)
        
        for (i in 1:length(scores)) text(sign(scores[i])*0.75, b[i+1], labels=x[i,3], col=cols[3], font=2)
        
        segments(segx[1],segy, segx[2],segy)
        for (i in 1:nticks) {
            if (scale[i] < 0) {
                segments(scale[i],segy, scale[i],segy+tick.ht)
                text(scale[i], segy+tick.ht*2, labels=-scale[i])
            } else {
                if (scale[i]==0) next
                segments(scale[i],segy, scale[i],segy-tick.ht)
                text(scale[i], segy-tick.ht*2, labels=scale[i])
            }
        }
        
    }
}


apa.names$plots <- c(apa.names$plots, "boxplot.outlier.bounds")
boxplot.outlier.bounds <- function(bp, range=NULL, plot=FALSE, pch="-", col=2, cex=2) {
    
    ## Plots and/or returns a matrix of outlier boundaries for a boxplot object.
    ## Returnable is a matrix with row format of:
    ##   col 1 = number of unit boxplot (since there are usually > 1 elements being boxplotted).
    ##   col 2 = -1 or 1 (-1 = low threshold, 1 = high threshold).
    ##   col 3 = value for that threshold
    ## "bp" is a boxplot object with one or more unit boxplots.
    ## "range" is the 'range' value from the original boxplot call, IF not default.
    ## "plot" switch causes the results to appear as dash-marks on an existing boxplot.
    ## "col" specifies color for the dashes in the plot, if "plot=T".
    
    if (is.null(range)) { 
        co <- capture.output(args(boxplot.default))
        re <- regexpr("range = [0-9.]+",co)
        range <- as.numeric(unlist(strsplit(regmatches(co,re)," "))[3])
    }
    cutoffs <- matrix(data=0, nrow=2*length(bp$n), ncol=3)
    for (i in 1:length(bp$n)) { 
        j <- (i-1)*2+1; k <- j+1
        cutoffs[j,1] <- i; cutoffs[k,1] <- i
        cutoffs[j,2] <- -1; cutoffs[k,2] <- 1
        IQR <- bp$stats[4,i] - bp$stats[2,i]
        cutoffs[j,3] <- bp$stats[2,i] - IQR*range
        cutoffs[k,3] <- bp$stats[4,i] + IQR*range
    }
    if (plot == TRUE) { points(cutoffs[,c(1,3)], pch=pch, col=col, cex=cex) }
    invisible(cutoffs)
}


apa.names$plots <- c(apa.names$plots, "stretch.attrib")
stretch.attrib <- function(x, N, label) {
    ## where 'x' is an attribute vector (probably of length 1), N is the length it should be, and 'label' is for the error message
    L <- length(x)
    if (L==1) {
        rep(x, N)
    } else if (L==N) {
        x
    } else if (N %% L == 0) {
        rep(x, N/L)
    } else {
        IM(paste("Warning:",label,"attribute length",L,"is not a multiple of",N))
        rep(x, ceiling(N/L))[1:N]
    }
}


apa.names$plots <- c(apa.names$plots, "error.bars")
error.bars <- function(x, y, width, method=c("sd","sem","iqr","range"), horizontal=FALSE, cross=NULL, col=1, lty=1, lwd=1) {
    
    ## Plots errors bars on existing plot
    ## Designed for barplots, but can be adapted to others
    ## Give 'x' pos for bars and 'y' height for bars
    ## 'width' is a vector, matrix, or list:
    ##  - Vector: indicates error-bar half-length; for each x, each error bar = 2 half-lengths extending from the corresponding y position.
    ##  - Matrix: nrow=2, ncol=length(x); row 1 gives max y value and row 2 = min y value. 
    ##  - List: list of length x, elements = vectors of data points at each position along x; MUST SPECIFY 'method' as error bars will be calculated on the fly.
    ## if 'horizontal=TRUE', 'x' and 'y' get transposed on the plot, and bars go horizontal instead of the default vertical.
    ## 'cross' gives the width of the cross-piece (at top and bottom of error bars) in pixels.  NULL = auto-calculate based on range of 'x'.
    ## col, lty, lwd as usual
    
    method <- match.arg(method)
    N <- length(x)
    if (length(y) != N) stop("'x' and 'y' must be same length!\n")
    if (is.matrix(width)) {  # y max, y min
        if (nrow(width)==2 & ncol(width)==length(x)) {
            width2 <- width
            method <- "range"
        } else {
            stop("'width' must be a vector or list of same length as x, or a 2-row matrix with ncol=length(x)\n")
        }
    } else if (is.nlv(width) & length(width)==length(x)) {  # abs distance from bar terminus
        width2 <- width
    } else if (is.ndfl(width) & length(width)==N) {
        width2 <- switch(method,
                         "sd"=sapply(width, sd),
                         "sem"=sapply(width, SEM),
                         "iqr"=sapply(width, function(w){ diff(quantile(w,c(0.25,0.75))) }),
                         "range"=t(sapply(width, range))   # RETURNS 2-COLUMN MATRIX
                         )
    } else {
        stop("'width' must be a vector or list of same length as x, or a 2-row matrix with ncol=length(x)\n")
    }
    if (length(cross)==0) cross <- diff(range(x))/100
    
    attribs <- list(col=col,lty=lty,lwd=lwd)
    for (i in 1:length(attribs)) attribs[[i]] <- stretch.attrib(attribs[[i]], N, names(attribs)[i])
    
    pos.mat <- matrix(NA, N, 12, F, list(1:N,qw(e.x1,e.y1,e.x2,e.y2, t.x1,t.y1,t.x2,t.y2, b.x1,b.y1,b.x2,b.y2)))
    ybot <- ternary(method=="range", width2[1,], y-width2)
    ytop <- ternary(method=="range", width2[2,], y+width2)
    pos.mat[,ternary(horizontal, c(2,4), c(1,3))] <- cbind(x,x)                # x pos, error bar (initial, final)
    pos.mat[,ternary(horizontal, c(1,3), c(2,4))] <- cbind(ybot,ytop)          # y pos, error bar
    pos.mat[,ternary(horizontal, c(6,8), c(5,7))] <- cbind(x-cross,x+cross)    # x pos, top crossbar
    pos.mat[,ternary(horizontal, c(5,7), c(6,8))] <- cbind(ytop,ytop)          # y pos, top crossbar
    pos.mat[,ternary(horizontal, c(10,12), c(9,11))] <- cbind(x-cross,x+cross) # x pos, bottom crossbar
    pos.mat[,ternary(horizontal, c(9,11), c(10,12))] <- cbind(ybot,ybot)       # y pos, bottom crossbar
    
    for (i in 1:N) {
        segments(pos.mat[i,1], pos.mat[i,2], pos.mat[i,3], pos.mat[i,4], col=attribs$col[i], lty=attribs$lty[i], lwd=attribs$lwd[i])      # error bar
        segments(pos.mat[i,5], pos.mat[i,6], pos.mat[i,7], pos.mat[i,8], col=attribs$col[i], lty=attribs$lty[i], lwd=attribs$lwd[i])      # bottom crossbar
        segments(pos.mat[i,9], pos.mat[i,10], pos.mat[i,11], pos.mat[i,12], col=attribs$col[i], lty=attribs$lty[i], lwd=attribs$lwd[i])   # top crossbar
    }
    
    invisible(pos.mat)
}


apa.names$plots <- c(apa.names$plots, "ellipsify")
ellipsify <- function(x, nsd=2, pts=100, col=1, lty=1, lwd=1, rslope=NULL, hull=FALSE, debug=FALSE) {

    ## Plots a mean+Nsd ellipse around a specified set of scatterplot points (plot must already be active)
    ## 'x' = 2-col matrix of x,y coords
    ## 'nsd' = n stdevs for ellipse axes
    ## 'pts' = n points for ellipse circumference
    ## 'col', 'lty', 'lwd' as usual
    ## 'rslope', if specified, forces the slope of the initial regression line
    ## 'hull' draws the convex hull instead of an ellipse
    
    ## PROBLEM: like many conical section plots, ellipses have erroneous rotation when x range != y range
    
    ## diagonal for plot area
#    xlim <- c()  # specify later
#    ylim <- c()
#    xyr <- rbind(x=xlim,y=ylim)
#    m <- quot(rev(apply(xyr,1,diff)))
#    b <- xyr[2,2]-m*xyr[1,2]
    
    if (hull) {
        
        conv.hull <- chull(x)
        for (v in 1:length(conv.hull)) {
            i <- conv.hull[v]
            j <- ifelse(v==length(conv.hull),conv.hull[1],conv.hull[v+1])
            segments(x[i,1],x[i,2], x[j,1],x[j,2], col=col, lty=lty, lwd=lwd)
        }
        
    } else {
        
        ## original centroid
        cent.x <- colMeans(x)
        if (debug) points(cent.x[1], cent.x[2], pch=3, col=col, cex=1.5)
        
        ## original regression line
        model.0 <- lm(x[,2] ~ x[,1])
        b.0 <- model.0$coef[[1]]
        m.0 <- model.0$coef[[2]]
        if (length(rslope)>0) {
            m.0 <- rslope  # with the current intercept, this new slope will not intersect the centroid
            y.gap <- cent.x[2]-(m.0*cent.x[1]+b.0)  # (true centroid y) - (y value of centroid x, using new slope)
            b.0 <- b.0+y.gap
        }
        if (debug) {
            abline(b.0, m.0, col=col)
            IM("Model:",b.0, m.0)
        }
        
        ## center data points at origin
        y <- cbind(x[,1]-cent.x[1], x[,2]-cent.x[2])
        
        ## shifted centroid
        cent.y <- colMeans(y)
        
        ## long axis = regression line
#        model.1 <- lm(y[,2] ~ y[,1])
#        b.1 <- model.1$coef[[1]]
#        m.1 <- model.1$coef[[2]]
        b.1 <- 0    # should be essentially 0
        m.1 <- m.0  # should not change
        
        ## short axis = perp to reg line, intersects centroid
        m.2 <- -1/m.1
        b.2 <- cent.y[2]-m.2*cent.y[1]
        
        ## theta for centroid->x, via long axis
        theta.1 <- atan(m.1)
        
        ## clockwise rotation matrix for long axis -> x
        rot.1 <- matrix(c(cos(-theta.1),sin(-theta.1),-sin(-theta.1),cos(-theta.1)), ncol=2)
#        for (i in 1:2) IM(rot.1)
        
        ## counterclockwise rotation matrix for long axis -> x
        rot.1.rev <- matrix(c(cos(theta.1),sin(theta.1),-sin(theta.1),cos(theta.1)), ncol=2)
#        for (i in 1:2) IM(rot.1.rev)
        
        ## long-axis-rotated points
        y.1r <- t(rot.1 %*% t(y))
        
        ## long-axis m+sd values for rotated points
        cm.1r <- colMeans(y.1r)
        sd.x <- nsd*sd(y.1r[,1])
        sd.y <- nsd*sd(y.1r[,2])
        msd.1r <- matrix(c(-sd.x,sd.x,cm.1r[2],cm.1r[2],cm.1r[1],cm.1r[1],-sd.y,sd.y), ncol=2)
        
        ## construct unrotated ellipse matrices
        el.x <- seq(msd.1r[1,1], msd.1r[2,1], length=pts)
        r1 <- diff(msd.1r[1:2,1])/2
        r2 <- diff(msd.1r[3:4,2])/2
        ternary(r1>r2, {a<-r1;b<-r2}, {a<-r2;b<-r1})
        el.top <- el.bot <- cbind(el.x, sqrt(1-(el.x/r1)^2)*r2)
        el.bot[,2] <- -el.top[,2]
        
        ## rotate + shift ellipse
        el.top.r <- t(rot.1.rev %*% t(el.top))
        el.bot.r <- t(rot.1.rev %*% t(el.bot))
        msd.1 <- t(rot.1.rev %*% t(msd.1r))
        for (i in 1:2) {
            el.top.r[,i] <- el.top.r[,i] + cent.x[i]
            el.bot.r[,i] <- el.bot.r[,i] + cent.x[i]
            msd.1[,i] <- msd.1[,i] + cent.x[i]
        }
        lines(el.top.r, col=col, lty=lty, lwd=lwd)
        lines(el.bot.r, col=col, lty=lty, lwd=lwd)
    }
}


apa.names$plots <- c(apa.names$plots, "smoothScatter2")
smoothScatter2 <- function(x, y = NULL, nbin = 256, bandwidth = NULL, colramp = palettizer("terrain.plus"), 
			nrpoints = 100, fhat.scale = NULL, pch = ".", cex = 1, col = "black", transformation = function(x) x^0.25, 
			postPlotHook = box, xlab = NULL, ylab = NULL, xlim, ylim, xaxs = par("xaxs"), yaxs = par("yaxs"), verbose=FALSE, ...) {
	
	## This is a slightly-streamlined copy of smoothScatter from R 2.10.1, with six hacks:
	##  1. The background color now extends the full range of xlim, ylim.
	##  2. x, y range + bandwidth calculations are not screwed up if x = 2-col matrix / y = null.
	##  3. xlim, ylim do not break bandwidth, since it is now calculated up-front.
	##  4. Bandwidth is now scaled to x and y ranges; no more oblong spots!  
	##     Also, single-bandwidths are scaled for both axes, and auto-bandwidths will not be too small.
	##     And, for reference, the effective bandwidths are reported to screen! (if not user-specified)
	##  5. "palettizer" palette selection is available, e.g. 'colramp="terrain.plus"'.
	##  6. fhat.scale alters density-to-color mappings by specifying a different fhat distribution than produced by grDevices:::.smoothScatterCalcDensity
	##	   Value should be the fhat object returned from a different smoothScatter2 call, e.g. "fhat.scale=smoothScatter2(...)$fhat"
	##	   THIS IS CURRENTLY NOT AVAILABLE -- under construction
	
	if (!is.numeric(nrpoints) | (nrpoints < 0) | (length(nrpoints) != 1)) { stop("'nrpoints' should be numeric scalar with value >= 0.") }
	if (length(y)==0) { 
		if (nrow(x)==0) {
			invisible(c())  # complicated way to skip execution without stopping (which breaks loops) or blowing up return value (which damages lists)
			return()
		}
	}
	
	###### HACK 1 + REARRANGED CODE ######
	
	## Hack 1 plots correct background extent when using custom xlim, ylim values 
	
	if (is.matrix(x)) {
		xlabel <- deparse(substitute(x))
		if (is.null(y)) {	
			if (ncol(x) == 2) {	# assumes col 1 = x, col 2 = y
				y <- x[,2]
				x <- x[,1]
				ylabel <- paste(xlabel, "[,2]", sep="")		################## FIX THIS
			} else {		# single- or multicolumn matrix?  treat as vector...
				x <- as.vector(x)
				ylabel <- paste(xlabel, "[,1]", sep="")		################## FIX THIS
			}
		} else if (length(x) == length(y)) {
			x <- as.vector(x)
			y <- as.vector(y)
			ylabel <- deparse(substitute(y))
		} else {
			stop ("x and y are of unequal length!\n")
		}
	} else {
		if (!missing(x)) xlabel <- deparse(substitute(x))
		if (!missing(y)) ylabel <- deparse(substitute(y))
	}
	
	xy <- xy.coords(x, y, xlabel, ylabel)
	xlab <- ifelse (is.null(xlab), xy$xlab, xlab)
	ylab <- ifelse (is.null(ylab), xy$ylab, ylab)
	x <- cbind(xy$x, xy$y)[is.finite(xy$x) & is.finite(xy$y), , drop = FALSE]
	if (!missing(xlim)) {
		stopifnot(is.numeric(xlim), length(xlim) == 2, is.finite(xlim))
		x <- x[min(xlim) <= x[, 1] & x[, 1] <= max(xlim), ]
	} else {
		xlim <- range(x[, 1])
	}
	if (!missing(ylim)) {
		stopifnot(is.numeric(ylim), length(ylim) == 2, is.finite(ylim))
		x <- x[min(ylim) <= x[, 2] & x[, 2] <= max(ylim), ]
	} else {
		ylim <- range(x[, 2])
	}
	
	###### END HACK 1 + REARRANGED CODE ######
	
	###### HACK 2 ######
	
	## Hack 2 enables:
	##  Independent bandwidths for x & y axes; by default will scale y to x so that density spots are always circular.
	##  Range-based color application; can assign color range in plot B based on color-to-density mapping from plot A.
	
	MN <- 85   # 'magic number' used for bandwidth scaling; smoothScatter default is 25
	bandwidth.def <- diff(apply(x,2,quantile,probs=c(0.05,0.95))) / 25   #### ORIGINAL METHOD
	bandwidth.def[bandwidth.def==0] <- 1   #### ORIGINAL METHOD
	xyrange <- signif(c(xlim[2]-xlim[1], ylim[2]-ylim[1]), 4)
	if (length(bandwidth)==0) {
		bandwidth2 <- c(MN,MN)
	} else if (length(bandwidth)==1) {
		bandwidth2 <- c(bandwidth,bandwidth)
	} else {
		# manually-specified x,y bandwidths
		bandwidth2 <- bandwidth[1:2]
	}
	bandwidth <- signif(xyrange / bandwidth2, 4)
#	bandwidth <- bandwidth2
	bandwidth[bandwidth == 0] <- 1
	
	eb1r <- signif(bandwidth[1],3)
	eb2r <- signif(bandwidth[2],3)
	xdiv <- round(xyrange[1]/bandwidth[1],1)
	ydiv <- round(xyrange[2]/bandwidth[2],1)
	divfc <- round(log2(xdiv/ydiv),4)
	
	XN <- 10  # 'magic number' used for range expansion of density map; KernSmooth::bkde2D default is 1.5
	xexp <- XN*bandwidth[1]
	yexp <- XN*bandwidth[2]
	xlim2 <- c(xlim[1]-xexp, xlim[2]+xexp)  # range extension method lifted from KernSmooth::bkde2D
	ylim2 <- c(ylim[1]-yexp, ylim[2]+yexp)
	
	if (verbose) {
		message(paste(c("Band2:",bandwidth2),collapse=" "))
		message(paste(c("BandW:",bandwidth),collapse=" "))
		message(paste(c("BandD:",bandwidth.def),collapse=" "))
		message(paste(c("xlim:",xlim),collapse=" "))
		message(paste(c("xlim2:",xlim2),collapse=" "))
		message(paste(c("x,y exps:",xexp,yexp),collapse=" "))
		message(paste(c("ylim:",ylim),collapse=" "))
		message(paste(c("ylim2:",ylim2),collapse=" "))
		message(paste(c("xy range:",xyrange[1],"/",xyrange[2]),collapse=" "))
		message("Effective bandwidth: x=", eb1r , " (", xdiv, "), y=", eb2r, " (", ydiv, ") : ", divfc)
	}
#	map <- grDevices:::.smoothScatterCalcDensity(x, nbin, bandwidth)			#### ORIGINAL
	map <- grDevices:::.smoothScatterCalcDensity(x=x, nbin=nbin, bandwidth=bandwidth, range.x=list(xlim2,ylim2))
	map$fhat <- transformation(map$fhat)
	# values <- head(sort(unique(c(map$fhat))))
	# steps <- diff(values)
	# if (steps[1]<steps[2]/10) {
		# ## density rounding error or something, essentially producing "zeroes with nonzero values"
		# IM("zeroing",sum(map$fhat==values[2]),"values")
		# map$fhat[map$fhat==values[2]] <- 0  # restore to zero
	# }
# #	map$fhat <- map$fhat/sum(map$fhat)   # useful for the time when 'fhat.scale' is a operating argument
	
	## 1. Incoming 'colramp' may or may not be a function
	color.bins <- 256
	if (is(colramp, "function")) {		# colramp is a colorRampPalette() function
		colramp2 <- colramp
	} else  {		# colramp is not a colorRampPalette() function
		colramp2 <- palettizer(colramp, n.colors=NA)	# convert palette name to ramp function
		if (!exists("colramp2")) colramp2 <- palettizer("terrain.plus", n.colors=NA)	# palette not found; default to my usual palette for this function
	}
	## 2. 'colramp2' is now a colorRamp function
	cols <- colramp2(color.bins)
	
	## On the operation of 'fhat.scale':
	## A wide variety of approaches have been attempted and all have failed.
	## Multiple issues with comparing fhats must be resolved for it to work:
	## 1. Some fhats have extreme, usually invisible, low-end noise problems which distort the value->color mappings.
	## 2. The number of unique data values varies, which impacts value->color mapping.
	## 3. fhats are not scaled; sums vary widely.
	## 4. It is clear that singletons are not color-mapped equivalently, investigation shows the data is not ratio.
	## 5. Further, the difference between singleton maxima is not the same as between global maxima, so not a linear scaling problem.
	## 6. Given #4-5 it appears that differences in fhat maxima are meaningful, but cannot be properly scaled?
	## 7. Even if #6 is resolved, fhats must be properly denoised/scaled/quantized to create comparable distributions of value->color mappings.
	
	## mixture of various attempts below:
	# if (length(fhat.scale)>0) {
		# fhat.unq1 <- luniq(c(map$fhat))
		# fhat.unq2 <- luniq(c(fhat.scale))
		# fhat.range1 <- c(min(map$fhat[map$fhat>0]), max(map$fhat))
		# fhat.range2 <- c(min(fhat.scale[fhat.scale>0]), max(fhat.scale))
		# fhat.width <- c(diff(fhat.range1), diff(fhat.range2))
		# fhat.ratio <- fhat.unq1/fhat.unq2
# #		color.bins2 <- round(color.bins*fhat.ratio, 0)
		# color.bins2 <- fhat.unq2
		# max.col <- colramp2(color.bins)[color.bins]
		# if (verbose) message(paste(c("this fhat max=",max(map$fhat),", fhat.max=",fhat.max,", fhat.scale=",fhat.scale,", color.bins=",color.bins,", color.bins2=",color.bins2,collapse="")))
		# if (fhat.ratio > 1) {
			# # these levels > scale levels; max density color will saturate at fhat.max instead of max(map$fhat) 
			# # color.bins2 < color.bins
			# pal2 <- c(colramp2(color.bins2), rep(max.col,color.bins-color.bins2))
		# } else {
			# # this max <= scale max; density colors will end where max(map$fhat) resides on the range from 0:fhat.max
			# # color.bins2 >= color.bins
			# pal2 <- colramp2(color.bins2)[1:color.bins]
		# }
		# # cols <- colorRampPalette(pal2)
		# cols <- palettizer(pal2, n.colors=color.bins)
	# } else {
		# cols <- colramp2(color.bins)
	# }
	## 3. cols is now a series of 256 colors
	
	###### END HACK 2 ######
	
	xm <- map$x1
	ym <- map$x2
	dens <- map$fhat
#	dens[] <- transformation(dens)
#	image(xm, ym, z = dens, col = colramp(col.res), xlab = xlab, ylab = ylab, xlim = xlim, ylim = ylim, xaxs = xaxs, yaxs = yaxs, ...)	#### ORIGINAL
	image(xm, ym, z = dens, col = cols, xlab = xlab, ylab = ylab, xlim = xlim, ylim = ylim, xaxs = xaxs, yaxs = yaxs, ...)	#### HACKED
	if (!is.null(postPlotHook)) 
		postPlotHook()
	if (nrpoints > 0) {
		nrpoints <- min(nrow(x), ceiling(nrpoints))
		stopifnot((nx <- length(xm)) == nrow(dens), (ny <- length(ym)) == ncol(dens))
		ixm <- 1L + as.integer((nx - 1) * (x[, 1] - xm[1])/(xm[nx] - xm[1]))
		iym <- 1L + as.integer((ny - 1) * (x[, 2] - ym[1])/(ym[ny] - ym[1]))
		sel <- order(dens[cbind(ixm, iym)])[seq_len(nrpoints)]
		points(x[sel, ], pch = pch, cex = cex, col = col)
	}
	invisible(map)
}


apa.names$plots <- c(apa.names$plots, "pairs2")
pairs2 <- function (x, labels, panel=points, ..., lower.panel=panel, upper.panel=panel, diag.panel=NULL, text.panel=textPanel, label.pos=0.5 + has.diag/3, cex.labels=NULL, font.labels=1, row1attop=TRUE, gap=1, abcol=1, abslope=1, ablty=1, ablwd=1) 
{
    textPanel <- function(x = 0.5, y = 0.5, txt, cex, font) text(x, 
        y, txt, cex = cex, font = font)
    localAxis <- function(side, x, y, xpd, bg, col = NULL, main, 
        oma, ...) {
        if (side%%2 == 1) 
            Axis(x, side = side, xpd = NA, ...)
        else Axis(y, side = side, xpd = NA, ...)
    }
	plotdiag <- function(slope, col, lty, lwd) { if (slope==0) { abline(h=0, col=col, lty=lty, lwd=lwd) } else if (slope == 1) { abline(0, 1, col=col, lty=lty, lwd=lwd) } }
    ##localPlot <- function(..., main, oma, font.main, cex.main, plotab) { plot(...); if (plotab) plotdiag(abslope, abcol, ablty, ablwd) }
    localPlot <- function(..., main, oma, font.main, cex.main) plot(...)
    localLowerPanel <- function(..., main, oma, font.main, cex.main, plotab) { lower.panel(...); if (plotab) plotdiag(abslope, abcol, ablty, ablwd) }
    localUpperPanel <- function(..., main, oma, font.main, cex.main, plotab) { upper.panel(...); if (plotab) plotdiag(abslope, abcol, ablty, ablwd) }
    localDiagPanel <- function(..., main, oma, font.main, cex.main) diag.panel(...)
    dots <- list(...)
    nmdots <- names(dots)
    if (!is.matrix(x)) {
        x <- as.data.frame(x)
        for (i in seq_along(names(x))) {
            if (is.factor(x[[i]]) || is.logical(x[[i]])) 
                x[[i]] <- as.numeric(x[[i]])
            if (!is.numeric(unclass(x[[i]]))) 
                stop("non-numeric argument to 'pairs'")
        }
    }
    else if (!is.numeric(x)) 
        stop("non-numeric argument to 'pairs'")
    panel <- match.fun(panel)
    if ((has.lower <- !is.null(lower.panel)) && !missing(lower.panel)) 
        lower.panel <- match.fun(lower.panel)
    if ((has.upper <- !is.null(upper.panel)) && !missing(upper.panel)) 
        upper.panel <- match.fun(upper.panel)
    if ((has.diag <- !is.null(diag.panel)) && !missing(diag.panel)) 
        diag.panel <- match.fun(diag.panel)
    if (row1attop) {
        tmp <- lower.panel
        lower.panel <- upper.panel
        upper.panel <- tmp
        tmp <- has.lower
        has.lower <- has.upper
        has.upper <- tmp
    }
    nc <- ncol(x)
    if (nc < 2) 
        stop("only one column in the argument to 'pairs'")
    has.labs <- TRUE
    if (missing(labels)) {
        labels <- colnames(x)
        if (is.null(labels)) 
            labels <- paste("var", 1L:nc)
    }
    else if (is.null(labels)) 
        has.labs <- FALSE
    oma <- if ("oma" %in% nmdots) 
        dots$oma
    else NULL
    main <- if ("main" %in% nmdots) 
        dots$main
    else NULL
    if (is.null(oma)) {
        oma <- c(4, 4, 4, 4)
        if (!is.null(main)) 
            oma[3L] <- 6
    }
    opar <- par(mfrow = c(nc, nc), mar = rep.int(gap/2, 4), oma = oma)
    on.exit(par(opar))
    dev.hold()
    on.exit(dev.flush(), add = TRUE)
    for (i in if (row1attop) 
        1L:nc
    else nc:1L) for (j in 1L:nc) {
		plotab <- i!=j
        localPlot(x[, j], x[, i], xlab = "", ylab = "", axes = FALSE, 
            type = "n", ...)
        if (i == j || (i < j && has.lower) || (i > j && has.upper)) {
            box()
            if (i == 1 && (!(j%%2) || !has.upper || !has.lower)) 
                localAxis(1 + 2 * row1attop, x[, j], x[, i], 
                  ...)
            if (i == nc && (j%%2 || !has.upper || !has.lower)) 
                localAxis(3 - 2 * row1attop, x[, j], x[, i], 
                  ...)
            if (j == 1 && (!(i%%2) || !has.upper || !has.lower)) 
                localAxis(2, x[, j], x[, i], ...)
            if (j == nc && (i%%2 || !has.upper || !has.lower)) 
                localAxis(4, x[, j], x[, i], ...)
            mfg <- par("mfg")
            if (i == j) {
                if (has.diag) 
                  localDiagPanel(as.vector(x[, i]), ...)
                if (has.labs) {
                  par(usr = c(0, 1, 0, 1))
                  if (is.null(cex.labels)) {
                    l.wid <- strwidth(labels, "user")
                    cex.labels <- max(0.8, min(2, 0.9/max(l.wid)))
                  }
                  text.panel(0.5, label.pos, labels[i], cex = cex.labels, 
                    font = font.labels)
                }
            }
            else if (i < j) 
                localLowerPanel(as.vector(x[, j]), as.vector(x[, 
                  i]), plotab=plotab, ...)
            else localUpperPanel(as.vector(x[, j]), as.vector(x[, 
                i]), plotab=plotab, ...)
            if (any(par("mfg") != mfg)) 
                stop("the 'panel' function made a new plot")
        }
        else par(new = FALSE)
    }
    if (!is.null(main)) {
        font.main <- if ("font.main" %in% nmdots) 
            dots$font.main
        else par("font.main")
        cex.main <- if ("cex.main" %in% nmdots) 
            dots$cex.main
        else par("cex.main")
        mtext(main, 3, 3, TRUE, 0.5, cex = cex.main, font = font.main)
    }
    invisible(NULL)
}


apa.names$plots <- c(apa.names$plots, "cross.pairs")
cross.pairs <- function(x, y=NULL, xname=NULL, yname=NULL, col="#00000044", pch=1, abcol=4, ablty=1, pt.cex=0.75, text.cex=1, R=FALSE) {
    
    ## Like pairs(), but can plot columns of matrix x vs matrix y.  Also has ablines.
    
    if (length(y)==0) {
        y <- x
    } else if (nrow(x)!=nrow(y)) {
        stop("'x' and 'y' must have same number of rows!\n")
    }

    NCX <- ncol(x)+1
    NCY <- ncol(y)+1
    xrange <- range(c(x)[!is.infinite(c(x))], na.rm=TRUE)
    yrange <- range(c(y)[!is.infinite(c(y))], na.rm=TRUE)
    
    if (length(xname)>0) {
        xnames <- paste(xname, colnames(x), sep="\n")
    } else {
        xnames <- colnames(x)
    }
    xnames <- c("", xnames)
    if (length(yname)>0) {
        ynames <- paste(yname, colnames(y), sep="\n")
    } else {
        ynames <- colnames(y)
    }
    ynames <- c(ynames, "")
    
    par(mfcol=c(NCX,NCY), mar=c(2,2,0,0), las=1)
    
    for (i in 1:NCX) {
        yaxt <- ifelse (i==2, "s", "n")
        if (i==1) {
            ## first col; plot y names
            for (j in 1:NCY) {
                plot(0, 0, col=0, xlab="", ylab="", main="", xaxt="n", yaxt="n", frame.plot=j!=NCY)
                if (j==NCY) next
                text(0, 0, font=2, cex=text.cex*1.2, labels=ynames[j])
            }
        } else {
            for (j in 1:NCY) {
                xaxt <- ifelse (j==NCY-1, "s", "n")
                if (j==NCY) {
                    ## last row; plot x names
                    plot(0, 0, col=0, xlab="", ylab="", main="", xaxt="n", yaxt="n")
                    text(0, 0, font=2, cex=text.cex*1.2, labels=xnames[i])
                } else {
                    xy <- cbind(x[,i-1], y[,j])
                    xy <- xy[apply(!is.na(xy)&!is.infinite(xy), 1, all),]
                    plot(xy, col=col, pch=pch, cex=pt.cex, xlim=xrange, ylim=yrange, xlab="", ylab="", main="", xaxt=xaxt, yaxt=yaxt)
                    abline(0, 1, col=abcol, lty=ablty)
                    if (R) text(mean(xrange), max(yrange)*0.95, font=2, col=abcol, cex=text.cex, labels=paste("R =",round(cor(xy[,1],xy[,2]),3)))
                }
            }
        }
    }
}


apa.names$plots <- c(apa.names$plots, "legend2")
legend2 <- function (x, y=NULL, legend, fill=NULL, col=par("col"), border="black", lty, lwd, pch, angle=45, density=NULL, 
	bty="o", bg=par("bg"), box.lwd=par("lwd"), box.lty=par("lty"), box.col=par("fg"), pt.bg=NA, cex=1, pt.cex=cex, pt.lwd=lwd, 
	xjust=0, yjust=1, x.intersp=1, y.intersp=1, adj=c(0, 0.5), text.width=NULL, text.col=par("col"), merge=do.lines && 
		has.pch, trace=FALSE, plot=TRUE, ncol=1, horiz=FALSE, title=NULL, inset=0, xpd, title.col=text.col, font=1) {

	# lots of code streamlining, but only one very slight hack, to support the use of "font" attribute

	if (missing(legend) && !missing(y) && (is.character(y) || is.expression(y))) {
		legend <- y
		y <- NULL
	}
	mfill <- !missing(fill) || !missing(density)
	if (!missing(xpd)) {
		op <- par("xpd")
		on.exit(par(xpd = op))
		par(xpd = xpd)
	}
	title <- as.graphicsAnnot(title)
	if (length(title) > 1) { stop("invalid title") }
	legend <- as.graphicsAnnot(legend)
	n.leg <- ifelse (is.call(legend), 1, length(legend))
	if (n.leg == 0) { stop("'legend' is of length 0") }
	auto <- ifelse (is.character(x), match.arg(x, c("bottomright","bottom","bottomleft","left","topleft","top","topright","right","center")), NA)
	if (is.na(auto)) {
		xy <- xy.coords(x, y)
		x <- xy$x
		y <- xy$y
		nx <- length(x)
		if (nx < 1 || nx > 2) { stop("invalid coordinate lengths") }
	} else { nx <- 0 }
	xlog <- par("xlog")
	ylog <- par("ylog")
	rect2 <- function(left, top, dx, dy, density = NULL, angle, ...) {
		r <- left + dx
		if (xlog) {
			left <- 10^left
			r <- 10^r
		}
		b <- top - dy
		if (ylog) {
			top <- 10^top
			b <- 10^b
		}
		rect(left, top, r, b, angle = angle, density = density, ...)
	}
	segments2 <- function(x1, y1, dx, dy, ...) {
		x2 <- x1 + dx
		if (xlog) {
			x1 <- 10^x1
			x2 <- 10^x2
		}
		y2 <- y1 + dy
		if (ylog) {
			y1 <- 10^y1
			y2 <- 10^y2
		}
		segments(x1, y1, x2, y2, ...)
	}
	points2 <- function(x, y, ...) {
		if (xlog) { x <- 10^x }
		if (ylog) { y <- 10^y }
		points(x, y, ...)
	}
	text2 <- function(x, y, ...) {
		if (xlog) { x <- 10^x }
		if (ylog) { y <- 10^y }
		text(x, y, ...)
	}
	if (trace) { catn <- function(...) do.call("cat", c(lapply(list(...), formatC), list("\n"))) }
	cin <- par("cin")
	Cex <- cex * par("cex")
	if (is.null(text.width)) { text.width <- max(abs(strwidth(legend, units = "user", cex = cex))) 
	} else if (!is.numeric(text.width) || text.width < 0) { stop("'text.width' must be numeric, >= 0") }
	xc <- Cex * xinch(cin[1L], warn.log = FALSE)
	yc <- Cex * yinch(cin[2L], warn.log = FALSE)
	if (xc < 0) { text.width <- -text.width }
	xchar <- xc
	xextra <- 0
	yextra <- yc * (y.intersp - 1)
	ymax <- yc * max(1, strheight(legend, units = "user", cex = cex)/yc)
	ychar <- yextra + ymax
	if (trace) { catn("  xchar=", xchar, "; (yextra,ychar)=", c(yextra, ychar)) }
	if (mfill) {
		xbox <- xc * 0.8
		ybox <- yc * 0.5
		dx.fill <- xbox
	}
	do.lines <- (!missing(lty) && (is.character(lty) || any(lty > 0))) || !missing(lwd)
	n.legpercol <- if (horiz) {
		if (ncol != 1) { warning("horizontal specification overrides: Number of columns := ", n.leg) }
		ncol <- n.leg
		1
	} else { ceiling(n.leg/ncol) }
	has.pch <- !missing(pch) && length(pch) > 0
	if (do.lines) {
		x.off <- ifelse (merge, -0.7, 0)
	} else if (merge) { warning("'merge = TRUE' has no effect when no line segments are drawn") }
	if (has.pch) {
		if (is.character(pch) && !is.na(pch[1L]) && nchar(pch[1L], type = "c") > 1) {
			if (length(pch) > 1) { warning("not using pch[2..] since pch[1L] has multiple chars") }
			np <- nchar(pch[1L], type = "c")
			pch <- substr(rep.int(pch[1L], np), 1L:np, 1L:np)
		}
	}
	if (is.na(auto)) {
		if (xlog) { x <- log10(x) }
		if (ylog) { y <- log10(y) }
	}
	if (nx == 2) {
		x <- sort(x)
		y <- sort(y)
		left <- x[1L]
		top <- y[2L]
		w <- diff(x)
		h <- diff(y)
		w0 <- w/ncol
		x <- mean(x)
		y <- mean(y)
		if (missing(xjust)) { xjust <- 0.5 }
		if (missing(yjust)) { yjust <- 0.5 }
	} else {
		h <- (n.legpercol + (!is.null(title))) * ychar + yc
		w0 <- text.width + (x.intersp + 1) * xchar
		if (mfill) 
			w0 <- w0 + dx.fill
		if (do.lines) 
			w0 <- w0 + (2 + x.off) * xchar
		w <- ncol * w0 + 0.5 * xchar
		if (!is.null(title) && (abs(tw <- strwidth(title, units = "user", 
			cex = cex) + 0.5 * xchar)) > abs(w)) {
			xextra <- (tw - w)/2
			w <- tw
		}
		if (is.na(auto)) {
			left <- x - xjust * w
			top <- y + (1 - yjust) * h
		} else {
			usr <- par("usr")
			inset <- rep(inset, length.out = 2)
			insetx <- inset[1L] * (usr[2L] - usr[1L])
			left <- switch(auto, bottomright = , topright = , 
				right = usr[2L] - w - insetx, bottomleft = , 
				left = , topleft = usr[1L] + insetx, bottom = , 
				top = , center = (usr[1L] + usr[2L] - w)/2)
			insety <- inset[2L] * (usr[4L] - usr[3L])
			top <- switch(auto, bottomright = , bottom = , bottomleft = usr[3L] + 
				h + insety, topleft = , top = , topright = usr[4L] - 
				insety, left = , right = , center = (usr[3L] + 
				usr[4L] + h)/2)
		}
	}
	if (plot && bty != "n") {
		if (trace) { catn("  rect2(", left, ",", top, ", w=", w, ", h=", h, ", ...)", sep = "") }
		rect2(left, top, dx = w, dy = h, col = bg, density = NULL, lwd = box.lwd, lty = box.lty, border = box.col)
	}
	xt <- left + xchar + xextra + (w0 * rep.int(0:(ncol - 1), rep.int(n.legpercol, ncol)))[1L:n.leg]
	yt <- top - 0.5 * yextra - ymax - (rep.int(1L:n.legpercol, ncol)[1L:n.leg] - 1 + (!is.null(title))) * ychar
	if (mfill) {
		if (plot) {
			fill <- rep(fill, length.out = n.leg)
			rect2(left = xt, top = yt + ybox/2, dx = xbox, dy = ybox, col = fill, density = density, angle = angle, border = border)
		}
		xt <- xt + dx.fill
	}
	if (plot && (has.pch || do.lines)) { col <- rep(col, length.out = n.leg) }
	if (missing(lwd)) { lwd <- par("lwd") }
	if (do.lines) {
		seg.len <- 2
		if (missing(lty)) { lty <- 1 }
		lty <- rep(lty, length.out = n.leg)
		lwd <- rep(lwd, length.out = n.leg)
		ok.l <- !is.na(lty) & (is.character(lty) | lty > 0)
		if (trace) { catn("  segments2(", xt[ok.l] + x.off * xchar, ",", yt[ok.l], ", dx=", seg.len * xchar, ", dy=0, ...)") }
		if (plot) { segments2(	xt[ok.l] + x.off * xchar, yt[ok.l], dx = seg.len * xchar, dy = 0, lty = lty[ok.l], 
					lwd = lwd[ok.l], col = col[ok.l] ) }
		xt <- xt + (seg.len + x.off) * xchar
	}
	if (has.pch) {
		pch <- rep(pch, length.out = n.leg)
		pt.bg <- rep(pt.bg, length.out = n.leg)
		pt.cex <- rep(pt.cex, length.out = n.leg)
		pt.lwd <- rep(pt.lwd, length.out = n.leg)
		ok <- !is.na(pch) & (is.character(pch) | pch >= 0)
		x1 <- (if (merge && do.lines) { xt - (seg.len/2) * xchar } else { xt })[ok]
		y1 <- yt[ok]
		if (trace) { catn("  points2(", x1, ",", y1, ", pch=", pch[ok], ", ...)") }
		if (plot) { points2(x1, y1, pch = pch[ok], col = col[ok], cex = pt.cex[ok], bg = pt.bg[ok], lwd = pt.lwd[ok]) }
	}
	xt <- xt + x.intersp * xchar
	if (plot) {
		if (!is.null(title)) { text2(left + w/2, top - ymax, labels = title, adj = c(0.5, 0), cex = cex, col = title.col) }
		text2(xt, yt, labels = legend, adj = adj, cex = cex, col = text.col, font = font)
	}
	invisible(list(rect = list(w = w, h = h, left = left, top = top), text = list(x = xt, y = yt)))
}


apa.names$plots <- c(apa.names$plots, "CAT.enrichment.frame")
CAT.enrichment.frame <- function(a, N, fixed, limit) {

	if (fixed) {
		breaks <- seq(0, length(a), N)
		if (length(a) %% N > 0) breaks <- c(breaks, length(a))
	} else {
		breaks <- floor( seq(0, length(a), length.out=N) )
	}
	B <- length(breaks)

	xmax <- ceiling(B*limit/100)		# x axis plot limit, in terms of # bins
	if (xmax <= 10) {	# don't make custom axes -- use actual bins
		axbins <- 1:xmax
		axlabs <- breaks[1:xmax]
	} else {
		scale <- trunc(xmax / 10)
		if (xmax %% 10 > 0) scale <- scale + 1
		axbins <- seq(1, xmax, scale)
		if (limit == 100 && length(axbins) <= 10) axbins <- c(axbins, length(breaks))
		axlabs <- breaks[axbins]
	}
	
	list(breaks=breaks, B=B, xmax=xmax, axbins=axbins, axlabs=axlabs)
}

	
apa.names$plots <- c(apa.names$plots, "CAT.plot")
CAT.plot <- function(a, b, N, fixed=TRUE, decreasing=TRUE, add.line=FALSE, limit.pct=100, xlim=NULL, ylim=c(0,1), diag=TRUE, main=NULL, col=1, lty=1, lwd=1, R.line=FALSE, R.log=FALSE, R.col=1, R.lty=3, R.lwd=1) {
	
	## Takes two NAMED numeric vectors of equal length (a, b) and makes a CAT (Correspondence-At-the-Top) plot from them.
	## "N": bin increment for breaking up the input list - CAT scores checked at each break.
	## "fixed": interpret "N" as N items per bin (TRUE) or as N bins for whole list (FALSE)?
	## "decreasing": if false, sort vectors increasing (i.e. lowest values first)-- get CAB (Correspondence-At-the-Bottom) plot.
	## "add.line = T": add CAT plot as a line to an existing plot .
	## "add.line = F": generate a new plot.
	## "col", "lty", "lwd" control plot line appearance (all work for either "add.line" mode).
	## "R.line = T": add a new line, plotting the correlation value for the set overlaps.  ("RAT" plot: "R-value-at-the-top").
	## "R.log = T": correlate log-values (otherwise, linear).
	## "R.col", "R.lty", "R.lwd" apply to the R line.
	## The following only apply for "add.line = F":
	##   "limit.pct": percent cutoff re: how much of the list tops the plot should show (don't plot beyond the top limit.pct%).
	##   "diag": plots the diagonal (line of random enrichment; grey dashed line).
	##   "main": gives a title to the CAT plot.
	
	if ( length(a) != length(b) ) stop("Vectors a, b must be of same length!\n")
	if ( is.null(names(a)) | is.null(names(b)) ) stop("Vectors a, b must both be named! (i.e. have non-null names()\n")
	a <- a[order(a, decreasing=decreasing)]
	b <- b[order(b, decreasing=decreasing)]
	
	vars <- CAT.enrichment.frame(a, N, fixed, limit.pct)
	breaks <- vars$breaks
	B <- vars$B
	xmax <- vars$xmax
	axbins <- vars$axbins
	axlabs <- vars$axlabs
	
	data <- list(set.size=breaks, overlap=c(0), overlap.pct=c(0), overlap.names=vector("list", length=B))
	
	if (length(B) > 1000) {
		message("High bin count; this may take a minute...\n")
		flush.console()
	}
	if (R.line) {
		message("Correlation line added; this will take extra time...\n")
		flush.console()
	}
	
	for (i in 2:B) {
		N.a <- names(a)[1:breaks[i]]
		N.b <- names(b)[1:breaks[i]]
		I <- intersect(N.a, N.b)
		U <- union(N.a, N.b)
		if (length(I) > 0) data$overlap[i] <- length(I)
		data$overlap.pct[i] <- length(I) / length(U)
		if (R.line) { 
			if (length(I) > 3) {
				x <- a[match(I,names(a))]
				y <- b[match(I,names(b))]
				data$overlap.corr[i] <- ifelse(R.log, cor(log(x), log(y), method="pearson"), cor(x, y, method="pearson"))
			} else {
				data$overlap.corr[i] <- NA
			}
		}
		data$overlap.names[[i]] <- I
#		report.index(i, 5000)
	}
	
	if (add.line) {
		lines(1:B, data$overlap.pct, col=col, lty=lty, lwd=lwd) 
	} else {
		if (is.null(xlim)) xlim=c(1,xmax)
		if (is.null(main)) main <- ifelse(decreasing, "CAT Plot", "CAB Plot")
		plot(1:B, data$overlap.pct, type="n", ylim=ylim, xlim=xlim, ylab="Percent Overlap", xlab="Set Size", main=main, xaxt="n")
		if (diag) segments(1, 0, B, 1, lty=2, col="grey50")
		lines(1:B, data$overlap.pct, col=col, lty=lty, lwd=lwd)
		axis(1, at=axbins, labels=axlabs)
	}
	
	if (R.line) lines(1:B, data$overlap.corr, col=R.col, lty=R.lty, lwd=R.lwd)
	
	invisible(data)
}


apa.names$plots <- c(apa.names$plots, "enrichment.curve")
enrichment.curve <- function(a, N, fixed=TRUE, add.line=FALSE, limit=100, ylim=c(0,1), diag=TRUE, main=NULL, col=1, lty=1, lwd=1) {
	
	## Takes a sorted numeric or binary vector and plots and enrichment curve, basically the CDF for a GSEA-style metric.
	## "N": bin increment for breaking up the input list - CAT scores checked at each break.
	## "fixed": interpret "N" as N items per bin (TRUE) or as N bins for whole list (FALSE)?
	## "decreasing": if false, sort vectors increasing (i.e. lowest values first)-- get CAB (Correspondence-At-the-Bottom) plot
	## "add.line = T": add CAT plot as a line to an existing plot 
	## "add.line = F": generate a new plot
	## "col", "lty", "lwd" control plot line appearance (all work for either "add.line" mode)
	## The following only apply for "add.line = F":
	##   "limit": percent cutoff re: how much of the list tops the plot should show (don't plot beyond the top limit%)
	##   "diag": plots the diagonal (line of random enrichment; grey dashed line)
	##   "main": gives a title to the plot
	
	vars <- CAT.enrichment.frame(a, N, fixed, limit)
	breaks <- vars$breaks
	B <- vars$B
	xmax <- vars$xmax
	axbins <- vars$axbins
	axlabs <- vars$axlabs
	
	data <- list(set.size=breaks, overlap=c(0), overlap.pct=c(0), overlap.names=vector("list", length=B))
	
	if (add.line == T) {
		lines(1:B, data$overlap.pct, col=col, lty=lty, lwd=lwd) 
	} else {
		if (is.null(main)) ternary ( decreasing, main <- "CAT Plot", main <- "CAB Plot" )
		plot(	1:B, data$overlap.pct, type="n", ylim=ylim, xlim=c(1,xmax), 
			ylab="Percent Overlap", xlab="Set Size", main=main, xaxt="n" )
		if (diag == T) segments(1, 0, B, 1, lty=2, col="grey50")
		lines(1:B, data$overlap.pct, col=col, lty=lty, lwd=lwd)
		axis(1, at=axbins, tick=TRUE, labels=axlabs)
	}
	invisible(data)
}


apa.names$plots <- c(apa.names$plots, "plot.lastz.pairs")
plot.lastz.pairs <- function(x, maxgap=100, query.name=NULL, subject.name=NULL) {
	
	## where 'x' is the output of /home/apa/local/bin/runLastz in 'pairwise' mode, an 8-column tab-separated text file where columns 1-8 are:
	##  Query Start, Query End, Subject Start, Subject End, Block Length, Block Identity %, Query Gap (Preceding Block), Subject Gap (Preceding Block).
	## 'maxgap' sets the maximum gap size (i.e. 0 <= this_gap <= maxgap) to ignore.  Gaps > maxgap or gaps < 0 will "break" the current plot-block and start a new one.
        ## 'query.name', 'subject.name' are for the plot
        
        qcols <- 2:4
        scols <- 5:7
        ecols <- c(8,"darkorange","purple3")
    
	q.runs <- find.runs((x[,7] >= 0 & x[,7] <= maxgap)+0)
        if (length(q.runs[[length(q.runs)]])==0) q.runs[[length(q.runs)]] <- c()  # remove any NULL final element
        q.runs.0 <- q.runs[names(q.runs)==0]
        q.runs.1 <- q.runs[names(q.runs)==1]
        q.runs.x <- c(list(q.runs.1[[1]][1]:q.runs.1[[1]][2]), lapply(q.runs.1[2:length(q.runs.1)], function(y){ (y[1]-1):y[2] }))
        lost <- setdiff(1:nrow(x), unlist(q.runs.x))
        if (length(lost)>0) message(paste("Warning: some blocks were lost:",paste(lost,collapse=',')))
 	qN <- length(q.runs.x)
        
	s.runs <- find.runs((x[,8] >= 0 & x[,8] <= maxgap)+0)
        if (length(s.runs[[length(s.runs)]])==0) s.runs[[length(s.runs)]] <- c()  # remove any NULL final element
        s.runs.0 <- s.runs[names(s.runs)==0]
        s.runs.1 <- s.runs[names(s.runs)==1]
        s.runs.x <- c(list(s.runs.1[[1]][1]:s.runs.1[[1]][2]), lapply(s.runs.1[2:length(s.runs.1)], function(y){ (y[1]-1):y[2] }))
        lost <- setdiff(1:nrow(x), unlist(s.runs.x))
        if (length(lost)>0) message(paste("Warning: some blocks were lost:",paste(lost,collapse=',')))
 	sN <- length(s.runs.x)
        
        edges <- qblocks <- sblocks <- list()
        for (i in 1:qN) {
            start <- q.runs.x[[i]][1]
            end <- q.runs.x[[i]][length(q.runs.x[[i]])]
            qblocks[[i]] <- c(x[start,1], x[end,2])
            edges[[i]] <- c(x[start,1], x[end,2], x[start,3], x[end,4], mean(c(x[start,1],x[end,2])), mean(c(x[start,3],x[end,4])))  # for block: q start, q end, s start, s end, q mid, s mid
        }
        for (i in 1:sN) {
            start <- s.runs.x[[i]][1]
            end <- s.runs.x[[i]][length(q.runs.x[[i]])]
            sblocks[[i]] <- c(x[start,3], x[end,4])
            edges[[qN+i]] <- c(x[start,1], x[end,2], x[start,3], x[end,4], mean(c(x[start,1],x[end,2])), mean(c(x[start,3],x[end,4])))  # for block: q start, q end, s start, s end, q mid, s mid
        }
        edges <- unique(do.call(rbind,edges))
        qblocks <- do.call(rbind,qblocks)
        qblocks <- cbind(qblocks[order(qblocks[,1]),], 1:qN)
        sblocks <- do.call(rbind,sblocks)
        sblocks <- cbind(sblocks[order(sblocks[,1]),], (qN+2):(qN+sN+1))
        
        xlim <- c(min(x[1,c(1,3)]), max(x[nrow(x),c(2,4)]))
        ylim <- c(0, qN+sN+3)
        q.ymid <- mean(qblocks[,3])
        s.ymid <- mean(sblocks[,3])

        par(mfrow=c(1,2))

        # plot 1: query -> subject
        plot(0, 0, col=0, axes=FALSE, ann=FALSE, xlim=xlim, ylim=ylim)
        rect(x[1,1], ylim[1], x[nrow(x),2], ylim[1]+0.5, col=0, border=1)  # query coverage bar
        
        for (i in 1:qN) {
            rect(qblocks[i,1], qblocks[i,3], qblocks[i,2], qblocks[i,3]+1, col=qcols[i%%3+1], border=qcols[i%%3+1])
            rect(qblocks[i,1], ylim[1], qblocks[i,2], ylim[1]+0.5, col="#00000044", border=NA)
        }
        for (i in 1:sN) {
            rect(sblocks[i,1], sblocks[i,3], sblocks[i,2], sblocks[i,3]+1, col=scols[i%%3+1], border=scols[i%%3+1])
            rect(sblocks[i,1], ylim[2]-0.5, sblocks[i,2], ylim[2], col="#00000044", border=NA)
        }
        for (i in 1:qN) {
            j <- which(edges[,1]==qblocks[i,1] & edges[,2]==qblocks[i,2])
            k <- which(sblocks[,1]==edges[j,3] & sblocks[,2]==edges[j,4])
            segments(edges[j,5], qblocks[i,3]+1, edges[j,6], sblocks[k,3], col=ecols[i%%3+1])
        }
        mtext(paste(query.name,"coverage on",subject.name), 1, 0)
        mtext(paste(subject.name,"coverage on",query.name), 3, 0)
        mtext(query.name, 2, 0, at=q.ymid)
        mtext(subject.name, 2, 0, at=s.ymid)

        
        # plot 2: subject -> query
        plot(0, 0, col=0, axes=FALSE, ann=FALSE, xlim=xlim, ylim=ylim)
        rect(x[1,1], ylim[1], x[nrow(x),2], ylim[1]+0.5, col=0, border=1)  # query coverage bar
 #       rect(x[1,3], ylim[2]-0.5, x[nrow(x),4], ylim[2], col=0, border=1)  # subject coverage bar
        
        for (i in 1:qN) {
            rect(qblocks[i,1], qblocks[i,3], qblocks[i,2], qblocks[i,3]+1, col=qcols[i%%3+1], border=qcols[i%%3+1])
            rect(qblocks[i,1], ylim[1], qblocks[i,2], ylim[1]+0.5, col="#00000044", border=NA)
        }
        for (i in 1:sN) {
            rect(sblocks[i,1], sblocks[i,3], sblocks[i,2], sblocks[i,3]+1, col=scols[i%%3+1], border=scols[i%%3+1])
            rect(sblocks[i,1], ylim[2]-0.5, sblocks[i,2], ylim[2], col="#00000044", border=NA)
        }
        for (i in 1:qN) {
            j <- which(edges[,1]==qblocks[i,1] & edges[,2]==qblocks[i,2])
            k <- which(sblocks[,1]==edges[j,3] & sblocks[,2]==edges[j,4])
            segments(edges[j,5], qblocks[i,3]+1, edges[j,6], sblocks[k,3], col=ecols[i%%3+1])
        }
        mtext(paste(query.name,"coverage on",subject.name), 1, 0)
        mtext(paste(subject.name,"coverage on",query.name), 3, 0)
        mtext(query.name, 2, 0, at=q.ymid)
        mtext(subject.name, 2, 0, at=s.ymid)
        
}


apa.names$general <- c(apa.names$general, "quantile.distort")
quantile.distort <- function(x, n, d, r=1E6, resamp=FALSE) {
	
	## takes a vector x and a distribution d, and returns a vector of length n (# quantiles).
	## here we assume that x reflects a linear spread of values and d does not.
	## will not work unless length(x) < n < length(d).  x must be ordered, but not necessarily numeric.
	## r is maximum quantile resolution.  If n is large and d has high positive kurtosis, this can create extreme quantile resolutions.  If > r, algo will stop (instead of running forever)
	## also note: distributions do have a maximum quantile resolution, i.e. the number of quantiles for which unique quantile values can be calculated.  High kurtosis can reduce this number very fast.
	##  thus if n is too large for d, your result will be shorter than n (and you will get a warning).
	##
	## toy example: let's distort the range 1:5 via the normal distribution, returning a vector of length 20:
	##  x=1:5, n=10, d=rnorm(0, 1, 100)
	##  returns: c(
	
	lx <- length(x)
	lqt <- incr <- 0
	while (lqt-1 < lx) {   # requesting lx quantiles gets < lx unique quantiles: must increase # quantiles until lx uniques exist
		incr <- incr + 1
		qt <- quantile(real(d), seq(0,1,length=lx+incr))
		dupqt <- duplicated(qt)
		if (any(dupqt)) { qt <- qt[!dupqt] }     # identical quantiles exist (extreme positive kurtosis): merge and re-evaluate
		lqt <- length(qt)    # AFTER duplicate removal
	}
#	IM("increased",incr-1,"times")
	dq <- diff(qt)  # has length = length(qt)-1 = length(x)
	ndec <- sapply(dq, function(x){as.numeric(strsplit(format(abs(x), sci=TRUE),"-")[[1]][2])})   # number of decimals after 0 at which nonzero values begin
	ndec[is.na(ndec)] <- 0
	max1d <- max(ndec)  # order of smallest quantile difference
	max2d <- max(ndec[ndec<max(ndec)])  # order of next-smallest quantile difference
#	IM(max1d,max2d)
	if (max1d > max2d+2) {  # 2 is arbitrary outlier cutoff: this indicates that max1d is an outlier (usually one that should be 0.0 but gets #e-16, for instance)
		IM(max1d,">",max2d,"+2")
		dq[which.max(ndec)] <- round(dq[which.max(ndec)], max2d+2)  # bring order into non-outlier range
		ndec <- sapply(dq, function(x){as.numeric(strsplit(format(abs(x), sci=TRUE),"-")[[1]][2])})   # post-rounding: number of decimals after 0 at which nonzero values begin
		ndec[is.na(ndec)] <- 0
	}
	sigd <- max(ndec)  # how many sig dig do we have to use before we can fully resolve all quantile values?
	res <- 1 / 10^sigd
	qbins <- round((qt[lqt] - qt[1]) / res, 0)   # quantile resolution = how many bins will d be broken into using the smallest observed quantile
#	IM(lqt, length(dq), sigd, res, qbins, r)
	if (qbins > r) {   # quantile resolution too high; runtime could explode.  Value of n was too ambitious, or d is really skewed.
		stop(paste("Required quantile resolution of",qbins,"exceeds max resolution of",r,"\nDistribution too skewed!  Decrease n or increase r\n")) 
	}
	# if (qbins > r) {   # quantile resolution too high; runtime could explode.  Value of n was too ambitious, or d is really skewed.
		# IM("Required quantile resolution of",qbins,"exceeds max resolution of",r)
	# }
	pre <- rep(NA, qbins+1)   # initial size; will probably wind up extending beyond this
	end <- 0
	for (i in 1:lx) {  # for each color value,
		start <- end + 1
		end <- start + round(dq[i] / res,0)
#		IM(i, start, end, dq[i])
		pre[start:end] <- x[i]
	}
	out <- pre[round(seq(1,length(pre),length=n),0)]  # evenly downsample to meet length requirements
	return(out)
}


apa.names$plots <- c(apa.names$plots, "color.thresholds")
color.thresholds <- function(x, diverging=NULL, quant=0.95) {
    
    ## determine thresholding limits for a heatmap matrix being imaged
    ## basically, we want to throttle outliers to prevent colors getting washed out
    ## 'diverging' indicates use of a diverging values/palette; value is the central value of the distribution (normally 0)

    x <- real(x)
    if (length(x)>1E6) x <- sample(x,1E5)

    limit.old <- function(y) {
        p <- percentiles(y)
        pm <- median(nonzero(p))
        pf <- p/pm
        p[which(pf>=10)-1]
    }
    limit <- function(y) {
        if (min(y)>=0) {
            ## all pos
            nameless(c(0, quantile(y,quant)))
        } else if (max(y)<=0) {
            ## all neg
            nameless(c(-quantile(abs(y),quant), 0))
        } else if (min(y)<0 & max(y)>0) {
            ## straddles 0
            z <- y-median(y)
            yn <- abs(y[y<0])
            yp <- y[y>0]
            nnz <- sum(z==0)
            if (nnz%%2==0) {
                yn <- c(yn, rep(0,nnz/2))
                yp <- c(yp, rep(0,nnz/2))
            } else {
                yn <- c(yn, rep(0,floor(nnz/2)))
                yp <- c(yp, rep(0,ceiling(nnz/2)))
            }
            nameless(c( -quantile(yn,quant), quantile(yp,quant) ))
        }
    }
    
    if (is.null(diverging)) {
        limit(x)
    } else {
        diverging + limit(x-diverging)
        ##diverging + c( -limit(abs(x[x<0])), limit(x[x>0]) )
    }
}


apa.names$plots <- c(apa.names$plots, "color.scale")
color.scale <- function(val.range, pal, main=NULL, breaks=11, hv=2, las=2, cex=par()$cex, cex.axis=par()$cex.axis) {
	
	## plots a color scale, given a range of numeric values (val), a palette (pal), the number of 'val' breaks to display (breaks), and a horiz/vert flag (hv)
	## like axes, hv=1 for horizontal and hv=2 for vertical.
	
	pal.val <- 1:length(pal)
	pal.r <- range(pal.val)
	if (hv == 1) {
		arg <- c(length(pal.val), 1, 1)  # image nrow, image ncol, axis side
	} else if (hv == 2) {
		arg <- c(1, length(pal.val), 2)
	} else {
		stop("'hv' must be 1 (horizontal) or 2 (vertical)!\n")
	}
	ax.seq <- seq(pal.r[1],pal.r[2],length.out=breaks)
	ax.lab <- sapply(seq(val.range[1],val.range[2],length.out=breaks),FUN=function(x){signif(x,3)})
	image(1, pal.val, matrix(pal.val, arg[1], arg[2]), col=pal, xlab="", ylab="", xaxt="n", yaxt="n", main=main)
	axis(arg[3], at=ax.seq, labels=ax.lab, las=las, cex.axis=cex.axis)
}


apa.names$plots <- c(apa.names$plots, "palette.mapping")
palette.mapping <- function(val, pal, rev.pal=FALSE, col.limits=NULL, col.center=NULL, quant.cols=FALSE, max.cols=256, max.qres=1E6, interpolate=NULL) {
	
	## Function to handle color-to-value mapping and palette distortion
	## Intended for matrix-plotting functions like heat.map, myImagePlotUltra, etc.
	## 'val' is either a vector or matrix containing values to be plotted
	## 'pal' is a name/vector resolvable by palettizer()
	## other args are as they are for myImagePlotUltra, and with same defaults
	
	vrange <- range(val, na.rm=TRUE)	# plottable value range
    colctr <- FALSE						# col centering off, initially
	scale.range <- vrange				# color scale limits, initially
	
	lcl <- length(col.limits)
	lcc <- length(col.center)
	if (lcl!=0 & lcl!=2) stop("'col.limits' must be NULL or a length-2 vector!")
	if (lcc!=0 & lcc!=1) stop("'col.center' must be NULL or a length-1 vector!")
	
	if (lcl==2 & lcc==1) {
		
		stop("Not yet ready for color limiting and centering at the same time!")
		
		## CODE BELOW JUST DUMPED HERE
		
		scale.range <- col.limits
        scale.colors <- palettizer(pal, max.cols, interpolate, NULL, rev.pal)
        if (!exists("scale.colors")) stop("No palette to use: cannot proceed!\n")
        scale.values <- seq(scale.range[1], scale.range[2], length=length(scale.colors))	# initial color scale (may be too wide)
        terminal.values <- quantize(vrange, scale.values)
		terminal.positions <- quantize(vrange, scale.values, indices=TRUE)
		matrix.colors <- scale.colors[terminal.positions[1]:terminal.positions[2]]
		
		colctr <- TRUE
        ## make and arrange half-palettes if color scale is centered
        percol <- diff(scale.range) / max.cols
        col.fracs <- col.ranges <- c(0,0)
        col.fracs[1] <- (col.center - scale.range[1]) / percol   # fraction below center
        col.fracs[2] <- (scale.range[2] - col.center) / percol   # fraction above center
        half.palettes <- palettizer(pal, max.cols, interpolate, round(col.fracs,0), FALSE)  # palette, n.colors=NA, interpolate=NULL, halves=c(lower.res,upper.res), reverse=FALSE
        scale.colors <- unlist(half.palettes)
        scale.values <- seq(vrange[1], vrange[2], length=length(scale.colors))
		
    } else if (lcl==2) {
		
		scale.range <- col.limits
        scale.colors <- palettizer(pal, max.cols, interpolate, NULL, rev.pal)
        if (!exists("scale.colors")) stop("No palette to use: cannot proceed!\n")
        scale.values <- seq(scale.range[1], scale.range[2], length=length(scale.colors))	# initial color scale (may be too wide)
        terminal.values <- quantize(vrange, scale.values)
		terminal.positions <- quantize(vrange, scale.values, indices=TRUE)
		matrix.colors <- scale.colors[terminal.positions[1]:terminal.positions[2]]
		
    } else if (lcc==1) {
		
        colctr <- TRUE
        ## make and arrange half-palettes if color scale is centered
        percol <- diff(scale.range) / max.cols
        col.fracs <- col.ranges <- c(0,0)
        col.fracs[1] <- (col.center - scale.range[1]) / percol   # fraction below center
        col.fracs[2] <- (scale.range[2] - col.center) / percol   # fraction above center
        half.palettes <- palettizer(pal, max.cols, interpolate, round(col.fracs,0), FALSE)  # palette, n.colors=NA, interpolate=NULL, halves=c(lower.res,upper.res), reverse=FALSE
        matrix.colors <- scale.colors <- unlist(half.palettes)
        scale.values <- seq(vrange[1], vrange[2], length=length(scale.colors))
###     return(list(col.center=col.center, max.cols=max.cols, vrange=vrange, scale=scale, percol=percol, col.fracs=col.fracs, half.palettes=half.palettes, ColorLevels=ColorLevels))
		
	} else if (quant.cols) {
		
        cbins <- max.cols
        qcolors <- palettizer(pal, max.cols, interpolate, NULL, rev.pal)
        qt <- quantile(real(as.vector(unlist(val))), seq(0,1,length=cbins+1))
        dupqt <- duplicated(qt)
        if (any(dupqt)) qt <- qt[!dupqt]     # identical quantiles exist (extreme positive kurtosis): merge and re-evaluate
        cbins <- length(qt) - 1
        if (cbins != max.cols) qcolors <- palettizer(pal, max.cols, interpolate, NULL, rev.pal)  # bin count changed: have to re-make color vector
        d <- diff(qt)
        sigd <- as.numeric(strsplit(format(abs(min(d)), sci=TRUE),"-")[[1]][2])
        res <- 1 / 10^sigd
        qbins <- round((qt[cbins+1] - qt[1]) / res, 0)
###		IM(qt[1],qt[257],min(d),sigd,res,qbins)
        if (qbins > max.qres) {   # data distribution too skewed: zero-inflated data?
            if (min(real(unlist(c(val))))==0) { }   # doing what here??
            stop(paste("Data has too much positive kurtosis: minimum quantile size too small! | resolution=",qbins,", max resolution=",max.qres,"\nDecrease max.cols or increase max.qres\n",sep="")) 
        }
        scale.colors <- rep(0, qbins+1)
        end <- 0
        for (i in 1:cbins) {
            start <- end + 1
            end <- start + round(d[i] / res,0)
            scale.colors[start:end] <- qcolors[i]
        }
###		IM(cbins, qbins, qcolors[1], scale.colors[1], qcolors[cbins], scale.colors[qbins+1])
        scale.values <- seq(vrange[1], vrange[2], length=length(scale.colors))
###		return(list(qt,ColorLevels,scale.colors))
		matrix.colors <- scale.colors
		
    } else {
		
        matrix.colors <- scale.colors <- palettizer(pal, max.cols, interpolate, NULL, rev.pal)
        scale.values <- seq(vrange[1], vrange[2], length=length(scale.colors))
		
    }
	
#	IM(matrix.colors[1], matrix.colors[length(matrix.colors)])
#	IM(scale.colors[1], scale.colors[length(scale.colors)])
	return(list(matrix.colors=matrix.colors, scale.colors=scale.colors, scale.values=scale.values, data.range=vrange, scale.range=scale.range))
}


apa.names$plots <- c(apa.names$plots, c("myImagePlotUltra","mipu"))
mipu <- myImagePlotUltra <- function(
    x, pmar=c(5,5), x.aspect=c(4,1), rnames=NULL, cnames=NULL, palette="KBY", rev.pal=FALSE, att.cols=NULL, att.rows=NULL, 
    att.palette=NULL, attrib=NULL, col.limits=NULL, col.center=NULL, quant.cols=FALSE, max.cols=256, max.qres=1E6, NA.col=8, Inf.col="white", 
    grid=0, mask=NULL, mask.ramp=NULL, interpolate=NULL, main=NULL, sub=NULL, stagger.main=0, las=2, cex=1, cex.axis=1, cex.main=1, 
    axes=TRUE, unlog.scale=NA, label.text=NULL, label.col=NULL, label.cex=NULL, show.scale=TRUE, scale.div=10, ...) {
    
    ## ----- Define a function for plotting a matrix ----- #
    ## Original myImagePlot() code by CWS
    ## Palettes + flexible margins + labels-free + scale-free + quantile colors + color scale forcing + aspect control + attribute rows/columns + text labels + more by APA
    ## x.aspect = c(map width, scale width); y.aspect is always "1" so adjust x accordingly
    
    ## 'quant.cols': apply color scale by quantiles, not by linear value range
    ## 'max.cols': force a maximum # color quantiles to use with 'quant.cols', if default is too many (getting positive kurtosis errors)
    
    if(!is.null(mask)) {
        if (!all(dim(mask) == dim(x))) { 
            stop("If mask is specified, must have same dims as input matrix!\n") 
        } else {
            m.min <- min(mask)
            m.max <- max(mask)
        }
    }
    
    NC <- ncol(x)
    NR <- nrow(x)
    NA.mat <- Inf.mat <- matrix(NA, NR, NC)
    NA.mat[is.na(x)] <- 1
    Inf.mat[is.infinite(x)] <- 1
    x[is.infinite(x)] <- NA  # remove infinites now
    core <- x   # initially
    if (is.null(palette)) palette <- "KBY"
    
    validate.att.pal <- function(apal, nlevs, rev.pal=FALSE) {
        if (length(apal)==0) {
            ## use master palette instead
            apal <- palette
        } else if (length(apal)==1) {
            ## length-1 palette? investigate
            is.pal <- class(try( palettizer(apal), silent=TRUE )) != "try-error"
            is.col <- class(try( col2rgb(apal)   , silent=TRUE )) != "try-error"
            if (is.col) {
                att.colors <- palettizer(c("white",apal), n=nlevs, NULL, NULL, rev.pal)
            } else if (is.pal) {
                att.colors <- palettizer(apal, n=nlevs, NULL, NULL, rev.pal)
            } else {
                stop("Cannot determine what kind of color scheme '",apal,"' is!\n")
            }
        } else if (nlevs==length(apal)) {
            ## data:palette is 1:1
            att.colors <- apal
        } else {
            ## data:palette is not 1:1; palette has > 1 element, so assume color vector
            att.colors <- palettizer(apal, n=nlevs, NULL, NULL, rev.pal)
        }
    }
    
    ## separate any attribute rows/cols from "core" matrix
    att.dims <- list(rows=c(), cols=c())  # not properly 'dim', just recording N rows & cols
    att.dat <- list()
    att.legacy <- length(att.cols)>0|length(att.rows)>0|length(att.palette)>0
    if (length(attrib)>0) {
        ## NEW METHOD -- MULTI-PALETTE
        if (att.legacy) stop("If using NEW attribute method 'attrib', do not specify any OLD attribute methods 'att.cols', 'att.rows', or 'att.palette'!\n")
        for (a in 1:length(attrib)) {
            att.mat <- matrix(NA, NR, NC)
            if ("rows" %in% names(attrib[[a]])) {
                att.mat[attrib[[a]]$rows,] <- x[attrib[[a]]$rows,,drop=FALSE]
                att.dims$rows <- c(att.dims$rows,attrib[[a]]$rows)
            }
            if ("cols" %in% names(attrib[[a]])) {
                att.mat[,attrib[[a]]$cols] <- x[,attrib[[a]]$cols,drop=FALSE]
                att.dims$cols <- c(att.dims$cols,attrib[[a]]$cols)
            }
            att.revpal <- ifelse("rev.pal" %in% names(attrib[[a]]), attrib[[a]]$rev.pal, FALSE)
            att.levels <- diff(range(att.mat,na.rm=TRUE))+1
            att.colors <- validate.att.pal(attrib[[a]]$palette, att.levels, att.revpal)
            att.dat[[a]] <- list(mat=att.mat, col=att.colors)
        }
    } else if (att.legacy) {
        ## LEGACY METHOD -- SINGLE-PALETTE
        att.mat <- matrix(NA, NR, NC)
        if (length(att.rows)>0) {
            att.mat[att.rows,] <- x[att.rows,,drop=FALSE]
            att.dims$rows <- c(att.dims$rows,att.rows)
        }
        if (length(att.cols)>0) {
            att.mat[,att.cols] <- x[,att.cols,drop=FALSE]
            att.dims$cols <- c(att.dims$cols,att.cols)
        }
        att.levels <- diff(range(att.mat,na.rm=TRUE))+1
        att.colors <- validate.att.pal(att.palette, att.levels, rev.pal)
        att.dat[[1]] <- list(mat=att.mat, col=att.colors)
    }
    
    if (length(att.dims$cols)>0) core[,att.dims$cols] <- NA
    if (length(att.dims$rows)>0) core[att.dims$rows,] <- NA
    if (length(dim(core))==0) {  # no longer a matrix?
        core <- t(as.matrix(core))
    }
    if (length(col.limits)>0) {
        core[core>col.limits[2]] <- col.limits[2]
        core[core<col.limits[1]] <- col.limits[1]
    }
    c.min <- min(real(core))
    c.max <- max(real(core))
    if (c.min==c.max) stop("Entire matrix has only one value: will not plot.\n")
    
    if (length(rnames)>0) {
        yLabels <- stretch.attrib(rnames,NR,'yLabels')
    } else if (length(rownames(x))>0) {
        yLabels <- rownames(x)
    } else {
        yLabels <- 1:NR
    }
    if (length(cnames)>0) {
        xLabels <- stretch.attrib(cnames,NC,'xLabels')
    } else if (length(colnames(x))>0) {
        xLabels <- colnames(x)
    } else {
        xLabels <- 1:NC
    }
    
    ## check for additional function arguments
    ## UPDATE: 'Lst' no longer used anywhere -- should this part get tossed?
    Lst <- list(...)
    xaxt <- yaxt <- ""
    if(length(Lst) > 0) {
        if(!is.null(Lst$zlim)) {
            c.min <- Lst$zlim[1]
            c.max <- Lst$zlim[2]
        }
        if (!is.null(Lst$yLabels)) yLabels <- c(Lst$yLabels)
        if (!is.null(Lst$xLabels)) xLabels <- c(Lst$xLabels)
        #if (!is.null(Lst$main)) main <- Lst$main
        #if (!is.null(Lst$xaxt)) xaxt <- Lst$xaxt
        #if (!is.null(Lst$yaxt)) yaxt <- Lst$yaxt
    }
    ## check for null values
    if (is.null(xLabels)) xLabels <- 1:NC
    if (is.null(yLabels)) yLabels <- 1:NR
    
    if (show.scale) layout(matrix(data=c(1,2), nrow=1, ncol=2), widths=x.aspect, heights=c(1,1))
    
    scale <- c()
    scale[1] <- c.min <- ifelse (!is.null(col.limits[1]), col.limits[1], c.min)
    scale[2] <- c.max <- ifelse (!is.null(col.limits[2]), col.limits[2], c.max)
    
    colctr <- fixpal <- FALSE
    if (length(ncol(palette))>0) {
        ## matrix to plot is discrete, and 'palette' is a value->color key
        fixpal <- TRUE
        obs.lev <- sort(unique(zapsmall(c(as.matrix(core)))))
        colors2 <- palette[match(obs.lev,zapsmall(palette[,1])),2]
        for (i in 1:ncol(core)) core[,i] <- translate(core[,i],obs.lev,1:length(obs.lev))
        ColorLevels <- obs.lev
    } else if (length(col.limits)>0 & length(col.center)>0) {
        ## COL LIMITS
        ## truncating or extending palette range
#        colors2 <- palettizer(palette, max.cols, interpolate, NULL, rev.pal)
#        if (!exists("colors2")) stop("No palette to use: cannot proceed!\n")
#        FullColorRange <- seq(scale[1], scale[2], length=length(colors2))	# initial color scale (may be too wide)
#        terminal <- quantize(c.max, FullColorRange)
#        ColorLevels <- FullColorRange[1:which(FullColorRange==terminal)]	# subset corresponding to data range
#        CL=list(ColorLevels)
        ## COL CENTER
        ## centered palette required (use two half-palettes)
        ## make and arrange half-palettes if color scale is centered
        percol <- (scale[2] - scale[1]) / max.cols
        col.fracs <- col.ranges <- c(0,0)
        col.fracs[1] <- (col.center - scale[1]) / percol   # fraction below center
        col.fracs[2] <- (scale[2] - col.center) / percol   # fraction above center
        half.palettes <- palettizer(palette, max.cols, interpolate, round(col.fracs,0), FALSE)  # palette, n.colors=NA, interpolate=NULL, halves=c(lower.res,upper.res), reverse=FALSE
        colors2 <- unlist(half.palettes)
        ColorLevels <- seq(c.min, c.max, length=length(colors2))
    } else if (length(col.limits)>0) {
        ## truncating or extending palette range
        colors2 <- palettizer(palette, max.cols, interpolate, NULL, rev.pal)
        if (!exists("colors2")) stop("No palette to use: cannot proceed!\n")
        FullColorRange <- seq(scale[1], scale[2], length=length(colors2))	# initial color scale (may be too wide)
        terminal <- quantize(c.max, FullColorRange)
        ColorLevels <- FullColorRange[1:which(FullColorRange==terminal)]	# subset corresponding to data range
    } else if (quant.cols) {
        ## quantile-based color distribution
        cbins <- max.cols
        qcolors <- palettizer(palette, max.cols, interpolate, NULL, rev.pal)
        qt <- quantile(real(as.vector(unlist(core))), seq(0,1,length=cbins+1))
        dupqt <- duplicated(qt)
        if (any(dupqt)) qt <- qt[!dupqt]     # identical quantiles exist (extreme positive kurtosis): merge and re-evaluate
        cbins <- length(qt) - 1
        if (cbins != max.cols) qcolors <- palettizer(palette, max.cols, interpolate, NULL, rev.pal)  # bin count changed: have to re-make color vector
        d <- diff(qt)
        sigd <- as.numeric(strsplit(format(abs(min(d)), sci=TRUE),"-")[[1]][2])
        res <- 1 / 10^sigd
        qbins <- round((qt[cbins+1] - qt[1]) / res, 0)
###		IM(qt[1],qt[257],min(d),sigd,res,qbins)
        if (qbins > max.qres) {   # data distribution too skewed: zero-inflated data?
            #if (min(real(core))==0) { }   # doing what here??
            stop(paste("Data has too much positive kurtosis: minimum quantile size too small! | resolution=",qbins,", max resolution=",max.qres,"\nDecrease max.cols or increase max.qres\n",sep="")) 
        }
        colors2 <- rep(0, qbins+1)
        end <- 0
        for (i in 1:cbins) {
            start <- end + 1
            end <- start + round(d[i] / res,0)
            colors2[start:end] <- qcolors[i]
        }
###		IM(cbins, qbins, qcolors[1], colors2[1], qcolors[cbins], colors2[qbins+1])
        ColorLevels <- seq(c.min, c.max, length=length(colors2))
###		return(list(qt,ColorLevels,colors2))
    } else if (length(col.center)>0) {
        ## centered palette required (use two half-palettes)
        colctr <- TRUE
        ## make and arrange half-palettes if color scale is centered
        percol <- (scale[2] - scale[1]) / max.cols
        col.fracs <- col.ranges <- c(0,0)
        col.fracs[1] <- (col.center - scale[1]) / percol   # fraction below center
        col.fracs[2] <- (scale[2] - col.center) / percol   # fraction above center
        half.palettes <- palettizer(palette, max.cols, interpolate, round(col.fracs,0), FALSE)  # palette, n.colors=NA, interpolate=NULL, halves=c(lower.res,upper.res), reverse=FALSE
        colors2 <- unlist(half.palettes)
        ColorLevels <- seq(c.min, c.max, length=length(colors2))
###                return(list(col.center=col.center, max.cols=max.cols, c.minmax=c(c.min,c.max), scale=scale, percol=percol, col.fracs=col.fracs, half.palettes=half.palettes, ColorLevels=ColorLevels))
    } else {
        ## default behavior
        colors2 <- palettizer(palette, max.cols, interpolate, NULL, rev.pal)
        ColorLevels <- seq(c.min, c.max, length=length(colors2))
    }
    LCL <- length(ColorLevels)
    
    ## labels test
    if (!is.null(label.text)) {
        if (nrow(label.text) != NR | ncol(label.text) != NC) stop("Label text dimensions do not match matrix dimensions!")
        if (is.null(label.col)) {
            label.col <- label.text
            label.col[label.col!=1] <- 1
        } else {
            if (nrow(label.col) != NR | ncol(label.col) != NC) stop("Label col dimensions do not match matrix dimensions!")
        }
#        label.text <- t(label.text[nrow(label.text):1,])
#        label.col <- t(label.col[nrow(label.col):1,])
    }
    
    Lm <- length(main)
    if (Lm>0) {
        if (stagger.main>0) {
            if (Lm<2) stop("Can't stagger 'main' unless 'main' is a vector of labels (with length > 1)!\n")
            main.tiers <- tier.pos <- vector("list", length=stagger.main)
            offset <- ifelse(Lm==NC,0,round(NC/(2*Lm),0))
            NCeff <- NC-2*offset
            for (i in 1:stagger.main) {
                s <- seq(i,Lm,stagger.main)
                main.tiers[[i]] <- main[s]
                tier.pos[[i]] <- seq(0,NCeff,length.out=Lm)[s] + offset
            }
            main <- NULL  # ZAP IT NOW
        } else {
            if (Lm>1) stop("'main' cannot be a vector unless stagger.main>0!\n")
        }
    }
    
    ## Data Map
    par(mar = c(pmar,2.5,2), cex=cex)
    add <- FALSE
    
    if (any(falsify(NA.mat==1))) {
        ## plot NA "background" first
        image(1:NC, 1:NR, t(NA.mat[NR:1,,drop=FALSE]), col=NA.col, xlab="", ylab="", axes=FALSE, main=main, sub=sub, cex.sub=cex.main)
        add <- TRUE
    }
    
    if (length(att.dat)>0) {
        for (a in 1:length(att.dat)) {
            this.sub <- if (!is.null(sub)) ifelse(add,"",sub)
            this.main <- if (!is.null(main)) ifelse(add,"",main)
            image(1:NC, 1:NR, t(att.dat[[a]]$mat[NR:1,,drop=FALSE]), col=att.dat[[a]]$col, xlab="", ylab="", axes=FALSE, add=add, main=this.main, sub=this.sub, cex.sub=cex.main)	
            add <- TRUE
        }
    }
    
    ## plot main heatmap
    z.lim <- if (fixpal) { c(1,LCL) } else { c(c.min,c.max) }
    this.sub <- if (!is.null(sub)) ifelse(add,"",sub)
    this.main <- if (!is.null(main)) ifelse(add,"",main)
    if (stagger.main==0) {
        image(1:NC, 1:NR, t(core[NR:1,,drop=FALSE]), col=colors2, xlab="", ylab="", axes=FALSE, add=add, zlim=z.lim, main=this.main, sub=this.sub, cex.main=cex.main, cex.sub=cex.main)
    } else {
        image(1:NC, 1:NR, t(core[NR:1,,drop=FALSE]), col=colors2, xlab="", ylab="", axes=FALSE, add=add, zlim=z.lim, main="", sub=this.sub, cex.sub=cex.main)
        for (i in 1:stagger.main) mtext(main.tiers[[i]], 3, stagger.main-i, FALSE, tier.pos[[i]], cex=cex.main)
    }
    #IM("Bye!")
    #return()
    
    ## plot gridlines
    if (grid != 0) {  # zero being the "invisible" color, so don't bother plotting...
        abline(h=c(-1:NR)+0.5, lty=1, col=grid)
        abline(v=c(-1:NC)+0.5, lty=1, col=grid)
    }
    
    ## add labels
    if (!is.null(label.text)) {
        label.text <- label.text
        for (i in 1:ncol(label.text)) { text(i, NR:1, labels=label.text[,i], col=label.col[,i], cex=label.cex) }
    }
    
    ## plot mask
    if (!is.null(mask)) image(1:NC, 1:NR, t(mask[NR:1,,drop=FALSE]), add=TRUE, col=mask.ramp, xlab="", ylab="", axes=FALSE, zlim=c(m.min,m.max)) 
    
    if (axes) {
        if (xaxt!="n") axis(1, at=1:NC, labels=xLabels, las=las, cex.axis=cex.axis)  # bottom
        if (yaxt!="n") axis(2, at=1:NR, labels=yLabels[NR:1], las=las, cex.axis=cex.axis)  # left
    }
    
    ## Color Scale
    if (show.scale) {
        par(mar=c(pmar[1],2.5,2.5,2), las=1, cex=cex)
        Nticks <- scale.div+1
        if (fixpal) {
            image(1, 1:LCL, matrix(data=1:LCL, ncol=LCL, nrow=1), col=colors2, xlab="", ylab="", xaxt="n", yaxt="n")
            axseq <- 1:LCL
            axis(2, at=axseq, labels=ColorLevels, las=2, cex.axis=cex.axis)
#            axis(4, at=axseq, labels=sort(unique(c(core))), las=2, cex.axis=cex.axis)
        } else {
            image(1, ColorLevels, matrix(data=ColorLevels, ncol=LCL, nrow=1), col=colors2, xlab="", ylab="", xaxt="n", yaxt="n")
            axlab <- sapply(seq(c.min,c.max,length.out=Nticks), function(x) signif(x,3) )
            if (!is.na(unlog.scale)) axlab <- sprintf("%0.2f",unlog.scale^axlab)
            axis(2, at=seq(c.min,c.max,length.out=Nticks), labels=axlab, las=2, cex.axis=cex.axis)
        }
###		if (colctr) axlab[which.min(abs(axlab))] <- 0
###		axlab <- paste(100*round(seq(c.min,c.max,length.out=Nticks),2),"%",sep="")   # 1-off thing
        layout(1)
    }
    
}


apa.names$microarray <- c(apa.names$microarray, "venn.areas")
venn.areas <- function(obj, vnames=NULL, include="both", dirs=NULL, universe=NULL, ABC.order=FALSE) { 
    
    ## Returns lists for all venn areas
    ## "obj" is a list of vectors or a decideTests-type matrix ({-1,0,1}, or logical)
    ## "include" = "up", "down", "both", and "opp", first 3 as with limma's vennDiagram(), ONLY IF using a decideTests-type matrix.
    ##  - "opp" returns only entries which are not all up or all down.
    ## "dirs" = vector to change column directionality, one entry for each column, ONLY IF using a decideTests-type matrix.
    ##  - directionality entries can be -1 or 1.  All = 1 if "dirs" is null.
    ## "universe" allows a universe-set specification if not using a decideTests-style matrix
    ## "ABC.order" indicates whether to reorder the output in Venn-area map order
    
    include <- match.arg(include, c("up","down","both","opp"))
    
    if (length(obj)==0) return()
    if (is.data.frame(obj)) obj <- as.matrix.data.frame(obj)	# coerce to matrix, if possible
    
    if (is.list(obj)) {
        N <- length(obj)
        if (is.null(names(obj))) {
            ternary(is.null(vnames), gnames <- 1:N, gnames <- vnames)
        } else {
            gnames <- names(obj)
        }
        mat <- FALSE
    } else if (is.matrix(obj) & mode(obj) %in% c("numeric", "double", "logical")) { 
        N <- ncol(obj)
        if (is.null(colnames(obj))) {
            ternary(is.null(vnames), gnames <- 1:N, gnames <- vnames)
        } else {
            gnames <- colnames(obj)
        }
        if (is.null(rownames(obj))) rownames(obj) <- 1:nrow(obj)
        mat <- TRUE
        if (mode(obj) == "logical") mode(obj) <- "numeric"	# convert to binary
    } else {
        stop("Input must be a list of vectors or a logical/numeric matrix!\n")
    }
    
    if (is.null(dirs)) dirs <- rep(1, N)
    delim <- "&"	# venn area name delimiter
    
    M <- N-1
    A <- 2*2^(N-1)   # Number of output areas, including 'Excluded'
    areas <- permn2(0:1,N,rep=TRUE)[,N:1]
    colnames(areas) <- gnames
    areas <- areas[order(rowSums(areas))[c(2:A,1)],]
    areas <- t( t(areas)*2^c(0:M) )
    areas <- data.frame(areas, Size=rowSums(areas>0), Bsum=rowSums(areas), Name=apply(areas,1,function(x) paste(gnames[x>0],collapse=delim) ))
    areas$Name[A] <- "Excluded"
    for (i in 2:M) {  # sort areas by size then names-in-colname-order, basically (identical to original order expected by venn.diag())
        w <- which(areas$Size==i)
        x <- areas[w[do.call(order,as.list(areas[w,1:N]))],]
        areas[w,] <- x[nrow(x):1,]
    }
    
    area.list <- vector("list", length=A)   	 # not 1 less, because we are adding the excludeds (universe) as a set
    names(area.list) <- areas$Name 	        	 # "Excluded" set automatically populated when using a decideTests-style matrix;
    for (i in 1:A) area.list[[i]] <- logical(0)	 # NULL not desirable -- initialize all with length-0 vectors
    attr(area.list, "class") <- "area.list"
    sizes <- matrix(data=0, nrow=2, ncol=(N+1))
    dimnames(sizes) <- list( c("Total","Unique"), c(gnames,"Universe") )
    uniq.univ <- c()
    if (length(universe)>0) uniq.univ <- sort(unique(universe))
    sizes[,(N+1)] <- c(length(universe), length(uniq.univ))
    
    ## Quantify any redundancy in lists; get original + unique set sizes
    ## Convert input data to matrix, if not already
    if (mat) {
        attr(area.list, "include") <- include
        obj2 <- obj[!duplicated(rownames(obj)),]  # if duplicate rownames, keep first instances
        for (i in 1:ncol(obj2)) {
            odat <- obj[,i] * dirs[i]   # original, N matching elements
            udat <- obj2[,i] * dirs[i]  # uniqued,  N matching elements
            sizes[,i] <- switch(
                include,
                both = c( sum(odat!=0), sum(udat!=0)),
                up   = c( sum(odat >0), sum(udat >0)),
                down = c( sum(odat <0), sum(udat <0)),
                opp  = c( sum(odat!=0), sum(udat!=0))
            )
        }
    } else {
        allobj <- sort(unique(unlist(obj)))
        obj2 <- matrix(0, length(allobj), N, FALSE, list(allobj,gnames))
        for (i in 1:N) {
            tab <- table(obj[[i]])
            obj2[match(names(tab),allobj),i] <- 1
            sizes[,i] <- c(length(obj[[i]]), length(tab))
        }
    }
    attr(area.list, "sizes") <- sizes
    
    ## Load Venn areas
    obj2.bsum <- rowSums(t( t(abs(obj2))*2^c(0:M) ))
    for (i in 1:nrow(areas)) area.list[[i]] <- rownames(obj2)[obj2.bsum==areas$Bsum[i]]
    
    if (!is.null(universe)) {
        ## Load exclusion area
        present <- as.numeric(unlist(area.list[1:(A-1)]))
        if (length(area.list[[A]])>0) {
            ## exclusion set already populated
            err <- length(setdiff(area.list[[A]], uniq.univ))
            if (err>0) stop(paste("Indicated universe is incomplete: there are",err,"members already in exclusion set which are not in the universe!\n"))
        }
        area.list[[A]] <- uniq.univ[!uniq.univ %in% present]
    }
    
    if (ABC.order) {
        ## What function was this intended to serve??  Clearly for 3-way venn area + excluded.
        ##     ACGBDFEH
        ##     12345678
        ##     ABCDEFGH
        ##     14257638
        area.list <- area.list[c(1,4,2,5,7,6,3,8)]
    }
    
    return(area.list)
}


apa.names$microarray <- c(apa.names$microarray, "va2GO")
va2GO <- function(va, filename=NULL, no.univ=TRUE) { 
    
    ## Takes a venn.areas object and converts it to a FatiClone-ready list.
    ## Writes it to file if 'filename' specified.
    
    gnames <- rep(names(va), times=listLengths(va))
    tab <- nameless(cbind(unlist(va), gnames))
    colnames(tab) <- c("Gene","Group")
    if (no.univ) { tab <- tab[tab[,2]!="Excluded",] }
    if (is.null(filename)) {
        return(tab)
    } else {
        write.table(tab, filename, sep="\t", quote=FALSE, row.names=FALSE)
    }
}


apa.names$plots <- c(apa.names$plots, "venn.diag")
venn.diag <- function(obj, names=NULL, include=c("both","up","down","opp"), dirs=NULL, universe=NULL, map=FALSE, as.pct=FALSE, showN=FALSE, colorize=FALSE, radius=2, main=NULL, calibrate=FALSE) {
    
    ## Venn diagram function; plotting code is an extensively-rewritten version of Thomas Girke's 2008/11/06 original:
    ##   source("http://faculty.ucr.edu/~tgirke/Documents/R_BioCond/My_R_Scripts/vennDia.R")
    ## This one is much more flexible with inputs, and doesn't have the incorrect 4-circle diagram option.
    ## "..." may be: a list with vectors describing sets, 
    ##		 a decideTests-type numeric matrix, 
    ##  		 the logical equivalent of a decideTests-type matrix, or 
    ##		 a venn.areas()-style list of venn area counts.
    ## In any case, # vectors, length of vector list, or ncol(matrix) must be between 1 and 5.
    ## Actual set processing is done by venn.areas(), my code.
    
    objname <- deparse(substitute(obj))
    include <- match.arg(include)
    if (is(obj, "area.list")) {	# already an area.list object
        areas <- obj
    } else if (is.matrix(obj)) {		# input not an area.list object; convert into area.list
        if (length(rownames(obj))==0) rownames(obj) <- 1:nrow(obj)
        if (length(colnames(obj))==0) colnames(obj) <- 1:ncol(obj)
        areas <- venn.areas(obj, include=include, dirs=dirs, universe=universe)
    } else if (length(obj)>0&length(obj)<=5) {		# input not an area.list object; convert into area.list
        if (length(names(obj))==0) {
            if (length(names)==0) {
                names(obj) <- names
            } else {
                names(obj) <- 1:length(obj)
            }
        }
        areas <- venn.areas(obj, include=include, dirs=dirs, universe=universe)
    } else if (length(obj)>5) {			# too large
        null.plot(); text(0, 0, "Too many vectors!")
        IM("Cannot plot > 5 vectors!\n")
        return()
    } else {
        null.plot()
        IM("Cannot plot an empty object!\n")
        return()
    }
    
    trueN <- length(areas)
    N <- switch(as.character(trueN), "1"=, "2"=1, "3"=, "4"=2, "7"=, "8"=3, "15"=, "16"=4, "31"=, "32"=5)
    maxN <- switch(as.character(N), "1"=2, "2"=4, "3"=8, "4"=16, "5"=32)	# insurance, for area.list objects lacking the exclusion set
    if (!N %in% 1:5) { stop(paste("Can only diagram 1-5 sets, not ",N,"!\n",sep="")) }
    
    all.cols <- c(2,3,4,"gold2","darkorchid")
    generics <- c("v","w","x","y","z")
    ternary (colorize, acols <- all.cols[1:N], acols <- rep(1,N))
    tcol <- lcol <- diacol <- 1
    radii <- rep(radius,N)
    ternary (map, labels <- generics[1:N], labels <- names(areas)[1:N])
    area.names <- paste("q", 1:maxN, sep="")
    lims <- c(0,10)
    count <- listLengths(areas)
    
    if (as.pct) {
        total <- sum(count[1:maxN-1])
        count <- round(100 * count / total, 1)
    }
    
    if (calibrate) count <- rep("000",length(count))
    
    if (is.null(main)) { 
#		main <- paste("Venn Diagram, ", objname, sep="")
        main <- objname
        if(!is.null(attr(areas, "include"))) { main <- paste(main,", ",include,sep="") }
    }
    
    basic.venn.plot <- function(count, main) {
        ## get most data from parent namespace
        symbols(symb.pos$x, symb.pos$y, circles=radii, fg=acols, xlim=lims, ylim=lims, inches=FALSE, main=main, xlab="", ylab="", xaxt="n", yaxt="n", bty="n")
        text(text.pos$x, text.pos$y, count, col=1)
        text(lab.pos$x, lab.pos$y, labels, col=acols)
    }
    
    plotellipse <- function (center=c(1,1), radius=c(1,2), rotate=1, segments=360, xlab="", ylab="", col=1) {
        angles <- (0:segments) * 2 * pi/segments  
        rotate <- rotate * pi / 180
        ellipse <- cbind(radius[1] * cos(angles), radius[2] * sin(angles))
        ellipse <- cbind( ellipse[,1]*cos(rotate) + ellipse[,2]*sin(rotate), ellipse[,2]*cos(rotate) - ellipse[,1]*sin(rotate) )
        ellipse <- cbind(center[1]+ellipse[,1], center[2]+ellipse[,2])	
        lines(ellipse, type="l", xlim=lims, ylim=lims, xlab="", ylab="", col=col)
##	points(center[1], center[2], pch=15, col=col)   # mark ellipse centers?
    }
    
    if (N == 1) {
        text.pos <- data.frame(x=c(5,9), y=c(6.1,0.5))
        symb.pos <- data.frame(x=5, y=6)
        lab.pos <- data.frame(x=5, y=8.8)
        if (map) {
            count <- area.names
            main <- "Mapping Venn Diagram"
        }
        basic.venn.plot(count, main)
    }
    
    if (N == 2) {
        text.pos <- data.frame(x=c(3.1, 7.0, 5.0, 9), y=c(6.1, 6.1, 6.1, 0.5))
        symb.pos <- data.frame(x=c(4, 6), y=c(6, 6))
        lab.pos <- data.frame(x=c(2.0, 8.0), y=c(8.8, 8.8))
        if (map) {
            count <- area.names
            main <- "Mapping Venn Diagram"
        }
        basic.venn.plot(count, main)
    }
    
    if (N == 3) {
        text.pos <- data.frame(x=c(3.0, 7.0, 5.0, 5.0, 3.8, 6.3, 5.0, 9), y=c(6.5, 6.5, 3.0, 6.9, 4.6, 4.6, 5.4, 0.5))
        symb.pos <- data.frame(x=c(4, 6, 5), y=c(6, 6, 4))
        lab.pos <- data.frame(x=c(2.0, 8.0, 5.0), y=c(8.8, 8.8, 1.1))
        if (map) {
            count <- area.names
            main <- "Mapping Venn Diagram"
        }
        basic.venn.plot(count, main)
    }
    
    if (N == 4) {
        text.pos <- data.frame(
            x=c(1.5, 3.5, 6.5, 8.5, 2.9, 3.1, 5.0, 5.0, 6.9, 7.1, 3.6, 5.8, 4.2, 6.4, 5.0, 9), 
            y=c(4.8, 7.2, 7.2, 4.8, 5.9, 2.2, 0.7, 6.0, 2.2, 5.9, 4.0, 1.4, 1.4, 4.0, 2.8, 0.5)
        )
        lab.pos <- data.frame(x=c(0.4, 2.8, 7.5, 9.4), y=c(7.7, 8.7, 8.7, 7.7))
        ## Plot ellipse as 4-way venn diagram
        ellipseVenn <- function(count, main, tcex=1.3) {   ## Get most data from parent namespace
            plot(lims, lims, type="n", xlim=lims, ylim=lims, main=main, xlab="", ylab="", xaxt="n", yaxt="n", bty="n")
            plotellipse(center=c(3.5,3.6), radius=c(2,4), rotate=-35, segments=360, xlab="", ylab="", col=acols[1])
            plotellipse(center=c(4.7,4.4), radius=c(2,4), rotate=-35, segments=360, xlab="", ylab="", col=acols[2])
            plotellipse(center=c(5.3,4.4), radius=c(2,4), rotate=35, segments=360, xlab="", ylab="", col=acols[3])
            plotellipse(center=c(6.5,3.6), radius=c(2,4), rotate=35, segments=360, xlab="", ylab="", col=acols[4])
            text(text.pos$x, text.pos$y, count, col=tcol)
            text(lab.pos$x, lab.pos$y, labels, col=acols)
        }
        if (map) {
            count <- area.names
            main <- "Mapping Venn Diagram"
        }
        ellipseVenn(count, main)
    }

    if (N == 5) {
        text.pos <- data.frame(
            x=c(4.1,1.2,3.4,7.9,8.2, 3.30,5.20,6.50,6.45,2.45, 2.45,7.60,5.20,3.30,7.70, 4.50,3.12,6.85,5.50,6.05, 6.70,2.80,2.80,7.60,4.05, 3.70,5.90,6.90,5.30,3.20, 5,9), 
            y=c(8.8,5.4,1.4,2.3,7.1, 7.20,7.70,2.75,7.55,4.20, 5.90,5.70,2.20,2.80,4.30, 7.15,6.77,6.30,2.50,7.32, 3.60,5.10,3.70,4.75,3.15, 6.40,6.75,5.05,3.00,4.50, 5,0)
        )
##		labxy <- 5+5*cbind(cos(theta2),sin(theta2))  # initial label points, see theta2 in ellipseVenn func below
        lab.pos <- data.frame(x=c(4.1, 0.5, 3.4, 7.7, 8.2), y=c(10.2, 7.3, 0.1, 1.0, 8.4))
        ## Plot ellipse as 5-way venn diagram
        ellipseVenn <- function(count, main, tcex=1.3) {   ## Get most data from parent namespace
            elrad <- c(2,4); rad <- 1; ca <- -15; ra <- -18; theta <- 72*0:4; theta2 <- (0.55*pi)+(theta+ca)*pi/180
            plot(lims, lims, type="n", xlim=lims, ylim=lims, main=main, xlab="", ylab="", xaxt="n", yaxt="n", bty="n")
            plotellipse(center=c(5+rad*cos(theta2[1]),5+rad*sin(theta2[1])), radius=elrad, rotate=-theta[1]+ra, segments=360, xlab="", ylab="", col=acols[1])
            plotellipse(center=c(5+rad*cos(theta2[2]),5+rad*sin(theta2[2])), radius=elrad, rotate=-theta[2]+ra, segments=360, xlab="", ylab="", col=acols[2])
            plotellipse(center=c(5+rad*cos(theta2[3]),5+rad*sin(theta2[3])), radius=elrad, rotate=-theta[3]+ra, segments=360, xlab="", ylab="", col=acols[3])
            plotellipse(center=c(5+rad*cos(theta2[4]),5+rad*sin(theta2[4])), radius=elrad, rotate=-theta[4]+ra, segments=360, xlab="", ylab="", col=acols[4])
            plotellipse(center=c(5+rad*cos(theta2[5]),5+rad*sin(theta2[5])), radius=elrad, rotate=-theta[5]+ra, segments=360, xlab="", ylab="", col=acols[5])
            text(text.pos$x, text.pos$y, count, col=tcol)
            text(lab.pos$x, lab.pos$y, labels, col=acols)
        }
        if (map) {
            count <- area.names
            main <- "Mapping Venn Diagram"
        }
        ellipseVenn(count, main)
    }
    invisible(areas)
}


apa.names$plots <- c(apa.names$plots, "dhist")
dhist <- function(vecs, vnames=NULL, points=FALSE, add=FALSE, legend="auto", verbose=TRUE, logscale=NA, dens.n=2^9, xlab="", xmin=NA, force.unit=FALSE, imgname=NULL, imgdim=c(700,600), device=c("png","pdf"), cex=par()$cex, denormalize=FALSE, pch="|", plot=TRUE, ...) {
    
    ## Density-histogram shortcut.
    ## 'vecs' is a list of vectors, matrix, or dataframe.
    ## 'vnames' names the list, if not already named.
    ## 'col' is a vector of colors, one for each element of 'vecs'.  If null, rainbow(length(vecs)) gets used.
    ## 'points=T' plots the point spread on the x-axis.  Not recommended for many-line histograms.
    ## 'add=T' allows dhist lines to be addd to an existing plot (e.g., another dhist using a different 'adjust' value)
    ## 'logscale' can be one of c(NA, "log", "log2", "log10"), indicating plotting in linear (NA) or log something.
    ## 'legend' indicates position of legend (e.g. "topleft"); NA for no legend; "auto" to make dhist() decide between "topleft" and "topright".
    ## "..." are other args are for either hist(), density(), or legend().
    ## use "dens.n" for density() 'n' argument
    ## "xlab" as usual
    ## 'xmin' specifies minimum x-axis value.  NA sets xmin = data min.
    ## ***** na.rm == TRUE automatically *****
    
    other.args <- list(...)
    dens.argnames <- c("x","bw","adjust","kernel","weights","window","width","give.Rkern","from","to","cut","na.rm")
    hist.argnames <- c("x","breaks","freq","probability","include.lowest","right","density","angle","col","border","main","sub","xlim","ylim","xlab","ylab","axes","plot","labels","nclass","xaxt","yaxt")
    legend.argnames <- c("x","y","legend","fill","col","border","lty","lwd","pch","angle","density","bty","bg","box.lwd","box.lty","box.col","pt.bg","cex","pt.cex","pt.lwd","xjust","yjust","x.intersp","y.intersp","adj","text.width","text.col","merge","trace","plot","ncol","horiz","title","inset","xpd","title.col","text.col")
    if (!is.na(logscale)) { match.arg(logscale, c("log", "log2", "log10")) }
    
    if (!is.na(device[1])) device <- match.arg(device)
    plot2file <- ifelse(is.na(device)|length(imgname)==0, FALSE, TRUE)
    
    xname <- deparse(substitute(vecs))
    if (is.ndfl(vecs)) {
        ## ok
    } else if (is.data.frame(vecs)) {
        vecs <- as.list(vecs)
    } else if (is.matrix(vecs)) {
        vecs <- as.list(as.data.frame(vecs))
    } else if (is.nlv(vecs)) {
        vecs <- list(vecs)
    } else {
        stop("'vecs' must be a list, matrix, or dataframe!\n")
    }

    for (i in 1:length(vecs)) { 
        if (length(vecs[[i]])>0) {
            vecs[[i]] <- real(vecs[[i]])  # strip NAs, Infinites
        } else {
            vecs[[i]] <- numeric(0)   # replace NULL with something not-null
        }
    }
    nvec <- length(vecs)
    llv <- listLengths(vecs)
    scales <- zapsmall(llv/max(llv))
#    message(paste(c("scales: ",scales),collapse=" "))
    
    if (length(names(vecs))==0) { 		
        ternary(length(vnames)==0, names(vecs) <- 1:nvec, names(vecs) <- vnames)
    } else {
        if (length(vnames)>0) names(vecs) <- vnames     # override existing names if 'vnames' is specified
    }
    vnames <- names(vecs)  # pass back to ensure 'vnames' is also set
    
    dens.args <- other.args[names(other.args) %in% dens.argnames]
    hist.args <- other.args[names(other.args) %in% hist.argnames]
    legend.args <- other.args[names(other.args) %in% legend.argnames]
    lost.args <- setdiff( names(other.args), c(names(hist.args), names(dens.args), names(legend.args)) )
    if (length(lost.args) > 0) IM("Warning: the following '...' arguments do not belong to density() or hist() (as of 2.11.1):", paste(lost.args, collapse=", "))
    
    col <- ternary (length(other.args$col)==0, 1, other.args$col)
    if (length(col) < nvec) { ternary(nvec <= 8, col <- 1:nvec, col <- rainbow(nvec)) }
    lty <- ternary (length(other.args$lty)==0, 1, other.args$lty)
    if (length(lty) < nvec) { times <- ceiling(nvec / length(lty)); lty <- rep(lty, times) }
    lwd <- ternary (length(other.args$lwd)==0, 1, other.args$lwd)
    if (length(lwd) < nvec) { times <- ceiling(nvec / length(lwd)); lwd <- rep(lwd, times) }
    
    maxlen <- max(listLengths(vecs))
    dens <- vecs
    drops <- rep(FALSE, length(vecs))
    ally <- allx <- new.list(names(vecs))
    for (i in 1:nvec) { 
        vecs[[i]] <- nameless(real(vecs[[i]]))
        if (sum(!is.na(vecs[[i]])) >= 2) {
            if (!is.na(logscale)) {
                vecs[[i]] <- switch(logscale,
                                    log = log(vecs[[i]]),
                                    log2 = log2(vecs[[i]]),
                                    log10 = log10(vecs[[i]])
                                    )
            }
            dens.args$x <- allx[[i]] <- vecs[[i]]
            dens.args$n <- dens.n
            dens.args$na.rm <- TRUE
            dens[[i]] <- do.call(density, dens.args)
            if (denormalize) dens[[i]]$y <- dens[[i]]$y*scales[i]
            ally[[i]] <- if (force.unit) { percentify(dens[[i]]$y, range=TRUE) } else { dens[[i]]$y }
            names(ally[[i]]) <- seq(min(vecs[[i]]), max(vecs[[i]]), length=dens.n)
        } else {
            if (verbose) IM(paste("Dropping vector #",i,": not enough observations!",sep=""))
            drops[i] <- TRUE
            if (nvec == 1) { 
                null.plot(main=paste("Unable to plot",xname))
                IM("Not enough data to make a density histogram.\n") 
                return()
            } 
            dens[[i]] <- NA
        }
    }
    
    if (is.null(hist.args$xlim)) {
        hist.args$xlim[1] <- ifelse(is.na(xmin), min(real(unlist(vecs))), xmin)
        hist.args$xlim[2] <- max(real(unlist(vecs)))
        if (is.infinite(hist.args$xlim[2])) hist.args$xlim[2] <- 0	# no real() results...
    }
    if (is.null(hist.args$ylim)) {
        hist.args$ylim[1] <- 0
        hist.args$ylim[2] <- max(real(unlist(ally)))
        if (is.infinite(hist.args$ylim[2])) hist.args$ylim[2] <- 0	# no real() results...
    }
    if (is.null(hist.args$main)) hist.args$main <- paste("Density Histogram of",xname)
    if (is.null(hist.args$ylab)) hist.args$ylab <- "Density"
    hist.args$xlab <- xlab
    hist.args$x <- sort(unlist(allx))
    hist.args$col <- 0
    hist.args$border <- 0
    hist.args$freq <- 0
    
    if (points) {	# plot each set of points on slightly different y values to make them more visible
        yincr <- hist.args$ylim[2] / 50 # y-point gap: 1/50th visible Y range
        yoffset <- -1 * yincr		# y-distance buffer
        point.ymax <- (nvec-1) * yincr
#        IM(yoffset, point.ymax, yincr)
        point.y <- yoffset - rev(seq(0, point.ymax, yincr))	# should get length = nvec!
        hist.args$ylim[1] <- yoffset - point.ymax 		# plot points BELOW x-axis
    }
    
    if (plot) {
        if (!plot2file) {
            ## do nothing
        } else if (device == "png") {
            png(imgname, imgdim[1], imgdim[2])
        } else if (device == "pdf") {
            pdf(imgname, imgdim[1]/100, imgdim[2]/100)
        }
        
        cex <- ifelse(length(cex)>0, cex, ifelse(plot2file, ifelse(device=="png", 1.2, 1), 1))
        par(cex=cex, las=1)
        
        if (!add) do.call(graphics::hist, hist.args)
        for (i in 1:nvec) { 
            lines(dens[[i]], col=col[i], lty=lty[i], lwd=lwd[i]) 
            if (points) points(vecs[[i]], rep(rev(point.y)[i], length(vecs[[i]])), pch=pch, cex=cex*0.55, col=col[i]) 
        }
        if (nvec >= 1 & !is.na(legend)) { 
            if (legend == "auto") {
                ymid <- diff(hist.args$ylim)/2 + hist.args$ylim[1]
                xmid <- diff(hist.args$xlim)/2 + hist.args$xlim[1]
                right.mass <- left.mass <- 0
                for (i in 1:nvec) {
                    xrange <- range(vecs[[i]])
                    if (!drops[i]) {
                        y <- rescale(which(dens[[i]]$y >= ymid), to=xrange, from=c(0,dens.n))   # line regions in the upper 50% of plot area -> translate to original x-values
                        right.mass <- right.mass + sum(y > xmid)
                        left.mass <- left.mass + sum(y <= xmid)
                    }
                }
#                IM(left.mass,right.mass,"|",hist.args$xlim,xmid,"|",hist.args$ylim,ymid)
                legend <- ifelse(right.mass>left.mass, "topleft", "topright")
            }
            legend(x=legend, legend=vnames, bty="n", col=col, lty=lty, lwd=lwd) 
        }

        if (plot2file) dev.off()
    }
    ## OLD SETTINGS -- give false impression of x,y consistency -- now replaced with true density() outputs
    ##hist.args$x <- allx
    ##hist.args$y <- rownameless(do.call(cbind,ally))
    if (points) hist.args$point.y <- point.y
    hist.args$density <- dens
    invisible(hist.args)
}


apa.names$plots <- c(apa.names$plots, "dotplot")
dotplot <- function(obj, legend="topright", r.names=NULL, c.names=NULL, rect.data=NULL, drop.na=TRUE, y.thresh=c(-Inf,Inf,0), col=1, pch=1, cex=1, las=par()$las, xaxt=par()$xaxt, ...) {

	## Takes a vector, matrix or dataframe and plots the rows as points.
	## "legend", if not null, specifies location of the legend.
    ## "r.names" replaces object rownames.
    ## "c.names" replaces object colnames.
#    ## "x.labs" indicates whether to use the object colnames as the x axis labels.
	## "drop.na" indicates whether to remove all-NA (incl NaN, Inf) entries from the legend.
    ## "y.thresh" prevents outlier datapoints (< y.thresh[1] or > y.thresh[2]) from affecting "ylim" calculations.
    ##   "y.thresh" also requires a third argument: 0 or 1, 0 = leave outliers alone, 1 = set outliers to NA.
	## "..." are other arguments passed to the initial plot() call, or to legend().
	##	 NOTE: if "pch" is supplied, points get plotted on the points.
	
	plot.argnames <- c("x","y","type","pch","xlim","ylim","log","main","sub","xlab","ylab","ann","axes","frame.plot","panel.first","panel.last","asp","las","xaxt","yaxt","cex")
	legend.argnames <- c("legend","fill","col","border","pch","angle","density","bty","bg","box.col","pt.bg","cex","pt.cex","pt.lwd","xjust","yjust","x.intersp","y.intersp","adj","text.width","text.col","merge","trace","plot","ncol","horiz","title","inset","xpd","title.col","text.col")
     ## legendx and legendy are also argnames, but transferred to legend.args below
    
	objname <- deparse(substitute(obj))
	if (is.nlv(obj)) { obj <- matrix(obj, nrow=1) }    # recast as matrix
    if (length(r.names)>0) { rownames(obj) <- r.names }
    if (length(c.names)>0) { colnames(obj) <- c.names }
    if (length(colnames(obj))==0) { colnames(obj) <- 1:ncol(obj) }
    if (class(obj) %in% c("matrix","data.frame")) {
        rows <- nrow(obj)
        cols <- ncol(obj)
    } else {
        stop("Object must be a numeric vector, numeric matrix, or data frame!\n")
    }
    
	if (drop.na) { 
		use.points <- which(apply(obj, 1, FUN=function(x){any(real(x,logical=TRUE))}))
		if (length(use.points)==0) { stop("No useable points with drop.na=TRUE!\n") }
	} else {
		use.points <- 1:nrow(obj)
	}
	
	other.args <- list(...)
	plot.args <- other.args[names(other.args) %in% plot.argnames]
	legend.args <- other.args[names(other.args) %in% legend.argnames]
	lost.args <- setdiff( names(other.args), c(names(plot.args), names(legend.args)) )   # par() calls wind up here
	
	if (!is.null(other.args$legendx)) { legend.args$x <- other.args$legendx }
	if (!is.null(other.args$legendy)) { legend.args$y <- other.args$legendy }
    
    if (length(col) < rows) {
        reps <- ceiling(rows / length(col))
        col <- rep(col, reps)
    }
    if (length(pch) < rows) {
        reps <- ceiling(rows / length(pch))
        pch <- rep(pch, reps)
    }
	
	if (is.null(plot.args$ylim)) {
        if (y.thresh[3] == 1) {
            obj[obj<y.thresh[1]] <- NA
            obj[obj>y.thresh[2]] <- NA
        }
        plot.args$ylim[1] <- min(real(obj[obj>y.thresh[1]]))
        plot.args$ylim[2] <- max(real(obj[obj<y.thresh[2]]))
	}
	if (is.null(plot.args$main)) { plot.args$main <- paste("Dot plot of",objname) }
	if (is.null(plot.args$xlab)) { plot.args$xlab <- objname }
	if (is.null(plot.args$ylab)) { plot.args$ylab <- "Value" }
	
	plot.args$xaxt <- "n"   # FOR INITIAL PLOTTING ONLY: does not reflect user-input 'xaxt' value
    plot.args$col <- col[1]
    plot.args$pch <- pch[1]
    plot.args$cex <- cex
    plot.args$las <- las
	plot.args$x <- 1:cols
	plot.args$y <- obj[1,]
	plot.args <- c(plot.args, lost.args)	# assuming "lost" are par() calls...
#     return(plot.args)
#     return(legend.args)

	do.call(plot, plot.args)
	if (!is.null(rect.data)) {
		rect(rect.data[1],plot.args$ylim[1],rect.data[2],plot.args$ylim[2],col=rect.data[3],border=NA)
		for (i in 1:rows) { points(1:cols, obj[i,], col=col[i], pch=pch[i], cex=cex) }
	} else {
		if (rows > 1) {
			for (i in 1:rows) { points(1:cols, obj[i,], col=col[i], pch=pch[i], cex=cex) }
		}
	}
	if (xaxt != "n") { axis(1, at=1:cols, labels=colnames(obj), las=las) }
	for (i in 1:rows) { points(1:cols, obj[i,], col=col[i], pch=pch[i], cex=cex) }
	if (rows > 1 & !is.null(legend)) { graphics::legend(x=legend, legend=rownames(obj)[use.points], bty="n", col=col[use.points], pch=pch[use.points]) } 
#	if (rows > 1 & !is.null(legend)) { do.call(legend, legend.args) } 
}


apa.names$plots <- c(apa.names$plots, "lineplot")
lineplot <- function(obj, legend="topright", r.names=NULL, c.names=NULL, trend.only=FALSE, trend.add=NULL, trend.err=NULL, rect.data=NULL, drop.na=TRUE, y.thresh=c(-Inf,Inf,0), 
                     offset=0, col=NULL, lty=1, lwd=1, pch=NULL, las=par()$las, xaxt=par()$xaxt, gaps=NULL, gap.col="white", gap.lty=1, gap.lwd=1, ...) {

    ## Takes a vector, matrix or dataframe and plots the rows as lines.
    ## "legend", if not null, specifies location of the legend.
    ## "r.names" replaces object rownames.
    ## "c.names" replaces object colnames.
    ## "trend.add", if not null, adds the specified trend line TO AN EXISTING line plot
    ## "trend.err" specified error bar types for the trendline; only works if "trend.add" is specified.
    ## "rect.data" plots a rectangle of color rect.data[3] on the whole y range, on x=rect.data[1:2].
    ## "drop.na" indicates whether to remove all-NA (incl NaN, Inf) entries from the legend.
    ## "y.thresh" prevents outlier datapoints (< y.thresh[1] or > y.thresh[2]) from affecting "ylim" calculations.
    ## "offset" shifts x-positions of the given line(s) by x (intended as a controlled jitter function).
    ## "gaps" may be a list of (start, stop) x coords indicating breaks in the plotted lines
    ## "gap.col" and "gap.lty", indicate how to draw lines in the gaps given by "gaps"
    ##   "y.thresh" also requires a third argument: 0 or 1, 0 = leave outliers alone, 1 = set outliers to NA.
    ## "..." are other arguments passed to the initial plot() call, or to legend().
    ##	 NOTE: if "pch" is supplied, points get plotted on the lines.
    
    plot.argnames <- c("x","y","type","lty","lwd","pch","xlim","ylim","log","main","sub","xlab","ylab","ann","axes","frame.plot","panel.first","panel.last","asp","las","xaxt","yaxt")
    legend.argnames <- c("legend","fill","col","border","lty","lwd","pch","angle","density","bty","bg","box.lwd","box.lty","box.col","pt.bg","cex","pt.cex","pt.lwd","xjust","yjust","x.intersp","y.intersp","adj","text.width","text.col","merge","trace","plot","ncol","horiz","title","inset","xpd","title.col","text.col")
    ## legendx and legendy are also argnames, but transferred to legend.args below
    if (!is.null(trend.add)) trend.add <- match.arg(trend.add, c("mean","median"))
    if (!is.null(trend.err)) trend.err <- match.arg(trend.err, c("se","sd","iqr"))
    
    objname <- deparse(substitute(obj))
    if (is.nlv(obj)) { 
        n <- names(obj)
        obj <- matrix(obj, nrow=1)     # recast as matrix
        colnames(obj) <- n
    }
    if (length(r.names)>0) rownames(obj) <- r.names
    if (length(c.names)>0) colnames(obj) <- c.names
    if (length(colnames(obj))==0) colnames(obj) <- 1:ncol(obj)
    if (class(obj) %in% c("matrix","data.frame")) {
        rows <- nrow(obj)
        cols <- ncol(obj)
    } else {
        stop("Object must be a numeric vector, numeric matrix, or data frame!\n")
    }
    
    if (drop.na) { 
        use.lines <- which(apply(obj, 1, FUN=function(x) any(real(x,logical=TRUE)) ))
        if (length(use.lines)==0) stop("No useable lines with drop.na=TRUE!\n")
    } else {
        use.lines <- 1:nrow(obj)
    }
    
    other.args <- list(...)
    plot.args <- other.args[names(other.args) %in% plot.argnames]
    legend.args <- other.args[names(other.args) %in% legend.argnames]
    lost.args <- setdiff( names(other.args), c(names(plot.args), names(legend.args)) )   # par() calls wind up here
    
    if (!is.null(other.args$legendx)) legend.args$x <- other.args$legendx
    if (!is.null(other.args$legendy)) legend.args$y <- other.args$legendy
    
    if (length(col)==0) {
        if (rows <= 8) {
            col <- 1:rows
        } else {
            col <- rainbow(rows)
        }
    } else if (length(col) < rows) {
        reps <- ceiling(rows / length(col))
        col <- rep(col, reps)
    }
    if (length(lty) < rows) {
        reps <- ceiling(rows / length(lty))
        lty <- rep(lty, reps)
    }
    if (length(lwd) < rows) {
        reps <- ceiling(rows / length(lwd))
        lwd <- rep(lwd, reps)
    }
    if (length(pch) < rows) {
        reps <- ceiling(rows / length(pch))
        pch <- rep(pch, reps)
    }
    
    if (is.null(plot.args$ylim)) {
        if (y.thresh[3] == 1) {
            obj[obj<y.thresh[1]] <- NA
            obj[obj>y.thresh[2]] <- NA
        }
        plot.args$ylim[1] <- min(real(obj[obj>y.thresh[1]]))
        plot.args$ylim[2] <- max(real(obj[obj<y.thresh[2]]))
    }
    if (is.null(plot.args$main)) plot.args$main <- paste("Line plot of",objname)
    if (is.null(plot.args$xlab)) plot.args$xlab <- ""
    if (is.null(plot.args$ylab)) plot.args$ylab <- "Value"
    plot.args$xaxt <- "n"   # FOR INITIAL PLOTTING ONLY: does not reflect user-input 'xaxt' value

    plot.args$col <- col[1]
    plot.args$lty <- lty[1]
    plot.args$lwd <- lwd[1]
    plot.args$pch <- pch[1]
    plot.args$las <- las
    plot.args$x <- c(1:cols)+offset
    plot.args$y <- obj[1,]
    plot.args$type <- "l"
    plot.args$frame.plot <- TRUE
    plot.args <- c(plot.args, lost.args)	# assuming "lost" are par() calls...
    if (is.null(plot.args$axes)) plot.args$axes <- TRUE
    if (is.null(plot.args$ann)) plot.args$ann <- TRUE
#     return(plot.args)
#     return(legend.args)
    
    plot.trend <- function() {
        obj[!real(obj, logical=TRUE)] <- NA
        if (trend.add == "mean") {
            trendline <- colMeans(obj, na.rm=TRUE)
        } else if (trend.add == "median") {
            trendline <- colMedians(obj, na.rm=TRUE)
        } else {
            stop("'trend.add' must be one of 'mean' or 'median'!\n")
        }
        lines(1:cols+offset, trendline, col=col, lty=lty, lwd=lwd)   # trendline
        if (!is.null(trend.err)) {
            if (trend.err == "sd") {
                errs <- colSDs(obj, na.rm=TRUE)
                err.hl <- rbind(trendline+errs, trendline-errs)
            } else if (trend.err == "se") {
                errs <- apply(obj, 2, SEM, na.rm=TRUE)
                err.hl <- rbind(trendline+errs, trendline-errs)
            } else if (trend.err == "iqr") {
                err.hl <- apply(obj, 2, FUN=function(x) quantile(x,c(0.25,0.75),na.rm=TRUE) )
            } else {
                stop("'trend.err' must be one of 'sd', 'se', or 'iqr'!\n")
            }
            for (i in 1:cols) {
                j <- i + offset
                segments(j, err.hl[1,i], j, err.hl[2,i], col=col, lty=lty, lwd=lwd)             # error bar
                segments(j-0.05, err.hl[1,i], j+0.05, err.hl[1,i], col=col, lty=lty, lwd=lwd)   # bottom crossbar
                segments(j-0.05, err.hl[2,i], j+0.05, err.hl[2,i], col=col, lty=lty, lwd=lwd)   # top crossbar
            }
        }
    }
    
    if (trend.only) {
        plot.args$col <- 0
        do.call(graphics::plot, plot.args)
        if (!is.null(rect.data)) {
            rect(rect.data[1],plot.args$ylim[1],rect.data[2],plot.args$ylim[2],col=rect.data[3],border=NA)
        }
        plot.trend()
    } else if (!is.null(trend.add)) {
        plot.trend()
    } else {
#        return(plot.args)
        do.call(graphics::plot, plot.args)
        if (!is.null(rect.data)) {
            rect(rect.data[1],plot.args$ylim[1],rect.data[2],plot.args$ylim[2],col=rect.data[3],border=NA)
            for (i in 1:rows) lines(1:cols, obj[i,], col=col[i], lty=lty[i], lwd=lwd[i])
        } else {
            if (rows > 1) {
                for (i in 1:rows) lines(1:cols+offset, obj[i,], col=col[i], lty=lty[i], lwd=lwd[i])
            }
        }
        if (length(gaps)>0) {
            for (i in 1:length(gaps)) {
                x <- gaps[[i]][1]
                y <- gaps[[i]][2]
                for (i in 1:rows) lines(x:y+offset, obj[i,x:y], col=gap.col, lty=gap.lty, lwd=gap.lwd)
            }
        }
        if (!is.null(pch)) {
            for (i in 1:rows) points(1:cols, obj[i,], col=col[i], pch=pch[i])
        }
        if (plot.args$ann & rows > 1 & !is.null(legend)) { 
            if (length(rownames(obj)[use.lines])>0) {
                graphics::legend(x=legend, legend=rownames(obj)[use.lines], bty="n", col=col[use.lines], lty=lty[use.lines], lwd=lwd[use.lines], pch=pch[use.lines]) 
            }
        } 
#	if (rows > 1 & !is.null(legend)) { do.call(legend, legend.args) } 
    }
    if (plot.args$axes & xaxt != "n") axis(1, at=1:cols, labels=colnames(obj), las=las)
}


apa.names$plots <- c(apa.names$plots, "ribbon.plot")
ribbon.plot <- function(x, fill=NULL, border=NULL, main=NULL, lty=1, lwd=1, line.col=1, names.arg=NULL, names.y=0.5, height="100%", shapes=NULL) {
	
	## takes "x", 4-col data.frame (group, start, stop, name).
	## returns a line spanning min(starts):max(stops) connecting a series of boxes, one for each start/stop pair.
	## boxes can be altered by "fill" = fill color(s), "border" = border color(s), "shapes" = primitive shape name(s) to use instead of rectangles.
	## names will be plotted is present; can override names with "names.arg".  "names.y" ranges from 0 (print below box) to 1 (print above box).
	## base line connecting boxes affected by line.col, lty, lwd.
	## "height.pct" is the height of plotted boxes.  If numeric, that # pixels.  If character and ends with "%", treated as percent of line length.
	
	#####  SHAPES ARGUMENT NOT YET READY  #####
	
#	if (ncol(x)==1) stop("'x' must be have >= 2 columns!\n")
#	if (is.matrix(x)) {
#		if (ncol(x)>2) stop("'x' must be 2 columns if matrix!\n")
#		xnames <- rownames(x)
#	}
	if (is.data.frame(x)) {
		if (ncol(x)!=4) stop("'x' must be 4 columns if data.frame!\n")
		xnames <- x[,4]
	}
	if (length(xnames)==0 || all(x=="")) xnames <- names.arg
	
	groups <- unique(x[,1])
	N <- length(groups)
	unit.coords <- t(sapply(groups, function(g){ y=x[x[,1]==g,]; c(Start=min(y[,2]),End=max(y[,3])) }))
	IM(dim(unit.coords))
	total.coords <- c(1, max(unit.coords[,2]-unit.coords[,1]+1))
	
	total.height <- 2*N
	unit.height <- ifelse(is.numeric(height), height, as.numeric(sub("%$","",height))/100)
	pct.height <- ifelse(is.numeric(height), FALSE, TRUE)
	
	null.plot(xlim=total.coords, ylim=c(0,total.height), main=main)
	
	rev.N <- N:1
	for (i in 1:N) {
		set <- x[x[,1]==i,]
		start <- min(set[,2])
		end <- max(set[,3])
		y.max <- rev.N[i]
		segments(start,y.max-0.45, end,y.max-0.45, lty=lty, lwd=lwd, col=line.col)  # base line
		for (j in 2:nrow(set)) {  # for the moment, record 1 is always the full-region-length record
			col.n <- ifelse(j%%length(fill)==0, length(fill), j%%length(fill))
			bord.n <- ifelse(j%%length(border)==0, length(border), j%%length(border))
			rect(set[j,2],y.max, set[j,3],y.max-0.9, col=fill[col.n], border=border[bord.n])
		}
	}
	
	
}


#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################


apa.names$clustering <- c(apa.names$clustering, "cluster.lineplots")
cluster.lineplots <- function(obj, map=NULL, cnames=NULL, col=1, trend.only=FALSE, ablines=NULL, map.ord=NULL, trend.line="mean", trend.err="sd", trend.col="red", 
	trend.lwd=2, y.thresh=c(-Inf,Inf,0), wide=FALSE, cex=par()$cex, layout=NULL, templates=NULL, temp.col=4, temp.lwd=2, ...) {
	
	# takes object(s) and makes a line plot for each cluster.  Input is either:
	#  1. obj=matrix/df; map=integer cluster mapping vector. (will call: split(obj, map))
	#  2. obj=list of matrices/dfs, one per cluster; map=NULL.
	
	if (length(map)==0) {
		if (is.ndfl(obj)) {
			N <- length(obj)
			clusters <- obj
		} else {
			stop("If 'map' is NULL, 'obj' must be a list of matrices/dfs per cluster!\n")
		}
		if (length(cnames)==0) cnames <- 1:N
	} else {
		good <- !is.na(map)
		map <- map[good]
		obj <- obj[good,]
		if (length(rownames(obj))==0) rownames(obj) <- 1:nrow(obj)
		N <- luniq(map)
		temp <- split(rownames(obj), map)
		if (length(map.ord)>0) {
			if (length(map.ord)==N) {
				temp <- temp[match(map.ord,names(temp))]
			} else {
				warning("map.ord is not 1:1 with unique map names!\n")
				temp <- temp[match(map.ord,names(temp))]
#				IM(length(temp), ":", match(map.ord,names(temp)))
			}
		}
		if (length(cnames)==0) cnames <- names(temp)
		clusters <- new.list(cnames)
		for (i in 1:N) {
			if (length(temp[[i]])>0) clusters[[i]] <- obj[match(temp[[i]],rownames(obj)),]
		}
	}
#	clusters <- clusters[listLengths(clusters)>0]
#	IM(N,":",listLengths(clusters,"nrow"))
	N <- length(clusters)
	
	plot.argnames <- c("x","y","type","pch","lty","lwd","xlim","ylim","log","main","sub","xlab","ylab","ann","axes","frame.plot","panel.first","panel.last","asp","las","xaxt","yaxt")
	other.args <- list(...)
	plot.args <- other.args[names(other.args) %in% plot.argnames]
	if ("ylim" %in% names(plot.args)) {
		ylim <- plot.args$ylim
	} else {
		ylim <- range(obj)
		plot.args$ylim <- ylim
	}
	
	do.templates <- FALSE
	if (length(templates)>0) {
		do.templates <- TRUE
		templates[templates==0] <- ylim[1]
		templates[templates==1] <- ylim[2]
		ntemplates <- translate(templates,ylim,rev(ylim))
	}
	if (length(layout)==0) layout <- MA.scatter.plotdim(N, wide=wide)   # irows icols iheight iwidth
#	IM(layout)
	
	par(mfrow=layout[1:2], cex=cex)
	for (i in 1:N) {
		nrc <- ifelse(!is.null(nrow(clusters[[i]])), nrow(clusters[[i]]), ifelse(length(clusters[[i]])>0, 1, 0))   # matrix or df, ELSE non-list vector, ELSE empty df or 0x0-matrix
		genes <- ifelse(nrc==1, "gene", "genes")
		title <- ifelse( cnames[i]==i, paste("Cluster ",i,": ",nrc," ",genes,sep=""), paste("Cluster '",cnames[i],"': ",nrc," ",genes,sep="") )
		IM(i, length(clusters), nrc)
		if (nrc>0) {
			if (trend.only) {
				do.call(lineplot, c(list(obj=clusters[[i]], c.names=colnames(clusters[[i]]), xlab="", trend.only=TRUE, trend.add=trend.line, trend.err=trend.err, legend=NULL, main=title, col=col), plot.args)) 
#				lineplot(clusters[[i]], c.names=colnames(clusters[[i]]), las=las, xlab="", trend.only=TRUE, legend=NULL, main=title) 
#				lineplot(clusters[[i]], trend.add=trend.line, trend.err=trend.err, col=trend.col, lwd=trend.lwd)
			} else {
				do.call(lineplot, c(list(obj=clusters[[i]], c.names=colnames(clusters[[i]]), xlab="", legend=NULL, main=title, col=col), plot.args)) 
#				lineplot(clusters[[i]], c.names=colnames(clusters[[i]]), las=las, xlab="", col=col, legend=NULL, main=title) 
				lineplot(clusters[[i]], trend.add=trend.line, trend.err=trend.err, col=trend.col, lwd=trend.lwd, xaxt="n")
			}
			if (length(ablines)>0) {
				if (length(ablines$h)>0) abline(h=ablines$h[[1]], col=ablines$h[[2]], lty=ablines$h[[3]], lwd=ablines$h[[4]])
				if (length(ablines$v)>0) abline(v=ablines$v[[1]], col=ablines$v[[2]], lty=ablines$v[[3]], lwd=ablines$v[[4]])
			}
		} else {
			null.plot(main=title)
		}
		if (do.templates) {
			j <- map.ord[i]
			if (j < 0) {
				lines(1:ncol(obj), ntemplates[-j,], col=temp.col, lwd=temp.lwd)
			} else {
				lines(1:ncol(obj), templates[j,], col=temp.col, lwd=temp.lwd)
			}
		}
	}
	invisible(plot.args)
}


apa.names$clustering <- c(apa.names$clustering, "kmeans.plots")
kmeans.plots <- function(x, map, func=mean, cex=1, col.bars=NULL, pal.hm=NULL, hm.ord=NULL) {
    
    ## takes clustered object 'x' and a kmeans clustering vector 'map'
    ## plots the cluster trend lineplots and the cluster size barplots
    ## trend is determined by the function passed to 'func', e.g. mean, median, etc.
    ## 'cex' and 'col are as usual
    ## 'troubleshoot' causes the legend-position function to plot the spatial map, separately, in case the legend seems out of place
    ## 'hm.ord' allows an existing cluster order to be applied to this map, e.g. from some other kmeans.plots image.
    ##  - Such an ordering may not be appropriate for given heatmap, and no compatibility checks are made, caveat emptor.
    ##  - A correctly-formatted hm.ord value is also the invisible output of this function, inspect this object for details.
    
    mm <- max(map)
    umap <- 1:mm
    names(umap) <- umap
    
    trends <- t(sapply(umap, function(i) apply(zerofy(x[map==i,,drop=FALSE]),2,func) ))
    lpos <- legend.position(cbind(x=rep(1:ncol(trends),each=nrow(trends)),y=c(trends)))
    nc <- ncol(x)
    nc.1 <- max(c(1,round(nc/10,0)))
    xr <- range(real(c(x)))
    
    if (length(hm.ord)>0) {
        trend.ord <- hm.ord$trend.ord
        clust.ord <- hm.ord$clust.ord
    } else {
        trend.ord <- reorder.hclust2(hclust(dist(trends),"average"), trends, sum)$order
        clust.ord <- lapply(sort(trend.ord), function(i) {
            w <- which(map==i)
            w[hclust(dist(zerofy(x[w,,drop=FALSE])),"average")$order]
        })
#        xco <- do.call(rbind, lapply(trend.ord, function(i) {
#            y=x[map==i,,drop=FALSE]
#            cbind(
#                y[hclust(dist(zerofy(y)),"average")$order,,drop=FALSE],
#                colrep(rep(i,nrow(y)),nc.1)
#            )
#        }))
        hm.ord <- list(trend.ord=trend.ord,clust.ord=clust.ord)
    }
    
    xco <- do.call(rbind, lapply(trend.ord, function(i) {
        y <- x[clust.ord[[i]],,drop=FALSE]
        cbind(y, colrep(rep(i,nrow(y)),nc.1))
    }))
    trends2 <- trends[,colSums(is.na(trends))==0]
    xlab <- paste("Mean Scaled Euc Dist:",round(mean(dist(trends2))/diff(range(trends2)),3))
    
    par(mfrow=c(1,3), las=1, cex=cex)
    
    if (length(col.bars)==0) col.bars <- ternary(mm<=8, 1:mm, rainbow(mm))
    lineplot(trends, col=col.bars, main="Cluster Trends", xlab=xlab, legend=lpos)
    barplot(table(map), col=col.bars, main="Cluster Sizes")
    
    if (any(xr>0) & any(xr<0)) {
        if (length(pal.hm)==0) pal.hm <- "RWB"
        mipu(xco, pal=pal.hm, col.center=0, att.col=(nc+1):ncol(xco), att.pal=col.bars, show.scale=FALSE, main="Cluster Heatmap")
    } else if (all(xr>=0)) {
        if (length(pal.hm)==0) pal.hm <- "Reds0"
        mipu(xco, pal=pal.hm, att.col=(nc+1):ncol(xco), att.pal=col.bars, show.scale=FALSE, main="Cluster Heatmap")
    } else if (all(xr<=0)) {
        if (length(pal.hm)==0) pal.hm <- "Blues0"
        mipu(xco, pal=pal.hm, rev.pal=TRUE, att.col=(nc+1):ncol(xco), att.pal=col.bars, show.scale=FALSE, main="Cluster Heatmap")
    } else {
        message(paste("Failed to identify data range!",xr,"\n"))
    }
    
    invisible(list(trends=trends,hm.ord=hm.ord))
}


apa.names$clustering <- c(apa.names$clustering, "compare.cluster.trends")
compare.cluster.trends <- function(maps, mats, cols=NULL, wide=TRUE, fun="mean", las=1, cex=1, lty=1, lwd=1, xlab="", ylab="", layout=NULL) {
	
	# plot trendlines of same-numbered clusters together (e.g. all cluster "1" trendlines plotted in same plot, all "2" trendlines on next plot, etc.).
	# "mats" is a list of matrices that were clustered.
	# "maps" is a list of cluster mappings, same respective order as "mats".
	# *** It is advised to run translate() on maps 2-N, to make their clustering numbers match the respective numbers from cluster 1.  
	#     That way all clusters with same numbers have same trends too.
	# Results are a multi-plot with one sub-plot per cluster number.
	# "cols" specifies colors per mapping (default 1:N; colors recycle if N > 8).
	# "wide" specifies that plot layout, if non-square, prefers wider layout (as opposed to taller).  Actual nrow, ncol from MA.scatter.plotdim().
	# "fun" specifies to take cluster trend by this function (so column mean, median, etc)
	
	N <- length(mats)
	if (length(maps) != N) stop("'mats' and 'maps' must have same length!\n")
	M <- max(sapply(maps,luniq))
	if (length(layout)==0) layout <- MA.scatter.plotdim(M, wide=wide)   # irows icols iheight iwidth
	if (length(cols)==0) cols <- 1:N
	
	par(mfrow=layout[1:2], cex=cex, las=las)
	for (m in 1:M) {  # clusters
		legx <- ifelse(m == 1, "topright", NA)
		x <- do.call(rbind, lapply(1:N, function(i){ apply(mats[[i]][maps[[i]]==m,], 2, fun) }))
		dimnames(x) <- list(names(mats), colnames(mats[[1]]))
		lineplot(x, legend=legx, lty=lty, lwd=lwd, col=cols, xlab=xlab, ylab=ylab, main=paste("Cluster",m))
	}
}


apa.names$general <- c(apa.names$general, "interleave")
interleave <- function(..., df.names=NULL, col.ord=FALSE, row.ord=FALSE, maxann=NULL, stringsAsFactors=TRUE) {
	
	## Takes N data frames and produces one output data frame, which consists of columns of the originals, shuffled together in order.
	##  e.g. given data frames A, B, C, each with three columns, output column order is { A1 B1 C1 A2 B2 C2 A3 B3 C3 }
	## Input may be separate data frames or a list of them.
	## All data frames must have the same dimension
	## "df.names" is a vector of names, one for each data frame, that become column name prefixes.  Otherwise, column names get numeric suffixes.
	## "col.ord=T" means that columns should be ordered prior to interleaving.  Requires colnames be equal among inputs.
	## "row.ord=T" means that rows should be ordered prior to interleaving.  Requires "maxann".
	## "maxann=<real num>" means that the first 'maxann' columns are annotation; use this to order the rows.
	##  If "maxann=0", rownames are used to order the data frames.
	## "stringsAsFactors" affects the output data frame.
	
	if (row.ord & is.null(maxann)) { stop("Cannot use 'row.ord=T' without specifying 'maxann'!\n") }
	
	input <- list(...)
	if (length(input) == 1) { 	# was a list to begin with
		input <- input[[1]]
	}
	N <- length(input)
	
	oktype <- okdim <- TRUE
	dim1 <- dim(input[[1]])
	for (i in 1:N) {
		dimi <- dim(input[[i]])
		if (!is.data.frame(input[[i]])) { 
			oktype <- FALSE 
		} else if (dimi[1] != dim1[1] | dimi[2] != dim1[2]) {
			okdim <- FALSE 
		}
	}
	if (!oktype) { stop("Inputs must all be data frames! (or a list of them)\n") }
	if (!okdim) { stop("Data frames must all have same dimension!\n") }
	
	if (col.ord) {	
		# all column names must be same for each df
		cnames <- colnames(input[[1]])
		if (!is.null(df.names)) {
			allcnames <- paste(df.names[i], cnames, sep=".")
		} else {
			allcnames <- paste(cnames, 1, sep=".")
		}
		for (i in 2:N) {
			int <- intersect(cnames, colnames(input[[i]]))
			if (length(int) != length(cnames)) {	# not same colnames
				stop(paste("Input",i,"has different column names from input 1!  Cannot order columns.\n"))
			}
			ord <- match(colnames(input[[i]]),cnames)
			input[[i]] <- input[[i]][,ord]	# reorder columns to match input #1
			if (!is.null(df.names)) {
				allcnames <- c(allcnames, paste(df.names[i], cnames, sep="."))
			} else {
				allcnames <- c(allcnames, paste(cnames, i, sep="."))
			}
		}
	} else {	
		# column names may vary between dfs
		allcnames <- rep("", N*dim1[2])
		k <- 0
		for (j in 1:dim1[2]) {
			for (i in 1:N) {
				k <- k + 1
				if (!is.null(df.names)) {
					allcnames[k] <- paste(df.names[i], colnames(input[[i]])[j], sep=".")
				} else {
					allcnames[k] <- paste(colnames(input[[i]])[j], j, sep=".")
				}
			}
		}
	}
	
	if (row.ord) {
		if (maxann == 0) {
			rnames1 <- rownames(input[[1]])
			ord <- do.call(order, rnames1)
			rnames1 <- rnames1[ord]
			input[[1]] <- input[[1]][ord,]
			for (i in 2:N) {
				rnamesi <- rownames(input[[i]])
				ord <- do.call(order, rnamesi)
				rnamesi <- rnamesi[ord,]
				if (all(rnames1==rnamesi)) { 
					input[[i]] <- input[[i]][ord,]	# reorder rows to match input #1
				} else {
					stop(paste("Row names for input",i,"are incompatible with input 1!\n"))
				}
			}
			allrnames <- rnames1
		} else {
			anncols1 <- input[[1]][,1:maxann]
			ord <- do.call(order, anncols1)
			anncols1 <- anncols1[ord,]
			input[[1]] <- input[[1]][ord,]
			for (i in 2:N) {
				anncolsi <- input[[i]][,1:maxann]
				ord <- do.call(order, anncolsi)
				anncolsi <- anncolsi[ord,]
				if (all(anncols1==anncolsi)) { 
					input[[i]] <- input[[i]][ord,]	# reorder rows to match input #1
				} else {
					stop(paste("The first",maxann,"(annot) columns for input",i,"are incompatible with input 1!\n"))
				}
			}
			allrnames <- 1:nrow(input[[1]])
		}
	}
	
	cols <- vector("list", length=dim1[2]*N)
	k <- 0
	for (i in 1:dim1[2]) {
		for (j in 1:N) {
			k <- k + 1
			cols[[k]] <- input[[j]][,i]
		}
	}
	inter <- as.data.frame.matrix(do.call(cbind, cols), stringsAsFactors=stringsAsFactors)
	colnames(inter) <- allcnames
	rownames(inter) <- allrnames
	return(inter)
}


apa.names$general <- c(apa.names$general, "barplot.shuffle")
barplot.shuffle <- function(mat, cols, plot=FALSE, legend="topright", ...) {
	
	col.mat <- colrep(cols, ncol(mat))
	for (i in 1:ncol(mat)) {
		x <- order(mat[,i], decreasing=TRUE)
		mat[,i] <- mat[x,i]
		col.mat[,i] <- col.mat[x,i]
	}
	factors <- rownames(mat)
	
	if (plot) {
		bp.args <- list(...)
		bp.args$height <- mat[1,]
		bp.args$col <- col.mat[1,]
		bp.args$names <- colnames(mat)
		bp.args$beside <- TRUE
		do.call(barplot, bp.args)
		
		bp.args$names <- NA
		bp.args$add <- TRUE
		bp.args$xaxt <- "n"
		bp.args$yaxt <- "n"

		for (i in 2:nrow(mat)) {
			bp.args$height <- mat[i,]
			bp.args$col <- col.mat[i,]
			do.call(barplot, bp.args)
		}
		legend(legend, bty="n", col=cols, pch=15, cex=1.5, legend=factors)
	}
	
	mat <- rownameless(mat)  # rownames no longer meaningful
	invisible(list(mat=mat, cols=col.mat))
}


apa.names$clustering <- c(apa.names$clustering, "template.match")
template.match <- function(obj, templates, tiebreak=c("random","both","drop"), p.values=TRUE, anti=FALSE) {
	
	## MeV-style "Pavlidis Template Matching" which takes a dataset and correlates each row to a set of templates.
	## 'templates' is vector, list of vectors, or numeric matrix (of row vectors); each vector specifies an abstract trend across samples (e.g. c(0,0,0,1,1,1), c(1,2,3,2,1), etc.).
	## - Template length must equal ncol(obj)
	## Rows are assigned to the template to which they correlate most strongly.
	## - In the rare case that a vector matches 2 templates equally strongly, 'tiebreak' takes effect.
	## - 'tiebreak' indicates whether to assign row to one best template randomly, or assign to both, or to not assign the row at all.
	## 'p.values' controls returning of p-values along with R-values
	## 'anti' controls the allowing of anticorrelators to go into their own clusters:
	## - if FALSE: template N (+) corrs assigned to 'N'
	## - if TRUE:  template N (+) corrs assigned to 'N' and (-) corrs assigned to '-N' 
	
	tiebreak <- match.arg(tiebreak)
	if (is.nlv(templates)) {
		temp.names <- 1
		templates <- list(templates)
	} else if (is.list(templates)) {
		temp.names <- ternary(length(names(templates))==0, 1:length(templates), names(templates))
	} else if (is.matrix(templates)) {
		temp.names <- ternary(length(rownames(templates))==0, 1:nrow(templates), rownames(templates))
		templates <- lapply(1:nrow(templates), function(i){templates[i,]})
	} else {
		stop ("Unknown object type for 'templates': must be vector, list, or matrix!\n")
	}
	T <- length(templates)
	R <- nrow(obj)
	if (T==0) stop("No templates to correlate to!\n")
	if (R==0) stop("'obj' is empty!\n")
	if(!is.matrix(obj)) obj <- as.matrix(obj)
	multi <- FALSE
	matches <- new.list(qw(template,R,p.val))
	if (p.values) {
		cor.p <- matrix(0, nrow(obj), T*2)
		for (i in 1:T) {
#			IM(" Template",i)
			j <- (i-1)*2+1
			suppressWarnings(x <- apply(obj, 1, function(x) unlist(cor.test(x,templates[[i]])[c(4,3)]) ))
			cor.p[,c(j,j+1)] <- t(x)
			# if (is.matrix(x)) {
				# cor.p[i] <- t(x)
			# } else {
				# cor.p[i] <- do.call(rbind, x)
			# }
		}
#		cor.p <- do.call(cbind, cor.p)
		cors <- as.matrix(cor.p[,seq(1, T*2, 2)])  # R value columns
		pval <- as.matrix(cor.p[,seq(2, T*2, 2)])  # p value columns
		pval[is.na(pval)] <- 1
		apval <- apply(pval, 2, p.adjust, method="BH")
	} else {
		suppressWarnings(cors <- as.matrix(sapply(templates, function(x) cor(x, t(obj)) )))
	}
	na <- which(apply(is.na(cors), 1, all))
	if (length(na)>0) {   # invariant genes exist
		invar <- which(apply(is.na(cors), 2, all))   # does an invariant template exist?
		if (length(invar)>1) { 
			IM("More than one invariant template exists!  Selecting first one.\n") 
			invar <- invar[1]
		}
		cors[na,invar] <- 1   # assign invariant genes to invariant template
	}
#	return(cors)
#	maxpos <- as.list(apply(cors, 1, function(i){which(i==max(i))}))
	if (anti) {
		maxany <- as.list(apply(abs(zerofy(cors)), 1, function(i) which(i==max(i)) ))
		maxneg <- as.list(apply(zerofy(cors), 1, function(i) which(i==min(i)) ))
	} else {
		maxany <- as.list(apply(zerofy(cors), 1, function(i) which(i==max(i)) ))
	}
	x <- which(listLengths(maxany)>1)
	if (length(x)>0) {
		IM(length(x),"rows had > 1 best template!\n")
		if (tiebreak == "both") {
			multi <- TRUE
		} else {
			if (tiebreak == "drop") {
				# maxany[[x]] <- maxpos[[x]] <- maxneg[[x]] <- NA
				for (i in x) maxany[[i]] <- NA
			} else {
				for (i in x) maxany[[i]] <- sample(maxany[[i]], 1)
#				if (maxany[[x]] %in% maxpos[[x]]) maxpos[[x]] <- maxany[[x]]
#				if (maxany[[x]] %in% maxmin[[x]]) maxmin[[x]] <- maxany[[x]]
			}
		}
	}
	# matches$template <- maxpos
	# matches$R <- lapply(1:length(maxpos), function(i){ cors[i,maxpos[[i]]] })
	matches$template <- maxany
	matches$R <- lapply(1:length(maxany), function(i) ifelse(is.na(i),i,cors[i,maxany[[i]]]) )
	if (p.values) {
		# matches$p.val <- lapply(1:length(maxpos), function(i){ pval[i,maxpos[[i]]] })
		matches$p.val <- lapply(1:length(maxany), function(i) pval[i,maxany[[i]]] )
		matches$adj.p.val <- lapply(1:length(maxany), function(i) apval[i,maxany[[i]]] )
	}
	if (multi) {
		if (anti) {
			for (i in 1:length(matches$R)) {
				n <- which(matches$R[[i]] %in% maxneg[[i]])
				if (length(n)>0) matches$R[[i]][n] <- -1 * matches$R[[i]][n]
			}
		}
	} else {
		for (i in 1:length(matches)) matches[[i]] <- unlist(matches[[i]])
		matches <- as.matrix(do.call(cbind, matches))  # if matches are singular, we can compress data structure
		if (anti) matches[,1] <- matches[,1] * sign(matches[,2])
	}
	return(matches)
}


apa.names$clustering <- c(apa.names$clustering, "slope.clust")
slope.clust <- function(obj, dirs=c(-1,0,1), tolerance=NA) {
    
    ## ********  THIS METHOD INTENDED FOR Z-SCORE ROW-NORMALIZED DATA ONLY  ********
    ## Profile-based clustering of genes using a "qualitative" method based on slope signs.
    ## All possible clusters are defined in advance, then genes are assigned to each based on profile characteristics.
    ## In a nutshell, for each gene, the slopes between sample points can be either increasing, decreasing, or invariant (within some tolerance).
    ## Thus 3 choices ^ (N-1) slopes => possible clusters.
    ## Choose invariance tolerance (if any), and assign genes to their appropriate cluster.
    ## 'tolerance' sets invariance tolerance, as the maximum number of standard deviations (distance on z-scale) of ignorable change between two points.
    ## - 'tolerance=NA' results in template matching to the cluster profiles.
    ## 'DBI' turns on reporting of DBI/intracluster variance.  These may crash for large datasets.  Not available if tolerance is NA.
    
    tmatch <- ifelse(is.na(tolerance), TRUE, FALSE)
    ndirs <- data.frame(c(-1,0,1), qw(DN,NC,UP))
    N <- ncol(obj)-1
    
    profiles <- t(apply(permn2(length(dirs), N, replacement=TRUE), 1, function(x) dirs[x] ))
    P <- nrow(profiles)
    map <- matrix("NA", nrow(obj), 1, F, list(rownames(obj),"Cluster"))
    centers <- matrix(0, P, ncol(obj))
    
    clusters <- vector("list", length=P+1)  # extra 1 for the "unclusterable cluster", just in case
    names(clusters) <- c(apply(profiles, 1, function(x) paste( ndirs[match(x,ndirs[,1]),2], collapse="." ) ), "NA")
    sets <- new.list(names(clusters))
    lost <- rep(0, P)
    
    ## Clustering
    if (tmatch) {
        V <- 1:ncol(obj)   # template values
        templates <- matrix(0, nrow(profiles), ncol(obj))
        for (i in 1:P) {
            templates[i,1] <- 0
            for (j in 1:N) {
                templates[i,(j+1)] <- templates[i,j] + profiles[i,j]
            }
        }
        tmatches <- template.match(obj, templates, p.values=FALSE, anti=FALSE)
        map <- names(clusters)[tmatches[,1]]
    } else {
        prof <- t(apply(obj, 1, function(x) diff(x) ))
        sprof <- sign(prof)
        if (!is.na(tolerance)) {
            sub.tol <- abs(prof) <= tolerance
            sprof[sub.tol] <- 0  # slopes within tolerance limit become "no-slopes"
        }
        for (i in 1:P) {
            set <- apply(sprof, 1, function(x) all(x==profiles[i,]) )
            map[set] <- names(clusters)[i]
        }
    }
    
    return(map)
}


apa.names$clustering <- c(apa.names$clustering, c("binary.clust","bclust"))
bclust <- binary.clust <- function(obj, method=c("euclidean","pearson","spearman","mean","min-mean","max-mean","median","min-median","max-median"), linkage=c("average","median","centroid","ward","mcquitty","single","complete"), present=NA, by.max=FALSE, by.min=FALSE) {
    
    ## Pre-clusters rows in a heatmap into blocks, according to which columns are present/absent
    ## Then hierarchically clusters within blocks, according to distance method 'method'
    ## present/absent cutoff determined by value of 'present', which is minimum present value.  Values < 'present' treated as NA.
    ## 'obj' is a numeric matrix
    ## output is length-2 list: 1=row ordering vector, 2=list of clusters
    ## 'by.max=TRUE' changes block definitions from present/absent to which.max on columns (thus rows with max in col 1 come first, then rows with max in col 2, etc)
    
    method <- match.arg(method)
    linkage <- match.arg(linkage)
    if (by.max & by.min) stop("'by.max' and 'by.min' cannot both be TRUE !\n")
    
    if (nrow(obj)==1) return(list(order=1,clusters=list(1)))
    
    if (length(rownames(obj))==0) rownames(obj) <- 1:nrow(obj)
    old.rownames <- rownames(obj)
    
    if (by.max) {
        row.blocks <- apply(obj, 1, which.max)
    } else if (by.min) {
        row.blocks <- apply(obj, 1, which.min)
    } else {
        ##block.patterns <- permn2(0:1, ncol(obj), TRUE)
        ##block.patterns <- block.patterns[order(rowSums(block.patterns),decreasing=TRUE),ncol(obj):1]
        ##block.codes <- apply(block.patterns, 1, paste, collapse="")
        
        obj.bin <- obj
        for (i in 1:ncol(obj)) {  # going by column in case of very large matrices -- may be unable to subscript entire thing
            if (is.na(present)) {
                obj.bin[!is.na(obj.bin[,i]),i] <- 1
                obj.bin[is.na(obj.bin[,i]),i] <- 0
            } else {
                obj.bin[obj.bin[,i]<present,i] <- NA
                obj.bin[obj.bin[,i]>=present,i] <- 1
                obj.bin[is.na(obj.bin[,i]),i] <- 0
            }
        }
        obj.codes <- apply(obj.bin, 1, paste, collapse="")
        block.codes <- rev(sort(unique(obj.codes)))  # not the exhaustive list -- which could take hours to calculate on a large dataset
        row.blocks <- sapply(obj.codes, function(x) which(block.codes==x) )
    }
    
    block.rows <- split(1:nrow(obj), row.blocks)
    block.rows <- blocks.ord <- blocks.clust <- block.rows[order(as.numeric(names(block.rows)))]  # put blocks in numeric order, if >= 10 blocks
    B <- length(block.rows)
    
    ##ordfun <- get(ifelse(by.max, "max", ifelse(by.min, "min", "mean")))
    clustfun <- switch(
        method,
        "euclidean"=function(x){ reorder.hclust2(hclust(dist(zerofy(x)),linkage),zerofy(x),mean)$order },
        ##"euclidean"=function(x){ reorder.hclust2(hclust(dist(zerofy(x)),linkage),zerofy(x),ordfun)$order },
        "pearson"=function(x){ hclust(distance(zerofy(x)),linkage)$order },
        "spearman"=function(x){ hclust(distance(zerofy(x),"spearman"),linkage)$order },
        "mean"=function(x){ rev(order(rowMeans(zerofy(x)))) },
        "min-mean"=function(x){ rev(order(rowMeans(zerofy(x[,which.min(x[1,])])))) },
        "max-mean"=function(x){ rev(order(rowMeans(zerofy(x[,which.max(x[1,])])))) },
        "median"=function(x){ rev(order(rowMedians(zerofy(x)))) },
        "min-median"=function(x){ rev(order(rowMedians(zerofy(x[,which.min(x[1,])])))) },
        "max-median"=function(x){ rev(order(rowMedians(zerofy(x[,which.max(x[1,])])))) }
    )
    
    for (i in 1:B) {
        if (length(block.rows[[i]])>1) {
            blocks.ord[[i]] <- block.rows[[i]][clustfun(obj[block.rows[[i]],,drop=FALSE])]
        } else {
            blocks.ord[[i]] <- block.rows[[i]]
        }
        blocks.clust[[i]] <- obj[blocks.ord[[i]],,drop=FALSE]
    }
    names(blocks.ord) <- colnames(obj)[as.numeric(names(blocks.ord))]
    
    return(list(order=nameless(unlist(blocks.ord)),clusters=blocks.ord))
}


apa.names$clustering <- c(apa.names$clustering, c("split.clust"))
split.clust <- function(x, p, by=c("rows","cols"), method="euclidean", linkage="average", reorder=FALSE, p.clust=FALSE) {
    ## 'x' is a matrix to cluster
    ## 'p' is a list of vectors partitioning the rows OR cols of 'x'
    ## 'by' indicates that 'p' applies to rows of x, or cols of x
    ## 'p.clust' also clusters the means of the rows/cols of 'p', thus reordering elements of 'p'
    ## 'method' is passed to dist() (or distance(), if needed); 'minkowski' not supported.
    ## 'linkage' is passed to hclust()
    ## returns a modified 'p', where each vector is now clustered
    
    by <- match.arg(by)
    psum <- sum(listLengths(p))
    x <- as.matrix(x)
    P <- length(p)
    if (by=="rows") {
        if (psum!=nrow(x)) stop(psum," != ",nrow(x))
        x2 <- lapply(p, function(v) x[v,] )
    } else if (by=="cols") {
        if (psum!=ncol(x)) stop(psum," != ",ncol(x))
        x2 <- lapply(p, function(v) t(x[,v]) )
    }
    
    if (!(linkage %in% c("ward.D","ward.D2","single","complete","average","mcquitty","median","centroid"))) {
        stop("Unknown 'linkage'\n")
    }
    
    if (method %in% c("euclidean","maximum","manhattan","canberra","binary")) {
        d <- dist
    } else if (method %in% c("pearson","pearson2","spearman","spearman2","kendall","r2","adjusted.r2","shape","silhouette","mahalanobis","jaccard","venn","edit","tile")) {
        d <- distance
    } else {
        stop(paste0("Unknown method '",method,"'\n"))
    }
    if (reorder) {
        x3 <- lapply(1:P, function(i) p[[i]][reorder.hclust2(hclust(d(x2[[i]],method),linkage),x2[[i]],mean)$order] )
    } else {
        x3 <- lapply(1:P, function(i) p[[i]][hclust(d(x2[[i]],method),linkage)$order] )
    }
    
    if (p.clust) {
        x2m <- do.call(rbind,lapply(x2,colMeans))
        if (reorder) {
            p.ord <- reorder.hclust2(hclust(d(x2m,method),linkage),x2m,mean)$order
        } else {
            p.ord <- hclust(d(x2m,method),linkage)$order
        }
        x3 <- x3[p.ord]
    }
    
    x3
}


apa.names$clustering <- c(apa.names$clustering, c("subcluster"))
subcluster <- subcluster <- function(x, map, ord, method=c("reordered.euclidean","euclidean","binary","manhattan","canberra","pearson","spearman","mean","mean-min","mean-max","median","median-min","median-max"), linkage=c("average","median","centroid","ward","mcquitty","single","complete")) {
    
    ## Breaks an object into row-slices, clusters them separately, then re-assembles.
    ## 'x' is a numeric matrix to cluster.
    ## 'map' is a row grouping vector for 'x'.
    ## 'ord' is an ordering, a vector of unique values in 'map', in the order to reassemble them.
    
    method <- match.arg(method)
    linkage <- match.arg(linkage)
    if (nrow(x)==1) return(list(order=1,clusters=list(1)))
    
    if (!is.matrix(x) | !(is.numeric(x) | is.integer(x))) stop("")
    blocks.ord <- new.list(ord)
    block.rows <- split(1:nrow(x), map)
    block.rows <- block.rows[match(ord, names(block.rows))]
    B <- length(block.rows)
    
    clusterfunc <- switch(
        method,
        "reordered.euclidean"=function(x){ reorder.hclust2(hclust(dist(zerofy(x)),linkage),zerofy(x),mean)$order },
        "euclidean"=function(x){                           hclust(dist(zerofy(x)),linkage)$order                 },
        "binary"=function(x){                              hclust(dist(zerofy(x),"binary"),linkage)$order        },
        "manhattan"=function(x){                           hclust(dist(zerofy(x),"manhattan"),linkage)$order     },
        "canberra"=function(x){                            hclust(dist(zerofy(x),"canberra"),linkage)$order      },
        "pearson"=function(x){                             hclust(distance(zerofy(x)),linkage)$order             },
        "spearman"=function(x){                            hclust(distance(zerofy(x),"spearman"),linkage)$order  },
        "mean"=function(x){                rev(order(rowMeans(zerofy(x))))                                       },
        "mean-min"=function(x){            rev(order(rowMeans(zerofy(x[,which.min(x[1,])]))))                    },
        "mean-max"=function(x){            rev(order(rowMeans(zerofy(x[,which.max(x[1,])]))))                    },
        "median"=function(x){              rev(order(rowMedians(zerofy(x))))                                     },
        "median-min"=function(x){          rev(order(rowMedians(zerofy(x[,which.min(x[1,])]))))                  },
        "median-max"=function(x){          rev(order(rowMedians(zerofy(x[,which.max(x[1,])]))))                  }
    )
    
    for (i in 1:B) {
        li <- length(block.rows[[i]])
        if (li==0) next
        do.clust <- ifelse(li>2 | (li>1 & method %in% qw(mean,median)), TRUE, FALSE)
        if (do.clust) {
            blocks.ord[[i]] <- block.rows[[i]][clusterfunc(x[block.rows[[i]],,drop=FALSE])]
        } else {
            blocks.ord[[i]] <- block.rows[[i]]
        }
    }

    cl.id <- rep(ord,times=listLengths(blocks.ord))
    return(list( order=nameless(unlist(blocks.ord)), clusters=blocks.ord, clust.id=cl.id, clust.bin=(as.numeric(factor2(cl.id))%%2==1)+0 ))
}


apa.names$clustering <- c(apa.names$clustering, "kmeans.consensus")
kmeans.consensus <- function(obj, centers, iter.max=5000, nstart=1, algorithm=c("Hartigan-Wong","Lloyd","Forgy","MacQueen"), trials=11, r.thresh=1, stable=0.5, more=FALSE, verbose=FALSE) {
    
    ## Iterates a k-means for 'trials' trials and assigns genes to clusters based on the most-prevalent mapping.
    ## Genes which have no consensus mapping go to "Outlier" cluster.
    ## Consensus clustering maps are made from trials with 1:1 cluster relationships.  
    ##   This is ascertained by cluster profile correlations between trial pairs; each trial-i cluster must have 1 and only 1 trial-j cluster with max R and R >= 'r.thresh'.
    ##   Thus cluster identity across trials means deciding which trial-j cluster correlates most with given trial-i cluster, as long as the R value passes the threshold.
    ##   If any trial-i cluster has 0 or > 1 best correlator in trial j, then the two trials are not 1:1.
    ## It can emerge that a given dataset has > 1 stable maps, i.e., 2+ ways in which it can be repeatably clustered:
    ##   For this reason 'trials' should be odd, to facilitate tie-breaking.
    ## 'r.thresh' is an R value on [-1,1].  Higher values = higher stringency for cluster similarity.
    ## 'stable' is a stability threshold percent on [0,1].  
    ##   A gene is assigned to a cluster if it occurs in that cluster in > 'stable'% of trials.  Thus 'stable' should always be >= 0.5
    ## 'more' returns not just the final clustering(s), but a variety of intermediate data for inspection or debugging
    
    algorithm <- match.arg(algorithm)
    if (is.data.frame(obj)) obj <- as.matrix(obj)
    if (is.na(r.thresh)) r.thresh <- -2  # below lowest possible
    nr <- nrow(obj)
    nc <- ncol(obj)
    if (length(centers)>1) {
        centers <- as.matrix(centers)
        N <- nrow(centers)
    } else {
        N <- centers
    }
    km <- vector("list", length=trials)  # initially
    km2km <- vector("list", length=trials)
    names(km2km) <- paste0("Trial", 1:trials)
    genemap.init <- matrix(0, nrow(obj), trials, F, list(rownames(obj),1:trials))
    
    for (i in 1:trials) {
        if (verbose) IM("Running Trial",i)
        km2km[[i]] <- vector("list", length=trials)  # one element per row, col
        km[[i]] <- kmeans(x=obj, centers=centers, iter.max=iter.max, nstart=nstart, algorithm=algorithm)
        genemap.init[,i] <- km[[i]]$cluster
    }
    
    if (verbose) IM("Evaluating Trials")
    trial.equiv <- matrix(0, trials, trials)
    for (i in 1:trials) {
        iclusters <- lapply(split(1:nr, km[[i]]$cluster), function(x) obj[x,] )
        icm <- t(sapply(iclusters, colMeans))
        rownames(icm) <- paste0("Trial",i,".Cluster",1:N)
        trial.equiv[i,i] <- 1
        for (j in 1:trials) {
            if (i <= j)  next    # keep it triangular; compare later trials to earlier
            jclusters <- lapply(split(1:nr, km[[j]]$cluster), function(x) obj[x,] )
            jcm <- t(sapply(jclusters, colMeans))
            rownames(jcm) <- paste0("Trial",j,".Cluster",1:N)
            km2km[[i]][[j]] <- list(icm=icm, jcm=jcm, corr=corr.mat(t(icm),t(jcm)))  # correlate cluster mean profiles
            ## equivalence decided on max R value, but only if R >= r.thresh; may return > 1
            km2km[[i]][[j]]$eq <- lapply(1:N, function(x){ y=zapsmall(km2km[[i]][[j]]$corr[,x]); z=which(y==max(y)&y>=r.thresh); ifelse(length(z)>0,z,NA) })  # TEST ON COLS NOT ROWS: always j relative to i
            one2one <- all(sapply(km2km[[i]][[j]]$eq,length)==1) & length(unique(unlist(km2km[[i]][[j]]$eq)))==N
            if (one2one) {
                onto <- sum(!sapply(km2km[[i]][[j]]$eq, is.na))==N
                if (onto) trial.equiv[i,j] <- trial.equiv[j,i] <- 1  # bijective trial pairs
            }
        }
        km2km[[i]] <- km2km[[i]][listLengths(km2km[[i]])>0]  # drop all unfilled [[j]] elements
    }
    
    if (verbose) IM("Finalizing")
    trial.sets <- clustermap <- gene.stability <- conn.mat.subgraphs(trial.equiv)  # a mapping consists of a set of equivalent trials.  Ideally there will be only one.
    print(trial.sets)
    tso <- hclust(dist(trial.equiv,"binary"),"average")$order
    teo <- trial.equiv[tso,tso]; dimnames(teo) <- list(tso,tso)
    tNA <- !(rownames(teo) %in% unlist(trial.sets))
    teo[tNA,tNA][teo[tNA,tNA]==1] <- 0.5
    dev.new(); mipu(teo)
    
    if (length(trial.sets)==0) { 
        IM("Failed: trials were 0% stable.\n")
        if (more) {
            return(list(km2km=km2km, genemap.init=genemap.init, trial.equiv=trial.equiv))
        } else {
            return()
        }
    } else {
        lm <- length(trial.sets)
        llm <- listLengths(trial.sets)
        trial.sets <- trial.sets[order(llm,decreasing=TRUE)]
        clustermap.complete <- clustermap
        for (i in 1:lm) {
            clustermap[[i]] <- matrix(0, N, length(trial.sets[[i]]), F, list(1:N,trial.sets[[i]]))
            clustermap[[i]][,1] <- 1:N  # reference
            mapi <- trial.sets[[i]][1]
            for (j in 2:length(trial.sets[[i]])) {
                mapj <- trial.sets[[i]][j]
                clustermap[[i]][,j] <- unlist(km2km[[mapj]][[mapi]]$eq)  # mapj is the trial being compared; mapi is the trial it is compared to
            }
            clustermap.complete[[i]] <- clustermap[[i]][,colSums(is.na(clustermap[[i]]))==0]
        }
        
        topm.t <- max(sapply(clustermap,ncol))  # n trials in top map(s)
        topm.n <- sum(sapply(clustermap,ncol)==topm.t)  # n top map(s)
        topm.w <- which(sapply(clustermap,ncol)==topm.t)  # which top map(s)
        topm.c <- sapply(clustermap.complete[topm.w], ncol)  # n bijective trials in top map(s)
        top.top <- which(topm.c==max(topm.c))  # most bijective trials of the top map(s)
        if (topm.n > 1 & length(top.top)>1) {
            IM(paste("Failed:",topm.n,"top-ranked clustermaps observed, with ",topm.t,"/",trials," trials and ",max(topm.c)," bijectives!  Increase 'trials', 'nstart' or maybe 'iter.max' to break tie.\n"))
            if (more) {
                return(list(trial.sets=trial.sets, km2km=km2km, genemap.init=genemap.init, clustermap=clustermap, trial.equiv=trial.equiv))
            } else {
                return()
            }
        }
        
        IM(paste0("Succeeded: 1 best clustermap with ",topm.t,"/",trials," trials, of which ",max(topm.c)," were bijective.\n"))
        init.clustering <- matrix(genemap.init[,1:lm], nrow(obj), lm, F, list(rownames(obj),1:lm))  # initialize
        genemap.final <- genemap.init
        for (i in 1:lm) {
            maptrials <- as.numeric(colnames(clustermap[[i]]))
            nmt <- length(maptrials)
            maptrials.ok <- maptrials[colSums(is.na(clustermap[[i]]))==0]
            nmo <- length(maptrials.ok)
            init.clustering[,i] <- genemap.init[,maptrials.ok[1]]
            gene.stability[[i]] <- apply(genemap.init[,maptrials], 1, function(x) sum(x==clustermap[[i]][x[1],]) )
            init.clustering[which(sapply(gene.stability[[i]], function(x) x<=stable*nmt )),i] <- NA   # the "unstable" cluster
            for (j in 2:nmt) {
                convert.from <- clustermap[[i]][,j]
                convert.to <- clustermap[[i]][,1]
                convert.to[is.na(convert.from)] <- NA
                genemap.final[,maptrials[j]] <- translate(genemap.init[,maptrials[j]], convert.from, convert.to)  # change cluster numbers to match first cluster
            }
        }
#        return(list(init.clustering=init.clustering, trial.sets=trial.sets, km2km=km2km, gene.stability=gene.stability, genemap.init=genemap.init, clustermap=clustermap, trial.equiv=trial.equiv))
        
        if (FALSE) {
#        if (lm > 1) {  # multiple trial.sets = multiple clustering configurations
            map.equiv <- matrix(0, lm, lm)   # test to see if trial.sets, though disjoint, are still equivalent (same gene assignments) -- merge if so
            for (i in 1:lm) {
                for (j in 1:lm) {
                    if (all(falsify(init.clustering[,i]==init.clustering[,j]))) map.equiv[i,j] <- 1
                }
            }
            
            equivalents <- conn.mat.subgraphs(map.equiv)
            le <- length(equivalents)
            final.clustering <- matrix(rep(genemap.init[,1],le), nrow(obj), le, F, list(rownames(obj),1:le))
            for (i in 1:le) {
                final.clustering[,i] <- init.clustering[,equivalents[[i]][1]]  # take first from each set of equivalent trial.sets
            }
        } else {
            map.equiv <- c()
            final.clustering <- init.clustering
        }
	
        if (more) {
            return(list(final.clustering=final.clustering, init.clustering=init.clustering, trial.sets=trial.sets, km2km=km2km, 
                        gene.stability=gene.stability, genemap.init=genemap.init, genemap.final=genemap.final, clustermap=clustermap, trial.equiv=trial.equiv, teo=teo)) #, map.equiv=map.equiv))
        } else {
            return(final.clustering)
        }
    }
}


apa.names$clustering <- c(apa.names$clustering, "kmeans.krange")
kmeans.krange <- function(obj, centers, iter.max=5000, nstart=100, algorithm=c("Hartigan-Wong","Lloyd","Forgy","MacQueen"), trials=11, r.thresh=1, stable=0.5, plot=FALSE) {
	
	## Executes kmeans.consensus() over a range of k and selects best based on Davies-Bouldin Index (DBI)
	## Mostly same args as kmeans.consensus(), but 'centers' must be a vector with the values of k.
	##  Different args: 'more' is not an option, 'plot' is.  Setting 'plot=T' will plot the DBI across range of k.
	
	per.k <- new.list(centers)
	NC <- length(centers)
	
	for (i in 1:NC) {
		IM("K =",centers[i])
		kdata <- kmeans.consensus(obj, centers[i], iter.max, nstart, algorithm, trials, r.thresh, stable, TRUE)
		if (length(kdata$clustermap)>0) {
			per.k[[i]] <- kdata
#			DBI[i] <- kdata$DBI[kdata$trial.sets[[1]][1]]  # DBI for first memeber of majority trial set
		}
	}
	# minDBI <- min(DBI,na.rm=TRUE)
	# minDBIx <- which(DBI==minDBI)
	
	# if (plot) {
		# plot(1:NC, DBI, type="l", ylab="DBI", xlab="k", main="DBI across k", xaxt="n", las=1)
		# points(1:NC, DBI, cex=1.5)
		# points(minDBIx, minDBI, cex=1.5, col=2, lwd=2)
		# axis(1, 1:NC, labels=centers)
	# }
	
	# invisible(list(per.k=per.k, minDBI=DBI))
	invisible(per.k)
}


apa.names$clustering <- c(apa.names$clustering, "pair.assoc")
pair.assoc <- function(pairs, map1, map2) {
    
    ## pre-chi-square matrix building, for whether gene pairs exhibit significant trending.
    ## 'pairs' is either:
    ##  - a 2-col matrix; col 1 = gene 1 and col 2 = gene 2 (many-to-one, many-to-many relationships allowed).
    ##  - a named list, where names = gene 1s and list elements = vectors of gene 2s.
    ## 'map1' is a named numeric vector (or rownamed 1-col matrix) = cluster mapping for gene 1s, e.g. output from kmeans().  Names=genes; values=cluster numbers.
    ## 'map2' is the cluster mapping for the gene 2s -- need not have same number of clusters as map1
    
    if (is.list(pairs)) {
        if (is.data.frame(pairs)) {
            pairs <- as.matrix(pairs)
        } else {
            pairs <- breakout(pairs,rev=TRUE)
        }
    } else if (is.matrix(pairs)) {
        # ok
    } else {
        stop("'pairs' must be a list or matrix/data.frame!\n")
    }
    if (ncol(pairs) != 2) stop("'pairs' must have 2 columns! (gene 1s, gene 2s)\n")

    if (is.matrix(map1)) { x=map1[,1]; names(x)=rownames(map1); map1=x }
    if (is.matrix(map2)) { y=map2[,1]; names(y)=rownames(map2); map2=y }
    if (!is.numeric(map1) | length(names(map1))==0) stop("'map1' must be a named numeric vector!\n")
    if (!is.numeric(map2) | length(names(map2))==0) stop("'map2' must be a named numeric vector!\n")
#    if (length(map1) != luniq(pairs[,1])) stop("'map1' length not equal to number of 'gene 1's!\n")
#    if (length(map2) != luniq(pairs[,2])) stop("'map2' length not equal to number of 'gene 2's!\n")
    map1 <- map1[!is.na(map1)]
    map2 <- map2[!is.na(map2)]
    N1 <- length(unique(map1))
    N2 <- length(unique(map2))
    
    OBS <- matrix(0,N1,N2)
    for (i in 1:N1) {
        others <- pairs[pairs[,1] %in% names(map1)[map1==i],2]
        oclust <- table(map2[names(map2) %in% others])
        OBS[i,] <- as.numeric(oclust[match(1:N2,names(oclust))])
    }
    OBS <- zerofy(OBS)
    EXP <- round(outer(rowSums(OBS),colSums(OBS))/sum(OBS),0)
    return(list(OBS=OBS, EXP=EXP, `O-E`=OBS-EXP, X2=chisq.test(x=OBS,y=EXP)))
}


apa.names$clustering <- c(apa.names$clustering, "distance")
distance <- function(obj, method=c("pearson","pearson2","spearman","spearman2","kendall","r2","adjusted.r2","shape","silhouette","mahalanobis","jaccard","venn","edit","tile","euclidean"), dist=TRUE) {
     
    ## Some distance metrics not found in dist()
    
    method <- match.arg(method)
    squared = c("pearson2","spearman2")
    nonsquared = c("pearson","spearman")
    lmdist <- c("r2","adjusted.r2")
    use.lm <- method %in% lmdist
    
    if (is.matrix(obj)) {
        ## ok
    } else if (is.data.frame(obj)) {
        if (use.lm) {
            ## leave alone; may have factors
        } else {
            obj <- as.matrix.data.frame(obj)
            if (mode(obj) == "character") stop("object not coercible to numeric matrix!  Check your data types.\n")  # 'contaminated' df
        }
    } else {
        stop("object must be a matrix or data frame!\n")
    }
    if (!use.lm) obj[is.infinite(obj)] <- NA
    nr <- nrow(obj)
    nc <- ncol(obj)
    
    corr.d <- function(mat, method) {
        dm <- matrix(0, nrow=nr, ncol=nr)
        do.square <- FALSE
        s <- which(squared %in% method)
        if (length(s)>0) {
            method <- nonsquared[s]
            do.square <- TRUE
        }
        dm <- zerofy(cor(t(mat), method=method, use="pairwise.complete.obs"))
        if (do.square) dm <- dm^2
        return(1-dm)   # distance, not similarity
    }
    
    lm.d <- function(mat, method) {
        ## 'mat' may be a matrix OR data.frame
        elem.name <- switch(method, "r2"="r.squared", "adjusted.r2"="adj.r.squared")
        dm <- matrix(0, nrow=nr, ncol=nr)
        for (i in 1:nr) {
            for (j in 1:nr) {
                dm[i,j] <- ifelse(is.factor(mat[,j]), NA, zerofy(summary(lm(mat[,j]~mat[,i]))[[elem.name]]))
            }
        }
        if (method == "adjusted.r2") dm[dm<0] <- 0  # adj. r2 often produces negative values; threshold at zero
        return(1-dm)   # distance, not similarity
    }
    
    euc.d <- function(mat) {   # euclidean
        dm <- matrix(0, nrow=nr, ncol=nr)
        for (i in 1:nr) {
            for (j in 1:nr) {
                if (i > j) {    # keep matrix triangular to save space/time
                    dm[i,j] <- sqrt(sum((mat[i,]-mat[j,])^2, na.rm=TRUE))
                }
            }
        }
        return(upper.triangle.fill(dm, 1))
    }
    
    venn.d <- function(mat) {   # normalized "venn" distance between two binary/logical vectors (0=identical, 1=disjoint)
        mode(mat) <- "logical"
        dm <- matrix(0, nrow=nr, ncol=nr)
        for (i in 1:nr) {
            for (j in 1:nr) {
                if (i > j) {    # keep matrix triangular to save space/time
                    dm[i,j] <- sum(mat[i,] & mat[j,]) / nc
                }
            }
        }
        dm <- upper.triangle.fill(dm, 1)
        return(1-dm)
    }
    
    jaccard.d <- function(mat) {
        dm <- matrix(0, nrow=nr, ncol=nr)
        for (i in 1:nr) {
            for (j in 1:nr) {
                if (i > j) {    # keep matrix triangular to save space/time
                    dm[i,j] <- length(intersect(mat[i,], mat[j,])) / length(union(mat[i,], mat[j,]))
                }
            }
        }
        dm <- upper.triangle.fill(dm, 1)
        return(1-dm)
    }
    
    edit.d <- function(mat) {   # edit distance between two sequences
        dm <- matrix(0, nrow=nr, ncol=nr)
        for (i in 1:nr) {
            for (j in 1:nr) {
                if (i > j) {    # keep matrix triangular to save space/time
                    dm[i,j] <- sum(mat[i,] != mat[j,])
                }
            }
        }
        dm <- upper.triangle.fill(dm, 1)
        return(dm)
    }
    
    tile.d <- function(mat) {   # tile distance between two sequences of equal length (i.e. do they overlap: dist = offset for j start relative to i start; if dist==seqlen then no overlap)
        dm <- matrix(0, nrow=nr, ncol=nr)
        for (i in 1:nr) {
            for (j in 1:nr) {
                if (i > j) {   # keep matrix triangular to save space/time
                    tiles.i <- tiles.j <- rep(FALSE, nc)
                    for (k in 1:nc) {
                        if (all(mat[i,k:nc] == mat[j,1:(nc-k+1)])) { tiles.i[k] <- TRUE }
                        if (all(mat[j,k:nc] == mat[i,1:(nc-k+1)])) { tiles.j[k] <- TRUE }
                    }
                    min.i <- ifelse (any(tiles.i), min(which(tiles.i))-1, nc)
                    min.j <- ifelse (any(tiles.j), min(which(tiles.j))-1, nc)
                    if (dist) {
                        dm[i,j] <- ifelse(min.i <= min.j, min.i, min.j)    # no negatives going into as.dist()
                    } else {
                        dm[i,j] <- ifelse(min.i <= min.j, min.i, -min.j)   # give min.j as a negative
                    }
                }
            }
        }
        dm <- upper.triangle.fill(dm, 1)
        return(dm)
    }
    
    dist.mat <- switch(
        method,
        "pearson"=corr.d(obj, "pearson"),
        "pearson2"=corr.d(obj, "pearson2"),    # squared pearson
        "spearman"=corr.d(obj, "spearman"),
        "spearman2"=corr.d(obj, "spearman2"),  # squared spearman
        "kendall"=corr.d(obj, "kendall"),
        "euclidean"=euc.d(obj),
        "shape"=shape.d(obj),
        "silhouette"=silh.d(obj),
        "mahalanobis"=maha.d(obj),
        "jaccard"=jaccard.d(obj),    # aka Tanimoto
        "venn"=venn.d(obj),        # binary vector overlap
        "edit"=edit.d(obj),        # for biological sequence
        "tile"=tile.d(obj)         # for biological sequence
    )
    rownames(dist.mat) <- colnames(dist.mat) <- rownames(obj)
    
    if (dist) {
        return(as.dist(dist.mat))
    } else {
        return(dist.mat)
    }
}


apa.names$dev <- c(apa.names$dev, "empty.list")
empty.list <- function(lst) { 
	
	recurse <- function(obj, depth.now, max.depth) {
		
		# recurses through input list and destroys data, but not list structure or names
		
		depth.now <- depth.now + 1
		if (trace) { IM(depth.now, ":Start") }
		temp.depth <- env.size <- 0
		this <- list()
		if (trace) { IM(depth.now, ":Basic") }
		this$basic <- getBasic(obj)
		if (trace) { IM(depth.now, ":Adv") }
		adv <- getAdvanced(obj)
		if (trace) { IM(depth.now, ":Post") }
		this$class <- adv[[1]]
		if (length(adv[[2]]) > 0) { this$slot.attributes <- adv[[2]] }
		if (is.ndfl(obj) & length(obj) > 0) {			# recurse through subelements
			if (trace) { IM(depth.now,":ndfl") }
			this$elems <- vector("list", length=length(obj))
			names(this$elems) <- names(obj)
			if (depth.now < max.depth) {	# then we can go one more level
				for (i in 1:length(obj)) {
					if (trace) { IM(depth.now, names(obj)[i]) }
					result <- recurse(obj[[i]], depth.now, max.depth)
					this$elems[[i]] <- result[[1]]					# Returned subdata
					env.size <- env.size + result[[2]]				# Returned env.size
					if (result[[3]] > temp.depth) { temp.depth <- result[[3]] }	# Returned depth
				}
			}
		} else {
			m <- mode(obj)
			obj <- vector(mode, length=0)    ### WILL NOT WORK LIKE THIS
		}
		if (trace) { IM(depth.now,":End") }
		temp.depth <- temp.depth + 1	# account for 'this' itself (thus min depth always = 1)
		this$basic$this.depth <- depth.now
		this$basic$depth <- temp.depth
		this$basic$env.size <- env.size
		return ( list(this, env.size, temp.depth) )
	}
	
	emptied <- recurse(lst)
	return(emptied)
}


apa.names$general <- c(apa.names$general, "get.killcurve.cdf")
get.killcurve.cdf <- function(fg.p, bg.p, N=1000) {
	
	## for use in 'motif.killcurve', 'peak.killcurve'
	## 'N' specifies the sampling for the p-value CDF (N bins to break p-value range into)
	
	F <- length(fg.p)
	B <- length(bg.p)
	p.bins <- seq(min(c(fg.p,bg.p)), max(c(fg.p,bg.p)), length=N)
	p.cdf <- matrix(0, 3, N, F, list(qw(P.VALUE,FG.RATE,BG.RATE),1:N))
	for (i in 1:N) p.cdf[,i] <- c( p.bins[i], sum(fg.p >= p.bins[i]), sum(bg.p >= p.bins[i]) )
	axseq <- seq(p.bins[1], p.bins[N], length=10)
	list(cdf=p.cdf, axis.lab=format(axseq,digits=3), axis.seq=rescale(axseq,to=c(1,N)))
}


apa.names$general <- c(apa.names$general, "motif.killcurve")
motif.killcurve <- function(fg.p, bg.p, N=1000) {
	
	## Compares foreground vs background CDFs and finds crossover point, if any
	## Designed to compute a kill-curve-based p-value for PWM matches, given vectors of foreground and background p-values
	## Also for finding critical dropoffs with chipseq IP/inp-vs-inp/IP peak calls
	## 'N' specifies the sampling for the p-value CDF (N bins to break p-value range into)
	
	cdf <- get.killcurve.cdf(fg.p, bg.p, N)
	comp <- cdf$cdf[2,] > cdf$cdf[3,]
	pass <- FALSE
	
	if (sum(comp)==N) {  # FG hit rate exceeds BG hit rate (or vice versa) over whole range; min value is sufficient
		pass <- TRUE
		thresh <- cdf$cdf[1,1]
	} else if (sum(comp)>0) {
		x <- diff(comp)
		inits <- which(x==1)+1
		for (i in inits) {
			if (sum(comp[i:N])/(N-i+1) > 0.5) {  # FG exceeds BG (or vice versa) for over half the range?
				pass <- TRUE
				thresh <- cdf$cdf[1,i]
				break  # stop if true
			}
		}
	}
	if (pass) {
		pass.fg <- sum(fg.p<=thresh)
		pass.bg <- sum(bg.p<=thresh)
		passing <- c(FG=pass.fg, FG.PCT=pass.fg/length(fg.p), BG=pass.bg, BG.PCT=pass.bg/length(bg.p))
	} else {
		thresh <- NA   # only passing motifs return a p-value threshold 
		passing <- c(FG=NA, FG.PCT=NA, BG=NA, BG.PCT=NA)
	}
	
	c(cdf, list(threshold=thresh, abline=rescale(thresh,from=range(as.numeric(cdf$axis.lab)),to=c(1,N)), passing=passing))
}


apa.names$general <- c(apa.names$general, "peak.killcurve")
peak.killcurve <- function(fg, bg, N=1000, fdr=0) {
	
	## Compares foreground vs background CDFs and finds crossover point, if any
	## Designed to compute kill-curve-based thresholds for peak statistics, given vectors of foreground and background statistics.
	## Also for finding critical dropoffs with chipseq IP/inp-vs-inp/IP peak calls
	## 'N' specifies the sampling for the p-value CDF (N bins to break p-value range into)
	## 'fdr' indicates the "false-discovery rate" threshold, as defined by setting the threshold such that fdr% of background peaks are above it.
	
	cdf <- get.killcurve.cdf(fg, bg, N)
	thresh <- quantile(bg, 1-fdr, na.rm=TRUE)
	pass.fg <- sum(fg>thresh)
	pass.bg <- sum(bg>thresh)
	passing <- c(FG=pass.fg, FG.PCT=pass.fg/length(fg), BG=pass.bg, BG.PCT=pass.bg/length(bg) )
	
	c(cdf, list(threshold=thresh, abline=rescale(thresh,from=range(as.numeric(cdf$axis.lab)),to=c(1,N)), passing=passing))
}


apa.names$plots <- c(apa.names$plots, c("heat.map","heat.map.F"))
heat.map <- heat.map.F <- function( mat, Rowv=NULL, Colv=NULL, c.dend=FALSE, r.dend=FALSE, aspect=NULL, dimensions=NULL, dendro.pix=c(150,150), label.pix=c(NA,NA), scale.pix=100, title.pix=40, 
                                   palette=NULL, rev.pal=FALSE, col.limits=NULL, quant.cols=FALSE, max.cols=256, max.qres=1E6, NA.col=8, col.center=NULL, grid.col=0, grid.lty=1, xlabs=TRUE, ylabs=TRUE, 
                                   metric="euclidean", linkage="average", scale.horiz=FALSE, scale.div=10, scale.term=FALSE, las=2, cex=1.5, family="mono", main=NULL, imgname=NULL, antialias=TRUE, 
                                   att.cols=NULL, att.rows=NULL, att.palette=NULL, row.optimize=NULL, col.optimize=NULL, device=c("png","pdf"), ppi=100, interpolate=NULL, verbose=FALSE, row.names=TRUE, 
                                   col.names=TRUE, label.text=NULL, label.col=NULL, label.cex=NULL, show.scale=TRUE, xaxt=NULL, yaxt=NULL ) {
    
## myImagePlotUltra args: function(x, pmar=c(5,5), x.aspect=c(4,1), rnames=NULL, cnames=NULL, palette="KBY", scale.div=10, rev.pal=FALSE, 
##                                     att.cols=NULL, att.rows=NULL, att.palette=NULL, col.limits=NULL, col.center=NULL, quant.cols=FALSE, max.cols=256, max.qres=1E6, NA.col=8, 
##                                     grid=0, mask=NULL, mask.ramp=NULL, interpolate=NULL, main=NULL, title=NULL, las=2, cex=1, cex.axis=1, axes=TRUE, unlog.scale=NA,
##                                     label.text=NULL, label.col=NULL, label.cex=NULL, show.scale=TRUE, ...) {
    
################ MUST ADD: auto png, with "size" factor to allow expansion, but img dim controlled by aspect calculations (thus png'd by the function) to make sure there are no surprises.
################ -- I thought this was added long ago?
    
    ## Fusion of R base heatmap() with Chris Seidel's myImagePlot() and MEV's color scale/limit control,
    ##    plus custom palettes, portable x:y aspect control, and other improvements.
    ##
    ## "mat": a matrix or dataframe to cluster
    ## "Rowv=TRUE" = row reordering; FALSE = none; NULL = decide based on "r.rend" value.
    ## "Rowv=<hclust object>" allows a predefined clustering to be used
    ## "Colv" works the same way for columns.
    ## "r.dend=TRUE" plots row dendrogram (only if reordering is used)
    ## "c.dend=TRUE" plots column dendrogram (only if reordering is used)
    ## 'aspect' and 'dimensions': see next section, "TWO WAYS TO CONTROL HEATMAP DIMENSION"
    ## "pmar": length-2 vector specifying x and y margin sizes (mainly so your row/columns labels are fully visible)
    ## 	  pmar values only affect the axes along which labels are printed, not the other axes
    ##    pmar x value is calculated as pmar[1] * row height; pmar y value is calculated as pmar[2] * col width; 
    ## "dendro.pix" indicate pixels to use for the dendrogram areas.  Given as c(x.dendro.dim, y.dendro.dim).
    ##    Thus, x.dendro.dim sets the height for col dendro and y.dendro.dim sets width for row dendro, since the other dims of each dendro area are pegged to the heatmap.
    ## "label.pix" works the same as dendro.pix, but for labels.  If any entry is NA, will autodetect proper size to fit respective labels (ONLY WORKS WHEN family="mono" !!!).
    ## "title.pix" and "scale.pix" similarly indicate, in pixels, title height and color-scale width (if vertical scale, or height if horizontal).
    ## "palette" indicates a palette name.  See list inside palettizer() or use an RColorBrewer palette name; NULL=Autodetect.
    ##    Autodetect based on data range: [0,Inf] = "Reds"; [-Inf,0] = rev("Greens"); [-Inf,Inf] = Cyan-Black-Yellow.
    ## "rev.pal" reverse palette?
    ## "col.limits": MeV-style, sets saturation limits for the color gradient.
    ## "col.center=x": NOT READY YET.  When complete it will force divergent palettes to center at 'x'.
    ## "grid.col": if not zero, will plot gridlines between cells in this color.  "grid.lty" controls gridline lty.
    ## "xlabs", "ylabs": print rows/column labels?
    ## "metric": if heat.map reorders rows/columns, what metric should dist() use? (use same names)
    ## "linkage": if heat.map reorders rows/columns, what linkage should hclust() use? (use same names)
    ## las, par, cex, family, main: as usual
    ## "device": if printing to file, specify png (default) or pdf.  IF PDF: be aways of 'ppi' value = "pixels per inch", which converts png dimensions to pdf page dimensions
    ## 
    ## TWO WAYS TO CONTROL HEATMAP DIMENSION:
    ## 1. Using 'aspect', which controls cell aspect and pixels-per-aspect.
    ##    a. aspect=c(x,y,ppa) sets the cellwise aspect ratio (x,y) and the pixels per aspect for plotting (ppa).
    ##    b. aspect ratio is a ratio, and will be normalized such that min(x,y) == 1.  For instance x=3, y=2 will become x=1.5, y=1.
    ##    c. (normalized cell aspects) * (pixels per aspect) specifies cell dimensions.
    ##    d. (cell dimensions) * (heatmap nrow, ncol) specifies final heatmap dimensions.
    ##    e. heatmap dimensions + label pix, dendro pix, scale.pix, determine final image dimensions.
    ## 2. Using 'dimension', which specifies height and width of the heatmap block directly.
    ##    a. dimensions=c(x,y) specified pixels to allot to heatmap width, height, respectively.
    ## 3. Both 'aspect' and 'dimensions' cannot be used at the same time.
    
    
    mat <- as.matrix(mat)  # ensure matrix 
    if (length(main)==0) main <- "Heat Map"
    device <- match.arg(device)
    cex.adj <- ifelse(device=="pdf", 0.7, 1)
    if (length(xaxt)==0) xaxt <- ""
    if (length(yaxt)==0) yaxt <- ""
    if (!(las %in% 1:2)) stop("'las' value may only be 1 (horizontal) or 2 (perpendicular)!\n")   # enforcing only las=1 (all labels horizontal) or las=2 (labels perpendicular to axis)
    
    cor.metrics <- c("pearson","spearman","kendall")
    dist.metrics <- c("euclidean","maximum","manhattan","canberra","binary","minkowski")
    if (metric %in% dist.metrics) {
        dist.fun <- dist
    } else if (metric %in% cor.metrics) {
        dist.fun <- distance
    } else {
        stop(paste("Unknown distance metric '",metric,"'!  Please use a metric from dist() or cor()\n",sep=""))
    }
    
    ## dendro plot consistency check
    if (is.null(Rowv)) Rowv <- ifelse(r.dend, TRUE, FALSE)	# dendrogram requires a reordering
    if (is.null(Colv)) Colv <- ifelse(c.dend, TRUE, FALSE)	# dendrogram requires a reordering
    mmin <- min(real(mat))
    mmax <- max(real(mat))
    
    ## names etc
    if (length(rownames(mat))==0) rownames(mat) <- 1:nrow(mat)
    if (length(colnames(mat))==0) colnames(mat) <- 1:ncol(mat)
    NR <- nrow(mat)
    NC <- ncol(mat)
    
    ## Testing data
#	aspect <- c(1,1); dendro.pix <- c(150,150); label.pix <- c(50,50); scale.pix <- 100; title.pix <- 40; ppa <- 20
#	mat <- structure(matrix(unlist(randu)[1:900], nrow=45, ncol=20), dimnames=list(paste("R",1:45,sep=""),paste("C",1:20,sep=""))); main <- "title"
    
    if (length(aspect)>0 & length(dimensions)>0) {
        stop("Can only specify one of 'aspect' or 'dimensions', not both!\n")
    } else if (length(aspect)>0) {
        ## aspect-driven dimensions
        ppa <- aspect[3]
        aspect <- aspect[1:2] / min(aspect[1:2])	# convert to c(1,x) or c(x,1); as long as the smallest value is 1 and the other is proportional
        x.px.hm <- NC * aspect[1] * ppa		# heatmap width in pixels
        y.px.hm <- NR * aspect[2] * ppa		# heatmap height in pixels
    } else if (length(dimensions)>0) {
        ## dimension-driven aspect ratio
        x.px.hm <- dimensions[1]			# heatmap width in pixels
        y.px.hm <- dimensions[2]			# heatmap height in pixels
        ppa <- min(dimensions/c(NC,NR))		# minimum-ppa estimate
    } else {
        stop("Must specify either 'aspect' or 'dimensions'!\n")
    }
    
    if (length(dendro.pix)==0) { 
        stop("'dendro.pix' must be specified!\n")
    } else if (length(dendro.pix)==1) { 
        dendro.pix <- c(dendro.pix,dendro.pix) 
    }
    
    if (length(label.pix)==0) { 
        stop("'label.pix' must be specified, even if NA!\n")
    } else if (length(label.pix)==1) { 
        label.pix <- c(label.pix,label.pix) 
    }
    if (xaxt=="n") label.pix[1] <- 1
    if (yaxt=="n") label.pix[2] <- 1
    
    tick.len <- max(c(ppa/2,5))  # axis tick length in pixels: half of ppa, or 5, whichever is larger
    
    if (is.na(label.pix[1])) {
        ## autodetect pixel width of COLUMN labels (works for most PNG plots, anyway)
        if (las == 2) {   # perpendicular x labels
            label.pix[1] <- tick.len*2 + calculate.mono.width(colnames(mat))  # tick.len*2 is the distance between the labels and the axis
        } else {          # horizontal x labels
            label.pix[1] <- 50   # get default 50 pixels
        }
    }
    if (is.na(label.pix[2])) {
        ## autodetect pixel width of ROW labels (works for most PNG plots, anyway)
        label.pix[2] <- tick.len*2 + calculate.mono.width(rownames(mat))  # tick.len*2 is the distance between the labels and the axis
    }
    
    null.mar <- c(0,0,0,0)
    y.dendro.mar <- c(0,1,0,0.35)
    x.dendro.mar <- c(0.35,0,1,0)
    x.px.den <- dendro.pix[2]	# number of x pixels added for *** Y (ROW) DENDROGRAM *** width
    y.px.den <- dendro.pix[1]	# number of y pixels added for *** X (COL) DENDROGRAM *** height
    x.px.lab <- ifelse(ylabs, max(c(label.pix[2],1)), 10)	# number of x pixels added for *** Y (ROW) AXIS LABELS *** width; minimum 1
    y.px.lab <- ifelse(xlabs, max(c(label.pix[1],1)), 10)	# number of y pixels added for *** X (COL) AXIS LABELS *** height; minimum 1
    px.scale <- ifelse(is.na(scale.pix), 100, scale.pix)		# number of x or y pixels added for color scale (depending on scale direction)
    y.px.title <- ifelse(is.null(main), title.pix, title.pix * length(unlist(strsplit(main,"\n"))))		# allowing for multi-line titles
    scale.margins <- c(0,2,0,5)
    if (device=="pdf") scale.margins[2] <- 1
    
    ## The 8 possible layout matrices:
    ## Where numeric values stand indicate: 1=title, 2=heatmap, 3=xlabs, 4=ylabs, 5=scale, 6/7=row.dend and/or col.dend
    
    ## No.1: no dendros, vertical scale
    if (!c.dend & !r.dend & !scale.horiz) {
        layout.mat <- matrix(c(1,4,0,1,2,3,1,5,0), nrow=3, ncol=3)
        map.axes <- c(1,2)
        heights.vec <- c(y.px.title, y.px.hm, y.px.lab)
        widths.vec <- c(x.px.lab, x.px.hm, px.scale)
        if (verbose) IM("Map 1")
    }
    ## No.2: no dendros, horizontal scale
    if (!c.dend & !r.dend & scale.horiz) {
        layout.mat <- matrix(c(1,4,0,0,1,2,3,5), nrow=4, ncol=2)
        map.axes <- c(1,2)
        heights.vec <- c(y.px.title, y.px.hm, y.px.lab, px.scale)
        widths.vec <- c(x.px.lab, x.px.hm)
        if (verbose) IM("Map 2")
    }
    ## No.3: col dendro only, vertical scale
    if (c.dend & !r.dend & !scale.horiz) {
        layout.mat <- matrix(c(1,0,4,0,1,6,2,3,1,0,5,0), nrow=4, ncol=3)
        map.axes <- c(1,2)
        heights.vec <- c(y.px.title, y.px.den, y.px.hm, y.px.lab)
        widths.vec <- c(x.px.lab, x.px.hm, px.scale)
        if (verbose) IM("Map 3")
    }
    ## No.4: col dendro only, horizontal scale
    if (c.dend & !r.dend & scale.horiz) {
        layout.mat <- matrix(c(1,6,2,3,5,1,0,4,0,0), nrow=5, ncol=2)
        map.axes <- c(1,2)
        heights.vec <- c(y.px.title, y.px.den, y.px.hm, y.px.lab, px.scale)
        widths.vec <- c(x.px.hm, x.px.lab)
        if (verbose) IM("Map 4")
    }
    ## No.5: row dendro only, vertical scale
    if (!c.dend & r.dend & !scale.horiz) {
        layout.mat <- matrix(c(1,6,0,1,2,3,1,4,0,1,5,0), nrow=3, ncol=4)
        map.axes <- c(1,4)
        heights.vec <- c(y.px.title, y.px.hm, y.px.lab)
        widths.vec <- c(x.px.den, x.px.hm, x.px.lab, px.scale)
        if (verbose) IM("Map 5")
    }
    ## No.6: row dendro only, horizontal scale
    if (!c.dend & r.dend & scale.horiz) {
        layout.mat <- matrix(c(1,6,0,0,1,2,3,5,1,4,0,0), nrow=4, ncol=3)
        map.axes <- c(1,4)
        heights.vec <- c(y.px.title, y.px.hm, y.px.lab, px.scale)
        widths.vec <- c(x.px.den, x.px.hm, x.px.lab)
        if (verbose) IM("Map 6")
    }
    ## No.7: both dendros, vertical scale
    if (c.dend & r.dend & !scale.horiz) {
        layout.mat <- matrix(c(1,0,6,0,1,7,2,3,1,0,4,0,1,0,5,0), nrow=4, ncol=4)
        map.axes <- c(1,4)
        heights.vec <- c(y.px.title, y.px.den, y.px.hm, y.px.lab)
        widths.vec <- c(x.px.den, x.px.hm, x.px.lab, px.scale)
        if (verbose) IM("Map 7")
    }
    ## No.8: both dendros, horizontal scale
    if (c.dend & r.dend & scale.horiz) {
        layout.mat <- matrix(c(1,0,6,0,0,1,7,2,3,5,1,0,4,0,0), nrow=5, ncol=3)
        map.axes <- c(1,4)
        heights.vec <- c(y.px.title, y.px.den, y.px.hm, y.px.lab, px.scale)
        widths.vec <- c(x.px.den, x.px.hm, x.px.lab)
        if (verbose) IM("Map 8")
    }
    
    ## Arrange row order
    if (is(Rowv, "hclust")) {
        hc.y <- Rowv
        Rowv <- TRUE
        dg.y <- as.dendrogram(hc.y)
        dg.lab <- dendrogram.labels(dg.y)
        row.ord <- hc.y$order <- match(dg.lab,rownames(mat))
    } else if (Rowv == TRUE) {
        if (verbose) IM("Clustering rows...\n")
        hc.y <- hclust(dist.fun(zerofy(mat), method=metric), method=linkage)
        dg.y <- as.dendrogram(hc.y)
        dg.lab <- raw.ord <- dendrogram.labels(dg.y)
        row.ord <- match(raw.ord,rownames(mat))
    } else {
        row.ord <- nrow(mat):1
    }
    if (length(row.optimize)>0) {
        opt.mode <- row.optimize[[1]]
        if (opt.mode == "KM") {
            row.ord <- km.hc.order(cutree(hc.y,k=row.optimize$k),mat,hc.y,reord=row.optimize$reord,reverse=row.optimize$reverse) # row.optimize should have at least: k, reord, reverse
        } else if (opt.mode == "HC") {
            ## INOPERABLE UNTIL DENDROGRAM REORDERING METHODS IN PLACE
#			row.ord <- reorder.hclust2(hc.y,mat,row.optimize$method)$order # row.optimize should have at least: method
        }
    }
    
    ## Arrange column order
    if (is(Colv, "hclust")) {
        hc.x <- Colv
        Colv <- TRUE
        dg.x <- as.dendrogram(hc.x)
        dg.lab <- dendrogram.labels(dg.x)
        col.ord <- hc.x$order <- match(dg.lab,colnames(mat))
    } else if (Colv) {
        if (verbose) IM("Clustering columns...\n")
        hc.x <- hclust(dist.fun(t(zerofy(mat)), method=metric), method=linkage)
        dg.x <- as.dendrogram(hc.x)
        dg.lab <- raw.ord <- dendrogram.labels(dg.x)
        col.ord <- match(raw.ord,colnames(mat))
    } else {
        col.ord <- 1:ncol(mat)
    }
    if (length(col.optimize)>0) {
        opt.mode <- col.optimize[[1]]
        if (opt.mode == "KM") {
            col.ord <- km.hc.order(cutree(hc.y,k=col.optimize$k),mat,reord=col.optimize$reord) # col.optimize should have at least: k, reord
        } else if (opt.mode == "HC") {
            message("Optimization mode 'HC' not yet available!")
            ## INOPERABLE UNTIL DENDROGRAM REORDERING METHODS IN PLACE
#			col.ord <- reorder.hclust2(hc.x,mat,col.optimize$method)$order # col.optimize should have at least: method
        }
    }

    ## check palette name, cluster metric, etc.
    if (length(palette)==0) {
        mr <- range(mat, na.rm=TRUE)
        if (mr[2] <= 0) {
            ## all negative
            palette <- "Greens"
            rev.pal <- TRUE
        } else if (mr[1] >= 0) {
            ## all positive
            palette <- "Reds"
            rev.pal <- FALSE
        } else {
            ## divergent, apparently
            palette <- "CKY"
            rev.pal <- FALSE
        }
    }
    
    scale.tick <- TRUE
    scale.col <- 1
    pm <- palette.mapping(mat, palette, rev.pal, col.limits, col.center, quant.cols, max.cols, max.qres, interpolate)	
    matrix.colors <- pm[[1]]
    scale.colors <- pm[[2]]
    scale.values <- pm[[3]]
    data.range <- pm[[4]]
    scale.range <- pm[[5]]
    
    if (device == "png") {
        antialias <- ifelse(antialias, "default", "none")
        pngtype <- ifelse(.Platform$OS.type == "windows", "windows", "quartz")
#		IM("H=",heights.vec)
#		IM("W=",widths.vec)
#		IM("H=",sum(heights.vec), ", W=",sum(widths.vec))
        if (!is.null(imgname)) png(imgname, height=sum(heights.vec), width=sum(widths.vec), type=pngtype)
    } else if (device == "pdf") {
#		IM("PDF with: ", sum(heights.vec)/ppi, sum(widths.vec)/ppi)
        if (!is.null(imgname)) pdf(imgname, height=sum(heights.vec)/ppi, width=sum(widths.vec)/ppi)
    }
    nf <- layout(layout.mat, heights=heights.vec, widths=widths.vec, respect=TRUE)
#	layout.show(nf)
	
    
    ### PLOT TITLE FIRST
    par(mar=null.mar, xaxs="i", yaxs="i")
    plot(1, 1, type="n", ann=FALSE, axes=FALSE)
    text(1, 1, labels=main, cex=1.5*cex*cex.adj, font=2)

    
    ### PLOT HEATMAP SECOND
    par(mar=null.mar, xaxs="i", yaxs="i")
    if (c.dend) {
#		plot.title <- ""
        cex.main <- 1	# not that it matters
    } else {
# 		plot.title <- ifelse (is.null(title), "Heatmap", title)
        cex.main <- ifelse (r.dend, 2, 1)
    }
#	image(t(mat[row.ord, col.ord]), col=colors2, xlab="", ylab="", axes=FALSE, main=plot.title, cex.main=cex.main)	
    
    imat <- 
        if (nrow(mat)>1) {
            t(mat[row.ord, col.ord, drop=FALSE])
        } else {
            t(mat[, col.ord, drop=FALSE])
        }
    
    if (any(is.na(imat))) {
        ## plot NA "background" first
        NA.mat <- imat
        NA.mat[!is.na(NA.mat)] <- 0
        NA.mat[is.na(NA.mat)] <- 1
        NA.mat[NA.mat==0] <- NA
        image(NA.mat, col=NA.col, xlab="", ylab="", axes=FALSE, main="")	
        add <- TRUE
    } else {
        add <- FALSE
    }
    # if (length(att.cols)+length(att.rows)>0) {   # attribute rows/cols were specified
		# core <- x   # initially
		# att.mat <- matrix(NA, NR, NC)
		# if (length(att.cols)>0) {
			# att.mat[,att.cols] <- x[,att.cols,drop=FALSE]
			# core[,att.cols] <- NA
		# }
		# if (length(att.rows)>0) {
			# att.mat[att.rows,] <- x[att.rows,,drop=FALSE]
			# core[att.rows,] <- NA
		# }
		# if (length(dim(core))==0) {  # no longer a matrix?
			# core <- t(as.matrix(core))
		# }
		# c.min <- min(core, na.rm=TRUE)
		# c.max <- max(core, na.rm=TRUE)
        # if (length(att.palette)==0) att.palette <- palette
        # att.levels <- length(sort(unique(c(att.mat)),na.last=NA))
        # if (att.levels==length(att.palette)) {
            # att.colors <- att.palette
        # } else {
            # att.colors <- palettizer(att.palette, n=att.levels, NULL, NULL, rev.pal)
        # }
        # image(1:NC, 1:NR, t(att.mat[NR:1,,drop=FALSE]), col=att.colors, xlab="", ylab="", axes=FALSE, add=add, main=title)	
        # add <- TRUE
    # }
    image(imat, col=matrix.colors, xlab="", ylab="", axes=FALSE, main="", add=add, cex.main=cex.main*cex.adj)	
	
    # plot gridlines
    if (grid.col != 0) {  # zero being the "invisible" color, so don't bother plotting...
        xSeq <- c(0, cumsum(rep(1/(ncol(mat)-1), ncol(mat))) )
        xGap <- xSeq[2]-xSeq[1]
        ySeq <- c(0, cumsum(rep(1/(nrow(mat)-1), nrow(mat))) )
        yGap <- ySeq[2]-ySeq[1]
        abline(v=xSeq-xGap/2, lty=grid.lty, col=grid.col)
        abline(h=ySeq-yGap/2, lty=grid.lty, col=grid.col)
    }
    
    ### PLOT X LABELS THIRD (if at all)
    if (xaxt=="n") {
	null.plot()
    } else {
	par(mar=null.mar, xaxs="i", yaxs="i")
	xmax <- x.px.hm
	ymax <- y.px.lab
	null.plot(xlim=c(0,xmax), ylim=c(0,ymax))
	if (col.names) {
            pre.x <- seq(0,xmax,length.out=NC+1)
            half <- (pre.x[2]-pre.x[1])/2
            x <- pre.x[1:NC]+half
            if (map.axes[1]==1) {  # bottom labels
                y <- ymax; y2 <- ymax-tick.len; y3 <- ymax-2*tick.len
            } else {  # top labels
                y <- 0; y2 <- tick.len; y3 <- 2*tick.len
            }
            if (xlabs) {
                segments(x[1],y, x[NC],y)   # x axis line
                for (i in 1:NC) segments(x[i],y, x[i],y2)  # ticks
#			if (las==0) {		 # parallel to axis (horizontal)
#				srt <- 0
#				adj <- ternary(map.axes[1]==1, c(0.5,0), c(0.5,1))
#			} else 
                if (las==1) { # horizontal
                    srt <- 0
                    adj <- ternary(map.axes[1]==1, c(0.5,1), c(0.5,0))
                } else if (las==2) { # perpendicular to axis (vertical)
                    srt <- 90
                    adj <- ternary(map.axes[1]==1, c(1,0.5), c(0,0.5))
#			} else if (las==3) { # vertical
#				srt <- 90
#				adj <- ternary(map.axes[1]==1, c(0.5,0), c(0.5,1))
                }
                text(x, rep(y3,length(x)), colnames(mat)[col.ord], srt=srt, adj=adj, cex=cex*cex.adj, family=family)
            }
	}
    }
    
    ### PLOT Y LABELS FOURTH (if at all)
    if (yaxt=="n") {
	null.plot()
    } else {
	par(mar=null.mar, xaxs="i", yaxs="i")
	xmax <- x.px.lab
	ymax <- y.px.hm
	null.plot(xlim=c(0,xmax), ylim=c(0,ymax))
	if (row.names) {
            if (map.axes[2]==2) {  # left-side labels
                x <- xmax; x2 <- xmax-tick.len; x3 <- xmax-2*tick.len
            } else {  # right-side labels
                x <- 0; x2 <- tick.len; x3 <- 2*tick.len
            }
            pre.y <- seq(0,ymax,length.out=NR+1)
            half <- (pre.y[2]-pre.y[1])/2
            y <- pre.y[1:NR]+half
            if (ylabs) {
                segments(x,y[1], x,y[NR])   # y axis line
                for (i in 1:NR) segments(x,y[i], x2,y[i])  # ticks
#			if (las==0) {		 # parallel to axis (vertical)
#				srt <- 90
#				adj <- ternary(map.axes[2]==2, c(1,0.3), c(0,0.3))
#			} else 
                if (las==1) { # horizontal
                    srt <- 0
                    adj <- ternary(map.axes[2]==2, c(1,0.3), c(0,0.3))
                } else if (las==2) { # perpendicular to axis (horizontal)
                    srt <- 0
                    adj <- ternary(map.axes[2]==2, c(1,0.3), c(0,0.3))
#			} else if (las==3) { # vertical
#				srt <- 90
#				adj <- ternary(map.axes[2]==2, c(1,0.3), c(0,0.3))
                }
                text(rep(x3,length(y)), y, rownames(mat)[row.ord], srt=srt, adj=adj, cex=cex*cex.adj, family=family)
            }
	}
    }
    
    ### PLOT COLOR SCALE FIFTH
    nticks <- scale.div+1
    color.levels <- scale.values
    prelabels <- seq(scale.range[1], scale.range[2], length.out=nticks)
    labelgap <- abs(prelabels[2] - prelabels[1])
    if (labelgap > 80) {		# width of scale divisions => number of digits to carry on labels
        ndig <- 0
    } else if (labelgap < 20) {
        ndig <- 2
    } else {
        ndig <- 1
    }
    
    if (scale.tick) {		# use this as indicator for skipping color scale flanking
        cseq <- seq(0,1,length.out=nticks)
        gradient <- color.levels
        clab <- round(prelabels,ndig)
    } else {
        cseq <- seq(0,1,length.out=nticks+2)
#		cseq2 <- c(sc.txt.y[1], cseq[2:12], sc.txt.y[2])
        flank <- rep(NA, max.cols*0.06)
        gradient <- c(flank,color.levels,flank)
        clab <- round(c(mmin,prelabels,mmax),ndig)
    }
    
    if (scale.term) {		# plot terminal values only = 2 ticks
        prelabels <- prelabels[c(1,nticks)]
        clab <- clab[c(1,nticks)]
        cseq <- c(0,1)
    }
    
    par(mar=scale.margins, xaxs="i", yaxs="i")
    if (is.na(scale.pix)) {
        par(mar=c(0,0,0,0))
        null.plot()
    } else if (scale.horiz) {
        err <- try(image(matrix(gradient,ncol=1), axes=FALSE, col=scale.colors, xlab="", ylab=""))   # originally had "col=colors", where was 'colors' defined?
        if (!is.null(err)) stop(paste("The 'scale.pix' value of",scale.pix,"was too small to plot color scale.  Please increase.\n"))
        axis(1, at=cseq, labels=clab, col=scale.col, las=las, tick=scale.tick, cex.axis=cex*cex.adj)
        if (!scale.tick) text(c(0,0), sc.txt.y, labels=c("Min","Max"), adj=c(0.5,0.5), cex=cex*cex.adj)
    } else {
        err <- try(image(matrix(gradient,nrow=1), axes=FALSE, col=scale.colors, xlab="", ylab=""))   # originally had "col=colors", where was 'colors' defined?
        if (!is.null(err)) stop(paste("The 'scale.pix' value of",scale.pix,"was too small to plot color scale.  Please increase.\n"))
        axis(4, at=cseq, labels=clab, col=scale.col, las=las, tick=scale.tick, cex.axis=cex*cex.adj)
        if (!scale.tick) text(c(0,0), sc.txt.y, labels=c("Min","Max"), adj=c(0.5,0.5), cex=cex*cex.adj)
    }
    
    
    ### PLOT DENDROGRAMS SIXTH (AND SEVENTH)
    if (c.dend && r.dend) {
        par(mar=y.dendro.mar)
        plot(dg.y, leaflab="none", yaxs="i", horiz=TRUE, axes=FALSE)	# Y-axis dendrogram plots FIRST
        par(mar=x.dendro.mar)
        plot(dg.x, leaflab="none", xaxs="i", horiz=FALSE, axes=FALSE)	# X-axis dendrogram plots SECOND
    } else if (c.dend) {
        par(mar=x.dendro.mar)
        plot(dg.x, leaflab="none", xaxs="i", horiz=FALSE, axes=FALSE)
    } else if (r.dend) {
        par(mar=y.dendro.mar)
        plot(dg.y, leaflab="none", yaxs="i", horiz=TRUE, axes=FALSE)
    }
    
    if (!is.null(imgname)) dev.off()
    
    ### Return
    if (Rowv & Colv) {
        invisible(list(hc.x,hc.y))
    } else if (Rowv) {
        invisible(hc.y)
    } else if (Colv) {
        invisible(hc.x)
    } else {
        ## no hc objects to return
    }
}


apa.names$clustering <- c(apa.names$clustering, "reorder.hclust2")
reorder.hclust2 <- function (hc, obj, method, heights=NULL) {
	
    ## Reorders an hclust object based on some row statistic.
    ## probably modified from gclus::reorder.hclust()
    ## 'hc' = hclust object
    ## 'obj' = matrix that was clustered.  It has no NAs, since you couldn't have clustered it if it did.
    ## 'method' IS A FUNCTION, NOT A FUNCTION NAME.  E.g. mean, not "mean".
    ## 'heights' = NULL or length-2 vector giving the height range of target nodes for rearrangement.  This allows one to reorder only at finer or grosser scales; NULL = full reorder.
    ##  - if one end of the interval is open, use 0 or Inf as appropriate.  E.g. can use "height=c(0,10)" or "height=c(5,100)" or "height=c(23,Inf)"
    

    if (!(length(heights) %in% c(0,2))) {
        warn("'heights' must be length 2 or NULL!")
        return()
    }
    if (is.null(heights)) heights <- c(0,Inf)
    
    ##get.metrics <- function(x) method(c(x))/length(c(x))  # NORMALIZE TO LENGTH
    get.metrics <- function(x) method(c(x))
    row.metrics <- apply(obj, 1, method)
    
    n <- nrow(hc$merge)
    clusters <- as.list(1:n)
    for (i in 1:n) {
        j <- hc$merge[i, 1]
        k <- hc$merge[i, 2]
        if (hc$height[i] <= heights[1] | hc$height[i] >= heights[2]) {
            ## out of range -- don't reorder
            if ((j < 0) & (k < 0)) {
                ## two single rows
                clusters[[i]] <- c(-j, -k)
            } else if (j < 0) {
                ## one single row to a cluster
                clusters[[i]] <- c(-j, clusters[[k]])
            } else if (k < 0) {
                ## a cluster to one single row
                clusters[[i]] <- c(clusters[[j]], -k)
            } else {
                ## two clusters
                clusters[[i]] <- c(clusters[[j]], clusters[[k]])
            }
        } else {
            ## in range -- reorder
            if ((j < 0) & (k < 0)) {
                ## comparing two single rows
                clusters[[i]] <- if (row.metrics[-j] > row.metrics[-k]) { c(-j, -k) } else { c(-k, -j) }
            } else if (j < 0) {
                ## comparing one single row to a cluster
                mk <- get.metrics(obj[clusters[[k]],])
                clusters[[i]] <- if (row.metrics[-j] > mk) { c(-j, clusters[[k]]) } else { c(clusters[[k]], -j) }
            } else if (k < 0) {
                ## comparing a cluster to one single row
                mj <- get.metrics(obj[clusters[[j]],])
                clusters[[i]] <- if (mj > row.metrics[-k]) { c(clusters[[j]], -k) } else { c(-k, clusters[[j]]) }
            } else {
                ## comparing two clusters
                mj <- get.metrics(obj[clusters[[j]],])
                mk <- get.metrics(obj[clusters[[k]],])
                clusters[[i]] <- if (mj > mk) { c(clusters[[j]], clusters[[k]]) } else { c(clusters[[k]], clusters[[j]]) }
            }
        }
    }
    hc$order <- clusters[[n]]
    hc
}


apa.names$clustering <- c(apa.names$clustering, "hclust2")
hclust2 <- function(d, method="average", members=NULL, x) {
    
    ## same args as hclust() but with better default linkage
    ## extra arg 'x' is the matrix being clustered (thus 'd' is dist(x,...))
    ## always passes through reorder.hclust2()
    
    reorder.hclust2(hclust(d,method,members), x, mean)
}


apa.names$clustering <- c(apa.names$clustering, "flip.hclust")
flip.hclust <- function(x) {
    
    ## flips an hclust tree upside-down
    x$order <- rev(x$order)
    x$labels <- rev(x$labels)
    x
}


#apa.names$clustering <- c(apa.names$clustering, "flip.dendrogram")
#flip.dendrogram <- function(x) {
#    
#    ## flips an dendrogram tree upside-down
#    ## FAIL: not yet able to recalculate 'midpoint' attributes; leaf order is OK but tree is jacked
#    
#    recurse <- function(y, i) {
#        i <- i + 1
#        if (length(y)==2) {
#           z <- y
#            z[[2]] <- recurse(y[[1]], i)
#            z[[1]] <- recurse(y[[2]], i)
#            z
#        } else {
#            y
#        }
#    }
#    recurse(x, 0)
#}


apa.names$clustering <- c(apa.names$clustering, "partial.reorder.dendrogram")
partial.reorder.dendrogram <- function(x, ord) {
    
    ## 'x' is a dendrogram object
    ## 'ord' is a list of paths through 'x' to nodes which should be reversed (paths are vectors of 1s and 2s).
    
    recurse.and.flip <- function(y, path, xpath, j) {
        y[[ path[1] ]] <- 
            if (length(path)==1) {
                rev( y[[ path[1] ]] )
            } else {
                recurse.and.flip(y[[ path[1] ]], path[2:length(path)], path[1], j+1)
            }
        y
    }
    
    r <- x
    for (i in 1:length(ord)) r <- recurse.and.flip(r, ord[[i]], ord[[i]], 1)
    stats:::midcache.dendrogram(r)
}


apa.names$clustering <- c(apa.names$clustering, "dendrogram.labels")
dendrogram.labels <- function(x) {
    
    ## Returns leaf label order for a dendrogram
    ## Original intended use was to be able to hclust a matrix, convert hclust to dendrogram (which reorders tree), then be able to reorder matrix to match dendrogram
    
    recurse <- function(y, LL) {
        if (is.leaf(y[[1]]) & is.leaf(y[[2]])) {
            LL[[2]][LL[[1]]+1] <- attr(y[[1]],"label")
            LL[[2]][LL[[1]]+2] <- attr(y[[2]],"label")
            LL[[1]] <- LL[[1]]+2
            return( LL )
        } else if (is.leaf(y[[1]])) {
            LL[[2]][LL[[1]]+1] <- attr(y[[1]],"label")
            LL[[1]] <- LL[[1]]+1
            return( recurse(y[[2]], LL) )
        } else if (is.leaf(y[[2]])) {
            stop("Assumptions have broken!!!\n")
        } else {
            LL2 <- recurse(y[[1]], LL)
            return( recurse(y[[2]], LL2) )
        }
    }
    
    LL.final <- recurse(x, list(0, rep("", attr(x,"members"))))
    LL.final[[2]]
}


apa.names$clustering <- c(apa.names$clustering, "get.phylo.ord")
get.phylo.ord <- function(phylo) {
	
    ## returns the leaf order for an object of class "phylo"
	
    ord <- phylo$edge[phylo$edge[, 2] <= length(phylo$tip.label), 2]
    return(ord)
}


apa.names$clustering <- c(apa.names$clustering, "logify.tree")
logify.tree <- function(x, logfun=log2, adjust.zero=FALSE) {
	
    ## log-converts tree heights in objects of class 'hclust' and 'dendrogram'.
	## 'logfun': A FUNCTION, NOT A NAME, e.g. log, log2, log10, or some other log function.
	## 'adjust.zero=TRUE' adds 1 to tree heights, to prevent them from going negative when logged.  This does distort the relative heights a bit.
	##   1. only necessary if any heights < 1.
	##   2. plot.hclust will crash with negative heights, but plot.dendrogram won't.
	##   3. so, if your tree has heights < 1 and 'adjust.zero=FALSE', logify.tree will stop if class is 'hclust', but only warn if class if 'dendrogram'
	
	adjustment <- ifelse(adjust.zero, 1, 0)
	
    if (is(x, "hclust")) {
		
		if (any(x$height < 1) & !adjust.zero) stop("hclust has heights < 1: cannot convert unless 'adjust.zero=TRUE'\n")
		x$height <- logfun(x$height + adjustment)
		
	} else if (is(x, "dendrogram")) {
		
		recurse.and.log <- function(y, i) {
			for (j in 1:2) {
				if (is.leaf(y[[j]])) {
					attr(y[[j]],"height") <- log2( attr(y[[j]],"height") + adjustment )
				} else {
					attr(y[[j]],"height") <- log2( attr(y[[j]],"height") + adjustment )
					y[[j]] <- recurse.and.log(y[[j]], i + 1)
				}
			}
			return(y)
		}
		
		if (!adjust.zero) warning("adjust.zero = FALSE: leaf distances (and maybe some others) will become negative!\n")
		attr(x,"height") <- log2( attr(x,"height") + adjustment )
		x <- recurse.and.log(x, 0)
		
	} else {
		
		stop("'logify.tree' only works with objects of class 'hclust' or 'dendrogram'!\n")
		
	}
	x
}


apa.names$clustering <- c(apa.names$clustering, "km.hc.order")
km.hc.order <- function(map, mat, hc, metric="euclidean", linkage="average", p=NULL, sort.by.k=FALSE, reord=NULL, reverse=FALSE) {
	
	# hclust-reorders rows within each kmeans cluster, for a better-looking kmeans heatmap
	# 'metric' may be any 'method' value for dist() or distance()
	# 'linkage' may be any 'method' value for hclust()
	# 'p' is same as in dist(), if using minkowski distance
	# 'sort' indicates to sort output by cluster number as well (if cluster mapping is numeric)
	# 'reord=method' invokes reorder.hclust2() on each cluster hclust object.  "method" must be a FUNCTION NOT A NAME, a metric to rank rows by, e.g. mean, median, etc.
	
	if (metric %in% qw(euclidean,maximum,manhattan,canberra,binary,minkowski)) {
		distfun <- dist
	} else if (metric %in% qw(pearson,pearson2,spearman,spearman2,kendall,shape,silhouette,mahalanobis,jaccard,venn,edit,tile)) {
		distfun <- distance
	} else {
		stop("No function known for given distance metric!\n")
	}
	
	k <- unique(map[hc$order])
	if (sort.by.k) k <- sort(k)
#	cs <- c(0,cumsum(k))
	reordered <- new.list(k)
	for (i in 1:length(k)) {
		w <- which(map==k[i])
		khc <- hclust(distfun(mat[w,],method=metric), method=linkage)
		if (length(reord)>0) khc <- reorder.hclust2(khc, mat[w,], method=reord)
		reordered[[i]] <- w[khc$order]
		if (reverse) reordered[[i]] <- rev(reordered[[i]])
	}
	nameless(unlist(reordered))
}


apa.names$clustering <- c(apa.names$clustering, "sort.hc.ord")
sort.hc.ord <- function(map, hco) {
    
    ## creates a modified version of hc$order based on cutree() results or something equivalent
    ## basically, new ordering will put clusters 1-N in decreasing order, leaving intra-cluster ordering untouched.
    ## Thus 'map' vector MUST BE NUMERIC.
    ## 'hco' is the 'order' element from an hclust object, e.g. 'x$order'
    
    ord <- new.list(sort(unique(map)))
    map <- map[hco]
    if (mode(map)!="numeric" | !is.nlv(map)) stop("'map' must be a numeric vector!\n")
    for (i in 1:length(ord)) ord[[i]] <- hco[which(map==as.numeric(names(ord)[i]))]
    unlist(ord)
}


apa.names$clustering <- c(apa.names$clustering, "best.tree")
best.tree <- function(x, z=FALSE) {
    
    ## 'x' is a matrix to be clustered (on columns)
    ## tests most distances and all linkages to see which one gives the highest CCC
    ## if 'z=TRUE' also tests 'x' in z-score format
    
    linkages <- c("average","complete","single","median","centroid","ward.D","ward.D2","mcquitty")
    names(linkages) <- linkages
    distances <- c("euclidean","maximum","manhattan","canberra")
    names(distances) <- distances
    distances2 <- c("pearson","spearman")  # NOT KENDALL -- extremely long runtime
    names(distances2) <- distances2
    
    m <- list(x=x)
    if (z) m <- c(m, list(z=t(scale(t(x)))))
    
    dst <- hc <- lapply(m, function(y) {
        c(
            lapply(distances, function(d) dist(t(y),d)),
            lapply(distances2, function(d) distance(t(y),d))
        )
    })
    
    alldist <- c(distances,distances2)
    D <- length(alldist)
    L <- length(linkages)
    M <- length(m)
    N <- D*L*M
    ccc <- data.frame(
        Dataset=rep(names(m),each=N/M),
        Distance=rep(rep(alldist,each=N/D/M),M),
        Linkage=rep(linkages,N/L),
        ccc=rep(0,N)
    )
    rownames(ccc) <- apply(ccc[,1:3],1,paste,collapse=":")
    
    n <- 0
    for (i in 1:M) {
        hc[[i]] <- lapply(dst[[i]], function(d) lapply(linkages, function(L) hclust(d,L) ))
        for (j in 1:length(dst[[i]])) {
            for (k in 1:L) {
                n <- n+1
                ccc[n,4] <- cor(dst[[i]][[j]],cophenetic(hc[[i]][[j]][[k]]))
            }
        }
    }
    
    best <- ccc[which.max(ccc[,4]),4]
    names(best) <- rownames(ccc)[which.max(ccc[,4])]
    message(paste(names(best),"=",best[[1]]))
    
    invisible(list(best=best, matrix=m, dist=dst, hclust=hc, ccc=ccc))
}


apa.names$clustering <- c(apa.names$clustering, "match.clusters")
match.clusters <- function(ref, maps, ref.mat, maps.mat=NULL, plot=FALSE) {
	
	# the basic idea is, I have a hc cutree map (k=6) and a kmeans map (k=6); I want all cluster 1s, 2s, 3s, to have the same trend.
	# re-IDs a list of 1 or more cluster mappings ('maps') to match a reference mapping ('refs').  'maps' can be just one mapping vector, not a list of them.
	# a "mapping" is basically a numeric vector, preferably named, indicating cluster membership for rows in some matrix.
	# "some matrix" is 'ref.mat', and optionally 'maps.mat', if 'maps' maps came from a different matrix.
	# 'ref.mat' and 'maps.mat' must contain ONLY columns used for clustering.
	# clearly, only works if all mappings have the same number of clusters.
	# also, 'maps' clusters must be close enough to reference to have only one best correlating ref clust.
	
	maps.list <- TRUE
	if (!is.list(maps)) {
		maps <- list(maps)
		maps.list <- FALSE  # was not given as a list
	}
	if (length(maps.mat)==0) maps.mat <- ref.mat
	N <- length(maps)
	k <- luniq(ref)
	ref.c <- sapply(mat.split(ref.mat, ref), colMeans)
	maps.c <- lapply(maps, function(x){ sapply(mat.split(maps.mat, x), colMeans) })

	new.maps <- maps
	remap <- matrix(0, N, k)
	mean.corrs <- new.list(1:N)
	
	for (i in 1:N) {
		x <- cor(ref.c, maps.c[[i]])
		corrs <- apply(x, 1, max, na.rm=TRUE)
		doppels <- as.numeric(colnames(x)[apply(x, 1, which.max)])
		ref.ord <- as.numeric(rownames(x))
		if (is.nlv(doppels)) {
			if (luniq(doppels)==k) {
				new.maps[[i]] <- translate(maps[[i]], doppels, ref.ord)
			} else {
				IM("Maps",i,"trends are not 1:1 to reference (1)!\n")
				new.maps[[i]] <- rep(0,length(maps[[i]]))
			}
		} else {
			IM("Maps",i,"trends are not 1:1 to reference (2)!\n")
			new.maps[[i]] <- rep(0,length(maps[[i]]))
		}
		names(new.maps[[i]]) <- names(maps[[i]])
		mean.corrs[[i]] <- mean(corrs)
	}
	
	if (plot) compare.cluster.trends(c(list(ref),new.maps), list(ref.mat,maps.mat))
	
	if (maps.list) {
		return(new.maps)
	} else {
		return(new.maps[[1]])
	}
	invisible(mean.corrs)
}


#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################


apa.names$microarray <- c(apa.names$microarray, "query.microarray.library")
query.microarray.library <- function(arrayID=NULL) {
	
	## Returns contents of "microarray_library.R" as a list
	## arrayID, if specified, will return only the contents for that array (if exists)
	
	path <- switch(Sys.info()[["sysname"]], 
		"Windows"="S:",
		"Linux"="/n",
		"Darwin"="/Volumes",
		NA
		)
	if (is.na(path)) stop(paste("Unknown system type '",Sys.info()[["sysname"]],"'!  Must be Windows, Linux, or Darwin\n",sep=""))
	
	libfile <- file.path(path,"Genomics","Molbio_Users","APA","R_Things","microarray_library","microarray_library.R")
	array.lib <- read.delim(libfile, sep="\t", header=FALSE, fill=TRUE, blank.lines.skip=TRUE, stringsAsFactors=FALSE, comment.char="#")
	brks <- which(array.lib[,1] == ".")	# should only be two
	headcols <- 1:5		# NOTE THAT COLUMNS ARE HARDCODED
	featcols <- 1:5		
	datacols <- 1:6		# EACH SECTION HAS DIFFERENT NCOLS
	ctrlcols <- 1:8		
	parscols <- 1:8		# BE CAREFUL WHEN ADDING NEW DATA TO LIBRARY
	lib <- list(
		head=array.lib[(brks[1]+2):(brks[2]-1),headcols],	
		feat=array.lib[(brks[2]+2):(brks[3]-1),featcols],
		data=array.lib[(brks[3]+2):(brks[4]-1),datacols],
		ctrl=array.lib[(brks[4]+2):(brks[5]-1),ctrlcols],
		pars=array.lib[(brks[5]+2):nrow(array.lib),parscols]
	)
	colnames(lib$head) <- array.lib[(brks[1]+1),headcols]
	colnames(lib$feat) <- array.lib[(brks[2]+1),featcols]
	colnames(lib$data) <- array.lib[(brks[3]+1),datacols]
	colnames(lib$ctrl) <- array.lib[(brks[4]+1),ctrlcols]
	colnames(lib$pars) <- array.lib[(brks[5]+1),parscols]
	
	if (is.null(arrayID)) {
		IDlist <- unique(lib$head[,2])
	} else {
		if (!arrayID %in% lib$head[,2]) { 
			cat("Array ID not found!  Please add it.\nReturning known arrays:\n")
			IM(paste(colnames(lib$head), collapse="\t"))
			for (i in 1:nrow(lib$head)) { IM(paste(lib$head[i,], collapse="\t")) }
			return()
		} else {
			chk <- lib$feat[which(lib$feat[,2] == arrayID),]
			if (length(chk) == 0) { stop("Array exists but no features have been entered!  Please add some to:\nlibfile\n") }
			IDlist <- arrayID
		}
	}
	
	Nids <- length(IDlist)
	data <- warns <- vector("list", length=Nids)
	names(data) <- names(warns) <- IDlist
	for (i in 1:Nids) {
		hrow <- match(IDlist[i], lib$head[,2])
		x <- c(
			which(lib$pars[,3] == lib$head[hrow,3] & lib$pars[,4] == lib$head[hrow,4]),
			which(lib$pars[,3] == "any" & lib$pars[,4] == lib$head[hrow,4]),
			which(lib$pars[,3] == lib$head[hrow,3] & lib$pars[,4] == "any"),
			which(lib$pars[,3] == "any" & lib$pars[,4] == "any")
		      )											# supported features for array type
		allow <- lib$pars[x,2]									# allowed features
		reqd <- lib$pars[x[which(lib$pars[x,5] == 1)],2]					# mandatory features
		y <- which(lib$feat[,2] == IDlist[i])							# arrayID entries in features section
		
		if (length(y) > 0) {
			given <- unique(lib$feat[y,3])							# given features for specific array
			ok1 <- reqd %in% given
			ok2 <- given %in% allow
			
			if (!all(ok1)) {	# required fields missing
				missing <- paste(reqd[!ok1], collapse=", ")
				IM(paste("The following mandatory fields for platform '", lib$head[hrow,3],"' type '", lib$head[hrow,4],"' are not present in the library: ", missing, sep=""))
				warns[[i]] <- c(warns[[i]], 1)	# missing required data flag
			}
			
			if (!all(ok2)) {	# unsupported fields exist
				oddball <- paste(given[!ok2], collapse=", ")
				IM(paste("The following fields are unknown for platform '", lib$head[hrow,3],"' type '", lib$head[hrow,4],"': ", oddball, sep=""))
				warns[[i]] <- c(warns[[i]], 2)	# unsupported data flag
			}
			
			xo <- x[match(lib$feat[y,3], lib$pars[x,2])]
			feats <- as.matrix.data.frame(join.tables(lib$feat[y,3:5], lib$pars[,c(2,6:7)], join=3))		# feat: KEY, VALUE, COMMENTS; pars: DELIMITED, MULTI
			all <- union(given, reqd)
			
			data[[i]] <- vector("list", length=nrow(feats)+1)
			names(data[[i]]) <- c("header", as.character(feats[,1]))
			data[[i]]$header <- lib$head[hrow,]
	#		data[[i]]$QC <- list(x=x, y=y, reqd=reqd, allow=allow, given=given)
			
			for (j in 1:length(all)) {
				z <- which(feats[,1] == all[j])
				if (length(z) > 1) {
					if (feats[z,5] == 1) {	# > 1 entry ok
						data[[i]][[all[j]]] <- vector("list", length=length(z))
						for (k in 1:length(z)) {
							value <- feats[z[k],2]
							data[[i]][[all[j]]][[k]] <- list(value=value, comments=feats[z[k],3])		# add value(s)
						}
					} else {
						IM(paste("Warning: Array ID '",IDlist[i],"' has more than one entry for feature '",feats[j,1],"'!  Using only the first...",sep=""))
						warns[[i]] <- c(warns[[i]], 3)		# improper duplicate data flag
						value <- feats[z[1],2]			# only taking first entry
						data[[i]][[all[j]]] <- list(value=value, comments=feats[z[1],3])		# add value(s)
					}
				} else {
					value <- feats[z,2]			# only taking first entry
					data[[i]][[all[j]]] <- value							# add value(s)
					data[[i]][[all[j]]] <- list(value=value, comments=feats[z,3])			# add value(s)
				}
			}
		} else {
			IM(paste("No features recorded for platform '", lib$head[hrow,3],"' type '", lib$head[hrow,4],"'!  Please add some to:\nlibfile\n",sep=""))
		}
	}
	
	return(data)
}


apa.names$microarray <- c(apa.names$microarray, "YOG.controls")
YOG.controls <- function(ID.vec) {
	
	## Takes RG$genes$ID from a YOG-type array and returns a logical vector indicating the controls
	
	ctls <- list(ALL=c(), ambion=c(), Alien=c(), YBOX=c(), YCONTROL=c(), EMPTY=c())
	for (i in 2:length(ctls)) { ctls[[i]] <- grep(names(ctls)[i], ID.vec) }
	ctls[[1]] <- sort(unlist(ctls)); names(ctls[[1]]) <- NULL	
	return(ctls)
}


apa.names$microarray <- c(apa.names$microarray, "parse.controls")
parse.controls <- function(idents, arrayID) {
	
	## Function to return index sets (and other data) for each control type, incl. spikes if used
	## idents = MA$genes$ID or RG$genes$ID, e.g.
	## arrayID = array ID from library file (= design number, for Agilent arrays)
	
	array.lib <- query.microarray.library(arrayID)
	if (length(array.lib) == 0) { stop("No array with that ID was found!  Please check library or add this array.\n") }
	
	pctrls <- records[which(records[,4] == "pctrls"),5]
	nctrls <- records[which(records[,4] == "nctrls"),5]
	spikes <- records[which(records[,4] == "spikes"),5]
	if (length(pctrls) == 0) { IM("No positive controls have been entered for this array!  Please add some to the library.\n") }
	if (length(nctrls) == 0) { IM("No negative controls have been entered for this array!  Please add some to the library.\n") }
	pnames <- unlist(strsplit(pctrls, ',', fixed=TRUE))
	nnames <- unlist(strsplit(nctrls, ',', fixed=TRUE))
	
	cstyles <- data.frame(
		col <- c("grey50","darkred","forestgreen","purple3","red","chartreuse","orchid","gold"),
		pch <- c( 1,       16,       7,            15,       22,   20,          21,      3    ),
		stringsAsFactors=FALSE
	)	# available control type plot styles
	spCols <- c("navy","blue","cornflowerblue")	# absolute-logratio colors for spikes, from most to least extreme (Agilent Only)
	
	x <- list()
	x$defLine <- array.lib[which(array.lib[,1] == "ARRAYDEF" & array.lib[,2] == arrayID),2:ncol(array.lib)]
	x$nonCtl <- c()		# place here, load later
	
	if (length(pnames)+length(nnames) > 0) {
		x$ctlAtt <- data.frame(
			name=c(nnames,pnames),
			dir=c( rep(-1,length(nnames)), rep(1,length(pnames)) ),
			col=cstyles$col[1:N],
			pch=cstyles$pch[1:N],
			stringsAsFactors=FALSE
		)
		
		N <- length(x$ctlAtt$name)
		x$ctlSets <- vector("list", length=N)
		names(x$ctlSets) <- x$ctlAtt$name
		for (i in 1:N) { x$ctlSets[[i]] <- grep(x$ctlAtt$name[i], idents, fixed=TRUE) }
	}
	x$nonCtl <- setdiff(1:length(idents), unlist(x$ctlSets))
	
	spikeAtt <- data.frame(
		name=paste("(+)E1A_r60",c("a22","3","a97","a104","1","a20","n11","a107","a135","n9"),sep="_"),
		ratio=c(1/10,1/3,1/3,1/3,1,1,3,3,3,10),
		col=c(spCols[1],rep(spCols[2],3),rep(spCols[3],2),rep(spCols[2],3),spCols[1]),
		pch=c(25,25,25,25,5,5,24,24,24,24),
		stringsAsFactors=FALSE
	)
	spikeSets <- vector("list", length=10)
	names(spikeSets) <- spikeAtt$name
	for (i in 1:10) { spikeSets[[i]] <- which(idents == spikeAtt$name[i]) }
	
	if (length(unlist(x$spikeSets)) == 0) {
		IM("No spike controls are known for this array.\n")
	} else {
		x$spikeAtt <- spikeAtt
		x$spikeSets <- spikeSets
		x$spikeLines <- data.frame(
			y=c(10, 3, 1, 1/3, 1/10),
			col=c(spCols[1],spCols[2],spCols[3],spCols[2],spCols[1]),
			stringsAsFactors=FALSE
		)
	}
	
	return(x)	# objects: { defLine nonCtl }, maybe { ctlAtt ctlSets }, maybe also { spikeAtt spikeSets spikeLines }
}


apa.names$microarray <- c(apa.names$microarray, "parse.controls2")
parse.controls2 <- function(idents, arrayID) {
	
	## Function to return index sets (and other data) for each control type, incl. spikes if used
	## idents = MA$genes$ID or RG$genes$ID, e.g.
	## arrayID = array ID from library file (= design number, for Agilent arrays)
	
	array.lib <- read.delim("S:/Genomics/Molbio_Users/APA/R_Things/microarray_library.R", sep="\t", header=TRUE, fill=TRUE, blank.lines.skip=TRUE, stringsAsFactors=FALSE)
	records <- array.lib[which(array.lib[,1] == "FEATURES" & array.lib[,2] == arrayID),]
	if (length(records) == 0) { stop("No array with that ID was found!  Please check library or add this array.\n") }
	
	pctrls <- records[which(records[,4] == "pctrls"),5]
	nctrls <- records[which(records[,4] == "nctrls"),5]
	spikes <- records[which(records[,4] == "spikes"),5]
	if (length(pctrls) == 0) { IM("No positive controls have been entered for this array!  Please add some to the library.\n") }
	if (length(nctrls) == 0) { IM("No negative controls have been entered for this array!  Please add some to the library.\n") }
	pnames <- unlist(strsplit(pctrls, ',', fixed=TRUE))
	nnames <- unlist(strsplit(nctrls, ',', fixed=TRUE))
	
	cstyles <- data.frame(
		col <- c("grey50","darkred","forestgreen","purple3","red","chartreuse","orchid","gold"),
		pch <- c( 1,       16,       7,            15,       22,   20,          21,      3    ),
		stringsAsFactors=FALSE
	)	# available control type plot styles
	spCols <- c("navy","blue","cornflowerblue")	# absolute-logratio colors for spikes, from most to least extreme (Agilent Only)
	
	x <- list()
#	x$defLine <- array.lib[which(array.lib[,1] == "ARRAYDEF" & array.lib[,2] == arrayID),2:ncol(array.lib)]
#	REPLACE WITH: $defline, subelements $ID, $Provider, $Assay, $Name, $Organism, $Genome, $Multislide
#	ALWAYS RETURN A FULL OBJECT WITH NON-NULL ENTRIES (e.g. ""'s or _type_(0)'s)
	
	x$nonCtl <- c()		# place here, load later
	
	if (length(pnames)+length(nnames) > 0) {
		x$ctlAtt <- data.frame(
			name=c(nnames,pnames),
			dir=c( rep(-1,length(nnames)), rep(1,length(pnames)) ),
			col=cstyles$col[1:N],
			pch=cstyles$pch[1:N],
			stringsAsFactors=FALSE
		)
		
		N <- length(x$ctlAtt$name)
		x$ctlSets <- vector("list", length=N)
		names(x$ctlSets) <- x$ctlAtt$name
		for (i in 1:N) { x$ctlSets[[i]] <- grep(x$ctlAtt$name[i], idents, fixed=TRUE) }
	}
	x$allCtl <- unlist(x$ctlSets)
	x$nonCtl <- setdiff(1:length(idents), x$allCtl)
	
	spikeAtt <- data.frame(
		name=paste("(+)E1A_r60",c("a22","3","a97","a104","1","a20","n11","a107","a135","n9"),sep="_"),
		ratio=c(1/10,1/3,1/3,1/3,1,1,3,3,3,10),
		col=c(spCols[1],rep(spCols[2],3),rep(spCols[3],2),rep(spCols[2],3),spCols[1]),
		pch=c(25,25,25,25,5,5,24,24,24,24),
		stringsAsFactors=FALSE
	)
	spikeSets <- vector("list", length=10)
	names(spikeSets) <- spikeAtt$name
	for (i in 1:10) { spikeSets[[i]] <- which(idents == spikeAtt$name[i]) }
	
	if (length(unlist(x$spikeSets)) == 0) {
		IM("No spike controls are known for this array.\n")
	} else {
		x$spikeAtt <- spikeAtt
		x$spikeSets <- spikeSets
		x$spikeLines <- data.frame(
			y=c(10, 3, 1, 1/3, 1/10),
			col=c(spCols[1],spCols[2],spCols[3],spCols[2],spCols[1]),
			stringsAsFactors=FALSE
		)
	}
	
	return(x)	# objects: { arrayDef allCtl nonCtl }, maybe { ctlAtt ctlSets }, maybe also { spikeAtt spikeSets spikeLines }
}


apa.names$microarray <- c(apa.names$microarray, "fc.sets")
fc.sets <- function(x.vec, y.vec, fc.max, slope=1, stdev=FALSE) {
	
	## Groups points from a diagonal scatterplot into absolute-fold-change bands.
	## 'x.vec' and 'y.vec' are the vectors from the scatterplot.
	## 'slope' sets the slope of the diagonal, if for some reason it is not 1 (e.g. MA plot).
    ## 'stdev', if true, uses standard deviations instead of fold-changes
	## 'fc.max' is the maximum fold-change limit to use.  Will be rounded to nearest integer if not an integer.
	##   Fold-changes will be calculated in units of 1 from 0 to fc.max.  Anything beyond fc.max is grouped into the final set.
	##   Both + and - fc groups are pooled together, e.g. all points between 1-2 FC and -1--2 FC are put into one set.
	
	ok <- intersect( which(!is.na(x.vec)), which(!is.na(y.vec)) )
	if (fc.max %% 1 != 0) { fc.max <- round(fc.max, 0) }
	bounds <- 0:fc.max
	lims <- fold.sets <- vector("list", length=length(bounds))
	
	theta <- thetacon(slope, "slope", "radians")	# from apa_functions.R
	scale <- tan(theta) / sin(theta)
	if (is.nan(scale)) { scale <- 1 }
	
	for (i in 1:fc.max) {
		p.o.lim <- sapply(x.vec[ok], FUN=function(x,m,b){ m*x+scale*b }, slope, bounds[(i+1)])
		p.i.lim <- sapply(x.vec[ok], FUN=function(x,m,b){ m*x+scale*b }, slope, bounds[i])
		n.i.lim <- sapply(x.vec[ok], FUN=function(x,m,b){ m*x-scale*b }, slope, bounds[i])
		n.o.lim <- sapply(x.vec[ok], FUN=function(x,m,b){ m*x-scale*b }, slope, bounds[(i+1)])
				
#		lims[[i]] <- cbind(p.o.lim, p.i.lim, n.i.lim, n.o.lim)
		fold.sets[[i]] <- ok[c(
			which(y.vec[ok] >= p.i.lim & y.vec[ok] < p.o.lim), 
			which(y.vec[ok] <= n.i.lim & y.vec[ok] > n.o.lim)
		)]
	}
	fold.sets[[(i+1)]] <- setdiff(ok, unlist(fold.sets))
		
	invisible(fold.sets)
}


apa.names$microarray <- c(apa.names$microarray, "get.saturation")
get.saturation <- function(RG, threshold=NULL, as.pct=FALSE) {
	
	## Gets channel saturation from an RG object and returns a matrix of dimension RG$R,
	##  with entries of "R", "G", "B", or NA indicating spot saturation in R, G, both, or neither.
	## "as.pct=T" replaces NA with 0, "R" and "G" with 0.5, and "B" with 1
	
	if (is.null(threshold)) { threshold <- 65500 }
	
	Rsat <- RG$R > threshold
	Gsat <- RG$G > threshold
	Bsat <- Rsat + Gsat == 2
	
	if (as.pct) {
		mat <- matrix(data=0, nrow=nrow(RG$R), ncol=ncol(RG$R))
		mat[Rsat] <- 0.5
		mat[Gsat] <- 0.5
		mat[Bsat] <- 1
	} else {
		mat <- matrix(data=NA, nrow=nrow(RG$R), ncol=ncol(RG$R))
		mat[Rsat] <- "R"
		mat[Gsat] <- "G"
		mat[Bsat] <- "B"
	}
	return(mat)
}


apa.names$microarray <- c(apa.names$microarray, "decideTests2")
decideTests2 <- function (object, method="separate", adjust.method="BH", p.value=0.05, lfc=0) {
	
	## Hacked version; produces a list with:
	##   element 1 = original output, 
	##   element 2 = adjusted p-value matrix behind the original output
	
	if (!require(limma)) { stop("Cannot load 'limma' package!\n") }
	if (!is(object, "MArrayLM")) { stop("Need MArrayLM object") }
	if (is.null(object$t)) { object <- eBayes(object) }
	method <- match.arg(method, c("separate", "global", "hierarchical", "nestedF"))
	adjust.method <- match.arg(adjust.method, c("none", "bonferroni", "holm", "BH", "fdr", "BY"))
	if (adjust.method == "fdr") 
		adjust.method <- "BH"
	switch(method, separate = {
		p <- as.matrix(object$p.value)
		tstat <- as.matrix(object$t)
		for (j in 1:ncol(p)) {
			o <- !is.na(p[, j])
			p[o, j] <- p.adjust(p[o, j], method = adjust.method)
		}
		val <- p
		sel <- sign(tstat) * (p < p.value)
		results <- list(new("TestResults", sel), val)
	}, global = {
		p <- as.matrix(object$p.value)
		tstat <- as.matrix(object$t)
		o <- !is.na(p)
		p[o] <- p.adjust(p[o], method = adjust.method)
		val <- p
		sel <- sign(tstat) * (p < p.value)
		results <- list(new("TestResults", sel), val)
	}, hierarchical = {
		if (any(is.na(object$F.p.value))) { stop("Can't handle NA p-values yet") }
		val <- p.adjust(object$F.p.value, method = adjust.method)
		sel <- val < p.value
		i <- sum(sel, na.rm = TRUE)
		n <- sum(!is.na(sel))
		a <- switch(adjust.method, none = 1, bonferroni = 1/n, holm = 1/(n - i + 1), BH = i/n, BY = i/n/sum(1/(1:n)))
		results1 <- new("TestResults", array(0, dim(object$t)))
		dimnames(results1) <- dimnames(object$coefficients)
		if (any(sel)) { results1[sel, ] <- classifyTestsP(object[sel, ], p.value = p.value * a, method = adjust.method) }
		results <- list(results1, val)
	}, nestedF = {
		if (any(is.na(object$F.p.value))) { stop("Can't handle NA p-values yet") }
		val <- p.adjust(object$F.p.value, method = adjust.method) 
		sel <- val < p.value
		i <- sum(sel, na.rm = TRUE)
		n <- sum(!is.na(sel))
		a <- switch(adjust.method, none = 1, bonferroni = 1/n, 
			holm = 1/(n - i + 1), BH = i/n, BY = i/n/sum(1/(1:n)))
		results1 <- new("TestResults", array(0, dim(object$t)))
		dimnames(results1) <- dimnames(object$coefficients)
		if (any(sel)) { results1[sel, ] <- classifyTestsF(object[sel, ], p.value = p.value * a) }
		results <- list(results1, val)
	})
	if (lfc > 0) {
		if (is.null(object$coefficients)) { 
			warning("lfc ignored because coefficients not found") 
		} else {
			results[[1]]@.Data <- results[[1]]@.Data * (abs(object$coefficients) > lfc)
		}
	}
	results
}


apa.names$microarray <- c(apa.names$microarray, "fix.YOG.orfnames")
fix.YOG.orfnames <- function(vec) {
	Aliens <- grep("Alien",vec)
	vec[Aliens] <- unlist(sub("_A$","",vec[Aliens]))
	vec <- unlist(sub("_[0-9_]+$","",vec))
	vec <- unlist(sub("([WC][A-Z])[0-9]{1,2}$","\\1",vec))
	vec <- unlist(sub("([WC])([A-Z])$","\\1-\\2",vec))
	return(vec)
}


apa.names$microarray <- c(apa.names$microarray, "subset.MARG")
subset.MARG <- function(obj, rows=NULL, cols=NULL, keep=TRUE) {
	
	## Removes columns and/or rows (given as vectors) from an MA or RG object
	## 'keep=T' indicates specified rows/cols are to be KEPT
	## 'keep=F' indicates specified rows/cols are to be REMOVED
	
	fit <- FALSE
	mdim <- dim(obj[[1]])	# dim of obj$R of obj$M
	
	if (is(obj, "RGList")) {
		mats <- c("R","G","Rb","Gb","weights")
	} else if (is(obj,"MAList")) {
		mats <- c("M","A","weights")
	} else {
		stop("Object must be of class 'RGList' or 'MAList'!\n")
	}
	
	if (!is.null(rows)) {
		ternary (keep, krows <- rows, krows <- c(1:mdim[1])[-rows])	# which rows get kept?
		for (i in mats) { obj[[i]] <- obj[[i]][krows,] }
		ternary ( is.null(dim(obj$genes)), obj$genes <- obj$genes[krows], obj$genes <- obj$genes[krows,] )
	}
	
	if (!is.null(cols)) {
		ternary (keep, kcols <- cols, kcols <- c(1:mdim[1])[-cols])	# which cols get kept?
		for (i in mats) { obj[[i]] <- obj[[i]][,kcols] }
		obj$targets <- as.data.frame(obj$targets[kcols,])	# columns == targets _rows_!
		rownames(obj$targets) <- colnames(obj$weights)
		colnames(obj$targets) <- "FileName"
	}
	
	return(obj)
}


apa.names$microarray <- c(apa.names$microarray, "flatten.MARG")
flatten.MARG <- function(obj, flat, merge="mean", merge.wts="max", na.rm=TRUE, transform=NULL) {
	
	## Produces a gene-flattened MA or RG object
	## Uses aggregate(), by=transform(flat), function=merge / merge.wts
	## '...' are any params passed to 'transform' function, if specified
	
	if (is(obj, "RGList")) {
		mats <- c("R","G","Rb","Gb")
	} else if (is(obj, "MAList")) {
		mats <- c("M","A")
	} else {
		stop("Object must be of class 'RGList' or 'MAList'!\n")
	}
	
	nco <- ncol(obj$weights)
	ternary (is.null(transform), g <- flat, g <- transform(flat))
	flats <- list()
	
	for (n in mats) { 
		flats[[n]] <- as.matrix(aggregate(obj[[n]], by=list(g), FUN=merge, na.rm=na.rm)[,(1:nco+1)]) 
		flats[[n]][is.nan(flats[[n]])] <- NA
	}
	W <- aggregate(obj$weights, by=list(g), FUN=merge.wts, na.rm=na.rm)
	agg <- W[,1]
	
	flats$weights <- W[,(1:nco+1)]
	flats$genes <- agg
	flats$printer <- NULL
	
	for (n in names(flats)) { obj[[n]] <- flats[[n]] }
	return(obj)
}


apa.names$microarray <- c(apa.names$microarray, "merge.MARG")
merge.MARG <- function(obj.list) {
	
	## Merges two or more RG or MA objects into one (e.g. for multislide array sets)
	
	merged <- obj.list[[1]]
	targets <- vector("list", length=length(obj.list))
	ncols <- prints <- sources <- rep("", length(obj.list))
	
	for (i in 1:length(obj.list)) {
		sources[i] <- obj.list[[i]]$source
		prints[i] <- paste(unlist(obj.list[[i]]$printer), collapse=".")
	}
	
	if (length(unique(sources)) > 1) { stop("Cannot merge objects from different sources!\n") }	# really just for data quality reasons -- be consistent!
	
	if (is(merged, "RGList")) {
		
		## RG-specific QC
		if (length(unique(prints)) > 1) { stop("Cannot merge RG objects with different print dimensions!\n") }
		for (i in 1:length(obj.list)) { ncols <- ncol(obj.list[[i]]$R) }
		if (length(unique(ncols)) > 1) { stop("Cannot merge objects with differing numbers of columns!\n") }
		
		## Merge
		for (i in 2:length(obj.list)) {
			merged$R <- rbind(merged$R, obj.list[[i]]$R)
			merged$Rb <- rbind(merged$Rb, obj.list[[i]]$Rb)
			merged$G <- rbind(merged$G, obj.list[[i]]$G)
			merged$Gb <- rbind(merged$Gb, obj.list[[i]]$Gb)
			merged$genes <- rbind(merged$genes, obj.list[[i]]$genes)
			merged$weights <- rbind(merged$weights, obj.list[[i]]$weights)
		}
		
	} else if (is(merged, "MAList")) {
		
		## MA-specific QC
		for (i in 1:length(obj.list)) { ncols <- ncol(obj.list[[i]]$M) }
		if (length(unique(ncols)) > 1) { stop("Cannot merge objects with differing numbers of columns!\n") }
		
		## Merge
		for (i in 2:length(obj.list)) {
			merged$M <- rbind(merged$M, obj.list[[i]]$M)
			merged$A <- rbind(merged$A, obj.list[[i]]$A)
			merged$genes <- rbind(merged$genes, obj.list[[i]]$genes)
			merged$weights <- rbind(merged$weights, obj.list[[i]]$weights)
		}
	} else if (is(merged, "MArrayLM")) {
		stop("'MArrayLM' objects cannot be merged due to the statistics they carry.  Instead, use lmFit() on the merged MA object.\n")
	} else {
		stop("Object must be of class 'RGList' or 'MAList'!\n")
	}
	
	## Update print dimensions
	merged$printer$ngrid.r <- merged$printer$ngrid.r * length(obj.list)
	
	## Merge and flatten targets
	tnames <- merged$targets <- vector("list", length=ncols[1])
	for (i in 1:length(obj.list)) {
		entries <- unlist(obj.list[[i]]$targets)
		rnames <- rownames(obj.list[[i]]$targets)
		for (j in 1:length(entries)) {
			merged$targets[[j]] <- c(merged$targets[[j]], entries[j])
			tnames[[j]] <- c(tnames[[j]], rnames[j])
		}
	}
	for (j in 1:length(merged$targets)) { 
		merged$targets[[j]] <- data.frame(A=unique(merged$targets[[j]]))
		rownames(merged$targets[[j]]) <- unique(tnames[[j]]) 
		colnames(merged$targets[[j]]) <- colnames(obj.list[[1]]$targets)
	}
	
	return(merged)
}


apa.names$microarray <- c(apa.names$microarray, "augment.fit")
augment.fit <- function(fit, input, adjust.method="BH", method="separate", merge.wts="mean", sat.RG=NULL, sat.thresh=NULL) {

	## Use input=NULL for Affy; otherwise specify input

	## augment.fit aways does:
	## Adds per-group A values (matrix, like fit$coefficients) according to embedded design matrix
	## Adds as-is stdevs for coefficients and A values
	## Adds adj.p.values object:
	##  'method' and 'adjust.method' are passed to decideTests2 to generate adjusted p-values

	## If 'input' is an MAList object:
	## Transfers weights from an MA object to a fit object, using the embedded design matrix; also adds adj p values and saturated spot percents.
	## 'merge.wts' specifies how replicate weights are merged into a single value: values can be "mean", "median", "min", "max"

	if (!is(fit, "MArrayLM")) { stop("'fit' must be an object of class 'MArrayLM'!\n") }
	
	method <- match.arg(method, c("separate", "global", "hierarchical", "nestedF"))
	adjust.method <- match.arg(adjust.method, c("bonferroni", "holm", "BH", "fdr", "BY", "none"))
     
    denoms <- rep(0, ncol(fit$design))
	sat.pct <- SD.coefficients <- SD.Ameans <- Ameans <- weights <- fit$coefficients
	
	if (is(input,"MAList")) {
		type <- 1
		merge.wts <- match.arg(merge.wts, c("mean", "median", "min", "max"))
		if (!is.null(sat.RG)) {
			sat.mat <- get.saturation(sat.RG, sat.thresh, as.pct=TRUE) 
			sat.mat <- sat.mat * 2	# convert from % channels affected to # channels affected
			sat.ok <- TRUE
		} else {
			sat.ok <- FALSE
		}
		colnames(weights) <- colnames(fit$coefficients)
	} else if (is(input,"AffyBatch") | is(input,"ExpressionSet")) {
		type <- 2
		input <- exprs(input)
	} else if (is(input,"matrix") | is(input,"data.frame")) {
		type <- 2
		input <- as.matrix(input)
	} else { 
		stop("'input' must be an object of class 'matrix', 'data.frame', 'MAList', 'AffyBatch', or 'ExpressionSet'!\n")
	}
     
	if (!is.null(fit$contrasts)) {
		cont <- TRUE
		design2 <- matrix(0, nrow=nrow(fit$design), ncol=ncol(fit$contrasts))  # cols indicate which inputs to summarize for each contrast
		for (i in 1:ncol(design2)) {
			x <- which(fit$contrasts[,i] != 0)
			design2[,i] <- rowSums(fit$design[,x])
		}
	} else {
		cont <- FALSE
		design2 <- fit$design
	}
     
	for (i in 1:ncol(design2)) {
		denoms[i] <- sum(design2[,i] != 0)
		x <- which(design2[,i] != 0)
		if (type == 1) {
			Ameans[,i] <- apply(input$A[,x], 1, mean, na.rm=TRUE)
			weights[,i] <- apply(input$weights[,x], 1, merge.wts, na.rm=TRUE)
			if (sat.ok) {
				sat.pct[,i] <- apply(sat.mat[,x], 1, sum, na.rm=TRUE)
				sat.pct[,i] <- sat.pct[,i] / denoms[i]
			}
			SD.coefficients[,i] <- apply(input$M[,x], 1, sd, na.rm=TRUE)
			SD.Ameans[,i] <- apply(input$A[,x], 1, sd, na.rm=TRUE)
		} else if (type == 2) {
			Ameans[,i] <- apply(input[,x], 1, mean, na.rm=TRUE)
			SD.coefficients[,i] <- apply(input[,x], 1, sd, na.rm=TRUE)
			SD.Ameans[,i] <- apply(input[,x], 1, sd, na.rm=TRUE)
		}
	}
	fit$adj.p.value <- decideTests2(fit, method=method, adjust.method=adjust.method)[[2]]
	fit$stdev.coefficients <- SD.coefficients
	fit$stdev.Ameans <- SD.Ameans
	fit$Ameans <- Ameans
    if (type == 1) {
        fit$saturation.pct <- sat.pct
        fit$weights <- weights
    }
	return(fit)
}


apa.names$microarray <- c(apa.names$microarray, "subset.augmented.fit")
subset.augmented.fit <- function(fit, vec) {
     
     ## Subsets a fit object by a row index vector
     ## Also searches for nonstandard 'fit' elements and subsets them as well
     
     orig <- nrow(fit$coefficients)
#     fit <- fit[vec,]
     x <- which(sapply(sapply(fit, nrow), length) == 1)
     y <- unlist(sapply(fit, nrow)[x])
     z <- which(y == orig)
     for (i in x[z]) { fit[[i]] <- fit[[i]][vec,] }
     return(fit)
}


apa.names$microarray <- c(apa.names$microarray, "select.genes")
select.genes <- function(fit, fixed=NULL, alpha=0.05, adj="BH", select="any", more=FALSE, preselect.F=NA, same.sign=FALSE, lfc=NA, lods=NA, ctls=NULL, as.list=FALSE, split=FALSE) {
	
	## Upgrade: add stdevs switch?
	
	## Selects genes from a fit object, based on certain criteria, and returns them topTable-style
	## 'fixed' specifies a row vector of selections; all other switches except 'adj', 'more' and 'as.list' will be ignored.
	## 'alpha' controls p-value threshold
	## 'adj' specifies what method to use for p.adjust -- if NA, then p values are not adjusted
	## 'select' controls whether a gene is required to be significant in at least one column (any) or all columns (all)
	## 'more' adds topTable columns (ONLY if fit object is augmented)
	## 'preselect.F=value' subsets the fit object based on F.p.value <= preselect.F, PRIOR TO any other selections being made.
	##  - NOTE: using 'preselect.F' will boost adjusted p values, because the number of p values decreases.
	## 'same.sign=T' ignores any genes that change sign between contrasts 
	## 'lfc' specifies a minimum absolute log-fold-change for selections
	## 'lods' specifies a minimum absolute log-odds for selections
	## 'ctls' is a logical (or binary) vector indicating which rows are controls.  If specified, controls will be dropped (BEFORE p adjustment).
	## 'as.list=T' returns results as a list of matrices; otherwise a dataframe is returned
	## 'split=T' splits results by fold-change direction (ONLY if same.sign=T)
	
	match.arg(select, c("any", "all"))
	if (is.na(adj)) { adj <- "none" }
	match.arg(adj, c("holm", "hochberg", "hommel", "bonferroni", "BH", "BY", "fdr", "none"))
	
	weights <- ifelse(is.na(match("weights", names(fit))), FALSE, TRUE)
	aug <- ifelse(is.na(match("Ameans", names(fit))), FALSE, TRUE)
	
	if (is.null(fixed)) {
		if (!is.na(preselect.F)) { 
			fit <- subset.augmented.fit(fit, which(fit$F.p.value <= preselect.F))
		}
	}
	
	fit$adj.p <- fit$p.value
	for (i in 1:ncol(fit$adj.p)) { fit$adj.p[,i] <- p.adjust(fit$p.value[,i], method=adj) }
	
	if (!is.null(fixed)) {
		same.sign <- split <- FALSE	# ignored
		fit <- subset.augmented.fit(fit, fixed)
	} else {
		selections <- list()	# these are what genes can be selected by
		if (!is.na(alpha)) { selections$adj.p=which(apply(adj.p <= alpha, 1, select) == TRUE) }		# 'select' is 'all' or 'any'
		if (same.sign) { selections$sign=which(apply(sign(fit$coef) == 1, 1, is.invariant) == TRUE) }
		if (!is.na(lfc)) { selections$lfc=which(apply(fit$lfc <= alpha, 1, select) == TRUE) }
		if (!is.na(lods)) { selections$lods=which(apply(fit$lods <= alpha, 1, select) == TRUE) }
		if (!is.null(ctls)) { selections$nonctl=which(!ctls) }
		
		x <- intersect2(selections)
		if (length(x) > 0) { 
			cat(length(x),"genes meet all criteria.\n"); flush.console()
			fit <- subset.augmented.fit(fit, x)
		} else {
			stop("Selections too stringent: no genes meet all criteria!\n") 
		}
	}
	
	if ("contrasts" %in% names(fit)) {
		contrast <- ifelse (max(colSums(fit$contrasts!=0)) > 1, TRUE, FALSE)   # contrasts fit or expression fit?
	} else {
		contrast <- FALSE
	}
	
	if (!aug) { 
		cat("Warning: Not augmented fit object, which is nicer...  See augment.fit().\n"); flush.console() 
		fit$Ameans <- cbind(fit$Amean, fit$Amean, fit$Amean)
		colnames(fit$Ameans) <- colnames(fit$coefficients)
	}
	
	if (aug && more) { 
		if (contrast) {
			tnames <- c("logFC","sd.logFC","AveExpr","sd.AveExpr","t","P.Value","adj.P.Val","logOdds")
		} else {
			tnames <- c("AveExpr","sd.AveExpr","t","P.Value","adj.P.Val","logOdds")
		}
		if (weights) { tnames <- c(tnames,"AvgWts") }
	} else {
		if (contrast) {
			tnames <- c("logFC","AveExpr","t","P.Value","adj.P.Val","logOdds")
		} else {
			tnames <- c("AveExpr","t","P.Value","adj.P.Val","logOdds")
		}
	}
     
	if (as.list) {
		if (aug && more) { 
			if (contrast) {
				top <- list(fit$genes, fit$coef, fit$stdev.coefficients, fit$Ameans, fit$stdev.Ameans, fit$t, fit$p.value, fit$adj.p, fit$lods)
			} else {
				top <- list(fit$genes, fit$coef, fit$stdev.coefficients, fit$t, fit$p.value, fit$adj.p, fit$lods)
			}
			if (weights) { top <- c(top, fit$weights) }
		} else {
			if (contrast) {
				top <- list(fit$genes, fit$coef, fit$Ameans, fit$t, fit$p.value, fit$adj.p, fit$lods)
			} else {
				top <- list(fit$genes, fit$coef, fit$t, fit$p.value, fit$adj.p, fit$lods)
			}
		}
		names(top) <- c("Genes",tnames)
	} else {
		cnames <- colnames(fit$coefficients)
 		ternary ( is.null(names(fit$genes)), xnames <- "Gene", xnames <- names(fit$genes) )	# flattened MA objects cause nameless fit$genes
 		for (i in tnames) { xnames <- gsub(" ","",c(xnames, paste(cnames, i, sep="_"))) }
 		if (aug && more) { 
			if (contrast) {
				if (weights) {
					top <- data.frame(fit$genes, fit$coef, fit$stdev.coefficients, fit$Ameans, fit$stdev.Ameans, fit$t, fit$p.value, fit$adj.p, fit$lods, fit$weights, stringsAsFactors=FALSE)
				} else {
					top <- data.frame(fit$genes, fit$coef, fit$stdev.coefficients, fit$Ameans, fit$stdev.Ameans, fit$t, fit$p.value, fit$adj.p, fit$lods, stringsAsFactors=FALSE)
				}
			} else {
				if (weights) {
					top <- data.frame(fit$genes, fit$coef, fit$stdev.coefficients, fit$t, fit$p.value, fit$adj.p, fit$lods, fit$weights, stringsAsFactors=FALSE)
				} else {
					top <- data.frame(fit$genes, fit$coef, fit$stdev.coefficients, fit$t, fit$p.value, fit$adj.p, fit$lods, stringsAsFactors=FALSE)
				}
			}
		} else {
 			top <- data.frame(fit$genes, fit$coef, fit$Ameans, fit$t, fit$p.value, fit$adj.p, fit$lods, stringsAsFactors=FALSE)
		}
		colnames(top) <- xnames
	}
	
	if (same.sign & split) {
		signs <- rowMeans(sign(fit$coef))
		up <- which(signs > 0)	# ignore any zeroes
		dn <- which(signs < 0)
		top2 <- list(UP=top, DOWN=top)
		if (as.list) {
			for (i in 1:length(top)) { 
				top2$UP[[i]] <- top[[i]][up,] 
				top2$DOWN[[i]] <- top[[i]][dn,] 
			}
		} else {
			top2$UP <- top[up,] 
			top2$DOWN <- top[dn,] 
		}
		return(top2)
	} else {
		return(top)
	}
}


apa.names$microarray <- c(apa.names$microarray, c("corr.mat","dist.mat","corr.dist.mat"))
corr.mat <-
    dist.mat <-
        corr.dist.mat <-
            function(obj1, obj2=NULL, names1=NULL, names2=NULL, metric="pearson", use=c("pairwise.complete.obs","complete.obs","all.obs"), 
                     with.p=FALSE, lower=FALSE, limits=c(-Inf,Inf), reorder=FALSE, palette="KBY", rev.pal=FALSE, pmar=c(5,5), scale.min=NULL,
                     scale.max=NULL, main=NULL, diagonal=NULL, reord.metric="euclidean", reord.linkage="average", view=FALSE, imgname=NULL,
                     imgdim=c(700,600), device=c("png","pdf"), nonzero=FALSE, plot=NULL, cex=1, drop.diag=FALSE, ...) {
                
    ## obj1 is any 2-D object; so is (optional) obj2.
    ##  - these are probably matrices, but may also be DFs with factors, if using r-squared metrics.
    ##  - if obj1 & obj2 given, columns of 1 are compared to columns of 2.
    ##  - if obj1 only, columns of obj1 are compared to themselves.
    ## "metric" is how to make pairwise comparisons:
    ##  1. Correlations: methods for cor()/cor.test(), i.e. "pearson", "spearman", or "kendall"
    ##  2. R-Squareds: "r2" or "adjusted.r2" [from summary(lm(...))]; can have ".dist" suffix to convert them to distances.
    ##  3. Distances: methods for dist(), e.g. euclidean, binary, manhattan, etc...
    ##  4. More Distances: methods for distance(), i.e. "pearson.dist", "spearman.dist", "kendall.dist", etc. USED AS DISTANCE NOT AS CORRELATION
    ##  These are NOT to be confused with "reord.metric" which does REORDERING of the resulting object...
    
    xargs <- list(...)
    if (length(xargs$filename)>0 & length(imgname)==0) imgname <- xargs$filename  # legacy call using 'filename'
    if (length(names1)>0) colnames(obj1) <- names1
    is.limited <- ifelse (all(is.infinite(limits)), FALSE, TRUE)
    use <- match.arg(use)
    device <- match.arg(device)
    plot2file <- ifelse(is.na(device)|length(imgname)==0, FALSE, TRUE)
    if (plot2file) view <- TRUE
    if (!is.null(plot)) view <- plot   # legacy support
    cex <- ifelse(length(cex)>0, cex, ifelse(plot2file, ifelse(device=="png", 1.2, 1), 1))
    
    r.metrics <- c("r2","r2.signed","adjusted.r2","adjusted.r2.signed")  # special subset of cor.metrics
    cor.metrics <- c("pearson", "spearman","kendall","r2","r2.signed","adjusted.r2","adjusted.r2.signed")
    dist.metrics <- c("euclidean","maximum","manhattan","canberra","binary")
    distance.metrics <- c("pearson.dist","spearman.dist","kendall.dist","r2.dist","adjusted.r2.dist")
    
    ## Test main metric
    Metric <- gsub("\\.","",sub(".dist$","",paste0(toupper(substr(metric,1,1)),substr(metric,2,nchar(metric)))))
    if (metric %in% cor.metrics) {
        is.corr <- TRUE; is.dist <- FALSE; is.distance <- FALSE
        is.r <- metric %in% r.metrics  # subset of cor.metrics
        if (is.r) Metric <- sub("r2","R^2",Metric)
        if (is.null(main)) main <- paste("Sample",Metric,"Correlations")
    } else if (metric %in% dist.metrics) {
        is.r <- FALSE; is.corr <- FALSE; is.dist <- TRUE; is.distance <- FALSE
        if (is.null(main)) main <- paste("Sample",Metric,"Distance")
    } else if (metric %in% distance.metrics) {
        dmetric <- sub(".dist$","",metric)
        is.r <- FALSE; is.corr <- FALSE; is.dist <- FALSE; is.distance <- TRUE
        if (is.null(main)) main <- paste("Sample",Metric,"Distance")
    } else {
        stop(paste("'",metric,"' is not a recognized correlation or distance metric!\n",sep=""))
    }
    
    ## Test reordering metric
    if (reord.metric %in% cor.metrics) {
        is.corr.reord <- TRUE; is.dist.reord <- FALSE; is.distance.reord <- FALSE
    } else if (reord.metric %in% dist.metrics) {
        is.corr.reord <- FALSE; is.dist.reord <- TRUE; is.distance.reord <- FALSE
    } else if (reord.metric %in% distance.metrics) {
        reord.dmetric <- sub(".dist$","",reord.metric)
        is.corr.reord <- FALSE; is.dist.reord <- FALSE; is.distance.reord <- TRUE
    } else {
        stop(paste("'",reord.metric,"' is not a recognized correlation or distance metric!\n",sep=""))
    }
    
    if (!(metric %in% cor.metrics) & with.p) {   # asked for p's but can't get
        IM("Warning: p-values are unavailable with this metric!\n")
        with.p <- FALSE
    }
    
    fill <- ifelse(lower, NA, 0)
    if (length(obj2)>0) {
        ## correlating columns of obj1 to obj2
        if (nrow(obj1) != nrow(obj2)) stop("Matrices have differing numbers of rows: cannot compare columns!\n")
        if (length(names2)>0) colnames(obj2) <- names2
        cmat <- matrix(fill, nrow=ncol(obj1), ncol=ncol(obj2))
        rownames(cmat) <- colnames(obj1)
        colnames(cmat) <- colnames(obj2)
        single.obj <- FALSE
    } else {
        ## correlating columns of obj1 to each other
        cmat <- matrix(fill, nrow=ncol(obj1), ncol=ncol(obj1))
        rownames(cmat) <- colnames(cmat) <- colnames(obj1)
        obj2 <- obj1
        single.obj <- TRUE
    }
    
    if (!is.r) {
        ## do not interfere with columns if some of them may be factors
        obj1[is.infinite(obj1)] <- NA
        obj2[is.infinite(obj2)] <- NA
        if (nonzero) {
            obj1 <- obj1[apply(obj1!=0,1,any),]
            obj2 <- obj2[apply(obj2!=0,1,any),]
            if (nrow(obj1)==0 | nrow(obj2)==0) stop("No non-zero rows!  Nothing to correlate.\n")
        }
    }
    if (with.p) pmat <- cmat
    
    if (is.r) {
        ## separate handling if some of the columns may be factors
        elem.name <- switch(metric, "r2"="r.squared", "r2.signed"="r.squared", "adjusted.r2"="adj.r.squared", "adjusted.r2.signed"="adj.r.squared")
        signed <- grepl(".signed$",metric)
        for (i in 1:ncol(obj1)) {
            for (j in 1:ncol(obj2)) {
                if (i==j) {
                    ## don't waste time fitting a column to itself
                    cmat[i,j] <- 1
                    if (with.p) pmat[i,j] <- 0
                } else if (is.factor(obj2[,j])) {
                    ## can't explain a factor with a linear model
                    cmat[i,j] <- NA
                    if (with.p) pmat[i,j] <- NA
                } else {
                    LM <- lm(obj2[,j]~obj1[,i])
                    cmat[i,j] <- zerofy(summary(lm(obj2[,j]~obj1[,i]))[[elem.name]])
                    if (signed) cmat[i,j] <- cmat[i,j] * sign(LM[[1]][[2]])
                    if (with.p) pmat[i,j] <- anova(LM)[[5]][[1]]
                }
            }
        }
        if (any(is.na(cmat))) {
            ## symmetrize: if any is.na(cmat[i,j]), replace with any non-NA cmat[j,i]
            for (i in 1:ncol(obj1)) {
                for (j in 1:ncol(obj2)) {
                    if (is.na(cmat[i,j])) cmat[i,j] <- cmat[j,i]
                    if (with.p) if (is.na(pmat[i,j])) pmat[i,j] <- pmat[j,i]
                }
            }
        }
    } else if (single.obj & !with.p & !is.limited) {
        ## single object, no p-values, no limits: simplest case
        if (is.corr) {
            cmat <- cor(obj1, method=metric, use=use)
        } else if (is.dist) {
            cmat <- as.matrix(dist(t(obj1)))
        } else if (is.distance) {
            cmat <- as.matrix(distance(t(obj1), method=dmetric))
        }
    } else {
        for (i in 1:ncol(obj1)) {
            ok1 <- real(obj1[,i],logical=TRUE) & falsify(obj1[,i]>=limits[1]) & falsify(obj1[,i]<=limits[2])
            for (j in 1:ncol(obj2)) {
                if (single.obj & i<j) next  # lower triangular object + diagonal only
                ok2 <- real(obj2[,j],logical=TRUE) & falsify(obj2[,j]>=limits[1]) & falsify(obj2[,j]<=limits[2])
                ok <- ok1 & ok2
                if (length(ok) >= 3) {
                    if (is.corr) {
                        if (with.p) {
                            x <- cor.test(obj1[ok,i], obj2[ok,j], method=metric)
                            cmat[i,j] <- x[[4]]
                            pmat[i,j] <- x[[3]]
                        } else {
                            cmat[i,j] <- cor(obj1[ok,i], obj2[ok,j], method=metric)
                        }
                    } else if (is.dist) {
                        cmat[i,j] <- dist(rbind(obj1[ok,i],obj2[ok,j]), method=metric)[1]
                    } else if (is.distance) {
                        cmat[i,j] <- distance(rbind(obj1[ok,i],obj2[ok,j]), method=dmetric)[1]
                    }
                    if (is.na(cmat[i,j])) cmat[i,j] <- 0
                } else {
                    cmat[i,j] <- 0
                    if (with.p) pmat[i,j] <- 1
                }
            }
        }
        if (single.obj & !lower) {
            cmat <- upper.triangle.fill(cmat)
            if (with.p) pmat <- upper.triangle.fill(pmat)
        }
    }
    
    if (reorder) {
        if (is.corr.reord) {
            reord.dist <- as.dist(cor(zerofy(cmat), method=reord.metric))
        } else if (is.dist.reord) {
            reord.dist <- dist(zerofy(cmat), method=reord.metric)
        } else if (is.distance.reord) {
            reord.dist <- distance(zerofy(t(obj1)), method=reord.dmetric)
        }
        hc <- hclust(reord.dist, method=reord.linkage)
        cmat <- cmat[hc$order,hc$order]
        if (with.p) pmat <- pmat[hc$order,hc$order]
    }
    
    if (length(diagonal)>0) diag(cmat) <- diagonal
    
    if (view) {
        if (!plot2file) {
            ## do nothing
        } else if (device == "png") {
            png(imgname, width=imgdim[1], height=imgdim[2])
            cex <- 1.2
        } else if (device == "pdf") {
            pdf(imgname, width=imgdim[1]/100, height=imgdim[2]/100)
            cex <- 0.9
        }
        
        cmat.scale <- cmat
        if (drop.diag) diag(cmat.scale) <- Inf
        scale.min <- ifelse(is.null(scale.min), min(real(cmat.scale)), scale.min)
        scale.max <- ifelse(is.null(scale.max), max(real(cmat.scale)), scale.max)
        myImagePlotUltra(cmat.scale, palette=palette, rev.pal=rev.pal, pmar=pmar, col.limits=c(scale.min,scale.max), main=main, cex=cex, NA.col=8, Inf.col="white", ...)
        if (!is.null(imgname)) dev.off()
    }
    
    if (with.p) {
        invisible(list(cmat=cmat, pmat=pmat))
    } else {
        invisible(cmat)
    }
}


apa.names$microarray <- c(apa.names$microarray, "plot.norm.QC")
plot.norm.QC <- function(raw, norm, names=NULL, special=NULL, bx.mar=7, bx.las=3, filename=NULL) {
	
	## raw, norm are expression-value matrices OF THE SAME CLASS (see below)
	## 'special' is an optional dataframe with targets$Alias, plot chars, line types, and colors in cols 1,2,3,4-5
	##   all colors in col 4 if Affy; else col 4 = red channel colors, col 5 = green channel colors
	
	if (is(raw, "RGList")) {
		if (!is.null(names)) { colnames(raw$R) <- colnames(raw$G) <- colnames(norm$R) <- colnames(norm$G) <- names }
		bp.raw <- bp.norm <- vector("list", length=ncol(raw$R)*2)
		for (i in 1:ncol(raw$R)) {
			j <- (i-1)*2+1
			bp.raw[[j]] <- log2(raw$R[,i])
			bp.raw[[(j+1)]] <- log2(raw$G[,i])
			bp.norm[[j]] <- log2(norm$R[,i])
			bp.norm[[(j+1)]] <- log2(norm$G[,i])
		}
          samplenames <- colnames(raw$R)
		if (is.null(special)) {
			cols <- rep(c(2,3), ncol(raw$R))
			ltys <- rep(1, ncol(raw$R))
		} else {
			if (ncol(special) != 5) { stop("'special' data frame must have 5 columns for 2-channel array data!\n") }
			cols <- ltys <- pchs <- c()
			for (i in 1:nrow(special)) { 
				cols <- c( cols, as.character(special[i,4]), as.character(special[i,5]) )
				ltys <- c( ltys, as.numeric(special[i,3]), as.numeric(special[i,3]) )
				pchs <- c( pchs, as.numeric(special[i,2]), as.numeric(special[i,2]) )
			}
		}
	} else if (is(raw, "AffyBatch")) {
          if (is(norm, "ExpressionSet")) {
               raw <- log2(exprs(raw))
               norm <- exprs(norm)
               if (!is.null(names)) { colnames(raw) <- colnames(norm) <- names }
               samplenames <- colnames(raw)
          } else {
               stop("If 'raw' is 'AffyBatch' then 'norm' must be 'ExpressionSet'!\n")
          }
		if (!is.null(names)) { colnames(raw) <- colnames(norm) <- names }
		bp.raw <- as.list(as.data.frame(raw))
		bp.norm <- as.list(as.data.frame(norm))
		if (is.null(special)) {
			cols <- rainbow(length(bp.raw))
			ltys <- rep(1, length(bp.raw))
			pchs <- rep(1, length(bp.raw))
		} else {
			if (ncol(special) != 4) { stop("'special' data frame must have 4 columns for Affy data!\n") }
			cols <- as.character(special[i,4])
			ltys <- as.numeric(special[,3])
			pchs <- as.numeric(special[,2])
		}
	} else {
		stop (paste("Unsupported object class '",class(raw),"' for raw object!\n",sep=""))
	}
	
	if (class(raw)[[1]] != class(norm)[[1]]) { stop("'raw' and 'norm' objects must be of same class!\n") }
     
	alldens.r <- alldens.n <- c()
	for (i in 1:length(bp.raw)) { alldens.r <- c(alldens.r, density(bp.raw[[i]], na.rm=TRUE)$y) }
	for (i in 1:length(bp.norm)) { alldens.n <- c(alldens.n, density(bp.norm[[i]], na.rm=TRUE)$y) }

	rmax <- max(alldens.r, na.rm=TRUE)
	nmax <- max(alldens.n, na.rm=TRUE) 
	
	if (!is.null(filename)) { 
		png(filename, height=1200, width=1800) 
          par(mfrow=c(2,2), mar=c(bx.mar,4,4,2), cex=1.2)
	} else {
		par(mfrow=c(2,2), mar=c(bx.mar,4,4,2))
	}

	hist(bp.raw[[1]], ylim=c(0,rmax), col=0, border=0, freq=FALSE, xlab="Log2 Intensity", main="Raw Signal Density", las=1)
	for (i in 1:length(bp.raw)) { lines(density(bp.raw[[i]], na.rm=TRUE), col=cols[i], lty=ltys[i]) }
	legend(x="topright", lty=1, col=cols, bty="n", legend=samplenames)

	hist(bp.norm[[1]], ylim=c(0,nmax), col=0, border=0, freq=FALSE, xlab="Log2 Intensity", main="Norm Signal Density", las=1)
	for (i in 1:length(bp.norm)) { lines(density(bp.norm[[i]], na.rm=TRUE), col=cols[i], lty=ltys[i]) }
	legend(x="topright", lty=1, col=cols, bty="n", legend=samplenames)

	bp.dec <- function() {	# get stuff from main function namespace
		abline(v=seq(2.5,22.5,2), col=4)
		axis(1, at=seq(1.5,length(bp.raw),2), tick=TRUE, las=bx.las, labels=samplenames)
	}

	boxplot(bp.raw, col=cols, pch=pchs, xlab="", ylab="Log2 Intensity", main="Raw Signal Boxplots", las=2)
#	bp.dec()
	boxplot(bp.norm, col=cols, pch=pchs, xlab="", ylab="Log2 Intensity", main="Norm Signal Boxplots", las=2)
#	bp.dec()

	if (!is.null(filename)) { dev.off() }
}


apa.names$microarray <- c(apa.names$microarray, "plot.ratio.QC")
plot.ratio.QC <- function(obj, type="M", names=NULL, special=NULL, groups=NULL, bx.mar=7, bx.las=3, filename=NULL) {
	
	## input is any expression-value matrix

	if (is(obj, "MAList")) {
		ternary (type == "M", mat <- obj$M, mat <- obj$A)
	} else if (is(obj, "MArrayLM")) {
		ternary (type == "M", mat <- obj$coefficients, stop("A-value comparisons not possible for class MArrayLM!\n"))
		type <- "Limma"
	} else if (is.matrix(obj) & mode(obj) == "numeric") {
		mat <- obj
	} else {
		stop("Object must be a numeric matrix, or of classes MAList or MArrayLM!\n")
	}
	
	if (!is.null(names)) { colnames(mat) <- names }
	if (is.null(groups)) { groups <- list(c(1:ncol(mat))) }
	irows <- length(groups)
	
	if (!is.null(filename)) { 
		png(filename, height=irows*600, width=1200) 
		par(mfrow=c(irows,2), mar=c(bx.mar,4,4,2), cex=1.2)
	} else {
		par(mfrow=c(irows,2), mar=c(bx.mar,4,4,2))
	}
	
	for (i in 1:length(groups)) {
		x <- groups[[i]]
		cols <- rainbow(length(x))
		alldens <- c()
		for (j in 1:length(x)) { alldens <- c(alldens, density(mat[,x[j]], na.rm=TRUE)$y) }
		ymax <- max(alldens)

		hist(mat[,x[1]], ylim=c(0,ymax), col=0, border=0, freq=FALSE, xlab=paste(type,"Values"), main="Signal Ratio Density")
		for (j in 1:length(x)) { lines(density(mat[,x[j]], na.rm=TRUE), col=cols[j]) }
#		legend(x="topright", lty=1, col=cols, bty="n", legend=c())

		boxplot(mat[,x], col=cols, las=bx.las, xlab="", ylab=paste(type,"Values"), main="Signal Ratio Boxplots")
	}
	
	if (!is.null(filename)) { dev.off() }
}


apa.names$microarray <- c(apa.names$microarray, "MA.scatter.plotdim")
MA.scatter.plotdim <- function(N, pixels=500, cap.dim=NA, square=FALSE, wide=TRUE) {
	
	## Determines plot rows, columns, and dimensions based on the number of plots (N), pixels per axis, and the square flag (square).
	## 'pixels' gives the external plot device (png, jpg) pixels per axis, so 'pixels=500' allocates 500x500 per plot.
	## 'square=T' fits the data to the nearest MxM plot layout.
	## 'wide=T' makes the plot layout wider than high
	
	if (square) {
		Q <- sqrt(N)
		if (Q == trunc(Q)) { 	# N == Q^2
			irows <- icols <- Q
		} else {
			irows <- icols <- ceiling(Q)
		}
	} else {
		## Determine plot dimensions -- calculable for N up to 101^2-1.
		## if cap.dim specified: if wide=T, max nrow=cap.dim and ncol will float; if wide=F, transpose the situation
		if (N > 101^2-1) { stop("MA.scatter.plotdim cannot process a panel count exceeding 101^2-1.\n") }
		squares <- c(1:100)^2   # here we assume that no-one will try to get an automated layout for > 101^2-1 panels...
		irows <- rev(which(squares-N<=0))[1]  # this is the nearest integer whose square is <= N (thus N can be up to 101^2-1 and still return irows=100)
		if (!is.na(cap.dim)) {
			if (irows > cap.dim) irows <- cap.dim
		}
		icols <- ceiling(N/irows)
	}
	
	if (wide) {
		x <- c(irows, icols, irows*pixels, icols*pixels)  # wide=T by default
	} else {
		x <- c(icols, irows, icols*pixels, irows*pixels)  # transpose
	}
	names(x) <- c("irows","icols","iheight","iwidth")
	return(x)
}
    
apa.names$plots <- c(apa.names$plots, "legend.position")
legend.position <- function(m, plot=FALSE) {
    
    ## give a matrix of values that will be plotted
    ## returns lowest density position for legend (of the named positions)
    
    thirds <- as.data.frame(apply(m,2,function(x) min(x,na.rm=TRUE)+diff(range(x,na.rm=TRUE))*c(1/3,2/3) ))
    colnames(thirds) <- c("x","y")
    ## Tile Positions:
    ## 1 2 3
    ## 4 5 6
    ## 7 8 9
    td <- c(  # tile densities
        T1=sum( falsify(m[,1]<thirds$x[1])                              & falsify(m[,2]>thirds$y[2])                              ),
        T2=sum( falsify(m[,1]>thirds$x[1]) & falsify(m[,1]<thirds$x[2]) & falsify(m[,2]>thirds$y[2])                              ),
        T3=sum( falsify(m[,1]>thirds$x[2])                              & falsify(m[,2]>thirds$y[2])                              ),
        T4=sum( falsify(m[,1]<thirds$x[1])                              & falsify(m[,2]>thirds$y[1]) & falsify(m[,2]<thirds$y[2]) ),
        T5=sum( falsify(m[,1]>thirds$x[1]) & falsify(m[,1]<thirds$x[2]) & falsify(m[,2]>thirds$y[1]) & falsify(m[,2]<thirds$y[2]) ),
        T6=sum( falsify(m[,1]>thirds$x[2])                              & falsify(m[,2]>thirds$y[1]) & falsify(m[,2]<thirds$y[2]) ),
        T7=sum( falsify(m[,1]<thirds$x[1])                              & falsify(m[,2]<thirds$y[1])                              ),
        T8=sum( falsify(m[,1]>thirds$x[1]) & falsify(m[,1]<thirds$x[2]) & falsify(m[,2]<thirds$y[1])                              ),
        T9=sum( falsify(m[,1]>thirds$x[2])                              & falsify(m[,2]<thirds$y[1])                              )
    )
    ## troubleshooting plot
    if (plot) {
        tmids <- apply(thirds, 2, function(x){ d=abs(diff(x)); c(x[2]+d/2,mean(x),x[1]-d/2) })
        tmids <- cbind(rep(rev(tmids[,1]),3),rep(tmids[,2],each=3))
        dev.new(); plot(m); abline(h=thirds$y,v=thirds$x); for (i in 1:9) text(tmids[i,1], tmids[i,2], td[i], font=2, col=2)
    }
    
    switch(
        names(td)[which.min(td)],
        "T1"="topleft",
        "T2"="top",
        "T3"="topright",
        "T4"="left",
        "T5"="center",
        "T6"="right",
        "T7"="bottomleft",
        "T8"="bottom",
        "T9"="bottomleft"
    )
}


apa.names$microarray <- c(apa.names$microarray, "MA.scatter.decorate")
MA.scatter.decorate <- function(pars) {
	
	### Function for adding fold-change lines, fold-change color bands, correlation/regression values, etc. to scatter and MA plots
	### 'pars' is a parameters list with named elements; see unpacking list below ...
	### DO NOT use any variable names that are being imported!!! 
	
	## unpack variables	(code is much easier to read without all the "pars$" prefixes...)
	x <- pars$x    # x plot-data vector
	y <- pars$y    # y plot-data vector
	i <- pars$i    # plot instance
	j <- pars$j    # comparison sample 1 (if any)
	k <- pars$k    # comparison sample 2 (if any)
	foldcolor <- pars$foldcolor
	smooth <- pars$smooth
	fc.lines <- pars$fc.lines
	fc.stdev <- pars$fc.stdev
	slope <- pars$slope
	regress <- pars$regress
	pch <- pars$pch
	cdat <- pars$cdat
	sat.mat <- pars$sat.mat
	sat.cols <- pars$sat.cols
    plot <- pars$plot
    sigs <- pars$sigs
	
	## Plot fold-change color bands, if indicated
	ok <- intersect( which(!is.na(x)), which(!is.na(y)) )
	if (foldcolor & !smooth) {	# fold-coloring not possible with smoothScatter!
		foldcols <- c(1,4,3,2,5,6,7)	# supports differential coloring up to logFC=6
		fold.sets <- fc.sets(x, y, max(fc.lines), slope)
		fold.pcts <- rep(0, length(fold.sets))
		for (f in 1:length(fold.sets)) { 
			points(x[fold.sets[[f]]], y[fold.sets[[f]]], pch=pch, col=foldcols[f]) 
			fold.pcts[f] <- round(100 * length(fold.sets[[f]]) / length(ok), 1)
		}
		fcl.col <- 8
	} else {
		fcl.col <- 2
          if (plot == "MA") {      # NOT plotting significant points if fold-coloring is applied...
               if (!is.null(sigs)) {
                    up <- intersect(sigs, which(y > 0))
                    dn <- intersect(sigs, which(y < 0))
                    if (length(up > 0)) { points(x[up], y[up], pch=pch, col=2) }
                    if (length(dn > 0)) { points(x[dn], y[dn], pch=pch, col=3) }
               }
          }
	}
	
	if (!is.null(sat.mat)) {
		if (mode(sat.mat) == "character") {		# RG data
			sat.x <- which(sat.mat[cdat$nonCtl,j] == type)
			sat.y <- which(sat.mat[cdat$nonCtl,k] == type)
			points(x[sat.x], y[sat.x], col=sat.cols[1], pch=pch)
			points(x[sat.y], y[sat.y], col=sat.cols[2], pch=pch)
			sltext <- c( paste(length(sat.x),"saturated (x)"), paste(length(sat.y),"saturated (y)") )
		} else if (mode(sat.mat) == "numeric") {	# MA/fit data
			sat.hi <- which(sat.mat[cdat$nonCtl,i] >= 0.5)
			sat.lo <- which(sat.mat[cdat$nonCtl,i] < 0.5)
			points(x[sat.hi], y[sat.hi], col=sat.cols[1], pch=pch)
			points(x[sat.lo], y[sat.lo], col=sat.cols[2], pch=pch)
			sltext <- c( paste(length(sat.x),">= 50% saturated"), paste(length(sat.y),"< 50% saturated") )
		}
	}
	
	## Plot fold-change lines, if indicated
	ternary (regress, reg.vecs <- list(x,y), reg.vecs <- NULL)
	if (!is.null(fc.lines)) { plot.fc.lines(fc.lines, reg.vecs=reg.vecs, slope=slope, stdev=fc.stdev, col=fcl.col, lty=2, lwd=1, col.diag=fcl.col, lty.diag=1, lwd.diag=1, col.reg=6, lty.reg=3, lwd.reg=1) }
	abline(0, slope, col=fcl.col)
	
	## Plot legends OVER ablines...
	if (foldcolor & !smooth) { legend(x="bottomright", bty="n", text.col=foldcols, legend=paste(fold.pcts,"%",sep="")) }
	if (!is.null(sat.mat)) { legend(x="bottom", bty="n", pch=pch, col=sat.cols, legend=sltext) }
	## Plot R value
	if (plot == "scatter") {
		tcol <- tcex <- 1
		if (smooth) { tcol <- "white"; tcex <- 1.2 }
		legend( x="topleft", bty="n", cex=tcex, text.col=tcol, legend=paste("R =",signif(cor(x[ok], y[ok], method="pearson"),3)) )
		if (!is.null(sigs)) { legend( x="topright", bty="n", cex=tcex, text.col=tcol, legend=paste("Sig DE =",length(sigs)) ) }
	} else if (plot == "MA") {
		tcol <- tcex <- 1
		if (smooth) { tcol <- "white"; tcex <- 1.2 }
          R <- 2^(x + y/2)
          G <- 2^(x - y/2)
		legend( x="topleft", bty="n", cex=tcex, text.col=tcol, legend=paste("R =",signif(cor(R[ok], G[ok], method="pearson"),3)) )
		if (!is.null(sigs)) { legend( x="topright", bty="n", cex=tcex, text.col=tcol, legend=paste("Sig DE =",length(sigs)) ) }
     }
}


apa.names$microarray <- c(apa.names$microarray, "MA.scatter.plot")
MA.scatter.plot <- function(obj, type, plot, IDcol=NULL, smooth=FALSE, fc.lines=c(-2:2), foldcolor=FALSE, monoscale=FALSE, significants=NULL, compares=NULL, names=NULL, arrayID=NULL, plot.ctls="yes", regress=FALSE, filename=NULL) {
	
	## 'arrayID', if supplied, must be an array ID from the library file "S:/Genomics/Molbio_Users/APA/R_Things/microarray_library.R"
	
	#### Check if 'obj', 'type', 'plot' are valid 
	
	match.arg(plot, c("MA", "scatter"))
	if (!is.null(type)) { match.arg(type, c("M","A","R","G")) }
    sigstop <- FALSE
	
     #### Check if 'obj' is valid; if so, set some values and create either 'mat' or 'MA.obj' objects
	
	if (is.matrix(obj) & mode(obj) == "numeric") {
        if (!is.null(significants)) { 
            if (!is.logical(significants)) { sigstop <- TRUE } 
            if (all(dim(significants) != dim(obj))) { sigstop <- TRUE } 
        }
		IDs <- rownames(obj)
		if (is.null(IDs)) { cat("Since rownames are not probe IDs, controls will not be identifiable.\n"); flush.console() }
		if (plot == "MA") {
			if (ncol(obj) == 2) { 
				MA.obj <- list(M=obj[,1], A=obj[,2])
			} else {
				stop ("Numeric matrix input for MA plot must have ncol=2 only!\n") 
			}
		} else {
			## n-column matrix with no ID: 'compares' will be used if given; otherwise all-by-all scatterplot matrix
            mat <- obj
		}
		rows <- nrow(obj)
	} else {
		if (is(obj, "MAList")) {
            if (!is.null(significants)) { 
                if (all(dim(significants) != dim(obj$M))) { sigstop <- TRUE } 
            }
			if (plot == "scatter") {
				mat <- switch(type, M=obj$M, A=obj$A)
				msg <- paste("Cannot extract matrix of type '",type,"' from an object of class 'MAList'!\n",sep="")
				if (is.null(mat)) { stop(msg) }
			} else if (plot == "MA") {
				MA.obj <- obj
			}
			rows <- nrow(obj$M)
		} else if (is(obj, "RGList")) {
            if (!is.null(significants)) { 
                if (all(dim(significants) != dim(obj$R))) { sigstop <- TRUE } 
            }
			if (plot == "scatter") {
				mat <- switch(type, R=log2(obj$R), G=log2(obj$G))
				msg <- paste("Cannot extract matrix of type '",type,"' from an object of class 'RGList'!\n",sep="")
				if (is.null(mat)) { stop(msg) }
			} else if (plot == "MA") {
				stop("Objects of class 'RGList' cannot be used for MA plots!\n")
			}
			rows <- nrow(obj$R)
		} else if (is(obj, "MArrayLM")) {
            if (!is.null(significants)) { 
                if (all(dim(significants) != dim(obj$coefficients))) { sigstop <- TRUE } 
            }
			if (plot == "scatter") {
				ternary (type == "M", mat <- obj$coefficients, stop("Class MArrayLM allows MA plots and M scatters only!\n"))
				type <- "Limma"
			} else if (plot == "MA") {
				ternary ("Ameans" %in% names(obj), Ameans <- cbind(obj$Amean,obj$Amean,obj$Amean), Ameans <- obj$Ameans)
				MA.obj <- list(M=obj$coefficients, A=Ameans)
			}
			rows <- nrow(obj$coefficients)
		} else { 
			stop("Object must be a numeric matrix, or of classes MAList, RGList, or MArrayLM!\n")
		}
		
		if (!is.null(IDcol)) {
			IDs <- obj$genes[,IDcol]	# custom column
		} else {
			IDs <- obj$genes$ProbeName	# AFE
			if (length(IDs) == 0) { IDs <- obj$genes$ID }	# GPR
			if (length(IDs) == 0) { stop("Cannot locate gene identifiers!\n") }	# toast
		}
	}
     if (sigstop) { stop("If specified, 'significants' must be a logical matrix of the same dimension as 'obj'!\n") }
	
	#### Other validity checks
	
	if (foldcolor & is.null(fc.lines)) { 
		IM("'foldcolor' requires 'fc.lines' to be defined!\n")
		foldcolor <- FALSE
	}
	if (is.null(plot.ctls) | plot.ctls == "no") {
		plot.ctls <- "no"	# in case null
		ctl.plot <- FALSE
		pcol <- 1
	} else if (plot.ctls == "yes") {
		ctl.plot <- TRUE
		pcol <- 1
	} else if (plot.ctls == "only") {
		ctl.plot <- TRUE
		pcol <- 0
		if (smooth) {
			IM("Warning: 'smooth' cannot be used for control-only plots!  Ignoring.\n")
			smooth <- FALSE
		}
	} else {
		IM("Unknown value for 'plot.ctls'!  Must be 'yes', 'no', or 'only': defaulting to 'no'\n")
		plot.ctls <- "no"
		ctl.plot <- FALSE
		pcol <- 1
	}
	
	#### Initialize default params for plot styles, identify any saturation, and get any controls
	
	if (smooth) {
		ss.ramp <- colorRampPalette(c(4, terrain.colors(7)[1:5], "white"), interp="spline")	# "avocado plot"
		ss.band <- 0.25
		ss.nbin <- 128
		ss.pch <- pch <- "."
          sat.cols <- NULL
	} else {
		pch <- 4	# or "x"	# MAKE SURE these do not overlap with defined control pchs in parse.controls()!
		sat.cols <- c("cyan","cyan3")	# MAKE SURE these do not overlap with defined control colors in parse.controls()!
	}
		
	if (is(obj, "RGList")) {
		sat.mat <- get.saturation(obj)
	} else if ("saturation.pct" %in% names(obj)) {
		sat.mat <- obj$saturation.pct
	} else {
		sat.mat <- NULL
	}
	
	#### Figure out if controls are being plotted (or anything else)
	
	cdat <- NULL
	if (ctl.plot) {		# plot controls
		if (plot.ctls == "only") {	# plot ONLY controls
			if (is.null(arrayID)) {		# no controls to plot
				stop("Nothing to plot: cannot get controls without 'arrayID' value!\n")
			} else {			# may have controls...
				cdat <- parse.controls(IDs, arrayID)
				if (length(cdat$allCtl) == 0) {	# no controls after all
					stop(paste("Nothing to plot: no controls for arrayID",arrayID,"have been annotated in the microarray library file!\n"))
				} else { 			# we have controls
					scalerows <- rowset <- cdat$allCtl
				}
			}
		} else {			# plot controls and everything else
			if (is.null(arrayID)) {		# no controls to plot
				ctl.plot <- FALSE
				scalerows <- rowset <- 1:rows
			} else {			# may have controls...
				cdat <- parse.controls(IDs, arrayID)
				if (length(cdat$allCtl) == 0) {	# no controls after all
					scalerows <- rowset <- 1:rows
				} else {			# we have controls
					scalerows <- 1:rows
					rowset <- cdat$nonCtl
				}
			}
		}
	} else {		# do not plot controls
		if (is.null(arrayID)) {		# but we don't even know what the controls are...
			IM(paste("No arrayID specified: controls cannot be removed.\n"))
			scalerows <- rowset <- 1:rows
		} else {			# may have controls...
			cdat <- parse.controls(IDs, arrayID)
			if (length(cdat$allCtl) == 0) {	# no controls after all
				scalerows <- rowset <- 1:rows
			} else {			# we have controls
				scalerows <- rowset <- cdat$nonCtl
			}
		}
	}
	
	#### Further object prep; set plot x/ylims, layout & image dimensions; arrange 'compares' list if necessary
	if (plot == "MA") {
		
		slope <- 0
		if (ctl.plot) {
			if (cdat$arrayDef$Provider == "Agilent" & cdat$arrayDef$Assay == "expr") {		# redefine smooth plot params if MAplot + Agilent + spikes
				greyscale <- c("#F7F7F7","#CCCCCC","#969696","#636363","#252525","#000000")	# equivalent of c(brewer.pal(5,"Greys"),1)
				ramp <- colorRampPalette(greyscale)
			}
		}
		if (monoscale) {
			xmin <- min(MA.obj$A[scalerows,], na.rm=TRUE)
			xmax <- max(MA.obj$A[scalerows,], na.rm=TRUE)
			ymin <- min(MA.obj$M[scalerows,], na.rm=TRUE)
			ymax <- max(MA.obj$M[scalerows,], na.rm=TRUE)
		}
		dims <- MA.scatter.plotdim(ncol(MA.obj$M))
		
	} else if (plot == "scatter") {
		
		slope <- 1
		if (monoscale) {  
			xmin <- ymin <- min(mat[scalerows,], na.rm=TRUE)
			xmax <- ymax <- max(mat[scalerows,], na.rm=TRUE)
		}
		if (is.null(compares)) {
			## convert 'compares' into an all-by-all comparison list
			compares <- vector("list", length=ncol(mat)^2)
			k <- 0
			for (i in 1:ncol(mat)) {
				for (j in 1:ncol(mat)) {
					k <- k + 1
					compares[[k]] <- c(i,j)
				}
			}
			
			lcomp <- length(compares)
#			dims <- MA.scatter.plotdim(ncol(mat), square=TRUE)
			dims <- c(ncol(mat), ncol(mat), 500*ncol(mat), 500*ncol(mat))
		} else if (is.list(compares)) {
			lcomp <- length(compares)
			dims <- MA.scatter.plotdim(lcomp)
		} else {
			stop("'compares' must be a list, if specified!\n")
		}
		
		## Check directions of comparisons
		dirs <- compares
		for (i in 1:lcomp) { 
			ternary( type == "A", dirs[[i]] <- c(1,1), dirs[[i]] <- sign(compares[[i]]) ) # A-values immune to dyeswaps
			compares[[i]] <- abs(compares[[i]])	# after sign capture, remove sign
		}
	}
	
	#### Set image and plot layout dimensions; open png device if filename given
	
	irows <- dims[1]
	icols <- dims[2]
	iheight <- dims[3]
	iwidth <- dims[4]
	
	if (!is.null(filename)) { 
		png(filename, height=iheight, width=iwidth) 
		par(mfrow=c(irows, icols), cex=1.2)
	} else {
		par(mfrow=c(irows, icols))
	}
	
	decorate.pars <- list(foldcolor=foldcolor, smooth=smooth, fc.lines=fc.lines, slope=slope, regress=regress, pch=pch, cdat=cdat, sat.mat=sat.mat, sat.cols=sat.cols, plot=plot)
	do.decorate <- TRUE
     
	#### Do the actual plotting

	if (plot == "MA") {
		for (i in 1:ncol(MA.obj$M)) {
			
			x <- MA.obj$A[rowset,i]
			y <- MA.obj$M[rowset,i]
			
			if (!monoscale) {  
				xmin <- min(x[scalerows], na.rm=TRUE)
				xmax <- max(x[scalerows], na.rm=TRUE)
				ymin <- min(y[scalerows], na.rm=TRUE)
				ymax <- max(y[scalerows], na.rm=TRUE)
			}
            
			if (smooth) {
				smoothScatter2(x, y, nbin=ss.nbin, bandwidth=ss.band, pch=ss.pch, colramp=ss.ramp, xlim=c(xmin,xmax), ylim=c(ymin,ymax), ylab="M", xlab="A", main=colnames(MA.obj$M)[i]) 
                    do.decorate=FALSE
			} else {
				plot(x, y, pch=pch, col=pcol, xlim=c(xmin,xmax), ylim=c(ymin,ymax), ylab="M", xlab="A", main=colnames(MA.obj$M)[i]) 
			}
			
			if (ctl.plot) {
				if (length(cdat$ctlSets) > 0) {
					for (j in 1:(length(cdat$ctlSets))) { 
						points(MA.obj$A[cdat$ctlSets[[j]],i], MA.obj$M[cdat$ctlSets[[j]],i], pch=cdat$ctlAtt$pch[j], col=cdat$ctlAtt$col[j])
					}
				}
				if (length(cdat$spikeSets) > 0) {
					for (j in 1:length(cdat$spikeSets)) { 
						points(MA.obj$A[cdat$spikeSets[[j]],i], MA.obj$M[cdat$spikeSets[[j]],i], pch=cdat$spikeAtt$pch[j], col=cdat$spikeAtt$col[j])
					}
					abline(h=log2(cdat$spikeLines$y), lty=2, col=cdat$spikeLines$col)
				}
			}
			
			if (do.decorate & plot.ctls != "only") {
				decorate.pars$i <- i
				decorate.pars$x <- x
				decorate.pars$y <- y
                    decorate.pars$sigs <- intersect(rowset,which(significants[,i]))
                    MA.scatter.decorate(decorate.pars)
	#			decorate()
			}
		}
		
	} else if (plot == "scatter") {
		for (i in 1:lcomp) {
			
			j <- compares[[i]][1]
			k <- compares[[i]][2]
			dj <- dirs[[i]][1]
			dk <- dirs[[i]][2]
			ternary (dj < 0, jf <- " (rev)", jf <- "")
			ternary (dk < 0, kf <- " (rev)", kf <- "")
			title <- paste(colnames(mat)[j],jf," - ",colnames(mat)[k],kf,", ",type," Values",sep="")
			jlab <- paste(colnames(mat)[j],jf,sep="")
			klab <- paste(colnames(mat)[k],kf,sep="")
			x <- mat[rowset,j] * dj
			y <- mat[rowset,k] * dk
			
			if (!monoscale) {  
				xmin <- min(x[scalerows], na.rm=TRUE)
				xmax <- max(x[scalerows], na.rm=TRUE)
				ymin <- min(y[scalerows], na.rm=TRUE)
				ymax <- max(y[scalerows], na.rm=TRUE)
			}
			
			if (smooth) {
				smoothScatter2(x, y, nbin=ss.nbin, bandwidth=ss.band, pch=ss.pch, colramp=ss.ramp, xlim=c(xmin,xmax), ylim=c(ymin,ymax), xlab=jlab, ylab=klab, main=title)
                    do.decorate=FALSE
			} else {
				plot(x, y, pch=pch, col=pcol, xlim=c(xmin,xmax), ylim=c(ymin,ymax), xlab=jlab, ylab=klab, main=title)
			}
			
			if (ctl.plot) {
				if (length(cdat$ctlSets) > 0) {
					for (j in 1:(length(cdat$ctlSets))) { 
						points(MA.obj$A[cdat$ctlSets[[j]],i], MA.obj$M[cdat$ctlSets[[j]],i], pch=cdat$ctlAtt$pch[j], col=cdat$ctlAtt$col[j])
					}
				}
				if (length(cdat$spikeSets) > 0) {
					for (j in 1:length(cdat$spikeSets)) { 
						points(MA.obj$A[cdat$spikeSets[[j]],i], MA.obj$M[cdat$spikeSets[[j]],i], pch=cdat$spikeAtt$pch[j], col=cdat$spikeAtt$col[j])
					}
					abline(h=log2(cdat$spikeLines$y), lty=2, col=cdat$spikeLines$col)
				}
			} 
			
			if (do.decorate & plot.ctls != "only") {
				decorate.pars$i <- i
				decorate.pars$j <- j
				decorate.pars$k <- k
				decorate.pars$x <- x
				decorate.pars$y <- y
                decorate.pars$sigs <- intersect(rowset,which(significants[,i]))
				MA.scatter.decorate(decorate.pars)
	#			decorate()
			}
		}
	}
	
	#### Close png device, if it was opened
	
	if (!is.null(filename)) { dev.off() }
}


# MA.plot(obj, smooth=FALSE, fc.lines=NULL, foldcolor=FALSE, monoscale=FALSE, names=NULL, arrayID=NULL, filename=NULL)
# scatter.plot <- function(obj, type="M", smooth=FALSE, fc.lines=c(-2:2), foldcolor=FALSE, monoscale=FALSE, compares=NULL, names=NULL, arrayID=NULL, filename=NULL)


apa.names$microarray <- c(apa.names$microarray, "MA.plot")
MA.plot <- function(obj, smooth=FALSE, fc.lines=NULL, foldcolor=FALSE, monoscale=FALSE, significants=NULL, names=NULL, arrayID=NULL, filename=NULL) {
	
	MA.scatter.plot(obj, type=NULL, plot="MA", smooth=smooth, fc.lines=fc.lines, foldcolor=foldcolor, monoscale=monoscale, significants=significants, names=names, arrayID=arrayID, filename=filename)
	
}


apa.names$microarray <- c(apa.names$microarray, "scatter.plot")
scatter.plot <- function(obj, type="M", smooth=FALSE, fc.lines=c(-2:2), foldcolor=FALSE, monoscale=FALSE, significants=NULL, compares=NULL, names=NULL, arrayID=NULL, filename=NULL) {
	
	MA.scatter.plot(obj, type=type, plot="scatter", smooth=smooth, fc.lines=fc.lines, foldcolor=foldcolor, monoscale=monoscale, significants=significants, compares=compares, names=names, arrayID=arrayID, filename=filename)
	
}


apa.names$microarray <- c(apa.names$microarray, "SVG.scatterplot")
SVG.scatterplot <- function(x, style=c("MA","volcano","scatter"), filename, sig.p=0.05, sig.fc=0, sig.x=-Inf, cex=1, las=1, col=c("grey","red","green3"), view=FALSE, handlers=FALSE, page.title=NULL, main=NULL, xlim=NULL, ylim=NULL, xlab=NULL, ylab=NULL) {
    
    ## 'x' is a 4-col data.frame.  Columns 1 and 2 are plot values; columns 3 and 4 are p-value (or 0) and gene label
    ##  - for 2-sample scatter plot, columns 1-2 are expression values or whatever
    ##  - for MA or volcano plot, column 1 is mean expr (A); column 2 is log2FC (M); also for volcano plots, col 3 must not be all 0.
    ##  - 'x' may also have columns 5-N; these are considered more gene annots, and will be displayed on the popups along with the gene label.
    ##
    ## 'filename' is the output SVG file that devSVGTips() will write to.  It will not write to screen.
    ## 'sig.p' indicates at which p-value the points start being colored (red=up, green=down).  Setting "sig.p=NA" turns this off.
    ## 'sig.fc', if not NA, is further restriction on which points get colored.  Works with or without 'sig.p'.
    ## 'pch' and 'sig.pch' control pch for non-sig and sig points, respectively.
    ## 'col' is a length-3 vector of color names, being non-sig, sig-up, and sig-down colors, respectively.
    ## 'view' launches Firefox (on *nix systems) to view the resulting plot.
    
    require(RSVGTipsDevice)
    
    style <- match.arg(style)
    ann <- x[,4:ncol(x),drop=FALSE]
    
    if (style=="MA") {
        mat <- x[,1:2]
        lfc <- x[,2]
        if (length(xlab)==0) xlab <- "Log2 Mean"
        if (length(ylab)==0) ylab <- "Log2 Fold-Change"
        if (length(main)==0) main <- "MA Plot"
        if (length(page.title)==0) page.title <- "MA Plot"
    } else if (style=="volcano") {
        mat <- cbind(x[,2], -log10(x[,3]))  # input p-values should be unlogged, so -log10 them here
        lfc <- x[,2]
        if (length(xlab)==0) xlab <- "Log2 Fold-Change"
        if (length(ylab)==0) ylab <- "-Log10(P-Value)"
        if (length(main)==0) main <- "Volcano Plot"
        if (length(page.title)==0) page.title <- "Volcano Plot"
    } else if (style=="scatter") {
        mat <- x[,1:2]
        lfc <- log2(x[,1]/x[,2])
        if (length(xlab)==0) xlab <- colnames(x)[1]
        if (length(ylab)==0) ylab <- colnames(x)[2]
        if (length(main)==0) main <- "Scatter Plot"
        if (length(page.title)==0) page.title <- "Scatter Plot"
    }
    
    if (!is.na(sig.p) & !is.na(sig.fc)) {
        sig.up <- x[,3] <= sig.p & lfc >= sig.fc
        sig.dn <- x[,3] <= sig.p & lfc <= -sig.fc
    } else if (!is.na(sig.p)) {
        sig.up <- x[,3] <= sig.p & lfc > 0
        sig.dn <- x[,3] <= sig.p & lfc < 0
    } else if (!is.na(sig.fc)) {
        sig.up <- lfc >= sig.fc
        sig.dn <- lfc <= -sig.fc
    } else {
        sig.up <- sig.dn <- rep(FALSE, nrow(x))
    }
    if (!is.infinite(sig.x)) {
        sig.up <- sig.up & x[,1] >= sig.x
        sig.dn <- sig.dn & x[,1] >= sig.x
    }
    non.sig <- !sig.up & !sig.dn
    
    if (length(xlim)<2) xlim <- range(real(mat[,1]))
    if (length(ylim)<2) ylim <- range(real(mat[,2]))
    
    devSVGTips(filename, toolTipMode=1, title=page.title)  # this title is for the web page, NOT the image
    plot(0, 0, col=0, xlim=xlim, ylim=ylim, xlab=xlab, ylab=ylab, main=main, cex=cex, las=las)  # empty plot frame
    ## no tooltips (not sig DE)
    if (any(non.sig)) points(mat[non.sig,], col=col[1], pch=1, cex=cex)
    ## red tooltips (sig DE up)
    if (any(sig.up)) {
        invisible(sapply(which(sig.up), function(i) {
            setSVGShapeToolTip(title=paste(ann[i,],collapse="\n"))
            points(mat[i,1], mat[i,2], col=col[2], pch=1, cex=cex)
        }))
    }
    if (any(sig.dn)) {
        ## green tooltips (sig DE down)
        invisible(sapply(which(sig.dn), function(i) {
            setSVGShapeToolTip(title=paste(ann[i,],collapse="\n"))
            points(mat[i,1], mat[i,2], col=col[3], pch=1, cex=cex)
        }))
    }
    
    if (style=="MA") {
        abline(h=0, col=1)
    } else if (style=="volcano") {
        abline(v=0, col=1)
    } else if (style=="scatter") {
        abline(0, 1, col=1)
    }
    
    dev.off()
    
    if (!handlers) system(paste("perl -i -pe 's!SVGRoot.addEventListener!// SVGRoot.addEventListener!'",filename))  # knock out JS even listeners -- Chrome & FF do it better, natively
    if (view) system(paste("firefox",filename,"&"))  # only works on *nix systems
}


apa.names$plots <- c(apa.names$plots, "strandedness.plot")
strandedness.plot <- function(x, label, style=c("density","MA"), minimum=0, pseudo=0, jitter=FALSE, ...) {
    
    ## 'x' is a 2-col expression matrix with rows = genes and col 1 = sense, col 2 = antisense values.
    ## 'label' is a short descriptive string for values in 'x', e.g. 'sample X mRNA counts'.
    ## 'style' is the plot style; either "density" for sense-pct, anti-pct density histogram, or "MA" for sense/anti MA plot.
    ## 'minimum' ignores genes with less than 'minimum' total counts.
    ## 'pseudo' adds this pseudocount to 'x' before making calculations.
    ## 'jitter' applies only if 'style' is "MA"; applies 1% jitter in both dimensions; jitter attenuates for larger values.
    
    style <- match.arg(style)
    x <- x[apply(x>=minimum,1,any),]
    all.sense.pct <- round(100*sum(x[,1])/sum(x),1)  # DO THIS BEFORE ADDING PSEUDOCOUNT
    if (!is.na(pseudo)) x <- x+pseudo
    nr <- nrow(x)
    A <- log2(rowSums(x))
    M <- log2(x[,1]/x[,2])
    M0 <- M==0 ; MP <- M>0 ; MN <- M<0
    pN <- sum(MP,na.rm=TRUE) ; nN <- sum(MN,na.rm=TRUE)
    pPct <- round(100*pN/(pN+nN),0) ; nPct <- round(100*nN/(pN+nN),0)
    pLabel <- paste0("S>A: ",pN," genes (",pPct,"%)")
    nLabel <- paste0("A>S: ",nN," genes (",nPct,"%)")
    title <- paste0(label,"\nSense Expr: ",all.sense.pct,"% Total\nGenes: ",nr)
    
    if (style == "density") {
        rs <- rowSums(x)
        L <- list(`Sense Pct per Gene`=100*x[,1]/rs, `Anti Pct per Gene`=100*x[,2]/rs)
        d <- dhist(L, main=title, legend="top", col=c(2,3), xlim=c(0,100), ...)
        Yr <- abs(diff(d$ylim))/100
        text(50, d$ylim[2]/2+Yr*3, pLabel, col=2)
        text(50, d$ylim[2]/2-Yr*3, nLabel, col=3)
    } else if (style == "MA") {
        Ar <- abs(diff(range(A)))/100
        Mr <- abs(diff(range(M)))/100
        if (jitter) {
            A <- A + runif(length(A),-Ar,Ar) * (1-A/max(A))^2
            M <- M + runif(length(M),-Mr,Mr) * (1-M/max(M))^2
        }
        plot(A, M, col=0, pch=".", main=title, ylab="Log2(Sense/Anti)", xlab="Log2(Sense+Anti)", ...)
        abline(h=0)
        points(A[M0], M[M0], col="#0000FF66", main=title, ylab="M", xlab="A")
        points(A[MN], M[MN], col="#00FF0066", main=title, ylab="M", xlab="A")
        points(A[MP], M[MP], col="#FF000066", main=title, ylab="M", xlab="A")
        text(min(real(A)), max(real(M)), pLabel, c(0.05,0.5), col=2)
        text(min(real(A)), min(real(M)), nLabel, c(0.05,0.2), col=3)
    }
}


#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################


apa.names$microarray <- c(apa.names$microarray, "Affy.QC.plots")
Affy.QC.plots <- function(ab.raw, ab.norm, fit=NULL, cfit=NULL, names=NULL, compares=NULL, smooth=FALSE, ...) {
	
	# norm densities/boxplots, ratio densities/boxplots, corr mat, MA plots
	# If 'compares' specified, make sure that it is correct per the col structure of your input object
	
	raw <- exprs(ab.raw)
	norm <- exprs(ab.norm)
	if (!is.null(names)) { colnames(norm) <- colnames(raw) <- names }
	
	if (require("affyQCReport")) {
		QCReport(ab.norm, filename="Affy_QCReport.pdf")
		affyQAReport(ab.norm, output="pdf", outdir=file.path(getwd(),"affyQA"), overwrite=TRUE, repname=Sys.Date())
	} else {
		cat("affyQCReport did not load (is it installed?), so these reports will be unavailable\n"); flush.console()
	}

	corr.mat(norm, plot=TRUE, filename="Norm_Corrs.png")
	plot.norm.QC (raw, norm, filename="Norm_Effect.png")	
#	MA.plot(obj, smooth=FALSE, fc.lines=NULL, foldcolor=FALSE, monoscale=FALSE, names=NULL, controls=NULL, filename=NULL)

	if (!is.null(fit)) {
		corr.mat(fit$coef, plot=TRUE, filename="Coef_Corrs.png")
		plot.ratio.QC(fit$coef, filename="Coef_Signal.png")	
	}
	if (!is.null(cfit)) {
		plot.ratio.QC(cfit$coef, filename="Ratio_Signal.png")	
	}
	if (!is.null(compares)) {
		plot.ratio.QC(norm, names, compares, filename=)
		plot.sample.scatter(norm, compares, smooth=smooth, filename=)
#		scatter.plot <- function(obj, type="M", smooth=FALSE, fc.lines=c(-2:2), foldcolor=FALSE, monoscale=FALSE, compares=NULL, names=NULL, controls=NULL, filename=NULL)
	}
}


apa.names$microarray <- c(apa.names$microarray, "Agilent.QC.plots")
Agilent.QC.plots <- function(RG, MA, array=NULL, slides=NULL, names=NULL, compares=NULL, smooth=FALSE, ...) {
	
	# norm densities/boxplots, ratio densities/boxplots, corr mat, MA plots 

	if (!require(limma)) { cat("Cannot load limma: control-scatter and 2-slide QC plots will be unavailable!\n"); flush.console() }
	if (!is.null(names)) { colnames(RG) <- colnames(MA) <- names }
	RG2 <- RG.MA(MA)
	
	corr.mat(MA$M, plot=TRUE, filename="Norm_Corrs.png")
	plot.norm.QC(RG, RG2, filename="Norm_Effect.png")	
#	MA.plot(obj, smooth=FALSE, fc.lines=NULL, foldcolor=FALSE, monoscale=FALSE, names=NULL, controls=NULL, filename=NULL)

	if (!is.null(compares)) {
		plot.ratio.QC(MA, names, compares, filename=)
		plot.sample.scatter(MA, compares, smooth=smooth, filename=)
#		scatter.plot <- function(obj, type="M", smooth=FALSE, fc.lines=c(-2:2), foldcolor=FALSE, monoscale=FALSE, compares=NULL, names=NULL, controls=NULL, filename=NULL)
	}

#	Agilent.control.scatters <- function(MA, names, array, ...) 
	
	# inter- and intra- array scatter

	RG <- RG.MA(MA)
	
#	Agilent.2slide.QC <- function(MA, names, array, ...) 
	
	# inter- and intra- array scatter

	RG <- RG.MA(MA)
	
}


apa.names$microarray <- c(apa.names$microarray, "Inhouse.QC.plots")
Inhouse.QC.plots <- function(RG, MA, names, array, ...) {
	
}


apa.names$microarray <- c(apa.names$microarray, "Agilent.wigify")
Agilent.wigify <- function(obj, des.no, smooth=NULL, flat=TRUE, max.aligns=1, remap=NULL, chr.conv=NULL, wig.mat=FALSE) {
	
	## mat is any expression-ratio matrix
	## des.no is the design number of the Agilent array
	## "flat=T" resolves probe overlaps
	
	if (is(obj, "MAList")) {
		values <- obj$M
		precoords <- obj$genes$SystematicName
	} else if (is(obj, "MArrayLM")) {
		values <- obj$coefficients
		precoords <- obj$genes$SystematicName
	} else if (is.matrix(obj) & is.numeric(obj) & !is.null(rownames(obj))) {
		values <- obj
		precoords <- rownames(obj)
	}
	
	## get controls
	ctldata <- parse.controls(idents, arrayID)	# objects: { defLine nonCtl }, maybe { ctlAtt ctlSets }, maybe also { spikeAtt spikeSets spikeLines }
	nonCtl <- ctldata$nonCtl
	
	## parse coords
	if (remap) {
		
		
		## Identify over-aligned probes (since Agilent arrays already come with coordinates, multiple-aligning probes can only be detected by realignment)
		if (is.na(max.aligns)) {
			ok <- nonCtl
		} else {
			ok <- nonCtl[x]
		}
		coords <- ""
	} else {
		coords <- t(sapply(strsplit(precoords[ok], "[:-]"), simplify=TRUE, FUN=function(x){x}))	# 3-col df: chr, start, end
	}
	N <- nrow(coords)
	
	## apply values
	mwig <- data.frame(CHR=coords[,1], START=coords[,2], END=coords[,3], VALUE=values)	# factorize CHR to lower memory
	if (length(unique(mwig$start)) < N) {	# redundant coords
		
		############### will this method work ????
		
		temp <- aggregate(mwig, by=list(mwig[,1], mwig[,2], mwig[,3]), mean)
		mwig <- as.data.frame(temp[,c(1:3,7)])
	}
	
	## resolve overlaps
	if (flat) {
		overlapped <- which(apply(cbind(mwig[1:(N-1),2], mwig[2:N,1]), 1, FUN=function(x){x[2]-x[1]}) < 0)	# probes whose ends overlap their 3' neighbors' starts
		
	}
	
	## smooth
	if (!is.null(smooth)) {
		flank <- ceiling(smooth/2)
		smoothed <- matrix()
	}
	
	if (wig.mat) {
		return(mwig)	# wig matrix
	} else {
		header <- paste("track name=", colnames(mwig), ", description=\"", colnames(mwig), "\", visibility=full, graphType=bar, autoscale=on", sep="")
		tracklist <- vector("list", length=ncol(mwig))
		for (i in 1:ncol(mwig)) { tracklist[[i]] <- c(header[i], paste(rownames(mwig), mwig[,i], sep="\t")) }
		return(tracklist)	# list containing complete, headered wig files
	}
}


apa.names$microarray <- c(apa.names$microarray, "Affy.wigify")
Affy.wigify <- function(mat, bpmap, smooth=1, flat=TRUE, max.aligns=1, remap=NULL, mapfile=NULL, chr.conv=NULL, wig.mat=FALSE) {
	
	## RECOMMENDED TO RUN THIS SERVERSIDE DUE TO HIGH MEM, RUNTIME
# ?	## 'mat' is any expression-ratio matrix
	## 'bpmap=file' points to the appropriate bpmap file
	## 'smooth=N' applies an N-bp smoothing window to output
	## 'flat=T' merges regions of probe overlap into new probes with averaged values
	## 'max.aligns' specifies how many different genomic alignments a probe may have before being dropped.  Value of NA removes the limit.
	## 'remap=genomefastapath' remaps probes using Starr
	## - OR - use 'mapfile=file' to specify an existing Starr remapping file for this array/genome combo
	## 'chr.conv=pairlist' applies old chr name => new chr name conversion
	## 'wig.mat=T' returns a wig matrix, not a list of wigs
	
	if (!require("Starr")) { stop("Cannot load Starr library: unable to continue!\n") }
	
	data <- cbind(data.frame(chr=, start=, end=), as.data.frame(MA$M))
	
	if (wig.mat) {
		return(mwig)	# wig matrix
	} else {
		header <- paste("track name=", colnames(mwig), ", description=\"", colnames(mwig), "\", visibility=full, graphType=bar, autoscale=on", sep="")
		tracklist <- vector("list", length=ncol(mwig))
		for (i in 1:ncol(mwig)) { tracklist[[i]] <- c(header[i], paste(rownames(mwig), mwig[,i], sep="\t")) }
		return(tracklist)	# list containing complete, headered wig files
	}
}


#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################
#######################################################################################################################################



#####  THE FUNCTIONS BELOW ARE STILL UNDER CONSTRUCTION  #####

# source("S:/Genomics/Molbio_Users/APA/R_Things/cluster_kit.R")

apa.names$dev <- c(apa.names$dev, "tables2faticlone")
tables2faticlone <- function(lst, column=1, na.rm=FALSE, names=NULL, id.conv=NULL) {
	
	## assumes excel-ready list of tables, with gene IDs consistently in column 'column'
	## extracts all ids into 2-col matrix; col1 = id col2 = table name (from names(lst))
	## ready for use in /home/apa/local/bin/FatiClone
	## 'column' can also be "rownames"
	## 'na.rm' removes not only NA but also entries with no ID (including post-conversion, if converting IDs)
	## if 'names' is specified it will supplant names(lst)
	## if 'id.conv' is specified, must be 2-col matrix/df with incoming ids in col1 and outgoing ids in col2.  Outgoing IDs should be FatiClone-compatible.
	
	if (is.null(names)) { names <- names(lst) }
	if (column == "rownames") {
		fc <- sapply(1:length(lst), function(x){cbind(rownames(lst[[x]]),names[x])})
	} else {
		fc <- sapply(1:length(lst), function(x){cbind(lst[[x]][,column],names[x])})
	}
	fc <- do.call(rbind, fc)
	if (!is.null(id.conv)) {
		fc[,1] <- id.conv[match(fc[,1],id.conv[,1]),2]
	}
	if (na.rm) { fc <- fc[real(fc[,1],logical=TRUE),] }
	fc
}


apa.names$dev <- c(apa.names$dev, "generate.GO.lists")
generate.GO.lists <- function(mat, conditions_MAYBE, present=NULL, bkg="") {

}


apa.names$general <- c(apa.names$general, "listDims")
listDims <- function(obj, dim.int=TRUE, max.depth=NA) {
	
	## Provides a view of the dimensions of a list object.
	## "internal.dims=T" show dimensions of non-list objects in the list structure.
	## "max.depth" sets max recursion depth.  "0" prevents recursion.  "NA" allows unlimited recursion.
	
	investigate <- function(obj, depth.now, max.depth) {
		
		# recurses to max list depth and constructs list representation of the list
		depth.now <- depth.now + 1
		
		dims <- vector("list", length=length(obj))
		for (i in 1:length(obj)) {
			if (is.nlv(obj[[i]])) {
				if (dim.int) {
					dims[[i]] <- length(obj[[i]])
					names(dims)[i] <- "vector"
				}
			} else if (is.matrix(obj[[i]])) {
				if (dim.int) {
					dims[[i]] <- dim(obj[[i]])
					names(dims)[i] <- "matrix"
				}
			} else if (is.array(obj[[i]])) {
				if (dim.int) {
					dims[[i]] <- dim(obj[[i]])
					names(dims)[i] <- "array"
				}
			} else if (is.data.frame(obj[[i]])) {
				if (dim.int) {
					dims[[i]] <- dim(obj[[i]])
					names(dims)[i] <- "data.frame"
				}
			} else if (is.list(obj[[i]])) {			# recurse through subelements
				if (depth.now < max.depth) {	# then we can go one more level
					dims[[i]] <- investigate(obj[[i]], depth.now, max.depth)
				} else {
					IM("Max recurson depth",max.depth,"reached!")
				}
				names(dims)[i] <- paste("list", length(obj[[i]]))
			} else {	# some custom class?
				if (dim.int) {
					dims[[i]] <- ternary(is.null(dim(obj[[i]])), length(obj[[i]]), dim(obj[[i]]))
					names(dims)[i] <- class(obj[[i]])
				}
			}
		}
		return (dims)
	}
	
	if (is.na(max.depth)) { max.depth <- .Options$expressions }	# current recursion limit
	dims <- investigate(obj, 0, max.depth)
	return(dims)
}


apa.names$general <- c(apa.names$general, "aggregate.list")
aggregate.list <- function(lst, FUN, max.depth=NA) {
	
	## aggregate() for use with lists.  At this time, list elements may ONLY be vectors (including other lists).
	## FUN is the merging function, e.g. sum, mean, min, etc.  DO NOT QUOTE.
	## "max.depth" sets max recursion depth.  "0" prevents recursion.  "NA" allows unlimited recursion.
	
	recurse <- function(lst, depth.now, max.depth) {
		depth.now = depth.now + 1
		
		## Merge namespace redundancies at this level
		x <- which(!duplicated(names(lst)))
		y <- which(duplicated(names(lst)))
		if (length(y) > 0) {	# named elements exist to be combined
			for (i in 1:length(y)) {
				first <- which(names(lst)[x] == names(lst)[y[i]])
				lst[[first]] <- c(lst[[first]], lst[[y[i]]])	# add to first element having same name
			}
			lst <- lst[-y]	# remove duplicates
		}
		
		## Descend to deeper levels (if any)
		for (i in 1:length(lst)) { 
			if (is.ndfl(lst[[i]])) {
				if (depth.now < max.depth) {	# then we can go one more level
					recurse(lst[[i]], depth.now, max.depth)
				} else {
					IM("Max recurson depth",max.depth,"reached!")
				}
			} else {	# hopefully a vector??
				x <- which(!duplicated(names(lst[[i]])))
				y <- which(duplicated(names(lst[[i]])))
				z <- unique(names(lst[[i]][y]))
				if (length(z) > 0) {	# named elements exist to be combined
					for (i in 1:length(z)) {
						w <- which(names(lst[[i]])[y] == z[i])
						first <- which(names(lst[[i]])[x] == z[i])
						lst[[i]][first] <- FUN(c(lst[[i]][first], lst[[i]][w]))	# merge (by FUN) with first element having same name
					}
					lst <- lst[[i]][-y]	# remove duplicates
				}
			}
		}
	}
	
	if (is.na(max.depth)) { max.depth <- .Options$expressions }	# current recursion limit
	heads <- recurse(lst, 0, max.depth)
	print(heads, quote=FALSE)
}


apa.names$general <- c(apa.names$general, "invert.list2")
invert.list2 <- function(list1, dup.rm=TRUE, empty.rm=TRUE, na.rm=FALSE, ignore.names=FALSE, verbose=FALSE) { 
	
	## Inverts a list. The list must have names.  Each element in the list must be:
	##	1. A named list,
	##	2. A named vector of any type (then specify "named=T"),
	##	3. An unnamed character vector.
	## Inverted list will have one element for each unique sublist name found in the original list (or vector element).
	## Inverted list sublists will have length = length input list.
	## "dup.rm" controls removal of duplicate elements in the inverted list, if the inverted list elements are vectors of length > 1.
	## "empty.rm" controls removal of empty elements in the inverted list.  Unnecessary if elements are vectors.
	## "na.rm" controls removal of NA elements in the inverted list or sublists.
	## "ignore.names=T" will ignore any vector names and invert by vector values instead.  Irrelevant if list elements are lists or unnamed vectors.
	## "verbose=T" reports what the function is doing from step to step (for off-the-cuff timing of large list processing)
	## 
	## Example 1:
	##	list( X=list(A=1, B=2, C=3), Y=list(A=4, B=5, C=6), Z=list(A=7, B=8, C=9) )
	## becomes
	##	list( A=list(X=1, Y=4, Z=7), B=list(X=2, Y=5, Z=8), C=list(X=3, Y=6, Z=9) )
	## 
	## Example 2:
	##	list( X=c(1, 2, 3), Y=c(4, 5, 6), Z=c(7, 8, 9) )	: all vectors having the names c("A","B","C")
	## becomes
	##	list( A=c(1, 4, 7), B=c(2, 5, 8), C=c(3, 6, 9) ) : all vectors having the names c("X","Y","Z")
	## 
	## Example 3:
	##	list( X=c("A", "B", "C"), Y=c("A", "B", "D"), Z=c("A", "C", "E") )
	## becomes
	##	list( A=c("X", "Y", "Z"), B=c("X", "Y"), C=c("X", "Z"), D=c("Y"), E=c("Z") )
	
	# prefilter list1 (get rid of uninformative elements prior to anything else)
	if (verbose) { IM("Prefiltering...\n") }
	list1 <- list1[which(listLengths(list1) > 0)]
	if (na.rm) {
		drop1 <- which(is.na(names1))
		if (length(drop1) > 0) { list1 <- list1[-drop1] }
	}
	if (empty.rm) {
		empties1 <- which(listLengths(list1) == 0)
		if (length(empties1) > 0) { list1 <- list1[-empties1] }
	}
	
	# list names
	if (verbose) { IM("Testing list...\n") }
	names1 <- sort(unique(names(list1)))
	if (is.null(names1)) { 
		stop("Input list must be named!\n") 
	} else if (any(names1 == "")) {			# only some list elements are named
		stop("Some input list elements are not named!  Stopping.\n")
	}
	
	# test element consistency
	nlv <- sapply(list1, simplify=TRUE, is.nlv)
	ndfl <- sapply(list1, simplify=TRUE, is.ndfl)
	
	# get names for inverted list
	if (verbose) { IM("Getting sublist names...\n") }
	if (all(nlv)) {
		go.list <- FALSE
		
		# get sublist names
		if (is.null(names(list1[[1]]))) {	# unfortunately cannot do names(unlist(list1)); that will automatically generate names
			if (!ignore.names) { IM("Some subelements do not have names!  Setting 'ignore.names = TRUE'...") }
			ignore.names=TRUE
			names2 <- as.character(sort(unique(unlist(list1))))
		} else {
			names2 <- sort(unique(names(unlist(list1))))
			if (is.null(names2)) {
				if (!ignore.names) { IM("Subelements are unnamed!  Setting 'ignore.names = TRUE'...") }
				ignore.names=TRUE
				names2 <- as.character(sort(unique(unlist(list1))))
			} else if (any(names2 == "")) {		# only some subelements are named
				if (!ignore.names) { IM("Some subelements do not have names!  Setting 'ignore.names = TRUE'...") }
				ignore.names=TRUE
				names2 <- as.character(sort(unique(unlist(list1))))
			}
		}
	} else if (all(ndfl)) {
		go.list <- TRUE
		
		# get sublist names
		names2 <- sort(unique(unlist(lapply(list1, names))))
		if (is.null(names2)) {
			stop("Sublist elements must be named!\n")
		} else if (any(names2 == "")) {			# only some sublist elements are named
			stop("Some sublist elements are not named!  Stopping.\n")
		}
	} else {
		stop("List elements of inconsistent or unsupported type: must be all (non-list) vectors or all (non-data-frame) lists!\n")
	}
	
	# create inverted list
	if (verbose) { IM("Creating inverted list frame...\n") }
	list2 <- vector("list", length=length(names2))
	names(list2) <- names2
	if (go.list) {
		for (i in 1:length(list2)) {
			list2[[i]] <- vector("list", length=length(names1))
			names(list2[[i]]) <- names1
		}
	}
	
	# fill inverted list
	if (verbose) { IM("Filling inverted list frame...\n") }
	if (go.list) {
		for (n2 in names2) {
			empties <- c()
			for (i in 1:length(list1)) {
				n1 <- names1[i]
				if (!is.null(list1[[n1]][[n2]])) { 
					list2[[n2]][[n1]] <- c(list2[[n2]][[n1]], list1[[n1]][[n2]]) 
				} else {
					empties <- c(empties, i)
				}
			}
			if (empty.rm & length(empties) > 0) { list2[[n2]] <- list2[[n2]][-empties] }
		}
	} else {
		for (i in 1:length(list1)) {
			if (ignore.names) {
				xo <- match(list1[[i]], names2)
			} else {
				xo <- match(names(list1[[i]]), names2)
			}
			if (any(is.na(xo))) { stop("Broken element assignments!\n") }
			for (x in 1:length(xo)) { list2[[xo[x]]] <- c(list2[[xo[x]]], names1[i]) }
		}
	}
	
	# postfilter list2
	if (verbose) { IM("Postfiltering...\n") }
	if (na.rm) {
		drop2 <- which(is.na(names2))
		if (length(drop2) > 0) { list2 <- list2[-drop2] }
	}
	if (empty.rm) {
		empties2 <- which(listLengths(list2) == 0)
		if (length(empties2) > 0) { list2 <- list2[-empties2] }
	}
	if (na.rm | empty.rm) {
		for (i in 1:length(list2)) {
			if (go.list) {
				
### MUST ADD SUBLIST ELEMENT HANDLING
				
				if (na.rm) {
					if (ignore.names) {
						drop <- which(is.na(list2[[i]]))
					} else {
						drop <- which(is.na(names(list2[[i]])))
					}
					if (length(drop) > 0) { list2[[i]] <- list2[[i]][-drop] }
				}
				if (empty.rm) {
					empties <- which(listLengths(list2[[i]]) == 0)
					if (length(empties) > 0) { list2[[i]] <- list2[[i]][-empties] }
				}
				if (dup.rm) { list2[[i]] <- list2[[i]][-duplicated(list2[[i]])] }
			} else {
				if (na.rm) {
					if (ignore.names) {
						drop <- which(is.na(list2[[i]]))
					} else {
						drop <- which(is.na(names(list2[[i]])))
					}
					if (length(drop) > 0) { list2[[i]] <- list2[[i]][-drop] }
				}
				if (dup.rm) { list2[[i]] <- list2[[i]][-duplicated(list2[[i]])] }
			}
		}
	}

	return(list2)
}


apa.names$general <- c(apa.names$general, "matchify")
matchify <- function(distmat, fast=TRUE, verbose=FALSE) {
	## distmat must have 4 columns = PSmGS, PSmGE, PEmGS, PEmGE
	signmat <- sign(distmat) 
    if (nrow(signmat) > 1) {
        anymatch <- apply(signmat[,2:3], 1, FUN=function(x){all(x==c(-1,1))})
    } else {
        anymatch <- all(signmat[,2:3]==c(-1,1))
    }
	results <- list(HITS=c(), NNS=c())   # at the moment, no reporting for match type, overlap bp, etc (thus "fast=TRUE" default)
    if (verbose) { IM("matchify: 1") }
    if (fast) {
        hits <- anymatch
    } else {
        if (verbose) { IM("matchify: 2") }
        exact <- apply(signmat[anymatch,c(1,4)], 1, FUN=function(x){all(x==c(0,0))})
        eclipse.p <- apply(signmat[anymatch,c(1,4)], 1, FUN=function(x){all(x[1] %in% 0:1 & x[2] %in% -1:0)})
        eclipse.g <- apply(signmat[anymatch,c(1,4)], 1, FUN=function(x){all(x[1] %in% -1:0 & x[2] %in% 0:1)})
        overlap.5 <- apply(signmat[anymatch,c(1,4)], 1, FUN=function(x){all(x==c(-1,-1))})
        overlap.3 <- apply(signmat[anymatch,c(1,4)], 1, FUN=function(x){all(x==c(1,1))})
        eclipse.p[exact] <- FALSE  # remove any exact hits
        eclipse.g[exact] <- FALSE  # remove any exact hits
        hits <- apply(cbind(eclipse.p,eclipse.g,overlap.5,overlap.3), 1, any)
    }
    if (verbose) { IM("matchify: 3") }
    if (any(hits)) {
        results$HITS <- which(hits)
    } else {
        neighbor.5 <- which(rowSums(signmat) == -4)
        neighbor.3 <- which(rowSums(signmat) == 4)
        nn.5 <- nn.3 <- c()
        if (verbose) { IM("matchify: 4") }
        if (length(neighbor.5) > 0) {
            dists.5 <- abs(distmat[neighbor.5,2])
            nn.5 <- neighbor.5[dists.5==min(dists.5)]
            nn.5 <- nameless(cbind(nn.5, rep(min(dists.5), length(nn.5))))
            if (verbose) { IM("matchify: 5") }
        }
        if (length(neighbor.3) > 0) {
            if (verbose) { IM("matchify: 6") }
            dists.3 <- distmat[neighbor.3,3]
            nn.3 <- neighbor.3[dists.3==min(dists.3)]
            nn.3 <- nameless(cbind(nn.3, rep(min(dists.3), length(nn.3))))
            if (verbose) { IM("matchify: 7") }
        }
        results$NNS <- list(NN5=nn.5, NN3=nn.3)
        if (verbose) { IM("matchify: 8") }
    }
	return(results)
}


apa.names$general <- c(apa.names$general, "place.peak")
place.peak <- function(pcoords, matchto, verbose=FALSE, exons=TRUE) {
    
    ## pcoords = row-list from a bed file data frame: chr start end id; more fields optional
    ## matchto = bed file data frame of coords to match "pcoords" to
    
    if (!is.data.frame(pcoords)) {  # e.g. coming from apply()
        pcoords <- as.data.frame(as.list(pcoords), stringsAsFactors=FALSE)
        for (i in 2:3) { mode(pcoords[,i]) <- "numeric" }
    }
	colnames(pcoords)[1:4] <- c("Chr","Start","End","Peak")
    if (exons) {
        results <- list(TYPE=c(),PEAK=pcoords,EXON=c(),INTR=c(),ITGC=c())
    } else {
        results <- list(TYPE=c(),PEAK=pcoords,GENE=c(),ITGC=c())
    }
	if (verbose) { IM(pcoords[[1]], dim(matchto)) }
	chrgenes <- matchto[matchto[,1]==pcoords[[1]],]
	colnames(chrgenes)[1:4] <- c("Chr","Start","End","Gene")
    if (verbose) { IM("place.peak: 0 :",pcoords,":",dim(chrgenes)) }
	PSmGS <- pcoords[[2]] - chrgenes[,2]
	PSmGE <- pcoords[[2]] - chrgenes[,3]
	PEmGS <- pcoords[[3]] - chrgenes[,2]
	PEmGE <- pcoords[[3]] - chrgenes[,3]
    if (verbose) { IM("place.peak: 1") }
	gresults <- matchify(cbind(PSmGS,PSmGE,PEmGS,PEmGE), verbose=verbose)
    if (verbose) { IM("place.peak: 2") }
	if (length(gresults$HITS)>0) {   # gene hits
        if (exons) {
            if (verbose) { IM("place.peak: 3") }
            xhits <- ihits <- list(c()); xN <- iN <- 0
            for (gene in chrgenes[gresults$HITS,4]) {
                if (verbose) { IM("place.peak: 4") }
                exons <- ebed[ebed[,7]==gene,]
                colnames(chrgenes) <- c("Chr","Start","End","Gene","Score","Strand")
                PSmXS <- pcoords[[2]] - exons[,2]
                PSmXE <- pcoords[[2]] - exons[,3]
                PEmXS <- pcoords[[3]] - exons[,2]
                PEmXE <- pcoords[[3]] - exons[,3]
                if (verbose) { IM("place.peak: 5: exon matchify",nrow(exons)) }
                xresults <- matchify(cbind(PSmXS,PSmXE,PEmXS,PEmXE), verbose=verbose)
                if (verbose) { IM("place.peak: 6") }
                if (length(xresults$HITS)>0) {   # exon hits
                    if (verbose) { IM("place.peak: 7") }
                    xN <- xN + 1
                    xhits[[xN]] <- exons[unlist(xresults$HITS),]  # exon hits
                } else {
                    if (verbose) { IM("place.peak: 8") }
                    iN <- iN + 1
                    introns <- do.call(rbind, xresults$NNS)
                    ihits[[iN]] <- cbind(exons[introns[,1],], introns[,2])   # exon nearest neighbors
                }
                if (verbose) { IM("place.peak: 9") }
            }
            if (length(xhits) > 0) {
                results$TYPE <- "EXON"
                results$EXON <- unique(do.call(rbind, xhits))
            } 
            if (length(ihits) > 0) {
                results$TYPE <- "INTR"
                results$INTR <- unique(do.call(rbind, ihits))
                if (!is.null(results$INTR)) { colnames(results$INTR)[ncol(results$INTR)] <- "Distance" }  # can get empty results
            }
            if (verbose) { IM("place.peak: 10") }
        } else {
            if (verbose) { IM("place.peak: G1") }
            results$TYPE <- "GENE"
            results$GENE <- chrgenes[gresults$HITS,]
            if (verbose) { IM("place.peak: G2") }
        }
    } else {
        if (verbose) { IM("place.peak: 11") }
        results$TYPE <- "ITGC"
        intergenes <- do.call(rbind, gresults$NNS)
        results$ITGC <- cbind(chrgenes[intergenes[,1],], intergenes[,2])
        if (!is.null(results$ITGC)) { colnames(results$ITGC)[ncol(results$ITGC)] <- "Distance" }  # can get empty results
        if (verbose) { IM("place.peak: 12") }
	}
	return(results)
}


apa.names$plots <- c(apa.names$plots, "placement.graph")
placement.graph <- function(place.list, label) {
	types <- rep(0,3); names(types) <- c("EXON","INTR","ITGC")
	dists <- c()
	for (i in 1:length(place.list)) {
#        IM(i)
        if (length(place.list[[i]]$EXON) > 0) {
            types[1] <- types[1] + 1
        } else if (length(place.list[[i]]$INTR) > 0) {
            types[2] <- types[2] + 1
        } else {
            types[3] <- types[3] + 1
            dists <- c(dists, min(place.list[[i]]$ITGC[,7]))
        }
	}
	par(mfrow=c(1,2), cex=1.2)
    if (length(dists) > 2) {
#        IM("A",length(dists))
        dhist(list(log2(dists)), legend=NULL, main="Nearest-Neighbor Distance, Log2", xlab="Log2 Bp")
    } else {
#        IM("B",length(dists))
        null.plot(main="Nearest-Neighbor Distance, Log2")
    }
#    IM("C")
    barplot(rev(types), horiz=TRUE, main=paste("Features Hit By Peaks:",label))
}


apa.names$dev <- c(apa.names$dev, "disgregation")
disgregation <- function(vec, binary=FALSE) {
    
    ## Measures the disgregation of a factor or vector
    ## For a factor of length N there are N-1 unit scores.
    ## For 'binary=F', the true spatial disgregation degree is calculated.  Final score is a percent of maximum possible disgregation. 
    ## ** NOT READY ** For 'binary=T' each score is either perfect or not.  Final score is the percent of perfect unit scores.
    
    if (is.factor(vec)) { vec <- as.numeric(vec) }

    ## maximum possible disgregation value
    N <- length(vec)
    tab <- table(vec)
    Ngrps <- length(tab)
	largest <- which(tab==max(tab))
	Nlargest <- tab[largest]
	Nwith2 <- sum(tab>=2)
	if (Nlargest >= 2) { Nwith2 <- Nwith2 - 1 }
	Nothers <- sum(tab[-largest])
#	IM(names(tab), ":", tab, ":", largest, Nlargest, Nwith2, Nothers)
#    offset <- N - Ngrps
	max.dis <- Nlargest * Nwith2 + Nothers

    scores <- c()
	for (i in 1:max(vec)) { scores <- c(scores, diff(which(vec==i))) }
	(max.dis-sum(scores)) / max.dis

    
}


apa.names$hacks <- c(apa.names$hacks, "plot.phylo2")
plot.phylo2 <- function (x, type="phylogram", use.edge.length=TRUE, node.pos=NULL, show.tip.label=TRUE, show.node.label=FALSE, edge.color="black", edge.width=1, edge.lty=1, font=3, cex=par("cex"), adj=NULL, 
    srt=0, no.margin=FALSE, root.edge=FALSE, label.offset=0, underscore=FALSE, x.lim=NULL, y.lim=NULL, direction="rightwards", lab4ut="horizontal", tip.color="black", plot=TRUE, leaf.just=FALSE, lab.just=FALSE, ...) {
	
	require("ape")
	stuff1 <- stuff2 <- c()
    Ntip <- length(x$tip.label)
    if (Ntip == 1) {
        warning("found only one tip in the tree")
        return(NULL)
    }
    if (any(tabulate(x$edge[, 1]) == 1)) { stop("there are single (non-splitting) nodes in your tree; you may need to use collapse.singles()") }
    .nodeHeight <- function(Ntip, Nnode, edge, Nedge, yy) {
		.C("node_height", as.integer(Ntip), as.integer(Nnode), as.integer(edge[,1]), as.integer(edge[, 2]), as.integer(Nedge), as.double(yy), DUP = FALSE, PACKAGE = "ape")[[6]]
	}
    .nodeDepth <- function(Ntip, Nnode, edge, Nedge) {
		.C("node_depth", as.integer(Ntip), as.integer(Nnode), as.integer(edge[,1]), as.integer(edge[, 2]), as.integer(Nedge), double(Ntip + Nnode), DUP = FALSE, PACKAGE = "ape")[[6]]
    }
	.nodeDepthEdgelength <- function(Ntip, Nnode, edge, Nedge, edge.length) {
		.C("node_depth_edgelength", as.integer(Ntip), as.integer(Nnode), as.integer(edge[, 1]), as.integer(edge[,2]), as.integer(Nedge), as.double(edge.length), double(Ntip + Nnode), DUP = FALSE, PACKAGE = "ape")[[7]]
    }
	Nedge <- dim(x$edge)[1]
    Nnode <- x$Nnode
    ROOT <- Ntip + 1
    type <- match.arg(type, c("phylogram", "cladogram", "fan", "unrooted", "radial"))
    direction <- match.arg(direction, c("rightwards", "leftwards", "upwards", "downwards"))
    if (is.null(x$edge.length)) { use.edge.length <- FALSE }
    if (type %in% c("unrooted", "radial") || !use.edge.length || is.null(x$root.edge) || !x$root.edge) { root.edge <- FALSE }
    if (type == "fan" && root.edge) {
		warning("drawing root edge with type = 'fan' is not yet supported")
        root.edge <- FALSE
    }
    phyloORclado <- type %in% c("phylogram", "cladogram")
    horizontal <- direction %in% c("rightwards", "leftwards")
    xe <- x$edge
    if (phyloORclado) {
        phyOrder <- attr(x, "order")
        if (is.null(phyOrder) || phyOrder != "cladewise") {
            x <- reorder(x)
            if (!identical(x$edge, xe)) {
                ereorder <- match(x$edge[, 2], xe[, 2])
                if (length(edge.color) > 1) {
					edge.color <- rep(edge.color, length.out = Nedge)
					edge.color <- edge.color[ereorder]
                }
                if (length(edge.width) > 1) {
					edge.width <- rep(edge.width, length.out = Nedge)
					edge.width <- edge.width[ereorder]
                }
                if (length(edge.lty) > 1) {
					edge.lty <- rep(edge.lty, length.out = Nedge)
					edge.lty <- edge.lty[ereorder]
                }
            }
        }
        yy <- numeric(Ntip + Nnode)
        TIPS <- x$edge[x$edge[, 2] <= Ntip, 2]
        yy[TIPS] <- 1:Ntip
    }
    z <- reorder(x, order = "pruningwise")
    if (phyloORclado) {
        if (is.null(node.pos)) {
            node.pos <- 1
            if (type == "cladogram" && !use.edge.length) { node.pos <- 2 }
        }
        if (node.pos == 1) { 
			yy <- .nodeHeight(Ntip, Nnode, z$edge, Nedge, yy) 
		} else {
            ans <- .C("node_height_clado", as.integer(Ntip), as.integer(Nnode), as.integer(z$edge[, 1]), as.integer(z$edge[,2]), as.integer(Nedge), double(Ntip + Nnode), as.double(yy), DUP = FALSE, PACKAGE = "ape")
            xx <- ans[[6]] - 1
            yy <- ans[[7]]
        }
        if (!use.edge.length) {
            if (node.pos != 2) {  xx <- .nodeDepth(Ntip, Nnode, z$edge, Nedge) - 1 }
            xx <- max(xx) - xx
        } else {
            xx <- .nodeDepthEdgelength(Ntip, Nnode, z$edge, Nedge, z$edge.length)
        }
    } else {
		switch(type, 
			fan = {
				TIPS <- x$edge[which(x$edge[, 2] <= Ntip), 2]
				xx <- seq(0, 2 * pi * (1 - 1/Ntip), 2 * pi/Ntip)
				theta <- double(Ntip)
				theta[TIPS] <- xx
				theta <- c(theta, numeric(Nnode))
				theta <- .nodeHeight(Ntip, Nnode, z$edge, Nedge, theta)
				if (use.edge.length) {
					r <- .nodeDepthEdgelength(Ntip, Nnode, z$edge, Nedge, z$edge.length)
				} else {
					r <- .nodeDepth(Ntip, Nnode, z$edge, Nedge)
					r <- 1/r
				}
				xx <- r * cos(theta)
				yy <- r * sin(theta)
			}, 
			unrooted = {
				nb.sp <- .nodeDepth(Ntip, Nnode, z$edge, Nedge)
				XY <- if (use.edge.length) {
						unrooted.xy(Ntip, Nnode, z$edge, z$edge.length, nb.sp) 
					} else { 
						unrooted.xy(Ntip, Nnode, z$edge, rep(1, Nedge), nb.sp)
					}
				xx <- XY$M[, 1] - min(XY$M[, 1])
				yy <- XY$M[, 2] - min(XY$M[, 2])
			}, 
			radial = {
				X <- .nodeDepth(Ntip, Nnode, z$edge, Nedge)
				X[X == 1] <- 0
				X <- 1 - X/Ntip
				yy <- c((1:Ntip) * 2 * pi/Ntip, rep(0, Nnode))
				Y <- .nodeHeight(Ntip, Nnode, z$edge, Nedge, yy)
				xx <- X * cos(Y)
				yy <- X * sin(Y)
			}
		)
	}
    if (phyloORclado) {
        if (!horizontal) {
            tmp <- yy
            yy <- xx
            xx <- tmp - min(tmp) + 1
        }
        if (root.edge) {
            if (direction == "rightwards") { xx <- xx + x$root.edge }
            if (direction == "upwards") { yy <- yy + x$root.edge }
        }
    }
    if (no.margin) { par(mai = rep(0, 4)) }
    if (is.null(x.lim)) {
        if (phyloORclado) {
            if (horizontal) {
                x.lim <- c(0, NA)
                pin1 <- par("pin")[1]
                strWi <- strwidth(x$tip.label, "inches")
                xx.tips <- xx[1:Ntip] * 1.04
                alp <- try(uniroot(function(a) max(a * xx.tips + strWi) - pin1, c(0, 1e+06))$root, silent = TRUE)
                if (is.character(alp)) {
					tmp <- max(xx.tips) * 1.5
                } else {
                  tmp <- ifelse (show.tip.label, max(xx.tips + strWi/alp), max(xx.tips))
                }
                x.lim[2] <- tmp
            } else {
				x.lim <- c(1, Ntip)
			}
        } else {
			switch(type, 
				fan = {
					if (show.tip.label) {
						offset <- max(nchar(x$tip.label) * 0.018 * max(yy) * cex)
						x.lim <- c(min(xx) - offset, max(xx) + offset)
					} else {
						x.lim <- c(min(xx), max(xx))
					}
				}, 
				unrooted = {
					if (show.tip.label) {
						offset <- max(nchar(x$tip.label) * 0.018 * max(yy) * 
						  cex)
						x.lim <- c(0 - offset, max(xx) + offset)
					} else x.lim <- c(0, max(xx))
				},
				radial = {
					if (show.tip.label) {
						offset <- max(nchar(x$tip.label) * 0.03 * cex)
						x.lim <- c(-1 - offset, 1 + offset)
					} else x.lim <- c(-1, 1)
				}
			)
		}
	} else if (length(x.lim) == 1) {
        x.lim <- c(0, x.lim)
        if (phyloORclado && !horizontal) { x.lim[1] <- 1 }
        if (type %in% c("fan", "unrooted") && show.tip.label) { x.lim[1] <- -max(nchar(x$tip.label) * 0.018 * max(yy) * cex) }
        if (type == "radial") { x.lim[1] <- ifelse (show.tip.label, -1 - max(nchar(x$tip.label) * 0.03 * cex), -1) }
    }
    if (phyloORclado && direction == "leftwards") { xx <- x.lim[2] - xx }
    if (is.null(y.lim)) {
        if (phyloORclado) {
            if (horizontal) {
                y.lim <- c(1, Ntip)
			} else {
                y.lim <- c(0, NA)
                pin2 <- par("pin")[2]
                strWi <- strwidth(x$tip.label, "inches")
                yy.tips <- yy[1:Ntip] * 1.04
                alp <- try(uniroot(function(a) max(a * yy.tips + strWi) - pin2, c(0, 1e+06))$root, silent = TRUE)
                if (is.character(alp)) {
					tmp <- max(yy.tips) * 1.5
                } else {
					tmp <- ifelse (show.tip.label, max(yy.tips + strWi/alp), max(yy.tips))
                }
                y.lim[2] <- tmp
            }
        } else {
			switch(type, 
				fan = {
					if (show.tip.label) {
						offset <- max(nchar(x$tip.label) * 0.018 * max(yy) * cex)
						y.lim <- c(min(yy) - offset, max(yy) + offset)
					} else {
						y.lim <- c(min(yy), max(yy))
					}
				}, unrooted = {
					if (show.tip.label) {
						offset <- max(nchar(x$tip.label) * 0.018 * max(yy) * cex)
						y.lim <- c(0 - offset, max(yy) + offset)
					} else {
						y.lim <- c(0, max(yy))
					}
				}, radial = {
					if (show.tip.label) {
						offset <- max(nchar(x$tip.label) * 0.03 * cex)
						y.lim <- c(-1 - offset, 1 + offset)
					} else {
						y.lim <- c(-1, 1)
					}
				}
			)
		}
    } else if (length(y.lim) == 1) {
        y.lim <- c(0, y.lim)
        if (phyloORclado && horizontal) { y.lim[1] <- 1 }
        if (type %in% c("fan", "unrooted") && show.tip.label) { y.lim[1] <- -max(nchar(x$tip.label) * 0.018 * max(yy) * cex) }
        if (type == "radial") { y.lim[1] <- ifelse (show.tip.label, -1 - max(nchar(x$tip.label) * 0.018 * max(yy) * cex), -1) }
    }
    if (phyloORclado && direction == "downwards") { yy <- y.lim[2] - yy }
    if (phyloORclado && root.edge) {
        if (direction == "leftwards") { x.lim[2] <- x.lim[2] + x$root.edge }
        if (direction == "downwards") { y.lim[2] <- y.lim[2] + x$root.edge }
    }
    asp <- ifelse(type %in% c("fan", "radial", "unrooted"), 1, NA)
	stuff1 <- list(x=0, type = "n", xlim = x.lim, ylim = y.lim, ann = FALSE, axes = FALSE, asp = asp, ...)
    plot(0, type = "n", xlim = x.lim, ylim = y.lim, ann = FALSE, axes = FALSE, asp = asp, ...)
    if (plot) {
        if (is.null(adj)) { adj <- ifelse (phyloORclado && direction == "leftwards", 1, 0) }
		if (phyloORclado && show.tip.label) {
            MAXSTRING <- max(strwidth(x$tip.label, cex = cex))
            loy <- 0
            if (direction == "rightwards") {
                lox <- label.offset + MAXSTRING * 1.05 * adj
            }
            if (direction == "leftwards") {
                lox <- -label.offset - MAXSTRING * 1.05 * (1 - adj)
            }
            if (!horizontal) {
                psr <- par("usr")
                MAXSTRING <- MAXSTRING * 1.09 * (psr[4] - psr[3])/(psr[2] - psr[1])
                loy <- label.offset + MAXSTRING * 1.05 * adj
                lox <- 0
                srt <- 90 + srt
                if (direction == "downwards") {
					loy <- -loy
					srt <- 180 + srt
                }
            }
        }
        if (type == "phylogram") {
            phylogram.plot(x$edge, Ntip, Nnode, xx, yy, horizontal, edge.color, edge.width, edge.lty)
        } else {
            if (type == "fan") {
                ereorder <- match(z$edge[, 2], x$edge[, 2])
                if (length(edge.color) > 1) {
					edge.color <- rep(edge.color, length.out = Nedge)
					edge.color <- edge.color[ereorder]
                }
                if (length(edge.width) > 1) {
					edge.width <- rep(edge.width, length.out = Nedge)
					edge.width <- edge.width[ereorder]
                }
                if (length(edge.lty) > 1) {
					edge.lty <- rep(edge.lty, length.out = Nedge)
					edge.lty <- edge.lty[ereorder]
                }
				stuff2 <- list(z.edge=z$edge, Ntip=Ntip, Nnode=Nnode, xx=xx, yy=yy, theta=theta, r=r, edge.color=edge.color, edge.width=edge.width, edge.lty=edge.lty)
                circular.plot(z$edge, Ntip, Nnode, xx, yy, theta, r, edge.color, edge.width, edge.lty)
			} else {
				stuff2 <- list(x.edge=x$edge, xx=xx, yy=yy, edge.color=edge.color, edge.width=edge.width, edge.lty=edge.lty)
				cladogram.plot(x$edge, xx, yy, edge.color, edge.width, edge.lty)
			}
        }
        if (root.edge) 
            switch(direction, 
				rightwards = segments(0, yy[ROOT], x$root.edge, yy[ROOT]), 
				leftwards = segments(xx[ROOT], yy[ROOT], xx[ROOT] + x$root.edge, yy[ROOT]), 
				upwards = segments(xx[ROOT], 0, xx[ROOT], x$root.edge), 
				downwards = segments(xx[ROOT], yy[ROOT], xx[ROOT], yy[ROOT] + x$root.edge)
			)
        if (show.tip.label) {
            if (is.expression(x$tip.label)) { underscore <- TRUE }
            if (!underscore) { x$tip.label <- gsub("_", " ", x$tip.label) }
            if (phyloORclado) { text(xx[1:Ntip] + lox, yy[1:Ntip] + loy, x$tip.label, adj = adj, font = font, srt = srt, cex = cex, col = tip.color) }
            if (type == "unrooted") {
                if (lab4ut == "horizontal") {
					y.adj <- x.adj <- numeric(Ntip)
					sel <- abs(XY$axe) > 0.75 * pi
					x.adj[sel] <- -strwidth(x$tip.label)[sel] * 1.05
					sel <- abs(XY$axe) > pi/4 & abs(XY$axe) < 0.75 * pi
					x.adj[sel] <- -strwidth(x$tip.label)[sel] * (2 * abs(XY$axe)[sel]/pi - 0.5)
					sel <- XY$axe > pi/4 & XY$axe < 0.75 * pi
					y.adj[sel] <- strheight(x$tip.label)[sel]/2
					sel <- XY$axe < -pi/4 & XY$axe > -0.75 * pi
					y.adj[sel] <- -strheight(x$tip.label)[sel] * 0.75
					text(xx[1:Ntip] + x.adj * cex, yy[1:Ntip] + y.adj * cex, x$tip.label, adj = c(adj, 0), font = font, srt = srt, cex = cex, col = tip.color)
                } else {
					adj <- abs(XY$axe) > pi/2
					srt <- 180 * XY$axe/pi
					srt[adj] <- srt[adj] - 180
					adj <- as.numeric(adj)
					xx.tips <- xx[1:Ntip]
					yy.tips <- yy[1:Ntip]
					if (label.offset) {
						xx.tips <- xx.tips + label.offset * cos(XY$axe)
						yy.tips <- yy.tips + label.offset * sin(XY$axe)
					}
					font <- rep(font, length.out = Ntip)
					tip.color <- rep(tip.color, length.out = Ntip)
					cex <- rep(cex, length.out = Ntip)
					for (i in 1:Ntip) { 
						text(xx.tips[i], yy.tips[i], cex = cex[i], x$tip.label[i], adj = adj[i], font = font[i], srt = srt[i], col = tip.color[i])
					}
                }
            }
            if (type %in% c("fan", "radial")) {
                xx.tips <- xx[1:Ntip]
                yy.tips <- yy[1:Ntip]
                rawangle <- atan2(yy.tips, xx.tips)
                if (label.offset) {
					xx.tips <- xx.tips + label.offset * cos(angle)
					yy.tips <- yy.tips + label.offset * sin(angle)
                }
                s <- xx.tips < 0
                angle <- rawangle * 180/pi
                angle[s] <- angle[s] + 180
                adj <- as.numeric(s)
                font <- rep(font, length.out = Ntip)
                tip.color <- rep(tip.color, length.out = Ntip)
                cex <- rep(cex, length.out = Ntip)
				radii <- sapply(1:Ntip, FUN=function(i){sqrt(xx.tips[i]^2+yy.tips[i]^2)})
                for (i in 1:Ntip) {
					tx <- xx.tips[i]
					ty <- yy.tips[i]
					if (lab.just) {
						just <- max(radii) - radii[i] + 1
						tx <- tx + just * cos(rawangle[i])
						ty <- ty + just * sin(rawangle[i])
					}
					text(tx, ty, x$tip.label[i], font = font[i], cex = cex[i], srt = angle[i], adj = adj[i], col = tip.color[i], family = "mono")
				}
            }
        }
        if (show.node.label) {
            text(xx[ROOT:length(xx)] + label.offset, yy[ROOT:length(yy)], x$node.label, adj = adj, font = font, srt = srt, cex = cex)
		}
    }
    L <- list(type = type, use.edge.length = use.edge.length, 
        node.pos = node.pos, show.tip.label = show.tip.label, 
        show.node.label = show.node.label, font = font, cex = cex, 
        adj = adj, srt = srt, no.margin = no.margin, label.offset = label.offset, 
        x.lim = x.lim, y.lim = y.lim, direction = direction, 
        tip.color = tip.color, Ntip = Ntip, Nnode = Nnode)
    assign("last_plot.phylo", c(L, list(edge = xe, xx = xx, yy = yy)), envir = .PlotPhyloEnv)
#	return(list(stuff1, stuff2))
    invisible(L)
}


apa.names$hacks <- c(apa.names$hacks, "circular.plot2")
circular.plot2 <- function (edge, Ntip, Nnode, xx, yy, theta, r, edge.color, edge.width, edge.lty, leaf.just) {
	
	### UNDER CONSTRUCTION -- will plot justified (cladogram-style) leaf edges which extend to the margin
	
    r0 <- r[edge[,1]]
    r1 <- r[edge[,2]]
    theta0 <- theta[edge[,2]]
    costheta0 <- cos(theta0)
    sintheta0 <- sin(theta0)
    x0 <- r0 * costheta0
    y0 <- r0 * sintheta0
    x1 <- r1 * costheta0
    y1 <- r1 * sintheta0
    segments(x0, y0, x1, y1, col = edge.color, lwd = edge.width, lty = edge.lty)
    tmp <- which(diff(edge[,1]) != 0)
    start <- c(1, tmp + 1)
    Nedge <- dim(edge)[1]
    end <- c(tmp, Nedge)
    foo <- function(edge.feat, default) {
        if (length(edge.feat) == 1) {
            return(rep(edge.feat, Nnode))
        } else {
            edge.feat <- rep(edge.feat, length.out = Nedge)
            feat.arc <- rep(default, Nnode)
            for (k in 1:Nnode) {
                tmp <- edge.feat[start[k]]
                if (tmp == edge.feat[end[k]]) { feat.arc[k] <- tmp }
            }
        }
        feat.arc
    }
    co <- foo(edge.color, "black")
    lw <- foo(edge.width, 1)
    ly <- foo(edge.lty, 1)
    for (k in 1:Nnode) {
        i <- start[k]
        j <- end[k]
        X <- rep(r[edge[i,1]], 100)
        Y <- seq(theta[edge[i,2]], theta[edge[j,2]], length.out = 100)
        lines(X * cos(Y), X * sin(Y), col = co[k], lwd = lw[k], lty = ly[k])
    }
}


apa.names$dev <- c(apa.names$dev, "FatiClone")
FatiClone <- function(map, db, taxon, bkg.model="genome", levels=c(3,9), alpha=0.05, p.adjust="BH", tails=2, Fclev=0.95, 
	no.dups=FALSE, no.under=FALSE, no.over=FALSE, adjust.all=FALSE, flag.sig.parents=FALSE, flag.sig.children=FALSE, no.sig.parents=FALSE, no.sig.children=FALSE, 
	show.dbs=FALSE, show.taxa=FALSE, intermediate=TRUE, remove.temp=TRUE, genome=NULL, other.annot=NULL, host=NULL, term.OD=NULL, use.DB=NULL, write.dir=NULL) {
	
	## THIS FUNCTION ONLY RUNS ON LINUX SERVERS
	## An interface to /home/apa/local/bin/FatiClone; call with --help to see description of parameters.
	## 'showDBs' and 'showtaxa' override all other arguments and return lists of GO DBs and major taxa.
	## 'intermediate' and 'remove.temp' are not a FatiClone argument:
	##	- 'intermediate' specifies whether to read in FC intermediate data as well as final data (= numbers for all terms)
	##	- 'remove.temp' deletes temp directory after function completes
	
	if (Sys.info()[["sysname"]] != "Linux") { stop("This function can only be run on the Linux servers!\n") }
	if (show.dbs) {
		msg <- system("/home/apa/local/bin/FatiClone --showdbs", intern=TRUE)
		for (i in 1:length(msg)) { IM(msg[i]) }
	} else if (show.taxa) {
		msg <- system("/home/apa/local/bin/FatiClone --showtaxa", intern=TRUE)
		for (i in 1:length(msg)) { IM(msg[i]) }
	} else {
		FC.temp <- tempfile("FatiCloneR")
		system(paste("mkdir -p",FC.temp))
		write.table(map, paste(FC.temp,"map.txt",sep="/"), sep="\t", quote=FALSE, row.names=TRUE, col.names=c(paste("GENE",colnames(map)[1],sep="\t"),colnames(map)[2:ncol(map)]))
		if (length(genome)>0) {
			gfile <- paste(FC.temp,"genome.txt",sep="/")
			write.vector(genome, gfile, sep="\t", quote=FALSE, row.names=FALSE, col.names=FALSE)
			genome <- gfile
		}
		if (length(other.annot)>0) {
			ofile <- paste(FC.temp,"other.annot.txt",sep="/")
			write.table(other.annot, ofile, sep="\t", quote=FALSE, row.names=FALSE, col.names=TRUE)
			other.annot <- ofile
		}
		if (is.null(write.dir)) {
			write.dir <- paste(FC.temp,"output",sep="/")
			system(paste("mkdir -p",write.dir))
		}
		
		params1 <- list(
			levels=list("-l", ternary(all(levels%in%c(3,9)), NULL, paste(levels, collapse="-"))), 
			alpha=list("-a", ternary(alpha == 0.05, NULL, alpha)), 
			p.adjust=list("-j", ternary(p.adjust == "BH", NULL, p.adjust)), 
			tails=list("-t", ternary(tails == 2, NULL, tails)), 
			Fclev=list("-v", ternary(Fclev == 0.95, NULL, Fclev)), 
			genome=list("-g", genome), 
			other.annot=list("-o", other.annot), 
			host=list("-h", host), 
			term.OD=list("-r", term.OD), 
			use.DB=list("-u", use.DB)
		)
		params2 <- list(
			no.dups=list("--nodups", no.dups), 
			no.under=list("--nounder", no.under), 
			no.over=list("--noover", no.over), 
			adjust.all=list("--adjustall", adjust.all), 
			flag.sig.parents=list("--flag_sig_parents", flag.sig.parents), 
			flag.sig.children=list("--flag_sig_children", flag.sig.children), 
			no.sig.parents=list("--no_sig_parents", no.sig.parents), 
			no.sig.children=list("--no_sig_children", no.sig.children)
		)
		
		FC.call <- paste("/home/apa/local/bin/FatiClone -f ",FC.temp,"/map.txt"," -b ",bkg.model," -d ",db," -x ",taxon," -w ",write.dir,sep="")
		for (i in 1:length(params1)) {
			if (length(params1[[i]][[2]])>0) {
				FC.call <- paste(FC.call, params1[[i]][[1]], params1[[i]][[2]])
			}
		}
		for (i in 1:length(params2)) {
			if (params2[[i]][[2]]) {
				FC.call <- paste(FC.call, params2[[i]][[1]])
			}
		}
		
		msg <- system(FC.call, intern=TRUE)
		terms.file <- dir(FC.temp, patt="significant_terms.txt$")[1]    # had better only be one! (or perhaps none)
		genes.file <- dir(FC.temp, patt="significant_genelist.txt$")[1]
		plot.file <- dir(FC.temp, patt="Plot_Table.txt$")[1]
		terms <- read.delim(paste(FC.temp, terms.file, sep="/"))
		genes <- read.delim(paste(FC.temp, genes.file, sep="/"))
		if (intermediate) {
			inter.table <- read.delim(paste(FC.temp,"FatiClone_Fishers_input.txt",sep="/"), header=FALSE)
			colnames(inter.table) <- qw(MAP,CLUST,DB,LEVEL,TERM,FG.W,FG.WO,BG.W,BG.WO,FG.PCT,BG.PCT,LOG2FC,TERM.W,TERM.PCT,ENRICH)
			term.table <- read.delim(paste(FC.temp,"FatiClone_term_table.txt",sep="/"))
			FC.dat <- list(terms=terms, genes=genes, msg=msg, intermediate=inter.table, term.table=term.table)
		} else {
			FC.dat <- list(terms=terms, genes=genes, msg=msg)
		}
		if (ncol(map)>1) {	# will have generated plot data
			FC.dat$plot.file <- read.delim(paste(FC.temp,plot.file,sep="/"))
		}
		if (remove.temp) {
			system("rm -Rf FC.temp")
		}
		return(FC.dat)
	}
}


apa.names$plots <- c(apa.names$plots, "gradient.census")
gradient.census <- function(x, axis, breaks, pal=NULL, alpha=0.25, width=NULL, ablines=FALSE, labels=NULL) {
	
	## histograms a vector 'x' according to 'breaks', then returns membership counts for each bin.
	## 'breaks' is either a vector of > 1 break values, or a single value indicating how many breaks.  If a vector, defines length(breaks)-1 bins.
	## if 'x' has been plotted, this will plot transparent color bands onto the plot, with membership numbers.
	## 'axis' = 1/2, indicating that breaks are applied to x-axis (1) or y-axis(2)
	## 'pal' indicates the palette to use; must have one color per bin.  If NULL then no color bands appear.  DO NOT MAKE PALETTE ITSELF TRANSPARENT; use 'alpha'.
	## 'alpha' is an opacity percent on [0,1].
	## 'width' is also required to indicate the other dimensions of the color bands (which are rect() calls).  Thus if axis=1, need ymin & ymax for rect(), so set 'width=range(y)' or something.
	## 'ablines' will plot ablines at the breaks.
	## 'labels' same as 'x' in legend().  If specified, will plot the membership numbers in each band, in the color of that band (but not transparent).
	##   NOTE: if 'axis' = 1, only "right", "left", "center" are meaningful; for 'axis' = 2, only "top", "bottom", "center".
	
	if (axis != 1 & axis != 2) { stop("'axis' must be 1 or 2!\n") }
	if (length(breaks) == 1) {
		Nbr <- breaks
		breaks <- seq(min(x), max(x), length=Nbr)
	} else {
		Nbr <- length(breaks)
	}
	cts <- hist(x, breaks=breaks, plot=FALSE)$counts
	N <- length(cts)
	
	plot <- TRUE
	if (length(width)==0) {
		plot <- FALSE
	} else if (length(pal)==0) {
		plot <- FALSE
	}
	
	if (plot) {
		width[1] <- width[1] - diff(width) * 0.05
		width[2] <- width[2] + diff(width) * 0.05
		if (length(pal) == 1) {
			pal <- palettizer(pal, N)
		} else if (length(pal) != N) { 
			stop("palette length does not match # bins (which is # breaks - 1)\n") 
		}
		alpha.hex <- rebase(round(255*alpha,0), 16)
		alpha.pal <- paste(pal, alpha.hex, sep="")
		if (axis == 1) {
			for (i in 1:N) {
				rect(breaks[i],width[1], breaks[i+1],width[2], bord=NA, col=alpha.pal[i])
			}
		} else if (axis == 2) {
			for (i in 1:N) {
				rect(width[1],breaks[i], width[2],breaks[i+1], bord=NA, col=alpha.pal[i])
			}
		}
	}
	
	if (ablines) {
		for (i in 1:Nbr) {
			if (axis == 1) {
				abline(v=breaks)
			} else if (axis == 2) {
				abline(h=breaks)
			}
		}
	}
	
	if (!is.null(labels)) {
		if (axis == 1) {
			yat <- switch(labels, "top"=width[2], "bottom"=width[1], "center"=mean(width))
			ypos <- switch(labels, "top"=1, "bottom"=3, "center"=NULL)
			text(midpoints(breaks), yat, labels=paste("N =",cts), col=1, pos=ypos)
		} else if (axis == 2) {
			xat <- switch(labels, "right"=width[2], "left"=width[1], "center"=mean(width))
			xpos <- switch(labels, "right"=2, "left"=4, "center"=NULL)
			text(xat, midpoints(breaks), labels=paste("N =",cts), col=1, pos=xpos)
		}
	}
}


apa.names$clustering <- c(apa.names$clustering, "sample.specificity")
sample.specificity <- function(mat, pseudo=2^-11, step=0.05, distinct=0, expressed=1, negative=FALSE, norm.w=c("none","rpm","tmm"), norm.b=c("none","quantile")) {
    
    ## Trapnell et al's tissue-specificity score (designed for gene-expression datasets)
    ## Plus other tables for evaluating score cutoffs
    ## 'mat' MUST BE LINEAR SCALE
    ## 'step' is the increment for score testing -- tests score thresholds from 0-1 with step size 'step'
    ## 'distinct' is a stringency criterion: for given gene, best FP score must be >= 'distinct' greater than runner-up score (else ignored)
    ## 'negative' gives negative-specificity scores, basically which genes are uniquely DOWN in sample x, rather than UP.
    ## 'expressed' sets an genewise expression threshold, linear scale, post-normalization.  If any gene value >= 'expressed', gene is flagged as expressed.
    
    input <- deparse(substitute(mat))
    pseudo.n <- deparse(substitute(pseudo))
    norm.w <- match.arg(norm.w)
    norm.b <- match.arg(norm.b)
    
    require(limma)
    
    entropy <- function(x) -sum(x*zerofy(NAfy(log(x))))
    
    specificity.cole <- function(p1) {
        ## Cole Trapnell's TS Score, Cabili et al http://genesdev.cshlp.org/content/25/18/1915.long, pages 1924-1925
        theoretical <- diag(length(p1))
#        if (negative) theoretical <- 1-theoretical  # get 'negative' from parent namespace  ## DON'T INVERT HERE: ALL SCORES -> 0
        JS <- apply(theoretical, 1, function(p2) entropy((p1+p2)/2)-entropy(p1)/2 )  # (1) for every maximal expression profile; entropy(p2)==0 so ignore
        zapsmall(1-sqrt(JS))  # (3) + (4), zapped; skipping (5): not max score; reporting all scores
    }
    
    specificity.orig <- function(x) {
        ## Earlier code
        ## Appears be Cole Trapnell's TS Score, but considerably rewritten
        ## Appears to produce the same scores
        Hx <- -sum(x*log(x))/2
        Hxy <- apply(t(diag(length(x))+x)/2,1,function(z) -sum(z*log(z)) )
        1-sqrt(Hxy-Hx)
    }
    
    NC <- ncol(mat)
    if (length(colnames(mat))==0) colnames(mat) <- 1:NC
    cnames <- colnames(mat)
    
    if (norm.w == "rpm") {
        message("Applying RPM normalization")
        mat.n <- mean(colSums(mat)) * t( t(mat)/colSums(mat) )
    } else if (norm.w == "tmm") {
        message("Applying 10%-trimmed-mean RPM normalization")
        mat.n <- mean(colSums(mat)) * apply(mat, 2, function(x){ tr=quantile(x, c(0.05,0.95)); x/sum(x[x>=tr[1]&x<=tr[2]])  })
    } else if (norm.w == "none") {
        mat.n <- mat
    } else {
        stop(paste0("Unknown within-sample normalization method '",norm.w,"'!"))
    }
    if (norm.b == "quantile") {
        message("Applying quantile normalization")
        mat.n <- 2^normalizeBetweenArrays(NAfy(log2(mat.n)),method="quantile")
    } else if (norm.b == "none") {
        ## do nothing
    } else {
        stop(paste0("Unknown between-sample normalization method '",norm.b,"'!"))
    }
    mat.n[is.na(mat.n)] <- 0
    mat.n1 <- log2(mat.n+1+pseudo)  # +1 means no negatives in logscale; +1+pseudo ensures all > 0 in logscale
    
    if (negative) {
        ## invert the gene expression profile, preserving range
        mat.inv <- t(apply(mat.n, 1, function(x){ y=2*mean(x)-x; y+min(x)-min(y) }))
        mat.n1 <- log2(mat.inv+1+pseudo)
    }
    
    message("Calculating specificity scores")
    mat.pct <- mat.n1/rowSums(mat.n1)
    mat.spec <- t(apply(mat.pct,1,specificity.cole))
    mat.spec[is.na(mat.spec)] <- 0
    dimnames(mat.n) <- dimnames(mat.n1) <- dimnames(mat.spec) <- dimnames(mat)
    
    message("Annotating genes")
    gap <- apply(mat.spec, 1, function(x) abs(diff(rev(sort(x)))[1]) )
    is.distinct <- gap>=distinct
    is.expressed <- apply(mat.n>=expressed,1,any)
    fp.genes <- data.frame(
        Max.Sample=cnames[apply(mat.spec, 1, which.max)],
        Max.Score=rowMax(mat.spec),
        Next.Score=apply(mat.spec, 1, function(x) max(x[-which.max(x)]) ),
        Score.Gap=gap,
        Distinct=is.distinct,
        Median.Expr=rowMedians(mat.n),
        Max.Expr=rowMax(mat.n),
        Expressed=is.expressed,
        stringsAsFactors=FALSE
    )
    
    message("Analyzing scores")
    scores <- seq(0,1,step)  # range of scores from 0:1
    S <- length(scores)
    
    unq.table <- unq.table.d <- unq.table.e <- unq.table.de <- matrix(0, S, NC+1, FALSE, list(format(scores),0:NC))
    for (i in 1:S) {
        tab <- table(rowSums(mat.spec>=scores[i]))
        unq.table[i,] <- zerofy(tab[match(0:NC,as.numeric(names(tab)))])
    }
    
    sens.table <- sens.table.d <- sens.table.e <- sens.table.de <-
        spec.table <- spec.table.d <- spec.table.e <- spec.table.de <-
            matrix(0, S, NC, FALSE, list(format(scores),cnames))
    uniq.table <- uniq.table.d <- uniq.table.e <- uniq.table.de <- matrix(0, S, NC+1, FALSE, list(format(scores),0:NC))
    
    for (i in 1:S) {
        uas <- rowSums(mat.spec>=scores[i])
        is.mono <- uas==1
        is.above <- fp.genes$Max.Score>=scores[i]
        is.d <- is.above & is.distinct
        is.e <- is.above & is.expressed
        is.de <- is.above & is.distinct & is.expressed
        x <- table(uas)
        xd <- table(uas[is.d])
        xe <- table(uas[is.e])
        xde <- table(uas[is.de])
        uniq.table[i,] <- zerofy(x[match(0:NC,as.numeric(names(x)))])
        uniq.table.d[i,] <- zerofy(xd[match(0:NC,as.numeric(names(xd)))])
        uniq.table.e[i,] <- zerofy(xe[match(0:NC,as.numeric(names(xe)))])
        uniq.table.de[i,] <- zerofy(xde[match(0:NC,as.numeric(names(xde)))])
        y <- table(fp.genes$Max.Sample[is.above])
        yd <- table(fp.genes$Max.Sample[is.d])
        ye <- table(fp.genes$Max.Sample[is.e])
        yde <- table(fp.genes$Max.Sample[is.de])
        sens.table[i,] <- c(y[match(cnames,names(y))])
        sens.table.d[i,] <- c(yd[match(cnames,names(yd))])
        sens.table.e[i,] <- c(ye[match(cnames,names(ye))])
        sens.table.de[i,] <- c(yde[match(cnames,names(yde))])
        z <- table(fp.genes$Max.Sample[is.mono & is.above])
        zd <- table(fp.genes$Max.Sample[is.mono & is.d])
        ze <- table(fp.genes$Max.Sample[is.mono & is.e])
        zde <- table(fp.genes$Max.Sample[is.mono & is.de])
        spec.table[i,] <- c(z[match(cnames,names(z))])
        spec.table.d[i,] <- c(zd[match(cnames,names(zd))])
        spec.table.e[i,] <- c(ze[match(cnames,names(ze))])
        spec.table.de[i,] <- c(zde[match(cnames,names(zde))])
    }
    
    tables <- lapply(
        list(
            total=list(
                uniqueness=uniq.table,
                sensitivity=sens.table,
                specificity=spec.table
            ),
            distinct=list(
                uniqueness=uniq.table.d,
                sensitivity=sens.table.d,
                specificity=spec.table.d
            ),
            expressed=list(
                uniqueness=uniq.table.e,
                sensitivity=sens.table.e,
                specificity=spec.table.e
            ),
            distinct.expressed=list(
                uniqueness=uniq.table.de,
                sensitivity=sens.table.de,
                specificity=spec.table.de
            )
        ),
        function(x) lapply(x, function(y){ z=zerofy(y); cbind(z, Total=rowSums(z), CV=zerofy(rowCVs(z))) })
    )
    tot <- ncol(tables[[1]]$uniqueness)-1
    for (i in 1:length(tables)) tables[[i]]$uniqueness[,1] <- tables[[i]]$uniqueness[1,tot]-tables[[i]]$uniqueness[,tot]
    params <- list(input=input, pseudo=pseudo.n, step=step, distinct=distinct)
    return(list(genes=fp.genes, norm=mat.n, scores=mat.spec, tables=tables, params=params))
}


apa.names$clustering <- c(apa.names$clustering, "cvm")
cvm <- function(clustering, mat, method=c("balance.cv","dbi","dunn","silhouette","partition","separation","isolation","class.ent","fuzzy.hyper","c.index","gamma.index","cs","fom","calinski-harabasz","goodman-kruskal"), na.rm=FALSE) {
    
    ## cluster validation metrics
    ## 'mat' is matrix of clustered data
    ## 'clustering' is a vector specifying cluster membership for rows of 'mat'
    ## 'method' is the CVM desired
    ## 'na.rm' as in other functions
    
    method <- match.arg(method)
    clustering2 <- as.numeric(as.factor(clustering))
    K <- max(clustering2)
    NR <- nrow(mat)
    clusters <- lapply(1:K, function(i) mat[clustering2==i,] )
    centers <- t(sapply(clusters, function(x) colMeans(x, na.rm=na.rm) ))
    
    CVM <- list(
        "balance.cv"=function(x) {
            CV(table(clustering))
        },
        
        "dbi"=function(x){
            Dsum <- 0
            S <- rep(0, K)
# intracluster distance
            for (i in 1:K) {
                d <- dist(rbind(centers[i,],clusters[[i]]))		# distance from cluster vectors to centroid
                nr <- ifelse(is.null(nrow(clusters[[i]])), 1, nrow(clusters[[i]]))   # to correct for R's stupid handling of single-row matrices (hint: they are not matrices)
                S[i] <- max(as.matrix(d)[,1])/nr				# col 1 only, because row 1 is the centroid: all vectors' distances here
            }
# intercluster distance
            for (i in 1:K) {
                R <- rep(0, K)
                for (j in 1:K) {
                    if (j != i) {
                        M <- as.matrix(dist(centers[c(i,j),]))[1,2]   # cluster i / cluster j inter-centroid distance
                        R[j] <- (S[i]+S[j])/M
                    }
                }
                Dsum <- Dsum + max(R)
            }
            Dsum / K
        },
        
        "dunn"=function(x){
            Dsum <- 0
            dprime <- rep(NA, K)
# intracluster distance
            for (i in 1:K) {
                dprime[i] <- max(as.matrix(dist(rbind(centers[i,],clusters[[i]])))[,1])		# distance from cluster vectors to centroid | col 1 only, because row 1 is the centroid: all vectors' distances here
            }
            max.dprime <- max(dprime)
# intercluster distance
            d <- as.matrix(dist(centers))
# sum of min ratios
            R.i <- rep(NA, K)
            for (i in 1:K) {
                R.j <- rep(Inf, K)
                for (j in 1:K) {
                    if (j != i) {
                        R.j[j] <- d[i,j]/max.dprime
                    }
                }
                R.i[i] <- min(R.j)
            }
            min(R.i)
        },
        
        "silhouette"=function(x){
            S <- rep(NA, NR)
            for (i in 1:NR) {
                this.clust <- clustering2[i]
                clusteringX <- clustering2
                clusteringX[i] <- 0   # remove self
                rest <- mat[clusteringX==this.clust,]
                nr.this <- nrow(rest)
                a <- mean(as.matrix(dist(rbind(mat[i,],rest)))[2:nr.this,1])		# mean distance from vector i to rest of cluster(vector i goes first)
                b.d <- rep(Inf, K)
                for (j in 1:K) {
                    if (j != this.clust) {
                        b.d[j] <- as.matrix(dist(rbind(mat[i,],centers[j,])))[1,2]		# mean distance from vector i to each other cluster (calculating distance from i to [cluster j mean], not mean of [all i to all vec in j])
                    }
                }
                b <- min(b.d)
                S[i] <- (b-a)/max(c(a,b))
            }
            mean(S)
        },
        
        "partition"=function(x){
        },
        
        "separation"=function(x){
        },
        
        "isolation"=function(x){
        },
        
        "class.ent"=function(x){
        },
        
        "fuzzy.hyper"=function(x){
        },
        
        "c.index"=function(x){
            C <- rep(NA,K)
            S.all <- dist(mat)
            for (i in 1:K) {
                clust <- clusters[[i]]
                L <- (nrow(clust)^2-nrow(clust))/2   # all vector pairs such that i != j
                S <- sum(dist(clust))
                S.min <- sort(S.all)[1:L]
                S.max <- sort(S.all,decreasing=TRUE)[1:L]
                C[i] <- (S-S.min)/(S.max-S.min)
            }
            sum(C)
        },
        
        "gamma.index"=function(x){
            d.all <- as.matrix(dist(mat))
            within <- between <- matrix(FALSE, NR, NR)
            for (i in 1:NR) {
                clust.i <- clustering2[i]
                for (j in 1:(i-1)) {
                    d.ij <- d.all[i,j]
                    clust.j <- clustering2[j]
                    if (clust.i == clust.j) {
                        within[i,j] <- TRUE
                    } else {
                        between[i,j] <- TRUE
                    }
                }
            }
            d.within <- d.all[as.dist(within)==1]
            d.between <- d.all[as.dist(between)==1]
            n.within <- length(d.within)
            n.between <- length(d.between)
            d.cross <- matrix(NA, n.within, n.between)
            for (i in 1:n.within) {
                for (j in 1:n.between) {
                    if (d.within[i] < d.between[i]) { 
                        d.cross[i,j] <- TRUE 
                    } else if (d.within[i] > d.between[i]) {
                        d.cross[i,j] <- FALSE 
                    }
                }
            }
            consistent <- sum(d.cross, na.rm=TRUE)
            inconsistent <- sum(!d.cross, na.rm=TRUE)
            (consistent-inconsistent)/(consistent+inconsistent)
        },
        
        "CS"=function(x){
        },
        
        "FOM"=function(x){
        },
        
        "calinski-harabasz"=function(x){
            B <- sum(dist(centers)^2)
            W <- 0
            for (i in 1:K) {
                W <- W + sum(dist(clusters[[i]])^2)
            }
            (B*(K-1))/(W*(NR-K))
        }
    )
    CVM$`goodman-kruskal` <- CVM$gamma.index
    
    return(CVM[[method]](mat))
}


apa.names$dev <- c(apa.names$dev, "is.invariant")
is.invariant <- function(vec, tolerance=0, as=NULL, of=NULL) {
	
	## Returns T/F for whether a vector is "invariant", within limits
	## "tolerance" is the variance limit: give either a fixed number something else (see below)
	## "as" can be either: 
	##   "pct", meaning interpret tolerance as a percent of the "of" value
	##      1. value on [0,1]
	##      2. REQUIRES USE OF 'of'
	##   "fold", meaning interpret tolerance as the max(vec)/min(vec) fold-change
	##      1. only values > 1 make sense, since if max(vec)/min(vec)==1 then perfect invariance.  Values < 1 are impossible.
	## "of" is used only if "as" = "pct" and can be one of:
	##   "mean":      all values must lie within mean +/- mean*tolerance 
	##   "median":    all values must lie within median +/- median*tolerance
	##   "mean.sd":   all values must lie within mean +/- sd*tolerance
	##   "median.sd": all values must lie within median +/- sd*tolerance
	
	if ( !is.na(tolerance) & !is.numeric(tolerance) ) { stop ("Non-numeric input for 'tolerance' parameter!\n") }
	type <- "numeric"
	if (is.nlv(vec)) { 
		if (mode(vec) %in% c("character","logical")) {
			type <- mode(vec)
		}
	} else {
		stop ("Input must be a non-list vector!\n")
	}
	if (length(as)==0) as <- "fold"
	if (length(of)==0) of <- ""
	
	fail <- 0
	if (type == "character") {
		if (length(unique(vec)) > 1) { fail <- 1 }	# > 1 unique value: not invariant
	} else if (type == "logical") {
		if (!all(vec)) {					# not all TRUE...
			if (!all(!vec)) { fail <- 1 }	# but not all FALSE either: not invariant
		}
	} else if (as=="fold") {
		if ( max(vec)/min(vec)>tolerance ) { fail <- 1 }
	} else if (as=="pct") {
		if (of == "mean") {
			reference <- mean(vec)
			tolerance <- tolerance * reference
		} else if (of == "median") { 
			reference <- median(vec)
			tolerance <- tolerance * reference
		} else if (of == "mean.sd") { 
			reference <- mean(vec)
			tolerance <- tolerance * sd(vec)
		} else if (of == "median.sd") { 
			reference <- median(vec)
			tolerance <- tolerance * sd(vec)
		} else {
			stop ("If 'as' is 'pct', 'of' parameter must be one of 'mean', 'median', 'mean.sd', or 'median.sd'!\n") 
		}
		if (any(abs(vec-reference)>tolerance)) { fail <- 1 }
	}
	
	ternary (fail == 0, return(TRUE), return(FALSE))
}


apa.names$dev <- c(apa.names$dev, "GO.heatmap")
GO.heatmap <- function(fc, clust=NULL, opp=FALSE, terms=NULL, col.hc=FALSE, row.hc=FALSE, nlog10=FALSE, merge.maps=FALSE, ret.data=FALSE) {
	
	## Returns your GO metrics as a plot-ready matrix 
	## Defaults designed for current (v1.5) FatiClone output
	## fc: data.frame = four columns from the GO significant terms file contents: 
	## 		col 1 = map name, col 2 = cluster ID, col 3 = term, col 4 = metric (e.g. adj.p.value) AND POSSIBLY COL 5 = enrichment, if 'opp=TRUE'.
	##		in the default FatiClone sig terms table, these are columns 1, 2, 5 (for term IDs, or 6 if you want term names), and 13, respectively.
	## clust: the clustermap sent to GO analysis; expecting colnames = clustering IDs (map names), col 1 = gene IDs, cols 2-N = cluster mappings
	## 		if NULL, then missing clusters will not be represented in the heatmap
	## opp: was the background model 'opposite'? (i.e., up vs down lists?)
	##      IF TRUE, 'fc' MUST HAVE A 5TH COLUMN: enrichment, values being 'OVER' or 'UNDER'
	## terms: the complete list of terms to heatmap (= 1 row each), if not merely those terms which came back significant.
	## col.hc / row.hc: use hclust to reorder heatmap rows and cols?  Default binary distance / average linkage
	## nlog10: if TRUE, will take -log10(metric column) instead of using the metric directly
	## merge.maps: if TRUE, and 'fc' contains > 1 mapping, all mappings will be put in one matrix (instead of split out into a list of matrices, one per map)
	## ret.data: if TRUE, return a list of data.frames (subsets of 'fc'), one for each heatmap
	
	if (nlog10) fc[,4] <- -log10(fc[,4])
	if (length(clust)>0) {
		genes <- clust[,1]   # remove gene ID column
		clust <- clust[,2:ncol(clust),drop=FALSE]   # replace 'clust' with cluster mappings only
		mapnames <- colnames(clust)
		mapcols <- 1:ncol(clust)
		IM(mapnames,mapcols)
		if (length(mapnames)==0) stop("If specified, 'clust' must have the column names it had when it was sent to GO analysis!\n")
	} else {
		genes <- c()
		mapnames <- sort(unique(fc[,1]))  # first one just a placeholder
		mapcols <- 1:length(mapnames)
	}
	
	HMs <- DSs <- list()
	for (i in mapcols) {  # ignore gene column: mappings only
		uc <- ternary ( length(clust)>0, sort(unique(clust[,i])), sort(unique(fc[fc[,1]==mapnames[i],2])) )
		fc1 <- fc[fc[,1]==mapnames[i],]
		if (opp) over <- grep("^OVER",fc1[,5],ignore.case=TRUE)
		if (nrow(fc1)==0) {
			IM(paste("Warning: map '",mapnames[i],"' has no data!"))
		} else {
			terms2 <- ternary(length(terms)==0, suniq(fc1[,3]), terms)
			mat <- matrix(0, length(terms2), length(uc), F, list(terms2, uc))
			if (opp) {
				for (j in 1:nrow(fc1)) {
					if (j %in% over) {  # over-enriched: assign to positive cluster
						mat[match(fc1[j,3],terms2), match(fc1[j,2],uc)] <- fc1[j,4]
					} else {  # under-enriched: assign to negative cluster
						mat[match(fc1[j,3],terms2), match(-fc1[j,2],uc)] <- fc1[j,4]
					}
				}
			} else {
				for (j in 1:nrow(fc1)) mat[match(fc1[j,3],terms2), match(fc1[j,2],uc)] <- fc1[j,4]
			}
			HMs[[i]] <- mat
			fc2 <- fc1[,1:3]
			lost <- setdiff(uc,fc1[,2])
			if (length(lost) > 0) {
				extra <- fc2[rep(1,length(lost)),]
				extra[,2] <- lost
				extra[,3] <- ""
				fc2 <- rownameless(rbind(fc2, extra))
				fc2 <- fc2[order(fc2[,2]),]
			}
			DSs[[i]] <- fc2
		}
	}
	
	cluster.this <- function(x) {
		ord.c <- ternary(col.hc, hclust(dist(t(x),"binary"),"average")$order, 1:ncol(x))
		ord.r <- ternary(row.hc, hclust(dist(x,"binary"),"average")$order, 1:nrow(x))
		x[x==0] <- NA
		x[ord.r,ord.c]
	}
	
	names(HMs) <- mapnames
	if (length(HMs)==1) {
		HMs <- cluster.this(HMs[[1]])
		DSs <- DSs[[1]]
		DSs <- DSs[,c(1:2,1:3)]
		colnames(DSs)[1:2] <- qw(NEWMAP,NEWCLUST)
	} else if (merge.maps) {
		newnames <- lapply(1:length(HMs), function(i){paste(names(HMs)[i],colnames(HMs[[i]]),sep=":")})
		DSs <- data.frame(NEWMAP="ALL",NEWCLUST="",do.call(rbind,DSs), stringsAsFactors=FALSE)
		allrows <- sort(unique(unlist(lapply(HMs,rownames))))
		allcols <- matrix(c(
			MAP=rep(names(HMs), times=sapply(HMs,ncol)),
			CLUST=unlist(lapply(HMs,colnames)),
			NAME=unlist(newnames)
			), nrow=3, byrow=TRUE)
		alldata <- matrix(0, length(allrows), ncol(allcols), F, list(allrows, allcols[3,]))
		for (i in 1:length(HMs)) {
			w <- which(allcols[1,]==names(HMs)[i])
			alldata[match(rownames(HMs[[i]]),allrows),w[match(colnames(HMs[[i]]),allcols[2,w])]] <- HMs[[i]]
			for (j in 1:ncol(HMs[[i]])) DSs[DSs[,3]==names(HMs)[i] & DSs[,4]==colnames(HMs[[i]])[j],2] <- newnames[[i]][j]
		}
		HMs <- cluster.this(alldata)
	} else {
		for (i in 1:length(HMs)) {
			HMs[[i]] <- cluster.this(HMs[[i]])
			DSs[[i]] <- DSs[[i]][,c(1:2,1:3)]
			colnames(DSs[[i]])[1:2] <- qw(NEWMAP,NEWCLUST)
		}
	}
	
	if (ret.data) {
		list(HEATMAPS=HMs, DATASETS=DSs)
	} else {
		HMs
	}
}


apa.names$dev <- c(apa.names$dev, "GO.heatmap.plus")
GO.heatmap.plus <- function(fcfile, prefix, clust=NULL, terms=NULL, opp=FALSE, merge.maps=FALSE, metric=c("adj.p","raw.p","fg.pct","pct.lfc"), col.hc=FALSE, row.hc=TRUE, 
							term.x=c("all","multi","mono"), main=NULL, sig.par=TRUE, min.genes=1, ens2symb=NULL, las=2, cex=1.4, bkg=0.75, aspect=c(2,1,10), grid=TRUE, view=FALSE) {
	
	## GO.heatmap wrapper that also generates a clickable HTML imagemap.  Only runs on Linux.
	## REQUIRED PARAMETERS:
	## 'fcfile' is -EITHER- a path to a FatiClone "sig terms" file -OR- a data.frame with the UNALTERED contents of said file.
	## 'prefix' is the output prefix of the heatmap PNG that will be produced, which may include a path.  Do not add an extension.  All output images will be PNG.
	## INPUT OPTIONS:
	## 'clust' is a data.frame with col 1 = gene IDs and cols 2-N = mappings; basically what you printed out and sent to FatiClone, to generated 'fcfile'.
	##   If unspecified, any clusters not represented in 'fcfile' will also be missing in the heatmap.  If specified, they each get a blank column.
	## 'terms' gives the complete term set to consider, if all terms not present in 'fcfile'.  Typically used for slim lists.  Missing terms get a blank row each.
	## 'opp' specifies if the FatiClone run used the "opposite" background model (i.e. each cluster can be represented twice: under- and over-enriched)
	## DATA SELECTION AND HANDLING OPTIONS:
	## 'metric' indicates the score to use for the heatmap:
	##   "raw.p", "adj.p" use these p-values.  Will automatically be converted to -log10.
	##   "fg.pct", "pct.lfc" use foreground enrichment percent, or log2(fg.pct/bg.pct), respectively.
	## 'merge.maps': often, FatiClone runs will analyze multiple mappings in one run.  IF FALSE, one heatmap is generated per mapping; if TRUE, all mappings will appear in one heatmap.
	## 'sig.par': if FALSE, ignore "significant parent" entries (those with enrichment labels marked by '*').
	## 'min.genes': ignore terms with fewer than this number of genes in foreground.
	## 'term.x': require that terms in heatmap be found in this many clusters:
	##   "all" = no restrictions; "multi" = 2+ clusters; "mono" = only 1 cluster
	##   This helps to split giant heatmaps (like GO BP results) into "terms with 2+ clusters" and "singleton term" heatmaps.
	## 'ens2symb': Is a data.frame or matrix with col 1 = Ensembl ID and col 2 = symbol. The gene symbols in 'fcfile' will be missing if KEGG was used; this restores them.
	## HEATMAP OPTIONS:
	## 'col.hc': if TRUE, reorders heatmap columns by hclust, dist=binary, linkage=average.
	## 'row.hc': if TRUE, reorders heatmap rows by hclust, dist=binary, linkage=average.
	## 'aspect': given as c(x,y), specifies x:y ratio per heatmap cell.
	## 'ppa': Pixels Per Aspect.  If ppa=10 and aspect=c(2,1), then each heatmap cell will be 20px wide and 10px high.
	## las, cex, main: as usual.
	## HEATMAP2IMAGEMAP SCRIPT OPTIONS:
	## 'bkg': background-color (white) percent value for pixel rows/columns which are NOT in the heatmap body.  If heatmap boundaries don't detect properly, may have to raise this.
	## 'grid': if TRUE, heatmap will have gridlines, and the imagemap script will be informed of this.  Gridline color is hardcoded and expected by downstream scripts.
	## 'view': if TRUE, pops up a window with the cell-detection QC PNG.
	
	if (Sys.info()[["sysname"]] != "Linux") stop("This function can only be run on the Linux servers!\n")
	
	metric <- match.arg(metric)
	term.x <- match.arg(term.x)
	
	if (length(fcfile)>1) {
		fcdat <- fcfile  # assuming data.frame read from file
	} else {
		fcdat <- read.delim(fcfile, stringsAsFactors=FALSE)  # assuming filename
	}
	IM(nrow(fcdat)-1,"FatiClone entries")
	
	if (min.genes > 1) {
		fcdat <- fcdat[fcdat[,17]>=min.genes,]  # must have >= 'min.genes' genes to be considered
		IM(nrow(fcdat)-1,"entries >= min genes")
	}
	
	if (!sig.par) {
		fc <- fc[!grepl("\\*$",fc[,11]),]   # remove sig parent entries
		IM(nrow(fcdat)-1,"non-sig-parent entries")
	}
	
	if (length(ens2symb)>0) {
		if (falsify(all(is.na(fcdat[,25])))) fcdat[,25] <- FatiClone.KEGG.convert(ens2symb[,1:2], fcdat[,24])  # add missing symbols
	}
	
	metric.col <- switch(metric, "raw.p"=12, "adj.p"=13, "fg.pct"=7, "pct.lfc"=9)
	if (opp) {
		fc2hm <- fcdat[,c(1,2,6,metric.col,11)]
	} else {
		fc2hm <- fcdat[,c(1,2,6,metric.col)]
	}
	
	maps <- GO.heatmap(fc2hm, clust=clust, opp=opp, terms=terms, col.hc=col.hc, row.hc=row.hc, nlog10=TRUE, merge.maps=merge.maps, ret.data=TRUE)
#	return(maps)
	if (is.list(maps[[1]])) {
		datasets <- maps[[2]]
		maps <- maps[[1]]
	} else {
		datasets <- list(maps[[2]])
		maps <- list(maps[[1]])   # recast as list
	}
#	return(maps)
#	return(datasets)
	
	prefix <- sub("\\.png$","",prefix)   # just in case
	prefix <- sub("\\.PNG$","",prefix)   # just in case
	grid.col <- ifelse(grid, "grey60", 0)
	grid.flag <- ifelse(grid, "--grid", "")
	
	for (i in 1:length(maps)) {
		mapname <- ifelse (length(names(maps))==0, "ALL", names(maps)[i])
		if (term.x != "all") {
			nrm <- nrow(maps[[i]])
			if (term.x == "multi") {
				maps[[i]] <- maps[[i]][rowSums(!is.na(maps[[i]]))>1,]
				IM("Map",i,":",nrow(maps[[i]]),"/",nrm,"are 'multi' terms")
			} else if (term.x == "mono") {
				maps[[i]] <- maps[[i]][rowSums(!is.na(maps[[i]]))==1,]
				IM("Map",i,":",nrow(maps[[i]]),"/",nrm,"are 'mono' terms")
			}
		}
		if (nrow(maps[[i]])==0 | ncol(maps[[i]])==0) {   # failsafe
			IM("Map",i,"has no data left!!  Skipping.")
			next
		}
		this.imgname <- ifelse (length(maps)==1, paste(prefix,"png",sep="."), paste(prefix,mapname,"png",sep="."))
		IM(this.imgname)
		heat.map(maps[[i]], family="mono", pal="Reds", label.pix=c(NA,NA), aspect=aspect, las=las, cex=cex, main=main, grid.col=grid.col, imgname=this.imgname)
		tempnames <- paste(this.imgname,".names",sep="")
		tempdata <- paste(this.imgname,".data",sep="")
		tempscript <- paste(this.imgname,".sh",sep="")
		IM(tempnames, tempdata, tempscript)
		write.vector(c(	paste(c("ROWS",rownames(maps[[i]])), collapse="\t"), paste(c("COLS",colnames(maps[[i]])), collapse="\t") ), tempnames)
		newnames <- unique(datasets[[i]][,1:4])
		x <- fcdat[which(fcdat[,1]%in%newnames[,3] & fcdat[,2]%in%newnames[,4] & fcdat[,6]%in%datasets[[i]][,5]),]    # & fcdat[,6] %in% datasets[[i]][,4]
		for (j in 1:nrow(newnames)) {
			w <- which(x[,1]==newnames[j,3] & x[,2]==newnames[j,4])
			if (length(w)==0) next
			x[w,1] <- newnames[j,1]
			x[w,2] <- newnames[j,2]
		}
		write.table(x, tempdata, sep="\t", quote=FALSE, row.names=FALSE)
		write.vector(paste("/home/apa/local/bin/heatmap2imagemap -h",this.imgname,"-d",tempdata,"-n",tempnames,"-b",bkg,grid.flag), tempscript)
		cmd <- paste("./",tempscript,sep="")
		IM(cmd)
		system(cmd)
		if (view) view.image(sub("png$","imagemap.png",this.imgname))
	}
}


apa.names$dev <- c(apa.names$dev, "Excel.column.extract")
Excel.column.extract <- function(data, from="clipboard") {
    
    ## WINDOWS ONLY
    ## Produce N new data columns for an existing Excel file, based on an ID column.
    ## The 'data' object must have N+1 columns; col 1 is the IDs and the other N columns are the data to be transferred.
    ## 1. In the Excel file, insert N new columns where you want the new data to reside.
    ## 2. In R, paste string "Excel.column.extract(myDataFrame)" onto command line -- DO NOT EXECUTE.
    ## 3. In the Excel file, select all desired ID cells from the ID column (must be a contiguous range of cells)
    ## 4. Hit CTRL-C to send gene IDs to clipboard.
    ## 5. Back to R, hit <Enter> (run "Excel.column.extract(myDataFrame)").
    ## 6. In Excel, select upper-left corner of the empty column range.
    ## 7. Hit CTRL-V to paste in new data.
    
    clipboard <- ifelse(length(from)==1 & from[1]=="clipboard", TRUE, FALSE)
    if (clipboard & .Platform$OS.type != "windows") stop("Clipboard mode only works on Windows!\n")
    
    if (clipboard) {
        x <- readClipboard()
    } else {
        if (length(from)==0) message("'from' has no data!\n")
        x <- from
    }
    y <- data[match(x,data[,1]),2:ncol(data)]
    if (clipboard) {
        out <- c(
            paste(colnames(data)[2:ncol(data)],collapse="\t"),
            apply(y,1,paste,collapse="\t")
        )
        writeClipboard(out)
    } else {
        y
    }
    
}


apa.names$dev <- c(apa.names$dev, "FatiClone.KEGG.convert")
FatiClone.KEGG.convert <- function(key, from="clipboard") {

    ## WINDOWS ONLY
    ## Filling in gene names for FatiClone KEGG results:
    ## 1. In R, paste string "FatiClone.KEGG.convert(myKeyObject)" onto command line -- DO NOT EXECUTE.
    ## 2. In FatiClone sig KEGG terms file, select all non-header cells of column X ("Input_Xrefs") and CTRL-C to send gene IDs to clipboard.
    ## 3. Back to R, hit <Enter> (run "FatiClone.KEGG.convert()").
    ## 4. Select cell Y2 from sig terms file (first non-header cell of column "Mapped_Symbols") and CTRL-V to paste new data from clipboard.
    ## 5. Save sig terms file.
    ##
    ## 'key' is a 2-col object; col 1 = Ensembl IDs (or Entrez, or whatever KEGG DB IDs were used), col 2 = symbols
    
    clipboard <- ifelse(length(from)==1 & from[1]=="clipboard", TRUE, FALSE)
    if (clipboard & .Platform$OS.type != "windows") stop("Clipboard mode only works on Windows!\n")
    
    if (clipboard) {
        x <- lapply(readClipboard(), function(i) unlist(strsplit(i,"; ")) )
    } else {
        if (length(from)==0) message("'from' has no data!\n")
        x <- lapply(from, function(i) unlist(strsplit(i,"; ")) )
    }
    y <- lapply(x, function(i) key[match(i,key[,1]),2] )
    z <- sapply(y, function(i) paste(i,collapse="; ") )
    if (clipboard) {
        writeClipboard(z)
    } else {
        z
    }
}


apa.names$general <- c(apa.names$general, "genewise.anova")
genewise.anova <- function(x, model, col.factors=NULL, row.factors=NULL) {
    
    ## Takes an matrix of values + sets of column or row factors (needs at least one) 
    ## Returns an anova-ready dataset + row-wise anova results on that dataset
    ## **** Row factors aren't yet ready to run ****
    ## 'model' is the linear model as a character string, e.g. "Value ~ time + drug + time*drug"
    ##  -- Predictand name MUST be 'Value' !!!!!!!!!!  Others must correspond to given factor names.
    ## 'col.factors' or 'gene.factors' is a list with names = factor names in 'model', and values are vectors of levels.
    
    ## factor consistency checks
    any.factors <- FALSE
    if (length(col.factors)>0) {
        col.names <- names(col.factors)
        if (is.matrix(col.factors)) {
            col.factors2 <- as.list(as.data.frame(col.factors))
        } else if (is.data.frame(col.factors)) {
            col.factors2 <- as.list(col.factors)
        } else if (is.ndfl(col.factors)) {
            if (luniq(listLengths(col.factors))==1) {  # all same length
                col.factors2 <- lapply(col.factors, as.character)  # defactorized, if factor
            }
        } else if (is.nlv(col.factors)) {
            col.factors2 <- list(as.character(col.factors))  # defactorized, if factor
        }
        if (length(col.factors2[[1]])==ncol(x)) {
            col.factors <- col.factors2  # pass back to original,
            for (i in 1:length(col.factors)) {
                if (!is.factor(col.factors[[i]])) col.factors[[i]] <- as.factor(col.factors[[i]])
            }
            names(col.factors) <- col.names
        }
        if (length(col.factors)>0) {
            any.factors <- TRUE
        } else {
            stop("col.factors specified, but were either of incorrect/inconsistent length, or were not a matrix, data.frame, list, or vector\n")
        }
    }
    if (length(row.factors)>0) {
        row.names <- names(row.factors)
        if (is.matrix(row.factors)) {
            row.factors2 <- as.list(as.data.frame(row.factors))
        } else if (is.data.frame(row.factors)) {
            row.factors2 <- as.list(row.factors)
        } else if (is.ndfl(row.factors)) {
            if (luniq(listLengths(row.factors))==1) {  # all same length
                row.factors2 <- lapply(row.factors, as.character)  # defactorized, if factor
            }
        } else if (is.nlv(row.factors)) {
            row.factors2 <- list(as.character(row.factors))  # defactorized, if factor
        }
        if (length(row.factors2[[1]])==nrow(x)) {
            row.factors <- row.factors2  # pass back to original
            names(row.factors) <- row.names
        }
        if (length(row.factors)>0) {
            any.factors <- TRUE
        } else {
            stop("row.factors specified, but were either of incorrect/inconsistent length, or were not a matrix, data.frame, list, or vector\n")
        }
    }
#    if (!any.factors) stop("No factors specified: Cannot proceed!\n")   # once row factors are operational
    if (length(col.factors)==0) stop("No factors specified: Cannot proceed!\n")
    
    if (length(rownames(x))==0) rownames(x) <- 1:nrow(x)
    tests <- unlist(strsplit(gsub(" ","",model),"[~+-]"))  # do not split interactions
    tests <- tests[2:length(tests)]  # drop predictand
    
    pre.aov <- as.data.frame(c(
        list(Gene=factor(rep(rownames(x), ncol(x)))),
        list(Value=c(as.matrix(x))),
        lapply(col.factors, function(f) factor(rep(f, each=nrow(x))) )
    ))
    
    anova.fun <- function(dat) {
        y <- pre.aov[which(pre.aov[,1]==dat),]
        z <- eval(parse(text=paste("anova(lm(",model,", data=y))")))
        return(z[[5]][1:length(tests)])
    }
    
    IM("ANOVA running...")
    st <- system.time( aov.raw <- aov.adj <- aov.adj2 <- as.matrix(t(sapply(rownames(x), anova.fun))) )
    sm <- st[[3]]/60
    sm <- ifelse(sm<0.5, 0, ceiling(sm))
    
    colnames(aov.raw) <- paste0(tests,".p.raw")
    colnames(aov.adj) <- paste0(tests,".p.BH")
    colnames(aov.adj2) <- paste0(tests,".p.Bonferroni")
    for (i in 1:ncol(aov.raw)) {
        aov.adj[,i] <- p.adjust(aov.raw[,i], method="BH")
        aov.adj2[,i] <- p.adjust(aov.raw[,i], method="bonferroni")
    }
    result <- do.call(cbind, lapply(1:length(tests), function(i) cbind(aov.raw[,i,drop=FALSE], aov.adj[,i,drop=FALSE], aov.adj2[,i,drop=FALSE]) ))
    rownames(result) <- rownames(x)
    
    message(paste("ANOVA complete:",sm,"minutes elapsed"))
    return(list(data=pre.aov, result=result))
}


apa.names$dev <- c(apa.names$dev, "reorder.hclust.x")
reorder.hclust.x <- function(x, rowStats, ...) {
	
	## Based on someone else's function.  It does reorder, but not in any useful way.
	## Use reorder.hclust2 instead.
	
	stat.mat <- outer(rowStats, rowStats, "-")
    merges <- x$merge
    n <- nrow(merges)
    endpoints <- matrix(0, n, 2)
    dir <- matrix(1, n, 2)
    for (i in 1:n) {
        j <- merges[i, 1]
        k <- merges[i, 2]
        if ((j < 0) && (k < 0)) {
            endpoints[i, 1] <- -j
            endpoints[i, 2] <- -k
        } else if (j < 0) {
            j <- -j
            endpoints[i, 1] <- j
            if (stat.mat[j, endpoints[k, 1]] < stat.mat[j, endpoints[k, 2]]) {
                endpoints[i, 2] <- endpoints[k, 2]
            } else {
                endpoints[i, 2] <- endpoints[k, 1]
                dir[i, 2] <- -1
            }
        } else if (k < 0) {
            k <- -k
            endpoints[i, 2] <- k
            if (stat.mat[k, endpoints[j, 1]] < stat.mat[k, endpoints[j, 2]]) {
                endpoints[i, 1] <- endpoints[j, 2]
                dir[i, 1] <- -1
            } else {
                endpoints[i, 1] <- endpoints[j, 1]
            }
        } else {
            d11 <- stat.mat[endpoints[j, 1], endpoints[k, 1]]
            d12 <- stat.mat[endpoints[j, 1], endpoints[k, 2]]
            d21 <- stat.mat[endpoints[j, 2], endpoints[k, 1]]
            d22 <- stat.mat[endpoints[j, 2], endpoints[k, 2]]
            dmin <- min(d11, d12, d21, d22)
            if (dmin == d21) {
                endpoints[i, 1] <- endpoints[j, 1]
                endpoints[i, 2] <- endpoints[k, 2]
            } else if (dmin == d11) {
                endpoints[i, 1] <- endpoints[j, 2]
                endpoints[i, 2] <- endpoints[k, 2]
                dir[i, 1] <- -1
            } else if (dmin == d12) {
                endpoints[i, 1] <- endpoints[j, 2]
                endpoints[i, 2] <- endpoints[k, 1]
                dir[i, 1] <- -1
                dir[i, 2] <- -1
            } else {
                endpoints[i, 1] <- endpoints[j, 1]
                endpoints[i, 2] <- endpoints[k, 1]
                dir[i, 2] <- -1
            }
        }
    }
    for (i in n:2) {
        if (dir[i, 1] == -1) {
            m <- merges[i, 1]
            if (m > 0) {
                m1 <- merges[m, 1]
                merges[m, 1] <- merges[m, 2]
                merges[m, 2] <- m1
                if (dir[m, 1] == dir[m, 2]) { dir[m, ] <- -dir[m, ] }
            }
        }
        if (dir[i, 2] == -1) {
            m <- merges[i, 2]
            if (m > 0) {
                m1 <- merges[m, 1]
                merges[m, 1] <- merges[m, 2]
                merges[m, 2] <- m1
                if (dir[m, 1] == dir[m, 2]) { dir[m, ] <- -dir[m, ] }
            }
        }
    }
    clusters <- as.list(1:n)
    for (i in 1:n) {
        j <- merges[i, 1]
        k <- merges[i, 2]
        if ((j < 0) && (k < 0)) {
            clusters[[i]] <- c(-j, -k)
        } else if (j < 0) {
            clusters[[i]] <- c(-j, clusters[[k]])
        } else if (k < 0) {
            clusters[[i]] <- c(clusters[[j]], -k)
        } else {
			clusters[[i]] <- c(clusters[[j]], clusters[[k]])
		}
    }
    x1 <- x
    x1$merge <- merges
    x1$order <- clusters[[n]]
    x1
}


apa.names$dev <- c(apa.names$dev, "PCA.basic")
PCA.basic <- function(mat, method=c("cor","cov"), norm=c("scale","center","none"), drop.PC=NULL, rotate=NA, use=c("pairwise.complete.obs","complete.obs","na.or.complete","all.obs","everything"), ...) {
    
    ## Basic PCA function
	## Operates on columns, not rows
	## 'drop.PC' indicates PCs to exclude from the analysis:
    ##   In general, use 'drop.PC=1' when doing PCA on RNAseq data.  PC 1 captures within-sample variation while PCs 2-N will actually discriminate between samples.
	##   In some cases, batch effects may dominate the first 2 components; to remove use "drop.PC=1:2".
    
#    require(GPArotation)
    norm <- match.arg(norm)
    method <- match.arg(method)
    use <- match.arg(use)
    N <- ncol(mat)
    func <- get(method)
    etc <- list(...)
    
    if (norm == "scale") {
        scaled <- scale(mat)  # column centering is automatic with scaling (recommended)
    } else if (norm == "center") {
        scaled <- t( t(mat)-colMeans(mat) )  # column centering only
    } else {
        scaled <- mat  # nothing (not recommended...)
    }
    CO <- func(scaled, use=use)
    
    E <- eigen(CO)
    if (length(drop.PC)>0) {
        ## Exclude these components from analysis
		use.PC <- setdiff(1:N, drop.PC)
        E$vectors <- E$vectors[,use.PC]
        E$values <- E$values[use.PC]
    }
    P <- length(E$values)  # number of PCs in use
    dimnames(E$vectors) <- list(colnames(mat), paste("PC",1:P))
    names(E$values) <- colnames(E$vectors)
    prop.var <- percentify(E$values)
    cum.var <- cumsum(prop.var)
    stdev <- sqrt(E$values)
    scores <- scaled %*% E$vectors
    proj <- t(t(E$vectors)*stdev)   # a.k.a loadings
#	scores <- cor(t(mat), proj)  # correlate expression profiles to components
 	
    if (!is.na(rotate)) {
    }
	
	## to reconstruct scaled input from fewer PCs:   E$vectors[,1:N] %*% t(scores)	
	## to reconstruct cor/cov matrix from fewer PCs: E$vectors[,1:N] %*% diag(x=E$values[1:N]) %*% t(E$vectors[,1:N])
	
    output <- list(
        input.data=mat, scale.data=scaled, matrix=CO,
        eigenvectors=E$vectors, eigenvalues=E$values, 
        st.dev=stdev, variance.per=prop.var, cumulative.variance=cum.var,
        gene.scores=scores, sample.projections=proj,
        methods=list("norm"=norm,"method"=method,"use"=use,"rotate"=rotate,"drop.PC"=drop.PC,"..."=etc)
    )
    
    invisible(output)
}


apa.names$dev <- c(apa.names$dev, "PCA.project")
PCA.project <- function(pca, x, project=c("genes","samples")) {
    
    ## Project a matrix or vector of values 'x' into an existing PCA space 'pca'
    ## Returns 'pca' with new stuff added
    ## 'project.dim' indicates dimension to project:
    ##   1 = rows; projects rows of 'x' into PCs of 'pca'
    ##   2 = cols; projects cols of 'x' into gene scores of 'pca'
    
    project <- match.arg(project)
    if (!is.matrix(x)) {
        if (project=="genes") {
            x <- matrix(x, nrow=1)  # assuming single-gene vector
        } else if (project=="samples") {
            x <- matrix(x)  # assuming single-sample vector
        }
    }
    
    if (project=="genes") {
        
        ## must scale new genes (new sample subsets, basically) relative to original samples' parameters
        if (pca$methods$norm == "scale") {
            y <- t( ( t(x)-colMeans(pca$input.data) )/apply(pca$input.data,2,sd) )
        } else if (pca$methods$norm == "center") {
            y <- t( ( t(x)-colMeans(pca$input.data) ) )
        } else if (pca$methods$norm == "none") {
            y <- x
        } else {
            stop(paste0("No handlers for normalization method '",pca$methods$norm,"': cannot proceed!\n"))
        }
        
        ## project new genes into existing basis
        z <- y %*% pca$eigenvectors
        pca$projected.genes <- list( input.data=x, scale.data=y, gene.scores=rbind(pca$gene.scores,z) )
        
    } else if (project=="samples") {
        
        ## scaling is relative to sample
        if (pca$methods$norm == "scale") {
            y <- scale(x)
        } else if (pca$methods$norm == "center") {
            y <- t( t(x)-colMeans(x) )
        } else if (pca$methods$norm == "none") {
            y <- x
        } else {
            stop(paste0("No handlers for normalization method '",pca$methods$norm,"': cannot proceed!\n"))
        }
        
        ## construct synthetic sample projections for extraneous samples
        ## ONLY WORKS ONE SAMPLE AT A TIME -- so apply on columns
        z <- t(apply(y, 2, function(s) {
            initial <- t(s) %*% pca$gene.scores
            eigenscale <- (t(pca$scale.data) %*% pca$gene.scores / pca$eigenvectors)[1,]  # don't remember where I got this from, but it works: try reprojecting original samples.
            t( t(initial)/eigenscale )
        }))
        pca$projected.samples <- list( input.data=x, scale.data=y, eigenvectors=rbind(pca$eigenvectors,z) )
    }
    
    pca
}


apa.names$dev <- c(apa.names$dev, "PCA.plots")
PCA.plots <- function(pca, type=c("var","covcor","scores","scree","scree.percent","scree.cumulative","components",
                               "sample","sample.rgl","sample.svm","sample.rgl.svm","gene","gene.rgl","legend"),
                      PCx=NULL, PCy=NULL, PCz=NULL, labels=FALSE, smooth=FALSE, col=NULL, main=NULL, cex=1,
                      hulls=FALSE, projected=FALSE, viewpoint=NULL, svm.class=NULL, size=3, border=FALSE, ...) {
    
    ## ADD: xlim=NULL, ylim=NULL
    
    ## Input is the output list from 'PCA.basic'
    ## Variously plots 2D, 3D sample projections, scores biplots
    
    type <- match.arg(type)
    others <- list(...)
    if (projected) {
        if (grepl("sample",type)) {
            ev <- pca$projected.samples$eigenvectors
        } else if (grepl("gene",type) | type=="scores") {
            gs <- pca$projected.genes$gene.scores
        }
    } else {
        ev <- pca$eigenvectors
        gs <- pca$gene.scores
    }
    P <- ncol(ev)
    S <- nrow(ev)
    pcols <- if (P <= 8) { 1:8 } else { rainbow(P+1)[1:P] }  # principal component colors
    sp <- pca$sample.projections
    vp <- pca$variance.per
    vpr <- round(100*vp,2)
    out <- list()  # may have invisible output data
    
    plot.svm <- FALSE
    if (grepl("\\.svm$",type)) {
        if (length(svm.class)==ncol(pca$input.data)) {
            require(e1071)
            plot.svm <- TRUE
            type <- sub("\\.svm$","",type)
            if (!is.factor(svm.class)) svm.class <- as.factor(svm.class)
        } else {
            stop(paste0("length(svm.class) (",length(svm.class),") does not match ncol(pca$input.data) (",ncol(pca$input.data),")!\n"))
        }
    }
    
    if (length(col)>1) {
        scols <- col  # sample (or gene) colors
    } else if (length(col)==1) {
        scols <- rep(col,S)  # sample (or gene) colors
    } else {
        scols <- if (S <= 8) { 1:8 } else { rainbow(S+1)[1:S] }  # sample (or gene) colors
    }
    scols[is.na(scols)] <- 0
    if (is.logical(labels[1])) {
        custom.labels <- c()
    } else {
        custom.labels <- labels
        labels <- TRUE
    }
    
    if (type == "var") {
        ## Within/between-samples variances plot
        if (length(main)==0) main <- "Log2 Variance Distributions"
        lvars <- lapply(list(Within.Samples=apply(pca$input,2,var), Between.Samples=apply(pca$input,1,var)), log2)
        dhist(lvars, main=main, col=2:3, cex=cex, legend=NA)
        abline(v=sapply(lvars,function(x) mean(real(x)) ), lty=3:3, col=2:3)
        legend("topleft", bty="n", col=c(2,3,1), lty=c(1,1,3), legend=c(names(lvars),"Means"))
    }
    
    if (type == "covcor") {
        ## Sample cor/cov plot
        if (length(main)==0) main <- paste("Sample",label)
        CO <- pca$matrix; diag(CO) <- NA
        label <- ifelse(pca$methods["Method"] == "cor", "Correlations", "Covariances")
        mipu(CO, main=main)
    }
    
    if (type == "scores") {
        ## Scores-per-component heatmap
        if (length(main)==0) main <- "Gene Scores per PC"
        scores.hc <- hclust(dist(pca$gene.scores),"average")
        mipu(pca$gene.scores[scores.hc$order,], pal="CKY", main=main)
    }
    
    if (type == "scree") {
        ## Scree plot
        if (length(main)==0) main <- "Eigenvalues (Variances) per PC"
        lineplot(pca$eigenvalues, pch=1, col=2, cex=cex, main=main, las=1, xlab="Components")
    }
    
    if (type == "scree.percent") {
        ## Scree plot, as percent total
        if (length(main)==0) main <- "Percent Total Variance per PC"
        lineplot(pca$variance.per, pch=1, col=2, cex=cex, main=main, las=1, xlab="Components")
    }
    
    if (type == "scree.cumulative") {
        ## Scree plot, as cumulative total
        if (length(main)==0) main <- "Cumulative Variance"
        lineplot(pca$cumulative.variance, pch=1, col=2, cex=cex, main=main, las=1, xlab="Components")
    }
    
    if (type == "loadings") {
        ## PC lineplot
        if (length(main)==0) main <- "Eigenvectors (Loadings)"
        lineplot(pca$eigenvectors, col=pcols, cex=cex, main=main, las=1)
    }
    
    if (type == "legend") {
        ## Legend plots
        # have to figure out what kind of legend?
        if (length(main)==0) main <- ""
        null.plot(xlim=c(0,10), ylim=c(0,10))
        stop("'legend' style not ready yet!\n")
        ## ######################
    }
    
    ######## SAMPLE PLOTS
    
    if (type == "sample" & is.null(PCz) & !smooth) {
        ## 2D sample plots, points
        if (length(main)==0) main <- "Sample Projections"
        pclabs <- c( paste0("PC",PCx," (",vpr[PCx],"%)"), paste0("PC",PCy," (",vpr[PCy],"%)") )
        plot(sp[,c(PCx,PCy)], col=0, xlab=pclabs[1], ylab=pclabs[2], xlim=extend.xylim(sp[,PCx],0.03), ylim=extend.xylim(sp[,PCy],0.03), main=main, ...)
        abline(h=0, v=0, lty=size, col=8)
        if (border) {
            points(sp[,c(PCx,PCy)], pch=21, col=1, bg=scols, cex=size*cex)
        } else {
            points(sp[,c(PCx,PCy)], pch=19, col=scols, cex=size*cex)
        }
        if (labels) text(sp[,PCx], sp[,PCy], rownames(sp))
        if (hulls) {
            poly <- mat.split(sp[,c(PCx,PCy)], scols)  # split points by color; that is the only grouping vector we have to go on
            for (i in 1:length(poly)) {
                poly[[i]] <- poly[[i]][chull(poly[[i]]),]
                for (j in 1:nrow(poly[[i]])) {
                    j2 <- ifelse(j<nrow(poly[[i]]), j+1, 1)
                    segments(poly[[i]][j,1],poly[[i]][j,2], poly[[i]][j2,1],poly[[i]][j2,2], col=names(poly)[i], lwd=size)
                }
            }
        }
    }
    
    if (type == "sample" & is.null(PCz) & smooth) {
        ## 2D sample plots, smooth
        require(smoothScatter)
        if (length(main)==0) main <- ""
        ## ######################
    }
    
    if (type == "sample" & !is.null(PCz)) {
        ## 3D sample plots, static
        require(scatterplot3d)
        if (length(main)==0) main <- ""
        ## ######################
        ## OR dynamic, with viewpoint and auto-screenshot??
    }
    
    if (type == "sample.rgl" & !is.null(PCz)) {
        ## 3D sample plots, dynamic
        require(rgl)
        if (length(main)==0) main <- ""
        vp <- round(100*pca$variance.per,1)
        pclabs <- c( paste0("PC",PCx,"\n(",vpr[PCx],"%)"), paste0("PC",PCy,"\n(",vpr[PCy],"%)"), paste0("PC",PCz,"\n(",vpr[PCz],"%)") )
        lims <- apply(sp[,c(PCx,PCy,PCz)], 2, extendrange, f=0.075)  # capture limits BEFORE possible point removal
        remove <- scols==0
        IM(sum(remove),length(remove))
        if (any(remove)) {
            ## scols==0 points aren't meant to be visible, but rgl() shading will make them visible.
            ## so, we have to remove these points entirely, but preserve original plot xyz limits (captured above)
            sp <- sp[!remove,]
            scols <- scols[!remove]
            custom.labels <- custom.labels[!remove]
        }
        plot3d(sp[,PCx], sp[,PCy], sp[,PCz], pclabs[1], pclabs[2], pclabs[3], "s", scols, size, xlim=lims[,1], ylim=lims[,2], zlim=lims[,3])
        if (labels) {
            if (length(custom.labels)==0) custom.labels <- rownames(sp)
            text3d(sp[,PCx], sp[,PCy], sp[,PCz], custom.labels, adj=c(0.5,-1.5), col=scols)
        }
        if (hulls) {
            poly <- mat.split(sp[,c(PCx,PCy,PCz)], scols)  # split points by color; that is the only grouping vector we have to go on
            for (i in 1:length(poly)) {
                ## we aren't actually going to calculate 3D hulls; all points of one color will be connected with lines of that color.  So network, not hull
                for (j in 1:nrow(poly[[i]])) {
                    for (k in 1:nrow(poly[[i]])) {
                        if (j==k) next
                        lines3d(poly[[i]][c(j,k),1], poly[[i]][c(j,k),2], poly[[i]][c(j,k),3], col=names(poly)[i], lwd=size)
                    }
                }
            }
        }
        if (length(viewpoint)>0) do.call(rgl.viewpoint, viewpoint)
        if (plot.svm) {
            dat <- cbind(x=sp[,PCx], y=sp[,PCy], z=sp[,PCz])
            dat <- data.frame(dat, cl=svm.class)
            svm.model <- svm(cl~x+y+z, dat, type='nu-classification', kernel='linear', scale=FALSE)
            svm.pred <- predict(svm.model, dat[,-4])
            print(table(pred=svm.pred, true=dat[,4]))
            w <- t(svm.model$coefs) %*% svm.model$SV
            out$svm <- list(data=dat,model=svm.model,predict=svm.pred,hyperplane=c(w,-svm.model$rho))
            planes3d(w[1], w[2], w[3], -svm.model$rho, color="black", alpha="0.3")
        }
        ## rgl.viewpoint( theta = 0, phi = 15, fov = 60, zoom = 1, scale = par3d("scale"), interactive = TRUE, userMatrix )
    }
    
    ######## GENE PLOTS
    
    if (type == "gene" & is.null(PCz) & !smooth) {
        ## 2D gene plots, points
        if (length(main)==0) main <- "Gene Scores"
        pclabs <- c( paste0("PC",PCx," (",vpr[PCx],"%)"), paste0("PC",PCy," (",vpr[PCy],"%)") )
#        plot(gene.scores[,c(PBa,PCy)], col=0, xlab=pclabs[1], ylab=pclabs[2])
        plot(gene.scores[,c(PCx,PCy)], col=0, xlab=pclabs[1], ylab=pclabs[2], main=main)
        abline(h=0, v=0, lty=size, col=8)
#        points(gene.scores[,c(PBa,PCy)], pch=19, col=scols, cex=size*cex)
        points(gene.scores[,c(PCx,PCy)], pch=19, col=scols, cex=size*cex)
        if (labels) text(sp[,PCx], sp[,PCy], rownames(sp))
    }
    
    if (type == "gene" & is.null(PCz) & smooth) {
        ## 2D gene plots, smooth
        require(smoothScatter)
        if (length(main)==0) main <- ""
        ## ######################
    }
    
    if (type == "gene" & !is.null(PCz)) {
        ## 3D gene plots, static
        require(scatterplot3d)
        if (length(main)==0) main <- ""
        ## ######################
    }
    
    if (type == "gene.rgl" & !is.null(PCz)) {
        ## 3D gene plots, dynamic
        require(rgl)
        if (length(main)==0) main <- ""
        vp <- round(100*pca$variance.per,1)
        pclabs <- c( paste0("PC",PCx,"\n(",vpr[PCx],"%)"), paste0("PC",PCy,"\n(",vpr[PCy],"%)"), paste0("PC",PCz,"\n(",vpr[PCz],"%)") )
        plot3d(gs[,PCx], gs[,PCy], gs[,PCz], pclabs[1], pclabs[2], pclabs[3], "s", scols, 0.5)
        if (labels) text3d(gs[,PCx], gs[,PCy], gs[,PCz], rownames(gs), adj=c(0.5,-1.5), col=scols)
        rgl.spheres(0, 0, 0, col=4, radius=0.1)
    }
    
    invisible(out)
}


apa.names$dev <- c(apa.names$dev, "PCA.explain")
PCA.explain <- function(pca, factors) {
    
    ## Takes a data.frame of factors and quantitates the degree to which each PC separates levels of each factor
    ## 'pca' is an output of PCA.basic()
    ## 'factors' is a length-2 list: elem 1 is a vector of factor types ("categorical" or "numeric"); elem 2 is a data.frame with samples on rows and factors on columns
    
    
    
    
    
}


apa.names$dev <- c(apa.names$dev, "PCA.relevant.genes")
PCA.relevant.genes <- function(pca, steps=100, score.cutoff=NA, drop.PC1=FALSE, cex=1) {
    
    ## Concept from "Interactive Exploration of Microarray Gene Expression Patterns in a Reduced Dimensional Space", Misra et al. 2002, Genome Research.
    ## Filter irrelevant genes out of a PCA by using max score value per gene.
    ## Compare change in score coords of retained genes in full-pca vs. filtered-pca, by squared error.
    ## Want to maximize gene removal while minimizing squared error.
    ##
    ## 'pca' is an output from PCA.basic(); preferably using all genes.
    ## 'steps' indicates the number of iterations made while filtering from min score value to max score value.
    ##  - resulting plot indicates where cutoff should be made.
    ## 'score.cutoff' reruns the procedure with a static cutoff and shows results.  Will not run 'steps' iterations.
    ## 'drop.PC1' for consistency with PCA.basic() methods.
    
    gs <- pca$gene.scores
    gs <- gs[match(rownames(pca$input),rownames(gs)),]  # just in case gene.scores row order changes (to clustered) in the future
    lmax <- apply(abs(gs),1,max)
    xseq <- seq(0, steps, length.out=10)
    xlab <- seq(min(lmax), max(lmax), length.out=10)
    ylab.g <- seq(1, nrow(gs), length.out=10)
    
    par(mar=c(5,4,4,4), las=1, cex=cex)
    if (!is.na(score.cutoff)) {
    } else {
        bins <- seq(min(lmax), max(lmax), length.out=steps)
        bin.dat <- new.list(1:steps)
        for (i in 1:steps) {
            w <- which(lmax>=bins[i])
            inp <- pca$input[w,,drop=FALSE]
            gsi <- try(PCA.basic(inp, drop.PC1=drop.PC1)$gene.scores, silent=TRUE)
            if (class(gsi)=="try-error") {  # pca fail -- too few genes
                bin.dat[[i]] <- list(gene.scores.in=data.frame(), gene.scores.out=data.frame(), sq.diff=NA)
            } else {
                bin.dat[[i]] <- list(gene.scores.in=gs[w,], gene.scores.out=gsi, residuals=lm(gs[w,]~gsi)$residuals)
            }
        }
        results <- t(sapply(bin.dat, function(x) c(GENES=nrow(x$gene.scores.out), MSQD=sum(x$residuals)) ))
        ylab.d <- seq(min(results[,2],na.rm=TRUE), max(results[,2],na.rm=TRUE), length.out=10)  # FIRST
        for (i in 1:2) { results[,i] <- results[,i]-min(results[,i],na.rm=TRUE); results[,i] <- results[,i]/max(results[,i],na.rm=TRUE) }  # SECOND
        plot(1:steps, results[,1], col=4, type="l", xlab="Genewise Max Score", ylab="", main="", xaxt="n", yaxt="n")
        lines(1:steps, results[,2], col=2)
        axis(1, xseq, labels=round(xseq,4))
        axis(2, seq(0,1,length.out=10), labels=round(ylab.g,0), col=4)
        axis(4, seq(0,1,length.out=10), labels=round(ylab.d,0), col=2)
    }
    
    invisible(results)
    
    
}


apa.names$dev <- c(apa.names$dev, "PCA.score.plots")
PCA.score.plots <- function(mat, plot=TRUE, adjust.1=FALSE, min.radii=0, cut.radians=0, top.n=0, coloration=c("radial","density"), select=NULL) {
    
    ## Concept from "Interactive Exploration of Microarray Gene Expression Patterns in a Reduced Dimensional Space", Misra et al. 2002, Genome Research.
    ## Multifunction function for extracting major trends and critical genes from PCA scores.
    ## Takes 2 component gene score vectors at a time, as a 2-col matrix (i.e. gene scores on PC1 & PC2)
    ## Provides a biplot, a radially-unwrapped biplot and densities for r, theta values
    ## Can opt to drop points below a given radius (set 'min.radii')
    ## Can opt to rotate the unwrapped plot, if a structure crosses the 0/2pi boundary (set 'cut.radians')
    ## Can opt to define/quantitate the top N radial structures detectable by kernel density (set 'top.n')
    ## 
    ## 'plot': generates plots if TRUE (otherwise, will still return data invisibly)
    ## 'min.radii': a number >= 0.  Does nothing if 0.
    ## 'cut.radians': a value between 0 and 2pi, or "auto" to cut & rotate based on point of lowest radial density.
    ## 'top.n': detect & quantitate the top N radial structures (or as many as can be found, if < N exist).
    ##          detection uses kernel density on theta values and takes values of the top.n positive modes ranked by peak height.
    ## 'select': a list of length='top.n', values are numeric ranges (min,max); theta-positions of selections may be adjusted by specifying new ranges here
    ##           for instance, if selection 3 chose theta range = c(0,0.3926991), you can shift it 0.1 by making element 3 of 'select' = c(0.1,0.4026991)
    
    coloration <- match.arg(coloration)
    if (top.n > 0) cut.radians <- "auto"   # not guaranteed a useful visual arrangement of radial structures unless cut.radians="auto"
    if (adjust.1) mat[,1] <- mat[,1]-max(mat[,1])
    rth <- t( apply(mat, 1, xy2polar) )[,2:1]
    mat <- mat[order(rth[,1]),]
    rth <- rth2 <- rth[order(rth[,1]),]
    if (coloration == "density") {
        col <- rainbow(nrow(mat))
    } else {
        rcols <- rainbow(1000)
        rbins <- seq(0,2*pi,length=1001)[1:1000]  # because 2pi itself == 0, so don't double-count it, just to be proper
        col <- rcols[match(quantize(rth[,1],rbins),rbins)]
    }
    xseq <- seq(0, 2*pi, 0.125*pi)
    xlab <- rep("",length(xseq)); xlab[seq(1,length(xseq),2)] <- c("0","pi/4","pi/2","3pi/4","pi","5pi/4","3pi/2","7pi/4","2pi")
    ## rearrange rth rows, xseq to break across 'brk' instead of the 0/2pi boundary
    brk <- ifelse(cut.radians=="auto", quantize(min(modes(rth[,1])$neg[,1]), xseq), cut.radians)
    if (brk == 2*pi) brk <- 0
    if (brk == 0 | brk == 2*pi) {
        xlab2 <- xlab
        col2 <- col
        matchlab <- c("0","pi/2","pi","3pi/2","2pi")
    } else {
        wx1 <- which(xseq<brk); wx2 <- which(xseq>=brk)
        wx <- c(wx2[-length(wx2)],wx1,wx2[1])  # remove last wx2 -- 2pi -- now redundant.  New first element copied to last
        xlab2 <- xlab[wx]
        matchlab <- c("0","pi/2","pi","3pi/2")
        wr1 <- which(rth[,1]<brk); wr2 <- which(rth[,1]>=brk)
        wr <- c(wr2,wr1)
        col2 <- col[wr]
        rth2[wr1,1] <- rth2[wr1,1]+2*pi
        rth2[,1] <- rth2[,1]-brk
        rth2 <- rth2[wr,]
        for (i in 1:length(select)) {  # 'select' coords must be shifted, too
            if (length(select[[i]])==2) select[[i]] <- select[[i]]+2*pi-brk
        }
    }
    mat.1 <- mat; rth.1 <- rth; rth2.1 <- rth2; col.1 <- col; col2.1 <- col2  # "uncut" versions, just in case
    ## select points beyond N radii
    if (min.radii > 0) {
        ## rth-linked cuts
        mat <- mat[rth[,2]>=min.radii,,drop=FALSE]
        col <- col[rth[,2]>=min.radii]
        rth <- rth[rth[,2]>=min.radii,,drop=FALSE]
        ## rth2-linked cuts
        col2 <- col2[rth2[,2]>=min.radii]
        rth2 <- rth2[rth2[,2]>=min.radii,,drop=FALSE]
    }
    ## find top N radial structures
    if (top.n > 0) {
        m <- modes(rth2[,1], adjust=pi/8)$pos
        if (top.n > nrow(m)) {
            message("top.n value '",top.n,"' exceeds number of modes '",nrow(m),"': reducing to ",nrow(m),".")
            top.n <- nrow(m)
        }
        m <- m[rev(order(m[,2])),,drop=FALSE]
        top.rad <- new.list(1:top.n)
        for (i in 1:top.n) {
            if (length(select)>=i) {
                if (length(select[[i]])==2) top.rad[[i]] <- select[[i]]   # custom window: override automatic selection
            } else {
                top.rad[[i]] <- c(m[i,1]-pi/16, m[i,1]+pi/16)   # window of width pi/8 centered on mode
            }
        }
        top.rth2 <- lapply(top.rad, function(x) which(rth2.1[,1]<=x[2] & rth2.1[,1]>=x[1]) )
        top.rth <- lapply(top.rth2, function(x) match(rownames(rth2.1)[x],rownames(rth.1)) )
        top.points <- lapply(1:top.n, function(i) list( mat=mat.1[top.rth[[i]],], rth=rth.1[top.rth[[i]],], rth2=rth2.1[top.rth2[[i]],], col=col2.1[top.rth2[[i]]] ) )
    } else {
        m <- NULL
        top.points <- c()
    }
    ## continue plotting
    yseq <- 0:ceiling(max(rth2[,2]))
    if (plot) {
        par(mfrow=c(2,2), mar=c(4,4,3,1))
        ## scores biplot
        smax <- max(abs(c( floor(min(mat)), ceiling(max(mat)) )))
        plot(mat, col=col, xlim=c(-smax,smax), ylim=c(-smax,smax), xlab=paste(colnames(mat)[1],"scores"), ylab=paste(colnames(mat)[2],"scores"))
        symbols(rep(0,smax), rep(0,smax), circles=1:smax, fg=8, add=TRUE, inches=FALSE)
        abline(h=0, v=0)
        if (brk != 0) {
            cx <- smax*cos(brk)
            cy <- smax*sin(brk)
            segments(0,0, cx,cy, col=8, lty=3)  # plot cut point
#            text(cx, cy, "Cut Point")
        }
        ## radially-unwrapped scores biplot
        null.plot(xlim=range(xseq), ylim=range(yseq), xlab="radians", ylab="radii")
        axis(1, xseq, xlab2); axis(2, yseq, las=1)
        points(rth2, col=col2)
        abline(h=yseq, col=8)
        abline(v=xseq[match(matchlab,xlab2)], col=1)
        if (top.n > 0) {
            for (i in 1:top.n) {
                rect(min(top.points[[i]]$rth2[,1]),0, max(top.points[[i]]$rth2[,1]),smax, col="#88888844", border=NA)
                mtext(paste0("#",i), side=3, line=0, at=mean(top.points[[i]]$rth2[,1]), col=1)
            }
        }
        ## radial selections, if any (otherwise blank)
        null.plot(xlim=c(0,10), ylim=c(0,10))
        if (top.n > 0) {
            titles <- c("N","Radians","Height","Points",paste("Above",min.radii))
            x.pos <- c(N=0.5, Radians=2, Height=4, Points=6, Above=8)
            y.pos <- seq(0,10,length.out=top.n+1)
            revi <- top.n:1
            for (i in 1:top.n) {
                i.pts <- top.points[[i]]$rth
                x.text <- list(N=i, Radians=round(m[i,1],3), Height=round(m[i,2],3), Points=nrow(i.pts), Above=sum(i.pts[,2]>=min.radii))
                jmax <- ifelse(min.radii>0, 5, 4)
                i.col <- top.points[[i]]$col[round(nrow(i.pts)/2,0)]
                for (j in 1:jmax) text(x.pos[j], y.pos[revi[i]], x.text[j], col=i.col)
            }
            for (j in 1:jmax) text(x.pos[j], y.pos[top.n+1], titles[j], font=2)
        }
        ## radial density histogram
        dhist(rth2, adjust=pi/8, col=c(2,4), xlim=range(xseq), xaxt="n", xlab="", main="", ylab="Radial Densities of Scores", legend=NA)
        legend("topright", bty="n", col=c(0,4,2), lty=1, legend=c("","r","theta"))
        axis(1, xseq, xlab2, col=2)
        axis(3, 0:smax, labels=0:smax, col=4, line=-1)
    }
    invisible(list(r.theta=rth,selections=top.points))  # NOT rth2
}



apa.names$dev <- c(apa.names$dev, "SVGMAplot")
SVGMAplot <- function(x, ann, imgname, sig=0.05, fc=0, minA=-Inf, show=FALSE, cols=c(2,3,8,1), main="MA Plot", page.title="MA Plot", xlab="Log2 Mean", ylab="Log2 Fold-Change", xlim=NULL, ylim=NULL, handlers=FALSE) {
    
    ## Plots an MA plot using SVG, which allows mouseover popups with gene data for significant points.
    ## 'x' is a 3-column dataframe: M, A, p-value (or some other score).  MUST HAVE ROWNAMES = GENE IDS.
    ## 'ann' is a 9-column gene annotation dataframe with gene IDs in col 1.  Expected columns in order: GeneID,Symbol,Chr,Start,End,Strand,Biotype,Status,Description.
    ## 'imgname' is an output image name (should have .svg suffix).
    ## 'sig' is a cutoff for determining significance (applied to x[,3]).
    ## 'fc' is an additional cutoff to be applied with 'sig', for restricting which points are significant.
    ##   cutoff will be applied + and -, thus "fc=3" selects for points >= 3 and <= -3.
    ## 'minA' is another additional cutoff to be applied with 'sig', which specific minimum x-axis value to flag point as significant.
    ## 'show'=T' launches SVG image in firefox
    ## 'cols' is a length=4 vector with colors for sig up, sig down, background, and abline
    
    require(RSVGTipsDevice)
    
    ## Point sets
    non.sig <- which(abs(x[,1])<fc | x[,2]<minA | x[,3]>sig)
    sig.up <- which(x[,1]>=fc & x[,2]>=minA & x[,3]<=sig)
    sig.dn <- which(x[,1]<=-fc & x[,2]>=minA & x[,3]<=sig)
    message(paste("UP:",length(sig.up),"| DOWN:",length(sig.dn)))
    
    ## Tip text format: "symbol\ngeneID\nchr:start-end:strand\nstatus biotype\ndescription"
    ann <- ann[match(rownames(x),ann[,1]),]
    tips <- paste(ann[,2],ann[,1],paste0(ann[,3],":",ann[,4],"-",ann[,5],":",ann[,6]),paste(ann[,8],ann[,7]),ann[,9],sep="\n")
    
    ## Other plot params
    if (length(xlim)==0) xlim <- range(x[,2], na.rm=TRUE)
    if (length(ylim)==0) ylim <- range(x[,1], na.rm=TRUE)
    
    ## base plot
    devSVGTips(imgname, toolTipMode=1, title=page.title)  # this title is for the web page
    plot(0, 0, col=0, xlim=xlim, ylim=ylim, xlab=xlab, ylab=ylab, main=main, las=1)  # empty plot frame
    ## no tooltips (not sig DE)
    points(x[non.sig,2:1], col=cols[3])
    abline(h=0, col=cols[4])
    ## red tooltips (sig DE up)
    invisible(sapply(sig.up, function(i) {
        setSVGShapeToolTip(title=tips[i])
        points(x[i,2], x[i,1], col=cols[1])  # points must have pch=1!  Popups don't appear otherwise.
    }))
    ## green tooltips (sig DE down)
    invisible(sapply(sig.dn, function(i) {
        setSVGShapeToolTip(title=tips[i])
        points(x[i,2], x[i,1], col=cols[2])  # points must have pch=1!  Popups don't appear otherwise.
    }))
    dev.off()
    ## knock out JS event listeners -- Chrome & FF do it better, natively -- now we don't have redundant, overlapping popups!
    if (!handlers) system(paste("perl -i -pe 's!SVGRoot.addEventListener!// SVGRoot.addEventListener!'",imgname))
    ## can be buggy, but works well enough to show you the plot
    if (show) system(paste("firefox",imgname,"&"))
    
    ## notes:
    ## do not use "desc" argument in setSVGShapeToolTip() -- paste lines together with "\n" and load into "title" argument
    ## perl call is not necessary, but plot has annoying double-display of popups without it -- first from JS, then from browser itself.
    ## points() calls within sapply apparently can't handle single-arg x,y coords: must give x, y explicitly
}


apa.names$dev <- c(apa.names$dev, "coverage.matrix.generate")
coverage.matrix.generate <- function(bams, bed, path, nwin=100, ncpu=1, inputs=NULL, clobber=FALSE, skip=FALSE) {
    
    ## wrapper for cov.mat() from CoverageView package
    ## writes each matrix to an RData file
    ## 
    ## 'bams' is a NAMED vector of bam file paths.
    ## 'bed' is a bed file path
    ## 'path' is the output location; files will be named like "path/names(bams)[n].coverage_matrix_data.RData"
    ## 'nwin', 'ncpu' are further params for cov.mat()
    ## 'inputs' is a NAMED vector of ***input RData files*** with same length as 'bams'; enables IP/input fold-change matrices.
    ## 'inputs' can also be a LIST of such vectors, if any multiple IP/input pairings exist (e.g. IPs with 2 inputs, like mock and IgG).
    ## 'clobber' indicates to overwrite existing output file with same name; by default will not overwrite.
    
    suffix <- ".coverage_matrix_data.RData"
    
    require(CoverageView)

    B <- length(bams)
    bam.names <- names(bams)
    if (any(grepl("/",bam.names))) stop("Bam names must not contain slashes!\n")
    if (length(unique(bam.names)) < B) stop("Bam names must be unique!\n")
    bams.exist <- file.exists(bams)
    if (!all(bams.exist)) stop(paste("Some of these bam files do not exist!\n",paste0("  ",bams[!bams.exist],"\n")))
    bams.indexed <- file.exists(paste0(bams,".bai"))
    if (!all(bams.indexed)) stop(paste("Some of these bam files are not indexed!\n",paste0("  ",bams[!bams.indexed],"\n")))
    if (!file.exists(bed)) stop(paste0("Bed file '",bed,"' does not exist!\n"))
    
    outfiles <- paste0(path,"/",bam.names,suffix)
    names(outfiles) <- bam.names
    outfiles.exist <- file.exists(outfiles)
    if (any(outfiles.exist)) {
        filelist <- paste(paste0("  ",outfiles[outfiles.exist],"\n"),collapse="")
        if (clobber) {
            message(paste0("Some output files already exist: clobbering these\n",filelist))
        } else if (skip) {
            message(paste0("Some output files already exist: skipping these\n",filelist))
        } else {
            stop(paste0("Some output files already exist, but 'clobber' and 'skip' are both FALSE!  Halting...\n",filelist))
        }
    }
    
    I <- length(inputs)
    have.inputs <- FALSE
    if (I>0) {
        have.inputs <- TRUE
        if (is.nlv(inputs)) {
            inputs <- as.list(inputs)
            for (i in 1:length(inputs)) names(inputs[[i]]) <- names(inputs)[i]
            inputs <- nameless(inputs)
        }
        inputs <- lapply(inputs, function(x) x[sort(names(x))] )   # if > 1 element, then name sorting is important for future lookups
        inpN <- unlist(lapply(inputs,names))
        inpF <- unlist(inputs)
        uinpF <- real(unique(inpF))
        
        if (I!=B) {
            stop("If specified, 'inputs' must be same length as 'bams'!\n")
        } else if (!all(file.exists(uinpF))) {
            stop("Some 'inputs' files do not exist!\n")
        } else if (length(inpN)!=length(inpF)) {
            stop("Some 'inputs' files are missing names!\n")
        } else {
            input.logrpm <- new.list(1:B)
            for (i in 1:I) {
                if (all(is.na(inputs[[i]]))) {
                    ## leave input.logrpm[[i]] empty
                } else {
                    J <- length(inputs[[i]])
                    input.logrpm[[i]] <- new.list(names(inputs[[i]]))
                    for (j in 1:J) {
                        load(inputs[[i]][j])  # loads 'coverage.matrix.data'
                        input.logrpm[[i]][[j]] <- coverage.matrix.data$matrix$logrpm  # ONLY logrpm matrix, only used for IP/inp LFC
                    }
                }
            }
            rm(coverage.matrix.data)
        }
    }
    
    ## Finished with input-error-checking steps by now, so now can mkdir and write README.
    
    if (!file.exists(path)) system(paste("mkdir -p",path))
    if (!file.exists(path)) stop(paste0("Output path '",path,"' does not exist!\n"))
    
    aligns <- sapply(bams, function(x) as.numeric(system(paste("bash -c 'paste -s -d+ <(samtools idxstats",x,"| grep -vP \"^\\*\" | cut -f3) | bc'"), intern=TRUE)) )
    bed.names <- system(paste("cut -f4",bed), intern=TRUE)
    
    README <- c(
        "\nThis directory contains RData files with CoverageView coverage matrices + metadata.",
        "\nFiles were created with the function apa_tools.R::coverage.matrix.generate().",
        "\nThe bed file used to create these matrices is the only bed file in this directory.",
        "\nThere is one file per IP bam.  The IP may or may not have had associated inputs, which influences some content, see below.",
        "\nEach RData file contains one object named 'coverage.matrix.data', the structure of which is:",
        "\ncoverage.matrix.data <- list(",
        "    matrix=list(              # list of matrices of IP signal and transformations thereof.  Float values have been rounded to 3 places.",
        "        raw=matrix(...),      # Raw CoverageView::cov.matrix() output (transposed), such that rows = peaks, cols = coverageView bins.",
        "        logrpm=matrix(...),   # log2-adjusted-RPM, that is, log2(1E6*(raw+1)/M), where 'M' is the value of 'aligns' below.",
        "        pctmax=matrix(...),   # raw/max(raw).  To curb outliers, max(raw) is actually quantile(raw,0.99), and final matrix values > 1 have been thresholded down to 1.",
        "        zscore=matrix(...)    # the logrpm matrix, as row z-scores, i.e. t(scale(t(logrpm))).",
        "    ),",
        "    LFC.matrix=list(          # An empty list, OR, if N inputs supplied, then a list of N matrices, one for each input (usually, 0 or 1 inputs given).",
        "        input.i=matrix(...),  # IP 'logrpm' - input i 'logrpm'",
        "        ...,                  # ...",
        "        input.N=matrix(...)   # IP 'logrpm' - input N 'logrpm'",
        "    ),",
        "    aligns=aligns,            # N alignments in IP bam (samtools view IP.bam | wc -l)",
        "    bam=bams,                 # /path/to/IP.bam",
        "    bed=bed,                  # BED file supplied for CoverageView::cov.matrix()",
        "    inputs=inputs,            # vector of /path/to/input.bam(s), one for each matrix in 'LFC.matrix'.  Or, empty.",
        "    RData=outfiles            # /path/to/this.RData, just for reference.",
        ")",
        "\nThe function apa_tools.R::coverage.matrix.compile() can be used to lapply on a vector of RData filenames, and return a list of matrices.",
        "\nIf the file \"cov.mat.paths.RData\" exists (pipeline generated), it will contain a single list 'RDatas' which contains vectors of RData filenames, i.e. the directory tree in list format.\n"
    )
    write.vector(README, paste0(path,"/README.txt"))
    
    ## Process bams
    
    for (b in 1:B) {
        if (outfiles.exist[b] & skip) next
        M <- list()
        message(paste("Processing:",bams[b]))
        x <- suppressMessages(t(cov.matrix(CoverageBamFile(bams[b],reads_mapped=aligns[b]), coordfile=bed, no_windows=nwin, num_cores=ncpu)))
        message(paste("Post-processing:",bams[b]))
        rownames(x) <- bed.names
        bed.data <- read.bed(bed)
        
        M$raw <- x
        M$pctmax <- round(threshold(x/quantile(x,0.99),1,"gt"),3)
        a <- x+1                      ## ADJUST FIRST
        r <- 1E6*a/aligns[b]          ## RPM SECOND
        M$logrpm <- round(log2(r),3)  ## LOG THIRD
        M$zscore <- round(t(scale(t(M$logrpm))),3)
        mdim <- dim(M$logrpm)
        LFC <- NULL
        if (have.inputs) {
            LFC <- lapply(1:length(input.logrpm[[b]]), function(i) {
                idim <- dim(input.logrpm[[b]][[i]])
                #message(paste("IP",b,":",mdim[1],mdim[2]," INPUT",names(input.logrpm)[i],":",idim[1],idim[2]))
                M$logrpm - input.logrpm[[b]][[i]]
            })
            names(LFC) <- names(input.logrpm[[b]])
        }
        
        coverage.matrix.data <- list(
            matrix=M,
            LFC.matrix=LFC,
            aligns=aligns[b],
            bam=bams[b],
            bed=bed,
            inputs=inputs[[b]],
            RData=outfiles[b]
        )
        save(coverage.matrix.data, file=outfiles[b])
        message(paste("Completed:",bams[b]))
    }
    
    invisible(outfiles)
}


apa.names$dev <- c(apa.names$dev, "coverage.matrix.compile")
coverage.matrix.compile <- function(paths, matrix=c("logrpm","raw","pctmax","zscore","LFC"), LFC=1) {
    
    ## companion function to coverage.matrix.generate()
    ## returns a list of matrices from a list of coverage.matrix.generate() RData files
    ## 
    ## 'paths' is a NAMED vector of coverage.matrix.generate() RData objects.
    ## As each RData is loaded, the same matrix is extracted from it, and all matrices are returned in a list.
    ## 
    ## 'matrix' indicates what kind of matrix you want.
    ## 'LFC' only matters when using matrix="LFC": matrix will be taken from the "LFC.matrix" list; which one of them did you want?
    ##       NOTE 1: there is usually only one matrix in "LFC.matrix", so default value is 1.
    ##       NOTE 2: 'LFC' value can be an index number OR element name; will be inferred from the data type of the 'LFC' argument.
    ##
    ## Just to clarify:
    ## Matrices in 'coverage.matrix.data' objects are stored in one of two lists:
    ## coverage.matrix.data$matrix: four versions of the CoverageView matrix; raw, logrpm, zscore, and pct-of-max.
    ## coverage.matrix.data$LFC.matrix: for each associated input sample (if any), one log2(IP RPM / input RPM) matrix exists.
    ## 99% of the time, people only give one input per IP, thus the "LFC.matrix" list usually only has one matrix.
    
    matrix <- match.arg(matrix)
    paths.exist <- file.exists(paths)
    if (any(!paths.exist)) stop(paste("Some output files do not exist!\n",paste0("  ",paths[!paths.exist],"\n")))
    
    x <- lapply(1:length(paths), function(i) {
        suppressWarnings(rm(coverage.matrix.data))
        message(names(paths)[i])
        load(paths[i])  # gets 'coverage.matrix.data'
        LFC.names <- names(coverage.matrix.data$LFC.matrix)
        LFC.N <- length(coverage.matrix.data$LFC.matrix)
        if (matrix=="LFC") {
            if (is.character(LFC) && !(LFC %in% LFC.names)) stop(paste0("LFC.matrix name '",LFC,"' was not matched!\nExisting names: ",paste(LFC.names, collapse=", "),"\n"))
            if (is.numeric(LFC) && LFC>LFC.N) stop(paste0("LFC index ",LFC," exceeds LFC.matrix length of ",LFC.N,"!\n"))
            coverage.matrix.data$LFC.matrix[[LFC]]
        } else {
            coverage.matrix.data$matrix[[matrix]]
        }
    })
    
    if (length(names(paths))>0) {
        names(x) <- names(paths)
    } else {
        names(x) <- paths
    }
    x
}


apa.names$dev <- c(apa.names$dev, "coverage.matrix.bound")
coverage.matrix.bound <- function(heatmap, row.peaks, bam.peaks, extend=0, binarize=NULL, meta.data=NULL) {
    
    ## Takes a heatmap matrix (probably from coverage.matrix.generate()), the row peak list, the peak calls from the bam that the matrix was derived from,
    ##  and modified the matrix to indicate which peaks (rows) were considered "bound" by the sample peak calls.
    ## For example: you have a peak list from factor X and made CoverageView heatmaps from many bams, including the factor Y chipseq bam.
    ##              How many of these factor X peaks also had a peak call in the factor Y bam?  You could intersect peaks, but that would not illustrate it on your heatmap.
    ##              This function will keep factor-Y bound rows positive, and make factor-Y unbound rows negative.  Plot with Red->Blue palette, and see bound/unbound clearly.
    ## 
    ## 'heatmap':    a coverage heatmap matrix, say from t(CoverageView::cov.matrix()).
    ## 'row.peaks':  a peak list that was used to create 'heatmap', in same row order.  ORIGINAL PEAKS, NOT THE WULL-WINDOW PEAKS USED IN THE COV.MATRIX CALL.
    ## 'bam.peaks':  a separate set of peak calls from the bam used to create 'heatmap'.
    ## 'extend':     how far away may row.peaks be from bam.peaks and still be considered overlapping (default 0bp, must touch).
    ## 'binarize':   binarize the heatmap (see below) by giving the full heatmap row coords, i.e. the data from the bed file passed to cov.matrix().
    ## 'meta.data':  an optional metadata dataset for 'bam.peaks', in same row order.
    ## This function changes the sign of the rows in 'heatmap' to identify which rows (row.peaks) correspond to sample peak calls (bam.peaks).
    ## 
    ## More details:
    ## 'heatmap' is a heatmap-column matrix with rows = peaks and cols = spatial bins (returned by t(CoverageView::cov.matrix()), e.g.)
    ##           Matrix values MUST be non-negative, so DO NOT run this on a list of 'LFC' matrices.
    ## 'row.peaks' is a data.frame of peak coords from which rows of 'heatmap' were derived, and in same order.
    ##             HOWEVER:
    ##             These must be the ORIGINAL peaks, because we want to know if sample peaks intersect the original peaks.
    ##             The actual heatmap would probably have been generated from an extended version of these peaks, e.g. peak midpoint +-5kb.
    ##             The extended peaks, if they exist, can be supplied to 'binarize' if binarization is desired.
    ## 'bam.peaks' is a data.frame of peak coords, which are peak calls from the bam file used to create 'heatmap'.
    ##             ** These may be totally unrelated to 'row.peaks'. **
    ## 'extend' extends 'row.peaks' by this much on either side.  E.g. if 500, then sample peaks up to 500bp away from a row.peak will still be considered overlapping.
    ##          NOTE: negative values of 'extend' are allowed, but be careful with that.
    ## 'binarize' an optional extended version of 'row.peaks', same order -- but must be the full extended peaks used to create 'heatmap', i.e., as used by cov.matrix().
    ##            If supplied, 'heatmap' will be converted to 0/1 where 1=sample-bound region and 0=sample-unbound.
    ##            Knowing the full heatmap windows is necessary to determine which cells are covered by the sample peak calls.
    ##            Columns of 'heatmap' are probably bins.  If a sample peak call only partially overlaps a bin, the value will be the percent of bin overlapped (0 < value < 1).
    ## 'meta.data' is an optional metadata data.frame for 'bam.peaks', in same row order.
    ##             Tf specified, 'meta.data' will be returned with a new logical column, "Bound", simplifying separation of bound/non-bound rows.
    ## 
    ## 1. Rows of 'row.peaks' will be compared to 'bam.peaks' to find overlaps (co-binding events).
    ## 2. Rows of 'heatmap' for sample-bound peaks will remain positive, while rows for sample-unbound peaks will become negative (just a sign switch).
    ## 3. Resulting heatmaps can be plotted with a diverging palette, e.g. red->blue, and sample-bound coords will be red while sample-unbound will be blue.
    
    require(GenomicRanges)
    
    NR <- nrow(heatmap)
    NC <- ncol(heatmap)
    do.meta <- length(meta.data)>0
    do.bin  <- length(binarize)>0
    if (nrow(row.peaks) != NR) stop("'row.peaks' does not match N rows of 'heatmap'!\n")
    
    if (do.bin) {
        full.peaks <- binarize   # give the object a more appropriate working name
        full.peaks.gr <- bed2gr(full.peaks)
        row.peaks.gr <- bed2gr(row.peaks)
        bro <- suppressWarnings(as.matrix(findOverlaps(full.peaks.gr,row.peaks.gr)))
        ok <- length(unique(bro[,1]))==nrow(full.peaks) & length(unique(bro[,2]))==nrow(row.peaks)
        if (!ok) stop("'binarize' does not derive from 'row.peaks'!  Non-intersecting intervals exist.\n")
    }

    row.peaks2 <- row.peaks
    if (extend!=0) {
        row.peaks2[,2] <- row.peaks2[,2]-extend
        row.peaks2[,3] <- row.peaks2[,3]+extend
    }
    row.peaks2.gr <- bed2gr(row.peaks2)
    bam.peaks.gr <- bed2gr(bam.peaks)
    bound <- suppressWarnings(as.matrix(findOverlaps(row.peaks2.gr,bam.peaks.gr)))
    colnames(bound) <- c("Row.Peak","Bam.Peak")
    unbound <- setdiff(1:nrow(row.peaks), bound[,1])
    matched <- failed <- 0
    
    if (do.bin) {
        bppc <- round((full.peaks[1,3]-full.peaks[1,2])/NC, 0)  # mean bp per heatmap column; > 1 if binning took place
        f <- full.peaks[bound[,1],]
        b <- bam.peaks[bound[,2],]
        ob <- (as.matrix(b[,2:3])-f[,2])/bppc          # per row, bam.peak position within heatmap matrix, as c(start column, end column), but carrying decimals
        obi <- cbind(ceiling(ob[,1]),floor(ob[,2]))    # 'ob' as integer, which is start/end columns of 100% binding saturation
        obi[obi[,1]<1,1] <- 1                          # truncate 5' runoff
        obi[obi[,2]>100,2] <- 100                      # truncate 3' runoff
        obf <- ob-floor(ob)                            # fractional part of 'ob', which will be binding saturation % of flanking bins (1 on either side)
        heatmap <- matrix(0, NR, NC)                   # reboot heatmap with all 0 values
        for (i in 1:nrow(bound)) {
            j <- bound[i,1]
            if (obi[i,2]<obi[i,1]) {                   # extend>0 can lead to "bound" regions being entirely out of the window; skip these...
                failed <- failed + 1
            } else {
                #IM(i, nrow(bound), obi[i,1], obi[i,2])
                heatmap[j,obi[i,1]:obi[i,2]] <- 1
                if (obi[i,1]>1) heatmap[j,obi[i,1]-1] <- obf[i,1]    # fill in 5' flank value, if position contained within heatmap
                if (obi[i,2]<100) heatmap[j,obi[i,2]+1] <- obf[i,2]  # fill in 3' flank value, if position contained within heatmap
                matched <- matched + 1
            }
        }
        for (j in 1:NC) heatmap[heatmap[,j]>1,j] <- 1  # if overlapping bam peaks added up to > 1, truncate // by column to avoid excessive index vectors for large matrices
    } else {
        heatmap[unbound,] <- -1 * heatmap[unbound,]
    }
    message("PEAKS: ",nrow(bam.peaks)," | MATCH: ",matched," | FAIL: ",failed," | UN: ",length(unbound))
    
    if (do.meta) {
        meta.data <- cbind(meta.data, Bound=c(1:nrow(meta.data) %in% bound[,2]))
        list(heatmap=heatmap, bound=bound, meta.data=meta.data)
    } else {
        list(heatmap=heatmap, bound=bound)
    }
}


apa.names$dev <- c(apa.names$dev, "coverage.matrix.boundcolor")
coverage.matrix.boundcolor <- function(full, binary) {
    
    ## 'full': a list of heatmap matrices with bam-signal LFC0 (or other bam-signal values with minimum value=0)
    ## 'binary': the binarized version of 'full', after being run through coverage.matrix.bound()
    ## output: 'full', with sign switched for unbound regions.
    ##   Basically, based on 'binary', 'full' rows will either stay positive (bound) or become negative (unbound).
    ##   Then, you can cbind 'full' and plot it with a diverging palette, to see if the binarized version is acceptable, or whether peak call sig threshold should be changed, etc.
    
    if (length(full) != length(binary)) stop("'full' and 'binary' must be lists of equal length!\n")
    if (!all(sapply(full,dim) == sapply(binary,dim))) stop("'full' and 'binary' matrices must have same dimensions!\n")
    full.r <- sapply(full,range)
    bin.r <- sapply(binary,range)
    if (any(full.r<0)) stop("'full' values must all be >= 0!\n")
    if (any(bin.r<0 | bin.r>1)) stop("'binary' values must all be >= 0 and <= 1!\n")
    
    signed <- lapply(full,as.matrix)  # be ABSOLUTELY SURE that these are matrices
    for (i in 1:length(full)) {
        unbound <- which(rowSums(binary[[i]])==0)
        signed[[i]][unbound,] <- -signed[[i]][unbound,]
    }
    signed
}


apa.names$dev <- c(apa.names$dev, "coverage.matrix.cbind")
coverage.matrix.cbind <- function(x, spacer=10, sort.each=FALSE) {
    
    ## Takes a list of matrices 'x' and cbinds them all into one matrix, with NA spacers in between.
    ## Width of spacers, in columns, given by 'spacer'.
    ## 'sort.each=TRUE' will sort each matrix independently by rowSum (highest->lowest); matrices will NOT be cbound with the same row order (at least, same ordering is highly unlikely).
    ## Matrices MUST all have same N rows!
    
    L <- length(x)
    x <- lapply(x, as.matrix)
    spc <- matrix(NA, nrow(x[[1]]), spacer)
    if (sort.each) x <- lapply(x, function(y) y[rev(order(rowSums(y))),] )
    for (i in 1:(L-1)) x[[i]] <- cbind(x[[i]],spc)   # do not add spacer to final matrix
    y <- do.call(cbind, x)
    colnames(y) <- rep("",ncol(y))
    if (length(names(x))>0) colnames(y)[1] <- paste(names(x), collapse="; ")  # it's there if you want it
    y
}


apa.names$dev <- c(apa.names$dev, "coverage.matrix.compress")
coverage.matrix.compress <- function(x, reduce=10, spacer=NULL, binary=FALSE) {
    
    ## 'x' is either the output of coverage.matrix.cbind(), or the input to it.  Can be one matrix, or a list of them.
    ## reduces matrix columns by a factor of 'reduce', using the average.
    ## 'reduce' is the column reduction factor.
    ##   for instance if each matrix in 'x' if 100 columns, and 'reduce=20',
    ##   then 100/20 = 5 output columns, each one the mean of 20 original columns.
    ## 'spacer' only applies if 'x' was a matrix with spacer columns:
    ##   if 'NULL', then output will have same spacers as input
    ##   if numeric, then output will have spacers of that width (in columns).
    ##   if NA, output will not have spacer columns.
    ## 'binary' reduces each row to 0/1 based on whether nonzero values exist (assumes binarized bound/unbound heatmaps)
    
    if (is.ndfl(x)) {
        ## list of input matrices (we assume matrices)
        ## do nothing
        mat.in <- FALSE
        spacer.width <- NA
    } else if (is.matrix(x)) {
        ## cbound matrix
        ## convert cbound matrix back to the original list of input matrices
        mats <- find.runs(!is.na(x[1,]))  # columns of the original sub-matrices (non-spacer columns)
        x <- lapply(mats[ names(mats)=="TRUE" ], function(y) x[,y] )  # split into list of sub-matrices
        mat.in <- TRUE
        spacer.width <- diff(mats[[ which(names(mats)=="FALSE")[1] ]])+1
    } else {
        stop("'x' must be a matrix, or a list of matrices!\n")
    }

    if (binary) {
        y <- lapply(x, function(y) as.matrix(0+apply(y>0,1,any)) )
    } else {
        y <- lapply(x, function(y) {
            ends <- trunc(seq(0,ncol(y),length=reduce+1))
            starts <- ends[1:reduce]+1
            ends <- ends[2:(reduce+1)]
            sapply(1:reduce, function(i) rowMeans(y[,starts[i]:ends[i]]) )
        })
    }
    
    if (mat.in) {
        if (length(spacer)==0) {
            coverage.matrix.cbind(y, spacer.width)
        } else if (is.na(spacer)) {
            do.call(cbind,y)
        } else {
            coverage.matrix.cbind(y, spacer.width)
        }
    } else {
        y
    }
}


apa.names$dev <- c(apa.names$dev, "peak.featuremap")
peak.featuremap <- function(wins, peaks, feats=NULL, feat.space=c("peak","genomic"), compress=NULL) {
    
    ## Create an integer-valued heatmap matrix of peak positions 'peaks' within windows 'wins', optionally annotated with smaller features 'feats' (e.g. motif sites).
    ## 'wins' is a BED data.frame of window coords, MUST ALL HAVE SAME WIDTH.  Output matrix will have this width.
    ## 'peaks' is a BED data.frame of peak coords which overlap (ideally, contained by) 'wins'; MUST HAVE SAME ROW ORDER.
    ## 'feats' is an optional BED data.frame of feature coords within 'peaks' (NOT within 'wins').
    ##         Scores of 'feats' (col 5) are distinctive integers > 1; output cells which contain these feats will be given those score values.
    ##           e.g. if 'feats' are hits from various motifs, then all hits for one motif should have the same score.
    ##         Do not use values of 0, 1 since these are already reserved for the default value (0) and the peak region (1).
    ## 'feat.space' is required if using 'feats', and indicates if the coord space of 'feats' is relative to peaks (i.e. 0-peak_width), or relative to genome (same coord space as peaks).
    ## 'compress' is an optional output column number, less than the width of 'wins' intervals.  Will compress output by binning along columns.
    
    if (!is.null(compress)) stop("Compression not yet supported!  Please avoid this argument.\n")
    
    if (nrow(wins)!=nrow(peaks)) stop("'wins' and 'peaks' do not have same rows!\n")
    feat.space <- match.arg(feat.space)
    win.gr <- bed2gr(wins)
    peaks.gr <- bed2gr(peaks)
    wpo <- as.matrix(findOverlaps(wins.gr,peaks.gr))
    ok <- length(unique(wro[,1]))==nrow(wins) & length(unique(wro[,2]))==nrow(peaks)
    if (!ok) stop("'peaks' does not fully intersect with 'wins'!  Non-intersecting intervals exist.\n")
    P <- nrow(peaks)
    W <- wins[1,3]-wins[1,2]
    have.feats <- length(feats)>0
    if (have.feats) if (!all(feats[,1] %in% peaks[,4])) stop("'feats' do not all belong to 'peaks': 'feats' column 1 not contained by 'peaks' column 4!\n")
    
    m <- matrix(0, P, W, FALSE, list(peaks[,4],c()))
    op <- as.matrix(p[,2:3])-w[,2]
    for (i in 1:P) m[i,op[i,1]:op[i,2]] <- 1  # cells occupied by peaks -> 1
    if (have.feats) {
        of <- mat.split(feats, feats[,1])
        of <- of[real(match(peaks[,4],names(of)))]
        wp <- match(names(of),peaks[,4])
        if (feat.space=="peak") {
            for (i in 1:length(wp)) of[[i]][,2:3] <- of[[i]][,2:3]+peaks[wp[i],2]-win[wp[i],2]  # peak coords -> genomic coords -> local window coords
        } else if (feat.space=="genomic") {
            for (i in 1:length(wp)) of[[i]][,2:3] <- of[[i]][,2:3]-win[wp[i],2]                 # already genomic coords -> local window coords
        }
        for (i in 1:length(wp)) {
            for (j in 1:nrow(of[[i]])) m[i,of[[i]][j,2]:of[[i]][j,3]] <- of[[i]][j,5]
        }
    }
    
    if (!is.null(compress)) {
        ## Shrink N columns in matrix by binning columns and taking means; decide what values the bins get.
        m2 <- matrix(0, P, compress, FALSE, list(peaks[,4],c()))
        
        ### WORKING HERE ###
        
        m2
    } else {
        m
    }
}


apa.names$dev <- c(apa.names$dev, "cluster.subunit")
cluster.subunit <- function(data, verbose=FALSE) {
    
    ## This is the first of three variants.  It executes ALL given jobs in parallel.
    ## 'data' must be a list of jobs, all at first level, one element per job.
    
    ## runs multiple 1-core clustering jobs in parallel.
    ## 'data' is a list of data to be clustered.
    ## output object will be a list of outputs, one for each element of 'data'.
    ## 
    ## each element of 'data' must be a list with AT LEAST two elements, 'matrix' and 'command':
    ##  1. data[[i]]$matrix: a numeric matrix to be clustered
    ##  2. data[[i]]$command: a string which, when executed in R -- via eval(parse(text="cmd")) -- will cluster data[[i]]$matrix.
    ##    A. data[[i]]$command must refer to data[[i]]$matrix as 'x', e.g. data[[i]]$command="hclust(dist(x),\"average\")"
    ##    B. data[[i]]$command must not contain single-quotes.
    ##  3. data[[i]]$libraries is an optional vector of R COMMANDS to run before clustering, i.e. to load libraries or source scripts.
    ##  4. other elements of data[[i]] may be included, if the clustering command requires additional data objects.
    ##    A. be sure to name the elements the same way they are called in the command:
    ##       for instance, if data[[i]]$command="hclust(dist(x,method=\"minkowski\",p=power))", then make sure data[[i]]$power exists.
    ##    B. no element may be named 'x'; this is reserved for the matrix being clustered.
    
    ## Objects
    N <- length(data)
    pids <- rep(NA,N)
    prefixes <- rep(NA,N)
    outputs <- vector("list", length=N)
    names(outputs) <- names(data)
    
    ## Files
    master.prefix <- paste(c("cluster.subunit.tmp",Sys.getpid(),abs(now.seed())),collapse="-")
    prefixes <- paste0(master.prefix,"-",1:N,".")
    pid.files <- paste0(prefixes,"pid")
    in.files <- paste0(prefixes,"input")
    out.files <- paste0(prefixes,"output")
    
    ## It is assumed that 'command' double-quotes are already escaped.
    ## This escapes the escapes so that 'command' can itself be inside a command.
    ## Escaping escapes is not possible in R (poorly handled regular expressions), so this just re-escapes the quotes.
    escapeq <- function(x) gsub("\"","\\\\\"",x)  
    
    ## Compose and execute individual clustering jobs
    for (i in 1:N) {
        
        ## Write matrix to temp file
        xnames <- setdiff(names(data[[i]]), c("matrix","command","libraries"))  # look for extra objects
        libs <- data[[i]]$libraries  # may not exist
        if ("x" %in% xnames) stop(paste0("No element of data[[",i,"]] may be named 'x'!\n"))
        for (n in xnames) assign(n, data[[i]][[n]])  # unpack objects by name
        x <- data[[i]]$matrix
        save(list=c("x",xnames), file=in.files[i])   # save 'x' and any extra objects from data[[i]]
        
        block <- paste(c(
            ## Write subunit PID to known location
            paste0("sink(\"",pid.files[i],"\")"),
            "cat(Sys.getpid())",
            "sink()",
            ## Load libraries / source scripts, if any
            libs,
            ## Load data
            paste0("load(\"",in.files[i],"\")"),
            ## Cluster matrix
            paste0("result <- eval(parse(text=\"",escapeq(data[[i]]$command),"\"))"),
            ## Write output object to temp file
            paste0("save(result, file=\"",out.files[i],"\")")
        ), collapse="; ")
        
        ## Execute code block in background
        if (verbose) {
            system(paste0("R --vanilla -e '",block,"' &"))
        } else {
            system(paste0("R --vanilla -e '",block,"' >/dev/null &"))
        }
    }
    
    ## Get PIDs
    Sys.sleep(5)  # pause to ensure last process has written PID file
    for (i in 1:N) {
        pids[i] <- scan(pid.files[i],quiet=TRUE)
        if (verbose) message(paste("Process",i,"PID",pids[i]))
    }
    
    ## Babysit; check every minute
    M <- N
    if (!verbose) message(paste("PIDs:",paste(sort(pids),collapse=",")))  # if verbose, already saw pids above.  If not, show condensed PID list here.
    message(paste("Babysitting",M,"processes:",Sys.time()))
    wait <- TRUE
    
    while (wait) {
        Sys.sleep(60)
        pid.ps <- lapply(pids, function(x) suppressWarnings(system(paste("ps -p",x), intern=TRUE)) )
        pid.running <- sapply(pid.ps, function(x) length(x)==2 )
        nr <- sum(pid.running)
        if (nr>0 & nr<M) message(paste("Babysitting",nr,"processes:",Sys.time()))  # count down as processes drop off
        M <- nr
        wait <- M>0
    }
    
    ## Read in results
    message(paste("All processes complete:",Sys.time()))
    for (i in 1:N) {
        if (file.exists(out.files[i])) {
            load(out.files[i])  # MUST CONTAIN ONLY ONE OBJECT, NAMED 'result' !!!
            outputs[[i]] <- result
        } else {
            warning(paste0("Call #",key," failed to produce the expected output file!\n"))
        }
    }
    
    ## Clean up
    system(paste0("rm -f ",master.prefix,"*"))
    
    ## Return results
    outputs
}


apa.names$dev <- c(apa.names$dev, "cluster.subunit2")
cluster.subunit2 <- function(data, verbose=FALSE) {
    
    ## This is the second of three variants.  It executes jobs in serial batches, and all jobs within a batch are run in parallel.
    ## 'data' must be a list of batches, all at first level, one element per batch.
    ##  each batch element 'data[[i]]' must be a list of jobs for that batch, all at second level, one element per job.
    
    ## runs multiple 1-core clustering jobs in parallel.
    ## 'data' is a list of data to be clustered.
    ## output object will be a list of outputs, one for each element of 'data'.
    ## 
    ## each element of 'data' must be a list with AT LEAST two elements, 'matrix' and 'command':
    ##  1. data[[i]]$matrix: a numeric matrix to be clustered
    ##  2. data[[i]]$command: a string which, when executed in R -- via eval(parse(text="cmd")) -- will cluster data[[i]]$matrix.
    ##    A. data[[i]]$command must refer to data[[i]]$matrix as 'x', e.g. data[[i]]$command="hclust(dist(x),\"average\")"
    ##    B. data[[i]]$command must not contain single-quotes.
    ##  3. data[[i]]$libraries is an optional vector of R COMMANDS to run before clustering, i.e. to load libraries or source scripts.
    ##  4. other elements of data[[i]] may be included, if the clustering command requires additional data objects.
    ##    A. be sure to name the elements the same way they are called in the command:
    ##       for instance, if data[[i]]$command="hclust(dist(x,method=\"minkowski\",p=power))", then make sure data[[i]]$power exists.
    ##    B. no element may be named 'x'; this is reserved for the matrix being clustered.
    
    ## It is assumed that 'command' double-quotes are already escaped.
    ## This escapes the escapes so that 'command' can itself be inside a command.
    ## Escaping escapes is not possible in R (poorly handled regular expressions), so this just re-escapes the quotes.
    escapeq <- function(x) gsub("\"","\\\\\"",x)  
    
    ## Objects
    B <- length(data)  ## BATCHES OF JOBS
    outputs <- vector("list", length=B)
    names(outputs) <- names(data)
    master.prefix <- paste(c("cluster.subunit.tmp",Sys.getpid(),abs(now.seed())),collapse="-")
    
    ## Run each batch separately
    for (b in 1:B) {
        
        N <- length(data[[b]])  # JOBS WITHIN BATCH
        pids <- rep(NA,N)
        prefixes <- rep(NA,N)
        outputs[[b]] <- vector("list", length=N)
        names(outputs[[b]]) <- names(data[[b]])
        
        ## Files
        prefixes <- paste0(master.prefix,"-B",b,"-",1:N,".")
        pid.files <- paste0(prefixes,"pid")
        in.files <- paste0(prefixes,"input")
        out.files <- paste0(prefixes,"output")
        
        ## Compose and execute individual clustering jobs within batch
        ## All jobs from batch b must complete before moving on to batch b+1
        for (i in 1:N) {
            
            ## Write matrix to temp file
            xnames <- setdiff(names(data[[b]][[i]]), c("matrix","command","libraries"))  # look for extra objects
            rm(list=xnames)  # remove last batch's objects, just for safety
            libs <- data[[b]][[i]]$libraries  # may not exist
            if ("x" %in% xnames) stop(paste0("No element of data[[",i,"]] may be named 'x'!\n"))
            for (n in xnames) assign(n, data[[b]][[i]][[n]])  # unpack objects by name
            x <- data[[b]][[i]]$matrix
            save(list=c("x",xnames), file=in.files[i])   # save 'x' and any extra objects from data[[b]][[i]]
            
            block <- paste(c(
                ## Write subunit PID to known location
                paste0("sink(\"",pid.files[i],"\")"),
                "cat(Sys.getpid())",
                "sink()",
                ## Load libraries / source scripts, if any
                libs,
                ## Load data
                paste0("load(\"",in.files[i],"\")"),
                ## Cluster matrix
                paste0("result <- eval(parse(text=\"",escapeq(data[[b]][[i]]$command),"\"))"),
                ## Write output object to temp file
                paste0("save(result, file=\"",out.files[i],"\")")
            ), collapse="; ")
            
            ## Execute code block in background
            if (verbose) {
                system(paste0("R --vanilla -e '",block,"' &"))
            } else {
                system(paste0("R --vanilla -e '",block,"' >/dev/null &"))
            }
        }
        
        ## Get PIDs
        Sys.sleep(5)  # pause to ensure last process has written PID file
        for (i in 1:N) {
            pids[i] <- scan(pid.files[i],quiet=TRUE)
            if (verbose) message(paste("Process",i,"PID",pids[i]))
        }
        
        ## Babysit; check every minute
        M <- N
        if (!verbose) message(paste("PIDs:",paste(sort(pids),collapse=",")))  # if verbose, already saw pids above.  If not, show condensed PID list here.
        message(paste("Babysitting",M,"processes:",Sys.time()))
        wait <- TRUE
        
        while (wait) {
            Sys.sleep(60)
            pid.ps <- lapply(pids, function(x) suppressWarnings(system(paste("ps -p",x), intern=TRUE)) )
            pid.running <- sapply(pid.ps, function(x) length(x)==2 )
            nr <- sum(pid.running)
            if (nr>0 & nr<M) message(paste("Babysitting",nr,"processes:",Sys.time()))  # count down as processes drop off
            M <- nr
            wait <- M>0
        }
        
        ## Read in results
        message(paste("All processes complete:",Sys.time()))
        for (i in 1:N) {
            if (file.exists(out.files[i])) {
                load(out.files[i])  # MUST CONTAIN ONLY ONE OBJECT, NAMED 'result' !!!
                outputs[[b]][[i]] <- result
            } else {
                warning(paste0("Call #",key," failed to produce the expected output file!\n"))
            }
        }
    }
    
    ## Clean up
    system(paste0("rm -f ",master.prefix,"*"))
    
    ## Return results
    outputs
}


apa.names$dev <- c(apa.names$dev, "cluster.subunit3")
cluster.subunit3 <- function(data, verbose=FALSE) {
    
    ## This will be the third of three variants.  It executes jobs in rolling parallel, with no more than B running at a time.
    ## Like the first variant, 'data' must be a list of jobs, all at first level, one element per job.
    
}


apa.names$dev <- c(apa.names$dev, "generic.subunit")
generic.subunit <- function(tmp) {
    
    ## IN DEVELOPMENT, may or may not work as desired.
    ## runs multiple R scripts in parallel.
    ## 'tmp' is a list with two elements:
    ##
    ##
    ##
    ##
    ##
    ##
    ##
    ## RESERVED NAMES: { tmp, result, my.i, pids, prefixes, outputs, master.prefix, pid.files, in.files, out.files, R.files, Rout.files }
    
    ## Objects
    N <- length(tmp)
    pids <- rep(NA,N)
    prefixes <- rep(NA,N)
    outputs <- vector("list", length=N)
    names(outputs) <- names(tmp)
    
    ## Files
    master.prefix <- paste(c("generic.subunit.tmp",Sys.getpid(),abs(now.seed())),collapse="-")
    prefixes <- paste0(master.prefix,"-",1:N,".")
    pid.files <- paste0(prefixes,"pid")
    in.files <- paste0(prefixes,"input")
    out.files <- paste0(prefixes,"output")
    R.files <- paste0(prefixes,"R")
    Rout.files <- paste0(prefixes,"Rout")
    
    ## Compose and execute individual clustering jobs
    for (my.i in 1:length(tmp)) {
        
        ## Write data to temp file
        for (name in names(tmp[[my.i]]$data)) assign(name, tmp[[my.i]]$data[[name]])
        save(list=names(tmp[[my.i]]$data), file=in.files[my.i])   # save objects from tmp[[my.i]]$data
        
        ## Create R script
        sink(R.files[my.i])
        cat(paste(c(
            ## Write subunit PID to known location
            paste0("sink(\"",pid.files[my.i],"\")"),
            "cat(Sys.getpid())",
            "sink()",
            ## Load data
            paste0("load(\"",in.files[my.i],"\")"),
            ## Run commands
            tmp[[my.i]]$commands,
            ## Write output object to temp file
            paste0("save(result, file=\"",out.files[my.i],"\")")
        ), collapse="\n"))
        sink()
        
        ## Execute R script in background
        system(paste("R --vanilla <",R.files[my.i],">",Rout.files[my.i],"&"))
    }
    
    ## Get PIDs
    Sys.sleep(5)  # pause to ensure last process has written PID file
    N <- length(tmp)  # reset N, since it might have been overwritten in object assignments above
    for (i in 1:N) pids[i] <- scan(pid.files[i],quiet=TRUE)
    
    ## Babysit; check every minute
    M <- N
    message(paste("PIDs:",paste(sort(pids),collapse=",")))
    message(paste("Babysitting",M,"processes:",Sys.time()))
    wait <- TRUE
    
    while (wait) {
        Sys.sleep(60)
        pid.ps <- lapply(pids, function(x) suppressWarnings(system(paste("ps -p",x), intern=TRUE)) )
        pid.running <- sapply(pid.ps, function(x) length(x)==2 )
        nr <- sum(pid.running)
        if (nr>0 & nr<M) message(paste("Babysitting",nr,"processes:",Sys.time()))  # count down as processes drop off
        M <- nr
        wait <- M>0
    }
    
    ## Read in results
    message(paste("All processes complete:",Sys.time()))
    for (i in 1:N) {
        if (file.exists(out.files[i])) {
            load(out.files[i])  # MUST CONTAIN ONLY ONE OBJECT, NAMED 'result' !!!
            outputs[[i]] <- result
        } else {
            warning(paste0("Call #",key," failed to produce the expected output file!\n"))
        }
    }
    
    ## Clean up
    system(paste0("rm -f ",master.prefix,"*"))
    
    ## Return results
    outputs
}


apa.names$dev <- c(apa.names$dev, "GATK.hh.analyze")
GATK.hh.analyze <- function(x, major, minor, groups=NULL) {
    
    ## UNDER CONSTRUCTION
    
    ## Analyze trends in GATK AD, DP and GT fields
    ## 
    ## 'x' is a list of 1 or more matrices which have been extracted from a single VCF file:
    ##   Each matrix must have columns GT,DP,AD for one sample, in that order.
    ##   If 'x' has > 1 matrix, these must all be single-sample matrices from one multisample VCF, because they will be compared to each other.
    
    ## txt.raw[[i]] cols: 7,8 GT "0/1"; 9,10 DP "5"; 11,12 AD "10,5"
    
    rescore <- function(i, j, gt, dp, ad) {
        gt <- GT[[i]][[j]]
        dp <- DP[[i]][j]
        ad <- AD[[i]][[j]]
        lgt <- length(gt)
        lad <- length(ad)
        if (lad>1) {
            sad <- sum(ad)
            alost <- max(gt)-lad  # >0 means depths not reported for all alleles
            dlost <- dp-sum(ad)  # >0 means depths not reported for all alleles
            if (alost > 0 | dlost > 0) {
                message(paste("Lost depths for",i,j))
            } else {
                ap <- ad/dp  # depth percent per allele
                lfc <- ad[1]/sum(ad[2:lad])
                if (blah) {
                    
                } else {
                    
                }
            }
        }
    }
    
    if (is.data.frame(x) | !is.list(x)) x <- list(x)
    
    X <- length(x)
    NR <- sapply(x,nrow)
    GT <- lapply(x, function(y) lapply(strsplit("/",y[,1]), as.numeric) )
    DP <- lapply(x, function(y) as.numeric(y[,2]) )
    AD <- lapply(x, function(y) lapply(strsplit(",",y[,3]), as.numeric) )
    
    stats <- lapply(1:X, function(i) do.call(rbind, lapply(1:NR, function(j) rescore(i, j) )))
    
    
    
    
    
    
    
    ## further filters, like requiring sib geno call, min sib het ratio, depth, etc.
    bad1[[i]][which(txt.raw[[i]][,11]==txt.raw[[i]][,12])] <- TRUE   # exact same genotype call
    txt.flt1[[i]] <- txt.raw[[i]][txt.raw[[i]][,11]!=txt.raw[[i]][,12],]  # different genotype calls
    txt.flt1[[i]] <- txt.flt1[[i]][falsify(txt.flt1[[i]][,9]>=2) & falsify(txt.flt1[[i]][,10]>=2),]  # both depths > 2
    txt.flt1[[i]] <- txt.flt1[[i]][txt.flt1[[i]][,7] != "./." & txt.flt1[[i]][,8] != "./.",]  # both genotypes not "./."
    bad2[[i]] <- rep(FALSE,nrow(txt.flt1[[i]]))  # initialize bi/tri test-pass vector
    biallelic <- which(!grepl(2,txt.flt1[[i]][,7]) & !grepl(2,txt.flt1[[i]][,8]))  # 2 alleles called
    triallelic <- which(grepl(2,txt.flt1[[i]][,7]) | grepl(2,txt.flt1[[i]][,8]))  # > 2 alleles called (so 3; never observed 4...)
    
    sib.max2 <- nameless(sapply(txt.flt1[[i]][biallelic,11], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
    mut.max2 <- nameless(sapply(txt.flt1[[i]][biallelic,12], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
    sib.max3 <- nameless(sapply(txt.flt1[[i]][triallelic,11], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
    mut.max3 <- nameless(sapply(txt.flt1[[i]][triallelic,12], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
#    cbind(sib.max2,mut.max2,sib.max2==mut.max2)
#    cbind(sib.max3,mut.max3,sib.max3==mut.max3)
    
    ## Allele frequency filter, mutant   ## NOTE: GATK fails to call HET/HOM properly.  E.g. 2,2 is not HOM, neither is 10,1 HET.
    AB <- t(apply(txt.flt1[[i]][biallelic,11:12], 1, function(s)
                   c( sort(as.numeric(unlist(strsplit(s[1],",")))), sort(as.numeric(unlist(strsplit(s[2],","))))) ))
    biallelic.ok <- sib.max2!=mut.max2 & AB[,1]/rowSums(AB[,1:2])<=0.4 & AB[,3]/rowSums(AB[,3:4])<=0.1  # sib: minor <= 40%; mut: minor <= 10%
    triallelic.ok <- NA
    if (length(triallelic)>0) {
        ABC <- t(apply(txt.flt1[[i]][triallelic,11:12], 1, function(s)
                       c( sort(as.numeric(unlist(strsplit(s[1],",")))), sort(as.numeric(unlist(strsplit(s[2],","))))) ))
        triallelic.ok <- sib.max3!=mut.max3 & ABC[,2]/rowSums(ABC[,1:3])<=0.4 & ABC[,5]/rowSums(ABC[,4:6])<=0.1  # as above, but minor is second-largest, not smallest
    }
    
#    ## genotype-distinctiveness field
#    txt[[i]] <- txt[[i]][,c(1:12,9,9,9,13:14)]
#    colnames(txt[[i]])[13:15] <- c("GEN[1].AD","GEN[0].AD","GEN.DIST")
#    txt[[i]][,13:14] <- sapply(11:12, function(j) {
#        x <- t(sapply(txt[[i]][,j], function(s) as.numeric(unlist(strsplit(s,","))) ))
#        y <- rowMax(x)/txt[[i]][,j-2]
#        z <- y*sign(log(apply(x,1,quot)))
#    })
#    txt[[i]][,15] <- round(100*abs(txt[[i]][,13]-txt[[i]][,14])/2,1)

    bad2[[i]][biallelic[which(!biallelic.ok)]] <- TRUE
    bad2[[i]][triallelic[which(!triallelic.ok)]] <- TRUE
    
    allele.diff <- sort(c( biallelic[biallelic.ok], triallelic[triallelic.ok] ))
    txt.flt2[[i]] <- txt.flt1[[i]][allele.diff,]

    
#    txt.flt2[[i]][,7] <- sub("0/0","HOM",sub("1/1","HOM",sub("2/2","HOM",sub("1/2","HET",sub("0/1","HET",txt.flt2[[i]][,7])))))
#    txt.flt2[[i]][,8] <- sub("0/0","HOM",sub("1/1","HOM",sub("2/2","HOM",sub("1/2","HET",sub("0/1","HET",txt.flt2[[i]][,8])))))
    
    
}


apa.names$dev <- c(apa.names$dev, "GATK.hh.recall")
GATK.hh.recall <- function(x, major, minor, groups=NULL) {
    
    ## UNDER CONSTRUCTION
    
    ## Combines GATK AD and DP fields and compares to GT field; reclassifies HET/HOM.
    ## 
    ## 'x' is a list of 1 or more matrices which have been extracted from a single VCF file:
    ##   Each matrix must have columns GT,DP,AD for one sample, in that order.
    ##   If 'x' has > 1 matrix, these must all be single-sample matrices from one multisample VCF, because they will be compared to each other.
    ## 'groups' is an optional grouping vector if length(x)>1.  These indicate which matrices in 'x' should be grouped for comparisons (e.g. which are MUT vs WT).
    ##   Same principle as 'group' factor in EdgeR.  Example: length(x) = 6; groups = c("MUT","MUT","MUT","WT","WT","WT").
    ##   All pairwise tests between factor levels will be carried out, so plan function call accordingly!
    ##   Consistency tests are also carried out within each factor level.
    ## Returns HET/HOM calls, GATK-call-was T/F value, genotype distinctiveness scores
    
    ## txt.raw[[i]] cols: 7,8 GT "0/1"; 9,10 DP "5"; 11,12 AD "10,5"
    
    rescore <- function(i, j, gt, dp, ad) {
        gt <- GT[[i]][[j]]
        dp <- DP[[i]][j]
        ad <- AD[[i]][[j]]
        lgt <- length(gt)
        lad <- length(ad)
        if (lad>1) {
            sad <- sum(ad)
            alost <- max(gt)-lad  # >0 means depths not reported for all alleles
            dlost <- dp-sum(ad)  # >0 means depths not reported for all alleles
            if (alost > 0 | dlost > 0) {
                message(paste("Lost depths for",i,j))
            } else {
                ap <- ad/dp  # depth percent per allele
                lfc <- ad[1]/sum(ad[2:lad])
                if (blah) {
                    
                } else {
                    
                }
            }
        }
    }
    
    if (is.data.frame(x) | !is.list(x)) x <- list(x)
    
    X <- length(x)
    NR <- sapply(x,nrow)
    GT <- lapply(x, function(y) lapply(strsplit("/",y[,1]), as.numeric) )
    DP <- lapply(x, function(y) as.numeric(y[,2]) )
    AD <- lapply(x, function(y) lapply(strsplit(",",y[,3]), as.numeric) )
    
    stats <- lapply(1:X, function(i) do.call(rbind, lapply(1:NR, function(j) rescore(i, j) )))
    
    
    
    
    
    
    
    ## further filters, like requiring sib geno call, min sib het ratio, depth, etc.
    bad1[[i]][which(txt.raw[[i]][,11]==txt.raw[[i]][,12])] <- TRUE   # exact same genotype call
    txt.flt1[[i]] <- txt.raw[[i]][txt.raw[[i]][,11]!=txt.raw[[i]][,12],]  # different genotype calls
    txt.flt1[[i]] <- txt.flt1[[i]][falsify(txt.flt1[[i]][,9]>=2) & falsify(txt.flt1[[i]][,10]>=2),]  # both depths > 2
    txt.flt1[[i]] <- txt.flt1[[i]][txt.flt1[[i]][,7] != "./." & txt.flt1[[i]][,8] != "./.",]  # both genotypes not "./."
    bad2[[i]] <- rep(FALSE,nrow(txt.flt1[[i]]))  # initialize bi/tri test-pass vector
    biallelic <- which(!grepl(2,txt.flt1[[i]][,7]) & !grepl(2,txt.flt1[[i]][,8]))  # 2 alleles called
    triallelic <- which(grepl(2,txt.flt1[[i]][,7]) | grepl(2,txt.flt1[[i]][,8]))  # > 2 alleles called (so 3; never observed 4...)
    
    sib.max2 <- nameless(sapply(txt.flt1[[i]][biallelic,11], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
    mut.max2 <- nameless(sapply(txt.flt1[[i]][biallelic,12], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
    sib.max3 <- nameless(sapply(txt.flt1[[i]][triallelic,11], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
    mut.max3 <- nameless(sapply(txt.flt1[[i]][triallelic,12], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
#    cbind(sib.max2,mut.max2,sib.max2==mut.max2)
#    cbind(sib.max3,mut.max3,sib.max3==mut.max3)
    
    ## Allele frequency filter, mutant   ## NOTE: GATK fails to call HET/HOM properly.  E.g. 2,2 is not HOM, neither is 10,1 HET.
    AB <- t(apply(txt.flt1[[i]][biallelic,11:12], 1, function(s)
                   c( sort(as.numeric(unlist(strsplit(s[1],",")))), sort(as.numeric(unlist(strsplit(s[2],","))))) ))
    biallelic.ok <- sib.max2!=mut.max2 & AB[,1]/rowSums(AB[,1:2])<=0.4 & AB[,3]/rowSums(AB[,3:4])<=0.1  # sib: minor <= 40%; mut: minor <= 10%
    triallelic.ok <- NA
    if (length(triallelic)>0) {
        ABC <- t(apply(txt.flt1[[i]][triallelic,11:12], 1, function(s)
                       c( sort(as.numeric(unlist(strsplit(s[1],",")))), sort(as.numeric(unlist(strsplit(s[2],","))))) ))
        triallelic.ok <- sib.max3!=mut.max3 & ABC[,2]/rowSums(ABC[,1:3])<=0.4 & ABC[,5]/rowSums(ABC[,4:6])<=0.1  # as above, but minor is second-largest, not smallest
    }
    
#    ## genotype-distinctiveness field
#    txt[[i]] <- txt[[i]][,c(1:12,9,9,9,13:14)]
#    colnames(txt[[i]])[13:15] <- c("GEN[1].AD","GEN[0].AD","GEN.DIST")
#    txt[[i]][,13:14] <- sapply(11:12, function(j) {
#        x <- t(sapply(txt[[i]][,j], function(s) as.numeric(unlist(strsplit(s,","))) ))
#        y <- rowMax(x)/txt[[i]][,j-2]
#        z <- y*sign(log(apply(x,1,quot)))
#    })
#    txt[[i]][,15] <- round(100*abs(txt[[i]][,13]-txt[[i]][,14])/2,1)

    bad2[[i]][biallelic[which(!biallelic.ok)]] <- TRUE
    bad2[[i]][triallelic[which(!triallelic.ok)]] <- TRUE
    
    allele.diff <- sort(c( biallelic[biallelic.ok], triallelic[triallelic.ok] ))
    txt.flt2[[i]] <- txt.flt1[[i]][allele.diff,]

    
#    txt.flt2[[i]][,7] <- sub("0/0","HOM",sub("1/1","HOM",sub("2/2","HOM",sub("1/2","HET",sub("0/1","HET",txt.flt2[[i]][,7])))))
#    txt.flt2[[i]][,8] <- sub("0/0","HOM",sub("1/1","HOM",sub("2/2","HOM",sub("1/2","HET",sub("0/1","HET",txt.flt2[[i]][,8])))))
    
    
}


apa.names$dev <- c(apa.names$dev, "dendroCAT")
dendroCAT <- function(x, y, plot=FALSE, ignore.singletons=FALSE) {
    
    ## CAT-plot-like approach to comparing dendrogram topology.
    ## Cuts two dendrograms from k=1 to k=N (N = elements that were clustered);
    ##   at each K, pairs clusters (one from 'x' with one from 'y') that have greatest gene overlap*,
    ##   then sums the gene overlaps from all paired clusters (n).  0 <= n <= N.
    ##   E.g. if clusters A1 (from 'x') and A2 (from 'y') are considered paired, and gene X is found in both A1 and A2, n+=1.
    ## If topologies are identical, n=N for every K.
    ## If topologies have no relation, n will rapidly approach some random value after k=1.
    ## Also able to compare a dendrogram (x) to a static clustering (y),
    ##   and see at what k the dendrogram most resembles the clustering.
    ##
    ## * if Mxy is a k-by-k matrix where rows = x clusters, cols = y clusters, and cells = gene overlap counts, 
    ##   then 'greatest gene overlap' is found by ordering rows/cols such that the diagonal is maximized (Hungarian algorithm).
    ##   Then, for i from 1:k, clusters corresponding to row i and col i are considered 'paired'.
    ##   The total gene overlap, n, is the diagonal sum.
    ##
    ## 'plot=TRUE' will plot n/N for all k
    ## 'ignore.singletons=TRUE' will throw out single-gene clusters before calculating n.
    ## If 'y' is a named numeric clustering vector and 'plot=TRUE', plot shows ablines for max(n) (red) and for length(unique(y)) (blue).
    
    require(clue)
    if (!is(x,"hclust")) stop("'x' must be an 'hclust' object!\n")
    Nx <- length(x$order)
    if (is(y,"hclust")) {
        ## y is another hclust
        y.fixed <- FALSE
        Ny <- length(y$order)
        x.is.y <- all(x$labels==y$labels)  # same sample set, not necessarily same hclust
        ccc <- cor(cophenetic(x), cophenetic(y))
        message("CCC:",ccc)
    } else if (is.vector(y) & mode(y)=="numeric" & length(names(y))>0) {
        ## y is a cutree vector or something like it (a fixed clustering vector to compare to cutree k=1:Nmin)
        ## MUST BE NAMED
        y.fixed <- TRUE
        Ny <- length(y)
        Ky <- length(unique(y))
        x.is.y <- all(x$labels%in%names(y))
        if (x.is.y) y <- y[match(x$labels,names(y))]
    } else {
        stop("'y' is neither an 'hclust' object nor a named clustering vector.\n")
    }
    Nmin <- min(c(Nx,Ny))
    diag.sums <- rep(NA, Nmin)
    title <- "Percent Labels Assigned to Compatible Clusters"
    xlab <- "N Clusters"
    ylab <- "Percent"
    ylim <- c(0,100)
    if (y.fixed) Cy <- y
    for (k in 1:Nmin) {
        Cx <- cutree(x,k=k)
        if (y.fixed) {
            x.gt.y <- k > Ky
        } else {
            x.gt.y <- FALSE
            Cy <- cutree(y,k=k)
        }
        if (x.is.y) {
            Mxy <- table(Cx,Cy)
        } else {
            Mxy <- matrix(0, k, k)  # x=rows, y=cols
            for (i in 1:k) {
                for (j in 1:k) Mxy[i,j] <- length(intersect(names(Cx)[Cx==i],names(Cy)[Cy==j]))
            }
        }
        if (ignore.singletons) {
            Mxy <- Mxy[rowSums(Mxy)>1,,drop=FALSE]
            Mxy <- Mxy[,colSums(Mxy)>1,drop=FALSE]
            if (nrow(Mxy)==0 | ncol(Mxy)==0) {
                message(paste0("k=",k,", Mxy is empty!  Stopping.\n"))
                if (plot) {
                    dev.new(); lineplot(100*diag.sums/Nmin, las=1, ylim=ylim, xlab=xlab, ylab=ylab, main=title)
                }
                if (y.fixed) abline(v=c(which.max(diag.sums),Ky), col=c(2,4))
                return(diag.sums)
            }
            x.gt.y <- nrow(Mxy) > ncol(Mxy)
        }
        if (x.gt.y) Mxy <- t(Mxy)
        MxyS <- solve_LSAP(Mxy, maximum=TRUE)  # find optimal row-column assignments by maximizing the diagonal sum
        if (x.gt.y) MxyS <- t(MxyS)
        diag.sums[k] <- sum(diag(Mxy[,as.numeric(MxyS)]))
    }
    if (plot) {
        dev.new(); lineplot(100*diag.sums/Nmin, las=1, ylim=ylim, xlab=xlab, ylab=ylab, main=title)
    }
    if (y.fixed) abline(v=c(which.max(diag.sums),Ky), col=c(2,4))
    return(diag.sums)
}


apa.names$dev <- c(apa.names$dev, "call.peaks.old")
call.peaks.old <- function(IP, inp, minHeight=0, minWidth=0, mergeGap=0, minFC=0, maxP=0.05, bkg=list(90,"pctl-chromosome"), call=list(98,"pctl-chromosome"), prefix="Peak", scale.to=c("input","IP","larger","smaller"), seqNames=NULL) {
    
    ## IMPROVEMENTS TO BE MADE:
    ## Multi-IP calling (i.e. 'IP' is a list of bams)
    ## Trim tails / split peaks on N5 set which are below minFC (to get them above minFC)
    ## threshold-by-chromosome option in case chr behaviors are too different to threshold all at once
    
    ## 'IP', 'inp' are bam-derived GRanges lists
    
    scale.to <- match.arg(scale.to)
    types <- c("pctl-genome","pctl-chromosome","reads","rpm")
    bkg.upper <- bkg[[1]]
    bkg.type <- bkg[[2]]
    call.lower <- call[[1]]
    call.type <- call[[2]]
    if (!(bkg.type %in% types)) stop(paste0(c("Background threshold type must be one of: ",types,collapse=" ")))
    if (!(call.type %in% types)) stop(paste0(c("Call threshold type must be one of: ",types,collapse=" ")))
    
    now <- system("date", intern=TRUE)
    message(paste("Preparing:",now))
    if (length(seqNames)>0) {
        ibams <- list( IP=keepSeqlevels(IP,seqNames), inp=keepSeqlevels(inp,seqNames) )
    } else {
        ibams <- list( IP=IP, inp=inp )
    }
    B <- 1:2; names(B) <- c("IP","inp")
    seqNames <- levels(seqnames(ibams$inp))  # ensure these are in GenomicRanges order
    S <- 1:length(seqNames); names(S) <- seqNames
    
    rlen <- width(ranges(IP[1]))  # read length
    chr.len <- attr(ibams$inp,"seqinfo")@seqlengths  # chromosome bp
    names(chr.len) <- levels(seqnames(ibams$inp))
    chr.len <- chr.len[match(seqNames,names(chr.len))]
    Glen <- sum(chr.len)  # genome bp
    Grds <- sapply(ibams,length)  # reads/alignments per bam
    
    Gscale <- c(1,1)  # initial scaling factors
    if (scale.to == "input") {
        Gscale[1] <- Grds[2]/Grds[1]  # scale IP towards input
        message(paste(c(Grds,":",Gscale[1]),collapse=" "))
    } else if (scale.to == "IP") {
        Gscale[2] <- Grds[1]/Grds[2]  # scale input towards IP
        message(paste(c(Grds,":",Gscale[2]),collapse=" "))
    } else if (scale.to == "larger") {
        Gscale[which.min(Grds)] <- max(Grds)/min(Grds)  # scale smaller sample towards larger
        message(paste(c(Grds,":",max(Gscale)),collapse=" "))
    } else if (scale.to == "smaller") {
        Gscale[which.max(Grds)] <- min(Grds)/max(Grds)  # scale larger sample towards smaller
        message(paste(c(Grds,":",min(Gscale)),collapse=" "))
    }
    
    Grds.scaled <- Grds*Gscale  # post-scaling, both values are same
    chr.rds <- merge.table.list(lapply(ibams, function(x) table(as.character(seqnames(x))) ))  #  read counts per chrom
    chr.rds <- chr.rds[,match(seqNames,colnames(chr.rds))]
    chr.rds.scaled <- Gscale*chr.rds   # scaled read counts per chrom
    chr.pseudo <- 1E6/chr.rds.scaled/2   # per-chrom RPM pseudocounts (RPM of 0.5 reads) for adjusting prior to Log-FC
    for (i in 1:length(chr.pseudo)) chr.pseudo[i] <- 1E6/Grds.scaled[1]/2     ##### REPLACE WITH GENOMIC RPM PSEUDOCOUNTS
    minHeight.rpm <- 1E6*minHeight/Grds.scaled[1]
    
    ## per-bam-per-chromosome objects
    now <- system("date", intern=TRUE)
    message(paste("Calculating coverage vectors:",now))
    covg <- lapply(B, function(i) coverage(ibams[[i]])*Gscale[i] )  # scaled read coverage
    rpm <- lapply(B, function(i) lapply(1:length(seqNames), function(j) 1E6*Gscale[i]*covg[[i]][[j]]/Grds.scaled[i] ))  # scaled RPM coverage
    
    ## set background and call vectors, one value per chrom (may all be same value)
    Gbkg <- Gbkg.rpm <- lapply(B, function(i) NA )
    if (bkg.type == "pctl-genome" || call.type == "pctl-genome") {
        
        now <- system("date", intern=TRUE)
        message(paste("Calculating genome-wide background percentiles:",now))
        Gbkg <- lapply(B, function(i) zapsmall(percentiles(unlist(lapply(covg[[i]],as.numeric))))[2:101] )  # one value per bam
        Gbkg.rpm <- lapply(B, function(i) zapsmall(1E6*Gbkg[[i]]/sum(Grds.scaled[i])) )
        if (bkg.type == "pctl-genome") {
            minht <- rep(max(c(minHeight,Gbkg$IP[bkg.upper])), max(S))              # PERCENTILES ARE IN READ HEIGHT, NOT RPM
            minht.rpm <- rep(max(c(minHeight.rpm,Gbkg.rpm$IP[bkg.upper])), max(S))  # PERCENTILES ARE IN READ HEIGHT, NOT RPM
        } else if (bkg.type == "height") {
            minht <- rep(bkg.upper, max(S))
            minht.rpm <- 1E6*minht/Grds.scaled[1]
        }
        if (call.type == "pctl-genome") {
            callht <- rep(Gbkg$IP[call.lower], max(S))          # PERCENTILES ARE IN READ HEIGHT, NOT RPM
            callht.rpm <- rep(Gbkg.rpm$IP[call.lower], max(S))  # PERCENTILES ARE IN READ HEIGHT, NOT RPM
        } else if (call.type == "height") {
            callht <- rep(call.lower, max(S))
            callht.rpm <- 1E6*callht/Grds.scaled[1]
        }
        
    }
    gbp.mat <- colname( do.call(cbind, c(Gbkg,Gbkg.rpm)), paste(rep(c("IP","Input"),2),rep(c("Rds","RPM"),each=2)) )  # bkg pctl matrix
    
    now <- system("date", intern=TRUE)
    message(paste("Calculating chromosome background percentiles:",now))
    Cbkg <- lapply(S, function(j) lapply(B, function(i) zapsmall(percentiles(as.numeric(covg[[i]][[j]])))[2:101] ))  # one value per chromosome per bam
    Cbkg.rpm <- lapply(S, function(j) lapply(B, function(i) zapsmall(1E6*Cbkg[[j]][[i]]/Grds.scaled[1]) ))
    cbp.mat <- lapply(S, function(j) colname( do.call(cbind, c(Cbkg[[j]],Cbkg.rpm[[j]])), paste(rep(c("IP","Input"),2),rep(c("Rds","RPM"),each=2)) ))  # bkg pctl matrices
    if (bkg.type == "pctl-chromosome") {
        minht <- sapply(Cbkg, function(x) max(c(minHeight,x$IP[bkg.upper])) )              # PERCENTILES ARE IN READ HEIGHT, NOT RPM
        minht.rpm <- sapply(Cbkg.rpm, function(x) max(c(minHeight.rpm,x$IP[bkg.upper])) )  # PERCENTILES ARE IN READ HEIGHT, NOT RPM
    } else if (bkg.type == "height") {
        minht <- rep(bkg.upper, max(S))
        minht.rpm <- 1E6*minht/Grds.scaled[1]
    }
    if (call.type == "pctl-chromosome") {
        callht <- sapply(Cbkg, function(x) x$IP[call.lower] )          # PERCENTILES ARE IN READ HEIGHT, NOT RPM
        callht.rpm <- sapply(Cbkg.rpm, function(x) x$IP[call.lower] )  # PERCENTILES ARE IN READ HEIGHT, NOT RPM
    } else if (call.type == "height") {
        callht <- rep(call.lower, max(S))
        callht.rpm <- 1E6*callht/Grds.scaled[1]
    }
    
    ## chromosomal objects
    chr.peaks <- chr.stats <- new.list(seqNames)
    
    m.tmp <- data.frame(
        Chr="", Start=0, End=0, ID="", Width=0,
        ScaledReads=0, InpScaledReads=0, 
        MeanHt=0, MedHt=0, MaxHt=0, TotBp=0,
        MeanHt.RPM=0, MedHt.RPM=0, MaxHt.RPM=0, TotBp.RPM=0,
        InpMeanHt.RPM=0, InpMedHt.RPM=0, InpMaxHt.RPM=0, InpTotBp.RPM=0,
        LFC.RPM.max=0, LFC.RPM.tot=0, Pois.P=1, Pois.P.BH=1,
        stringsAsFactors=FALSE
    )
    
    ## process chromosome at a time
    now <- system("date", intern=TRUE)
    message(paste("Calling peaks per chromosome:",now))
    for (n in S) {
        
        chr <- seqNames[n]
        this.minht <- minht[n]
        this.callht <- callht[n]
        this.pseudo <- chr.pseudo[,n]
        this.len <- chr.len[n]
        this.rds <- chr.rds[,n]
        this.rds.scaled <- chr.rds.scaled[,n]
        
        N1 <- N2 <- N3 <- N4 <- N5 <- N6 <- 0
        
        ## call islands w/ background subtraction
        isl1 <- slice(covg$IP[[n]], lower=this.minht)
        N1 <- length(isl1)  # total islands
        
        if (N1==0) {
            m <- m.tmp[0,]
        } else {
            
            ## restrict by island width
            isl2 <- isl1[width(isl1)>=minWidth] 
            N2 <- length(isl2)  # wide islands 
            
            if (N2==0) {
                m <- m.tmp[0,]
            } else {
                m <- as.matrix(ranges(isl2))
                m <- data.frame(
                    Chr=rep(chr,N2),
                    Start=m[,1],
                    End=m[,1]+m[,2]-1,
                    ID="",
                    Width=m[,2],
                    stringsAsFactors=FALSE
                )
                
                covg2 <- lapply(covg, function(x) as.numeric(x[[n]]) )  # CONVERT COVERAGES TO NUMERIC VECTORS
                mcovg <- lapply(B, function(i) lapply(1:N2, function(j) covg2[[i]][m$Start[j]:m$End[j]] ))
                mcovg.rpm <- lapply(B, function(i) lapply(mcovg[[i]], function(x) 1E6*x/Grds.scaled[i] ) )
                mcovg.rpm2 <- lapply(B, function(i) lapply(mcovg.rpm[[i]], function(x) x+this.pseudo[i] ) )
                LFC.RPM <- lapply(1:N2, function(j) log2(mcovg.rpm2$IP[[j]]/mcovg.rpm2$inp[[j]]) )
                LFC.RPM1 <- lapply(1:N2, function(j) log2(mcovg.rpm$IP[[j]]/mcovg.rpm$inp[[j]]) )
                LFC.RPM0 <- lapply(1:N2, function(j) log2(mcovg$IP[[j]]/mcovg$inp[[j]]) )
                
                ## call peaks by call threshold
                if (call.type == "reads") {
                    called <- which(sapply(mcovg$IP,max)>=this.callht)
                } else if (call.type == "rpm") {
                    called <- which(sapply(mcovg.rpm$IP,max)>=this.callht)
                } else {
                    called <- which(sapply(mcovg$IP,max)>=this.callht)  # PERCENTILES ARE IN READ HEIGHT, NOT RPM
                }
                m <- m[called,]
                LFC.RPM <- LFC.RPM[called]
                N3 <- nrow(m)
                
                if (N3==0) {
                    m <- m.tmp[0,]
                } else {
                    
                    ## restrict to islands with max IP/inp LFC >= minFC
                    m <- m[sapply(LFC.RPM,max)>=log2(minFC),]
                    N4 <- nrow(m)
                    
                    if (N4==0) {
                        m <- m.tmp[0,]
                        N5 <- N6 <- 0
                    } else {
                        
                        if (N4>1) {
                            ## fuse peak sets that are within mergeGap bp of each other
                            if (mergeGap>0) {
                                gaps <- m$Start[2:N4]-m$End[1:(N4-1)]
                                gapruns <- find.runs((gaps<=mergeGap)+0)
                                gapruns <- lapply(gapruns[falsify(names(gapruns)==1)], function(x) c(x[1]:(x[2]+1)) )
                                mnon <- m[!(1:N4 %in% unlist(gapruns)),]
                                mgap <- lapply(gapruns, function(x) m[x,] )
                                if (length(mgap)>0) {  # just in case N4==2, and the pair were not close enough to merge
                                    m <- rbind(
                                        mnon,
                                        do.call(rbind, lapply(mgap, function(x){ y=x[1,]; y$Start=x$Start[1]; y$End=x$End[nrow(x)]; y$Width=y$End-y$Start+1; y }))
                                    )
                                    m <- rownameless(m[order(m$Start),])
                                }
                            }
                        }
                        
                        N5 <- nrow(m)  # N fused peaks; must be > 1 if N4 > 1
                        mcovg <- lapply(B, function(i) lapply(1:N5, function(j) covg[[i]][[n]][m$Start[j]:m$End[j]] ))  # REBOOT RPM COVERAGE VECTORS
                        mcovg.rpm <- lapply(B, function(i) lapply(mcovg[[i]], function(x) 1E6*x/Grds.scaled[i] ) )
                        m.bed <- cbind(m[,1:5],"+")
                        m.bed[,4] <- 1:N5
                        m.gr <- bed2gr(m.bed)
                        rcounts.scaled <- lapply(B, function(i) Gscale[i]*countOverlaps(m.gr, ibams[[i]], type="any", ignore.strand=TRUE) )
                        
                        m <- cbind(
                            m,
                            ScaledReads=round(rcounts.scaled$IP,0),
                            InpScaledReads=round(rcounts.scaled$inp,0),
                            MeanHt=sapply(mcovg$IP,mean),
                            MedHt=sapply(mcovg$IP,median),
                            MaxHt=sapply(mcovg$IP,max),
                            TotBp=sapply(mcovg$IP,sum),
                            MeanHt.RPM=sapply(mcovg.rpm$IP,mean),
                            MedHt.RPM=sapply(mcovg.rpm$IP,median),
                            MaxHt.RPM=sapply(mcovg.rpm$IP,max),
                            TotBp.RPM=sapply(mcovg.rpm$IP,sum),
                            InpMeanHt.RPM=sapply(mcovg.rpm$inp,mean),
                            InpMedHt.RPM=sapply(mcovg.rpm$inp,median),
                            InpMaxHt.RPM=sapply(mcovg.rpm$inp,max),
                            InpTotBp.RPM=sapply(mcovg.rpm$inp,sum),
                            LFC.RPM.tot=rep(0,N5),
                            LFC.RPM.max=rep(0,N5),
                            Pois.P=rep(0,N5),
                            Pois.P.BH=rep(0,N5)
                        )
                        mcovg.rpm2 <- lapply(B, function(i) lapply(mcovg.rpm[[i]], function(x) x+this.pseudo[i] ) )
                        LFC.RPM <- lapply(1:N5, function(j) log2(mcovg.rpm2$IP[[j]]/mcovg.rpm2$inp[[j]]) )
                        m$LFC.RPM.max <- sapply(LFC.RPM,max)
                        m$LFC.RPM.tot <- log2( (m$TotBp.RPM+this.pseudo[1]) / (m$InpTotBp.RPM+this.pseudo[2]) )
                        m$Pois.P <- rowMeans(cbind(
                            Upper=ppois(floor(rcounts.scaled$IP)-1,floor(rcounts.scaled$inp),FALSE,FALSE),
                            Lower=ppois(ceiling(rcounts.scaled$IP)-1,ceiling(rcounts.scaled$inp),FALSE,FALSE)
                        ))
                        
                        ## re-restrict to final peaks (incl. fused peak sets) which have Poisson p-value <= maxP
                        m <- m[m$Pois.P<=maxP,]
                        N6 <- nrow(m)
                    }
                }
            }
        }
        chr.peaks[[n]] <- m
        chr.stats[[n]] <- c(
            Length=this.len,
            IP.Reads=this.rds[1], Input.Reads=this.rds[2],
            IP.Reads.Scaled=this.rds.scaled[1], Input.Reads.Scaled=this.rds.scaled[2],
            IP.RPM.Pseudo=this.pseudo[1], Input.RPM.Pseudo=this.pseudo[2],
            Bkg.Max.Height=this.minht, Peak.Min.Height=this.callht,
            Raw.Islands=N1, Wide.Islands=N2, Called.Peaks=N3,
            HiFC.Peaks=N4, Merge.Peaks=N5, SigP.Peaks=N6
        )
        message(paste(chr,":",round(this.rds.scaled[1],0),round(this.rds.scaled[2],0),":",round(this.minht,2),round(this.callht,2),":",N1,N2,N3,N4,N5,N6))
    }
    
    ## combine chrom datasets into genomic datasets
    now <- system("date", intern=TRUE)
    message(paste("Finalizing:",now))
    peaks <- do.call(rbind, chr.peaks)
    if (nrow(peaks)>0) {
        peaks$ID <- sprintf(paste0(prefix,"_%0",nchar(nrow(peaks)),"i"),1:nrow(peaks))
        peaks$Pois.P.BH <- p.adjust(peaks$Pois.P, "BH")
    }
    stats <- rep(0, length(chr.stats[[1]])); names(stats) <- names(chr.stats[[1]])
    for (n in S) stats <- stats + chr.stats[[n]]
    stats[grepl("(Pseudo|Height)",names(stats))] <- NA
    args <- list(call=c(deparse(substitute(IP)),deparse(substitute(inp)),minHeight,minWidth,mergeGap,minFC,bkg,call,prefix),seqNames=seqNames,minht=minht)
    
    list(
        peaks=peaks,
        args=args,
        stats=do.call(rbind, c(list(Genome=stats), chr.stats)),
        covg.percentiles=c(list(Genome=gbp.mat), cbp.mat)
    )
}


apa.names$dev <- c(apa.names$dev, "call.peaks")
call.peaks <- function(IP, inp, maxP=0.05, bkg.pctl=90, prefix="Peak", scale.to=c("input","IP","larger","smaller"), seqNames=NULL) {  # mergeGap=0, 
    
    ## IMPROVEMENTS TO BE MADE:
    ## Multi-IP calling (i.e. 'IP' is a list of bams)
    ## pass in precomputed percentile tables
    ## Trim tails / split peaks on N5 set which are below minFC (to get them above minFC)
    ## threshold-by-chromosome option in case chr behaviors are too different to threshold all at once
    
    ## 'IP', 'inp' are bam-derived GRanges lists
    
    scale.to <- match.arg(scale.to)
    
    now <- system("date", intern=TRUE)
    message(paste("Preparing:",now))
    if (length(seqNames)>0) {
        ibams <- list( IP=keepSeqlevels(IP,seqNames), inp=keepSeqlevels(inp,seqNames) )
    } else {
        ibams <- list( IP=IP, inp=inp )
    }
    B <- 1:2; names(B) <- c("IP","inp")
    seqNames <- levels(seqnames(ibams$inp))  # ensure these are in GenomicRanges order
    S <- 1:length(seqNames); names(S) <- seqNames
    
    rlen <- width(ranges(IP[1]))  # read length
    chr.len <- attr(ibams$inp,"seqinfo")@seqlengths  # chromosome bp
    names(chr.len) <- levels(seqnames(ibams$inp))
    chr.len <- chr.len[match(seqNames,names(chr.len))]
    Glen <- sum(chr.len)  # genome bp
    Grds <- sapply(ibams,length)  # reads/alignments per bam
    
    Gscale <- c(IP=1,inp=1)  # initial scaling factors
    if (scale.to == "input") {
        Gscale[1] <- Grds[2]/Grds[1]  # scale IP towards input
        message(paste(c(Grds,":",Gscale[1]),collapse=" "))
    } else if (scale.to == "IP") {
        Gscale[2] <- Grds[1]/Grds[2]  # scale input towards IP
        message(paste(c(Grds,":",Gscale[2]),collapse=" "))
    } else if (scale.to == "larger") {
        Gscale[which.min(Grds)] <- max(Grds)/min(Grds)  # scale smaller sample towards larger
        message(paste(c(Grds,":",max(Gscale)),collapse=" "))
    } else if (scale.to == "smaller") {
        Gscale[which.max(Grds)] <- min(Grds)/max(Grds)  # scale larger sample towards smaller
        message(paste(c(Grds,":",min(Gscale)),collapse=" "))
    }
    
    now <- system("date", intern=TRUE)
    message(paste("Counting reads on chromosomes:",now))
    Grds.scaled <- Grds*Gscale  # post-scaling, both values are same
    Gpseudo <- 1E6/Grds.scaled/2   # whole-genome RPM pseudocount (RPM of 0.5 reads) for adjusting prior to Log-FC
    chr.rds <- merge.table.list(lapply(ibams, function(x) table(as.character(seqnames(x))) ))  #  read counts per chrom
    chr.rds <- chr.rds[,match(seqNames,colnames(chr.rds))]
    chr.rds.scaled <- Gscale*chr.rds   # scaled read counts per chrom
    chr.pseudo <- 1E6/chr.rds.scaled/2   # per-chrom RPM pseudocounts (RPM of 0.5 reads) for adjusting prior to Log-FC
    for (i in 1:length(chr.pseudo)) chr.pseudo[i] <- 1E6/Grds.scaled[1]/2     ##### REPLACE WITH GENOMIC RPM PSEUDOCOUNTS
    
    ## per-bam-per-chromosome objects
    now <- system("date", intern=TRUE)
    message(paste("Calculating coverage vectors:",now))
    covg <- lapply(B, function(i) coverage(ibams[[i]])*Gscale[i] )  # scaled read coverage
    rpm <- lapply(B, function(i) lapply(1:length(seqNames), function(j) 1E6*Gscale[i]*covg[[i]][[j]]/Grds.scaled[i] ))  # scaled RPM coverage
    
    ## set background and call vectors, one value per bam
    now <- system("date", intern=TRUE)
    message(paste("Calculating genome-wide percentiles:",now))
    Gbkg <- lapply(B, function(i) zapsmall(percentiles(unlist(lapply(covg[[i]],as.numeric))))[2:101] )  # one value per bam
    Gbkg.rpm <- lapply(B, function(i) zapsmall(1E6*Gbkg[[i]]/sum(Grds.scaled[i])) )
    minht <- rep(Gbkg$IP[call.lower], max(S))  # PERCENTILES IN READ HEIGHT
    min.rpm <- rep(Gbkg.rpm$IP[call.lower], max(S))  # PERCENTILES IN RPM
    gbp.mat <- colname( do.call(cbind, c(Gbkg,Gbkg.rpm)), paste(rep(c("IP","Input"),2),rep(c("Rds","RPM"),each=2)) )  # bkg pctl matrix
    
    now <- system("date", intern=TRUE)
    message(paste("Calculating chromosome percentiles:",now))
    Cbkg <- lapply(S, function(j) lapply(B, function(i) zapsmall(percentiles(as.numeric(covg[[i]][[j]])))[2:101] ))  # one value per chromosome per bam
    Cbkg.rpm <- lapply(S, function(j) lapply(B, function(i) zapsmall(1E6*Cbkg[[j]][[i]]/Grds.scaled[1]) ))
    cbp.mat <- lapply(S, function(j) colname( do.call(cbind, c(Cbkg[[j]],Cbkg.rpm[[j]])), paste(rep(c("IP","Input"),2),rep(c("Rds","RPM"),each=2)) ))  # bkg pctl matrices
    
    ## chromosomal objects
    chr.peaks <- chr.stats <- new.list(seqNames)
    
    m.tmp <- data.frame(
        Chr="", Start=0, End=0, ID="", Width=0,
        Pois.P=1, Pois.FDR=1,
        LFC.RPM.max=0, LFC.RPM.tot=0,
        ScaledReads=0, InpScaledReads=0, 
        MeanHt=0, MedHt=0, MaxHt=0, TotBp=0,
        MeanHt.RPM=0, MedHt.RPM=0, MaxHt.RPM=0, TotBp.RPM=0,
        InpMeanHt.RPM=0, InpMedHt.RPM=0, InpMaxHt.RPM=0, InpTotBp.RPM=0,
        stringsAsFactors=FALSE
    )
    
    ## process chromosome at a time
    now <- system("date", intern=TRUE)
    message(paste("Calling peaks per chromosome:",now))
    for (n in S) {
        
        chr <- seqNames[n]
        this.minht <- minht[n]
        this.pseudo <- Gpseudo  # chr.pseudo[,n]
        this.len <- chr.len[n]
        this.rds <- chr.rds[,n]
        this.rds.scaled <- chr.rds.scaled[,n]
        
        N1 <- N2 <- N3 <- N4 <- N5 <- N6 <- 0
        
        ## call islands w/ background subtraction
        isl1 <- slice(covg$IP[[n]], lower=this.minht)
        N1 <- length(isl1)  # total islands
        
        if (N1==0) {
            m <- m.tmp[0,]
        } else {
            
            ## restrict by island width -- must exceed read length
            isl2 <- isl1[width(isl1)>rlen] 
            N2 <- length(isl2)  # wide-enough islands 
            
            if (N2==0) {
                m <- m.tmp[0,]
            } else {
                m <- as.matrix(ranges(isl2))
                m <- data.frame(
                    Chr=rep(chr,N2),
                    Start=m[,1],
                    End=m[,1]+m[,2]-1,
                    ID="",
                    Width=m[,2],
                    stringsAsFactors=FALSE
                )
                
                ## with minimal m defined, prep some stats
                covg2 <- lapply(covg, function(x) as.numeric(x[[n]]) )  # CONVERT COVERAGES TO NUMERIC VECTORS
                mcovg <- lapply(B, function(i) lapply(1:N2, function(j) covg2[[i]][m$Start[j]:m$End[j]] ))
                mcovg.rpm <- lapply(B, function(i) lapply(mcovg[[i]], function(x) 1E6*x/Grds.scaled[i] ) )
                mcovg.rpm.adj <- lapply(B, function(i) lapply(mcovg.rpm[[i]], function(x) x+this.pseudo[i] ) )
                LFC.RPM <- lapply(1:N2, function(j) log2(mcovg.rpm.adj$IP[[j]]/mcovg.rpm.adj$inp[[j]]) )
                m.gr <- bed2gr(cbind(m[,1:4],1:N2,"+"))
                rcounts.scaled <- lapply(B, function(i) Gscale[i]*countOverlaps(m.gr, ibams[[i]], type="any", ignore.strand=TRUE) )
                
                ## add rest of stats
                m <- cbind(
                    m,
                    Pois.P=rep(1,N2),
                    Pois.FDR=rep(1,N2),
                    LFC.RPM.tot=rep(0,N2),
                    LFC.RPM.max=sapply(LFC.RPM,max),
                    ScaledReads=round(rcounts.scaled$IP,0),
                    InpScaledReads=round(rcounts.scaled$inp,0),
                    MeanHt=sapply(mcovg$IP,mean),
                    MedHt=sapply(mcovg$IP,median),
                    MaxHt=sapply(mcovg$IP,max),
                    TotBp=sapply(mcovg$IP,sum),
                    MeanHt.RPM=sapply(mcovg.rpm$IP,mean),
                    MedHt.RPM=sapply(mcovg.rpm$IP,median),
                    MaxHt.RPM=sapply(mcovg.rpm$IP,max),
                    TotBp.RPM=sapply(mcovg.rpm$IP,sum),
                    InpMeanHt.RPM=sapply(mcovg.rpm$inp,mean),
                    InpMedHt.RPM=sapply(mcovg.rpm$inp,median),
                    InpMaxHt.RPM=sapply(mcovg.rpm$inp,max),
                    InpTotBp.RPM=sapply(mcovg.rpm$inp,sum)
                )
                
                ## fill in LFC.RPM.tot and Pois.P
                m$LFC.RPM.tot <- log2( (m$TotBp.RPM+this.pseudo[1]) / (m$InpTotBp.RPM+this.pseudo[2]) )
                m$Pois.P <- rowMeans(cbind(
                    Upper=ppois(floor(rcounts.scaled$IP)-1,floor(rcounts.scaled$inp),FALSE,FALSE),
                    Lower=ppois(ceiling(rcounts.scaled$IP)-1,ceiling(rcounts.scaled$inp),FALSE,FALSE)
                ))
            }
        }

        ## store chromosome-wise stats
        N3 <- sum(m$Pois.P<=maxP)
        N4 <- sum(m$Pois.P<=maxP & m$LFC.RPM.max>=minFC)
        chr.peaks[[n]] <- m
        chr.stats[[n]] <- c(
            Length=this.len,
            IP.Reads=this.rds[1], Input.Reads=this.rds[2],
            IP.Reads.Scaled=this.rds.scaled[1], Input.Reads.Scaled=this.rds.scaled[2],
            IP.RPM.Pseudo=this.pseudo[1], Input.RPM.Pseudo=this.pseudo[2],
            Bkg.Max.Height=this.minht, Peak.Min.Height=this.callht,
            Raw.Peaks=N1, Wide.Peaks=N2, Sig.Peaks=N3, PosFC.Peaks=N4
#            Raw.Islands=N1, Wide.Islands=N2, Called.Peaks=N3,
#            HiFC.Peaks=N4, Merge.Peaks=N5, SigP.Peaks=N6
        )
        message(paste(chr,":",round(this.rds.scaled[1],0),round(this.rds.scaled[2],0),":",round(this.minht,2),round(this.callht,2),":",N1,N2,N3,N4)) #,N5,N6))
    }
    
    ## combine chrom datasets into genomic datasets
    now <- system("date", intern=TRUE)
    message(paste("Finalizing:",now))
    peaks <- do.call(rbind, chr.peaks)
    if (nrow(peaks)>0) {
        peaks$ID <- sprintf(paste0(prefix,"_%0",nchar(nrow(peaks)),"i"),1:nrow(peaks))
        peaks$Pois.FDR <- p.adjust(peaks$Pois.P, "BH")
    }
    stats <- rep(0, length(chr.stats[[1]])); names(stats) <- names(chr.stats[[1]])
    for (n in S) stats <- stats + chr.stats[[n]]
    stats[grepl("(Pseudo|Height)",names(stats))] <- NA
    args <- list(call=c(deparse(substitute(IP)),deparse(substitute(inp)),bkg.pctl,prefix),seqNames=seqNames,minht=minht)
    
    list(
        peaks=peaks,
        args=args,
        stats=do.call(rbind, c(list(Genome=stats), chr.stats)),
        covg.percentiles=c(list(Genome=gbp.mat), cbp.mat)
    )
}


apa.names$dev <- c(apa.names$dev, "pre.EdgeR")
pre.EdgeR <- function(counts, group, annot, contrasts, FDR=0.05, frange=c(1,10), model=NULL) {
    
    ## Stripped-down version of run.EdgeR that tests N DE genes at given FDR, for a range of minimum-count-per-gene thresholds
    ## The idea is that pre-restricting genes to only those with nonzero counts (in any sample) is less than optimal,
    ##  and that some (slightly) higher value (<= frange[2]) is the minimum-counts-per-gene, in any sample, to optimize EdgeR's SNR.
    ## pre.EdgeR takes a table of counts and runs EdgeR with varying minimum-expression filters to find the optimal filter, if any.

    FDR.list <- rev(c(0,10^-c(10:2),0.05,seq(0.1,1,0.1)))   # MUST MATCH FDR LIST FROM 'run.EdgeR'
    FDR.names <- c( round(FDR.list[FDR.list>=0.01],2), format(FDR.list[FDR.list<0.01],scientific=TRUE,digits=2) )  # print values
    f <- which(FDR.list==FDR)
    if (is.na(f)) stop(paste0("Given FDR '",FDR,"' is not a precalculated FDR limit!\nPlease use one of the following:\n ",paste(FDR.names,collapse=", "),"\n(Thresholds are applied as <=, except for FDR=1, which is <)"))

    out <- new.list(paste("Counts >=",frange[1]:frange[2]))
    for (i in frange[1]:frange[2]) {
        w <- which(rowSums(counts>=i)>0)
        message(paste0("Testing ",length(w)," genes with counts >= ",i," ..."))
        e <- run.EdgeR(counts[w,], group, annot[w,], contrasts, model, pre=TRUE)
        de <- do.call(rbind, lapply(e$DE.table, function(x) x[f,2:3]))
        de.vec <- unlist(lapply(1:nrow(de), function(i) de[i,] ))
        names(de.vec) <- paste0(rep(rownames(de),each=2),".",qw(UP,DN))
#        out[[i]] <- as.data.frame(c( pseudo.lib.size=list(e$dge$pseudo.lib.size), common.dispersion=list(e$dge$common.dispersion), as.list(de.vec)))
        out[[i]] <- as.data.frame(as.list(de.vec))
    }
    do.call(rbind, out)
}


apa.names$dev <- c(apa.names$dev, "run.EdgeR")
run.EdgeR <- function(counts, group, annot, contrasts, M=NULL, model=NULL, pre=FALSE) {
    
    ## runs basic EdgeR the way I usually do
    ## 'counts' is a gene counts matrix in linear scale
    ## 'group' is the group factor required by EdgeR
    ## 'annot' is a gene-annotation dataframe, same row order as 'counts'
    ## 'contrasts' is a list of pairs of factor levels to contrast; must be numeric, e.g. c(2,1); NUMERATOR FIRST, DENOMINATOR SECOND
    ## 'M' provides an alternate M value for RPKMs than colSums(counts).  This will become 'lib.size' in the DGEList() call.
    ## 'model' is a string with the model expression to fit, if not default
    ## 'pre' is intended only for use by pre.EdgeR(): stops calculation of expression datasets.
    
    require(edgeR)
    
    ## STAGE 0: test inputs, prepare output structures
    ###### still need to finish input-testing code
    if (nrow(counts)!=nrow(annot)) stop("'counts' and 'annot' must have same number of rows!\n")
    uxl <- mgrep(c("Uxon.?Len","Uxonic.?Len","Exon.?Len","Exonic.?Len","cDNA.?Len"),colnames(annot),TRUE)
    uxl <- uxl[!is.na(uxl)]
    if (length(uxl)>0) {
        exonic.len <- annot[,uxl[1]]
    } else {
        stop("Could not find a column in 'annot' which appears to have gene exonic length: need this for RPKM calculation!\n")
    }
    
    if (length(M)==0) M <- colSums(counts)
    C <- length(contrasts)
    if (length(names(contrasts))==0) names(contrasts) <- gsub(" ","",sprintf(paste0("Contrast%0",nchar(C),"i"),1:C))
    cnull <- new.list(names(contrasts))
    
    output <- list(
        input=list(     # inputs to run.EdgeR()
            counts=counts,
            annot=annot,
            group=group,
            factors=data.frame(LEVEL=as.numeric(group), LABEL=as.character(group), COLNAME=colnames(counts), stringsAsFactors=FALSE, check.names=FALSE),  # 'group' factor examination
            contrasts=contrasts,
            M=M,
            model=model
        ),
        expr=list(
            counts.all=c(),     # EdgeR-normalized counts
            counts.avg=c(),     # sample-average normalized counts
            counts.sd=c(),      # sample stdevs for normalized counts
            rpkms.all=c(),      # RPKMs based on above counts
            rpkms.avg=c(),      # sample-average RPKMs
            rpkms.sd=c(),       # sample stdevs for RPKMs
            EdgeR.logCPM=c()    # EdgeR logCPM (only one value per gene per dataset)
        ),
        dge=cnull,         # DGEList output
        et=cnull,          # exactTest output
        top=cnull,         # modified top$table output, including RPKM-based M,A values
        DE.table=cnull     # DE-at-FDR table
    )
    
    ## STAGE 1: initial EdgeR
    ######  NOT READY FOR CUSTOM MODELS  ######
    message("Running EdgeR...")
    output$dge <- estimateTagwiseDisp( estimateCommonDisp( calcNormFactors( DGEList(counts=counts, lib.size=M, group=group) ) ) )
    
    ## STAGE 2: expression values per dataset: normalized counts & RPKMs
    if (!pre) {
        message("Calculating expression datasets...")
        output$expr$counts.all <- zapsmall(output$dge$pseudo.counts)  # should have same row order as 'counts'
        output$expr$counts.all <- output$expr$counts.all
        output$expr$counts.avg <- zapsmall(aggregate.cols(output$expr$counts.all, list(group), mean))
        output$expr$counts.sd <- zapsmall(aggregate.cols(output$expr$counts.all, list(group), sd))
        colnames(output$expr$counts.all) <- paste0(colnames(output$expr$counts.all), ".Cpm")
        colnames(output$expr$counts.avg) <- paste0(colnames(output$expr$counts.avg), ".CpmAvg")
        colnames(output$expr$counts.sd) <- paste0(colnames(output$expr$counts.sd), ".CpmSd")
        
        output$expr$rpkms.all <- zapsmall(1E3*output$expr$counts.all/exonic.len)
        output$expr$rpkms.avg <- zapsmall(aggregate.cols(output$expr$rpkms.all, list(group), mean))
        output$expr$rpkms.sd <- zapsmall(aggregate.cols(output$expr$rpkms.all, list(group), sd))
        colnames(output$expr$rpkms.all) <- sub(".Cpm", ".Rpkm", colnames(output$expr$rpkms.all))
        colnames(output$expr$rpkms.avg) <- paste0(colnames(output$expr$rpkms.avg), ".RpkmAvg")
        colnames(output$expr$rpkms.sd) <- paste0(colnames(output$expr$rpkms.sd), ".RpkmSd")
    }
    
#### IGNORE -- we are not adjusting zeroes at all
#    ## ADJUST ZEROES __ONLY_AFTER__ ALL MATH HAS BEEN DONE  ...otherwise, you get strange behavior of present/absent points in the MA plots
#    output$expr$pseudo$count <- min(nonzero(output$expr$counts.all))/2
#    output$expr$pseudo$rpkm <- min(nonzero(output$expr$rpkms.all))/2
#    output$expr$counts.all[output$expr$counts.all==0] <- output$expr$pseudo$count
#    output$expr$counts.avg[output$expr$counts.avg==0] <- output$expr$pseudo$count
#    output$expr$rpkms.all[output$expr$rpkms.all==0] <- output$expr$pseudo$rpkm
#    output$expr$rpkms.avg[output$expr$rpkms.avg==0] <- output$expr$pseudo$rpkm
    
    ## STAGE 3: prepare post-DGE EdgeR datasets
    message(paste0("Preparing ",C," contrast dataset",ifelse(C>1,"s",""),"..."))
    FDR.list <- c(0,10^-c(10:2),0.05,seq(0.1,1,0.1))
    names(FDR.list) <- c("0",paste0("1E-",10:3),0.01,0.05,seq(0.1,0.9,0.1),"<1")
    FDR.list <- rev(FDR.list)  # decreasing order
    for (i in 1:C) {
        output$et[[i]] <- exactTest(output$dge, pair=rev(contrasts[[i]]))  # REVERSE CONTRAST: DENOMINATOR FIRST !!!!!
        output$top[[i]] <- topTags(output$et[[i]], nrow(counts))$table
        output$top[[i]] <- output$top[[i]][match(rownames(counts),rownames(output$top[[i]])),]  # put in rownames order
        output$top[[i]] <- data.frame(
            output$top[[i]][,c(1,3,4)],      # drop logCPM; junk statistic (but keeping a copy in output$expr)
            DE=sign(output$top[[i]]$logFC)   # 'DE' assumes p <= 1; filter later with 'post.EdgeR()'
        )
        if (!pre) {
            arp <- as.matrix(output$expr$rpkms.avg[,contrasts[[i]]])
            arp <- arp + min(nonzero(arp))/2
            output$top[[i]] <- cbind(
                output$top[[i]],
                A=log2(sqrt(apply(arp,1,prod))),  # RPKM-based 'A' value for MA plots
                M=log2(apply(arp,1,quot))         # RPKM-based 'M' value for MA & volcano plots
            )
        }
        output$DE.table[[i]] <- do.call(rbind, lapply(1:length(FDR.list), function(j) {
            is.sig <- output$top[[i]]$FDR<=FDR.list[j]
            if (FDR.list[j]==1) is.sig <- output$top[[i]]$FDR<1  # don't want <= 1; that would be all genes
            data.frame(FDR=names(FDR.list)[j], UP=sum(is.sig & output$top[[i]]$DE==1), DOWN=sum(is.sig & output$top[[i]]$DE==-1), stringsAsFactors=FALSE, check.names=FALSE)
        }))
    }
    rnames.et <- rownames(output$et[[1]]$table)
    if (!pre) output$expr$EdgeR.logCPM <- matrix(output$et[[1]]$table$logCPM[match(rownames(counts),rnames.et)], ncol=1, dimnames=list(rnames.et,"logCPM"))
    
    output
}


apa.names$dev <- c(apa.names$dev, "cluster.validity")
cluster.validity <- function(x, maps, method="all", ext=FALSE) {
    
    ## wrapper for clusterCrit package flagship functions, intCriteria() and extCriteria()
    
    require(clusterCrit)
    M <- length(maps)
    if (length(names(maps))==0) names(maps) <- 1:M
    intC <- do.call(rbind, lapply(1:M, function(i){ message(paste("Internal:",names(maps)[i])); unlist(intCriteria(x, maps[[i]], method)) }))
    rownames(intC) <- names(maps)
    
    optim <- list(
        max=c("calinski_harabasz","dunn","gamma","gdi11","gdi12","gdi13","gdi21","gdi22","gdi23","gdi31","gdi32","gdi33","gdi41","gdi42","gdi43","gdi51","gdi52","gdi53","pbm","point_biserial","ratkowsky_lance","silhouette","tau","wemmert_gancarski"),  # max score is best
        min=c("banfeld_raftery","c_index","davies_bouldin","g_plus","mcclain_rao","ray_turi","scott_symons","sd_scat","sd_dis","s_dbw","xie_beni"),  # min score is best
        maxdiff=c("ball_hall","ksq_detw","trace_w","trace_wib"),  # max second derivative is best
        mindiff=c("det_ratio","log_det_ratio","log_ss_ratio")   # min second derivative is best
    )
    matsym <- list(
        sym=c("czekanowski_dice","folkes_mallows","hubert","jaccard","kulczynski","phi","rand","rogers_tanimoto","russel_rao","sokal_sneath1","sokal_sneath2"),  # symmetric score matrices
        asym=c("mcnemar","precision","recall")  # asymmetric score matrices
    )
    
    intC.ranks <- intC
    for (j in 1:ncol(intC)) {
        intC.ranks[,j] <-
            if (colnames(intC)[j] %in% optim$max) {
                match(1:M,rev(order(intC.ranks[,j])))
            } else if (colnames(intC)[j] %in% optim$min) {
                match(1:M,order(intC.ranks[,j]))
            } else if (colnames(intC)[j] %in% optim$maxdiff) {
                deriv2 <- diff(diff(intC.ranks[,j]))
                match(1:M,rev(order(deriv2))+1)
            } else if (colnames(intC)[j] %in% optim$mindiff) {
                deriv2 <- diff(diff(intC.ranks[,j]))
                match(1:M,order(deriv2)+1)
            } else {
                message(paste0("Unknown internal cluster validity index '",colnames(intC)[j],"'!  Please add a handler.\n"))
                rep(NA,M)
            }
    }
    
    pre.mono <- apply(intC.ranks, 2, function(x) {
        na <- sum(is.na(x))
        y <- x[!is.na(x)]
        d <- diff(y)
        if (y[1] < y[length(y)]) {
            monotonic <- is.monotonic(y, decreasing=FALSE)
            sequential <- sum(d==1)+na+1
            all.flips <- sum(d==-1)
            single.flips <- all(d %in% -1:3)
        } else {
            monotonic <- is.monotonic(y, decreasing=TRUE)
            sequential <- sum(d==-1)+na+1
            all.flips <- sum(d==1)
            single.flips <- all(d %in% -3:1)
       }
       c(mono=monotonic,sequ=sequential,f.all=all.flips,f.single=single.flips)
    })
    near.mono <- pre.mono[4,]==1
    intC.mono <- matrix(NA, 2, ncol(pre.mono), FALSE, list(c("monotonic","monotonic with N flips"),colnames(pre.mono)))
    intC.mono[1,] <- pre.mono[1,]
    intC.mono[2,near.mono] <- pre.mono[3,near.mono]
    
    output <- list(intCriteria=intC, intRanks=intC.ranks, intMonotonic=intC.mono)
    
    if (ext) {
        pre.extC <- vector("list", length=M)
        for (i in 1:M) {
            message(paste("External:",names(maps)[i]))
            pre.extC[[i]] <- vector("list", length=M)
            for (j in 1:M) pre.extC[[i]][[j]] <- extCriteria(maps[[i]],maps[[j]],method)
        }
        
        E <- length(pre.extC[[1]][[1]])
        En <- names(pre.extC[[1]][[1]])
        extC <- vector("list", length=E)
        names(extC) <- En
        blank <- matrix(NA, M, M, F, list(names(maps),names(maps)))
        for (e in 1:E) {
            extC[[e]] <- list(scores=blank, globalRank.sim=blank, globalRank.dif=blank)
            for (i in 1:M) {
                for (j in 1:M) extC[[e]]$scores[i,j] <- pre.extC[[i]][[j]][[e]]
            }
        }
        
        get.ranks <- function(x) {
            if (is.matrix(x)) diag(x) <- NA
            uvals.dif <- sort(unique(x))
            uvals.sim <- rev(uvals.dif)
            list(sim=match(x,uvals.sim), dif=match(x,uvals.dif))
        }
        
        for (e in 1:E) {
            g.ranks <- get.ranks(extC[[e]]$scores)
            extC[[e]]$globalRank.sim[1:M^2] <- g.ranks$sim
            extC[[e]]$globalRank.dif[1:M^2] <- g.ranks$dif
            r.ranks <- apply(extC[[e]]$scores,1,get.ranks)
            extC[[e]]$rowRank.sim <- do.call(rbind, lapply(r.ranks, "[[", "sim"))
            extC[[e]]$rowRank.dif <- do.call(rbind, lapply(r.ranks, "[[", "dif"))
            colnames(extC[[e]]$rowRank.sim) <- colnames(extC[[e]]$rowRank.dif) <- names(maps)
            if (En[e] %in% matsym$asym) {
                ## if matrices symmetric, then col rankings same as row rankings above
                ## these are asymmetric, so need separate set of col rankings
                c.ranks <- apply(extC[[e]]$scores,2,get.ranks)
                extC[[e]]$colRank.sim <- do.call(cbind, lapply(c.ranks, "[[", "sim"))
                extC[[e]]$colRank.dif <- do.call(cbind, lapply(c.ranks, "[[", "dif"))
                rownames(extC[[e]]$colRank.sim) <- rownames(extC[[e]]$colRank.dif) <- names(maps)
            }
        }
        
        c(output, list(extCriteria=extC))
    } else {
        output
    }
}


apa.names$dev <- c(apa.names$dev, "chrom.DE.density")
chrom.DE.density <- function(n, L, genes, gene.p=0.05, bin.p=0.02, min.genes=2, plot=TRUE, ymax=NULL, sig=TRUE, aspect=NULL, xticks=15) {
    
    ## 'n' is a chromosome name
    ## 'L' is that chromosome's length
    ## 'genes' is a matrix/data.frame with rows = genes on that chromosome, rownames = gene IDs, and 4 columns = logFC, p-value, start.coord, end.coord
    ## 'gene.p' and 'bin.p' are p-value cutoffs to determine DE genes, and DE-enriched bins, respectively
    ## 'min.genes' will not test a window for significance unless it contains at least this many genes
    
#    require(GenomicRanges)
    
    message(paste("Processing",n))
    genes <- genes[order(genes[,3]),,drop=FALSE]  # order by start
    which.DE <- which(genes[,2]<=gene.p)
    genes.DE <- genes[which.DE,,drop=FALSE]  # DE-only
    gene.ids <- rownames(genes)
    gene.ids.DE <- rownames(genes.DE)
    mid.TOT <- rowMeans(genes[,3:4])
    mid.DE <- rowMeans(genes.DE[,3:4])
    pos <- which(genes.DE[,1]>0)
    neg <- which(genes.DE[,1]<0)
    NP <- length(pos)
    NN <- length(neg)
    NDE <- NN+NP
    NTOT <- nrow(genes)
    scale <- ifelse(L>1E7, 1E6, 1E4)
    bin.size <- 5*L/NTOT
    half.size <- trunc(bin.size/2)+1
    dhist.args <- list(vecs=list(UP=mid.DE[pos],DOWN=mid.DE[neg]), dens.n=2^12, adjust=1, bw=bin.size, denorm=TRUE, ylab="")
    
    if (plot) {
        dhist.args <- c(dhist.args, list(col=c(2,4), points=TRUE, xlim=c(0,L), main=paste("Sig DE Gene Density Along",n), xaxt="n"))
        if (length(ymax)>0) dhist.args <- c(dhist.args, list(ylim=c(0,ymax)))
        par(las=1, xaxs="i")
        if (NP>2|NN>2) {
            d <- do.call(dhist, dhist.args)
        } else {
            null.plot(main=paste("Sig DE Gene Density Along",n))
        }
        axmax <- round(trunc(L/scale),-1)
        axlab <- seq(0, axmax, xticks)
        axis(1, at=axlab*scale, labels=paste0(axlab,ifelse(scale==1E6,"M","K")))
    } else {
        if (NP>2|NN>2) {
            d <- do.call(dhist, c(dhist.args, list(plot=FALSE)))
        } else {
            d <- list(ylim=c(0,0))
        }
    }
    
    if (sig) {
        message(" Calculating bin gene counts...")
        
        bin.mids <- lapply(d$density, "[[", "x")
        bin.genes <- lapply(bin.mids, function(x) lapply(x, function(i) {
            list(
                TOT=which(mid.TOT>=i-half.size & mid.TOT<=i+half.size),
                DE=which.DE[which(mid.DE>=i-half.size & mid.DE<=i+half.size)],
                POS=which.DE[pos[which(mid.DE[pos]>=i-half.size & mid.DE[pos]<=i+half.size)]],
                NEG=which.DE[neg[which(mid.DE[neg]>=i-half.size & mid.DE[neg]<=i+half.size)]]
            )
        }) )
        bin.N.genes <- lapply(bin.genes, function(x) t(sapply(x,listLengths)) )
        
        bin.winstat <- lapply(1:2, function(i){
            bmi <- bin.mids[[i]]
            data.frame(
                CHROM=n,
                START=bmi-half.size,
                END=bmi+half.size,
                NAME=paste0(names(bin.mids)[i],".",sprintf(paste0("%0",nchar(max(length(bmi))),"i"),1:length(bmi))),
                DE.GENES=bin.N.genes[[i]][,"DE"],
                STRAND="+",
                I=i,
                BIN=1:length(bmi),
                Y=d$density[[i]]$y
            )
        }); names(bin.winstat) <- names(bin.mids)
        
        message(" Calculating bin FET p-values...")
#        ## FULL VERSION -- mothballed -- rarely get sig pos-only, neg-only windows, and no provision for plotting them either
#        ## also, contingency table math is wrong...
#        bin.FET.p <- lapply(bin.N.genes, function(x) t(apply(x, 1, function(y) {  
#            c(
#                ALL=fisher.test(matrix(c(DE.IN=y[2],DE.OUT=NDE-y[2],ALL.IN=y[1],ALL.OUT=NTOT-y[1]),2))[[1]]
#                POS=fisher.test(matrix(c(DE.IN=y[3],DE.OUT=NP-y[3],ALL.IN=y[2],ALL.OUT=NDE-y[2]),2))[[1]],
#                NEG=fisher.test(matrix(c(DE.IN=y[4],DE.OUT=NN-y[4],ALL.IN=y[2],ALL.OUT=NDE-y[2]),2))[[1]]
#            )
#        })))
#        bin.sig <- lapply(bin.FET.p, function(x) apply(x, 2, function(y) which(y<=0.01) ))  # FULL VERSION -- mothballed
        
        bin.FET.p <- lapply(bin.N.genes, function(x) {
            apply(x, 1, function(y) {
                if (y[2]>=min.genes) {
                    DE.IN <- y[2]
                    DE.OUT <- NDE-DE.IN
                    NONDE.IN <- y[1]-DE.IN
                    NONDE.OUT <- NTOT-DE.IN-NONDE.IN-DE.OUT
                    m <- matrix(c(DE.IN,DE.OUT,NONDE.IN,NONDE.OUT),2)
                    if (sum(m) != NTOT) message(paste0("WARNING: FET contingency does not sum correctly!  ",paste(c(m),collapse="+"),"=",sum(m)," not ",NTOT,"!\n"))
                    fisher.test(m)[[1]]
                } else {
                    NA
                }
            })
        })
        for (i in 1:2) bin.winstat[[i]] <- cbind(bin.winstat[[i]], FET.P=bin.FET.p[[i]], SIG=falsify(bin.FET.p[[i]]<=bin.p))
        bin.sig <- lapply(bin.FET.p, function(x) which(falsify(x<=bin.p)) )
        d$significance <- list(bin.size=bin.size, bin.mids=bin.mids, bin.N.genes=bin.N.genes, bin.FET.p=bin.FET.p, bin.sig=bin.sig)
        nsig <- length(unlist(bin.sig))
        
        if (nsig>0) {
            
            bin.winstat.sig <- lapply(bin.winstat, function(x) x[x$SIG,] )
            bin.sig.truexy <- do.call(rbind, bin.winstat.sig)
            bin.sig.truexy <- bin.sig.truexy[order(bin.sig.truexy$START),]
            bin.sig.truex.merge <- find.runs(diff(bin.sig.truexy$START)<bin.size)
            bin.sig.truex.merge <- bin.sig.truex.merge[names(bin.sig.truex.merge) == "TRUE"]
            for (j in 1:length(bin.sig.truex.merge)) bin.sig.truex.merge[[j]][2] <- bin.sig.truex.merge[[j]][2]+1  # incorporate right endpoint, which was previously in a "FALSE"-named element (or missing, if last value)
            bin.sig.truex.merged <- unlist(lapply(bin.sig.truex.merge, function(x) x[1]:x[2] ))
            bin.sig.truex.singleton <- setdiff(1:nrow(bin.sig.truexy), bin.sig.truex.merged)  # any unmerged points
            if (length(bin.sig.truex.singleton)>0) for (i in 1:length(bin.sig.truex.singleton)) bin.sig.truex.merge <- c(bin.sig.truex.merge, "SINGLE"=list(rep(bin.sig.truex.singleton[i],2)))
            
            sig.win.bed <- rownameless(do.call(rbind, lapply(bin.sig.truex.merge, function(x) {
                w <- x[1]:x[2]
                winstats <- rbind(
                    bin.winstat.sig$UP[bin.winstat.sig$UP$NAME %in% bin.sig.truexy$NAME[w],],
                    bin.winstat.sig$DOWN[bin.winstat.sig$DOWN$NAME %in% bin.sig.truexy$NAME[w],]
                )
                data.frame(
                    CHROM=n,
                    START=min(winstats$START),
                    END=max(winstats$END),
                    NAME="",
                    DE.GENES=0,
                    STRAND="+",
                    MIN.Y=min(winstats$Y),
                    MAX.Y=max(winstats$Y),
                    MIN.P=min(winstats$FET.P),
                    MAX.P=max(winstats$FET.P)
                )
            })))
            sig.win.bed$NAME <- names(bin.sig.truex.merge) <- paste0("Sig.Window.",1:length(sig.win.bed))
            nwin <- nrow(sig.win.bed)
            
            sig.win.orig.bins <- lapply(bin.sig.truex.merge, function(x) lapply(bin.winstat.sig, function(y) y$BIN[y$NAME %in% bin.sig.truexy$NAME[x[1]:x[2]]] ))
            sig.win.bed.genes <- lapply(sig.win.orig.bins, function(x) {
                genes <- lapply(1:2, function(i) {
                    list(
                        TOT=sort(unique(unlist(lapply(bin.genes[[i]][min(x[[i]]):max(x[[i]])], "[[", "TOT")))),
                        DE=sort(unique(unlist(lapply(bin.genes[[i]][min(x[[i]]):max(x[[i]])], "[[", "DE"))))
                    )
                })
                list(
                    TOT=sort(unique(unlist(lapply(genes, "[[", "TOT")))),
                    DE=sort(unique(unlist(lapply(genes, "[[", "DE"))))
                )
            })
            sig.win.bed$DE.GENES <- listLengths(lapply(sig.win.bed.genes, "[[", "DE"))
            sig.win.bed$TOT.GENES <-  listLengths(lapply(sig.win.bed.genes, "[[", "TOT"))
            
            ### WORKING HERE
            ### THE ISSUE IS: density ran independently on up, down does not have same window positions.
            ###               when combining up + down windows in one sig window, gene counts can change from the original FET counts.
            ###               SOLUTIONS: 1) forget FET values once windows are merged, 2) run density on all-DE just for window calcs (preferred).
            
            sig.win.genes <- lapply(1:nwin, function(i) {
                sig.win.orig.bins
            })
            
            sig.win.genes <- lapply(1:nwin, function(i) {
                rownameless(unique(do.call(
                    rbind,
                    lapply(bin.genes, function(y) {
                        w <- sort(unique(unlist(y[x[1]:x[2]])))
                        data.frame(GeneID=gene.ids[w],genes[w,,drop=FALSE])
                    })
                )))
            })
            d$significance <- c(d$significance, list(sig.windows=rownameless(sig.win.bed), sig.window.genes=sig.win.genes))
            
            if (plot) {
                yrange.1pct <- diff(d$ylim)*0.01
                margin <- diff(range(d$point.y))/length(bin.sig)
                win.xplot.range <- sig.win.bed[,2:3]
                win.yplot.range <- rowrep(c(min(d$point.y)-margin*2, max(d$point.y)+margin*2), nrow(win.xplot.range))
                if (length(aspect)>0) {
                    margin.x <- (diff(d$xlim)*aspect[1])*margin/(diff(d$ylim)*aspect[2]) / 2
                    win.xplot.range[,1] <- win.xplot.range[,1]-margin.x
                    win.xplot.range[,2] <- win.xplot.range[,2]+margin.x
                }
                for (i in 1:length(bin.sig.truex.merge)) rect(win.xplot.range[i,1], win.yplot.range[i,1], win.xplot.range[i,2], win.yplot.range[i,2], border=3, lwd=1)
            }
        }
    }
    
    invisible(d)
}


apa.names$dev <- c(apa.names$dev, "PCA.factor.eval")
PCA.factor.eval <- function(PCs, facs, separation=c("none","full"), nshuf=100, anova=FALSE) {

    ##### later, separation=c("none","sig","full")
    ## 'pca' = output of PCA.basic()
    ## 'facs' = data.frame of explanatory factors (samples on rows, same order as 'PCs')
    ## Returns data for how well said factor(s) explain each PC, also how well (or if) any pair of PCs separates the levels of a given factor.
    
    separation <- match.arg(separation)
#    PCs <- pca$sample.projections
    P <- ncol(PCs)
    nlev <- sapply(facs,luniq)
    if (any(nlev==1)) message(paste(sum(nlev==1),"factors had only one level!  Ignoring these...\n"))
    facs <- facs[,nlev>1]
    F <- ncol(facs)
    message(paste0(F," factors\n",P," PCs\nRegressing on real and ",nshuf," shuffled factors..."))
    is.fac <- which(sapply(facs,is.factor))
    F2 <- length(is.fac)
    
    ## Correlate factors
    fac2corr <- do.call(cbind,lapply(facs,as.numeric))
    rownames(fac2corr) <- rownames(facs)
    fcorr <- suppressWarnings(cor(fac2corr, use="pairwise.complete.obs", method="spearman"))  # get rid of "standard deviation is zero" stuff
    output <- list(factor.corr=fcorr)
    
    ## Regress factors to PCs
    regression <- TRUE  # for code testing only
    if (regression) {
        reg.data <- lapply(1:P, function(p) {
            message(paste0("PC",p))
            pf <- lapply(1:F, function(i) {
                l <- lm(PCs[,p]~facs[[i]])
                fake.stats <- t(sapply(1:nshuf, function(n) {
                    l2 <- lm(PCs[,p]~sample(facs[[i]], length(facs[[i]])))
                    ars <- max(c(summary(l2)$adj.r.squared,0))
                    aop <- ifelse(anova, anova(l2)[[5]][[1]], NA)
                    c(adj.r.squared=ars, anova.p=aop)
                }))
                lm.sum <- summary(l)
                anova.res <- if (anova) { anova(l) } else { NA }
                ars <- max(c(lm.sum$adj.r.squared,0))
                aop <- ifelse(anova, anova.res[[5]][[1]], NA)
                list(
                    stats=list( adj.r.squared=ars, anova.p=aop ),
                    real=list( lm=l, sum=lm.sum, anova=anova.res ),
                    shuf=fake.stats
                )
            })
            names(pf) <- colnames(facs)
            pf
        })
        names(reg.data) <- colnames(PCs)
        
        r2.tab <- r2.tab2 <- t(sapply(reg.data, function(x) sapply(x, function(y) ifelse(length(y)==1,NA,y$stats$adj.r.squared) )))
        for (i in 1:P) { for (j in 1:F) {
            if (quantile(reg.data[[i]][[j]]$shuf[,1],0.95)>r2.tab[i,j]) r2.tab2[i,j] <- 0   # if shuffled beat observed, delete observed
        } }
        p.tab <- p.tab2 <- t(sapply(reg.data, function(x) sapply(x, function(y) ifelse(length(y)==1,NA,y$stats$anova.p) )))
        if (anova) {
            for (i in 1:P) { for (j in 1:F) {
                if (quantile(reg.data[[i]][[j]]$shuf[,2],0.05)<p.tab[i,j]) p.tab2[i,j] <- 1     # if shuffled beat observed, delete observed
            } }
        }
        
        #### WORKING ON THIS -- PER PC, PROVIDE A SHORT-LIST OF EXPLANATORY FACTORS & WEIGHTS
        pc.exp <- lapply(as.list(as.data.frame(t(r2.tab2))), function(x){ names(x)=colnames(r2.tab2); rev(sort(x[x>0])) })
        fac.exp <- lapply(as.list(as.data.frame(r2.tab2)), function(x){ names(x)=rownames(r2.tab2); rev(sort(x[x>0])) })
        for (i in which(sapply(pc.exp,length)==0)) pc.exp[[i]] <- NA
        for (i in which(sapply(fac.exp,length)==0)) fac.exp[[i]] <- NA
        
        output <- c(output, list(regression=list(r2=r2.tab, p=p.tab, r2.filtered=r2.tab2, p.filtered=p.tab2, pc.exp=pc.exp, fac.exp=fac.exp, data=reg.data)))
    }
    
    ## Test all pairs of PCs for ability to separate levels of each CATEGORICAL factor
    if (separation != "none") {
        ndim <- 2  # currently, will only support 2-D separation
        ncr <- t(combn(ncol(PCs),ndim))
        rownames(ncr) <- apply(ncr,1,paste,collapse="-")
        ncr.per.fac <- matrix(TRUE, nrow(ncr), F, FALSE, list(rownames(ncr),colnames(facs)))
        
        if (separation == "sig") {
            
            
            ############# THIS MODE DOES NOT WORK CORRECTLY
            
            
            ncr.per.fac[1:length(ncr.per.fac)] <- FALSE
            for (i in 1:F) {
                hi.PCs <- which(r2.tab2[,i]>0)
#                IM(i, hi.PCs)
                if (length(hi.PCs)>1) {
                    ## multiple high-r2 PCs found: restrict to pairs of these
                    keep <- which(rowSums(apply(ncr, 2, function(x) x%in%hi.PCs ))==ndim)
                } else if (length(hi.PCs)>1) {
                    ## only one high-r2 PC found: restrict to any pair with this
                    keep <- which(rowSums(apply(ncr, 2, function(x) x%in%hi.PCs ))>0)
                } else {
                    ## no high-r2 PCs found: search all pairs
                    keep <- 1:nrow(ncr)
                }
                ncr.per.fac[keep,i] <- TRUE
            }
        }
        ncr.per.fac <- ncr.per.fac[,is.fac]  # only using this subset below
#        for (i in 1:nrow(ncr.per.fac)) IM(ncr.per.fac[i,])
#        IM(colSums(ncr.per.fac))
        ncr2 <- ncr[rowSums(ncr.per.fac)>0,]   # matrix of PC pairs; rownames are "PCA-PCB", col 1 = PCA, col 2 = PCB
        
        message(paste("Testing",nrow(ncr2),"PC pairs for level separation..."))
        sep.data <- lapply(1:nrow(ncr2), function(i) {
            IM(i)
            test.facs <- is.fac[which(ncr.per.fac[i,])]  # subset of is.fac which is considered 'testable' on this PC combo
            hull.sep <- lapply(test.facs, function(f) {
                
                samp.ok <- !is.na(facs[,f]) & facs[,f]!=""
                maxf <- max(as.numeric(facs[samp.ok,f]))
                PCs.all <- PCs[samp.ok,ncr2[i,],drop=FALSE]
                
                superhull <- PCs.all[chull(PCs.all),]  # hull for all points
                super.area <- polyarea(superhull[,1], superhull[,2])
                ## instead of using actual superhull area, calculate median of all leave-one-out superhull areas, to reduce impact of outlier vertices
                super.area.mLOO <- median(sapply(1:nrow(superhull), function(i) polyarea(superhull[-i,1], superhull[-i,2]) ))
                
                cmn <- colMin(PCs.all)
                cmx <- colMax(PCs.all)
                space <- rbind(c(cmn),c(cmx[1],cmn[2]),c(cmx),c(cmn[1],cmx[2]))
                space.hull <- space[chull(space),]
                space.area <- polyarea(space.hull[,1],space.hull[,2])
                
                PCs.by.factor <- mat.split(PCs.all, as.numeric(facs[samp.ok,f]))
                PC.hulls <- lapply(PCs.by.factor, function(x) x[chull(x),] )
                is.poly <- sapply(PC.hulls,nrow)>2
                PC.mldist <- PC.areas <- sapply(PC.hulls, function(x) max(c(dist(x))) )  # init max-linedist and areas as same
                PC.areas[is.poly] <- sapply(PC.hulls[is.poly], function(x) polyarea(x[,1],x[,2]) )  # replace polygonal hull values with actual areas
                min.alr <- min(PC.areas[is.poly]/PC.mldist[is.poly])  # minimum area-to-length ratio; will be used to calculate pseudo-areas for linear hulls
                PC.areas[!is.poly] <- PC.areas[!is.poly] * min.alr  # convert line distances to pseudo-areas for linear hulls
                hull.area.sum <- sum(PC.areas)
                overlap <- polygon.overlap(PCs.by.factor)$combined
                
                centroids <- do.call(rbind, lapply(PCs.by.factor, colMeans))
                centroids.hull <- centroids[chull(centroids),]
                if (nrow(centroids.hull)==2) {
                    centroids.area <- dist(centroids.hull) * min.alr  # pseudo-area = line length * alr
                } else {
                    centroids.area <- polyarea(centroids.hull[,1],centroids.hull[,2])
                }
                
                spread <- c( hull.area=hull.area.sum, cent.area=centroids.area, super.area=super.area.mLOO, space.area=space.area )
                list(ol=overlap, sd=spread)
                ## plot(PCs.all, col=rainbow(maxf)[as.numeric(facs[samp.ok,f])]); points(centroids, pch=3, col=rainbow(maxf)); points(centroids.hull, pch=4)
                ## abline(lm(centroids[,2]~centroids[,1]))
            })
            names(hull.sep) <- colnames(facs)[test.facs]
            list(PCs=ncr2[i,], testable.factors=test.facs, sep.pct=lapply(hull.sep, "[[", "ol"), sep.area=lapply(hull.sep, "[[", "sd"))
        })

        sep.pct <- do.call(rbind, lapply(sep.data, function(x) sapply(x$sep.pct, function(y){ z=y[lower.tri(y)]; sum(z!=1)/length(z) })))  # separated level pairs / all level pairs
        spatials <- qw(hull.area,cent.area,super.area,space.area)
        names(spatials) <- spatials
        spatials <- lapply(spatials, function(x) do.call(rbind, lapply(lapply(sep.data, "[[", "sep.area"), function(y) unlist(lapply(y, "[[", x)))))  # hull centroid area / total area
        for (i in 1:length(spatials)) for (j in 1:ncol(spatials[[i]])) spatials[[i]][,j] <- unlist(spatials[[i]][,j])
        rownames(sep.pct) <- apply(ncr2,1,paste,collapse="-")
        for (i in 1:length(spatials)) rownames(spatials[[i]]) <- rownames(sep.pct)
        output <- c(output, list(spatial.sep=list(pct.levels.separated=sep.pct, separation.degree=spatials, data=sep.data, ncr.per.fac=cbind(ncr,ncr.per.fac))))
        
        ## Lots more improvements, like:
        ## disjoint hull area / total hull area (normalized to total loadings area?)
        ## centroid spread (normalized to total loadings area?)  DONE
        ## clustering validity index where clusters = hulls?
    }
    
    output
}


apa.names$dev <- c(apa.names$dev, "PCA.reconstitute")
PCA.reconstitute <- function(pca, PCs, scaling, orig=NULL) {
    
    
    
    ##### UNDER CONSTRUCTION #####
    
    
    
    ## Reconstructs original data from a subset of PCs
    ## 'pca' is an output object from PCA.basic()
    ## 'PCs' is a numeric vector of PC numbers to use
    ## 'scaling' can be         ##########  STANDARDIZE THIS  ##########
    
    
    ## if rescaling is needed, must use 'scaling' and 'pca$methods' (and 'orig' if supplied) to determine order of rescaling operations
    
    
    recons <- pca$gene.scores[,PCs] %*% t(pca$eigenvectors[,PCs])
    ## NO RESCALING NEEDED FOR UNSCALED PCA (cor/cov doesn't matter)
    
    ## THIS RESCALING WORKS FOR SAMPLE-SCALED PCA (cor/cov doesn't matter)
    for (i in 1:ncol(recons)) recons[,i] <- recons[,i]*(sd(lcounts.ok[,i])/sd(recons[,i]))
    for (i in 1:ncol(recons)) recons[,i] <- recons[,i]+(mean(lcounts.ok[,i])-mean(recons[,i]))
    max(lcounts.ok-recons)
    
    ## THIS RESCALING WORKS FOR GENE-SCALED PCA (cor/cov doesn't matter)
    recons <- recons*rowSDs(lcounts.ok)
    recons <- recons+rowMeans(lcounts.ok)
    max(lcounts.ok-recons)
    
    ## COMBINE THEM FOR DOUBLE-SCALED PCA (gene first then sample) (cor/cov doesn't matter)
    for (i in 1:ncol(recons)) recons[,i] <- recons[,i]*(sd(zcounts.ok[,i])/sd(recons[,i]))
    for (i in 1:ncol(recons)) recons[,i] <- recons[,i]+(mean(zcounts.ok[,i])-mean(recons[,i]))
    recons <- recons*rowSDs(lcounts.ok)
    recons <- recons+rowMeans(lcounts.ok)
    
    message(paste("Max error:",max(lcounts.ok-recons)))
    recons
}

