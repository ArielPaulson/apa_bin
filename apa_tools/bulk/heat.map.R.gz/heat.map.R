

apa.names$plots <- c(apa.names$plots, "heat.map","heat.map.F")
heat.map <- heat.map.F <- function( mat, Rowv=NULL, Colv=NULL, c.dend=FALSE, r.dend=FALSE, aspect=NULL, dimensions=NULL, dendro.pix=c(150,150), label.pix=c(NA,NA), scale.pix=100, title.pix=40, 
                                   palette=NULL, rev.pal=FALSE, col.limits=NULL, quant.cols=FALSE, max.cols=256, max.qres=1E6, NA.col=8, col.center=NULL, grid.col=0, grid.lty=1, xlabs=TRUE, ylabs=TRUE, 
                                   metric="euclidean", linkage="average", scale.horiz=FALSE, scale.div=10, scale.term=FALSE, las=2, cex=1.5, family="mono", main=NULL, imgname=NULL, antialias=TRUE, 
                                   att.cols=NULL, att.rows=NULL, att.palette=NULL, row.optimize=NULL, col.optimize=NULL, device=c("png","pdf"), ppi=100, interpolate=NULL, verbose=FALSE, row.names=TRUE, 
                                   col.names=TRUE, label.text=NULL, label.col=NULL, label.cex=NULL, show.scale=TRUE, xaxt=NULL, yaxt=NULL ) {
    
## myImagePlotUltra args: function(x, pmar=c(5,5), x.aspect=c(4,1), rnames=NULL, cnames=NULL, palette="KBY", scale.div=10, rev.pal=FALSE, 
##                                     att.cols=NULL, att.rows=NULL, att.palette=NULL, col.limits=NULL, col.center=NULL, quant.cols=FALSE, max.cols=256, max.qres=1E6, NA.col=8, 
##                                     grid=0, mask=NULL, mask.ramp=NULL, interpolate=NULL, main=NULL, title=NULL, las=2, cex=1, cex.axis=1, axes=TRUE, unlog.scale=NA,
##                                     label.text=NULL, label.col=NULL, label.cex=NULL, show.scale=TRUE, ...) {
    
################ MUST ADD: auto png, with "size" factor to allow expansion, but img dim controlled by aspect calculations (thus png'd by the function) to make sure there are no surprises.
################ -- I thought this was added long ago?
    
    ## Fusion of R base heatmap() with Chris Seidel's myImagePlot() and MEV's color scale/limit control,
    ##    plus custom palettes, portable x:y aspect control, and other improvements.
    ##
    ## "mat": a matrix or dataframe to cluster
    ## "Rowv=TRUE" = row reordering; FALSE = none; NULL = decide based on "r.rend" value.
    ## "Rowv=<hclust object>" allows a predefined clustering to be used
    ## "Colv" works the same way for columns.
    ## "r.dend=TRUE" plots row dendrogram (only if reordering is used)
    ## "c.dend=TRUE" plots column dendrogram (only if reordering is used)
    ## 'aspect' and 'dimensions': see next section, "TWO WAYS TO CONTROL HEATMAP DIMENSION"
    ## "pmar": length-2 vector specifying x and y margin sizes (mainly so your row/columns labels are fully visible)
    ## 	  pmar values only affect the axes along which labels are printed, not the other axes
    ##    pmar x value is calculated as pmar[1] * row height; pmar y value is calculated as pmar[2] * col width; 
    ## "dendro.pix" indicate pixels to use for the dendrogram areas.  Given as c(x.dendro.dim, y.dendro.dim).
    ##    Thus, x.dendro.dim sets the height for col dendro and y.dendro.dim sets width for row dendro, since the other dims of each dendro area are pegged to the heatmap.
    ## "label.pix" works the same as dendro.pix, but for labels.  If any entry is NA, will autodetect proper size to fit respective labels (ONLY WORKS WHEN family="mono" !!!).
    ## "title.pix" and "scale.pix" similarly indicate, in pixels, title height and color-scale width (if vertical scale, or height if horizontal).
    ## "palette" indicates a palette name.  See list inside palettizer() or use an RColorBrewer palette name; NULL=Autodetect.
    ##    Autodetect based on data range: [0,Inf] = "Reds"; [-Inf,0] = rev("Greens"); [-Inf,Inf] = Cyan-Black-Yellow.
    ## "rev.pal" reverse palette?
    ## "col.limits": MeV-style, sets saturation limits for the color gradient.
    ## "col.center=x": NOT READY YET.  When complete it will force divergent palettes to center at 'x'.
    ## "grid.col": if not zero, will plot gridlines between cells in this color.  "grid.lty" controls gridline lty.
    ## "xlabs", "ylabs": print rows/column labels?
    ## "metric": if heat.map reorders rows/columns, what metric should dist() use? (use same names)
    ## "linkage": if heat.map reorders rows/columns, what linkage should hclust() use? (use same names)
    ## las, par, cex, family, main: as usual
    ## "device": if printing to file, specify png (default) or pdf.  IF PDF: be aways of 'ppi' value = "pixels per inch", which converts png dimensions to pdf page dimensions
    ## 
    ## TWO WAYS TO CONTROL HEATMAP DIMENSION:
    ## 1. Using 'aspect', which controls cell aspect and pixels-per-aspect.
    ##    a. aspect=c(x,y,ppa) sets the cellwise aspect ratio (x,y) and the pixels per aspect for plotting (ppa).
    ##    b. aspect ratio is a ratio, and will be normalized such that min(x,y) == 1.  For instance x=3, y=2 will become x=1.5, y=1.
    ##    c. (normalized cell aspects) * (pixels per aspect) specifies cell dimensions.
    ##    d. (cell dimensions) * (heatmap nrow, ncol) specifies final heatmap dimensions.
    ##    e. heatmap dimensions + label pix, dendro pix, scale.pix, determine final image dimensions.
    ## 2. Using 'dimension', which specifies height and width of the heatmap block directly.
    ##    a. dimensions=c(x,y) specified pixels to allot to heatmap width, height, respectively.
    ## 3. Both 'aspect' and 'dimensions' cannot be used at the same time.
    
    
    mat <- as.matrix(mat)  # ensure matrix 
    if (length(main)==0) main <- "Heat Map"
    device <- match.arg(device)
    cex.adj <- ifelse(device=="pdf", 0.7, 1)
    if (length(xaxt)==0) xaxt <- ""
    if (length(yaxt)==0) yaxt <- ""
    if (!(las %in% 1:2)) stop("'las' value may only be 1 (horizontal) or 2 (perpendicular)!\n")   # enforcing only las=1 (all labels horizontal) or las=2 (labels perpendicular to axis)
    
    cor.metrics <- c("pearson","spearman","kendall")
    dist.metrics <- c("euclidean","maximum","manhattan","canberra","binary","minkowski")
    if (metric %in% dist.metrics) {
        dist.fun <- dist
    } else if (metric %in% cor.metrics) {
        dist.fun <- distance
    } else {
        stop(paste("Unknown distance metric '",metric,"'!  Please use a metric from dist() or cor()\n",sep=""))
    }
    
    ## dendro plot consistency check
    if (is.null(Rowv)) Rowv <- ifelse(r.dend, TRUE, FALSE)	# dendrogram requires a reordering
    if (is.null(Colv)) Colv <- ifelse(c.dend, TRUE, FALSE)	# dendrogram requires a reordering
    mmin <- min(real(mat))
    mmax <- max(real(mat))
    
    ## names etc
    if (length(rownames(mat))==0) rownames(mat) <- 1:nrow(mat)
    if (length(colnames(mat))==0) colnames(mat) <- 1:ncol(mat)
    NR <- nrow(mat)
    NC <- ncol(mat)
    
    ## Testing data
#	aspect <- c(1,1); dendro.pix <- c(150,150); label.pix <- c(50,50); scale.pix <- 100; title.pix <- 40; ppa <- 20
#	mat <- structure(matrix(unlist(randu)[1:900], nrow=45, ncol=20), dimnames=list(paste("R",1:45,sep=""),paste("C",1:20,sep=""))); main <- "title"
    
    if (length(aspect)>0 & length(dimensions)>0) {
        stop("Can only specify one of 'aspect' or 'dimensions', not both!\n")
    } else if (length(aspect)>0) {
        ## aspect-driven dimensions
        ppa <- aspect[3]
        aspect <- aspect[1:2] / min(aspect[1:2])	# convert to c(1,x) or c(x,1); as long as the smallest value is 1 and the other is proportional
        x.px.hm <- NC * aspect[1] * ppa		# heatmap width in pixels
        y.px.hm <- NR * aspect[2] * ppa		# heatmap height in pixels
    } else if (length(dimensions)>0) {
        ## dimension-driven aspect ratio
        x.px.hm <- dimensions[1]			# heatmap width in pixels
        y.px.hm <- dimensions[2]			# heatmap height in pixels
        ppa <- min(dimensions/c(NC,NR))		# minimum-ppa estimate
    } else {
        stop("Must specify either 'aspect' or 'dimensions'!\n")
    }
    
    if (length(dendro.pix)==0) { 
        stop("'dendro.pix' must be specified!\n")
    } else if (length(dendro.pix)==1) { 
        dendro.pix <- c(dendro.pix,dendro.pix) 
    }
    
    if (length(label.pix)==0) { 
        stop("'label.pix' must be specified, even if NA!\n")
    } else if (length(label.pix)==1) { 
        label.pix <- c(label.pix,label.pix) 
    }
    if (xaxt=="n") label.pix[1] <- 1
    if (yaxt=="n") label.pix[2] <- 1
    
    tick.len <- max(c(ppa/2,5))  # axis tick length in pixels: half of ppa, or 5, whichever is larger
    
    if (is.na(label.pix[1])) {
        ## autodetect pixel width of COLUMN labels (works for most PNG plots, anyway)
        if (las == 2) {   # perpendicular x labels
            label.pix[1] <- tick.len*2 + calculate.mono.width(colnames(mat))  # tick.len*2 is the distance between the labels and the axis
        } else {          # horizontal x labels
            label.pix[1] <- 50   # get default 50 pixels
        }
    }
    if (is.na(label.pix[2])) {
        ## autodetect pixel width of ROW labels (works for most PNG plots, anyway)
        label.pix[2] <- tick.len*2 + calculate.mono.width(rownames(mat))  # tick.len*2 is the distance between the labels and the axis
    }
    
    null.mar <- c(0,0,0,0)
    y.dendro.mar <- c(0,1,0,0.35)
    x.dendro.mar <- c(0.35,0,1,0)
    x.px.den <- dendro.pix[2]	# number of x pixels added for *** Y (ROW) DENDROGRAM *** width
    y.px.den <- dendro.pix[1]	# number of y pixels added for *** X (COL) DENDROGRAM *** height
    x.px.lab <- ifelse(ylabs, max(c(label.pix[2],1)), 10)	# number of x pixels added for *** Y (ROW) AXIS LABELS *** width; minimum 1
    y.px.lab <- ifelse(xlabs, max(c(label.pix[1],1)), 10)	# number of y pixels added for *** X (COL) AXIS LABELS *** height; minimum 1
    px.scale <- ifelse(is.na(scale.pix), 100, scale.pix)		# number of x or y pixels added for color scale (depending on scale direction)
    y.px.title <- ifelse(is.null(main), title.pix, title.pix * length(unlist(strsplit(main,"\n"))))		# allowing for multi-line titles
    scale.margins <- c(0,2,0,5)
    if (device=="pdf") scale.margins[2] <- 1
    
    ## The 8 possible layout matrices:
    ## Where numeric values stand indicate: 1=title, 2=heatmap, 3=xlabs, 4=ylabs, 5=scale, 6/7=row.dend and/or col.dend
    
    ## No.1: no dendros, vertical scale
    if (!c.dend & !r.dend & !scale.horiz) {
        layout.mat <- matrix(c(1,4,0,1,2,3,1,5,0), nrow=3, ncol=3)
        map.axes <- c(1,2)
        heights.vec <- c(y.px.title, y.px.hm, y.px.lab)
        widths.vec <- c(x.px.lab, x.px.hm, px.scale)
        if (verbose) IM("Map 1")
    }
    ## No.2: no dendros, horizontal scale
    if (!c.dend & !r.dend & scale.horiz) {
        layout.mat <- matrix(c(1,4,0,0,1,2,3,5), nrow=4, ncol=2)
        map.axes <- c(1,2)
        heights.vec <- c(y.px.title, y.px.hm, y.px.lab, px.scale)
        widths.vec <- c(x.px.lab, x.px.hm)
        if (verbose) IM("Map 2")
    }
    ## No.3: col dendro only, vertical scale
    if (c.dend & !r.dend & !scale.horiz) {
        layout.mat <- matrix(c(1,0,4,0,1,6,2,3,1,0,5,0), nrow=4, ncol=3)
        map.axes <- c(1,2)
        heights.vec <- c(y.px.title, y.px.den, y.px.hm, y.px.lab)
        widths.vec <- c(x.px.lab, x.px.hm, px.scale)
        if (verbose) IM("Map 3")
    }
    ## No.4: col dendro only, horizontal scale
    if (c.dend & !r.dend & scale.horiz) {
        layout.mat <- matrix(c(1,6,2,3,5,1,0,4,0,0), nrow=5, ncol=2)
        map.axes <- c(1,2)
        heights.vec <- c(y.px.title, y.px.den, y.px.hm, y.px.lab, px.scale)
        widths.vec <- c(x.px.hm, x.px.lab)
        if (verbose) IM("Map 4")
    }
    ## No.5: row dendro only, vertical scale
    if (!c.dend & r.dend & !scale.horiz) {
        layout.mat <- matrix(c(1,6,0,1,2,3,1,4,0,1,5,0), nrow=3, ncol=4)
        map.axes <- c(1,4)
        heights.vec <- c(y.px.title, y.px.hm, y.px.lab)
        widths.vec <- c(x.px.den, x.px.hm, x.px.lab, px.scale)
        if (verbose) IM("Map 5")
    }
    ## No.6: row dendro only, horizontal scale
    if (!c.dend & r.dend & scale.horiz) {
        layout.mat <- matrix(c(1,6,0,0,1,2,3,5,1,4,0,0), nrow=4, ncol=3)
        map.axes <- c(1,4)
        heights.vec <- c(y.px.title, y.px.hm, y.px.lab, px.scale)
        widths.vec <- c(x.px.den, x.px.hm, x.px.lab)
        if (verbose) IM("Map 6")
    }
    ## No.7: both dendros, vertical scale
    if (c.dend & r.dend & !scale.horiz) {
        layout.mat <- matrix(c(1,0,6,0,1,7,2,3,1,0,4,0,1,0,5,0), nrow=4, ncol=4)
        map.axes <- c(1,4)
        heights.vec <- c(y.px.title, y.px.den, y.px.hm, y.px.lab)
        widths.vec <- c(x.px.den, x.px.hm, x.px.lab, px.scale)
        if (verbose) IM("Map 7")
    }
    ## No.8: both dendros, horizontal scale
    if (c.dend & r.dend & scale.horiz) {
        layout.mat <- matrix(c(1,0,6,0,0,1,7,2,3,5,1,0,4,0,0), nrow=5, ncol=3)
        map.axes <- c(1,4)
        heights.vec <- c(y.px.title, y.px.den, y.px.hm, y.px.lab, px.scale)
        widths.vec <- c(x.px.den, x.px.hm, x.px.lab)
        if (verbose) IM("Map 8")
    }
    
    ## Arrange row order
    if (is(Rowv, "hclust")) {
        hc.y <- Rowv
        Rowv <- TRUE
        dg.y <- as.dendrogram(hc.y)
        dg.lab <- dendrogram.labels(dg.y)
        row.ord <- hc.y$order <- match(dg.lab,rownames(mat))
    } else if (Rowv == TRUE) {
        if (verbose) IM("Clustering rows...\n")
        hc.y <- hclust(dist.fun(zerofy(mat), method=metric), method=linkage)
        dg.y <- as.dendrogram(hc.y)
        dg.lab <- raw.ord <- dendrogram.labels(dg.y)
        row.ord <- match(raw.ord,rownames(mat))
    } else {
        row.ord <- nrow(mat):1
    }
    if (length(row.optimize)>0) {
        opt.mode <- row.optimize[[1]]
        if (opt.mode == "KM") {
            row.ord <- km.hc.order(cutree(hc.y,k=row.optimize$k),mat,hc.y,reord=row.optimize$reord,reverse=row.optimize$reverse) # row.optimize should have at least: k, reord, reverse
        } else if (opt.mode == "HC") {
            ## INOPERABLE UNTIL DENDROGRAM REORDERING METHODS IN PLACE
#			row.ord <- reorder.hclust2(hc.y,mat,row.optimize$method)$order # row.optimize should have at least: method
        }
    }
    
    ## Arrange column order
    if (is(Colv, "hclust")) {
        hc.x <- Colv
        Colv <- TRUE
        dg.x <- as.dendrogram(hc.x)
        dg.lab <- dendrogram.labels(dg.x)
        col.ord <- hc.x$order <- match(dg.lab,colnames(mat))
    } else if (Colv) {
        if (verbose) IM("Clustering columns...\n")
        hc.x <- hclust(dist.fun(t(zerofy(mat)), method=metric), method=linkage)
        dg.x <- as.dendrogram(hc.x)
        dg.lab <- raw.ord <- dendrogram.labels(dg.x)
        col.ord <- match(raw.ord,colnames(mat))
    } else {
        col.ord <- 1:ncol(mat)
    }
    if (length(col.optimize)>0) {
        opt.mode <- col.optimize[[1]]
        if (opt.mode == "KM") {
            col.ord <- km.hc.order(cutree(hc.y,k=col.optimize$k),mat,reord=col.optimize$reord) # col.optimize should have at least: k, reord
        } else if (opt.mode == "HC") {
            message("Optimization mode 'HC' not yet available!")
            ## INOPERABLE UNTIL DENDROGRAM REORDERING METHODS IN PLACE
#			col.ord <- reorder.hclust2(hc.x,mat,col.optimize$method)$order # col.optimize should have at least: method
        }
    }

    ## check palette name, cluster metric, etc.
    if (length(palette)==0) {
        mr <- range(mat, na.rm=TRUE)
        if (mr[2] <= 0) {
            ## all negative
            palette <- "Greens"
            rev.pal <- TRUE
        } else if (mr[1] >= 0) {
            ## all positive
            palette <- "Reds"
            rev.pal <- FALSE
        } else {
            ## divergent, apparently
            palette <- "CKY"
            rev.pal <- FALSE
        }
    }
    
    scale.tick <- TRUE
    scale.col <- 1
    pm <- palette.mapping(mat, palette, rev.pal, col.limits, col.center, quant.cols, max.cols, max.qres, interpolate)	
    matrix.colors <- pm[[1]]
    scale.colors <- pm[[2]]
    scale.values <- pm[[3]]
    data.range <- pm[[4]]
    scale.range <- pm[[5]]
    
    if (device == "png") {
        antialias <- ifelse(antialias, "default", "none")
        pngtype <- ifelse(.Platform$OS.type == "windows", "windows", "quartz")
#		IM("H=",heights.vec)
#		IM("W=",widths.vec)
#		IM("H=",sum(heights.vec), ", W=",sum(widths.vec))
        if (!is.null(imgname)) png(imgname, height=sum(heights.vec), width=sum(widths.vec), type=pngtype)
    } else if (device == "pdf") {
#		IM("PDF with: ", sum(heights.vec)/ppi, sum(widths.vec)/ppi)
        if (!is.null(imgname)) pdf(imgname, height=sum(heights.vec)/ppi, width=sum(widths.vec)/ppi)
    }
    nf <- layout(layout.mat, heights=heights.vec, widths=widths.vec, respect=TRUE)
#	layout.show(nf)
	
    
    ### PLOT TITLE FIRST
    par(mar=null.mar, xaxs="i", yaxs="i")
    plot(1, 1, type="n", ann=FALSE, axes=FALSE)
    text(1, 1, labels=main, cex=1.5*cex*cex.adj, font=2)

    
    ### PLOT HEATMAP SECOND
    par(mar=null.mar, xaxs="i", yaxs="i")
    if (c.dend) {
#		plot.title <- ""
        cex.main <- 1	# not that it matters
    } else {
# 		plot.title <- ifelse (is.null(title), "Heatmap", title)
        cex.main <- ifelse (r.dend, 2, 1)
    }
#	image(t(mat[row.ord, col.ord]), col=colors2, xlab="", ylab="", axes=FALSE, main=plot.title, cex.main=cex.main)	
    
    imat <- 
        if (nrow(mat)>1) {
            t(mat[row.ord, col.ord, drop=FALSE])
        } else {
            t(mat[, col.ord, drop=FALSE])
        }
    
    if (any(is.na(imat))) {
        ## plot NA "background" first
        NA.mat <- imat
        NA.mat[!is.na(NA.mat)] <- 0
        NA.mat[is.na(NA.mat)] <- 1
        NA.mat[NA.mat==0] <- NA
        image(NA.mat, col=NA.col, xlab="", ylab="", axes=FALSE, main="")	
        add <- TRUE
    } else {
        add <- FALSE
    }
    # if (length(att.cols)+length(att.rows)>0) {   # attribute rows/cols were specified
		# core <- x   # initially
		# att.mat <- matrix(NA, NR, NC)
		# if (length(att.cols)>0) {
			# att.mat[,att.cols] <- x[,att.cols,drop=FALSE]
			# core[,att.cols] <- NA
		# }
		# if (length(att.rows)>0) {
			# att.mat[att.rows,] <- x[att.rows,,drop=FALSE]
			# core[att.rows,] <- NA
		# }
		# if (length(dim(core))==0) {  # no longer a matrix?
			# core <- t(as.matrix(core))
		# }
		# c.min <- min(core, na.rm=TRUE)
		# c.max <- max(core, na.rm=TRUE)
        # if (length(att.palette)==0) att.palette <- palette
        # att.levels <- length(sort(unique(c(att.mat)),na.last=NA))
        # if (att.levels==length(att.palette)) {
            # att.colors <- att.palette
        # } else {
            # att.colors <- palettizer(att.palette, n=att.levels, NULL, NULL, rev.pal)
        # }
        # image(1:NC, 1:NR, t(att.mat[NR:1,,drop=FALSE]), col=att.colors, xlab="", ylab="", axes=FALSE, add=add, main=title)	
        # add <- TRUE
    # }
    image(imat, col=matrix.colors, xlab="", ylab="", axes=FALSE, main="", add=add, cex.main=cex.main*cex.adj)	
	
    # plot gridlines
    if (grid.col != 0) {  # zero being the "invisible" color, so don't bother plotting...
        xSeq <- c(0, cumsum(rep(1/(ncol(mat)-1), ncol(mat))) )
        xGap <- xSeq[2]-xSeq[1]
        ySeq <- c(0, cumsum(rep(1/(nrow(mat)-1), nrow(mat))) )
        yGap <- ySeq[2]-ySeq[1]
        abline(v=xSeq-xGap/2, lty=grid.lty, col=grid.col)
        abline(h=ySeq-yGap/2, lty=grid.lty, col=grid.col)
    }
    
    ### PLOT X LABELS THIRD (if at all)
    if (xaxt=="n") {
	null.plot()
    } else {
	par(mar=null.mar, xaxs="i", yaxs="i")
	xmax <- x.px.hm
	ymax <- y.px.lab
	null.plot(xlim=c(0,xmax), ylim=c(0,ymax))
	if (col.names) {
            pre.x <- seq(0,xmax,length.out=NC+1)
            half <- (pre.x[2]-pre.x[1])/2
            x <- pre.x[1:NC]+half
            if (map.axes[1]==1) {  # bottom labels
                y <- ymax; y2 <- ymax-tick.len; y3 <- ymax-2*tick.len
            } else {  # top labels
                y <- 0; y2 <- tick.len; y3 <- 2*tick.len
            }
            if (xlabs) {
                segments(x[1],y, x[NC],y)   # x axis line
                for (i in 1:NC) segments(x[i],y, x[i],y2)  # ticks
#			if (las==0) {		 # parallel to axis (horizontal)
#				srt <- 0
#				adj <- ternary(map.axes[1]==1, c(0.5,0), c(0.5,1))
#			} else 
                if (las==1) { # horizontal
                    srt <- 0
                    adj <- ternary(map.axes[1]==1, c(0.5,1), c(0.5,0))
                } else if (las==2) { # perpendicular to axis (vertical)
                    srt <- 90
                    adj <- ternary(map.axes[1]==1, c(1,0.5), c(0,0.5))
#			} else if (las==3) { # vertical
#				srt <- 90
#				adj <- ternary(map.axes[1]==1, c(0.5,0), c(0.5,1))
                }
                text(x, rep(y3,length(x)), colnames(mat)[col.ord], srt=srt, adj=adj, cex=cex*cex.adj, family=family)
            }
	}
    }
    
    ### PLOT Y LABELS FOURTH (if at all)
    if (yaxt=="n") {
	null.plot()
    } else {
	par(mar=null.mar, xaxs="i", yaxs="i")
	xmax <- x.px.lab
	ymax <- y.px.hm
	null.plot(xlim=c(0,xmax), ylim=c(0,ymax))
	if (row.names) {
            if (map.axes[2]==2) {  # left-side labels
                x <- xmax; x2 <- xmax-tick.len; x3 <- xmax-2*tick.len
            } else {  # right-side labels
                x <- 0; x2 <- tick.len; x3 <- 2*tick.len
            }
            pre.y <- seq(0,ymax,length.out=NR+1)
            half <- (pre.y[2]-pre.y[1])/2
            y <- pre.y[1:NR]+half
            if (ylabs) {
                segments(x,y[1], x,y[NR])   # y axis line
                for (i in 1:NR) segments(x,y[i], x2,y[i])  # ticks
#			if (las==0) {		 # parallel to axis (vertical)
#				srt <- 90
#				adj <- ternary(map.axes[2]==2, c(1,0.3), c(0,0.3))
#			} else 
                if (las==1) { # horizontal
                    srt <- 0
                    adj <- ternary(map.axes[2]==2, c(1,0.3), c(0,0.3))
                } else if (las==2) { # perpendicular to axis (horizontal)
                    srt <- 0
                    adj <- ternary(map.axes[2]==2, c(1,0.3), c(0,0.3))
#			} else if (las==3) { # vertical
#				srt <- 90
#				adj <- ternary(map.axes[2]==2, c(1,0.3), c(0,0.3))
                }
                text(rep(x3,length(y)), y, rownames(mat)[row.ord], srt=srt, adj=adj, cex=cex*cex.adj, family=family)
            }
	}
    }
    
    ### PLOT COLOR SCALE FIFTH
    nticks <- scale.div+1
    color.levels <- scale.values
    prelabels <- seq(scale.range[1], scale.range[2], length.out=nticks)
    labelgap <- abs(prelabels[2] - prelabels[1])
    if (labelgap > 80) {		# width of scale divisions => number of digits to carry on labels
        ndig <- 0
    } else if (labelgap < 20) {
        ndig <- 2
    } else {
        ndig <- 1
    }
    
    if (scale.tick) {		# use this as indicator for skipping color scale flanking
        cseq <- seq(0,1,length.out=nticks)
        gradient <- color.levels
        clab <- round(prelabels,ndig)
    } else {
        cseq <- seq(0,1,length.out=nticks+2)
#		cseq2 <- c(sc.txt.y[1], cseq[2:12], sc.txt.y[2])
        flank <- rep(NA, max.cols*0.06)
        gradient <- c(flank,color.levels,flank)
        clab <- round(c(mmin,prelabels,mmax),ndig)
    }
    
    if (scale.term) {		# plot terminal values only = 2 ticks
        prelabels <- prelabels[c(1,nticks)]
        clab <- clab[c(1,nticks)]
        cseq <- c(0,1)
    }
    
    par(mar=scale.margins, xaxs="i", yaxs="i")
    if (is.na(scale.pix)) {
        par(mar=c(0,0,0,0))
        null.plot()
    } else if (scale.horiz) {
        err <- try(image(matrix(gradient,ncol=1), axes=FALSE, col=scale.colors, xlab="", ylab=""))   # originally had "col=colors", where was 'colors' defined?
        if (!is.null(err)) stop(paste("The 'scale.pix' value of",scale.pix,"was too small to plot color scale.  Please increase.\n"))
        axis(1, at=cseq, labels=clab, col=scale.col, las=las, tick=scale.tick, cex.axis=cex*cex.adj)
        if (!scale.tick) text(c(0,0), sc.txt.y, labels=c("Min","Max"), adj=c(0.5,0.5), cex=cex*cex.adj)
    } else {
        err <- try(image(matrix(gradient,nrow=1), axes=FALSE, col=scale.colors, xlab="", ylab=""))   # originally had "col=colors", where was 'colors' defined?
        if (!is.null(err)) stop(paste("The 'scale.pix' value of",scale.pix,"was too small to plot color scale.  Please increase.\n"))
        axis(4, at=cseq, labels=clab, col=scale.col, las=las, tick=scale.tick, cex.axis=cex*cex.adj)
        if (!scale.tick) text(c(0,0), sc.txt.y, labels=c("Min","Max"), adj=c(0.5,0.5), cex=cex*cex.adj)
    }
    
    
    ### PLOT DENDROGRAMS SIXTH (AND SEVENTH)
    if (c.dend && r.dend) {
        par(mar=y.dendro.mar)
        plot(dg.y, leaflab="none", yaxs="i", horiz=TRUE, axes=FALSE)	# Y-axis dendrogram plots FIRST
        par(mar=x.dendro.mar)
        plot(dg.x, leaflab="none", xaxs="i", horiz=FALSE, axes=FALSE)	# X-axis dendrogram plots SECOND
    } else if (c.dend) {
        par(mar=x.dendro.mar)
        plot(dg.x, leaflab="none", xaxs="i", horiz=FALSE, axes=FALSE)
    } else if (r.dend) {
        par(mar=y.dendro.mar)
        plot(dg.y, leaflab="none", yaxs="i", horiz=TRUE, axes=FALSE)
    }
    
    if (!is.null(imgname)) dev.off()
    
    ### Return
    if (Rowv & Colv) {
        invisible(list(hc.x,hc.y))
    } else if (Rowv) {
        invisible(hc.y)
    } else if (Colv) {
        invisible(hc.x)
    } else {
        ## no hc objects to return
    }
}


