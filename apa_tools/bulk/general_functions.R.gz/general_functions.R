

apa.names$general <- c(apa.names$general, "downcast")
downcast <- function(x, verbose=c(0,1,2)) { 
	
	## Attempts the following operations on a vector's storage mode:
	## Downcast Character to Complex, Numeric, or Logical.
	## Downcast Complex to Numeric or Logical.
	## Downcast Numeric to Logical.
	## Only returns downcast vector if there is no detectable loss of data; otherwise returns original.
	
	if (length(verbose)>1) verbose <- verbose[1]
	recastings <- list(character=c("complex","logical"), complex="numeric", numeric="logical")
	
	test <- function(v, m) {  
		## v = vector, m = new mode
		## Function to compare recast values to originals and test success of recasting
		## Designed to test ONLY these recastings: character->complex, character->logical, complex->numeric, numeric->logical
		##  - ANY OTHER RECASTING MAY FAIL THE TESTS, either obviously or otherwise...
		v2 <- suppressWarnings(as(v, m))
		if (mode(v)=="character") {
			if (m=="logical") {
				## character to logical: test for change in N unique values
				## recasting only succeeds for certain strings.
				okT <- sum(v2)==sum(v %in% c("TRUE","true","T"))
				okF <- sum(!v2)==sum(v %in% c("FALSE","false","F"))
				okN <- sum(is.na(v2))==sum(is.na(v))
				agree <- okT & okF & okN
				if (verbose>0) message(paste(mode(v),m,agree,":",okT,okF,okN))
			} else {  
				## character to complex: test for change in NA content
				## anything not recognizable as a number will become NA
				## however, NaNs are also picked up with is.na(), which will confuse things
				nav <- which(v=="NA")
				nav2 <- which(is.na(v2) & !is.nan(v2))
				agree <- length(nav)==length(nav2) & all(nav==nav2)
				if (verbose>0) message(paste(mode(v),m,agree,":",length(nav),length(nav2),all(nav==nav2)))
			}
		} else if (mode(v)=="complex") {
			## complex to numeric: test for loss of nonzero imaginary components
			i0 <- v2-v==0
			agree <- length(v)==length(v2) & all(i0)
			if (verbose>0) message(paste(mode(v),m,agree,":",length(v),length(v2),all(i0)))
		} else if (mode(v)=="numeric") { 
			## numeric to logical: test for binary-ness of numeric data
			## because any nonzero numeric will recast to TRUE, although only { 0 1 NA } are really "logical"
			agree <- all(v %in% c(0,1,NA))
			if (verbose>0) message(paste(mode(v),m,agree))
		}
		ifelse (agree, TRUE, FALSE)
	}
	
	recast <- function(v) {
		## v = vector
		## Function to test downcast options and return lowest successful storage mode
		m1 <- m2 <- mode(v)  # initialize recast mode as original mode
		## Test to see if v can be downcast 
		if (m1 == "character") {
			if (test(v, "logical")) {  # steepest downcast -- test this first
				m2 <- "logical"
			} else if (test(v, "complex")) {  # otherwise, might be some kind of number
				m2 <- "complex"
			}
		} else if (m1 == "complex") {  # may be real not imaginary
			if (test(v, "numeric")) m2 <- "numeric"
		} else if (m1 == "numeric") {  # may be recastable as logical (i.e. numeric but binary)
			if (test(v, "logical")) m2 <- "logical"
		} else if (m1 == "logical") {  # lowest-information storage mode; can't downcast further
			m2 <- "logical"
		}
		## Recasting only "downcasts" mode one level; may be able to go further if m2 is complex or numeric
		if (m1 != m2 & m2 %in% c("complex","numeric")) {
			## If m2 == "complex", then recast from character.  May be able to go to numeric.
			## If m2 == "numeric", then recast from complex.  May be able to go to logical.
			if (test(v, recastings[[m2]])) m2 <- recastings[[m2]]  # additional downcast was successful
		}
		m2
	}
	
	y <- x
	
	if (is.list(x)) {  # list/data.frame
		for (i in 1:length(x)) {
			new.mode <- recast(x[[i]])
			if (new.mode != mode(x[[i]])) y[[i]] <- as(x[[i]], new.mode)
			if (verbose>1) message("Downcast column ",i," from ",mode(x[[i]])," to ",new.mode)
		}
	} else if (is.atomic(x)) {  # vector/matrix/array
		new.mode <- recast(x)
		if (new.mode != mode(x)) {
			y <- as(x, new.mode)
			if (verbose>1) message("Downcast from ",mode(x)," to ",new.mode)
		}
	} else {
		warn("Can only downcast 'list' and 'atomic' objects!\n")
	}
	
	y
}


apa.names$general <- c(apa.names$general, "remode")
remode <- function(x,m) {
    
    ## changes storage mode on a vector or matrix

    if (length(dim(x))>0) x <- as.matrix(x)  # may be pulled from a dataframe
    mode(x) <- m
    x
}


apa.names$general <- c(apa.names$general, "deattribute")
deattribute <- function(x, rmv=NULL, grep=FALSE) {
    
    ## removes attributes on an object
    ## 'rmv' provides a list of attribute names to remove (default: all)
    ## 'grep' will grep strings in 'rmv' instead of exact-matching them into attribute names
    
    if (length(rmv)==0) {
        attributes(x) <- NULL
    } else {
        if (grep) {
            w.rmv <- mgrep(rmv,names(attributes(x)),value=TRUE)
        } else {
            w.rmv <- which(names(attributes(x)) %in% rmv)
        }
        for (i in w.rmv) attributes(x)[i] <- NULL
    }
    x
}


apa.names$hacks <- c(apa.names$hacks, "factor2")
factor2 <- function(vec, ord) { 
    
    ## Converts to a factor with correct ordering, i.e. the order presented in the vector
    
    vec2 <- vec
    levs <- unique(vec[!is.na(vec)])   # preserves order of appearance
    LL <- length(levs)
    LV <- length(vec)
    flevs <- 1:LL
    whichlev <- matrix(0, nrow=LL, ncol=LV)
    for (i in 1:LL) whichlev[i,falsify(vec2==levs[i])] <- i
    whichlev[1,is.na(vec)] <- NA
    fac <- as.factor(colSums(whichlev))
    levels(fac) <- levs
    return(fac)
}


apa.names$general <- c(apa.names$general, "show.factor")
show.factor <- function(x, ...) {
    
    ## displays character and numeric versions of factor
    ## '...' are optional supplementary vectors to display (e.g. name vector that factor was derived from)
    ## 
    ## example: mat.fac <- factor2(sub("_[0-9]+$","",colnames(mat)))
    ##          show.factor(mat.fac)
    ##          show.factor(mat.fac, colnames=colnames(mat))
    
    y <- list(...)
    Y <- length(y)
    z <- data.frame(Labels=as.character(x), Levels=as.numeric(x))
    if (Y>0) {
        if (length(names(y))==0) names(y) <- paste0("V",1:Y)
        for (i in 1:length(y)) z <- cbind(z, y[i])
    }
    z
}


apa.names$general <- c(apa.names$general, "defactor")
defactor <- function(df, verbose=FALSE) { 
	
	## Converts factors to original values in a dataframe
	
	types <- c("logical","complex","numeric","character")  # no methods for binary, but your df probably doesn't have any anyway.
	if (all(sapply(df, is.list))) {    # mangled "data frame", as per t(sapply(data.frame)) which sapply cannot figure out.  But you should have used do.call(rbind,lapply(data.frame))
		new <- new.list(names(df))
		for (i in 1:ncol(df)) {
			new[[i]] <- unlist(df[,i])
		}
		df <- as.data.frame(new)
	} else {
		for (i in which(sapply(df, is.list))) {    # mangled "data frame", as per t(sapply(data.frame)) which sapply cannot figure out.  But you should have used do.call(rbind,lapply(data.frame))
			df[,i] <- unlist(df[,i])
		}
	}
	for (i in which(sapply(df, is.factor))) {
		levs <- levels(df[,i])
		vec <- as.vector(df[,i])
		for (type in types) {
			as.type <- levs
			suppressWarnings( mode(as.type) <- type )
			if (all(falsify(levs == as.type))) {	# matched datatype
				if (verbose) { IM("Column",i,"is",type) }
				df[,i] <- as(vec,type)
				break
			} else {
#				if (verbose) { IM("Column",i,"is not",type) }
			}
		}
		if (verbose) { if (is.factor(df[,i])) { IM("Failed to defactor column",i) } }
	}
	return(df)
}


apa.names$general <- c(apa.names$general, "centered.window")
centered.window <- function(x,y,width) { 
	
	start <- min(x,y)
	end <- max(x,y)
	mid <- start+(end-start+1)/2
	c(mid-width/2,mid+width/2-1)
}


apa.names$general <- c(apa.names$general, "chrom.ord")
chrom.ord <- function(x) {
	
	## 'x' is a list of chromosome names
	## returns the ordered list, the way I typically order things
	
	y <- data.frame(BEFORE=x,AFTER=sub("^chr","",x),SET="",RANK=0)
	
	## classify
	suppressWarnings(y[!is.na(as.numeric(y[,2])) & !grepl("_",y[,2]),3] <- "nums")  # numeric chromosomes
	suppressWarnings(y[is.na(as.numeric(y[,2])) & !grepl("_",y[,2]),3]  <- "alps")  # alpha chromosomes
	odds <- grep("_",y[,2])                                    # randoms, or other things with underscores
	y[odds[grepl("^[0-9]",y[odds,2])],3] <- "odds.n"           # randoms associated with numerics
	y[odds[!grepl("^[0-9]",y[odds,2])],3] <- "odds.c"          # randoms NOT associated with numerics
	
	## rank
	offset <- 0
	w <- which(y[,3]=="nums")
	if (length(w)>0) y[w[order(as.numeric(y[w,2]))],4] <- 1:length(w)+offset
	offset <- offset + length(w)
	
	w <- which(y[,3]=="alps")
	if (length(w)>0) y[w[order(y[w,2])],4] <- 1:length(w)+offset
	offset <- offset + length(w)
	
	w <- which(y[,3]=="odds.n")
	if (length(w)>0) y[w[order(as.numeric(sub("_.*$","",y[w,2])), sub("^[^_]+_","",y[w,2]))],4] <- 1:length(w)+offset
	offset <- offset + length(w)
	
	w <- which(y[,3]=="odds.c")
	if (length(w)>0) y[w[order(y[w,2])],4] <- 1:length(w)+offset
	offset <- offset + length(w)
	
	y[order(y[,4]),1]
}


apa.names$general <- c(apa.names$general, "binify")
binify <- function(vec, bins, fun=mean, na.rm=FALSE, drop.short=FALSE, distribute=c("first","last","random","drop")) {
	
	## takes a vector and bins the values into N bins, specified by 'bins'
	## "fun" is the actual function (NOT NAME) used to evaluate bins, e.g. sum, mean, median, sd, etc
	## "na.rm" like it is in other functions
	## "drop.short=T" returns 'NA' for any vector with fewer than 'bins' values
	## "distribute" can be one of c("first","last","random") indicating how leftover positions should be distributed among bins
	
	distribute <- match.arg(distribute)
	L <- length(vec)
	binned <- rep(0, bins)
	if (L >= bins) {   		# long enough to bin
		span <- trunc(L/bins)		# base width per bin
		remainder <- L-span*bins	# leftover positions @ base width
		widths <- rep(span,bins)	# bin width vector
		if (remainder > 0) {
			if (distribute=="first") {
				alloc <- 1:remainder
			} else if (distribute=="last") {
				alloc <- (bins-remainder+1):bins
			} else if (distribute=="random") {
				alloc <- sample(1:bins, remainder)
			} else if (distribute=="drop") {
				alloc <- NULL
			}
#			IM(span, remainder, ':', widths, ':', alloc)
			widths[alloc] <- widths[alloc]+1  # distribute leftovers to first 'remainder' bins
#			IM(widths)
		}
		end <- 0
		for (i in 1:bins) {
			start <- end + 1
			end <- end + widths[i]
			binned[i] <- fun(vec[start:end], na.rm=na.rm)
		}
	} else if (drop.short) {	# too short; drop
		binned <- rep(NA,bins)
	} else {				# too short, but binify it anyway (stretch vector to # bins)
		span <- trunc(bins/L)		# how many bins each position must stretch over (base value)
		remainder <- bins-span*L	# leftover positions need to be placed
		posits <- rep(1:L,each=span)		# vector indicating which bins each position is stretched over
		if (remainder > 0) {
			if (distribute=="first") {
				alloc <- 1:remainder
			} else if (distribute=="last") {
				alloc <- (L-remainder+1):L
			} else if (distribute=="random") {
				alloc <- sample(1:L, remainder)
			}
#			IM(span, remainder, ':', posits, ':', alloc)
			posits <- sort(c(posits, alloc))  # add leftover positions; resort: should now have length == bins
#			IM(posits)
		}
		for (i in 1:bins) {
			binned[i] <- vec[posits[i]]	  # no function applied because no multiple values to summarize
		}
	}
	return(binned)
}



apa.names$general <- c(apa.names$general, "rescale")
rescale <- function(x, to, from=NULL, na.rm=FALSE) {
    
    ## rescales values found in from to values from to
    ## intended so that from[1] <= {all x} <= from[2]; and to is derived from from (in some other scale, e.g.)
    ## the algorithm then finds the relative position of each member of x in from and returns the corresponding relative value from to
    
	if (length(to) == 1) stop("'to' must have >= 2 entries!\n")
	if (length(from) == 1) stop("'from', if specified, must have >= 2 entries!\n")
	
	if (length(from) == 0) {
		if (length(x) == 1) {
			stop("Must specify 'from' if rescaling a single value!\n")
		} else {
			from <- range(x, na.rm=TRUE)  # always TRUE, else may not get a range
		}
	}
	if (length(from) == 2) {  # range
#		if (length(x) == 1) {
			y <- percentify(x, range=from, na.rm=na.rm)
#		} else {
#			y <- percentify(x, range=TRUE, na.rm=na.rm)
#		}
		z <- y * diff(to) + to[1]
	} else {   # distribution
		z <- sapply(x, find.quantile, from)
		z[is.infinite(z)] <- NA
		z[!is.na(z)] <- quantile(to, z[!is.na(z)])
	}
	return(z)
}


apa.names$general <- c(apa.names$general, "chase")
chase <- function (start, vec, value, reverse=FALSE) {
	
	## Finds end position of an unchanging run of values in a vector (assuming it starts in such a run).
	## Initialize at 'start' in 'vec' having value 'value'; finds end of unbroken run of 'value'.
	## "reverse=T" makes the search run backwards instead of forwards.
	
	others <- which(vec != value)
	if (start %in% others) {		# start position does not have the desired value!
		return(start)
	} else if (start > 1 & start < length(vec)) {
		if (vec[(start-1)] != value & vec[(start+1)] != value) {	# non-terminal start which is not in a run!  Nowhere to go.
			return(start)
		}
	}
	if (reverse) {
		flank <- others[which(others < start)]
		return(flank[length(flank)] + 1)
	} else {
		flank <- others[which(others > start)]
		if (length(flank) == 0) {	# ran to the end
			return(length(vec))
		} else {
			return(flank[1] - 1)
		}
	}
}


apa.names$general <- c(apa.names$general, "find.runs")
find.runs <- function(vec, terminal=TRUE, index=TRUE) {
	
	## Returns a list of index ranges (start-end) where contiguous runs of a identical numbers occur in the input vector.
	## Names of the ranges indicate the values for those indexes.
	## 'terminal' returns only the interval endpoints.
	## 'index' indicates whether to return runs as indices (TRUE) or as input values (FALSE)
     
	## difference positions reported by diff() are right-inclusive ONLY.  Take this into account if making changes.
    
    L <- length(vec)
    if (length(unique(vec)) == 1) {
        runs <- vector("list", length=1)
        names(runs) <- vec[1]
        if (terminal) {
            runs[[1]] <- c(1,L)
        } else {
            runs[[1]] <- 1:L
        }
    } else {
        end <- ifelse(falsify(vec[(L-1)] == vec[L]), 1, 0)
        d <- c(diff(vec), end)   # cap runs of 2 or more with a 1 (or, singleton final element gets 0)
        x <- which(d != 0)
        X <- length(x)
        runs <- vector("list", length=X+1)
        names(runs) <- c(vec[x], vec[L])
        for (i in 1:X) {
            if (i == 1) {	               # first entry
                if (terminal) {
                    runs[[i]] <- c(1,x[i])             # must run to beginning of parent vector
                } else {
                    runs[[i]] <- 1:x[i]
                }
            } else if (i == X) {	     # last entry
                if (terminal) {
                    runs[[i]] <- c(x[i-1]+1,x[i])      # add run to the left
                } else {
                    runs[[i]] <- (x[i-1]+1):x[i]
                }
            } else {			          # non-terminal entry
                if (terminal) {
                    runs[[i]] <- c(x[i-1]+1,x[i])
                } else {
                    runs[[i]] <- (x[i-1]+1):x[i]
                }
            }
        }
        if (end == 0) {                    # singleton final index to account for
            if (terminal) {
                runs[[(i+1)]] <- c(L,L)
            } else {
                runs[[(i+1)]] <- L
                runs[[(i+1)]] <- L
            }
            names(runs)[(i+1)] <- vec[L]
        }
        if (length(runs[[X+1]])==0) runs[[X+1]] <- NULL   # remove
    }
    if (index) {
        runs
    } else {
        lapply(runs, FUN=function(x){vec[x]})
    }
}


apa.names$general <- c(apa.names$general, "find.runs2")
find.runs2 <- function(vec, terminal=TRUE, index=TRUE) {
	
	## Returns a list of index ranges (start-end) where contiguous runs of a identical values occur in the input vector.
	## Names of the ranges indicate the values for those indexes.
	## 'terminal' returns only the interval endpoints.
	## 'index' indicates whether to return runs as indices (TRUE) or as values at those indices (FALSE)
     
	## difference positions reported by diff() are for distances to the RIGHT of the ith position.  Take this into account if making changes.
     
	L <- length(vec)
	if (length(unique(vec)) == 1) {
		runs <- vector("list", length=1)
		if (terminal) {
			runs[[1]] <- c(1,L)
		} else {
			runs[[1]] <- 1:L
		}
	} else {
		u <- sort(unique(vec),na.last=TRUE)
		runs.u <- lapply(u, function(i){
			if (is.na(i)) {
				w <- which(is.na(vec))
			} else {
				w <- which(vec==i)
			}
			brk <- which(diff(w)!=1)
			if (length(brk)==0) {
				if (length(w)==1) {
					list(c(w,w))
				} else {
					list(range(w))
				}
			} else {
				tmp <- new.list(1:(length(brk)+1))
				for (j in 1:length(brk)) {
					init <- ifelse(j==1,1,brk[j-1]+1)
					tmp[[j]] <- c(w[init], w[brk[j]])
				}
				tmp[[j+1]] <- c(w[brk[j]+1], w[length(w)])
				tmp
			}
		})
		runs <- new.list(rep(u,times=sapply(runs.u,length)))
		f <- 0
		for (n in 1:length(u)) {
			i <- f + 1
			f <- f + length(runs.u[[n]])
			runs[i:f] <- runs.u[[n]]
		}
		runs <- runs[order(unlist(slice.list(runs,1)))]
		if (!terminal) runs <- lapply(runs, function(x) x[1]:x[2] )
	}	  
    if (index) {
		runs
	} else {
		lapply(runs, FUN=function(x){vec[x]})
	}
}


apa.names$general <- c(apa.names$general, "reorder.matrix")
reorder.matrix <- function(mat, alt=NULL, metric="euclidean", linkage="average", clusters=NULL, col.ord=TRUE) {
    
    ## Reorders a matrix by clustering rows and columns.
    ## 'clusters' is a list with N elements denoting clusters; each element contains row indices
    ##   using 'clusters' will focus reordering on the clusters instead of using the whole matrix
    ## 'col.ord' passed to internal function 'get.order'
    ## if 'alt' is specified, matrix gets reordered using clustering order from 'alt', NOT 'mat'    *** 'alt' option not yet ready to go
    
    if (!is.matrix(mat)) { stop("Object must be a matrix!\n") }
    if (!is.null(clusters) & nrow(mat)!=ncol(mat)) { stop("Matrix must be square to use 'clusters'!\n") }
    if (!is.null(alt)) { 
        if (nrow(mat) == nrow(alt) && ncol(mat) == ncol(alt)) {
            alt.dim <- 3
        } else if (nrow(mat) == nrow(alt)) {
            alt.dim <- 1
        } else if (ncol(mat) == ncol(alt)) {
            alt.dim <- 2
        } else {
            stop("No corresponding dimensions between 'alt' and 'mat'!  Cannot use 'alt' for ordering.\n")
        }
    }
	
    cor.metrics <- c("pearson","spearman","kendall")
    dist.metrics <- c("euclidean","maximum","manhattan","canberra","binary","minkowski")
    distance.metrics <- c("pearson.dist","spearman.dist","kendall.dist")
    ## Test main metric
    if (metric %in% cor.metrics) {
        is.corr <- TRUE; is.dist <- FALSE; is.distance <- FALSE
    } else if (metric %in% dist.metrics) {
        is.corr <- FALSE; is.dist <- TRUE; is.distance <- FALSE
    } else if (metric %in% distance.metrics) {
        dmetric <- sub(".dist$","",metric)
        is.corr <- FALSE; is.dist <- FALSE; is.distance <- TRUE
    } else {
        stop(paste("'",metric,"' is not a recognized correlation or distance metric!\n",sep=""))
    }
    
    get.order <- function(obj, ord.col=col.ord) {      # gets most stuff from outside namespace
        if (is.corr) {
            dist.row <- as.dist(cor(t(obj), method=metric))
            if (ord.col) dist.col <- as.dist(cor(obj, method=metric))
        } else if (is.dist) {
            dist.row <- dist(obj, method=metric)
            if (ord.col) dist.col <- dist(t(obj), method=metric)
        } else if (is.distance) {
            dist.row <- distance(obj, method=dmetric)
            if (ord.col) dist.col <- distance(t(obj), method=dmetric)
        }
        hc.r <- hclust(dist.row, method=linkage)
        if (ord.col) { 
            hc.c <- hclust(dist.col, method=linkage) 
            return( list(ROW=hc.r$order,COL=hc.c$order) )
        } else {
            return(hc.r$order)
        }
    }
    
    if (is.null(clusters)) {
		if (is.null(alt)) {
			ords <- get.order(mat)
		} else {
			ords <- get.order(alt)
		}
		if (col.ord) {
			return(mat[ords$ROW,ords$COL])
		} else {
			return(mat[ords,ords])
		}
	} else {
        N <- length(clusters)
        ## get between-clusters order
        pattern <- breakout(clusters, reverse=TRUE)
		pattern[,1] <- as.numeric(as.factor(pattern[,1]))
        mode(pattern) <- "numeric"
        pattern <- pattern[order(pattern[,2]),]

        means1 <- aggregate(mat, by=list(pattern[,1]), mean)
        rownames(means1) <- means1[,1]; means1 <- means1[,-1]
        means2 <- aggregate(t(means1), by=list(pattern[,1]), mean)
        rownames(means2) <- means2[,1]; means2 <- means2[,-1]
        ord.between <- get.order(means2,ord.col=FALSE)
        ## get within-clusters order
        ord.within <- clusters
        for (i in 1:N) {
            clust.mat <- mat[clusters[[i]],clusters[[i]]]
			ord.within[[i]] <- clusters[[i]]
			if (length(clusters[[i]])>1) ord.within[[i]] <- clusters[[i]][get.order(clust.mat,ord.col=FALSE)]
        }
        ## order matrix
        final.ord <- unlist(ord.within[ord.between])
        return(mat[final.ord,final.ord])
    }
}


apa.names$general <- c(apa.names$general, "aggregate.cols")
aggregate.cols <- function(obj, by, func, na.rm=FALSE) {
    
    ## Like aggregate() but works on columns not rows
    
    if (class(obj)=="data.frame") obj <- as.matrix(obj)
    mode(obj) <- "numeric"  # avoid integer overflows
    fname <- deparse(substitute(func))
    NC <- ncol(obj)
    if (length(by)==0) {
        stop("'by' has length 0!\n")
    } else {
        for (i in 1:length(by)) {
            if (length(by[[i]]) != NC) stop("'by' element",i,"has length != ncol(obj)!\n")
        }
    }
    B <- length(by)
    if (length(names(by))==0) names(by) <- paste("Factor",1:B,sep="")
    by.mat <-  matrix(0, B, NC)
    for (i in 1:B) by.mat[i,] <- as.character(by[[i]])
    agg.grps <- apply(by.mat, 2, paste, collapse="-")
    ugrps <- unique(agg.grps)
    NG <- length(ugrps)
    output <- matrix(NA, nrow(obj), NG, F, list(rownames(obj),ugrps))
    for (i in 1:NG) {
        x <- which(agg.grps==ugrps[i])
        if (length(x)>1) {
            output[,i] <- switch(
                fname,
                "mean"=rowMeans(obj[,x], na.rm=na.rm),
                "median"=rowMedians(obj[,x], na.rm=na.rm),
                "min"=rowMin(obj[,x], na.rm=na.rm),
                "max"=rowMax(obj[,x], na.rm=na.rm),
                "sd"=rowSDs(obj[,x], na.rm=na.rm),
                "CV"=rowCVs(obj[,x], na.rm=na.rm),
                apply(obj[,x], 1, func, na.rm=na.rm)
            )
        } else {
            output[,i] <- obj[,x]
        }
    }
    output
}


apa.names$general <- c(apa.names$general, "detable")
detable <- function(obj, interpolate=FALSE) { 
	
	## Reverses 'table' function, i.e. takes a table object or equivalent matrix (see below) and reverts it to the original vector
	## 'interpolate=T' not yet ready : checks for and corrects 
	## INPUT CAN BE: 
	## 1. The output of a 'table' call or something equivalent (named numeric vector),
	## 2. 1-col matrix/df: col 1 = values; rownames = names
	## 3. 2-col matrix/df: col 1 = names; col 2 = values
	
	if (is(obj, "table")) obj <- as.matrix(obj)	# convert real table() output to matrix
	
	if (is.nlv(obj)) {
		
		temp <- vector("list", length=length(obj))
		for (i in 1:length(temp)) temp[[i]] <- rep(names(obj)[i], obj[i])
		output <- unlist(temp)
		
		if (interpolate) {
			x <- sort(as.numeric(names(obj)))
			y <- x[1]:x[length(x)]
			extra <- length(y) > length(x)
			if (extra > 0) output <- c(output, y[which(!y %in% x)])	# gaps in x
		}
		
	} else {	# df or matrix, hopefully
		
		if (ncol(obj) == 1) {
			if (is.null(rownames(obj))) stop("1-column object must have rownames!\n")
			labels <- rownames(obj)
			data <- obj
		} else if (ncol(obj) == 2) {
			labels <- obj[,1]
			data <- obj[,2]
		} else {
			stop("Cannot take objects with > 2 columns!\n")
		}
		
		temp <- vector("list", length=nrow(obj))
		for (i in 1:length(temp)) temp[[i]] <- rep(labels[i], data[i])
		output <- unlist(temp)
		
#		if (interpolate) {
#			x <- sort(as.numeric(labels))
#			y <- x[1]:x[length(x)]
#			extra <- length(y) > length(x)
#			if (extra > 0) output <- c(output, y[which(!(y %in% x))])	# gaps in x
#		}
	}
	
	return(output)
}


apa.names$general <- c(apa.names$general, "merge.table.list")
merge.table.list <- function(tables, sort=FALSE, expand=FALSE) { 
    
    ## merge.table.list takes a list made of outputs of the table() function, and merges them into master table.
    ## each element in the 'tables' is the output of a single table() call.
    ## names(tables) become the rownames; colnames are taken from the union of all table names (each element of 'tables').
    ## if tabulated data is numeric or (single-char) alphabetical, 'expand=T' will ensure one column for each possible value within the observed range
    
    if (!is.list(tables)) stop("Input must be a list!\n")
    
    T <- length(tables)
    table.types <- table.nrows <- new.vector(names(tables))
    table.rownames <- table.colnames <- new.list(names(tables))
    for (i in 1:T) {
        if (length(tables[[i]])==0) {
            table.nrows[i] <- 0
        } else if (class(tables[[i]]) %in% c("matrix","data.frame")) {
            table.types[i] <- "matrix"
            table.nrows[i] <- nrow(tables[[i]])
            table.rownames[[i]] <- paste0(names(tables)[i],".",rownames(tables[[i]]))
            table.colnames[[i]] <- colnames(tables[[i]])
        } else {  # assuming table or named vector
            table.types[i] <- "vector"
            table.nrows[i] <- 1
            table.rownames[[i]] <- names(tables)[i]
            table.colnames[[i]] <- names(tables[[i]])
        }
    }
    columns <- unique(unlist(table.colnames))
    if (sort) columns <- sort(columns)
    
    if (length(columns)==0) {
        warning("Failed to get names for frequencies!\n")
        return(c())
    } else {
        master <- matrix(data=0, nrow=sum(table.nrows), ncol=length(columns), F, list(unlist(table.rownames),columns))
        
        k <- 0
        for (i in 1:T) {
            if (table.nrows[i]>0) {
                cols <- match(table.colnames[[i]], colnames(master))
                if (table.types[i]=="matrix") {
                    master[(k+1):(k+table.nrows[i]),cols] <- as.matrix(tables[[i]])
                } else {
                    master[(k+1):(k+table.nrows[i]),cols] <- as.vector(tables[[i]])
                }
                k <- k + table.nrows[i]
            }
        }
        
        if (sum(is.na(suppressWarnings(as.numeric(colnames(master)))))==0) {
            ## 'master' has numeric colnames, apparently
            master <- master[,order(as.numeric(colnames(master))),drop=FALSE]
            if (expand) {
                ancm <- as.numeric(colnames(master))
                col.range <- min(ancm):max(ancm)
                master <- master[,match(col.range,ancm),drop=FALSE]
                colnames(master) <- col.range
            }
        } else if (expand) {
            ## non-numeric column expansion
            if (all(colnames(master) %in% LETTERS)) {
                cml <- LETTERS[min(match(colnames(master),LETTERS)):max(match(colnames(master),LETTERS))]
                master <- master[,match(cml,colnames(master)),drop=FALSE]
                colnames(master) <- cml
            } else if (all(colnames(master) %in% letters)) {
                cml <- letters[min(match(colnames(master),letters)):max(match(colnames(master),letters))]
                master <- master[,match(cml,colnames(master)),drop=FALSE]
                colnames(master) <- cml
            }
        }
        
        master[is.na(master)] <- 0
        return(master)
    }
}


apa.names$general <- c(apa.names$general, "table2histo")
table2histo <- function(x, expand=FALSE) { 
    
    ## converts a vector (or table of a vector) into a 2-col histogram object (matrix if 'x' is numeric; data.frame if otherwise)
    ## 'expand' only meaningful if 'x' is numeric or (single-letter) alphabetical: 
    ##   'expand=T' ensures that all values from min(x) to max(x) get a row in the output matrix; 'expand=F' only returns rows for existing values
    
    num <- is(x,"numeric")
    if (!is(x,"table")) x <- table(x)
    
    if (num) {
        h <- cbind(Value=as.numeric(names(x)), Times=x)
    } else {
        h <- data.frame(Value=names(x), Times=x)
    }
    
    if (expand) {
        if (num) {
            h1range <- min(h[,1]):max(h[,1])
            h <- h[match(h1range,h[,1]),]
            h[,1] <- h1range
            h[is.na(h[,2]),2] <- 0
        } else if (all(x %in% LETTERS)) {
            h1range <- LETTERS[min(match(x,LETTERS)):max(match(x,LETTERS))]
            h <- h[match(h1range,h[,1]),]
            h[,1] <- h1range
            h[is.na(h[,2]),2] <- 0
        } else if (all(x %in% letters)) {
            h1range <- letters[min(match(x,letters)):max(match(x,letters))]
            h <- h[match(h1range,h[,1]),]
            h[,1] <- h1range
            h[is.na(h[,2]),2] <- 0
        }
    }
    rownames(h) <- NULL
    h
}


apa.names$general <- c(apa.names$general, "tally.combinations")
tally.combinations <- function(mat, delim="+", sort.names=FALSE, allcombo=FALSE, subcombo=FALSE) { 
	
	## example usage:
	## input a binary matrix where rows are peaks and columns are motifs; cells are 1/0 (or T/F) for motif presence
	## returns a table of all motif combinations per peak and how many peaks had each combo
	## 'delim' specifies the delimiter to use when concatenating motif names into combo names
	## "sort.names=T" will sort columns or 'mat' so they are in alphabetical order, so that motif names in combos will also be in alphabetical order
	## "allcombo=T" means that all possible motif combinations are enumerated, whether or not any peaks with that combo ocurred
	## "subcombo=T" will assign each peak to all possible combinations of motifs found in that peak:
	##   For instance, peak X has motifs A, B, C.  subcombo=F adds 1 to "A+B+C".  subcombo=T adds 1 to "A", "B", "C", "A+B", "A+C", "B+C", and "A+B+C"
	## If subcombo=T and allcombo=F: all combos in all peaks will be discovered as though subcombo=F; during tallying, only already-discovered subcombos will get counts:
	##   For instance, peak X is as above, and peak Y has only A, B.  Peak X will then count to "A+B+C" and also "A+B", since "A+B" is known from peak Y.
	## If subcombo=F and allcombo=T: all possible combos will be represented, but each peaks only counts once, e.g. peak X only counts to "A+B+C"
	
	if (is.data.frame(mat)) mat <- as.matrix(mat)
	if (!is.matrix(mat)) stop("'mat' must be a matrix!\n")
	if (mode(mat)=="numeric") mode(mat) <- "logical"
	
	N <- ncol(mat)
	motif.names <- colnames(mat)
	if (N==0) stop("'mat' must have column names!\n")
	
	if (sort.names) mat <- mat[,order(colnames(mat))]
	
	umat <- unique(mat)
	mat.index <- rowSums(t( t(mat)*2^(0:(N-1)) ))   # binary index values per OBSERVED combination
	unq.index <- rowSums(t( t(umat)*2^(0:(N-1)) ))  # unique combo indexes
	unq.names <- apply(umat, 1, function(x){ paste(motif.names[as.logical(x)],collapse=delim) })  # unique combo names
	
	if (allcombo | subcombo) {
		IM("Generating combinations...")
		combo.PA <- permn2(0:1, N, replacement=TRUE)
		combo.index <- rowSums(t( t(combo.PA)*2^(0:(N-1)) ))  # binary index values per POSSIBLE combination
		combo.names <- apply(combo.PA, 1, function(x){ paste(motif.names[as.logical(x)],collapse=delim) })  # names per POSSIBLE combination
	} else {
		combo.index <- unq.index
		combo.names <- unq.names
	}
	combo.tally <- rep(0, length(combo.index))
	
	if (subcombo) {
		IM("Sub-indexing...")
		sub.index <- apply(mat, 1, function(x){ unique(rowSums(t( t(permn2(0:1,sum(x),replace=TRUE))*2^c(0:(N-1))[x] ))) })  # all possible subcombos per row // unique() due to bug in permn2
		for (i in 1:length(sub.index)) {
			w <- match(sub.index[[i]],combo.index)
			combo.tally[w] <- combo.tally[w] + 1
		}
		IM("Filtering...")
		if (!allcombo) {
			w <- match(unq.index,combo.index)
			combo.tally <- combo.tally[w]  # filter out novel subcombos
			combo.names <- combo.names[w]
		}
	} else {
		mat.tally <- table(mat.index)
		combo.tally[match(names(mat.tally),combo.index)] <- mat.tally
	}
	
	rownameless(data.frame(COMBO=combo.names,N=combo.tally,stringsAsFactors=FALSE))
}


apa.names$general <- c(apa.names$general, "mat.split")
mat.split <- function(x, f, bycol=FALSE, sort=TRUE, delim=":") {
    
    ## like 'split', but operates on rows/cols of matrices/dataframes
    ## 'bycol' splits by columns instead of rows
    ## short 'f' vector will get recycled, if it can be recycled evenly
    ## 'sort' will sort output list by name
    ## 'delim' is a delimiter (for the concatenated values that make up element names) when 'f' is a list with length > 1
    
    NR <- nrow(x)
    NC <- ncol(x)
    if (is.list(f) & length(f) == 1) f <- f[[1]]
    
    if (is.nlv(f)) {
        
        F <- length(f)
        f <- as.character(f)
        f[is.na(f)] <- "NA"
        U <- unique(f)
        if (sort) U <- sort(U)
        
        if (bycol) {
            if (F == NC) {
                L <- lapply(U, function(i) x[,f==i,drop=FALSE] ) 
            } else if (NC %% F == 0) {
                f <- rep(f, times=NC/F)
                L <- lapply(U, function(i) x[,f==i,drop=FALSE] ) 
            } else {
                stop("ncol(x) is not a multiple of length(f): cannot split!\n")
            }
        } else if (F == NR) {
            L <- lapply(U, function(i) x[f==i,,drop=FALSE] ) 
        } else if (NR %% F == 0) {
            f <- rep(f, times=NR/F)
            L <- lapply(U, function(i) x[f==i,,drop=FALSE] ) 
        } else {
            stop("nrow(x) is not a multiple of length(f): cannot split!\n")
        }
        names(L) <- U
        
    } else if (is.list(f)) {
        
        if (length(unique(listLengths(f))) != 1) stop("All vectors in 'f' must have same length!\n")
        F <- length(f[[1]])
        UF <- apply(do.call(cbind,f),1,paste,collapse=delim)
        UFF <- as.numeric(factor2(UF))  ## USE 'factor2': MUST NOT SORT LEVELS DURING NUMBERING PROCESS
        
        if (bycol) {
            if (F == NC) {
                L <- lapply(unique(UFF), function(i){ x[,UFF==i,drop=FALSE] }) 
            } else if (NC %% F == 0) {
                UF <- rep(UF, times=NC/F)
                UFF <- as.numeric(factor2(UF))
                L <- lapply(unique(UFF), function(i){ x[,UFF==i,drop=FALSE] }) 
            } else {
                stop("ncol(x) is not a multiple of length(f): cannot split!\n")
            }
        } else if (F == NR) {
            L <- lapply(unique(UFF), function(i){ x[UFF==i,,drop=FALSE] }) 
        } else if (NR %% F == 0) {
            UF <- rep(UF, times=NR/F)
            UFF <- as.numeric(factor2(UF))
            L <- lapply(unique(UFF), function(i){ x[UFF==i,,drop=FALSE] }) 
        } else {
            stop("nrow(x) is not a multiple of length(f): cannot split!\n")
        }
        names(L) <- unique(UF)
        
    } else {
        
        stop("'f' must be a vector, or a list of vectors!\n")
        
    }
    return(L)
}


apa.names$general <- c(apa.names$general, "combine.names")
combine.names <- function(vec.list, delim="_", dataframe=FALSE) {
	
	## Creates a new names vector from the "cross product" of two or more other names vectors.
	## The lowest vector (vec.list[1]) is the outermost iterator and the highest vector (vec.list[N]) is the innermost iterator.
	## "delim" speficies the delimiter when stringing names together.  Use "" or NA for no delimiter.  Ignored if dataframe=T.
	## "dataframe" indicates whether to return the combinations as a data frame (TRUE) or as a vector (FALSE).
	
	if (!is.list(vec.list)) { stop("Input must be a list of vectors!\n") }
	if (length(vec.list) < 2) { stop("Input list must have length > 1!\n") }
	if (is.na(delim)) { delim <- "" }
	vec.list <- rev(vec.list)  # enter as outer->inner, but build as inner->outer
	
	vlen <- length(vec.list)
	vlen1 <- vlen - 1
	tot.len <- 1	# total number of resulting names
	
	for (i in 1:vlen) { tot.len <- tot.len * length(vec.list[[i]]) }
	ilens <- listLengths(vec.list)		# num names in each vector
	
	blocks <- c(1, rep(0, vlen1))
	prenames <- matrix(data="", nrow=tot.len, ncol=vlen)
	for (i in 1:vlen) {
		temp <- c()
		if (i > 1) { blocks[i] <- blocks[(i-1)] * ilens[(i-1)] }
		for (j in unique(vec.list[[i]])) { temp <- c(temp, rep(j, blocks[i])) }
		reps <- tot.len / ( blocks[i] * ilens[i] )
		prenames[,i] <- rep(temp, reps)
	}
	
	if (dataframe) {
		allnames <- as.data.frame(prenames[,vlen:1])
	} else {
		allnames <- apply(prenames, 1, FUN=function(x,delim){paste(rev(x),collapse=delim)}, delim)
	}
	return(allnames)
}


apa.names$general <- c(apa.names$general, "sprintf.rownames")
sprintf.rownames <- function(obj, sep=" ", justify=NULL) {
	
	## Takes a matrix, dataframe, or dataframe-conformable list and merges rows into strings via sprintf
	## "sep" gives the field separator
	## "justify" sets left or right justification per column as a vector of 1s & -1s, length=ncol
	
	if (is.ndfl(obj)) { obj <- as.data.frame(obj) }	# this could fail, so re-test for d.f below
	
	if (is.data.frame(obj) | is.matrix(obj)) {
		# ok
	} else {
		stop("object must be a matrix, dataframe, or dataframe-conformable list!\n")
	}
	
	if (is.null(justify)) { 
		justify <- rep(-1, ncol(obj)) 
	} else {
		if (length(justify) != ncol(obj)) { stop("'justify' vector must have length = ncol 'obj'!\n") }
	}
	
	typeconv <- matrix(c("character","s", "numeric","d", "integer","d", "double","d", "complex","s", "float","f"), ncol=2, byrow=TRUE) # float not a mode, but decided prior to conversion
	
	lens <- apply(obj, 2, nchar)
	maxlen <- apply(lens, 2, max)
	datatypes <- apply(obj, 2, mode)
	prefloat <- which(datatypes!="character" & datatypes!="complex")
	floats <- prefloat[which(apply(obj, 2, FUN=function(x){any(grep("\\.",x))}))]
	datatypes[floats] <- "float"
	formats <- typeconv[match(datatypes,typeconv[,1]),2]
	prefixes <- gsub("1","",paste("%",justify,sep=""))
	format.str <- paste(paste(prefixes,maxlen,formats,sep=""),collapse=sep)
#	IM(maxlen)
#	IM(datatypes)
#	IM(formats)
#	IM(format.str)
	string <- apply(obj, 1, FUN=function(x){do.call(sprintf, as.list(c(format.str,x)))})
	return(string)
}


apa.names$general <- c(apa.names$general, "multi.index")
multi.index <- function(..., names=NULL, na.rm=FALSE) {
	
	## Essentially, multi.index produces an N-way outer join table (na.rm=F) or an N-way inner join table (na.rm=T).
	## "vectorlist" is a list object containing two or more UNIQUED vectors from tables to join (e.g. rowname vectors -- no duplicate entries).
	## Output: one matrix with ncol=length(vectorlist), nrow=length(union(vectorlist)), rownames=sort(union(vectorlist)), and colnames=names(vectorlist).
	## Each unique identifier in union(vectorlist) gets a row (i) in output matrix; each column entry is the index for that identifier in vector (j)
	## In many cases there will be NA entries: na.rm=T will strip any rows which possess any NA entries.
	
	vectorlist <- list(...)
	if (length(vectorlist) == 1) { vectorlist <- vectorlist[[1]] }	# input was a single list
	vlen <- length(vectorlist)
	if (vlen < 2) { stop("Need at least two vectors (= list of length 2) to join!\n") }
#	for (i in 1:length(vectorlist)) { vectorlist[[i]] <- as.character(vectorlist[[i]]) }	# incoming might be factors
	
	nuniq <- c()
	for (i in 1:length(vectorlist)) { 
		if (any(duplicated(vectorlist[[i]]))) { nuniq <- c(nuniq, i) }
	}
	if (length(nuniq) > 0) { stop(paste(c("Vectors",nuniq,"have redundant entries!  Cannot index redundancies.\n"),collapse=" ")) }
	
	ternary (is.null(names), vnames <- names(vectorlist), vnames <- names)
	vunion <- c()
	for (i in 1:vlen) { vunion <- union(vunion, vectorlist[[i]]) }
	vunion <- sort(vunion, na.last=TRUE)
	
	join.mat <- matrix(data=NA, nrow=length(vunion), ncol=vlen)
	rownames(join.mat) <- vunion; colnames(join.mat) <- vnames
	
	for (j in 1:ncol(join.mat)) { join.mat[,j] <- match(vunion, vectorlist[[j]]) }
	if (na.rm) {
		keep <- which(!is.na(rowSums(join.mat)))
		join.mat <- join.mat[keep,]
	}
	
	return(join.mat)
}


apa.names$general <- c(apa.names$general, "match.multi")
match.multi <- function(x, y) {
	
	## Extension of base match() to match on multiple columns simultaneously
	## 'x' and 'y' are matrices or dataframes with the same number of columns (not necessarily rows)
	## returns match vector for 'x' in 'y'
	
	x2 <- apply(x,1,paste,collapse="\t")
	y2 <- apply(y,1,paste,collapse="\t")
	match(x2, y2)
}


apa.names$general <- c(apa.names$general, "join.tables")
join.tables <- function(mat1, mat2, join, key1=1, key2=1, dup.rm=TRUE, spacer=NA, sort=TRUE) {
	
	## DB-style table joins for two matrices or dataframes
	## key1, key2 indicate column numbers for keys in mat1, mat2 respectively
	## join: { 1=Outer, 2=Inner, 3=Left, 4=Right, 5=Disjoin }
	## dup.rm: discard duplicate rows?
	## spacer: missing (null) values represented by this spacer
	## sort: separate rows into joined/unjoined sets or leave in mat1 (+mat2) order?
	
	if (!join %in% 1:5) { stop("'join' must be an integer from 1-5!\n") }
	
#	df.out <- FALSE
#	if (is.data.frame(mat1)) { df.out <- TRUE }
#	if (is.data.frame(mat2)) { df.out <- TRUE }
	
	keyname <- colnames(mat1)[key1]
	k1 <- mat1[,key1]
	k2 <- mat2[,key2]
	all <- sort(union(k1, k2))
	int <- intersect(k1, k2)
	int.v1 <- match(int, k1)
	int.v2 <- match(int, k2)
	sd1 <- setdiff(k1, k2)
	sd2 <- setdiff(k2, k1)
	sd1.v1 <- match(sd1, k1)
	sd2.v2 <- match(sd2, k2)
	
	mat1 <- mat1[,-key1]	# remove keys
	mat2 <- mat2[,-key2]	# remove keys
	
	spacer1 <- matrix(data=spacer, nrow=length(sd2), ncol=ncol(mat1))
	colnames(spacer1) <- colnames(mat1)
	spacer2 <- matrix(data=spacer, nrow=length(sd1), ncol=ncol(mat2))
	colnames(spacer2) <- colnames(mat2)
	joinreport <- c()
	
	joined <- switch(as.character(join),
		"1" = rbind(
				nameless(cbind(sd1, mat1[sd1.v1,], spacer2)),
				nameless(cbind(int, mat1[int.v1,], mat2[int.v2,])),
				nameless(cbind(sd2, spacer1,       mat2[sd2.v2,]))
			),
		"2" = cbind( int, mat1[int.v1,], mat2[int.v2,] ),
		"3" = rbind( 
				nameless(cbind(sd1, mat1[sd1.v1,], spacer2)),
				nameless(cbind(int, mat1[int.v1,], mat2[int.v2,]))
			),
		"4" = rbind( 
				nameless(cbind(int, mat1[int.v1,], mat2[int.v2,])), 
				nameless(cbind(sd2, spacer1,       mat2[sd2.v2,]))
			),
		"5" = rbind( 
				nameless(cbind(sd1, mat1[sd1.v1,], spacer2)), 
				nameless(cbind(sd2, spacer1,       mat2[sd2.v2,])) 
			)
	)
	colnames(joined) <- c(keyname, colnames(spacer1), colnames(spacer2))
	
	if (sort) joined <- joined[match(all, joined[,1]),]
	
	if (dup.rm) {
		if (is.matrix(joined)) {
			cats <- apply(joined, 1, FUN=function(x){paste(x, collapse=".")})
		} else {
			cats <- apply(as.matrix.data.frame(joined), 1, FUN=function(x){paste(x, collapse=".")})
		}
		drop <- which(duplicated(cats))
		if (length(drop > 0)) { joined <- joined[-drop,] }
	}
	
#	if (df.out) { joined <- defactor(as.data.frame.matrix(joined)) }
	
#	IM(joinreport)
	return (joined)	
}


apa.names$microarray <- c(apa.names$microarray, "venn.areas")
venn.areas <- function(obj, vnames=NULL, include="both", dirs=NULL, universe=NULL, ABC.order=FALSE) { 
    
    ## Returns lists for all venn areas
    ## "obj" is a list of vectors or a decideTests-type matrix ({-1,0,1}, or logical)
    ## "include" = "up", "down", "both", and "opp", first 3 as with limma's vennDiagram(), ONLY IF using a decideTests-type matrix.
    ##  - "opp" returns only entries which are not all up or all down.
    ## "dirs" = vector to change column directionality, one entry for each column, ONLY IF using a decideTests-type matrix.
    ##  - directionality entries can be -1 or 1.  All = 1 if "dirs" is null.
    ## "universe" allows a universe-set specification if not using a decideTests-style matrix
    ## "ABC.order" indicates whether to reorder the output in Venn-area map order
    
    include <- match.arg(include, c("up","down","both","opp"))
    
    if (length(obj)==0) return()
    if (is.data.frame(obj)) obj <- as.matrix.data.frame(obj)	# coerce to matrix, if possible
    
    if (is.list(obj)) {
        N <- length(obj)
        if (is.null(names(obj))) {
            ternary(is.null(vnames), gnames <- 1:N, gnames <- vnames)
        } else {
            gnames <- names(obj)
        }
        mat <- FALSE
    } else if (is.matrix(obj) & mode(obj) %in% c("numeric", "double", "logical")) { 
        N <- ncol(obj)
        if (is.null(colnames(obj))) {
            ternary(is.null(vnames), gnames <- 1:N, gnames <- vnames)
        } else {
            gnames <- colnames(obj)
        }
        if (is.null(rownames(obj))) rownames(obj) <- 1:nrow(obj)
        mat <- TRUE
        if (mode(obj) == "logical") mode(obj) <- "numeric"	# convert to binary
    } else {
        stop("Input must be a list of vectors or a logical/numeric matrix!\n")
    }
    
    if (is.null(dirs)) dirs <- rep(1, N)
    delim <- "&"	# venn area name delimiter
    
    M <- N-1
    A <- 2*2^(N-1)   # Number of output areas, including 'Excluded'
    areas <- permn2(0:1,N,rep=TRUE)[,N:1]
    colnames(areas) <- gnames
    areas <- areas[order(rowSums(areas))[c(2:A,1)],]
    areas <- t( t(areas)*2^c(0:M) )
    areas <- data.frame(areas, Size=rowSums(areas>0), Bsum=rowSums(areas), Name=apply(areas,1,function(x) paste(gnames[x>0],collapse=delim) ))
    areas$Name[A] <- "Excluded"
    for (i in 2:M) {  # sort areas by size then names-in-colname-order, basically (identical to original order expected by venn.diag())
        w <- which(areas$Size==i)
        x <- areas[w[do.call(order,as.list(areas[w,1:N]))],]
        areas[w,] <- x[nrow(x):1,]
    }
    
    area.list <- vector("list", length=A)   	 # not 1 less, because we are adding the excludeds (universe) as a set
    names(area.list) <- areas$Name 	        	 # "Excluded" set automatically populated when using a decideTests-style matrix;
    for (i in 1:A) area.list[[i]] <- logical(0)	 # NULL not desirable -- initialize all with length-0 vectors
    attr(area.list, "class") <- "area.list"
    sizes <- matrix(data=0, nrow=2, ncol=(N+1))
    dimnames(sizes) <- list( c("Total","Unique"), c(gnames,"Universe") )
    uniq.univ <- c()
    if (length(universe)>0) uniq.univ <- sort(unique(universe))
    sizes[,(N+1)] <- c(length(universe), length(uniq.univ))
    
    ## Quantify any redundancy in lists; get original + unique set sizes
    ## Convert input data to matrix, if not already
    if (mat) {
        attr(area.list, "include") <- include
        obj2 <- obj[!duplicated(rownames(obj)),]  # if duplicate rownames, keep first instances
        for (i in 1:ncol(obj2)) {
            odat <- obj[,i] * dirs[i]   # original, N matching elements
            udat <- obj2[,i] * dirs[i]  # uniqued,  N matching elements
            sizes[,i] <- switch(
                include,
                both = c( sum(odat!=0), sum(udat!=0)),
                up   = c( sum(odat >0), sum(udat >0)),
                down = c( sum(odat <0), sum(udat <0)),
                opp  = c( sum(odat!=0), sum(udat!=0))
            )
        }
    } else {
        allobj <- sort(unique(unlist(obj)))
        obj2 <- matrix(0, length(allobj), N, FALSE, list(allobj,gnames))
        for (i in 1:N) {
            tab <- table(obj[[i]])
            obj2[match(names(tab),allobj),i] <- 1
            sizes[,i] <- c(length(obj[[i]]), length(tab))
        }
    }
    attr(area.list, "sizes") <- sizes
    
    ## Load Venn areas
    obj2.bsum <- rowSums(t( t(abs(obj2))*2^c(0:M) ))
    for (i in 1:nrow(areas)) area.list[[i]] <- rownames(obj2)[obj2.bsum==areas$Bsum[i]]
    
    if (!is.null(universe)) {
        ## Load exclusion area
        present <- as.numeric(unlist(area.list[1:(A-1)]))
        if (length(area.list[[A]])>0) {
            ## exclusion set already populated
            err <- length(setdiff(area.list[[A]], uniq.univ))
            if (err>0) stop(paste("Indicated universe is incomplete: there are",err,"members already in exclusion set which are not in the universe!\n"))
        }
        area.list[[A]] <- uniq.univ[!uniq.univ %in% present]
    }
    
    if (ABC.order) {
        ## What function was this intended to serve??  Clearly for 3-way venn area + excluded.
        ##     ACGBDFEH
        ##     12345678
        ##     ABCDEFGH
        ##     14257638
        area.list <- area.list[c(1,4,2,5,7,6,3,8)]
    }
    
    return(area.list)
}


apa.names$general <- c(apa.names$general, "interleave")
interleave <- function(..., df.names=NULL, col.ord=FALSE, row.ord=FALSE, maxann=NULL, stringsAsFactors=TRUE) {
	
	## Takes N data frames and produces one output data frame, which consists of columns of the originals, shuffled together in order.
	##  e.g. given data frames A, B, C, each with three columns, output column order is { A1 B1 C1 A2 B2 C2 A3 B3 C3 }
	## Input may be separate data frames or a list of them.
	## All data frames must have the same dimension
	## "df.names" is a vector of names, one for each data frame, that become column name prefixes.  Otherwise, column names get numeric suffixes.
	## "col.ord=T" means that columns should be ordered prior to interleaving.  Requires colnames be equal among inputs.
	## "row.ord=T" means that rows should be ordered prior to interleaving.  Requires "maxann".
	## "maxann=<real num>" means that the first 'maxann' columns are annotation; use this to order the rows.
	##  If "maxann=0", rownames are used to order the data frames.
	## "stringsAsFactors" affects the output data frame.
	
	if (row.ord & is.null(maxann)) { stop("Cannot use 'row.ord=T' without specifying 'maxann'!\n") }
	
	input <- list(...)
	if (length(input) == 1) { 	# was a list to begin with
		input <- input[[1]]
	}
	N <- length(input)
	
	oktype <- okdim <- TRUE
	dim1 <- dim(input[[1]])
	for (i in 1:N) {
		dimi <- dim(input[[i]])
		if (!is.data.frame(input[[i]])) { 
			oktype <- FALSE 
		} else if (dimi[1] != dim1[1] | dimi[2] != dim1[2]) {
			okdim <- FALSE 
		}
	}
	if (!oktype) { stop("Inputs must all be data frames! (or a list of them)\n") }
	if (!okdim) { stop("Data frames must all have same dimension!\n") }
	
	if (col.ord) {	
		# all column names must be same for each df
		cnames <- colnames(input[[1]])
		if (!is.null(df.names)) {
			allcnames <- paste(df.names[i], cnames, sep=".")
		} else {
			allcnames <- paste(cnames, 1, sep=".")
		}
		for (i in 2:N) {
			int <- intersect(cnames, colnames(input[[i]]))
			if (length(int) != length(cnames)) {	# not same colnames
				stop(paste("Input",i,"has different column names from input 1!  Cannot order columns.\n"))
			}
			ord <- match(colnames(input[[i]]),cnames)
			input[[i]] <- input[[i]][,ord]	# reorder columns to match input #1
			if (!is.null(df.names)) {
				allcnames <- c(allcnames, paste(df.names[i], cnames, sep="."))
			} else {
				allcnames <- c(allcnames, paste(cnames, i, sep="."))
			}
		}
	} else {	
		# column names may vary between dfs
		allcnames <- rep("", N*dim1[2])
		k <- 0
		for (j in 1:dim1[2]) {
			for (i in 1:N) {
				k <- k + 1
				if (!is.null(df.names)) {
					allcnames[k] <- paste(df.names[i], colnames(input[[i]])[j], sep=".")
				} else {
					allcnames[k] <- paste(colnames(input[[i]])[j], j, sep=".")
				}
			}
		}
	}
	
	if (row.ord) {
		if (maxann == 0) {
			rnames1 <- rownames(input[[1]])
			ord <- do.call(order, rnames1)
			rnames1 <- rnames1[ord]
			input[[1]] <- input[[1]][ord,]
			for (i in 2:N) {
				rnamesi <- rownames(input[[i]])
				ord <- do.call(order, rnamesi)
				rnamesi <- rnamesi[ord,]
				if (all(rnames1==rnamesi)) { 
					input[[i]] <- input[[i]][ord,]	# reorder rows to match input #1
				} else {
					stop(paste("Row names for input",i,"are incompatible with input 1!\n"))
				}
			}
			allrnames <- rnames1
		} else {
			anncols1 <- input[[1]][,1:maxann]
			ord <- do.call(order, anncols1)
			anncols1 <- anncols1[ord,]
			input[[1]] <- input[[1]][ord,]
			for (i in 2:N) {
				anncolsi <- input[[i]][,1:maxann]
				ord <- do.call(order, anncolsi)
				anncolsi <- anncolsi[ord,]
				if (all(anncols1==anncolsi)) { 
					input[[i]] <- input[[i]][ord,]	# reorder rows to match input #1
				} else {
					stop(paste("The first",maxann,"(annot) columns for input",i,"are incompatible with input 1!\n"))
				}
			}
			allrnames <- 1:nrow(input[[1]])
		}
	}
	
	cols <- vector("list", length=dim1[2]*N)
	k <- 0
	for (i in 1:dim1[2]) {
		for (j in 1:N) {
			k <- k + 1
			cols[[k]] <- input[[j]][,i]
		}
	}
	inter <- as.data.frame.matrix(do.call(cbind, cols), stringsAsFactors=stringsAsFactors)
	colnames(inter) <- allcnames
	rownames(inter) <- allrnames
	return(inter)
}
