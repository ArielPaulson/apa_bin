

apa.names$bio.seq <- c(apa.names$bio.seq, "rev.comp")
rev.comp <- function(x) {
    ## ONE SEQUENCE AT A TIME
    if (length(x)==1) {
        y <- unlist(strsplit(x,''))
    } else {
        y <- x
    }
    z <- translate(y, qw(A,C,G,T,a,c,g,t), qw(T,G,C,A,t,g,c,a))
    if (length(x)==1) {
        paste(rev(z),collapse="")
    } else {
        rev(z)
    }
}


apa.names$bio.seq <- c(apa.names$bio.seq, "rev.comp.vector")
rev.comp.vector <- function(x, same.len=FALSE) {
    ## MULTIPLE SEQUENCES, EACH ONE STRING
    if (same.len) {
        ## Matricized, fast
        y <- do.call(rbind, strsplit(x,''))
        y <- y[,ncol(y):1]
        z <- translate(y, qw(A,C,G,T,a,c,g,t), qw(T,G,C,A,t,g,c,a))
        apply(z,1,paste,collapse="")
    } else {
        ## Cannot matricize, slower
        y <- strsplit(x,'')
        z <- lapply(strsplit(x,''), function(y) translate(rev(y), qw(A,C,G,T,a,c,g,t), qw(T,G,C,A,t,g,c,a)))
        sapply(z,paste,collapse="")
    }
}


apa.names$bio.seq <- c(apa.names$bio.seq, "aa.translate")
aa.translate <- function(x, frames=1, alpha=c("DNA","RNA"), stop.unique=FALSE) {
	
	## translate DNA/RNA to AA
	## 'x' is a character vector (each element = 1 sequence)
	## 'frames' can be 1, 3, or 6
	## "stop.unique=TRUE" gives each type of stop codon a unique symbol (otherwise '*')
	
	alpha <- match.arg(alpha)
	if (!(frames %in% c(1,3,6))) stop("'frames' must be 1, 3, or 6!\n")
	frames <- as.character(frames)
	
	fnames <- switch(frames,
		"1"="+0",
		"3"=paste0("+",0:2),
		"6"=c(paste0("+",0:2),paste0("-",0:2))
	)
	
	xnames <- names(x)
	x <- sapply(x, toupper)
	if (alpha=="DNA") {
		if (any(grepl("[^ACGTN]",x))) warning("Non-ACGTN characters detected!\n")
	} else if (alpha=="RNA") {
		if (any(grepl("[^ACGUN]",x))) warning("Non-ACGUN characters detected!\n")
		x <- sapply(x, translate, "T", "U")
	}
	
	offsets <- rep(0:2,2)
	stops <- 
		if (stop.unique) {
			list( c('TAA','#'), c('TAG','$'), c('TGA','%') )  ## ochre, amber, opal/umber
		} else {
			list( c('TAA','*'), c('TAG','*'), c('TGA','*') )
		}
	codons <- do.call(rbind, c(stops, list(
		c('TTT','F'), c('TTC','F'), c('TTA','L'), c('TTG','L'), 
		c('TCT','S'), c('TCC','S'), c('TCA','S'), c('TCG','S'), 
		c('TAT','Y'), c('TAC','Y'), c('TGT','C'), c('TGC','C'), 
		c('TGG','W'), c('CTT','L'), c('CTC','L'), c('CTA','L'), 
		c('CTG','L'), c('CCT','P'), c('CCC','P'), c('CCA','P'), 
		c('CCG','P'), c('CAT','H'), c('CAC','H'), c('CAA','Q'), 
		c('CAG','Q'), c('CGT','R'), c('CGC','R'), c('CGA','R'), 
		c('CGG','R'), c('ATT','I'), c('ATC','I'), c('ATA','I'), 
		c('ATG','M'), c('ACT','T'), c('ACC','T'), c('ACA','T'), 
		c('ACG','T'), c('AAT','N'), c('AAC','N'), c('AAA','K'), 
		c('AAG','K'), c('AGT','S'), c('AGC','S'), c('AGA','R'), 
		c('AGG','R'), c('GTT','V'), c('GTC','V'), c('GTA','V'), 
		c('GTG','V'), c('GCT','A'), c('GCC','A'), c('GCA','A'), 
		c('GCG','A'), c('GAT','D'), c('GAC','D'), c('GAA','E'), 
		c('GAG','E'), c('GGT','G'), c('GGC','G'), c('GGA','G'), 
		c('GGG','G') )
	))
	
	trans <- list(
		`1`=function(y) {  # in-frame translation
			L <- nchar(y)
			if (L<3) return(NA)
			if (L %% 3 != 0) warning("Sequence length not a multiple of 3!  Translation will be 3'-incomplete.", call.=FALSE)
			aa <- rep("",floor(L/3))
			for (i in 1:length(aa)) {
				codon <- substr(y, 3*(i-1)+1, 3*i)
				aa[i] <- ifelse(grepl("[^ACGT]",codon), "X", codons[match(codon,codons[,1]),2])
			}
			paste(aa,collapse="")
		},
		`3`=function(y) {  # 3-frame translation
			L <- nchar(y)
			if (L<3) return(rep(NA,3))
			aa <- named.list(lapply(1:3, function(i){ rep("", floor((L-i+1)/3)) }), 1:3)
			for (f in 1:frames) {
				for (i in 1:length(aa[[f]])) {
					codon <- substr(y, 3*(i-1)+1+offsets[f], 3*i+offsets[f])
					if (nchar(codon)<3) next
					aa[[f]][i] <- ifelse(grepl("[^ACGT]",codon), "X", codons[match(codon,codons[,1]),2])
				}
				aa[[f]] <- ifelse(length(aa[[f]])>0, paste(aa[[f]],collapse=""), NA)
			}
			unlist(aa)
		},
		`6`=function(y) {  # 6-frame translation
			L <- nchar(y)
			if (L<3) return(rep(NA,6))
			aa <- lapply(1:3, function(i){ rep("", floor((L-i+1)/3)) })
			aa <- named.list(c(aa, aa), c(1:3,-1:-3))
			rev.y <- paste(rev(unlist(strsplit(y,""))),collapse="")
			for (f in 1:frames) {
				y2 <- ifelse(f <= 3, y, rev.y)
				for (i in 1:length(aa[[f]])) {
					codon <- substr(y2, 3*(i-1)+1+offsets[f], 3*i+offsets[f])
					if (nchar(codon)<3) next
					aa[[f]][i] <- ifelse(grepl("N",codon), "X", codons[match(codon,codons[,1]),2])
				}
				aa[[f]] <- ifelse(length(aa[[f]])>0, paste(aa[[f]],collapse=""), NA)
			}
			unlist(aa)
		}
	)
	
	if (frames == 1) {
            x <- sapply(x, trans[[frames]])
            names(x) <- NULL
	} else {
            x <- t(sapply(x, trans[[frames]]))
            colnames(x) <- fnames
	}
        x
}


apa.names$bio.seq <- c(apa.names$bio.seq, "aa.eval")
aa.eval <- function(x) {
	
	## Returns statistics about a vector of peptide sequences 'x':
	## Sequence Length, N Unique AAs, Shannon-Weaver Index (Complexity), N Internal Stops (not counting 3'-terminal stop), Max ORF Length, N Max Orfs, Seq Starts with M?, Seq Ends with Stop?
	
	x <- toupper(x)  # vector of peptide sequences
	x2 <- lapply(strsplit(x,""), function(s) s[s %in% LETTERS[-24]] )  # seq vectors; no stops, gaps, X
	orfs <- strsplit(x,"\\*")  # list of vectors of ORF sequences
#	orfs2 <- lapply(orfs, strsplit, "")  # list of lists of ORF aa vectors
	y <- data.frame(
		Length=nchar(x), 
		UnqAAs=sapply(x2, luniq),
		Shannon.Weaver=sapply(x2, shannon.weaver),
		IntStops=sapply(orfs, length)-1,
		MaxOrf=sapply(orfs, function(s) max(nchar(s)) ),
		NMaxOrfs=sapply(orfs, function(s) sum(nchar(s)==max(nchar(s))) ),
		Start.M=grepl("^M",x),
		End.Stop=grepl("\\*$",x),
	)
	na <- which(is.na(x))
	for (i in na) for (j in 1:ncol(y)) y[i,j] <- NA
	y
}


apa.names$hacks <- c(apa.names$hacks, "muscle")
muscle <- function(input, output=NULL, flat=NULL, params=NULL, as.matrix=FALSE, silent=FALSE, fix.terminals=c("none","DNA","AA")) {
    
    ## Runs muscle on two fasta sequences
    ## 'input' can be a file, or results from read.fasta() -- basically a named vector of DNA/AA strings
    ## 'output' file can be specified, if not a temp file will be made.
    ## 'flat', if specified (must be a filename), creates a flattened multialignment file for easier viewing
    ## returns the multialigned fasta sequences as vector, or as matrix if "as.matrix=TRUE"
    ## 'fix.terminals', if not "none", will ensure that M/ATG and */{TAA,TAG,TGA} are shifted to first/last columns where possible.
    
    fix.terminals <- match.arg(fix.terminals)
    infile <- tempfile()
    if (is.nlv(input) & length(input)>1) {
        input <- gsub("\\*","Z",input)               # currently, "Z" is not an AA or NT character -- substitute for stops
        write.fasta(input, infile)
    } else if (file.exists(input)) {
        input2 <- gsub("\\*","Z",read.fasta(input))  # currently, "Z" is not an AA or NT character -- substitute for stops
        write.fasta(input2, infile)
    } else {
        stop("'input' is neither a vector nor a file!")
    }
    if (is.null(output)) output <- tempfile()
    if (silent) {
        cmd <- paste("muscle -in",infile,"-out",output,params," 2> /dev/null")
    } else {
        cmd <- paste("muscle -in",infile,"-out",output,params)
    }
    IM("Running:",cmd)
    system(cmd)
    aln <- gsub("Z","*",read.fasta(output))  # put stop codons back
    if (fix.terminals != "none") {
        start <- ifelse(fix.terminals=="AA", "M", "ATG")
        end   <- ifelse(fix.terminals=="AA", "\\*", "(TGA|TAA|TAG)")
        aln <- sub(paste0("^(-*)",start),paste0(start,"\\1"),aln)
        aln <- sub(paste0("(",end,")(-*)$"),paste0("\\2","\\1"),aln)
   }
    write.fasta(aln, output)
    if (!is.null(flat)) {
        system(paste("/home/apa/local/bin/flattenMultialign -i",output,"--flat >",flat))
    }
    if (as.matrix) {
        do.call(rbind, lapply(read.fasta(output), function(x) unlist(strsplit(x,"")) ))
    } else {
        read.fasta(output)
    }
}


apa.names$bio.seq <- c(apa.names$bio.seq, "shuffle.sequences")
shuffle.sequences <- function(seqs, replace=FALSE) {
    
    ## Randomizes each sequence in a vector of sequences

    spl <- strsplit(seqs,"")
    shuf <- sapply(spl, function(x) sample(x,length(x),replace=replace) )
    sapply(shuf,paste,collapse="")
}


apa.names$bio.seq <- c(apa.names$bio.seq, "get.N50")
get.N50 <- function(vec, N=50, minimum=0) {
    
    ## calculates the N50 of a vector of contig lengths
    ## "minimum" specifies minimum contig length to consider
    ## "N" shifts from N50 to something else, e.g. "N=90" gets N90
    
    if (any(vec>=minimum)) {
        vec <- vec[vec>=minimum]
        ksum <- sum(vec)
        threshold <- ksum * N / 100
        S <- sort(vec, decreasing=TRUE)
        L <- length(vec)
        cs <- cumsum(S)
        x <- ifelse (any(cs==threshold), which(cs==threshold), which(cs>threshold)[1])
        S[x]
    } else {
        NA
    }
}


apa.names$bio.seq <- c(apa.names$bio.seq, "pct.GC")
pct.GC <- function(vec, ignore.degen=FALSE) {
    
    ## calculates the GC content of a vector of DNa/RNA sequences
    ## "ignore.degen" drops degen chars if TRUE.  Otherwise, adds the GC fraction of member bases (e.g.: S=[GC]=1, W=[AT]=0, M=[AC]=0.5, V=[ACG]=0.67, N=[ACGT]=0.5, etc)
    
    dict <- list(N=c("A","C","G","T"), H=c("A","C","T"), D=c("A","G","T"), V=c("A","C","G"), B=c("C","G","T"), R=c("A","G"), Y=c("C","T"), S=c("C","G"), W=c("A","T"), M=c("A","C"), K=c("G","T"), A="A", C="C", G="G", T="T")
    bases <- strsplit(toupper(vec,""))
    
    if (ignore.degen) {
        bases <- lapply(bases, function(x) x[x%in%c("A","C","G","T")] )
        GC <- sapply(bases, function(x) sum(x%in%c("C","G")) )
    } else {
        GC <- sapply(bases, function(x) 1*sum(x%in%c("C","G","S")) + 0.5*sum(x%in%c("N","R","Y","W","M")) + 0.33*sum(x%in%c("H","D")) + 0.67*sum(x%in%c("V","B")) )
    }
    GC / sapply(bases,length)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "martCheck")
martCheck <- function (mart, biomart = NULL) {
    
    stop("bio.seq.dev.R martCheck() is obsolete, archive-query functionality now exist in base biomaRt()\n")
    
    ## Hacked version which allows querying of archival biomarts -- if only the biomaRt packages would use this one and not the native, non-exported version...
    
    if (missing(mart) || class(mart) != "Mart") {
        stop("You must provide a valid Mart object. To create a Mart object use the function: useMart.  Check ?useMart for more information.")
    }
    if (!is.null(biomart)) {
        martcheck = strsplit(biomaRt:::martBM(mart), "_", fixed = TRUE, useBytes = TRUE)[[1]][1]
        if (toupper(martcheck[1]) != toupper(biomart)) stop(paste("This function only works when used with the ", biomart, " BioMart.", sep = ""))
    }
    if (biomaRt:::martDataset(mart) == "") {
        stop("No dataset selected, please select a dataset first.  You can see the available datasets by using the listDatasets function see ?listDatasets for more information.  Then you should create the Mart object by using the useMart function.  See ?useMart for more information")
    }
}


apa.names$bio.seq <- c(apa.names$bio.seq, "getSequence")
getSequence <- function (chromosome, start, end, id, type, seqType, upstream, downstream, mart, verbose = FALSE) {
    
    ## EXPERIMENTAL
    ## Hacked version of biomaRt getSequence()
    
    if (missing(seqType) || !seqType %in% c("cdna", "peptide", 
        "3utr", "5utr", "gene_exon", "transcript_exon", "transcript_exon_intron", 
        "gene_exon_intron", "coding", "coding_transcript_flank", 
        "coding_gene_flank", "transcript_flank", "gene_flank")) {
        stop("Please specify the type of sequence that needs to be retrieved when using biomaRt in web service mode.  Choose either gene_exon, transcript_exon,transcript_exon_intron, gene_exon_intron, cdna, coding,coding_transcript_flank,coding_gene_flank,transcript_flank,gene_flank,peptide, 3utr or 5utr")
    }
    if (missing(type)) 
        stop("Please specify the type argument.  If you use chromosomal coordinates to retrieve sequences, then the type argument will specify the type of gene indentifiers that you will retrieve with the sequences.  If you use a vector of identifiers to retrieve the sequences, the type argument specifies the type of identifiers you are using.")
    if (missing(id) && missing(chromosome) && !missing(type)) 
        stop("No vector of identifiers given. Please use the id argument to give a vector of identifiers for which you want to retrieve the sequences.")
    if (!missing(chromosome) && !missing(id)) 
        stop("The getSequence function retrieves sequences given a vector of identifiers specified with the id argument of a type specified by the type argument.  Or alternatively getSequence retrieves sequences given a chromosome, a start and a stop position on the chromosome.  As you specified both a vector of identifiers and chromsomal coordinates. Your query won't be processed.")
    if (!missing(chromosome)) {
        if (!missing(start) && missing(end)) 
            stop("You specified a chromosomal start position but no end position.  Please also specify a chromosomal end position.")
        if (!missing(end) && missing(start)) 
            stop("You specified a chromosomal end position but no start position.  Please also specify a chromosomal start position.")
        if (!missing(start)) {
            start = as.integer(start)
            end = as.integer(end)
        }
        if (missing(upstream) && missing(downstream)) {
            sequence = getBM(c(seqType, type), filters = c("chromosome_name", 
                "start", "end"), values = list(chromosome, start, 
                end), mart = mart, checkFilters = FALSE, verbose = verbose)
        }
        else {
            if (!missing(upstream) && missing(downstream)) {
                sequence = getBM(c(seqType, type), filters = c("chromosome_name", 
                  "start", "end", "upstream_flank"), values = list(chromosome, 
                  start, end, upstream), mart = mart, checkFilters = FALSE, 
                  verbose = verbose)
            }
            if (!missing(downstream) && missing(upstream)) {
                sequence = getBM(c(seqType, type), filters = c("chromosome_name", 
                  "start", "end", "downstream_flank"), values = list(chromosome, 
                  start, end, downstream), mart = mart, checkFilters = FALSE, 
                  verbose = verbose)
            }
            if (!missing(downstream) && !missing(upstream)) {
                stop("Currently getSequence only allows the user to specify either an upstream of a downstream argument but not both.")
            }
        }
    }
    if (!missing(id)) {
        if (missing(type)) 
            stop("Type argument is missing.  This will be used to retrieve an identifier along with the sequence so one knows which gene it is from.  Use the listFilters function to select a valid type argument.")
        if (!type %in% listFilters(mart, what = "name")) 
            stop("Invalid type argument.  Use the listFilters function to select a valid type argument.")
        valuesString = paste(id, "", collapse = ",", sep = "")
        if (missing(upstream) && missing(downstream)) {
            sequence = getBM(c(seqType, type), filters = type, 
                values = id, mart = mart, verbose = verbose)
        }
        else {
            if (!missing(upstream) && missing(downstream)) {
                sequence = getBM(c(seqType, type), filters = c(type, 
                  "upstream_flank"), values = list(id, upstream), 
                  mart = mart, checkFilters = FALSE, verbose = verbose)
            }
            if (!missing(downstream) && missing(upstream)) {
                sequence = getBM(c(seqType, type), filters = c(type, 
                  "downstream_flank"), values = list(id, downstream), 
                  mart = mart, checkFilters = FALSE, verbose = verbose)
            }
            if (!missing(downstream) && !missing(upstream)) {
                stop("Currently getSequence only allows the user to specify either an upstream of a downstream argument but not both.")
            }
        }
    }
    return(sequence)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "getGene")
getGene <- function (id, type, mart) {
    
    ## EXPERIMENTAL
    ## Hacked version of biomaRt getGene()
    
    biomaRt:::checkWrapperArgs(id, type, mart)
    symbolAttrib = switch(strsplit(biomaRt:::martDataset(mart), "_", fixed = TRUE, useBytes = TRUE)[[1]][1], hsapiens = "hgnc_symbol", mmusculus = "mgi_symbol", "external_gene_id")
    typeAttrib = switch(type, affy_hg_u133a_2 = "affy_hg_u133a_v2", type)
    attrib = c(typeAttrib, symbolAttrib, "description", "chromosome_name", "band", "strand", "start_position", "end_position", "ensembl_gene_id")
    table = getBM(attributes = attrib, filters = type, values = id, mart = mart)
    return(table)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "seq.dist.partial")
seq.dist.partial <- function(seqs, alpha=c("DNA","RNA","AA"), degen.match=c("0","1","2","-1"), ignore.gaps=FALSE, min.pos=1, min.pct=0, MI=c("none","null","true"), aligns=FALSE) {
    
    ## THIS MAY BE OBSOLETE -- see if now-base adist() can replace it...
    
    ## Calculates edit (Hamming) distance for a set of multiply-aligned incomplete sequences ('seqs').
    ##
    ## Each pairwise distance is based solely on the "matchable" positions, i.e. non-N/X.  Unknown positions like N/X -- and perhaps others, depending on settings -- are "ignored".
    ##  - "Ignored" letters neither match nor contribute to the matchable sequence length.
    ##  - Thus, during comparison, at some position i, if either sequence has an ignorable letter, it is as though position i never existed.
    ##
    ## 'alpha' specifies alphabet to match in.
    ## 'degen.match' is a stringency level for allowing degenerate letters to match:
    ##   0 = Exact matches only: no flexibility for degenerates.
    ##   1 = Proper-subset matches: degenerates will match if one is a proper subset of the other.  E.g.: M vs A => [AC] vs A => match ; R vs D => [AG] vs [AGT] => match.
    ##   2 = Any-intersection matches: degenerates match if any part of their definitions match.  E.g. M vs W => [AC] vs [AT] => match, because the "A" is shared.
    ##  -1 = Ignore degenerates just like N/X.
    ## Degenerate letters will match if the compared letter is part of the degenerate set (e.g. M vs A = [AC] vs A = match, while Y vs A = [CT] vs A = no match).
    ## 'ignore.gap' affects gap handling.  If two sequences both have gaps at the same position, this position is always removed from consideration.  Otherwise:
    ##  - If FALSE, gaps ("-") are considered "letters" and will mismatch with non-gaps, except N/X (then ignored).
    ##  - If TRUE, gaps ("-") are ignored like N/X.
    ## 'min.pos' and 'min.pct' both control the minimum amount of shared sequence to conduct a comparison; else dist = NA.
    ##  - 'min.pos' specifies minimum N positions; 'min.pct' specifies minimum sequence percent (on [0,1], as % total sequence length, INCLUDING N/X positions but EXCLUDING gaps)
    ##  - The two flags can be used simultaneously; in practice, whichever value is smaller is used.  
    ##  - Thus one can specify "min.pct=0.5, min.pos=20" and compare only sequences where shared positions are >= 50% of each sequence, and this must also be >= 20bp.
    ## 'MI' specifies calculation of mutual information:
    ##  - "none" = do not calculate.
    ##  - "null" = calculate based random frequencies.
    ##  - "true" = calculate based on observed frequencies.  Degenerate positions do not contribute.
    ## 'aligns=TRUE' will return a list of all scored, pairwise alignments.
    ## Returns distance matrix, N-comparable-positions matrix, and mutual info matrix.
    
    alpha <- match.arg(alpha)
    MI <- match.arg(MI)
    degen.match <- match.arg(degen.match)
    
    ## Alphabets and degenerate definitions
    bases <- list(
        DNA=list(A="A", C="C", G="G", T="T"),
        RNA=list(A="A", C="C", G="G", U="U"),
        AA=as.list(qw(A,C,D,E,F,G,H,I,K,L,M,N,P,Q,R,S,T,V,W,Y))
    )
    names(bases[["AA"]]) <- unlist(bases[["AA"]])
    
    degen <- list(
        DNA=list(A="A", C="C", G="G", T="T", R=qw(A,G), Y=qw(C,T), M=qw(A,C), S=qw(C,G), W=qw(A,T), K=qw(G,T), B=qw(C,G,T), V=qw(A,C,G), D=qw(A,G,T), H=qw(A,C,T)),
        RNA=list(A="A", C="C", G="G", U="U", R=qw(A,G), Y=qw(C,U), M=qw(A,C), S=qw(C,G), W=qw(A,U), K=qw(G,U), B=qw(C,G,U), V=qw(A,C,G), D=qw(A,G,U), H=qw(A,C,U)),
        AA=c(bases[["AA"]], list(B=qw(D,N), Z=qw(E,Q)))
    )
    
    if (ignore.gaps) {
        ignore <- list(DNA=list(`-`="-",N="N"), RNA=list(`-`="-",N="N"), AA=list(`-`="-",X="X"))
    } else {
        ignore <- list(DNA=list(N="N"), RNA=list(N="N"), AA=list(X="X"))
    }
    
    ## Null distributions for MI calculation
    B <- bases[[alpha]]
    NB <- length(B)
    marg <- data.frame(I=B, P=rep(1/NB,NB))
    joint <- data.frame(I=rep(B,each=NB), J=rep(B,times=NB), P=rep(1/NB,NB^2))
    if (MI=="true") marg$P <- joint$P <- 0
    
    ## Convert each sequence string to uppercase vector; basic integrity checks
    seqs <- lapply(seqs, function(x){ unlist(strsplit(toupper(x),'')) })  
    
    lens <- sapply(seqs, length)
    M <- lens[1]
    if (length(unique(lens)) > 1) stop("All sequences must be of same length (or be multiple-alignments)!\n")
    
    chars <- table(unlist(seqs))
    if (!all( names(chars) %in% c("-",names(degen[[alpha]]),names(ignore[[alpha]])) )) stop("Illegal characters detected: only alphabet-appropriate IUPAC DNA/AA letters (incl. degenerates) and '-' allowed!\n")
    N <- length(seqs)
		
    ## Matching functions (based on 'degen.match')
    fun.name <- ifelse(degen.match == -1, "DMn1", ifelse(degen.match == 0, "DM0", ifelse(degen.match == 1, "DM1", "DM2")))  # name of match function, below
    
    ## ########## MATCH SCORES: 4 = non-degen match, 3 = degen match, 2 = non-degen mismatch, 1 = non-ignored-gap/letter mismatch or disallowed degen match, 0 = unmatchable due to N/X (or -)
    match.fun <- list(  
        DMn1=function(L1,L2){  # no degenerate matches at all
            if (all(c(L1,L2) %in% bases[[alpha]])) {
                ifelse(L1==L2, 4, 2)
            } else if (L1==L2 & all(c(L1,L2) %in% degen[[alpha]])) {
                2
            } else if (any(c(L1,L2) %in% ignore[[alpha]])) {
                0
			} else if (L1=="-" | L2=="-") {  # if here, then not ignoring gaps
				1
    } else {
				2
    }
        },
        DM0=function(L1,L2){   # exact matches only, even for degenerates
            if (all(c(L1,L2) %in% bases[[alpha]])) {
                ifelse(L1==L2, 4, 2)
            } else if (L1==L2 & all(c(L1,L2) %in% degen[[alpha]])) {
                3
            } else if (any(c(L1,L2) %in% ignore[[alpha]])) {
                0
            } else if (L1=="-" | L2=="-") {  # if here, then not ignoring gaps
                1
            } else {
                2
            }
        },
        DM1=function(L1,L2){   # proper-subset matches only
            if (all(c(L1,L2) %in% bases[[alpha]])) {
                ifelse(L1==L2, 4, 2)
            } else if (L1==L2 & all(c(L1,L2) %in% degen[[alpha]])) {
                3
            } else if (any(c(L1,L2) %in% ignore[[alpha]])) {
                0
            } else if (L1=="-" | L2=="-") {  # if here, then not ignoring gaps
                1
            } else {   # degenerate-definition comparison
                sorted <- ternary (length(degen[[L1]])<=length(degen[[L2]]), list(degen[[L1]],degen[[L2]]), list(degen[[L2]],degen[[L1]]))  # smaller set goes first in list...
                ifelse(all(sorted[[1]] %in% sorted[[2]]), 4, 1)  # ...so that we can do this 
            }
        },
        DM2=function(L1,L2){   # any-intersection matches
            if (all(c(L1,L2) %in% bases[[alpha]])) {
                ifelse(L1==L2, 4, 2)
            } else if (L1==L2 & all(c(L1,L2) %in% degen[[alpha]])) {
                3
            } else if (any(c(L1,L2) %in% ignore[[alpha]])) {
                0
            } else if (L1=="-" | L2=="-") {  # if here, then not ignoring gaps
                1
            } else {   # degenerate-definition comparison
                ifelse(length(intersect(degen[[L1]],degen[[L2]])), 4, 1)
            }
        }
    )
    
    ## Begin sequence comparison
    IM("Comparing",N,"sequences...")
    matrices <- new.list(qw(distance,matches,reporting,report.pct,length,underflow,MI), elem=matrix(0, N, N, F, list(names(seqs),names(seqs))))
    aligned <- new.list(names(seqs), elem=new.list(names(seqs)))
    MI.blocks <- new.list(1:N, elem=new.list(1:N, elem=rep(FALSE,M)))
    
    for (s1 in 1:N) {        # sequence s1
        for (s2 in 1:N) {    # sequence s2
            if (s1 >= s2) {  # lower triangle of matrix only 
                MI.blocks[[s1]][[s2]] <- rep(FALSE,M)
                aligned[[s1]][[s2]] <- data.frame(x=rep("",M),y=rep("",M),Score=rep(NA,M),MI.use=rep(F,M))
                names(aligned[[s1]][[s2]])[1:2] <- c(names(seqs)[s1],names(seqs)[s2])
                for (p in 1:M) {   # position p in seq s1 - seq s2 alignment
                    
                    if (seqs[[s1]][[p]]=="-" & seqs[[s2]][[p]]=="-") {
                        if (aligns) aligned[[s1]][[s2]][p,] <- list(seqs[[s1]][[p]],seqs[[s2]][[p]],NA,FALSE)
                        next  # double-gap positions must be removed from further consideration
                    }
                    
                    ## ########## MATCH SCORES: 4 = non-degen match, 3 = degen match, 2 = non-degen mismatch, 1 = non-ignored-gap/letter mismatch or disallowed degen match, 0 = unmatchable due to N/X (or -)
                    matrices$length[s1,s2] <- matrices$length[s1,s2] + 1
                    score <- match.fun[[fun.name]](seqs[[s1]][[p]],seqs[[s2]][[p]])
                    if (score > 2) matrices$matches[s1,s2] <- matrices$matches[s1,s2] + 1
                    if (score != 0) matrices$reporting[s1,s2] <- matrices$reporting[s1,s2] + 1
                    if (score %in% c(4,2)) MI.blocks[[s1]][[s2]][[p]] <- TRUE   # able to use this position for MI calculation
                    
                    if (aligns) aligned[[s1]][[s2]][p,] <- list(seqs[[s1]][[p]],seqs[[s2]][[p]],score,MI.blocks[[s1]][[s2]][[p]])
                    
                    if (MI == "true") {   # Calculate true joint/marginal distributions, if specified
                        if (MI.blocks[[s1]][[s2]][[p]]) {   # in requiring this, ONLY those positions which contribute to joint probability are allowed to contribute to marginal probabilities
                            if (all(c(seqs[[s1]][[p]],seqs[[s2]][[p]]) %in% bases[[alpha]])) {
                                w1 <- which(marg[,1]==seqs[[s1]][[p]])
                                marg[w1,2] <- marg[w1,2] + 1
                                w2 <- which(marg[,1]==seqs[[s2]][[p]])
                                marg[w2,2] <- marg[w2,2] + 1
                                w3 <- which(joint[,1]==seqs[[s1]][[p]] & joint[,2]==seqs[[s2]][[p]])  # guaranteed to match; reciprocal letter pairs still exist in 'joint' at this stage
                                joint[w3,3] <- joint[w3,3] + 1
                            }
                        }
                    }
                }
            }
        }
    }
    
    gapless.len <- sapply(seqs, function(x) sum(x != "-") )
    for (s1 in 1:N) {        # sequence s1
        for (s2 in 1:N) {    # sequence s2
            if (s1 >= s2) {  # lower triangle of matrix only 
                if (matrices$reporting[s1,s2] < min.pos) {  # not enough absolute positions to go on
                    matrices$matches[s1,s2] <- 0  # zap
                    matrices$underflow[s1,s2] <- 1
                } else {
                    s1.pct <- matrices$reporting[s1,s2] / gapless.len[s1]
                    s2.pct <- matrices$reporting[s1,s2] / gapless.len[s2]
                    if (s1.pct < min.pct | s2.pct < min.pct) {  # not enough relative positions to go on
                        matrices$matches[s1,s2] <- 0  # zap
                        matrices$underflow[s1,s2] <- 2
                    }
                }
            }
        }
    }
    
    if (MI == "true") {
        joint$P <- joint$P / sum(joint$P)
        marg$P <- marg$P / sum(marg$P)
                                        # merge reciprocal entries in joint-probability distribution (e.g. merge A&C, C&A)
        for (i in 1:nrow(joint)) joint[i,1:2] <- as.list(sort(unlist(joint[i,1:2])))  # all reciprocal pairs get reoriented, e.g. (A,C) and (C,A) both become (A,C)
        joint <- joint2 <- aggregate(joint[,3], by=list(joint[,1], joint[,2]), sum)   # probabilities for reoriented reciprocal pairs now get summed into single probability
        joint2[,1:2] <- joint[,2:1]
        joint <- rbind(joint,joint2)  # after fixing reciprocal-pair probabilities, add reciprocals back to accelerate lookups
    }
    if (MI != "none") {
        IM("Calculating pairwise MI...")
        for (s1 in 1:N) {        # sequence s1
            for (s2 in 1:N) {    # sequence s2
                if (s1 >= s2) {  # lower triangle of matrix only 
                    use <- which(MI.blocks[[s1]][[s2]])
                    for (u in 1:length(use)) {
                        joint.prob <- joint[ joint[,1]==seqs[[s1]][[p]][use[u]] & joint[,2]==seqs[[s2]][[p]][use[u]] ,3]
                        marg1.prob <- marg[ marg[,1]==seqs[[s1]][[p]][use[u]], 2]
                        marg2.prob <- marg[ marg[,1]==seqs[[s2]][[p]][use[u]], 2]
                        matrices$MI[s1,s2] <- matrices$MI[s1,s2] + joint.prob * log( joint.prob / (marg1.prob * marg2.prob) )
                    }
                }
            }
        }
    }
    
    for (i in 1:length(matrices)) matrices[[i]] <- upper.triangle.fill(matrices[[i]])
    matrices$distance <- matrices$matches/matrices$reporting
    matrices$distance <- as.dist(1-zerofy(matrices$distance))
    matrices$report.pct <- matrices$reporting/matrices$length
    if (aligns) {
        c(matrices,list(alignments=aligned))
    } else {
        matrices
    }
}
