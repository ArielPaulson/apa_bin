

apa.names$dev <- c(apa.names$dev, "PCA.basic")
PCA.basic <- function(mat, method=c("cor","cov"), norm=c("scale","center","none"), drop.PC=NULL, rotate=NA, use=c("pairwise.complete.obs","complete.obs","na.or.complete","all.obs","everything"), ...) {
    
    ## Basic PCA function
	## Operates on columns, not rows
	## 'drop.PC' indicates PCs to exclude from the analysis:
    ##   In general, use 'drop.PC=1' when doing PCA on RNAseq data.  PC 1 captures within-sample variation while PCs 2-N will actually discriminate between samples.
	##   In some cases, batch effects may dominate the first 2 components; to remove use "drop.PC=1:2".
    
#    require(GPArotation)
    norm <- match.arg(norm)
    method <- match.arg(method)
    use <- match.arg(use)
    N <- ncol(mat)
    func <- get(method)
    etc <- list(...)
    
    if (norm == "scale") {
        scaled <- scale(mat)  # column centering is automatic with scaling (recommended)
    } else if (norm == "center") {
        scaled <- t( t(mat)-colMeans(mat) )  # column centering only
    } else {
        scaled <- mat  # nothing (not recommended...)
    }
    CO <- func(scaled, use=use)
    
    E <- eigen(CO)
    if (length(drop.PC)>0) {
        ## Exclude these components from analysis
		use.PC <- setdiff(1:N, drop.PC)
        E$vectors <- E$vectors[,use.PC]
        E$values <- E$values[use.PC]
    }
    P <- length(E$values)  # number of PCs in use
    dimnames(E$vectors) <- list(colnames(mat), paste("PC",1:P))
    names(E$values) <- colnames(E$vectors)
    prop.var <- percentify(E$values)
    cum.var <- cumsum(prop.var)
    stdev <- sqrt(E$values)
    scores <- scaled %*% E$vectors
    proj <- t(t(E$vectors)*stdev)   # a.k.a loadings
#	scores <- cor(t(mat), proj)  # correlate expression profiles to components
 	
    if (!is.na(rotate)) {
    }
	
	## to reconstruct scaled input from fewer PCs:   E$vectors[,1:N] %*% t(scores)	
	## to reconstruct cor/cov matrix from fewer PCs: E$vectors[,1:N] %*% diag(x=E$values[1:N]) %*% t(E$vectors[,1:N])
	
    output <- list(
        input.data=mat, scale.data=scaled, matrix=CO,
        eigenvectors=E$vectors, eigenvalues=E$values, 
        st.dev=stdev, variance.per=prop.var, cumulative.variance=cum.var,
        gene.scores=scores, sample.projections=proj,
        methods=list("norm"=norm,"method"=method,"use"=use,"rotate"=rotate,"drop.PC"=drop.PC,"..."=etc)
    )
    
    invisible(output)
}


apa.names$dev <- c(apa.names$dev, "PCA.project")
PCA.project <- function(pca, x, project=c("genes","samples")) {
    
    ## Project a matrix or vector of values 'x' into an existing PCA space 'pca'
    ## Returns 'pca' with new stuff added
    ## 'project.dim' indicates dimension to project:
    ##   1 = rows; projects rows of 'x' into PCs of 'pca'
    ##   2 = cols; projects cols of 'x' into gene scores of 'pca'
    
    project <- match.arg(project)
    if (!is.matrix(x)) {
        if (project=="genes") {
            x <- matrix(x, nrow=1)  # assuming single-gene vector
        } else if (project=="samples") {
            x <- matrix(x)  # assuming single-sample vector
        }
    }
    
    if (project=="genes") {
        
        ## must scale new genes (new sample subsets, basically) relative to original samples' parameters
        if (pca$methods$norm == "scale") {
            y <- t( ( t(x)-colMeans(pca$input.data) )/apply(pca$input.data,2,sd) )
        } else if (pca$methods$norm == "center") {
            y <- t( ( t(x)-colMeans(pca$input.data) ) )
        } else if (pca$methods$norm == "none") {
            y <- x
        } else {
            stop(paste0("No handlers for normalization method '",pca$methods$norm,"': cannot proceed!\n"))
        }
        
        ## project new genes into existing basis
        z <- y %*% pca$eigenvectors
        pca$projected.genes <- list( input.data=x, scale.data=y, gene.scores=rbind(pca$gene.scores,z) )
        
    } else if (project=="samples") {
        
        ## scaling is relative to sample
        if (pca$methods$norm == "scale") {
            y <- scale(x)
        } else if (pca$methods$norm == "center") {
            y <- t( t(x)-colMeans(x) )
        } else if (pca$methods$norm == "none") {
            y <- x
        } else {
            stop(paste0("No handlers for normalization method '",pca$methods$norm,"': cannot proceed!\n"))
        }
        
        ## construct synthetic sample projections for extraneous samples
        ## ONLY WORKS ONE SAMPLE AT A TIME -- so apply on columns
        z <- t(apply(y, 2, function(s) {
            initial <- t(s) %*% pca$gene.scores
            eigenscale <- (t(pca$scale.data) %*% pca$gene.scores / pca$eigenvectors)[1,]  # don't remember where I got this from, but it works: try reprojecting original samples.
            t( t(initial)/eigenscale )
        }))
        pca$projected.samples <- list( input.data=x, scale.data=y, eigenvectors=rbind(pca$eigenvectors,z) )
    }
    
    pca
}


apa.names$dev <- c(apa.names$dev, "PCA.plots")
PCA.plots <- function(pca, type=c("var","covcor","scores","scree","scree.percent","scree.cumulative","components",
                               "sample","sample.rgl","sample.svm","sample.rgl.svm","gene","gene.rgl","legend"),
                      PCx=NULL, PCy=NULL, PCz=NULL, labels=FALSE, smooth=FALSE, col=NULL, main=NULL, cex=1,
                      hulls=FALSE, projected=FALSE, viewpoint=NULL, svm.class=NULL, size=3, border=FALSE, ...) {
    
    ## ADD: xlim=NULL, ylim=NULL
    
    ## Input is the output list from 'PCA.basic'
    ## Variously plots 2D, 3D sample projections, scores biplots
    
    type <- match.arg(type)
    others <- list(...)
    if (projected) {
        if (grepl("sample",type)) {
            ev <- pca$projected.samples$eigenvectors
        } else if (grepl("gene",type) | type=="scores") {
            gs <- pca$projected.genes$gene.scores
        }
    } else {
        ev <- pca$eigenvectors
        gs <- pca$gene.scores
    }
    P <- ncol(ev)
    S <- nrow(ev)
    pcols <- if (P <= 8) { 1:8 } else { rainbow(P+1)[1:P] }  # principal component colors
    sp <- pca$sample.projections
    vp <- pca$variance.per
    vpr <- round(100*vp,2)
    out <- list()  # may have invisible output data
    
    plot.svm <- FALSE
    if (grepl("\\.svm$",type)) {
        if (length(svm.class)==ncol(pca$input.data)) {
            require(e1071)
            plot.svm <- TRUE
            type <- sub("\\.svm$","",type)
            if (!is.factor(svm.class)) svm.class <- as.factor(svm.class)
        } else {
            stop(paste0("length(svm.class) (",length(svm.class),") does not match ncol(pca$input.data) (",ncol(pca$input.data),")!\n"))
        }
    }
    
    if (length(col)>1) {
        scols <- col  # sample (or gene) colors
    } else if (length(col)==1) {
        scols <- rep(col,S)  # sample (or gene) colors
    } else {
        scols <- if (S <= 8) { 1:8 } else { rainbow(S+1)[1:S] }  # sample (or gene) colors
    }
    scols[is.na(scols)] <- 0
    if (is.logical(labels[1])) {
        custom.labels <- c()
    } else {
        custom.labels <- labels
        labels <- TRUE
    }
    
    if (type == "var") {
        ## Within/between-samples variances plot
        if (length(main)==0) main <- "Log2 Variance Distributions"
        lvars <- lapply(list(Within.Samples=apply(pca$input,2,var), Between.Samples=apply(pca$input,1,var)), log2)
        dhist(lvars, main=main, col=2:3, cex=cex, legend=NA)
        abline(v=sapply(lvars,function(x) mean(real(x)) ), lty=3:3, col=2:3)
        legend("topleft", bty="n", col=c(2,3,1), lty=c(1,1,3), legend=c(names(lvars),"Means"))
    }
    
    if (type == "covcor") {
        ## Sample cor/cov plot
        if (length(main)==0) main <- paste("Sample",label)
        CO <- pca$matrix; diag(CO) <- NA
        label <- ifelse(pca$methods["Method"] == "cor", "Correlations", "Covariances")
        mipu(CO, main=main)
    }
    
    if (type == "scores") {
        ## Scores-per-component heatmap
        if (length(main)==0) main <- "Gene Scores per PC"
        scores.hc <- hclust(dist(pca$gene.scores),"average")
        mipu(pca$gene.scores[scores.hc$order,], pal="CKY", main=main)
    }
    
    if (type == "scree") {
        ## Scree plot
        if (length(main)==0) main <- "Eigenvalues (Variances) per PC"
        lineplot(pca$eigenvalues, pch=1, col=2, cex=cex, main=main, las=1, xlab="Components")
    }
    
    if (type == "scree.percent") {
        ## Scree plot, as percent total
        if (length(main)==0) main <- "Percent Total Variance per PC"
        lineplot(pca$variance.per, pch=1, col=2, cex=cex, main=main, las=1, xlab="Components")
    }
    
    if (type == "scree.cumulative") {
        ## Scree plot, as cumulative total
        if (length(main)==0) main <- "Cumulative Variance"
        lineplot(pca$cumulative.variance, pch=1, col=2, cex=cex, main=main, las=1, xlab="Components")
    }
    
    if (type == "loadings") {
        ## PC lineplot
        if (length(main)==0) main <- "Eigenvectors (Loadings)"
        lineplot(pca$eigenvectors, col=pcols, cex=cex, main=main, las=1)
    }
    
    if (type == "legend") {
        ## Legend plots
        # have to figure out what kind of legend?
        if (length(main)==0) main <- ""
        null.plot(xlim=c(0,10), ylim=c(0,10))
        stop("'legend' style not ready yet!\n")
        ## ######################
    }
    
    ######## SAMPLE PLOTS
    
    if (type == "sample" & is.null(PCz) & !smooth) {
        ## 2D sample plots, points
        if (length(main)==0) main <- "Sample Projections"
        pclabs <- c( paste0("PC",PCx," (",vpr[PCx],"%)"), paste0("PC",PCy," (",vpr[PCy],"%)") )
        plot(sp[,c(PCx,PCy)], col=0, xlab=pclabs[1], ylab=pclabs[2], xlim=extend.xylim(sp[,PCx],0.03), ylim=extend.xylim(sp[,PCy],0.03), main=main, ...)
        abline(h=0, v=0, lty=size, col=8)
        if (border) {
            points(sp[,c(PCx,PCy)], pch=21, col=1, bg=scols, cex=size*cex)
        } else {
            points(sp[,c(PCx,PCy)], pch=19, col=scols, cex=size*cex)
        }
        if (labels) text(sp[,PCx], sp[,PCy], rownames(sp))
        if (hulls) {
            poly <- mat.split(sp[,c(PCx,PCy)], scols)  # split points by color; that is the only grouping vector we have to go on
            for (i in 1:length(poly)) {
                poly[[i]] <- poly[[i]][chull(poly[[i]]),]
                for (j in 1:nrow(poly[[i]])) {
                    j2 <- ifelse(j<nrow(poly[[i]]), j+1, 1)
                    segments(poly[[i]][j,1],poly[[i]][j,2], poly[[i]][j2,1],poly[[i]][j2,2], col=names(poly)[i], lwd=size)
                }
            }
        }
    }
    
    if (type == "sample" & is.null(PCz) & smooth) {
        ## 2D sample plots, smooth
        require(smoothScatter)
        if (length(main)==0) main <- ""
        ## ######################
    }
    
    if (type == "sample" & !is.null(PCz)) {
        ## 3D sample plots, static
        require(scatterplot3d)
        if (length(main)==0) main <- ""
        ## ######################
        ## OR dynamic, with viewpoint and auto-screenshot??
    }
    
    if (type == "sample.rgl" & !is.null(PCz)) {
        ## 3D sample plots, dynamic
        require(rgl)
        if (length(main)==0) main <- ""
        vp <- round(100*pca$variance.per,1)
        pclabs <- c( paste0("PC",PCx,"\n(",vpr[PCx],"%)"), paste0("PC",PCy,"\n(",vpr[PCy],"%)"), paste0("PC",PCz,"\n(",vpr[PCz],"%)") )
        lims <- apply(sp[,c(PCx,PCy,PCz)], 2, extendrange, f=0.075)  # capture limits BEFORE possible point removal
        remove <- scols==0
        IM(sum(remove),length(remove))
        if (any(remove)) {
            ## scols==0 points aren't meant to be visible, but rgl() shading will make them visible.
            ## so, we have to remove these points entirely, but preserve original plot xyz limits (captured above)
            sp <- sp[!remove,]
            scols <- scols[!remove]
            custom.labels <- custom.labels[!remove]
        }
        plot3d(sp[,PCx], sp[,PCy], sp[,PCz], pclabs[1], pclabs[2], pclabs[3], "s", scols, size, xlim=lims[,1], ylim=lims[,2], zlim=lims[,3])
        if (labels) {
            if (length(custom.labels)==0) custom.labels <- rownames(sp)
            text3d(sp[,PCx], sp[,PCy], sp[,PCz], custom.labels, adj=c(0.5,-1.5), col=scols)
        }
        if (hulls) {
            poly <- mat.split(sp[,c(PCx,PCy,PCz)], scols)  # split points by color; that is the only grouping vector we have to go on
            for (i in 1:length(poly)) {
                ## we aren't actually going to calculate 3D hulls; all points of one color will be connected with lines of that color.  So network, not hull
                for (j in 1:nrow(poly[[i]])) {
                    for (k in 1:nrow(poly[[i]])) {
                        if (j==k) next
                        lines3d(poly[[i]][c(j,k),1], poly[[i]][c(j,k),2], poly[[i]][c(j,k),3], col=names(poly)[i], lwd=size)
                    }
                }
            }
        }
        if (length(viewpoint)>0) do.call(rgl.viewpoint, viewpoint)
        if (plot.svm) {
            dat <- cbind(x=sp[,PCx], y=sp[,PCy], z=sp[,PCz])
            dat <- data.frame(dat, cl=svm.class)
            svm.model <- svm(cl~x+y+z, dat, type='nu-classification', kernel='linear', scale=FALSE)
            svm.pred <- predict(svm.model, dat[,-4])
            print(table(pred=svm.pred, true=dat[,4]))
            w <- t(svm.model$coefs) %*% svm.model$SV
            out$svm <- list(data=dat,model=svm.model,predict=svm.pred,hyperplane=c(w,-svm.model$rho))
            planes3d(w[1], w[2], w[3], -svm.model$rho, color="black", alpha="0.3")
        }
        ## rgl.viewpoint( theta = 0, phi = 15, fov = 60, zoom = 1, scale = par3d("scale"), interactive = TRUE, userMatrix )
    }
    
    ######## GENE PLOTS
    
    if (type == "gene" & is.null(PCz) & !smooth) {
        ## 2D gene plots, points
        if (length(main)==0) main <- "Gene Scores"
        pclabs <- c( paste0("PC",PCx," (",vpr[PCx],"%)"), paste0("PC",PCy," (",vpr[PCy],"%)") )
#        plot(gene.scores[,c(PBa,PCy)], col=0, xlab=pclabs[1], ylab=pclabs[2])
        plot(gene.scores[,c(PCx,PCy)], col=0, xlab=pclabs[1], ylab=pclabs[2], main=main)
        abline(h=0, v=0, lty=size, col=8)
#        points(gene.scores[,c(PBa,PCy)], pch=19, col=scols, cex=size*cex)
        points(gene.scores[,c(PCx,PCy)], pch=19, col=scols, cex=size*cex)
        if (labels) text(sp[,PCx], sp[,PCy], rownames(sp))
    }
    
    if (type == "gene" & is.null(PCz) & smooth) {
        ## 2D gene plots, smooth
        require(smoothScatter)
        if (length(main)==0) main <- ""
        ## ######################
    }
    
    if (type == "gene" & !is.null(PCz)) {
        ## 3D gene plots, static
        require(scatterplot3d)
        if (length(main)==0) main <- ""
        ## ######################
    }
    
    if (type == "gene.rgl" & !is.null(PCz)) {
        ## 3D gene plots, dynamic
        require(rgl)
        if (length(main)==0) main <- ""
        vp <- round(100*pca$variance.per,1)
        pclabs <- c( paste0("PC",PCx,"\n(",vpr[PCx],"%)"), paste0("PC",PCy,"\n(",vpr[PCy],"%)"), paste0("PC",PCz,"\n(",vpr[PCz],"%)") )
        plot3d(gs[,PCx], gs[,PCy], gs[,PCz], pclabs[1], pclabs[2], pclabs[3], "s", scols, 0.5)
        if (labels) text3d(gs[,PCx], gs[,PCy], gs[,PCz], rownames(gs), adj=c(0.5,-1.5), col=scols)
        rgl.spheres(0, 0, 0, col=4, radius=0.1)
    }
    
    invisible(out)
}


apa.names$dev <- c(apa.names$dev, "PCA.explain")
PCA.explain <- function(pca, factors) {
    
    ## Takes a data.frame of factors and quantitates the degree to which each PC separates levels of each factor
    ## 'pca' is an output of PCA.basic()
    ## 'factors' is a length-2 list: elem 1 is a vector of factor types ("categorical" or "numeric"); elem 2 is a data.frame with samples on rows and factors on columns
    
    
    
    
    
}


apa.names$dev <- c(apa.names$dev, "PCA.relevant.genes")
PCA.relevant.genes <- function(pca, steps=100, score.cutoff=NA, drop.PC1=FALSE, cex=1) {
    
    ## Concept from "Interactive Exploration of Microarray Gene Expression Patterns in a Reduced Dimensional Space", Misra et al. 2002, Genome Research.
    ## Filter irrelevant genes out of a PCA by using max score value per gene.
    ## Compare change in score coords of retained genes in full-pca vs. filtered-pca, by squared error.
    ## Want to maximize gene removal while minimizing squared error.
    ##
    ## 'pca' is an output from PCA.basic(); preferably using all genes.
    ## 'steps' indicates the number of iterations made while filtering from min score value to max score value.
    ##  - resulting plot indicates where cutoff should be made.
    ## 'score.cutoff' reruns the procedure with a static cutoff and shows results.  Will not run 'steps' iterations.
    ## 'drop.PC1' for consistency with PCA.basic() methods.
    
    gs <- pca$gene.scores
    gs <- gs[match(rownames(pca$input),rownames(gs)),]  # just in case gene.scores row order changes (to clustered) in the future
    lmax <- apply(abs(gs),1,max)
    xseq <- seq(0, steps, length.out=10)
    xlab <- seq(min(lmax), max(lmax), length.out=10)
    ylab.g <- seq(1, nrow(gs), length.out=10)
    
    par(mar=c(5,4,4,4), las=1, cex=cex)
    if (!is.na(score.cutoff)) {
    } else {
        bins <- seq(min(lmax), max(lmax), length.out=steps)
        bin.dat <- new.list(1:steps)
        for (i in 1:steps) {
            w <- which(lmax>=bins[i])
            inp <- pca$input[w,,drop=FALSE]
            gsi <- try(PCA.basic(inp, drop.PC1=drop.PC1)$gene.scores, silent=TRUE)
            if (class(gsi)=="try-error") {  # pca fail -- too few genes
                bin.dat[[i]] <- list(gene.scores.in=data.frame(), gene.scores.out=data.frame(), sq.diff=NA)
            } else {
                bin.dat[[i]] <- list(gene.scores.in=gs[w,], gene.scores.out=gsi, residuals=lm(gs[w,]~gsi)$residuals)
            }
        }
        results <- t(sapply(bin.dat, function(x) c(GENES=nrow(x$gene.scores.out), MSQD=sum(x$residuals)) ))
        ylab.d <- seq(min(results[,2],na.rm=TRUE), max(results[,2],na.rm=TRUE), length.out=10)  # FIRST
        for (i in 1:2) { results[,i] <- results[,i]-min(results[,i],na.rm=TRUE); results[,i] <- results[,i]/max(results[,i],na.rm=TRUE) }  # SECOND
        plot(1:steps, results[,1], col=4, type="l", xlab="Genewise Max Score", ylab="", main="", xaxt="n", yaxt="n")
        lines(1:steps, results[,2], col=2)
        axis(1, xseq, labels=round(xseq,4))
        axis(2, seq(0,1,length.out=10), labels=round(ylab.g,0), col=4)
        axis(4, seq(0,1,length.out=10), labels=round(ylab.d,0), col=2)
    }
    
    invisible(results)
    
    
}


apa.names$dev <- c(apa.names$dev, "PCA.score.plots")
PCA.score.plots <- function(mat, plot=TRUE, adjust.1=FALSE, min.radii=0, cut.radians=0, top.n=0, coloration=c("radial","density"), select=NULL) {
    
    ## Concept from "Interactive Exploration of Microarray Gene Expression Patterns in a Reduced Dimensional Space", Misra et al. 2002, Genome Research.
    ## Multifunction function for extracting major trends and critical genes from PCA scores.
    ## Takes 2 component gene score vectors at a time, as a 2-col matrix (i.e. gene scores on PC1 & PC2)
    ## Provides a biplot, a radially-unwrapped biplot and densities for r, theta values
    ## Can opt to drop points below a given radius (set 'min.radii')
    ## Can opt to rotate the unwrapped plot, if a structure crosses the 0/2pi boundary (set 'cut.radians')
    ## Can opt to define/quantitate the top N radial structures detectable by kernel density (set 'top.n')
    ## 
    ## 'plot': generates plots if TRUE (otherwise, will still return data invisibly)
    ## 'min.radii': a number >= 0.  Does nothing if 0.
    ## 'cut.radians': a value between 0 and 2pi, or "auto" to cut & rotate based on point of lowest radial density.
    ## 'top.n': detect & quantitate the top N radial structures (or as many as can be found, if < N exist).
    ##          detection uses kernel density on theta values and takes values of the top.n positive modes ranked by peak height.
    ## 'select': a list of length='top.n', values are numeric ranges (min,max); theta-positions of selections may be adjusted by specifying new ranges here
    ##           for instance, if selection 3 chose theta range = c(0,0.3926991), you can shift it 0.1 by making element 3 of 'select' = c(0.1,0.4026991)
    
    coloration <- match.arg(coloration)
    if (top.n > 0) cut.radians <- "auto"   # not guaranteed a useful visual arrangement of radial structures unless cut.radians="auto"
    if (adjust.1) mat[,1] <- mat[,1]-max(mat[,1])
    rth <- t( apply(mat, 1, xy2polar) )[,2:1]
    mat <- mat[order(rth[,1]),]
    rth <- rth2 <- rth[order(rth[,1]),]
    if (coloration == "density") {
        col <- rainbow(nrow(mat))
    } else {
        rcols <- rainbow(1000)
        rbins <- seq(0,2*pi,length=1001)[1:1000]  # because 2pi itself == 0, so don't double-count it, just to be proper
        col <- rcols[match(quantize(rth[,1],rbins),rbins)]
    }
    xseq <- seq(0, 2*pi, 0.125*pi)
    xlab <- rep("",length(xseq)); xlab[seq(1,length(xseq),2)] <- c("0","pi/4","pi/2","3pi/4","pi","5pi/4","3pi/2","7pi/4","2pi")
    ## rearrange rth rows, xseq to break across 'brk' instead of the 0/2pi boundary
    brk <- ifelse(cut.radians=="auto", quantize(min(modes(rth[,1])$neg[,1]), xseq), cut.radians)
    if (brk == 2*pi) brk <- 0
    if (brk == 0 | brk == 2*pi) {
        xlab2 <- xlab
        col2 <- col
        matchlab <- c("0","pi/2","pi","3pi/2","2pi")
    } else {
        wx1 <- which(xseq<brk); wx2 <- which(xseq>=brk)
        wx <- c(wx2[-length(wx2)],wx1,wx2[1])  # remove last wx2 -- 2pi -- now redundant.  New first element copied to last
        xlab2 <- xlab[wx]
        matchlab <- c("0","pi/2","pi","3pi/2")
        wr1 <- which(rth[,1]<brk); wr2 <- which(rth[,1]>=brk)
        wr <- c(wr2,wr1)
        col2 <- col[wr]
        rth2[wr1,1] <- rth2[wr1,1]+2*pi
        rth2[,1] <- rth2[,1]-brk
        rth2 <- rth2[wr,]
        for (i in 1:length(select)) {  # 'select' coords must be shifted, too
            if (length(select[[i]])==2) select[[i]] <- select[[i]]+2*pi-brk
        }
    }
    mat.1 <- mat; rth.1 <- rth; rth2.1 <- rth2; col.1 <- col; col2.1 <- col2  # "uncut" versions, just in case
    ## select points beyond N radii
    if (min.radii > 0) {
        ## rth-linked cuts
        mat <- mat[rth[,2]>=min.radii,,drop=FALSE]
        col <- col[rth[,2]>=min.radii]
        rth <- rth[rth[,2]>=min.radii,,drop=FALSE]
        ## rth2-linked cuts
        col2 <- col2[rth2[,2]>=min.radii]
        rth2 <- rth2[rth2[,2]>=min.radii,,drop=FALSE]
    }
    ## find top N radial structures
    if (top.n > 0) {
        m <- modes(rth2[,1], adjust=pi/8)$pos
        if (top.n > nrow(m)) {
            message("top.n value '",top.n,"' exceeds number of modes '",nrow(m),"': reducing to ",nrow(m),".")
            top.n <- nrow(m)
        }
        m <- m[rev(order(m[,2])),,drop=FALSE]
        top.rad <- new.list(1:top.n)
        for (i in 1:top.n) {
            if (length(select)>=i) {
                if (length(select[[i]])==2) top.rad[[i]] <- select[[i]]   # custom window: override automatic selection
            } else {
                top.rad[[i]] <- c(m[i,1]-pi/16, m[i,1]+pi/16)   # window of width pi/8 centered on mode
            }
        }
        top.rth2 <- lapply(top.rad, function(x) which(rth2.1[,1]<=x[2] & rth2.1[,1]>=x[1]) )
        top.rth <- lapply(top.rth2, function(x) match(rownames(rth2.1)[x],rownames(rth.1)) )
        top.points <- lapply(1:top.n, function(i) list( mat=mat.1[top.rth[[i]],], rth=rth.1[top.rth[[i]],], rth2=rth2.1[top.rth2[[i]],], col=col2.1[top.rth2[[i]]] ) )
    } else {
        m <- NULL
        top.points <- c()
    }
    ## continue plotting
    yseq <- 0:ceiling(max(rth2[,2]))
    if (plot) {
        par(mfrow=c(2,2), mar=c(4,4,3,1))
        ## scores biplot
        smax <- max(abs(c( floor(min(mat)), ceiling(max(mat)) )))
        plot(mat, col=col, xlim=c(-smax,smax), ylim=c(-smax,smax), xlab=paste(colnames(mat)[1],"scores"), ylab=paste(colnames(mat)[2],"scores"))
        symbols(rep(0,smax), rep(0,smax), circles=1:smax, fg=8, add=TRUE, inches=FALSE)
        abline(h=0, v=0)
        if (brk != 0) {
            cx <- smax*cos(brk)
            cy <- smax*sin(brk)
            segments(0,0, cx,cy, col=8, lty=3)  # plot cut point
#            text(cx, cy, "Cut Point")
        }
        ## radially-unwrapped scores biplot
        null.plot(xlim=range(xseq), ylim=range(yseq), xlab="radians", ylab="radii")
        axis(1, xseq, xlab2); axis(2, yseq, las=1)
        points(rth2, col=col2)
        abline(h=yseq, col=8)
        abline(v=xseq[match(matchlab,xlab2)], col=1)
        if (top.n > 0) {
            for (i in 1:top.n) {
                rect(min(top.points[[i]]$rth2[,1]),0, max(top.points[[i]]$rth2[,1]),smax, col="#88888844", border=NA)
                mtext(paste0("#",i), side=3, line=0, at=mean(top.points[[i]]$rth2[,1]), col=1)
            }
        }
        ## radial selections, if any (otherwise blank)
        null.plot(xlim=c(0,10), ylim=c(0,10))
        if (top.n > 0) {
            titles <- c("N","Radians","Height","Points",paste("Above",min.radii))
            x.pos <- c(N=0.5, Radians=2, Height=4, Points=6, Above=8)
            y.pos <- seq(0,10,length.out=top.n+1)
            revi <- top.n:1
            for (i in 1:top.n) {
                i.pts <- top.points[[i]]$rth
                x.text <- list(N=i, Radians=round(m[i,1],3), Height=round(m[i,2],3), Points=nrow(i.pts), Above=sum(i.pts[,2]>=min.radii))
                jmax <- ifelse(min.radii>0, 5, 4)
                i.col <- top.points[[i]]$col[round(nrow(i.pts)/2,0)]
                for (j in 1:jmax) text(x.pos[j], y.pos[revi[i]], x.text[j], col=i.col)
            }
            for (j in 1:jmax) text(x.pos[j], y.pos[top.n+1], titles[j], font=2)
        }
        ## radial density histogram
        dhist(rth2, adjust=pi/8, col=c(2,4), xlim=range(xseq), xaxt="n", xlab="", main="", ylab="Radial Densities of Scores", legend=NA)
        legend("topright", bty="n", col=c(0,4,2), lty=1, legend=c("","r","theta"))
        axis(1, xseq, xlab2, col=2)
        axis(3, 0:smax, labels=0:smax, col=4, line=-1)
    }
    invisible(list(r.theta=rth,selections=top.points))  # NOT rth2
}


apa.names$dev <- c(apa.names$dev, "PCA.factor.eval")
PCA.factor.eval <- function(PCs, facs, separation=c("none","full"), nshuf=100, anova=FALSE) {

    ##### later, separation=c("none","sig","full")
    ## 'pca' = output of PCA.basic()
    ## 'facs' = data.frame of explanatory factors (samples on rows, same order as 'PCs')
    ## Returns data for how well said factor(s) explain each PC, also how well (or if) any pair of PCs separates the levels of a given factor.
    
    separation <- match.arg(separation)
#    PCs <- pca$sample.projections
    P <- ncol(PCs)
    nlev <- sapply(facs,luniq)
    if (any(nlev==1)) message(paste(sum(nlev==1),"factors had only one level!  Ignoring these...\n"))
    facs <- facs[,nlev>1]
    F <- ncol(facs)
    message(paste0(F," factors\n",P," PCs\nRegressing on real and ",nshuf," shuffled factors..."))
    is.fac <- which(sapply(facs,is.factor))
    F2 <- length(is.fac)
    
    ## Correlate factors
    fac2corr <- do.call(cbind,lapply(facs,as.numeric))
    rownames(fac2corr) <- rownames(facs)
    fcorr <- suppressWarnings(cor(fac2corr, use="pairwise.complete.obs", method="spearman"))  # get rid of "standard deviation is zero" stuff
    output <- list(factor.corr=fcorr)
    
    ## Regress factors to PCs
    regression <- TRUE  # for code testing only
    if (regression) {
        reg.data <- lapply(1:P, function(p) {
            message(paste0("PC",p))
            pf <- lapply(1:F, function(i) {
                l <- lm(PCs[,p]~facs[[i]])
                fake.stats <- t(sapply(1:nshuf, function(n) {
                    l2 <- lm(PCs[,p]~sample(facs[[i]], length(facs[[i]])))
                    ars <- max(c(summary(l2)$adj.r.squared,0))
                    aop <- ifelse(anova, anova(l2)[[5]][[1]], NA)
                    c(adj.r.squared=ars, anova.p=aop)
                }))
                lm.sum <- summary(l)
                anova.res <- if (anova) { anova(l) } else { NA }
                ars <- max(c(lm.sum$adj.r.squared,0))
                aop <- ifelse(anova, anova.res[[5]][[1]], NA)
                list(
                    stats=list( adj.r.squared=ars, anova.p=aop ),
                    real=list( lm=l, sum=lm.sum, anova=anova.res ),
                    shuf=fake.stats
                )
            })
            names(pf) <- colnames(facs)
            pf
        })
        names(reg.data) <- colnames(PCs)
        
        r2.tab <- r2.tab2 <- t(sapply(reg.data, function(x) sapply(x, function(y) ifelse(length(y)==1,NA,y$stats$adj.r.squared) )))
        for (i in 1:P) { for (j in 1:F) {
            if (quantile(reg.data[[i]][[j]]$shuf[,1],0.95)>r2.tab[i,j]) r2.tab2[i,j] <- 0   # if shuffled beat observed, delete observed
        } }
        p.tab <- p.tab2 <- t(sapply(reg.data, function(x) sapply(x, function(y) ifelse(length(y)==1,NA,y$stats$anova.p) )))
        if (anova) {
            for (i in 1:P) { for (j in 1:F) {
                if (quantile(reg.data[[i]][[j]]$shuf[,2],0.05)<p.tab[i,j]) p.tab2[i,j] <- 1     # if shuffled beat observed, delete observed
            } }
        }
        
        #### WORKING ON THIS -- PER PC, PROVIDE A SHORT-LIST OF EXPLANATORY FACTORS & WEIGHTS
        pc.exp <- lapply(as.list(as.data.frame(t(r2.tab2))), function(x){ names(x)=colnames(r2.tab2); rev(sort(x[x>0])) })
        fac.exp <- lapply(as.list(as.data.frame(r2.tab2)), function(x){ names(x)=rownames(r2.tab2); rev(sort(x[x>0])) })
        for (i in which(sapply(pc.exp,length)==0)) pc.exp[[i]] <- NA
        for (i in which(sapply(fac.exp,length)==0)) fac.exp[[i]] <- NA
        
        output <- c(output, list(regression=list(r2=r2.tab, p=p.tab, r2.filtered=r2.tab2, p.filtered=p.tab2, pc.exp=pc.exp, fac.exp=fac.exp, data=reg.data)))
    }
    
    ## Test all pairs of PCs for ability to separate levels of each CATEGORICAL factor
    if (separation != "none") {
        ndim <- 2  # currently, will only support 2-D separation
        ncr <- t(combn(ncol(PCs),ndim))
        rownames(ncr) <- apply(ncr,1,paste,collapse="-")
        ncr.per.fac <- matrix(TRUE, nrow(ncr), F, FALSE, list(rownames(ncr),colnames(facs)))
        
        if (separation == "sig") {
            
            
            ############# THIS MODE DOES NOT WORK CORRECTLY
            
            
            ncr.per.fac[1:length(ncr.per.fac)] <- FALSE
            for (i in 1:F) {
                hi.PCs <- which(r2.tab2[,i]>0)
#                IM(i, hi.PCs)
                if (length(hi.PCs)>1) {
                    ## multiple high-r2 PCs found: restrict to pairs of these
                    keep <- which(rowSums(apply(ncr, 2, function(x) x%in%hi.PCs ))==ndim)
                } else if (length(hi.PCs)>1) {
                    ## only one high-r2 PC found: restrict to any pair with this
                    keep <- which(rowSums(apply(ncr, 2, function(x) x%in%hi.PCs ))>0)
                } else {
                    ## no high-r2 PCs found: search all pairs
                    keep <- 1:nrow(ncr)
                }
                ncr.per.fac[keep,i] <- TRUE
            }
        }
        ncr.per.fac <- ncr.per.fac[,is.fac]  # only using this subset below
#        for (i in 1:nrow(ncr.per.fac)) IM(ncr.per.fac[i,])
#        IM(colSums(ncr.per.fac))
        ncr2 <- ncr[rowSums(ncr.per.fac)>0,]   # matrix of PC pairs; rownames are "PCA-PCB", col 1 = PCA, col 2 = PCB
        
        message(paste("Testing",nrow(ncr2),"PC pairs for level separation..."))
        sep.data <- lapply(1:nrow(ncr2), function(i) {
            IM(i)
            test.facs <- is.fac[which(ncr.per.fac[i,])]  # subset of is.fac which is considered 'testable' on this PC combo
            hull.sep <- lapply(test.facs, function(f) {
                
                samp.ok <- !is.na(facs[,f]) & facs[,f]!=""
                maxf <- max(as.numeric(facs[samp.ok,f]))
                PCs.all <- PCs[samp.ok,ncr2[i,],drop=FALSE]
                
                superhull <- PCs.all[chull(PCs.all),]  # hull for all points
                super.area <- polyarea(superhull[,1], superhull[,2])
                ## instead of using actual superhull area, calculate median of all leave-one-out superhull areas, to reduce impact of outlier vertices
                super.area.mLOO <- median(sapply(1:nrow(superhull), function(i) polyarea(superhull[-i,1], superhull[-i,2]) ))
                
                cmn <- colMin(PCs.all)
                cmx <- colMax(PCs.all)
                space <- rbind(c(cmn),c(cmx[1],cmn[2]),c(cmx),c(cmn[1],cmx[2]))
                space.hull <- space[chull(space),]
                space.area <- polyarea(space.hull[,1],space.hull[,2])
                
                PCs.by.factor <- mat.split(PCs.all, as.numeric(facs[samp.ok,f]))
                PC.hulls <- lapply(PCs.by.factor, function(x) x[chull(x),] )
                is.poly <- sapply(PC.hulls,nrow)>2
                PC.mldist <- PC.areas <- sapply(PC.hulls, function(x) max(c(dist(x))) )  # init max-linedist and areas as same
                PC.areas[is.poly] <- sapply(PC.hulls[is.poly], function(x) polyarea(x[,1],x[,2]) )  # replace polygonal hull values with actual areas
                min.alr <- min(PC.areas[is.poly]/PC.mldist[is.poly])  # minimum area-to-length ratio; will be used to calculate pseudo-areas for linear hulls
                PC.areas[!is.poly] <- PC.areas[!is.poly] * min.alr  # convert line distances to pseudo-areas for linear hulls
                hull.area.sum <- sum(PC.areas)
                overlap <- polygon.overlap(PCs.by.factor)$combined
                
                centroids <- do.call(rbind, lapply(PCs.by.factor, colMeans))
                centroids.hull <- centroids[chull(centroids),]
                if (nrow(centroids.hull)==2) {
                    centroids.area <- dist(centroids.hull) * min.alr  # pseudo-area = line length * alr
                } else {
                    centroids.area <- polyarea(centroids.hull[,1],centroids.hull[,2])
                }
                
                spread <- c( hull.area=hull.area.sum, cent.area=centroids.area, super.area=super.area.mLOO, space.area=space.area )
                list(ol=overlap, sd=spread)
                ## plot(PCs.all, col=rainbow(maxf)[as.numeric(facs[samp.ok,f])]); points(centroids, pch=3, col=rainbow(maxf)); points(centroids.hull, pch=4)
                ## abline(lm(centroids[,2]~centroids[,1]))
            })
            names(hull.sep) <- colnames(facs)[test.facs]
            list(PCs=ncr2[i,], testable.factors=test.facs, sep.pct=lapply(hull.sep, "[[", "ol"), sep.area=lapply(hull.sep, "[[", "sd"))
        })

        sep.pct <- do.call(rbind, lapply(sep.data, function(x) sapply(x$sep.pct, function(y){ z=y[lower.tri(y)]; sum(z!=1)/length(z) })))  # separated level pairs / all level pairs
        spatials <- qw(hull.area,cent.area,super.area,space.area)
        names(spatials) <- spatials
        spatials <- lapply(spatials, function(x) do.call(rbind, lapply(lapply(sep.data, "[[", "sep.area"), function(y) unlist(lapply(y, "[[", x)))))  # hull centroid area / total area
        for (i in 1:length(spatials)) for (j in 1:ncol(spatials[[i]])) spatials[[i]][,j] <- unlist(spatials[[i]][,j])
        rownames(sep.pct) <- apply(ncr2,1,paste,collapse="-")
        for (i in 1:length(spatials)) rownames(spatials[[i]]) <- rownames(sep.pct)
        output <- c(output, list(spatial.sep=list(pct.levels.separated=sep.pct, separation.degree=spatials, data=sep.data, ncr.per.fac=cbind(ncr,ncr.per.fac))))
        
        ## Lots more improvements, like:
        ## disjoint hull area / total hull area (normalized to total loadings area?)
        ## centroid spread (normalized to total loadings area?)  DONE
        ## clustering validity index where clusters = hulls?
    }
    
    output
}


apa.names$dev <- c(apa.names$dev, "PCA.reconstitute")
PCA.reconstitute <- function(pca, PCs, scaling, orig=NULL) {
    
    
    
    ##### UNDER CONSTRUCTION #####
    
    
    
    ## Reconstructs original data from a subset of PCs
    ## 'pca' is an output object from PCA.basic()
    ## 'PCs' is a numeric vector of PC numbers to use
    ## 'scaling' can be         ##########  STANDARDIZE THIS  ##########
    
    
    ## if rescaling is needed, must use 'scaling' and 'pca$methods' (and 'orig' if supplied) to determine order of rescaling operations
    
    
    recons <- pca$gene.scores[,PCs] %*% t(pca$eigenvectors[,PCs])
    ## NO RESCALING NEEDED FOR UNSCALED PCA (cor/cov doesn't matter)
    
    ## THIS RESCALING WORKS FOR SAMPLE-SCALED PCA (cor/cov doesn't matter)
    for (i in 1:ncol(recons)) recons[,i] <- recons[,i]*(sd(lcounts.ok[,i])/sd(recons[,i]))
    for (i in 1:ncol(recons)) recons[,i] <- recons[,i]+(mean(lcounts.ok[,i])-mean(recons[,i]))
    max(lcounts.ok-recons)
    
    ## THIS RESCALING WORKS FOR GENE-SCALED PCA (cor/cov doesn't matter)
    recons <- recons*rowSDs(lcounts.ok)
    recons <- recons+rowMeans(lcounts.ok)
    max(lcounts.ok-recons)
    
    ## COMBINE THEM FOR DOUBLE-SCALED PCA (gene first then sample) (cor/cov doesn't matter)
    for (i in 1:ncol(recons)) recons[,i] <- recons[,i]*(sd(zcounts.ok[,i])/sd(recons[,i]))
    for (i in 1:ncol(recons)) recons[,i] <- recons[,i]+(mean(zcounts.ok[,i])-mean(recons[,i]))
    recons <- recons*rowSDs(lcounts.ok)
    recons <- recons+rowMeans(lcounts.ok)
    
    message(paste("Max error:",max(lcounts.ok-recons)))
    recons
}

