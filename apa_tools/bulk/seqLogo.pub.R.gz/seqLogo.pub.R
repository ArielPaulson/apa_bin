

plotLogo <- function(x, imgname, title=NULL) {
	
	## seqLogo.title()->png() wrapper with constant letter scales
	
	require(seqLogo)
	N <- ncol(x)
	png(imgname, 170+60*N, 400)  # 400px high; 170px base width + 60px per letter
	par(xaxs="i")
	seqLogo.title(x, title=title)
	dev.off()
}


logo.batchpdf <- function(pwms, imgname, ppi=100) {
	
	## plot a list of logos ('pwms') to a multi-page PDF
    ## ppi' = pixels per inch, to convert image dims into inches for pdf()
    
	require(seqLogo)
	pdf(imgname, width=(170+60*ncol(pwms[[1]]))/ppi, height=400/ppi)  # inches
	for (i in 1:length(pwms)) seqLogo.title(pwms[[i]], title=names(pwms)[i])
	dev.off()
}


seqLogo.title <- function (pwm, title=NULL, ic.scale = TRUE, xaxis = TRUE, yaxis = TRUE, xfontsize = 15, yfontsize = 15) {
	
	## Modified seqLogo() to enable plot titles (which are actually modified xlabs)
	
	require(seqLogo)
    if (class(pwm) == "pwm") {
        pwm <- pwm@pwm
    } else if (class(pwm) == "data.frame") {
        pwm <- as.matrix(pwm)
    } else if (class(pwm) != "matrix") {
        stop("pwm must be of class matrix or data.frame")
    }
    if (any(abs(1 - apply(pwm, 2, sum)) > 0.01)) stop("Columns of PWM must add up to 1.0")
    chars <- c("A", "C", "G", "T")
    letters <- list(x = NULL, y = NULL, id = NULL, fill = NULL)
    npos <- ncol(pwm)
    if (ic.scale) {
        ylim <- 2
        ylab <- "Information content"
        facs <- seqLogo:::pwm2ic(pwm)
    } else {
        ylim <- 1
        ylab <- "Probability"
        facs <- rep(1, npos)
    }
    wt <- 1
    x.pos <- 0
    for (j in 1:npos) {
        column <- pwm[, j]
        hts <- 0.95 * column * facs[j]
        letterOrder <- order(hts)
        y.pos <- 0
        for (i in 1:4) {
            letter <- chars[letterOrder[i]]
            ht <- hts[letterOrder[i]]
            if (ht > 0) letters <- seqLogo:::addLetter(letters, letter, x.pos, y.pos, ht, wt)
            y.pos <- y.pos + ht + 0.01
        }
        x.pos <- x.pos + wt
    }
    grid.newpage()
    bottomMargin = ifelse(xaxis, 2 + xfontsize/3.5, 2)
    leftMargin = ifelse(yaxis, 2 + yfontsize/3.5, 2)
    pushViewport(plotViewport(c(bottomMargin, leftMargin, 2, 2)))
    pushViewport(dataViewport(0:ncol(pwm), 0:ylim, name = "vp1"))
    grid.polygon(x = unit(letters$x, "native"), y = unit(letters$y, 
        "native"), id = letters$id, gp = gpar(fill = letters$fill, 
        col = "transparent"))
    if (xaxis) {
        grid.xaxis(at = seq(0.5, ncol(pwm) - 0.5), label = 1:ncol(pwm), gp = gpar(fontsize = xfontsize))
		xlab <- ifelse(is.null(title), "Position", paste(title,"Position"))
        grid.text(xlab, y = unit(-3, "lines"), gp = gpar(fontsize = xfontsize))
    }
    if (yaxis) {
        grid.yaxis(gp = gpar(fontsize = yfontsize))
        grid.text(ylab, x = unit(-3, "lines"), rot = 90, gp = gpar(fontsize = yfontsize))
    }
    popViewport()
    popViewport()
    par(ask = FALSE)
    invisible(facs)
}


