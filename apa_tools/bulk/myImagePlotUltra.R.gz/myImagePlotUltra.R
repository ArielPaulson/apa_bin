

apa.names$plots <- c(apa.names$plots,"myImagePlotUltra","mipu")
mipu <- myImagePlotUltra <- function(
    x, pmar=c(5,5), x.aspect=c(4,1), rnames=NULL, cnames=NULL, palette="KBY", rev.pal=FALSE, att.cols=NULL, att.rows=NULL, 
    att.palette=NULL, attrib=NULL, col.limits=NULL, col.center=NULL, quant.cols=FALSE, max.cols=256, max.qres=1E6, NA.col=8, Inf.col="white", 
    grid=0, mask=NULL, mask.ramp=NULL, interpolate=NULL, main=NULL, sub=NULL, stagger.main=0, las=2, cex=1, cex.axis=1, cex.main=1, 
    axes=TRUE, unlog.scale=NA, label.text=NULL, label.col=NULL, label.cex=NULL, show.scale=TRUE, scale.div=10, ...) {
    
    ## ----- Define a function for plotting a matrix ----- #
    ## Original myImagePlot() code by CWS
    ## Palettes + flexible margins + labels-free + scale-free + quantile colors + color scale forcing + aspect control + attribute rows/columns + text labels + more by APA
    ## x.aspect = c(map width, scale width); y.aspect is always "1" so adjust x accordingly
    
    ## 'quant.cols': apply color scale by quantiles, not by linear value range
    ## 'max.cols': force a maximum # color quantiles to use with 'quant.cols', if default is too many (getting positive kurtosis errors)
    
    if(!is.null(mask)) {
        if (!all(dim(mask) == dim(x))) { 
            stop("If mask is specified, must have same dims as input matrix!\n") 
        } else {
            m.min <- min(mask)
            m.max <- max(mask)
        }
    }
    
    NC <- ncol(x)
    NR <- nrow(x)
    NA.mat <- Inf.mat <- matrix(NA, NR, NC)
    NA.mat[is.na(x)] <- 1
    Inf.mat[is.infinite(x)] <- 1
    x[is.infinite(x)] <- NA  # remove infinites now
    core <- x   # initially
    if (is.null(palette)) palette <- "KBY"
    
    validate.att.pal <- function(apal, nlevs, rev.pal=FALSE) {
        if (length(apal)==0) {
            ## use master palette instead
            apal <- palette
        } else if (length(apal)==1) {
            ## length-1 palette? investigate
            is.pal <- class(try( palettizer(apal), silent=TRUE )) != "try-error"
            is.col <- class(try( col2rgb(apal)   , silent=TRUE )) != "try-error"
            if (is.col) {
                att.colors <- palettizer(c("white",apal), n=nlevs, NULL, NULL, rev.pal)
            } else if (is.pal) {
                att.colors <- palettizer(apal, n=nlevs, NULL, NULL, rev.pal)
            } else {
                stop("Cannot determine what kind of color scheme '",apal,"' is!\n")
            }
        } else if (nlevs==length(apal)) {
            ## data:palette is 1:1
            att.colors <- apal
        } else {
            ## data:palette is not 1:1; palette has > 1 element, so assume color vector
            att.colors <- palettizer(apal, n=nlevs, NULL, NULL, rev.pal)
        }
    }
    
    ## separate any attribute rows/cols from "core" matrix
    att.dims <- list(rows=c(), cols=c())  # not properly 'dim', just recording N rows & cols
    att.dat <- list()
    att.legacy <- length(att.cols)>0|length(att.rows)>0|length(att.palette)>0
    if (length(attrib)>0) {
        ## NEW METHOD -- MULTI-PALETTE
        if (att.legacy) stop("If using NEW attribute method 'attrib', do not specify any OLD attribute methods 'att.cols', 'att.rows', or 'att.palette'!\n")
        for (a in 1:length(attrib)) {
            att.mat <- matrix(NA, NR, NC)
            if ("rows" %in% names(attrib[[a]])) {
                att.mat[attrib[[a]]$rows,] <- x[attrib[[a]]$rows,,drop=FALSE]
                att.dims$rows <- c(att.dims$rows,attrib[[a]]$rows)
            }
            if ("cols" %in% names(attrib[[a]])) {
                att.mat[,attrib[[a]]$cols] <- x[,attrib[[a]]$cols,drop=FALSE]
                att.dims$cols <- c(att.dims$cols,attrib[[a]]$cols)
            }
            att.revpal <- ifelse("rev.pal" %in% names(attrib[[a]]), attrib[[a]]$rev.pal, FALSE)
            att.levels <- diff(range(att.mat,na.rm=TRUE))+1
            att.colors <- validate.att.pal(attrib[[a]]$palette, att.levels, att.revpal)
            att.dat[[a]] <- list(mat=att.mat, col=att.colors)
        }
    } else if (att.legacy) {
        ## LEGACY METHOD -- SINGLE-PALETTE
        att.mat <- matrix(NA, NR, NC)
        if (length(att.rows)>0) {
            att.mat[att.rows,] <- x[att.rows,,drop=FALSE]
            att.dims$rows <- c(att.dims$rows,att.rows)
        }
        if (length(att.cols)>0) {
            att.mat[,att.cols] <- x[,att.cols,drop=FALSE]
            att.dims$cols <- c(att.dims$cols,att.cols)
        }
        att.levels <- diff(range(att.mat,na.rm=TRUE))+1
        att.colors <- validate.att.pal(att.palette, att.levels, rev.pal)
        att.dat[[1]] <- list(mat=att.mat, col=att.colors)
    }
    
    if (length(att.dims$cols)>0) core[,att.dims$cols] <- NA
    if (length(att.dims$rows)>0) core[att.dims$rows,] <- NA
    if (length(dim(core))==0) {  # no longer a matrix?
        core <- t(as.matrix(core))
    }
    if (length(col.limits)>0) {
        core[core>col.limits[2]] <- col.limits[2]
        core[core<col.limits[1]] <- col.limits[1]
    }
    c.min <- min(real(core))
    c.max <- max(real(core))
    if (c.min==c.max) stop("Entire matrix has only one value: will not plot.\n")
    
    if (length(rnames)>0) {
        yLabels <- stretch.attrib(rnames,NR,'yLabels')
    } else if (length(rownames(x))>0) {
        yLabels <- rownames(x)
    } else {
        yLabels <- 1:NR
    }
    if (length(cnames)>0) {
        xLabels <- stretch.attrib(cnames,NC,'xLabels')
    } else if (length(colnames(x))>0) {
        xLabels <- colnames(x)
    } else {
        xLabels <- 1:NC
    }
    
    ## check for additional function arguments
    ## UPDATE: 'Lst' no longer used anywhere -- should this part get tossed?
    Lst <- list(...)
    xaxt <- yaxt <- ""
    if(length(Lst) > 0) {
        if(!is.null(Lst$zlim)) {
            c.min <- Lst$zlim[1]
            c.max <- Lst$zlim[2]
        }
        if (!is.null(Lst$yLabels)) yLabels <- c(Lst$yLabels)
        if (!is.null(Lst$xLabels)) xLabels <- c(Lst$xLabels)
        #if (!is.null(Lst$main)) main <- Lst$main
        #if (!is.null(Lst$xaxt)) xaxt <- Lst$xaxt
        #if (!is.null(Lst$yaxt)) yaxt <- Lst$yaxt
    }
    ## check for null values
    if (is.null(xLabels)) xLabels <- 1:NC
    if (is.null(yLabels)) yLabels <- 1:NR
    
    if (show.scale) layout(matrix(data=c(1,2), nrow=1, ncol=2), widths=x.aspect, heights=c(1,1))
    
    scale <- c()
    scale[1] <- c.min <- ifelse (!is.null(col.limits[1]), col.limits[1], c.min)
    scale[2] <- c.max <- ifelse (!is.null(col.limits[2]), col.limits[2], c.max)
    
    colctr <- fixpal <- FALSE
    if (length(ncol(palette))>0) {
        ## matrix to plot is discrete, and 'palette' is a value->color key
        fixpal <- TRUE
        obs.lev <- sort(unique(zapsmall(c(as.matrix(core)))))
        colors2 <- palette[match(obs.lev,zapsmall(palette[,1])),2]
        for (i in 1:ncol(core)) core[,i] <- translate(core[,i],obs.lev,1:length(obs.lev))
        ColorLevels <- obs.lev
    } else if (length(col.limits)>0 & length(col.center)>0) {
        ## COL LIMITS
        ## truncating or extending palette range
#        colors2 <- palettizer(palette, max.cols, interpolate, NULL, rev.pal)
#        if (!exists("colors2")) stop("No palette to use: cannot proceed!\n")
#        FullColorRange <- seq(scale[1], scale[2], length=length(colors2))	# initial color scale (may be too wide)
#        terminal <- quantize(c.max, FullColorRange)
#        ColorLevels <- FullColorRange[1:which(FullColorRange==terminal)]	# subset corresponding to data range
#        CL=list(ColorLevels)
        ## COL CENTER
        ## centered palette required (use two half-palettes)
        ## make and arrange half-palettes if color scale is centered
        percol <- (scale[2] - scale[1]) / max.cols
        col.fracs <- col.ranges <- c(0,0)
        col.fracs[1] <- (col.center - scale[1]) / percol   # fraction below center
        col.fracs[2] <- (scale[2] - col.center) / percol   # fraction above center
        half.palettes <- palettizer(palette, max.cols, interpolate, round(col.fracs,0), FALSE)  # palette, n.colors=NA, interpolate=NULL, halves=c(lower.res,upper.res), reverse=FALSE
        colors2 <- unlist(half.palettes)
        ColorLevels <- seq(c.min, c.max, length=length(colors2))
    } else if (length(col.limits)>0) {
        ## truncating or extending palette range
        colors2 <- palettizer(palette, max.cols, interpolate, NULL, rev.pal)
        if (!exists("colors2")) stop("No palette to use: cannot proceed!\n")
        FullColorRange <- seq(scale[1], scale[2], length=length(colors2))	# initial color scale (may be too wide)
        terminal <- quantize(c.max, FullColorRange)
        ColorLevels <- FullColorRange[1:which(FullColorRange==terminal)]	# subset corresponding to data range
    } else if (quant.cols) {
        ## quantile-based color distribution
        cbins <- max.cols
        qcolors <- palettizer(palette, max.cols, interpolate, NULL, rev.pal)
        qt <- quantile(real(as.vector(unlist(core))), seq(0,1,length=cbins+1))
        dupqt <- duplicated(qt)
        if (any(dupqt)) qt <- qt[!dupqt]     # identical quantiles exist (extreme positive kurtosis): merge and re-evaluate
        cbins <- length(qt) - 1
        if (cbins != max.cols) qcolors <- palettizer(palette, max.cols, interpolate, NULL, rev.pal)  # bin count changed: have to re-make color vector
        d <- diff(qt)
        sigd <- as.numeric(strsplit(format(abs(min(d)), sci=TRUE),"-")[[1]][2])
        res <- 1 / 10^sigd
        qbins <- round((qt[cbins+1] - qt[1]) / res, 0)
###		IM(qt[1],qt[257],min(d),sigd,res,qbins)
        if (qbins > max.qres) {   # data distribution too skewed: zero-inflated data?
            #if (min(real(core))==0) { }   # doing what here??
            stop(paste("Data has too much positive kurtosis: minimum quantile size too small! | resolution=",qbins,", max resolution=",max.qres,"\nDecrease max.cols or increase max.qres\n",sep="")) 
        }
        colors2 <- rep(0, qbins+1)
        end <- 0
        for (i in 1:cbins) {
            start <- end + 1
            end <- start + round(d[i] / res,0)
            colors2[start:end] <- qcolors[i]
        }
###		IM(cbins, qbins, qcolors[1], colors2[1], qcolors[cbins], colors2[qbins+1])
        ColorLevels <- seq(c.min, c.max, length=length(colors2))
###		return(list(qt,ColorLevels,colors2))
    } else if (length(col.center)>0) {
        ## centered palette required (use two half-palettes)
        colctr <- TRUE
        ## make and arrange half-palettes if color scale is centered
        percol <- (scale[2] - scale[1]) / max.cols
        col.fracs <- col.ranges <- c(0,0)
        col.fracs[1] <- (col.center - scale[1]) / percol   # fraction below center
        col.fracs[2] <- (scale[2] - col.center) / percol   # fraction above center
        half.palettes <- palettizer(palette, max.cols, interpolate, round(col.fracs,0), FALSE)  # palette, n.colors=NA, interpolate=NULL, halves=c(lower.res,upper.res), reverse=FALSE
        colors2 <- unlist(half.palettes)
        ColorLevels <- seq(c.min, c.max, length=length(colors2))
###                return(list(col.center=col.center, max.cols=max.cols, c.minmax=c(c.min,c.max), scale=scale, percol=percol, col.fracs=col.fracs, half.palettes=half.palettes, ColorLevels=ColorLevels))
    } else {
        ## default behavior
        colors2 <- palettizer(palette, max.cols, interpolate, NULL, rev.pal)
        ColorLevels <- seq(c.min, c.max, length=length(colors2))
    }
    LCL <- length(ColorLevels)
    
    ## labels test
    if (!is.null(label.text)) {
        if (nrow(label.text) != NR | ncol(label.text) != NC) stop("Label text dimensions do not match matrix dimensions!")
        if (is.null(label.col)) {
            label.col <- label.text
            label.col[label.col!=1] <- 1
        } else {
            if (nrow(label.col) != NR | ncol(label.col) != NC) stop("Label col dimensions do not match matrix dimensions!")
        }
#        label.text <- t(label.text[nrow(label.text):1,])
#        label.col <- t(label.col[nrow(label.col):1,])
    }
    
    Lm <- length(main)
    if (Lm>0) {
        if (stagger.main>0) {
            if (Lm<2) stop("Can't stagger 'main' unless 'main' is a vector of labels (with length > 1)!\n")
            main.tiers <- tier.pos <- vector("list", length=stagger.main)
            offset <- ifelse(Lm==NC,0,round(NC/(2*Lm),0))
            NCeff <- NC-2*offset
            for (i in 1:stagger.main) {
                s <- seq(i,Lm,stagger.main)
                main.tiers[[i]] <- main[s]
                tier.pos[[i]] <- seq(0,NCeff,length.out=Lm)[s] + offset
            }
            main <- NULL  # ZAP IT NOW
        } else {
            if (Lm>1) stop("'main' cannot be a vector unless stagger.main>0!\n")
        }
    }
    
    ## Data Map
    par(mar = c(pmar,2.5,2), cex=cex)
    add <- FALSE
    
    if (any(falsify(NA.mat==1))) {
        ## plot NA "background" first
        image(1:NC, 1:NR, t(NA.mat[NR:1,,drop=FALSE]), col=NA.col, xlab="", ylab="", axes=FALSE, main=main, sub=sub, cex.sub=cex.main)
        add <- TRUE
    }
    
    if (length(att.dat)>0) {
        for (a in 1:length(att.dat)) {
            this.sub <- if (!is.null(sub)) ifelse(add,"",sub)
            this.main <- if (!is.null(main)) ifelse(add,"",main)
            image(1:NC, 1:NR, t(att.dat[[a]]$mat[NR:1,,drop=FALSE]), col=att.dat[[a]]$col, xlab="", ylab="", axes=FALSE, add=add, main=this.main, sub=this.sub, cex.sub=cex.main)	
            add <- TRUE
        }
    }
    
    ## plot main heatmap
    z.lim <- if (fixpal) { c(1,LCL) } else { c(c.min,c.max) }
    this.sub <- if (!is.null(sub)) ifelse(add,"",sub)
    this.main <- if (!is.null(main)) ifelse(add,"",main)
    if (stagger.main==0) {
        image(1:NC, 1:NR, t(core[NR:1,,drop=FALSE]), col=colors2, xlab="", ylab="", axes=FALSE, add=add, zlim=z.lim, main=this.main, sub=this.sub, cex.main=cex.main, cex.sub=cex.main)
    } else {
        image(1:NC, 1:NR, t(core[NR:1,,drop=FALSE]), col=colors2, xlab="", ylab="", axes=FALSE, add=add, zlim=z.lim, main="", sub=this.sub, cex.sub=cex.main)
        for (i in 1:stagger.main) mtext(main.tiers[[i]], 3, stagger.main-i, FALSE, tier.pos[[i]], cex=cex.main)
    }
    #IM("Bye!")
    #return()
    
    ## plot gridlines
    if (grid != 0) {  # zero being the "invisible" color, so don't bother plotting...
        abline(h=c(-1:NR)+0.5, lty=1, col=grid)
        abline(v=c(-1:NC)+0.5, lty=1, col=grid)
    }
    
    ## add labels
    if (!is.null(label.text)) {
        label.text <- label.text
        for (i in 1:ncol(label.text)) { text(i, NR:1, labels=label.text[,i], col=label.col[,i], cex=label.cex) }
    }
    
    ## plot mask
    if (!is.null(mask)) image(1:NC, 1:NR, t(mask[NR:1,,drop=FALSE]), add=TRUE, col=mask.ramp, xlab="", ylab="", axes=FALSE, zlim=c(m.min,m.max)) 
    
    if (axes) {
        if (xaxt!="n") axis(1, at=1:NC, labels=xLabels, las=las, cex.axis=cex.axis)  # bottom
        if (yaxt!="n") axis(2, at=1:NR, labels=yLabels[NR:1], las=las, cex.axis=cex.axis)  # left
    }
    
    ## Color Scale
    if (show.scale) {
        par(mar=c(pmar[1],2.5,2.5,2), las=1, cex=cex)
        Nticks <- scale.div+1
        if (fixpal) {
            image(1, 1:LCL, matrix(data=1:LCL, ncol=LCL, nrow=1), col=colors2, xlab="", ylab="", xaxt="n", yaxt="n")
            axseq <- 1:LCL
            axis(2, at=axseq, labels=ColorLevels, las=2, cex.axis=cex.axis)
#            axis(4, at=axseq, labels=sort(unique(c(core))), las=2, cex.axis=cex.axis)
        } else {
            image(1, ColorLevels, matrix(data=ColorLevels, ncol=LCL, nrow=1), col=colors2, xlab="", ylab="", xaxt="n", yaxt="n")
            axlab <- sapply(seq(c.min,c.max,length.out=Nticks), function(x) signif(x,3) )
            if (!is.na(unlog.scale)) axlab <- sprintf("%0.2f",unlog.scale^axlab)
            axis(2, at=seq(c.min,c.max,length.out=Nticks), labels=axlab, las=2, cex.axis=cex.axis)
        }
###		if (colctr) axlab[which.min(abs(axlab))] <- 0
###		axlab <- paste(100*round(seq(c.min,c.max,length.out=Nticks),2),"%",sep="")   # 1-off thing
        layout(1)
    }
    
}


