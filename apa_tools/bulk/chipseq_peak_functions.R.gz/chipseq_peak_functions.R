

apa.names$general <- c(apa.names$general, "place.peak")
place.peak <- function(pcoords, matchto, verbose=FALSE, exons=TRUE) {
    
    ## pcoords = row-list from a bed file data frame: chr start end id; more fields optional
    ## matchto = bed file data frame of coords to match "pcoords" to
    
    if (!is.data.frame(pcoords)) {  # e.g. coming from apply()
        pcoords <- as.data.frame(as.list(pcoords), stringsAsFactors=FALSE)
        for (i in 2:3) { mode(pcoords[,i]) <- "numeric" }
    }
	colnames(pcoords)[1:4] <- c("Chr","Start","End","Peak")
    if (exons) {
        results <- list(TYPE=c(),PEAK=pcoords,EXON=c(),INTR=c(),ITGC=c())
    } else {
        results <- list(TYPE=c(),PEAK=pcoords,GENE=c(),ITGC=c())
    }
	if (verbose) IM(pcoords[[1]], dim(matchto))
	chrgenes <- matchto[matchto[,1]==pcoords[[1]],]
	colnames(chrgenes)[1:4] <- c("Chr","Start","End","Gene")
    if (verbose) IM("place.peak: 0 :",pcoords,":",dim(chrgenes))
	PSmGS <- pcoords[[2]] - chrgenes[,2]
	PSmGE <- pcoords[[2]] - chrgenes[,3]
	PEmGS <- pcoords[[3]] - chrgenes[,2]
	PEmGE <- pcoords[[3]] - chrgenes[,3]
    if (verbose) IM("place.peak: 1")
	gresults <- matchify(cbind(PSmGS,PSmGE,PEmGS,PEmGE), verbose=verbose)
    if (verbose) IM("place.peak: 2")
	if (length(gresults$HITS)>0) {   # gene hits
        if (exons) {
            if (verbose) IM("place.peak: 3")
            xhits <- ihits <- list(c()); xN <- iN <- 0
            for (gene in chrgenes[gresults$HITS,4]) {
                if (verbose) IM("place.peak: 4")
                exons <- ebed[ebed[,7]==gene,]
                colnames(chrgenes) <- c("Chr","Start","End","Gene","Score","Strand")
                PSmXS <- pcoords[[2]] - exons[,2]
                PSmXE <- pcoords[[2]] - exons[,3]
                PEmXS <- pcoords[[3]] - exons[,2]
                PEmXE <- pcoords[[3]] - exons[,3]
                if (verbose) IM("place.peak: 5: exon matchify",nrow(exons))
                xresults <- matchify(cbind(PSmXS,PSmXE,PEmXS,PEmXE), verbose=verbose)
                if (verbose) IM("place.peak: 6")
                if (length(xresults$HITS)>0) {   # exon hits
                    if (verbose) IM("place.peak: 7")
                    xN <- xN + 1
                    xhits[[xN]] <- exons[unlist(xresults$HITS),]  # exon hits
                } else {
                    if (verbose) IM("place.peak: 8")
                    iN <- iN + 1
                    introns <- do.call(rbind, xresults$NNS)
                    ihits[[iN]] <- cbind(exons[introns[,1],], introns[,2])   # exon nearest neighbors
                }
                if (verbose) IM("place.peak: 9")
            }
            if (length(xhits) > 0) {
                results$TYPE <- "EXON"
                results$EXON <- unique(do.call(rbind, xhits))
            } 
            if (length(ihits) > 0) {
                results$TYPE <- "INTR"
                results$INTR <- unique(do.call(rbind, ihits))
                if (!is.null(results$INTR)) { colnames(results$INTR)[ncol(results$INTR)] <- "Distance" }  # can get empty results
            }
            if (verbose) IM("place.peak: 10")
        } else {
            if (verbose) IM("place.peak: G1")
            results$TYPE <- "GENE"
            results$GENE <- chrgenes[gresults$HITS,]
            if (verbose) IM("place.peak: G2")
        }
    } else {
        if (verbose) IM("place.peak: 11")
        results$TYPE <- "ITGC"
        intergenes <- do.call(rbind, gresults$NNS)
        results$ITGC <- cbind(chrgenes[intergenes[,1],], intergenes[,2])
        if (!is.null(results$ITGC)) { colnames(results$ITGC)[ncol(results$ITGC)] <- "Distance" }  # can get empty results
        if (verbose) IM("place.peak: 12")
	}
	return(results)
}


apa.names$dev <- c(apa.names$dev, "peak.featuremap")
peak.featuremap <- function(wins, peaks, feats=NULL, feat.space=c("peak","genomic"), compress=NULL) {
    
    ## Create an integer-valued heatmap matrix of peak positions 'peaks' within windows 'wins', optionally annotated with smaller features 'feats' (e.g. motif sites).
    ## 'wins' is a BED data.frame of window coords, MUST ALL HAVE SAME WIDTH.  Output matrix will have this width.
    ## 'peaks' is a BED data.frame of peak coords which overlap (ideally, contained by) 'wins'; MUST HAVE SAME ROW ORDER.
    ## 'feats' is an optional BED data.frame of feature coords within 'peaks' (NOT within 'wins').
    ##         Scores of 'feats' (col 5) are distinctive integers > 1; output cells which contain these feats will be given those score values.
    ##           e.g. if 'feats' are hits from various motifs, then all hits for one motif should have the same score.
    ##         Do not use values of 0, 1 since these are already reserved for the default value (0) and the peak region (1).
    ## 'feat.space' is required if using 'feats', and indicates if the coord space of 'feats' is relative to peaks (i.e. 0-peak_width), or relative to genome (same coord space as peaks).
    ## 'compress' is an optional output column number, less than the width of 'wins' intervals.  Will compress output by binning along columns.
    
    if (!is.null(compress)) stop("Compression not yet supported!  Please avoid this argument.\n")
    
    if (nrow(wins)!=nrow(peaks)) stop("'wins' and 'peaks' do not have same rows!\n")
    feat.space <- match.arg(feat.space)
    win.gr <- bed2gr(wins)
    peaks.gr <- bed2gr(peaks)
    wpo <- as.matrix(findOverlaps(wins.gr,peaks.gr))
    ok <- length(unique(wro[,1]))==nrow(wins) & length(unique(wro[,2]))==nrow(peaks)
    if (!ok) stop("'peaks' does not fully intersect with 'wins'!  Non-intersecting intervals exist.\n")
    P <- nrow(peaks)
    W <- wins[1,3]-wins[1,2]
    have.feats <- length(feats)>0
    if (have.feats) if (!all(feats[,1] %in% peaks[,4])) stop("'feats' do not all belong to 'peaks': 'feats' column 1 not contained by 'peaks' column 4!\n")
    
    m <- matrix(0, P, W, FALSE, list(peaks[,4],c()))
    op <- as.matrix(p[,2:3])-w[,2]
    for (i in 1:P) m[i,op[i,1]:op[i,2]] <- 1  # cells occupied by peaks -> 1
    if (have.feats) {
        of <- mat.split(feats, feats[,1])
        of <- of[real(match(peaks[,4],names(of)))]
        wp <- match(names(of),peaks[,4])
        if (feat.space=="peak") {
            for (i in 1:length(wp)) of[[i]][,2:3] <- of[[i]][,2:3]+peaks[wp[i],2]-win[wp[i],2]  # peak coords -> genomic coords -> local window coords
        } else if (feat.space=="genomic") {
            for (i in 1:length(wp)) of[[i]][,2:3] <- of[[i]][,2:3]-win[wp[i],2]                 # already genomic coords -> local window coords
        }
        for (i in 1:length(wp)) {
            for (j in 1:nrow(of[[i]])) m[i,of[[i]][j,2]:of[[i]][j,3]] <- of[[i]][j,5]
        }
    }
    
    if (!is.null(compress)) {
        ## Shrink N columns in matrix by binning columns and taking means; decide what values the bins get.
        m2 <- matrix(0, P, compress, FALSE, list(peaks[,4],c()))
        
        ### WORKING HERE ###
        
        m2
    } else {
        m
    }
}


apa.names$dev <- c(apa.names$dev, "call.peaks.old")
call.peaks.old <- function(IP, inp, minHeight=0, minWidth=0, mergeGap=0, minFC=0, maxP=0.05, bkg=list(90,"pctl-chromosome"), call=list(98,"pctl-chromosome"), prefix="Peak", scale.to=c("input","IP","larger","smaller"), seqNames=NULL) {
    
    ## IMPROVEMENTS TO BE MADE:
    ## Multi-IP calling (i.e. 'IP' is a list of bams)
    ## Trim tails / split peaks on N5 set which are below minFC (to get them above minFC)
    ## threshold-by-chromosome option in case chr behaviors are too different to threshold all at once
    
    ## 'IP', 'inp' are bam-derived GRanges lists
    
    scale.to <- match.arg(scale.to)
    types <- c("pctl-genome","pctl-chromosome","reads","rpm")
    bkg.upper <- bkg[[1]]
    bkg.type <- bkg[[2]]
    call.lower <- call[[1]]
    call.type <- call[[2]]
    if (!(bkg.type %in% types)) stop(paste0(c("Background threshold type must be one of: ",types,collapse=" ")))
    if (!(call.type %in% types)) stop(paste0(c("Call threshold type must be one of: ",types,collapse=" ")))
    
    now <- system("date", intern=TRUE)
    message(paste("Preparing:",now))
    if (length(seqNames)>0) {
        ibams <- list( IP=keepSeqlevels(IP,seqNames), inp=keepSeqlevels(inp,seqNames) )
    } else {
        ibams <- list( IP=IP, inp=inp )
    }
    B <- 1:2; names(B) <- c("IP","inp")
    seqNames <- levels(seqnames(ibams$inp))  # ensure these are in GenomicRanges order
    S <- 1:length(seqNames); names(S) <- seqNames
    
    rlen <- width(ranges(IP[1]))  # read length
    chr.len <- attr(ibams$inp,"seqinfo")@seqlengths  # chromosome bp
    names(chr.len) <- levels(seqnames(ibams$inp))
    chr.len <- chr.len[match(seqNames,names(chr.len))]
    Glen <- sum(chr.len)  # genome bp
    Grds <- sapply(ibams,length)  # reads/alignments per bam
    
    Gscale <- c(1,1)  # initial scaling factors
    if (scale.to == "input") {
        Gscale[1] <- Grds[2]/Grds[1]  # scale IP towards input
        message(paste(c(Grds,":",Gscale[1]),collapse=" "))
    } else if (scale.to == "IP") {
        Gscale[2] <- Grds[1]/Grds[2]  # scale input towards IP
        message(paste(c(Grds,":",Gscale[2]),collapse=" "))
    } else if (scale.to == "larger") {
        Gscale[which.min(Grds)] <- max(Grds)/min(Grds)  # scale smaller sample towards larger
        message(paste(c(Grds,":",max(Gscale)),collapse=" "))
    } else if (scale.to == "smaller") {
        Gscale[which.max(Grds)] <- min(Grds)/max(Grds)  # scale larger sample towards smaller
        message(paste(c(Grds,":",min(Gscale)),collapse=" "))
    }
    
    Grds.scaled <- Grds*Gscale  # post-scaling, both values are same
    chr.rds <- merge.table.list(lapply(ibams, function(x) table(as.character(seqnames(x))) ))  #  read counts per chrom
    chr.rds <- chr.rds[,match(seqNames,colnames(chr.rds))]
    chr.rds.scaled <- Gscale*chr.rds   # scaled read counts per chrom
    chr.pseudo <- 1E6/chr.rds.scaled/2   # per-chrom RPM pseudocounts (RPM of 0.5 reads) for adjusting prior to Log-FC
    for (i in 1:length(chr.pseudo)) chr.pseudo[i] <- 1E6/Grds.scaled[1]/2     ##### REPLACE WITH GENOMIC RPM PSEUDOCOUNTS
    minHeight.rpm <- 1E6*minHeight/Grds.scaled[1]
    
    ## per-bam-per-chromosome objects
    now <- system("date", intern=TRUE)
    message(paste("Calculating coverage vectors:",now))
    covg <- lapply(B, function(i) coverage(ibams[[i]])*Gscale[i] )  # scaled read coverage
    rpm <- lapply(B, function(i) lapply(1:length(seqNames), function(j) 1E6*Gscale[i]*covg[[i]][[j]]/Grds.scaled[i] ))  # scaled RPM coverage
    
    ## set background and call vectors, one value per chrom (may all be same value)
    Gbkg <- Gbkg.rpm <- lapply(B, function(i) NA )
    if (bkg.type == "pctl-genome" || call.type == "pctl-genome") {
        
        now <- system("date", intern=TRUE)
        message(paste("Calculating genome-wide background percentiles:",now))
        Gbkg <- lapply(B, function(i) zapsmall(percentiles(unlist(lapply(covg[[i]],as.numeric))))[2:101] )  # one value per bam
        Gbkg.rpm <- lapply(B, function(i) zapsmall(1E6*Gbkg[[i]]/sum(Grds.scaled[i])) )
        if (bkg.type == "pctl-genome") {
            minht <- rep(max(c(minHeight,Gbkg$IP[bkg.upper])), max(S))              # PERCENTILES ARE IN READ HEIGHT, NOT RPM
            minht.rpm <- rep(max(c(minHeight.rpm,Gbkg.rpm$IP[bkg.upper])), max(S))  # PERCENTILES ARE IN READ HEIGHT, NOT RPM
        } else if (bkg.type == "height") {
            minht <- rep(bkg.upper, max(S))
            minht.rpm <- 1E6*minht/Grds.scaled[1]
        }
        if (call.type == "pctl-genome") {
            callht <- rep(Gbkg$IP[call.lower], max(S))          # PERCENTILES ARE IN READ HEIGHT, NOT RPM
            callht.rpm <- rep(Gbkg.rpm$IP[call.lower], max(S))  # PERCENTILES ARE IN READ HEIGHT, NOT RPM
        } else if (call.type == "height") {
            callht <- rep(call.lower, max(S))
            callht.rpm <- 1E6*callht/Grds.scaled[1]
        }
        
    }
    gbp.mat <- colname( do.call(cbind, c(Gbkg,Gbkg.rpm)), paste(rep(c("IP","Input"),2),rep(c("Rds","RPM"),each=2)) )  # bkg pctl matrix
    
    now <- system("date", intern=TRUE)
    message(paste("Calculating chromosome background percentiles:",now))
    Cbkg <- lapply(S, function(j) lapply(B, function(i) zapsmall(percentiles(as.numeric(covg[[i]][[j]])))[2:101] ))  # one value per chromosome per bam
    Cbkg.rpm <- lapply(S, function(j) lapply(B, function(i) zapsmall(1E6*Cbkg[[j]][[i]]/Grds.scaled[1]) ))
    cbp.mat <- lapply(S, function(j) colname( do.call(cbind, c(Cbkg[[j]],Cbkg.rpm[[j]])), paste(rep(c("IP","Input"),2),rep(c("Rds","RPM"),each=2)) ))  # bkg pctl matrices
    if (bkg.type == "pctl-chromosome") {
        minht <- sapply(Cbkg, function(x) max(c(minHeight,x$IP[bkg.upper])) )              # PERCENTILES ARE IN READ HEIGHT, NOT RPM
        minht.rpm <- sapply(Cbkg.rpm, function(x) max(c(minHeight.rpm,x$IP[bkg.upper])) )  # PERCENTILES ARE IN READ HEIGHT, NOT RPM
    } else if (bkg.type == "height") {
        minht <- rep(bkg.upper, max(S))
        minht.rpm <- 1E6*minht/Grds.scaled[1]
    }
    if (call.type == "pctl-chromosome") {
        callht <- sapply(Cbkg, function(x) x$IP[call.lower] )          # PERCENTILES ARE IN READ HEIGHT, NOT RPM
        callht.rpm <- sapply(Cbkg.rpm, function(x) x$IP[call.lower] )  # PERCENTILES ARE IN READ HEIGHT, NOT RPM
    } else if (call.type == "height") {
        callht <- rep(call.lower, max(S))
        callht.rpm <- 1E6*callht/Grds.scaled[1]
    }
    
    ## chromosomal objects
    chr.peaks <- chr.stats <- new.list(seqNames)
    
    m.tmp <- data.frame(
        Chr="", Start=0, End=0, ID="", Width=0,
        ScaledReads=0, InpScaledReads=0, 
        MeanHt=0, MedHt=0, MaxHt=0, TotBp=0,
        MeanHt.RPM=0, MedHt.RPM=0, MaxHt.RPM=0, TotBp.RPM=0,
        InpMeanHt.RPM=0, InpMedHt.RPM=0, InpMaxHt.RPM=0, InpTotBp.RPM=0,
        LFC.RPM.max=0, LFC.RPM.tot=0, Pois.P=1, Pois.P.BH=1,
        stringsAsFactors=FALSE
    )
    
    ## process chromosome at a time
    now <- system("date", intern=TRUE)
    message(paste("Calling peaks per chromosome:",now))
    for (n in S) {
        
        chr <- seqNames[n]
        this.minht <- minht[n]
        this.callht <- callht[n]
        this.pseudo <- chr.pseudo[,n]
        this.len <- chr.len[n]
        this.rds <- chr.rds[,n]
        this.rds.scaled <- chr.rds.scaled[,n]
        
        N1 <- N2 <- N3 <- N4 <- N5 <- N6 <- 0
        
        ## call islands w/ background subtraction
        isl1 <- slice(covg$IP[[n]], lower=this.minht)
        N1 <- length(isl1)  # total islands
        
        if (N1==0) {
            m <- m.tmp[0,]
        } else {
            
            ## restrict by island width
            isl2 <- isl1[width(isl1)>=minWidth] 
            N2 <- length(isl2)  # wide islands 
            
            if (N2==0) {
                m <- m.tmp[0,]
            } else {
                m <- as.matrix(ranges(isl2))
                m <- data.frame(
                    Chr=rep(chr,N2),
                    Start=m[,1],
                    End=m[,1]+m[,2]-1,
                    ID="",
                    Width=m[,2],
                    stringsAsFactors=FALSE
                )
                
                covg2 <- lapply(covg, function(x) as.numeric(x[[n]]) )  # CONVERT COVERAGES TO NUMERIC VECTORS
                mcovg <- lapply(B, function(i) lapply(1:N2, function(j) covg2[[i]][m$Start[j]:m$End[j]] ))
                mcovg.rpm <- lapply(B, function(i) lapply(mcovg[[i]], function(x) 1E6*x/Grds.scaled[i] ) )
                mcovg.rpm2 <- lapply(B, function(i) lapply(mcovg.rpm[[i]], function(x) x+this.pseudo[i] ) )
                LFC.RPM <- lapply(1:N2, function(j) log2(mcovg.rpm2$IP[[j]]/mcovg.rpm2$inp[[j]]) )
                LFC.RPM1 <- lapply(1:N2, function(j) log2(mcovg.rpm$IP[[j]]/mcovg.rpm$inp[[j]]) )
                LFC.RPM0 <- lapply(1:N2, function(j) log2(mcovg$IP[[j]]/mcovg$inp[[j]]) )
                
                ## call peaks by call threshold
                if (call.type == "reads") {
                    called <- which(sapply(mcovg$IP,max)>=this.callht)
                } else if (call.type == "rpm") {
                    called <- which(sapply(mcovg.rpm$IP,max)>=this.callht)
                } else {
                    called <- which(sapply(mcovg$IP,max)>=this.callht)  # PERCENTILES ARE IN READ HEIGHT, NOT RPM
                }
                m <- m[called,]
                LFC.RPM <- LFC.RPM[called]
                N3 <- nrow(m)
                
                if (N3==0) {
                    m <- m.tmp[0,]
                } else {
                    
                    ## restrict to islands with max IP/inp LFC >= minFC
                    m <- m[sapply(LFC.RPM,max)>=log2(minFC),]
                    N4 <- nrow(m)
                    
                    if (N4==0) {
                        m <- m.tmp[0,]
                        N5 <- N6 <- 0
                    } else {
                        
                        if (N4>1) {
                            ## fuse peak sets that are within mergeGap bp of each other
                            if (mergeGap>0) {
                                gaps <- m$Start[2:N4]-m$End[1:(N4-1)]
                                gapruns <- find.runs((gaps<=mergeGap)+0)
                                gapruns <- lapply(gapruns[falsify(names(gapruns)==1)], function(x) c(x[1]:(x[2]+1)) )
                                mnon <- m[!(1:N4 %in% unlist(gapruns)),]
                                mgap <- lapply(gapruns, function(x) m[x,] )
                                if (length(mgap)>0) {  # just in case N4==2, and the pair were not close enough to merge
                                    m <- rbind(
                                        mnon,
                                        do.call(rbind, lapply(mgap, function(x){ y=x[1,]; y$Start=x$Start[1]; y$End=x$End[nrow(x)]; y$Width=y$End-y$Start+1; y }))
                                    )
                                    m <- rownameless(m[order(m$Start),])
                                }
                            }
                        }
                        
                        N5 <- nrow(m)  # N fused peaks; must be > 1 if N4 > 1
                        mcovg <- lapply(B, function(i) lapply(1:N5, function(j) covg[[i]][[n]][m$Start[j]:m$End[j]] ))  # REBOOT RPM COVERAGE VECTORS
                        mcovg.rpm <- lapply(B, function(i) lapply(mcovg[[i]], function(x) 1E6*x/Grds.scaled[i] ) )
                        m.bed <- cbind(m[,1:5],"+")
                        m.bed[,4] <- 1:N5
                        m.gr <- bed2gr(m.bed)
                        rcounts.scaled <- lapply(B, function(i) Gscale[i]*countOverlaps(m.gr, ibams[[i]], type="any", ignore.strand=TRUE) )
                        
                        m <- cbind(
                            m,
                            ScaledReads=round(rcounts.scaled$IP,0),
                            InpScaledReads=round(rcounts.scaled$inp,0),
                            MeanHt=sapply(mcovg$IP,mean),
                            MedHt=sapply(mcovg$IP,median),
                            MaxHt=sapply(mcovg$IP,max),
                            TotBp=sapply(mcovg$IP,sum),
                            MeanHt.RPM=sapply(mcovg.rpm$IP,mean),
                            MedHt.RPM=sapply(mcovg.rpm$IP,median),
                            MaxHt.RPM=sapply(mcovg.rpm$IP,max),
                            TotBp.RPM=sapply(mcovg.rpm$IP,sum),
                            InpMeanHt.RPM=sapply(mcovg.rpm$inp,mean),
                            InpMedHt.RPM=sapply(mcovg.rpm$inp,median),
                            InpMaxHt.RPM=sapply(mcovg.rpm$inp,max),
                            InpTotBp.RPM=sapply(mcovg.rpm$inp,sum),
                            LFC.RPM.tot=rep(0,N5),
                            LFC.RPM.max=rep(0,N5),
                            Pois.P=rep(0,N5),
                            Pois.P.BH=rep(0,N5)
                        )
                        mcovg.rpm2 <- lapply(B, function(i) lapply(mcovg.rpm[[i]], function(x) x+this.pseudo[i] ) )
                        LFC.RPM <- lapply(1:N5, function(j) log2(mcovg.rpm2$IP[[j]]/mcovg.rpm2$inp[[j]]) )
                        m$LFC.RPM.max <- sapply(LFC.RPM,max)
                        m$LFC.RPM.tot <- log2( (m$TotBp.RPM+this.pseudo[1]) / (m$InpTotBp.RPM+this.pseudo[2]) )
                        m$Pois.P <- rowMeans(cbind(
                            Upper=ppois(floor(rcounts.scaled$IP)-1,floor(rcounts.scaled$inp),FALSE,FALSE),
                            Lower=ppois(ceiling(rcounts.scaled$IP)-1,ceiling(rcounts.scaled$inp),FALSE,FALSE)
                        ))
                        
                        ## re-restrict to final peaks (incl. fused peak sets) which have Poisson p-value <= maxP
                        m <- m[m$Pois.P<=maxP,]
                        N6 <- nrow(m)
                    }
                }
            }
        }
        chr.peaks[[n]] <- m
        chr.stats[[n]] <- c(
            Length=this.len,
            IP.Reads=this.rds[1], Input.Reads=this.rds[2],
            IP.Reads.Scaled=this.rds.scaled[1], Input.Reads.Scaled=this.rds.scaled[2],
            IP.RPM.Pseudo=this.pseudo[1], Input.RPM.Pseudo=this.pseudo[2],
            Bkg.Max.Height=this.minht, Peak.Min.Height=this.callht,
            Raw.Islands=N1, Wide.Islands=N2, Called.Peaks=N3,
            HiFC.Peaks=N4, Merge.Peaks=N5, SigP.Peaks=N6
        )
        message(paste(chr,":",round(this.rds.scaled[1],0),round(this.rds.scaled[2],0),":",round(this.minht,2),round(this.callht,2),":",N1,N2,N3,N4,N5,N6))
    }
    
    ## combine chrom datasets into genomic datasets
    now <- system("date", intern=TRUE)
    message(paste("Finalizing:",now))
    peaks <- do.call(rbind, chr.peaks)
    if (nrow(peaks)>0) {
        peaks$ID <- sprintf(paste0(prefix,"_%0",nchar(nrow(peaks)),"i"),1:nrow(peaks))
        peaks$Pois.P.BH <- p.adjust(peaks$Pois.P, "BH")
    }
    stats <- rep(0, length(chr.stats[[1]])); names(stats) <- names(chr.stats[[1]])
    for (n in S) stats <- stats + chr.stats[[n]]
    stats[grepl("(Pseudo|Height)",names(stats))] <- NA
    args <- list(call=c(deparse(substitute(IP)),deparse(substitute(inp)),minHeight,minWidth,mergeGap,minFC,bkg,call,prefix),seqNames=seqNames,minht=minht)
    
    list(
        peaks=peaks,
        args=args,
        stats=do.call(rbind, c(list(Genome=stats), chr.stats)),
        covg.percentiles=c(list(Genome=gbp.mat), cbp.mat)
    )
}


apa.names$dev <- c(apa.names$dev, "call.peaks")
call.peaks <- function(IP, inp, maxP=0.05, bkg.pctl=90, prefix="Peak", scale.to=c("input","IP","larger","smaller"), seqNames=NULL) {  # mergeGap=0, 
    
    ## IMPROVEMENTS TO BE MADE:
    ## Multi-IP calling (i.e. 'IP' is a list of bams)
    ## pass in precomputed percentile tables
    ## Trim tails / split peaks on N5 set which are below minFC (to get them above minFC)
    ## threshold-by-chromosome option in case chr behaviors are too different to threshold all at once
    
    ## 'IP', 'inp' are bam-derived GRanges lists
    
    scale.to <- match.arg(scale.to)
    
    now <- system("date", intern=TRUE)
    message(paste("Preparing:",now))
    if (length(seqNames)>0) {
        ibams <- list( IP=keepSeqlevels(IP,seqNames), inp=keepSeqlevels(inp,seqNames) )
    } else {
        ibams <- list( IP=IP, inp=inp )
    }
    B <- 1:2; names(B) <- c("IP","inp")
    seqNames <- levels(seqnames(ibams$inp))  # ensure these are in GenomicRanges order
    S <- 1:length(seqNames); names(S) <- seqNames
    
    rlen <- width(ranges(IP[1]))  # read length
    chr.len <- attr(ibams$inp,"seqinfo")@seqlengths  # chromosome bp
    names(chr.len) <- levels(seqnames(ibams$inp))
    chr.len <- chr.len[match(seqNames,names(chr.len))]
    Glen <- sum(chr.len)  # genome bp
    Grds <- sapply(ibams,length)  # reads/alignments per bam
    
    Gscale <- c(IP=1,inp=1)  # initial scaling factors
    if (scale.to == "input") {
        Gscale[1] <- Grds[2]/Grds[1]  # scale IP towards input
        message(paste(c(Grds,":",Gscale[1]),collapse=" "))
    } else if (scale.to == "IP") {
        Gscale[2] <- Grds[1]/Grds[2]  # scale input towards IP
        message(paste(c(Grds,":",Gscale[2]),collapse=" "))
    } else if (scale.to == "larger") {
        Gscale[which.min(Grds)] <- max(Grds)/min(Grds)  # scale smaller sample towards larger
        message(paste(c(Grds,":",max(Gscale)),collapse=" "))
    } else if (scale.to == "smaller") {
        Gscale[which.max(Grds)] <- min(Grds)/max(Grds)  # scale larger sample towards smaller
        message(paste(c(Grds,":",min(Gscale)),collapse=" "))
    }
    
    now <- system("date", intern=TRUE)
    message(paste("Counting reads on chromosomes:",now))
    Grds.scaled <- Grds*Gscale  # post-scaling, both values are same
    Gpseudo <- 1E6/Grds.scaled/2   # whole-genome RPM pseudocount (RPM of 0.5 reads) for adjusting prior to Log-FC
    chr.rds <- merge.table.list(lapply(ibams, function(x) table(as.character(seqnames(x))) ))  #  read counts per chrom
    chr.rds <- chr.rds[,match(seqNames,colnames(chr.rds))]
    chr.rds.scaled <- Gscale*chr.rds   # scaled read counts per chrom
    chr.pseudo <- 1E6/chr.rds.scaled/2   # per-chrom RPM pseudocounts (RPM of 0.5 reads) for adjusting prior to Log-FC
    for (i in 1:length(chr.pseudo)) chr.pseudo[i] <- 1E6/Grds.scaled[1]/2     ##### REPLACE WITH GENOMIC RPM PSEUDOCOUNTS
    
    ## per-bam-per-chromosome objects
    now <- system("date", intern=TRUE)
    message(paste("Calculating coverage vectors:",now))
    covg <- lapply(B, function(i) coverage(ibams[[i]])*Gscale[i] )  # scaled read coverage
    rpm <- lapply(B, function(i) lapply(1:length(seqNames), function(j) 1E6*Gscale[i]*covg[[i]][[j]]/Grds.scaled[i] ))  # scaled RPM coverage
    
    ## set background and call vectors, one value per bam
    now <- system("date", intern=TRUE)
    message(paste("Calculating genome-wide percentiles:",now))
    Gbkg <- lapply(B, function(i) zapsmall(percentiles(unlist(lapply(covg[[i]],as.numeric))))[2:101] )  # one value per bam
    Gbkg.rpm <- lapply(B, function(i) zapsmall(1E6*Gbkg[[i]]/sum(Grds.scaled[i])) )
    minht <- rep(Gbkg$IP[call.lower], max(S))  # PERCENTILES IN READ HEIGHT
    min.rpm <- rep(Gbkg.rpm$IP[call.lower], max(S))  # PERCENTILES IN RPM
    gbp.mat <- colname( do.call(cbind, c(Gbkg,Gbkg.rpm)), paste(rep(c("IP","Input"),2),rep(c("Rds","RPM"),each=2)) )  # bkg pctl matrix
    
    now <- system("date", intern=TRUE)
    message(paste("Calculating chromosome percentiles:",now))
    Cbkg <- lapply(S, function(j) lapply(B, function(i) zapsmall(percentiles(as.numeric(covg[[i]][[j]])))[2:101] ))  # one value per chromosome per bam
    Cbkg.rpm <- lapply(S, function(j) lapply(B, function(i) zapsmall(1E6*Cbkg[[j]][[i]]/Grds.scaled[1]) ))
    cbp.mat <- lapply(S, function(j) colname( do.call(cbind, c(Cbkg[[j]],Cbkg.rpm[[j]])), paste(rep(c("IP","Input"),2),rep(c("Rds","RPM"),each=2)) ))  # bkg pctl matrices
    
    ## chromosomal objects
    chr.peaks <- chr.stats <- new.list(seqNames)
    
    m.tmp <- data.frame(
        Chr="", Start=0, End=0, ID="", Width=0,
        Pois.P=1, Pois.FDR=1,
        LFC.RPM.max=0, LFC.RPM.tot=0,
        ScaledReads=0, InpScaledReads=0, 
        MeanHt=0, MedHt=0, MaxHt=0, TotBp=0,
        MeanHt.RPM=0, MedHt.RPM=0, MaxHt.RPM=0, TotBp.RPM=0,
        InpMeanHt.RPM=0, InpMedHt.RPM=0, InpMaxHt.RPM=0, InpTotBp.RPM=0,
        stringsAsFactors=FALSE
    )
    
    ## process chromosome at a time
    now <- system("date", intern=TRUE)
    message(paste("Calling peaks per chromosome:",now))
    for (n in S) {
        
        chr <- seqNames[n]
        this.minht <- minht[n]
        this.pseudo <- Gpseudo  # chr.pseudo[,n]
        this.len <- chr.len[n]
        this.rds <- chr.rds[,n]
        this.rds.scaled <- chr.rds.scaled[,n]
        
        N1 <- N2 <- N3 <- N4 <- N5 <- N6 <- 0
        
        ## call islands w/ background subtraction
        isl1 <- slice(covg$IP[[n]], lower=this.minht)
        N1 <- length(isl1)  # total islands
        
        if (N1==0) {
            m <- m.tmp[0,]
        } else {
            
            ## restrict by island width -- must exceed read length
            isl2 <- isl1[width(isl1)>rlen] 
            N2 <- length(isl2)  # wide-enough islands 
            
            if (N2==0) {
                m <- m.tmp[0,]
            } else {
                m <- as.matrix(ranges(isl2))
                m <- data.frame(
                    Chr=rep(chr,N2),
                    Start=m[,1],
                    End=m[,1]+m[,2]-1,
                    ID="",
                    Width=m[,2],
                    stringsAsFactors=FALSE
                )
                
                ## with minimal m defined, prep some stats
                covg2 <- lapply(covg, function(x) as.numeric(x[[n]]) )  # CONVERT COVERAGES TO NUMERIC VECTORS
                mcovg <- lapply(B, function(i) lapply(1:N2, function(j) covg2[[i]][m$Start[j]:m$End[j]] ))
                mcovg.rpm <- lapply(B, function(i) lapply(mcovg[[i]], function(x) 1E6*x/Grds.scaled[i] ) )
                mcovg.rpm.adj <- lapply(B, function(i) lapply(mcovg.rpm[[i]], function(x) x+this.pseudo[i] ) )
                LFC.RPM <- lapply(1:N2, function(j) log2(mcovg.rpm.adj$IP[[j]]/mcovg.rpm.adj$inp[[j]]) )
                m.gr <- bed2gr(cbind(m[,1:4],1:N2,"+"))
                rcounts.scaled <- lapply(B, function(i) Gscale[i]*countOverlaps(m.gr, ibams[[i]], type="any", ignore.strand=TRUE) )
                
                ## add rest of stats
                m <- cbind(
                    m,
                    Pois.P=rep(1,N2),
                    Pois.FDR=rep(1,N2),
                    LFC.RPM.tot=rep(0,N2),
                    LFC.RPM.max=sapply(LFC.RPM,max),
                    ScaledReads=round(rcounts.scaled$IP,0),
                    InpScaledReads=round(rcounts.scaled$inp,0),
                    MeanHt=sapply(mcovg$IP,mean),
                    MedHt=sapply(mcovg$IP,median),
                    MaxHt=sapply(mcovg$IP,max),
                    TotBp=sapply(mcovg$IP,sum),
                    MeanHt.RPM=sapply(mcovg.rpm$IP,mean),
                    MedHt.RPM=sapply(mcovg.rpm$IP,median),
                    MaxHt.RPM=sapply(mcovg.rpm$IP,max),
                    TotBp.RPM=sapply(mcovg.rpm$IP,sum),
                    InpMeanHt.RPM=sapply(mcovg.rpm$inp,mean),
                    InpMedHt.RPM=sapply(mcovg.rpm$inp,median),
                    InpMaxHt.RPM=sapply(mcovg.rpm$inp,max),
                    InpTotBp.RPM=sapply(mcovg.rpm$inp,sum)
                )
                
                ## fill in LFC.RPM.tot and Pois.P
                m$LFC.RPM.tot <- log2( (m$TotBp.RPM+this.pseudo[1]) / (m$InpTotBp.RPM+this.pseudo[2]) )
                m$Pois.P <- rowMeans(cbind(
                    Upper=ppois(floor(rcounts.scaled$IP)-1,floor(rcounts.scaled$inp),FALSE,FALSE),
                    Lower=ppois(ceiling(rcounts.scaled$IP)-1,ceiling(rcounts.scaled$inp),FALSE,FALSE)
                ))
            }
        }

        ## store chromosome-wise stats
        N3 <- sum(m$Pois.P<=maxP)
        N4 <- sum(m$Pois.P<=maxP & m$LFC.RPM.max>=minFC)
        chr.peaks[[n]] <- m
        chr.stats[[n]] <- c(
            Length=this.len,
            IP.Reads=this.rds[1], Input.Reads=this.rds[2],
            IP.Reads.Scaled=this.rds.scaled[1], Input.Reads.Scaled=this.rds.scaled[2],
            IP.RPM.Pseudo=this.pseudo[1], Input.RPM.Pseudo=this.pseudo[2],
            Bkg.Max.Height=this.minht, Peak.Min.Height=this.callht,
            Raw.Peaks=N1, Wide.Peaks=N2, Sig.Peaks=N3, PosFC.Peaks=N4
#            Raw.Islands=N1, Wide.Islands=N2, Called.Peaks=N3,
#            HiFC.Peaks=N4, Merge.Peaks=N5, SigP.Peaks=N6
        )
        message(paste(chr,":",round(this.rds.scaled[1],0),round(this.rds.scaled[2],0),":",round(this.minht,2),round(this.callht,2),":",N1,N2,N3,N4)) #,N5,N6))
    }
    
    ## combine chrom datasets into genomic datasets
    now <- system("date", intern=TRUE)
    message(paste("Finalizing:",now))
    peaks <- do.call(rbind, chr.peaks)
    if (nrow(peaks)>0) {
        peaks$ID <- sprintf(paste0(prefix,"_%0",nchar(nrow(peaks)),"i"),1:nrow(peaks))
        peaks$Pois.FDR <- p.adjust(peaks$Pois.P, "BH")
    }
    stats <- rep(0, length(chr.stats[[1]])); names(stats) <- names(chr.stats[[1]])
    for (n in S) stats <- stats + chr.stats[[n]]
    stats[grepl("(Pseudo|Height)",names(stats))] <- NA
    args <- list(call=c(deparse(substitute(IP)),deparse(substitute(inp)),bkg.pctl,prefix),seqNames=seqNames,minht=minht)
    
    list(
        peaks=peaks,
        args=args,
        stats=do.call(rbind, c(list(Genome=stats), chr.stats)),
        covg.percentiles=c(list(Genome=gbp.mat), cbp.mat)
    )
}


apa.names$general <- c(apa.names$general, "peak.killcurve")
peak.killcurve <- function(fg, bg, N=1000, fdr=0) {
	
	## Compares foreground vs background CDFs and finds crossover point, if any
	## Designed to compute kill-curve-based thresholds for peak statistics, given vectors of foreground and background statistics.
	## Also for finding critical dropoffs with chipseq IP/inp-vs-inp/IP peak calls
	## 'N' specifies the sampling for the p-value CDF (N bins to break p-value range into)
	## 'fdr' indicates the "false-discovery rate" threshold, as defined by setting the threshold such that fdr% of background peaks are above it.
	
	cdf <- get.killcurve.cdf(fg, bg, N)
	thresh <- quantile(bg, 1-fdr, na.rm=TRUE)
	pass.fg <- sum(fg>thresh)
	pass.bg <- sum(bg>thresh)
	passing <- c(FG=pass.fg, FG.PCT=pass.fg/length(fg), BG=pass.bg, BG.PCT=pass.bg/length(bg) )
	
	c(cdf, list(threshold=thresh, abline=rescale(thresh,from=range(as.numeric(cdf$axis.lab)),to=c(1,N)), passing=passing))
}


apa.names$bio.seq <- c(apa.names$bio.seq, "read.mergePeaks")
read.mergePeaks <- function(dir, key=TRUE) {
    
    ## reads pertinent datasets from a mergePeaks output directory
    ## outputs: venn groups, venn histo, venn cooc, factor cooc, key, source2merge, final peaks w/ groupings & factors
    
    ## TO DO: add factors to output$peaks, fix source2merge
    
    output <- vector("list", length=8) 
    ## some elements may be null; depends on the version of mergePeaks that was run
    names(output) <- c("venn.areas","uniqueness.histogram","cooccurrence.matrix","factor.cooccurrence.matrix","peaks","source2merge","key","inputs")
    
    ## Chop up venn_data.txt
    x <- scan(paste0(dir,"/venn_data.txt"), what="", sep="\n")
    va <- which(x=="Venn_Areas:")
    uh <- which(x=="Uniqueness_Histogram:")
    cm <- which(x=="Cooccurrence_Matrix:")
    fc <- which(x=="Factor_Cooccurrence_Matrix:")
    if (length(fc)==0) fc <- length(x)+1
    VA <- do.call(rbind, strsplit(sub("\t$","\t0",gsub("\t\t","\t0\t",gsub("\t\t","\t0\t",x[(va+1):(uh-1)]))),"\t"))
    colnames(VA) <- VA[1,]
    VA <- as.data.frame(VA[2:nrow(VA),], stringsAsFactors=FALSE)
    numcol <- 2:3
    if (ncol(VA)>4) numcol <- c(numcol,setdiff(1:ncol(VA),1:4))
    for (i in numcol) mode(VA[[i]]) <- "numeric"
    VA[is.na(VA)] <- 0
    output$venn.areas <- VA
    UH <- do.call(rbind, strsplit(x[(uh+1):(cm-1)],"\t"))
    colnames(UH) <- UH[1,]
    output$uniqueness.histogram <- rownamed.matrix(UH[2:nrow(UH),])
    CM <- do.call(rbind, strsplit(x[(cm+1):(fc-1)],"\t"))
    colnames(CM) <- CM[1,]
    output$cooccurrence.matrix <- rownamed.matrix(CM[2:nrow(CM),])
    if (fc<length(x)) {
        FC <- do.call(rbind, strsplit(x[(fc+1):length(x)],"\t"))
        colnames(FC) <- FC[1,]
        output$factor.cooccurrence.matrix <- rownamed.matrix(FC[2:nrow(FC),])
    }

    ## Add other datasets
    peaks <- read.delim(paste0(dir,"/final.bed"), as.is=TRUE, header=FALSE)
    output$peaks <- cbind(peaks, Group=sub(".*_","",sub("_[0-9]+$","",peaks[,4])))
    output$source2merge <- read.delim(paste0(dir,"/source2merge.txt"), as.is=TRUE)
    if (key) {
        key1 <- read.delim(paste0(dir,"/merged_peaks_key.txt"), as.is=TRUE)
        output$key <- list(Final_Peak_ID=key1[,1], Merged_Peaks=strsplit(key1[,2],";"))
    }
    inputs <- paste0(dir,"/inputs.txt")
    if (file.exists(inputs)) output$inputs <- read.delim(inputs, as.is=TRUE)
    
    output
}


apa.names$bio.seq <- c(apa.names$bio.seq, "filter.mergePeaks")
filter.mergePeaks <- function(merge, IDs) {
    
    ## restricts a read.mergePeaks() dataset to only those peaks specified by 'IDs'
    ## peak names in 'IDs' must be a subset of merge$peaks[,4]
    ## recalculates everything
    
    N <- nrow(merge$uniqueness.histogram)
    before <- nrow(merge$peaks)
    
    ## filter $peaks
    merge$peaks <- merge$peaks[merge$peaks[,4] %in% IDs,]
    after <- nrow(merge$peaks)
    message(paste(after,"peaks retained |",before-after,"peaks removed"))
    ## filter $source2merge
    merge$source2merge <- merge$source2merge[merge$source2merge[,4] %in% IDs,]
    ## filter $key
    w <- match(IDs, merge$key[[1]])
    for (i in 1:2) merge$key[[i]] <- merge$key[[i]][w]
    ## recalculate $venn.areas
    u <- unique(merge$source2merge[,3:4])
    tu <- table(u[,1])
    merge$venn.areas$Final_Peaks[match(names(tu),merge$venn.areas$Group_ID)] <- c(tu)
    ## recalculate $uniqueness.histogram
    for (i in 1:N) {
        is.src <- merge$source2merge$Source==rownames(merge$uniqueness.histogram)[i]
        merge$uniqueness.histogram[i,"Total"] <- sum(is.src)
        for (j in 1:N) {
            merge$uniqueness.histogram[i,j+1] <- luniq(merge$source2merge$Merge[is.src & merge$source2merge$Group %in% merge$venn.areas$Group_ID[merge$venn.areas$N_Sources==j]])
        }
    }
    ## recalculate $cooccurrence.matrix
    for (i in 1:N) {
        is.i <- merge$source2merge$Source==rownames(merge$uniqueness.histogram)[i]
        for (j in 1:N) {
            is.j <- merge$source2merge$Source==rownames(merge$uniqueness.histogram)[j]
            merge$cooccurrence.matrix[i,j] <- length(intersect(merge$source2merge$Merge[is.i], merge$source2merge$Merge[is.j]))
        }
    }
    merge$cooccurrence.matrix[,N+1] <- merge$uniqueness.histogram[,1]
    merge$cooccurrence.matrix[,N+2] <- merge$cooccurrence.matrix[,N+1]-diag(merge$cooccurrence.matrix[1:N,1:N])
    
    merge
}


apa.names$bio.seq <- c(apa.names$bio.seq, "mergePeaks.venn")
mergePeaks.venn <- function(merge, main=NULL, as.pct=FALSE) {
    
    ## Takes a read.mergePeaks() output, and returns the $venn.areas element as a list of peak names, of class 'venn.areas'
    ## also plots the venn diagram
    
    uh <- merge$uniqueness.histogram
    va <- merge$venn.areas
    if (nrow(uh)>5) stop("Cannot make a venn diagram with > 5 sets!\n")
    
    VA <- venn.areas(new.list(sort(rownames(uh)), elem=1))
    for (i in 1:nrow(va)) {
        name <- paste(sort(unlist(strsplit(va[i,4],";"))),collapse="&")
        w <- match(name, names(VA))
        VA[[w]] <- merge$peaks[merge$peaks$Group==va[i,1],4]
    }
    
    if (length(main)==0) main <- ""
    venn.diag(VA, main=main, as.pct=as.pct)
    invisible(VA)
}


apa.names$general <- c(apa.names$general, "bed2gr")
bed2gr <- function(bed, zero.based=TRUE) {
    if (require("GenomicRanges")) {
        for (i in 2:3) bed[[i]] <- as.integer(bed[[i]])
        if (zero.based) {  # bed coords are zero-based: shift to one-based for gr
            bed[,2] <- bed[,2] + 1
        }
        if (ncol(bed)>=6) {
            GRanges(bed[,1], IRanges(bed[,2], bed[,3], bed[,3]-bed[,2]+1, bed[,4]), bed[,6])  # with strand
        } else {
            GRanges(bed[,1], IRanges(bed[,2], bed[,3], bed[,3]-bed[,2]+1, bed[,4]))  # without strand
        }
    } else {
        stop("Could not load library 'GenomicRanges'\n")
    }
}


apa.names$general <- c(apa.names$general, "gr2bed")
gr2bed <- function(gr, zero.based=FALSE, scores=NULL) {
    if (length(gr)==0) {
        message("No data in GenomicRanges object!")
        return() 
    }
    if (require("GenomicRanges")) {
        chr <- as.character(seqnames(gr))
        st <- start(gr)
        en <- end(gr)
        id <- as.character(names(gr))
        if (length(id)==0) id <- 1:length(chr)
        str <- as.character(strand(gr))
        if (zero.based) {  # gr coords are one-based: shift to zero-based if you want correct BED format
            st <- st - 1
        }
        with.scores <- TRUE
        if (length(scores)==0) {  # if you didn't specify your own scores
            scores <- rep(1,length(st))
            with.scores <- FALSE
        }
        if (all(str == "*")) {  # no strand info
            if (with.scores) {
                data.frame(CHR=chr,START=st,END=en,NAME=id,SCORE=scores)  # strands: no | scores: given
            } else {
                data.frame(CHR=chr,START=st,END=en,NAME=id)  # strands: no | scores: not given
            }
        } else {
            data.frame(CHR=chr,START=st,END=en,NAME=id,SCORE=scores,STRAND=str)  # strands: yes | scores: given, or dummy data
        }
    } else {
        stop("Could not load library 'GenomicRanges'\n")
    }
}


apa.names$bio.seq <- c(apa.names$bio.seq, "overlapSizes")
overlapSizes <- function(mat, gr1, gr2, method=c("all","max","min"), multi=TRUE) {
    stop("DEPRECATED: please use findOverlaps2()\n")
}


apa.names$bio.seq <- c(apa.names$bio.seq, "findOverlaps2")
findOverlaps2 <- function(query, subject=NULL, maxgap=0L, minoverlap=1L, type=c("any", "start", "end", "within", "equal"),
                          select=c("all", "first", "last", "arbitrary"), ignore.strand=FALSE, ignore.self=FALSE, only=c("all","smallest","largest")) {
    
    ## returns findOverlaps() result as a matrix, with extra columns
    ## arguments identical to GenomicRanges::findOverlaps(), except for"
    ## - 'ignore.self', which is only used if subject=NULL.
    ## - 'only', which indicates to filter results query-wise for the indicated overlap width
    ##   i.e. only="smallest" returns only the smallest overlap(s) per query; only="largest" the largest, only="all" returns everything.
    
    require(GenomicRanges)
    
    only <- match.arg(only)
    self <- FALSE
    if (length(subject)==0) {
        subject <- query
        self <- TRUE
    }
    ignore.self <- ignore.self & self
    
    ol <- suppressWarnings(findOverlaps(query=query, subject=subject, maxgap=maxgap, minoverlap=minoverlap, type=type, select=select, ignore.strand=ignore.strand))
    if (ignore.self) ol <- ol[attr(ol,"queryHits")!=attr(ol,"subjectHits")]
    olr <- as.matrix(ranges(ol, query@ranges, subject@ranges))
    olm <- as.matrix(ol)
    i <- olm[,1]
    j <- olm[,2]
    
#    output <- data.frame(
#        query=i, subject=j, seqname=as.character(seqnames(query))[i],
#        queryStart=start(query)[i], queryEnd=end(query)[i], queryName=names(query)[i], queryWidth=width(query)[i], queryStrand=as.character(strand(query))[i], 
#        subjectStart=start(subject)[j], subjectEnd=end(subject)[j], subjectName=names(subject)[i], subjectWidth=width(subject)[j], subjectStrand=as.character(strand(subject))[j],
#        overlapStart=olr[,1], overlapEnd=olr[,1]+olr[,2]-1, overlapWidth=as.integer(olr[,2])
#    )
    output <- data.frame(query=i, subject=j, overlapWidth=as.integer(olr[,2]))
    
    ## dups <- union( duplicated2(output[,1]), duplicated2(output[,2]) )
    ## CURRENTLY THIS IS QUERY-CENTRIC
    ## LATER THERE SHOULD BE SUBJECT-CENTRIC AND ACENTRIC (?) MODES (acentric being joint-smallest/largest, but this may not be resolvable for all overlap pairs)
    if (only != "all") {
        which.func <- if (only=="smallest") { which.min } else { which.max }
        keep <- rep(FALSE, nrow(output))
        dups <- which(duplicated2(output[,1]))
        unq <- setdiff(1:nrow(output), dups)
        keep[unq] <- TRUE
        keep[unlist(lapply(unique(output[dups,1]), function(i){ w=which(output[,1]==i); w[which.func(output$overlapWidth[w])] }))] <- TRUE
        output <- output[keep,]
    }
    
    output
}


apa.names$general <- c(apa.names$general, "gr.overlap.table")
gr.overlap.table <- function(gr1, gr2) {
    
    gr12 <- suppressWarnings(reduce(c(gr1,gr2)))
    gr12.ol1 <- as.matrix(findOverlaps(gr12,gr1))
    gr12.ol2 <- as.matrix(findOverlaps(gr12,gr2))
    gr12.olt <- lapply(list(table(gr12.ol1), table(gr12.ol2)), function(x) cbind(MERGE=as.numeric(names(x)),INPUT=c(x)) )
    gr12.1to2 <- matrix(0, length(gr12), 2)
    gr12.1to2[gr12.olt[[1]][,1],1] <- gr12.olt[[1]][,2]
    gr12.1to2[gr12.olt[[2]][,1],2] <- gr12.olt[[2]][,2]
    table(GR1=gr12.1to2[,1],GR2=gr12.1to2[,2])
}


apa.names$general <- c(apa.names$general, "nearest")
nearest <- function(x, vec, direction=c("0","1","-1"), index=FALSE, distance=FALSE) {
   
###### FIXME: direction !=0 no longer works
###### FIXME: if 'vec' contains multiple same nearest values, then pick index at correct side of equal-value run, depending if 'x' is higher or lower than that nearest value
      
    ## For values 'x', find its nearest neighbor in 'vec'
    ## 'direction' values: '-1' for nearest <= x, '1' for nearest >= x, '0' for absolute nearest.
    ## 'index' = whether to return the nearest position in 'vec' (TRUE) or the actual value from 'vec' (FALSE).
    ## 'distance' = whether to return the signed distance to the nearest position in 'vec' (TRUE) or the actual value from 'vec' (FALSE).
    ## if 'distance=T', negative values indicate n < x and positive values indicate n > x.
    ## 'index' and 'distance' cannot both be TRUE.
    
    direction <- as.character(direction)  # so can specify "0" or 0
    direction <- as.numeric(match.arg(direction))  # but lame match.arg() can only consider character vectors; then recast back to numeric
    if (index & distance) stop("'index' and 'distance' cannot both be TRUE!\n")
    if (length(vec)==0) return(NA)
    y <- rep(NA,length(x))
    
    for (i in 1:length(x)) {
        if (!is.na(x[i])) {
            d <- x[i] - vec
            if (direction == 0) {
                n <- which.min(abs(d))
            } else if (direction == 1) {
                gt <- which(d <= 0)
                n <- ifelse(length(gt)>0, gt[which.min(d[gt])], NA)
            } else if (direction == -1) {
                lt <- which(d >= 0)
                n <- ifelse(length(lt)>0, lt[which.max(d[lt])], NA)
            }
            
            if (index) {
                y[i] <- n
            } else if (distance) {
                y[i] <- vec[n]-x[i]
            } else {
                y[i] <- vec[n]
            }
	}
    }
    return(y)
}


apa.names$general <- c(apa.names$general, "minmax")
minmax <- function(targets, positions, values, window, direction=c("0","1","-1"), minmax=c("max","min"), nearest=FALSE) {
	
	## Finds minimum or maximum value(s) within some distance from 'targets'.
	## args as for 'nearest', except:
	##  'values' is a vector of numeric values corresponding to 'positions'.  These will be searched for min/max values.
	##  'window=N' sets a search window of size N, which may be:
	##    centered in targets[i] (distance=0),
	##    upstream of targets[i] (distance=-1),
	##    downstream of targets[i] (distance=1).
	##  'minmax' which indicates search for min or max value
	##  'nearest' which indicates to take only the nearest of N equivalent minima/maxima (nearest in 'positions' to targets[i]).
	
	direction <- as.character(direction)
	direction <- match.arg(direction)
	minmax <- match.arg(minmax)
	ismax <- ifelse(minmax=="max",TRUE,FALSE)
	lt <- length(targets)
	
	find.minmax <- function (x) {
		win <-	if (direction==0) {
					c(x-(window/2), x+(window/2))
				} else if (direction==1) {
					c(x, x+window)
				} else if (direction==-1) {
					c(x-window, x)
				}
		w <- which(positions>=win[1]&positions<=win[2])
		if (length(w)>0) {
			mmi <- w[ternary(ismax,which(values[w]==max(values[w])),which(values[w]==min(values[w])))]
			res <- cbind(Index=mmi, Position=positions[mmi], Value=values[mmi], Distance=zapsmall(positions[mmi]-x))
			if (nearest) res <- res[which(abs(res[,4])==min(abs(res[,4]))),,drop=FALSE]
			res
		} else {
			cbind(Index=NA, Position=NA, Value=NA, Distance=NA)
		}
	}

	lapply(targets, find.minmax)
}


apa.names$general <- c(apa.names$general, "nearest.neighbors")
nearest.neighbors <- function (x, y, direction=c("both","any","up","down"), strand=c("any","same","opp","both"), as.list=FALSE, chr.sizes=NULL, zero.based=FALSE, split.symbol=FALSE) {
    
    ## FIXME #1: OUTPUT CHR.START, CHR.END ENTRIES FOR UNMATCHED PEAKS
    
    ## takes two bed-format data frames or GRanges objects (x, y); must be full 6-column to use strand=c("same","opp").
    ## for each entry in x, returns the nearest neighbor(s) from y.
    ## neighbors can be restricted to upstream ("up"), downstream ("down"), either up or down ("any"), or both up and down ("both").
    ## neighbors can be restricted to the same strand ("same"), the opposite strand ("opp"), either ("any"), or both strands ("both").
    ## there may be > 1 nearest neighbor for a given coordinate, so the return object is a list with length=nrow(x).
    ##  elements of return list are selections from y, with a distance column attached.  Distance values are signed.
    ## NOTE: using strand="both" will double the number of NN column sets.
    
    if (!require("GenomicRanges")) stop("Could not load library 'GenomicRanges'\n")
    if (length(x)==0 | length(y)==0) { 
        message("Both x and y must have data!") 
        return()
    }
    direction <- match.arg(direction)
    strand <- match.arg(strand)
    
    if (length(chr.sizes)>0) {
        if (length(names(chr.sizes))==0 | !is.nlv(chr.sizes)) stop("If specified, 'chr.sizes' must be a vector of chr lengths with names == chr names!\n")
    }
    
    if (class(x)=="GRanges") x <- gr2bed(x)
    if (class(y)=="GRanges") y <- gr2bed(y)
    
    if (ncol(x)<4) x <- cbind(x,1:nrow(x),1,"+")  # fake rest of 6-col BED columns, if necessary
    if (ncol(y)<4) y <- cbind(y,1:nrow(y),1,"+")
    
    if (ncol(x)>6) x <- x[,1:6]  # restrict to 6-col BED columns, if necessary
    if (ncol(y)>6) y <- y[,1:6]
    
    have.strands <- ifelse(ncol(x)>=6 & ncol(y)>=6, TRUE, FALSE)
    if (strand != "any" & !have.strands) stop("Cannot specify strandedness without using 6-column BED format!\n")
    if (zero.based) {  # coords are 0-based; GenomicRanges expects 1-based
        x[,2] <- x[,2] + 1
        y[,2] <- y[,2] + 1
    }
    cnames <- qw(CHR,START,END,NAME,SCORE,STRAND)
    ncx <- ncol(x)
    ncy <- ncol(y)
    colnames(x) <- c(cnames[1],paste(cnames[2:ncx],"1",sep="."))
    colnames(y) <- paste(cnames[1:ncy],"2",sep=".")
    
    x2 <- mat.split(x, x[,1])
    y2 <- mat.split(y, y[,1])
    strands <- c("+","-")
    chr <- suniq(x[,1])
    which.chr.x <- named.list(lapply(chr, function(n) which(x[,1]==n) ), chr)
    which.chr.y <- named.list(lapply(chr, function(n) which(y[,1]==n) ), chr)
    NN <- new.list(x[,4])
    
    cwidth <- max(nchar(chr))
    xwidth <- nchar(nrow(x))
    ywidth <- nchar(nrow(y))
    fmt <- paste0("%-",cwidth,"s : %",xwidth,"i input coords : %",ywidth,"i neighbor pool")
    
    IM("Matching...")
    for (C in chr) {
        
        wCx <- which.chr.x[[C]]
        wCy <- which.chr.y[[C]]
        xC <- x2[[C]]
        yC <- y2[[C]]
        IM(sprintf(fmt, C, length(wCx), length(wCy)))
        
        neighborless <- FALSE
        nn.hit <- new.list(xC[,4])    # direct-hit neighbors; 1 element per input coord (that will be matched to neighbors)
        nn.up.as <- nn.dn.as <- new.list(xC[,4])   # all-strand non-hit neighbors, upstream and downstream
        nn.up.ss <- nn.dn.ss <- new.list(xC[,4])   # same-strand non-hit neighbors, upstream and downstream
        nn.up.os <- nn.dn.os <- new.list(xC[,4])   # opposite-strand non-hit neighbors, upstream and downstream
        
        if (length(yC)==0) {
            
            neighborless <- TRUE
            nn.hit   <- lapply(nn.up.as, function(x) cbind(NA, 0,NA,-1) )  # neighbor, dir, strand, class
            nn.up.as <- lapply(nn.up.as, function(x) cbind(NA,-1,NA,-1) )  # neighbor, dir, strand, class
            nn.dn.as <- lapply(nn.dn.as, function(x) cbind(NA, 1,NA,-1) )  # neighbor, dir, strand, class
            
        } else {
            
            y.gr <- bed2gr(yC)
            y.ir <- IRanges(start=start(y.gr), width=width(y.gr))
            
            if (strand == "any") {
                
                x.gr <- bed2gr(xC)
                x.ir <- IRanges(start=start(x.gr), width=width(x.gr))
                ## returning: neighbor, dir, strand, class
                nn.hit   <- lapply(as.list(suppressWarnings(IRanges::findOverlaps(x.ir,y.ir))),         function(x) cbind(ifelse(is.null(x),NA,x), 0,NA,0) )
                nn.up.as <- lapply(as.list(suppressWarnings(IRanges::follow(x.ir,y.ir,select="all"))),  function(x) cbind(ifelse(is.null(x),NA,x),-1,NA,1) )
                nn.dn.as <- lapply(as.list(suppressWarnings(IRanges::precede(x.ir,y.ir,select="all"))), function(x) cbind(ifelse(is.null(x),NA,x), 1,NA,2) )
                
            } else {
                
                which.str.x <- lapply(strands, function(s) sort(which(xC[,6]==s)) )  # separate input coords by strand
                which.str.y <- lapply(strands, function(s) sort(which(yC[,6]==s)) )  # separate neighbor pool by strand
                
                for (s in 1:2) {  # strands; 1="+", 2="-"
                    
                    wsx <- which.str.x[[s]]
                    wsy <- which.str.y[[s]]
                    if (length(wsx)==0 | length(wsy)==0) next
                    xCs <- xC[wsx,]
                    if (nrow(xCs)==0) next
                    x.gr <- bed2gr(xCs)
                    x.ir <- IRanges(start=start(x.gr), width=width(x.gr))
                    
                    nn.hit[wsx] <- as.list(suppressWarnings(IRanges::findOverlaps(x.ir,y.ir)))
                    all.blank <- wsx[ listLengths(nn.hit[wsx])>0 ]
                    nn.hit[all.blank] <- lapply(nn.hit[all.blank], function(y) cbind(y,0,0,0) )  # neighbor, dir, strand, class
                    
                    if (strand == "both") {
                        
                        yCs <- yC[wsy,]
                        yCs.gr <- bed2gr(yCs)
                        yCs.ir <- IRanges(start=start(yCs.gr), width=width(yCs.gr))
                        opp <- ifelse(s==1,2,1)
                        woy <- which.str.y[[opp]]
                        yCo <- yC[which.str.y[[opp]],]
                        yCo.gr <- bed2gr(yCo)
                        yCo.ir <- IRanges(start=start(yCo.gr), width=width(yCo.gr))
                        
                        ## returning: neighbor, dir, strand, class
                        nn.up.ss[wsx] <- lapply( as.list(suppressWarnings(IRanges::follow(x.ir,yCs.ir,select="all"))), function(y) cbind(ifelse(is.null(y),NA,wsy[y]),-1,s,1) )
                        nn.dn.ss[wsx] <- lapply( as.list(suppressWarnings(IRanges::precede(x.ir,yCs.ir,select="all"))), function(y) cbind(ifelse(is.null(y),NA,wsy[y]),1,s,2) )
                        nn.up.os[wsx] <- lapply( as.list(suppressWarnings(IRanges::follow(x.ir,yCo.ir,select="all"))), function(y) cbind(ifelse(is.null(y),NA,woy[y]),-1,opp,3) )
                        nn.dn.os[wsx] <- lapply( as.list(suppressWarnings(IRanges::precede(x.ir,yCo.ir,select="all"))), function(y) cbind(ifelse(is.null(y),NA,woy[y]),1,opp,4) )
                        
                        ## fill in ss blanks, which will become chr start/end entries
                        up.blank.ss <- wsx[ sapply(nn.up.ss[wsx], ncol)==3 ]
                        dn.blank.ss <- wsx[ sapply(nn.dn.ss[wsx], ncol)==3 ]
                        nn.up.ss[up.blank.ss] <- lapply(up.blank.ss, function(y) cbind(NA,-1,s,11) )  # neighbor, dir, strand, class
                        nn.dn.ss[dn.blank.ss] <- lapply(dn.blank.ss, function(y) cbind(NA, 1,s,12) )  # neighbor, dir, strand, class
                        
                        ## fill in os blanks, which will become chr start/end entries
                        up.blank.os <- wsx[ sapply(nn.up.os[wsx], ncol)==3 ]
                        dn.blank.os <- wsx[ sapply(nn.dn.os[wsx], ncol)==3 ]
                        nn.up.os[up.blank.os] <- lapply(up.blank.os, function(y) cbind(NA,-1,opp,11) )  # neighbor, dir, strand, class
                        nn.dn.os[dn.blank.os] <- lapply(dn.blank.os, function(y) cbind(NA, 1,opp,12) )  # neighbor, dir, strand, class
                        
                        nn.up.as[wsx] <- nn.up.ss[wsx]
                        nn.dn.as[wsx] <- nn.dn.ss[wsx]
                        for (i in wsx) {
                            nn.up.as[[i]] <- do.call(rbind, list(nn.up.ss[[i]], nn.up.os[[i]]))
                            nn.dn.as[[i]] <- do.call(rbind, list(nn.dn.ss[[i]], nn.dn.os[[i]]))
                        }
                        
                    } else {
                        
                        if (strand == "same") {
                            yCs <- yC[wsy, ]
                            str <- s
                        } else if (strand == "opp") {
                            str <- opp <- ifelse(s==1,2,1)
                            yCs <- yC[which.str.y[[opp]], ]
                        }
                        if (nrow(yCs)==0) next
                        yCs.gr <- bed2gr(yCs)
                        yCs.ir <- IRanges(start=start(yCs.gr), width=width(yCs.gr))
                        
                        ## returning: neighbor, dir, strand, class
                        nn.up.as[wsx] <- lapply( as.list(suppressWarnings(IRanges::follow(x.ir,yCs.ir,select="all"))),  function(y) cbind(ifelse(is.null(y),NA,wsy[y]),-1,str,1) )
                        nn.dn.as[wsx] <- lapply( as.list(suppressWarnings(IRanges::precede(x.ir,yCs.ir,select="all"))), function(y) cbind(ifelse(is.null(y),NA,wsy[y]), 1,str,2) )
                        
                        ## fill in blanks, which will become chr start/end entries
                        up.blank <- wsx[ sapply(nn.up.as[wsx], ncol)<=3 ]  # just for .ss; .os handled above if needed
                        dn.blank <- wsx[ sapply(nn.dn.as[wsx], ncol)<=3 ]
                        nn.up.as[up.blank] <- lapply(up.blank, function(y) cbind(NA,-1,str,13))  # neighbor, dir, strand, class
                        nn.dn.as[dn.blank] <- lapply(dn.blank, function(y) cbind(NA, 1,str,14))  # neighbor, dir, strand, class
                    }
                }
            }
        }
        
        for (i in 1:length(wCx)) {   # for each input gene on chr C
            ## Compile all hits for this input coord
            tmp <- list()
            if (nrow(nn.up.as[[i]])>0) tmp <- c( tmp, list( cbind(nn.up.as[[i]][,1:4,drop=FALSE], yC[nn.up.as[[i]][,1],3]-xC[i,2], match(yC[nn.up.as[[i]][,1],6],strands)) ) )
            if (nrow(nn.dn.as[[i]])>0) tmp <- c( tmp, list( cbind(nn.dn.as[[i]][,1:4,drop=FALSE], yC[nn.dn.as[[i]][,1],2]-xC[i,3], match(yC[nn.dn.as[[i]][,1],6],strands)) ) )
            if (nrow(nn.hit[[i]])>0)   tmp <- c( tmp, list( cbind(  nn.hit[[i]][,1:4,drop=FALSE],                               0, match(yC[  nn.hit[[i]][,1],6],strands)) ) )
            if (neighborless) {
                for (j in 1:length(tmp)) {
                    if (ncol(tmp[[j]])<6) tmp[[j]] <- cbind(tmp[[j]], colrep(rep(NA,nrow(tmp[[j]])), 6-ncol(tmp[[j]])))
                }
            }
            tmp <- as.data.frame(do.call(rbind, tmp), stringsAsFactors=FALSE)  # DATA.FRAME CLASS REQUIRED AFTER THIS POINT
            for (j in 1:ncol(tmp)) mode(tmp[[j]]) <- "integer"  # remove any float issues
            colnames(tmp) <- qw(Neighbor, Dir, Strand, Class, Distance, NbStrand)
            ## Flag distances / directions for chr ends
            dist.na.up <- is.na(tmp$Distance) & tmp$Dir < 0
            dist.na.dn <- is.na(tmp$Distance) & tmp$Dir > 0
            if (any(dist.na.up)) tmp$Distance[dist.na.up] <- -Inf
            if (any(dist.na.dn)) tmp$Distance[dist.na.dn] <- Inf
            ## Add actual data for input coord, neighbor(s)
            if (neighborless) {
                neighb.dat <- xC[NA,][1:3,]  # neighborless 'tmp' objects always have 3 rows
                colnames(neighb.dat) <- paste0(sub(".1$","",colnames(neighb.dat)),".2")
            } else {
                neighb.dat <- yC[tmp[,1],]
            }
            tmp <- cbind( rowrep(xC[i,],nrow(tmp)), neighb.dat, tmp[,5,drop=FALSE] )  # from 'tmp' keep only Distance; the other columns were for troubleshooting
            tmp <- tmp[!(is.na(tmp$CHR.2)&falsify(tmp$Distance==0)),]  # drop rows for nonexistent overlap-neighbors
            NN[[ wCx[i] ]] <- tmp[order(tmp$Distance),colnames(tmp)!="CHR.2"]  # sort by distance and drop redundant second chrom column
        }
    }
    
    IM("Collapsing...")
    ## collapse list to data.frame, add column flagging smallest-distance neighbors per input coord
    is.nearest <- function(x) {
        if (any(is.real(x))) {
            abs(x)==min(abs(x),na.rm=TRUE)
        } else {
            rep(FALSE, length(x))
        }
    }
    
    Nearest <- falsify(unlist(lapply(lapply(NN,"[[","Distance"), is.nearest)))
    NNnr <- sum(sapply(NN,nrow))
    NN2 <- NN[[1]][0,]  # rowless data.frame
    offset <- 0
    for (n in 1:length(NN)) {
        ## now avoiding do.call(rbind,NN) because will fail if too many chromosomes (e.g. nemVec1)
        if (nrow(NN[[n]])==0) next
        i <- offset+1
        j <- offset+nrow(NN[[n]])
        NN2[i:j,] <- NN[[n]]
        offset <- j
    }
    NN <- rownameless(cbind(NN2, Nearest=Nearest))
    rm(NN2)
    
    IM("Filtering...")
    if (direction == "both") {
        ## do nothing
    } else if (direction == "any") {
        NN <- NN[NN$Nearest,]  # take only smallest-distance neighbors
    } else if (direction == "up") {
        NN <- NN[NN$Dir<=0,]  # take only upstream or overlap neighbors
    } else if (direction == "down") {
        NN <- NN[NN$Dir>=0,]  # take only downstream or overlap neighbors
    }
    
    IM("Annotating neighborless positions...")
    ## Missing neighbor names mean neighbor == chrom start/end; label as such
    is.chr <- is.infinite(NN$Distance)
    if (any(is.chr)) {
        need.start <- sapply(NN$Distance,identical,-Inf)
        need.end <- sapply(NN$Distance,identical,Inf)
        NN$NAME.2[need.start] <- "CHR.START"
        NN$NAME.2[need.end] <- "CHR.END"
        if (length(chr.sizes)>0) {
            ## add distances to starts/ends if chromosome sizes are available.
            ## we could add start distances no matter what, but for consistency's sake, it's double or nothing.
            chr.ends <- chr.sizes[match(NN$CHR[need.end],names(chr.sizes))]
            NN$START.2[need.start] <- ifelse(zero.based, 0, 1)
            NN$END.2[need.start] <- ifelse(zero.based, 0, 1)
            NN$START.2[need.end] <- chr.ends
            NN$END.2[need.end] <- chr.ends
            NN$Distance[need.start] <- -NN$START.1[need.start]
            NN$Distance[need.end] <- chr.ends-NN$END.1[need.end]
        }
    }
    
    if (split.symbol) {
        IM("Splitting symbols...")
        ## neighbor names are "geneID:symbol"; split into separate columns
        wn2 <- which(colnames(NN)=="NAME.2")
        NN <- NN[,c(1:wn2,wn2:ncol(NN))]
        colnames(NN)[wn2+1] <- "SYMB.2"
        nsplit <- strsplit(NN$NAME.2[!is.chr],":")
        NN$SYMB.2[is.chr] <- ""
        NN$STRAND.2[is.chr] <- "."
        NN$NAME.2[!is.chr] <- sapply(nsplit, '[', 1)
        NN$SYMB.2[!is.chr] <- sapply(nsplit, '[', 2)
    }
    
    if (as.list) NN <- mat.split(NN, NN$NAME.1)
    NN
}


apa.names$general <- c(apa.names$general, "merge.coords")
merge.coords <- function(obj, type="generic", strand=FALSE) {
	
	## Takes a dataframe or matrix of coordinates (start, end) and merges overlaps.
	## "type"s = row types: "generic" = c(start, end, [else]); "genomic" = c(chr, start, end, strand, [else]).
	## "strand": it type="genomic" and strand=TRUE, rows are separated by strand prior to merging.  No cross-strand merges.
	## return object is a length-2 list:
	##   [[1]]: the merged coordinate set.
	##   [[2]]: a list (matched to rows of [[1]]) containing original rows that got merged.
	
	if (!is.data.frame(obj) & ! is.matrix(obj)) { stop("Object must be a matrix or dataframe!\n") }
	if (ncol(obj) < 2) { stop("Object must contain at least 2 cols!\n") }
	if (ncol(obj) < 4 & type == "genomic") { stop("Object must contain at least 4 cols for type 'genomic'!\n") }
	
	flatten <- function(coords, annots) {
		sets <- vector("list", length=nrow(coords))
		sizes <- rep(0, nrow(coords))
		merged <- matrix(data=0, nrow=nrow(coords), ncol=2)
		prev.i <- prev.j <- NA
		size <- 0
		for (i in 1:nrow(coords)) {
			if (is.na(prev.i)) {		# no pending merging
				j <- which(annots[,1] == coords[i,1] & annots[,2] == coords[i,2])
				sets[[i]] <- annots[j,]
				if (i < nrow(coords)) {
					if (coords[i,2] >= coords[(i+1),1]-1) {	# downstream overlap
						prev.i <- i
						prev.j <- j
						size <- size + 1
						boundaries <- coords[i,]
						clear <- FALSE
					} else {
						clear <- TRUE
					}
				} else {
					clear <- TRUE
				}
				if (clear) { 				# no downstream overlap
					merged[i,] <- coords[i,] 
					sizes[i] <- length(j)
				}
			} else {			# rows pending merging
				j <- which(annots[,1] == coords[i,1] & annots[,2] == coords[i,2])
				if (sum(j != prev.j) == 0) {	# for rows with identical coordinates -- different handling...
					uniq <- FALSE
				} else {
					sets[[prev.i]] <- rbind(sets[[prev.i]], annots[j,])
					uniq <- TRUE
				}
				boundaries <- c(boundaries, coords[i,])
				sb <- sort(unlist(boundaries))
				boundaries <- sb[c(1,length(sb))]
				if (i < nrow(coords)) {
					if (boundaries[2] >= coords[(i+1),1]-1) {	# downstream overlap
						# DO NOT RESET prev.i
						prev.j <- j
						if (uniq) { size <- size + length(j) }	# not if this row is a duplicate!
						clear <- FALSE
					} else {
						clear <- TRUE
					}
				} else {
					clear <- TRUE
				}
				if (clear) {					# no downstream overlap
					merged[prev.i,] <- boundaries[c(1,length(boundaries))]
					sizes[prev.i] <- size
					prev.i <- prev.j <- NA
					size <- 0
					boundaries <- c()
				}
			}
		}
		
		drop <- which(rowSums(merged) == 0)
		length(drop)
		merged <- merged[-drop,]
		sets <- sets[-drop]
		sizes <- sizes[-drop]
		return(list(coords=merged, annots=sets, sizes=sizes))
	}
	
	if (type == "generic") {
		
		inputs <- as.matrix(obj[,1:2])
		ternary (ncol(obj) > 2, annots <- obj, annots <- NA)
		output <- flatten(inputs, annots)
		
	} else if (type == "genomic") {
		
		chrs <- unique(obj[,1])
		if (strand) { 
			strs <- unique(obj[,4]) 
			flat <- vector("list", length=length(chrs)*length(strs))
		} else {
			flat <- vector("list", length=length(chrs))
		}
		
		idx <- 0
		for (i in 1:length(chrs)) {
			x <- which(obj[,1] == chrs[i])
			if (strand) {
				for (j in 1:length(strs)) {
					idx <- idx + 1
					y <- which(ojb[x,4] == strs[j])
					inputs <- as.matrix(obj[y,2:3])
					ternary (ncol(obj) > 4, annots <- obj[y,], annots <- NA)
					flat[[idx]] <- flatten(inputs, annots)
				}
			} else {
				idx <- idx + 1
				inputs <- as.matrix(obj[x,2:3])
				ternary (ncol(obj) > 4, annots <- obj[x,], annots <- NA)
				flat[[idx]] <- flatten(inputs, annots)
			}
		}
		
		flat2 <- invert.list(flat)
		coords <- do.call(rbind, flat2$coords)
		for (i in 1:length(flat2$annots)) { flat2$annots[[i]] <- flat2$annots[[i]][[1]] }	# squeeze list
		
		return(list(coords=coords, merge.sets=sets))
		
	} else {
		stop("'type' must be either 'generic' or 'genomic'!\n") 
	}
}


apa.names$bio.seq <- c(apa.names$bio.seq, "annot2bed")
annot2bed <- function(annot, set=c("gene","transcript","exon"), name=c("id","name","id:name"), biotypes=NULL) {
    
    ## Takes annotation data ('annot', i.e. output from read.annotations() above) and converts it to bed
    ## Expects the original column ordering of the data set indicated by 'set'
    ## 'Biotypes', if not NULL, selects only models with that value(s) of SimpleBiotype (can be a vector of multiple values).
    ## 
    ## RIGHT NOW DESIGNED FOR GENES ONLY.  NOT READY FOR TRANSCRIPTS OR EXONS.
    ## FUTURE: filter on Biotype or SimpleBiotype; also for trans/exon select gene/trans biotype, etc.
    
    set <- match.arg(set)
    name <- match.arg(name)
    if (set=="gene") {
        col4 <- ifelse(name=="name",2,1)
        bed <- annot[,c(3:5,col4,9,6)]  # Chr, Start, End, col4, Transcripts, Strand
        bed[,5] <- 1  # "Transcripts" was just to get a numeric column // now reset to 1
        if (name=="id:name") bed[,4] <- paste0(bed[,4],":",annot[,2])  # now GeneID:Symbol
        if (length(biotypes)>0) bed <- bed[annot$SimpleBiotype %in% biotypes,]
    } else {
        stop("Only working for set 'gene' right now!\n")
    }
    nameless(bed)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "nn.gene.position")
nn.gene.position <- function(nn, bins=10) {
    
    ## Takes output from nearest.neighbors() call and calculates:
    ##  for each hit gene, which bin (given 'bins') does peak midpoint fall into.
    ##  bin orientation is reversed for (-) strand genes.
    ## Returns: columns 1:6 (peak bed) + column for hit bin #
    
    nnh <- nn[nn$Distance==0 & !is.na(nn$START.2),]
    hitbins <- rep(0,nrow(nnh))
    for (i in 1:nrow(nnh)) {
        pmid <- mean(unlist(nnh[i,2:3]))  # peak midpoint
        width <- round((nnh$END.2[i]-nnh$START.2[i])/bins,0)  # bin size
        breaks <- round(seq(nnh$START.2[i],nnh$END.2[i],length=bins+1),0)  # breakpoints
        mids <- breaks[1:bins]+trunc(width/2)  # midpoints
        hit <- nearest(pmid, mids, index=TRUE)
        hitbins[i] <- ifelse(nnh$STRAND.2[i]=="-", bins-hit+1, hit)  # reverse if strand is "-"
    }
    cbind(nnh,Bin=hitbins)
}


