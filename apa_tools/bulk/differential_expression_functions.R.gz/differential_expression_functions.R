

apa.names$general <- c(apa.names$general, "anyfc")
anyfc <- function(vec, func=max) {
	
	## Returns the max fold-change between any 2 points fom a vector in log2
	## Or can return min, mean, etc. depending on 'fun'.
	
	n <- length(vec)
	m <- outer(vec, vec, "-")
	func(m, na.rm=TRUE)
}


apa.names$general <- c(apa.names$general, "RPM.norm")
RPM.norm <- function(mat, minimum=0, M=1E6, rescale=FALSE, totals=NULL) {
	
	## Reads-per-million normalizes a matrix of raw read counts, where rows are genes (e.g.) and columns are lanes (e.g.)
	## "subzero" if not null, replaces zeroes with specified value, for example 0.5 (half the smallest positive integer)
	##  - "subzero = NA" will convert zeroes to NAs.
	## "totals" is an optional vector specifying true read totals per lane; otherwise, colSums(mat) is used.
	
	nonlistvector <- ifelse(is.vector(totals) & !is.list(totals), TRUE, FALSE)
	if (!is.matrix(mat)) { stop("Object must be a matrix!  If vector, recast using as.matrix()\n") }
	if (length(minimum) > 1) { stop("'minimum' must be singular!\n") }
	if (!is.null(totals) & !nonlistvector) { stop("If specified, 'totals' must be a vector!\n") }
	if (nonlistvector & (length(totals) != ncol(mat))) { stop("'totals' must be a vector with length = ncol(mat)!\n") }
	
	if (!is.null(minimum)) {
		mat[is.na(mat)] <- minimum
		mat[mat==0] <- minimum
	}
	if (is.null(totals)) { totals <- colSums(mat, na.rm=TRUE) }
	RPM <- t( t(M*mat) / totals)
	return(RPM)
}


apa.names$general <- c(apa.names$general, "row.norm")
row.norm <- function(mat, med=FALSE, divSD=FALSE, na.rm=FALSE) {
    
    ## Subtracts each row in a matrix by its row mean.
    ##  unless 'med=T', in which median is used, not mean.
    ## "na.rm" same as in other functions.
    ## "divSD=T" further divides rows by SD, converting to z-scores
    
    if (med) {
        x <- x - rowMedians(x, na.rm=na.rm)
    } else {
        x <- x - rowMeans(x, na.rm=na.rm)
    }
    if (divSD) x <- x / rowSDs(x, na.rm=na.rm)
    x
}


apa.names$hacks <- c(apa.names$hacks, "get.MA")
get.MA <- function(x, y=NULL, pseudo=0) {
    
    ## Converts two vectors (or 2-col matrix/df) to MA values
    ## 'pseudo' is an optional pseudocount to adjust values with prior to MA calculations
    
    if (ncol(x)==2) {
        if (length(y)>0) stop("Do not specify 'y' if 'x' has 2 columns.")
    } else if (length(y)>0) {
        if (length(x)==length(y)) {
            x <- cbind(x,y)
        } else {
            stop("'x' and 'y' are not the same length!")
        }
    }
    x <- x+pseudo
    data.frame(A=log2(sqrt(x[,1]*x[,2])),M=log2(x[,1]/x[,2]))
}


apa.names$general <- c(apa.names$general, "remap.matrix")
remap.matrix <- function(x, map, func=NULL, delim=NULL, ids=c("rownames","column1"), keep.old=FALSE, return.unmapped=FALSE) {
    
    ## similar to aggregate()
    ## returns a new matrix/df with IDs converted from one set to another, and rows expanded/collapsed accordingly
    ## 'x' is a matrix/df with rownames/column-1 which are IDs
    ## 'ids' indicates if rownames have the IDs, or column 1.
    ## 'map' is a 2-col matrix/df with ID mappings; col 1 corresponds to rownames(x) and col 2 is some other ID set.
    ## - it is assumed that 'map' has many-to-many relationships, but it doesn't have to
    ## 'func' is the aggregating function, if needed: mean, sum, etc.  Just like with aggregate().
    ## 'delim': if 'func' is paste(), then specify the delimiter.
    ## RETURNS A MATRIX: data.frames are converted to matrices, with all the attendant upcasting of datatypes, be forewarned.
    ## if not 'func', then new IDs will be in column 1 of the output -- not as rownames, since not guaranteed to be unique without an aggregating 'func'.
    
    
    ## #### FUTURE: able to return matrix including old ID column, with rows showing complete many->many mappings
    
    
    ## Prep 'x'
    ids <- match.arg(ids)
    if (ids=="rownames") {
        xids <- rownames(x)
    } else if (ids=="column1") {
        xids <- x[,1]
        x <- x[,2:ncol(x),drop=FALSE]
    }
    xnames <- colnames(x)
    x <- nameless(as.matrix(x))
    
    ## remove incomplete mappings
    incomplete <- apply(is.na(map)|map=="",1,any)
    if (sum(incomplete)>0) {
        map <- map[!incomplete,]
        message(paste(sum(incomplete),"incomplete ID pairs removed"))
    }
    ## remove unmapped rows
    unmapped <- !(xids %in% map[,1])
    unmapped.ids <- sort(unique(xids[unmapped]))
    if (sum(unmapped)>0) {
        x <- x[!unmapped,,drop=FALSE]
        xids <- xids[!unmapped]
        message(paste(sum(unmapped),"unmappable rows removed"))
    }
    ## remove IDs not in dataset
    irrelevant <- !(map[,1] %in% xids)
    if (sum(irrelevant)>0) {
        map <- map[!irrelevant,]
        message(paste(sum(irrelevant),"irrelevant ID pairs removed"))
    }
    nrx <- nrow(x)
    ncx <- ncol(x)
    
    if (is.null(func)) {
        
        ## no aggregation function; output is complete many:many mapping
        
        message("Remapping ",length(unique(xids))," ids / ",nrx," rows")
        map2 <- split(map[,2], map[,1])  # new IDs, split by old IDs
        mapx <- split(1:nrx, xids)   # 'x' row numbers, split by old IDs
        M <- length(map2)
        x2 <- lapply(1:M, function(i) {
            report.index(i,10000,M)
            m2i <- map2[[i]]
            ##xi <- cbind("",x[xids==map[i,1],,drop=FALSE])  # 40 SEC PER 1000
            xi <- cbind("",x[mapx[[map[i,1]]],,drop=FALSE])  # 24000 IN 15 SEC !!!!!
            xix <- do.call(rbind, lapply(1:length(m2i), function(j) xi ))
            xix[,1] <- rep(m2i,each=nrow(xi))
            xix
        })
        y <- unique(do.call(rbind,x2))
        cny <- "New.ID"
        if (keep.old) {
            y <- y[,c(1,1:ncol(y))]
            cny <- c(cny,"Old.ID")
            y[,2] <- rep(names(map1),times=listLengths(map2))
        }
        colnames(y) <- c(cny,xnames)
        if (ids=="rownames") {
            rownames(y) <- y[,1]
            y <- y[,2:ncol(y)]
        }
        
    } else {
        
        ## have aggregation function
        
        ## ID mappings
        ## 'mapx' = one row per input row; only one TRUE value per row, in the column of the output mapping type
        ## colnames: o=one, m=many, first=input IDs, second=output IDs
        mapx <- matrix(FALSE, nrow(map), 4, FALSE, list(c(),c("o2o","o2m","m2o","m2m")))
        mapx[!duplicated2(map[,1]) & !duplicated2(map[,2]),"o2o"] <- TRUE  # 1:1 mappings
        many2many.1 <- duplicated2(map[,1]) & duplicated2(map[,2])
        many2many <- map[,1] %in% map[many2many.1,1] | map[,2] %in% map[many2many.1,2]
        mapx[many2many,"m2m"] <- TRUE    # M:M mappings
        mapx[!many2many & duplicated2(map[,1]) & !duplicated2(map[,2]),"o2m"] <- TRUE   # 1:M mappings  # the 'one' must be present in multiple copies, corresponding to the 'many'
        mapx[!many2many & !duplicated2(map[,1]) & duplicated2(map[,2]),"m2o"] <- TRUE   # M:1 mappings  # ditto, in the other direction
        if (nrow(map)!=sum(colSums(mapx))) stop("Mappings do not add up!")  ###### FIXME: need to improve this message...
        
        ## output matrix
        newids <- sort(unique(map[,2]))
        y <- matrix(NA, length(newids), ncx, FALSE, list(newids,c()))
        
        ## 1:1 mappings
        if (sum(mapx[,"o2o"])>0) {
            y[match(map[mapx[,"o2o"],2],rownames(y)),] <- x[match(map[mapx[,"o2o"],1],xids),,drop=FALSE]   # copy over 1:1 rows
        }
        ## Many:1 mappings
        if (sum(mapx[,"m2o"])>0) {
            if (length(delim)>0) {
                m2o <- aggregate(x[match(map[mapx[,"m2o"],1],xids),,drop=FALSE], list(map[mapx[,"m2o"],2]), func, collapse=delim)  # aggregate M:1 rows
            } else {
                m2o <- aggregate(x[match(map[mapx[,"m2o"],1],xids),,drop=FALSE], list(map[mapx[,"m2o"],2]), func)  # aggregate M:1 rows
            }
            y[match(m2o[,1],rownames(y)),] <- as.matrix(m2o[,2:(ncx+1)])      # add aggregated M:1 rows
        }
        ## 1:Many mappings
        if (sum(mapx[,"o2m"])>0) {
            o2m <- map[which(mapx[,"o2m"])[order(map[mapx[,"o2m"],1])],]   # o2m mappings
            y[match(o2m[,2],rownames(y)),] <- x[match(o2m[,1],xids),,drop=FALSE]  # add multiple copies of 1:M rows
        }
        ## Many:Many mappings
        if (sum(mapx[,"m2m"])>0) {
            if (length(delim)>0) {
                m2m <- aggregate(x[match(map[mapx[,"m2m"],1],xids),,drop=FALSE], list(map[mapx[,"m2m"],2]), func, collapse=delim)  # aggregate M:M rows
            } else {
                m2m <- aggregate(x[match(map[mapx[,"m2m"],1],xids),,drop=FALSE], list(map[mapx[,"m2m"],2]), func)  # aggregate M:M rows
            }
            y[match(m2m[,1],rownames(y)),] <- as.matrix(m2m[,2:(ncx+1)])  # add aggregated M:M rows
        }
        
        colnames(y) <- xnames
        if (keep.old) {
            oldids <- sapply(newids, function(x) paste(sort(map[map[,2]==x,1],collapse=";")))
            y <- data.frame(Old.ID=oldids, y)
        }
        if (ids=="rownames") {
            rownames(y) <- newids
        } else if (ids=="column1") {
            y <- data.frame(New.ID=newids, y)  # this way, new IDs are in column 1 regardless if keep.old or not.
        }
        
    }
    
    message(paste(nrow(y),"rows remaining"))
    if (return.unmapped) {
        list(y, unmapped.ids)
    } else {
        y
    }
}


apa.names$clustering <- c(apa.names$clustering, "sample.specificity")
sample.specificity <- function(mat, pseudo=2^-11, step=0.05, distinct=0, expressed=1, negative=FALSE, norm.w=c("none","rpm","tmm"), norm.b=c("none","quantile")) {
    
    ## Trapnell et al's tissue-specificity score (designed for gene-expression datasets)
    ## Plus other tables for evaluating score cutoffs
    ## 'mat' MUST BE LINEAR SCALE
    ## 'step' is the increment for score testing -- tests score thresholds from 0-1 with step size 'step'
    ## 'distinct' is a stringency criterion: for given gene, best FP score must be >= 'distinct' greater than runner-up score (else ignored)
    ## 'negative' gives negative-specificity scores, basically which genes are uniquely DOWN in sample x, rather than UP.
    ## 'expressed' sets an genewise expression threshold, linear scale, post-normalization.  If any gene value >= 'expressed', gene is flagged as expressed.
    
    input <- deparse(substitute(mat))
    pseudo.n <- deparse(substitute(pseudo))
    norm.w <- match.arg(norm.w)
    norm.b <- match.arg(norm.b)
    
    require(limma)
    
    entropy <- function(x) -sum(x*zerofy(NAfy(log(x))))
    
    specificity.cole <- function(p1) {
        ## Cole Trapnell's TS Score, Cabili et al http://genesdev.cshlp.org/content/25/18/1915.long, pages 1924-1925
        theoretical <- diag(length(p1))
#        if (negative) theoretical <- 1-theoretical  # get 'negative' from parent namespace  ## DON'T INVERT HERE: ALL SCORES -> 0
        JS <- apply(theoretical, 1, function(p2) entropy((p1+p2)/2)-entropy(p1)/2 )  # (1) for every maximal expression profile; entropy(p2)==0 so ignore
        zapsmall(1-sqrt(JS))  # (3) + (4), zapped; skipping (5): not max score; reporting all scores
    }
    
    specificity.orig <- function(x) {
        ## Earlier code
        ## Appears be Cole Trapnell's TS Score, but considerably rewritten
        ## Appears to produce the same scores
        Hx <- -sum(x*log(x))/2
        Hxy <- apply(t(diag(length(x))+x)/2,1,function(z) -sum(z*log(z)) )
        1-sqrt(Hxy-Hx)
    }
    
    NC <- ncol(mat)
    if (length(colnames(mat))==0) colnames(mat) <- 1:NC
    cnames <- colnames(mat)
    
    if (norm.w == "rpm") {
        message("Applying RPM normalization")
        mat.n <- mean(colSums(mat)) * t( t(mat)/colSums(mat) )
    } else if (norm.w == "tmm") {
        message("Applying 10%-trimmed-mean RPM normalization")
        mat.n <- mean(colSums(mat)) * apply(mat, 2, function(x){ tr=quantile(x, c(0.05,0.95)); x/sum(x[x>=tr[1]&x<=tr[2]])  })
    } else if (norm.w == "none") {
        mat.n <- mat
    } else {
        stop(paste0("Unknown within-sample normalization method '",norm.w,"'!"))
    }
    if (norm.b == "quantile") {
        message("Applying quantile normalization")
        mat.n <- 2^normalizeBetweenArrays(NAfy(log2(mat.n)),method="quantile")
    } else if (norm.b == "none") {
        ## do nothing
    } else {
        stop(paste0("Unknown between-sample normalization method '",norm.b,"'!"))
    }
    mat.n[is.na(mat.n)] <- 0
    mat.n1 <- log2(mat.n+1+pseudo)  # +1 means no negatives in logscale; +1+pseudo ensures all > 0 in logscale
    
    if (negative) {
        ## invert the gene expression profile, preserving range
        mat.inv <- t(apply(mat.n, 1, function(x){ y=2*mean(x)-x; y+min(x)-min(y) }))
        mat.n1 <- log2(mat.inv+1+pseudo)
    }
    
    message("Calculating specificity scores")
    mat.pct <- mat.n1/rowSums(mat.n1)
    mat.spec <- t(apply(mat.pct,1,specificity.cole))
    mat.spec[is.na(mat.spec)] <- 0
    dimnames(mat.n) <- dimnames(mat.n1) <- dimnames(mat.spec) <- dimnames(mat)
    
    message("Annotating genes")
    gap <- apply(mat.spec, 1, function(x) abs(diff(rev(sort(x)))[1]) )
    is.distinct <- gap>=distinct
    is.expressed <- apply(mat.n>=expressed,1,any)
    fp.genes <- data.frame(
        Max.Sample=cnames[apply(mat.spec, 1, which.max)],
        Max.Score=rowMax(mat.spec),
        Next.Score=apply(mat.spec, 1, function(x) max(x[-which.max(x)]) ),
        Score.Gap=gap,
        Distinct=is.distinct,
        Median.Expr=rowMedians(mat.n),
        Max.Expr=rowMax(mat.n),
        Expressed=is.expressed,
        stringsAsFactors=FALSE
    )
    
    message("Analyzing scores")
    scores <- seq(0,1,step)  # range of scores from 0:1
    S <- length(scores)
    
    unq.table <- unq.table.d <- unq.table.e <- unq.table.de <- matrix(0, S, NC+1, FALSE, list(format(scores),0:NC))
    for (i in 1:S) {
        tab <- table(rowSums(mat.spec>=scores[i]))
        unq.table[i,] <- zerofy(tab[match(0:NC,as.numeric(names(tab)))])
    }
    
    sens.table <- sens.table.d <- sens.table.e <- sens.table.de <-
        spec.table <- spec.table.d <- spec.table.e <- spec.table.de <-
            matrix(0, S, NC, FALSE, list(format(scores),cnames))
    uniq.table <- uniq.table.d <- uniq.table.e <- uniq.table.de <- matrix(0, S, NC+1, FALSE, list(format(scores),0:NC))
    
    for (i in 1:S) {
        uas <- rowSums(mat.spec>=scores[i])
        is.mono <- uas==1
        is.above <- fp.genes$Max.Score>=scores[i]
        is.d <- is.above & is.distinct
        is.e <- is.above & is.expressed
        is.de <- is.above & is.distinct & is.expressed
        x <- table(uas)
        xd <- table(uas[is.d])
        xe <- table(uas[is.e])
        xde <- table(uas[is.de])
        uniq.table[i,] <- zerofy(x[match(0:NC,as.numeric(names(x)))])
        uniq.table.d[i,] <- zerofy(xd[match(0:NC,as.numeric(names(xd)))])
        uniq.table.e[i,] <- zerofy(xe[match(0:NC,as.numeric(names(xe)))])
        uniq.table.de[i,] <- zerofy(xde[match(0:NC,as.numeric(names(xde)))])
        y <- table(fp.genes$Max.Sample[is.above])
        yd <- table(fp.genes$Max.Sample[is.d])
        ye <- table(fp.genes$Max.Sample[is.e])
        yde <- table(fp.genes$Max.Sample[is.de])
        sens.table[i,] <- c(y[match(cnames,names(y))])
        sens.table.d[i,] <- c(yd[match(cnames,names(yd))])
        sens.table.e[i,] <- c(ye[match(cnames,names(ye))])
        sens.table.de[i,] <- c(yde[match(cnames,names(yde))])
        z <- table(fp.genes$Max.Sample[is.mono & is.above])
        zd <- table(fp.genes$Max.Sample[is.mono & is.d])
        ze <- table(fp.genes$Max.Sample[is.mono & is.e])
        zde <- table(fp.genes$Max.Sample[is.mono & is.de])
        spec.table[i,] <- c(z[match(cnames,names(z))])
        spec.table.d[i,] <- c(zd[match(cnames,names(zd))])
        spec.table.e[i,] <- c(ze[match(cnames,names(ze))])
        spec.table.de[i,] <- c(zde[match(cnames,names(zde))])
    }
    
    tables <- lapply(
        list(
            total=list(
                uniqueness=uniq.table,
                sensitivity=sens.table,
                specificity=spec.table
            ),
            distinct=list(
                uniqueness=uniq.table.d,
                sensitivity=sens.table.d,
                specificity=spec.table.d
            ),
            expressed=list(
                uniqueness=uniq.table.e,
                sensitivity=sens.table.e,
                specificity=spec.table.e
            ),
            distinct.expressed=list(
                uniqueness=uniq.table.de,
                sensitivity=sens.table.de,
                specificity=spec.table.de
            )
        ),
        function(x) lapply(x, function(y){ z=zerofy(y); cbind(z, Total=rowSums(z), CV=zerofy(rowCVs(z))) })
    )
    tot <- ncol(tables[[1]]$uniqueness)-1
    for (i in 1:length(tables)) tables[[i]]$uniqueness[,1] <- tables[[i]]$uniqueness[1,tot]-tables[[i]]$uniqueness[,tot]
    params <- list(input=input, pseudo=pseudo.n, step=step, distinct=distinct)
    return(list(genes=fp.genes, norm=mat.n, scores=mat.spec, tables=tables, params=params))
}


apa.names$general <- c(apa.names$general, "genewise.anova")
genewise.anova <- function(x, model, col.factors=NULL, row.factors=NULL) {
    
    ## Takes an matrix of values + sets of column or row factors (needs at least one) 
    ## Returns an anova-ready dataset + row-wise anova results on that dataset
    ## **** Row factors aren't yet ready to run ****
    ## 'model' is the linear model as a character string, e.g. "Value ~ time + drug + time*drug"
    ##  -- Predictand name MUST be 'Value' !!!!!!!!!!  Others must correspond to given factor names.
    ## 'col.factors' or 'gene.factors' is a list with names = factor names in 'model', and values are vectors of levels.
    
    ## factor consistency checks
    any.factors <- FALSE
    if (length(col.factors)>0) {
        col.names <- names(col.factors)
        if (is.matrix(col.factors)) {
            col.factors2 <- as.list(as.data.frame(col.factors))
        } else if (is.data.frame(col.factors)) {
            col.factors2 <- as.list(col.factors)
        } else if (is.ndfl(col.factors)) {
            if (luniq(listLengths(col.factors))==1) {  # all same length
                col.factors2 <- lapply(col.factors, as.character)  # defactorized, if factor
            }
        } else if (is.nlv(col.factors)) {
            col.factors2 <- list(as.character(col.factors))  # defactorized, if factor
        }
        if (length(col.factors2[[1]])==ncol(x)) {
            col.factors <- col.factors2  # pass back to original,
            for (i in 1:length(col.factors)) {
                if (!is.factor(col.factors[[i]])) col.factors[[i]] <- as.factor(col.factors[[i]])
            }
            names(col.factors) <- col.names
        }
        if (length(col.factors)>0) {
            any.factors <- TRUE
        } else {
            stop("col.factors specified, but were either of incorrect/inconsistent length, or were not a matrix, data.frame, list, or vector\n")
        }
    }
    if (length(row.factors)>0) {
        row.names <- names(row.factors)
        if (is.matrix(row.factors)) {
            row.factors2 <- as.list(as.data.frame(row.factors))
        } else if (is.data.frame(row.factors)) {
            row.factors2 <- as.list(row.factors)
        } else if (is.ndfl(row.factors)) {
            if (luniq(listLengths(row.factors))==1) {  # all same length
                row.factors2 <- lapply(row.factors, as.character)  # defactorized, if factor
            }
        } else if (is.nlv(row.factors)) {
            row.factors2 <- list(as.character(row.factors))  # defactorized, if factor
        }
        if (length(row.factors2[[1]])==nrow(x)) {
            row.factors <- row.factors2  # pass back to original
            names(row.factors) <- row.names
        }
        if (length(row.factors)>0) {
            any.factors <- TRUE
        } else {
            stop("row.factors specified, but were either of incorrect/inconsistent length, or were not a matrix, data.frame, list, or vector\n")
        }
    }
#    if (!any.factors) stop("No factors specified: Cannot proceed!\n")   # once row factors are operational
    if (length(col.factors)==0) stop("No factors specified: Cannot proceed!\n")
    
    if (length(rownames(x))==0) rownames(x) <- 1:nrow(x)
    tests <- unlist(strsplit(gsub(" ","",model),"[~+-]"))  # do not split interactions
    tests <- tests[2:length(tests)]  # drop predictand
    
    pre.aov <- as.data.frame(c(
        list(Gene=factor(rep(rownames(x), ncol(x)))),
        list(Value=c(as.matrix(x))),
        lapply(col.factors, function(f) factor(rep(f, each=nrow(x))) )
    ))
    
    anova.fun <- function(dat) {
        y <- pre.aov[which(pre.aov[,1]==dat),]
        z <- eval(parse(text=paste("anova(lm(",model,", data=y))")))
        return(z[[5]][1:length(tests)])
    }
    
    IM("ANOVA running...")
    st <- system.time( aov.raw <- aov.adj <- aov.adj2 <- as.matrix(t(sapply(rownames(x), anova.fun))) )
    sm <- st[[3]]/60
    sm <- ifelse(sm<0.5, 0, ceiling(sm))
    
    colnames(aov.raw) <- paste0(tests,".p.raw")
    colnames(aov.adj) <- paste0(tests,".p.BH")
    colnames(aov.adj2) <- paste0(tests,".p.Bonferroni")
    for (i in 1:ncol(aov.raw)) {
        aov.adj[,i] <- p.adjust(aov.raw[,i], method="BH")
        aov.adj2[,i] <- p.adjust(aov.raw[,i], method="bonferroni")
    }
    result <- do.call(cbind, lapply(1:length(tests), function(i) cbind(aov.raw[,i,drop=FALSE], aov.adj[,i,drop=FALSE], aov.adj2[,i,drop=FALSE]) ))
    rownames(result) <- rownames(x)
    
    message(paste("ANOVA complete:",sm,"minutes elapsed"))
    return(list(data=pre.aov, result=result))
}


apa.names$bio.seq <- c(apa.names$bio.seq, "build.expr.table")
build.expr.table <- function(files, content=c("htseq","star","cufflinks"), genes=NULL, dir.name=TRUE, min.FPKM=2^-10) {
    
    ## Builds a named matrix from a vector of input files, one column per file
    
    content <- match.arg(content)
    file.names <- sub(".*/","",files)  # no paths
    col.names <- files
    if (dir.name) col.names <- sub(".*/","",sub("/[^/]+$","",files))
    
    ## Read all files into list of matrices, one element per file
    dat <- switch(
        content,
        htseq={
            lapply(files, function(x) rownamed.matrix(read.delim(x, as.is=TRUE, header=FALSE)) )
        },
        star={
            lapply(files, function(x) rownamed.matrix(read.delim(x, as.is=TRUE, header=FALSE)) )
        },
        cufflinks={
            lapply(files, function(x) {
                y <- read.delim(x, as.is=TRUE, header=TRUE)
                ystat <- sapply(split(y[,13], y[,1]), function(x) ifelse(luniq(x)==1, x[1], paste(x,collapse=",")) )
                ynum <- rownamed.matrix(aggregate(y[,10:12], list(y[,1]), sum))
                data.frame(ynum, STATUS=ystat[match(rownames(ynum),names(ystat))])
            })
        }
    )
    
    all.rn <- do.call(cbind, lapply(dat,rownames))
    if (!cols.same(all.rn)) stop("Files were not quantitated in the same fashion; rownames are not same / not in same order across all files!\n")
    
    if (length(genes)>0) {
        ## Test is given 'genes' value appears to match quantitated genes
        rn.genes <- all.rn[,1]  # but, must deplete any non-gene values below
        rn.genes <- switch(
            content,
            htseq=    { rn.genes[!grepl("^_", rn.genes)] },
            star=     { rn.genes[!grepl("^N_",rn.genes)] },
            cufflinks={ rn.genes }
        )
        if (!(all(rn.genes %in% genes))) stop("Quantitated genes are not a subset of the specified gene list!")
    }
    
    match.to.genes <- function(x) {
        if (length(genes)>0) {
            genic <- rownames(x) %in% genes
            x.non <- x[!genic,,drop=FALSE]
            x.genic <- x[genic,,drop=FALSE]
            x.genic <- x.genic[match(genes,rownames(x.genic)),]
            rownames(x.genic) <- genes
            rbind(x.non,x.genic)
        } else {
            x  # if no gene list, just return input
        }
    }
    
    if (content=="htseq") {
        
        dat <- do.call(cbind, dat)
        dimnames(dat[[i]]) <- list(all.rn[,1], col.names)
        is.stat <- grepl("^_",rownames(dat))
        A <- grep("anti",files,TRUE)
        S <- setdiff(grep("sense",files,TRUE), A)  # because A could have "antisense" not just "anti"
        if (length(S) + length(A) == length(files)) {
            
            ## file set was fully divided into sense/antisense counts
            ## ensure that sense, antisense column sets have same sample order
            An <- sub("anti(sense)?","",files[A],TRUE)  # case-insensitive removal of "anti" / "antisense" string
            Sn <- sub("sense","",files[S],TRUE)         # case-insensitive removal of "sense" string
            if (all(Sn==An)) {
                ## ok; without sense/antisense components, all in same order
            } else {
                ## sense/antisense tagging affected sort order; sort anti to match sense
                Sord <- match(An,Sn)
                files[A] <- files[A[Sord]]
                col.names[A] <- col.names[A[Sord]]
                dat[,A] <- dat[,A[Sord]]
            }
            dat <- list(
                      unstranded=dat[!is.stat,S]+dat[!is.stat,A],
                           sense=dat[!is.stat,S],
                       antisense=dat[!is.stat,A],
                stats.unstranded=dat[ is.stat,S]+dat[ is.stat,A],
                     stats.sense=dat[ is.stat,S],
                 stats.antisense=dat[ is.stat,A]
            )
            for (i in 1:3) dat[[i]] <- match.to.genes(dat[[i]])
            
        } else {
            
            ## file set was fully undivided, or at least not fully divided
            dat <- list(
                counts=dat[!is.stat,],
                 stats=dat[ is.stat,]
            )
            dat$counts <- match.to.genes(dat$counts)
            
        }
        
    } else if (content=="star") {
        
        is.stat <- grepl("^N_",rownames(dat[[1]]))
        dat <- list(
                  unstranded=do.call(cbind, lapply(dat,"[",,1))[!is.stat,],
                       sense=do.call(cbind, lapply(dat,"[",,2))[!is.stat,],
                   antisense=do.call(cbind, lapply(dat,"[",,3))[!is.stat,],
            stats.unstranded=do.call(cbind, lapply(dat,"[",,1))[ is.stat,],
                 stats.sense=do.call(cbind, lapply(dat,"[",,2))[ is.stat,],
             stats.antisense=do.call(cbind, lapply(dat,"[",,3))[ is.stat,]
        )
        for (i in 1:3) {
            dimnames(dat[[i]]) <- list(all.rn[!is.stat,1], col.names)
            dat[[i]] <- match.to.genes(dat[[i]])
        }
        for (i in 4:6) dimnames(dat[[i]]) <- list(all.rn[is.stat,1], col.names)
        
    } else if (content=="cufflinks") {
        
        ## could also test for stranded Cufflinks runs here, e.g. grepping W/C, plus/minus, etc.  Not doing so at the moment.
        dat <- list(
                    FPKM=as.matrix(do.call(cbind, lapply(dat,"[",,1))),
            FPKM.conf.lo=as.matrix(do.call(cbind, lapply(dat,"[",,2))),
            FPKM.conf.hi=as.matrix(do.call(cbind, lapply(dat,"[",,3))),
             FPKM.status=as.matrix(do.call(cbind, lapply(dat,"[",,4)))
        )
        for (i in 1:4) dimnames(dat[[i]]) <- list(all.rn[,1], col.names)
        if (min.FPKM>0) for (i in 1:ncol(dat$FPKM)) dat$FPKM[dat$FPKM[,i]<min.FPKM,i] <- 0  # zap too-small values
        dat$FPKM <- match.to.genes(dat$FPKM)  # pad rows to match expected gene set; Cufflinks almost always loses some genes
        
    }
    
    dat
}
