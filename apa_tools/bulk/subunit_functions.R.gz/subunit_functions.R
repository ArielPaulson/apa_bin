

apa.names$dev <- c(apa.names$dev, "generic.subunit")
generic.subunit <- function(tmp) {
    
    ## IN DEVELOPMENT, may or may not work as desired.
    ## runs multiple R scripts in parallel.
    ## 'tmp' is a list with two elements:
    ##
    ##
    ##
    ##
    ##
    ##
    ##
    ## RESERVED NAMES: { tmp, result, my.i, pids, prefixes, outputs, master.prefix, pid.files, in.files, out.files, R.files, Rout.files }
    
    ## Objects
    N <- length(tmp)
    pids <- rep(NA,N)
    prefixes <- rep(NA,N)
    outputs <- vector("list", length=N)
    names(outputs) <- names(tmp)
    
    ## Files
    master.prefix <- paste(c("generic.subunit.tmp",Sys.getpid(),abs(now.seed())),collapse="-")
    prefixes <- paste0(master.prefix,"-",1:N,".")
    pid.files <- paste0(prefixes,"pid")
    in.files <- paste0(prefixes,"input")
    out.files <- paste0(prefixes,"output")
    R.files <- paste0(prefixes,"R")
    Rout.files <- paste0(prefixes,"Rout")
    
    ## Compose and execute individual clustering jobs
    for (my.i in 1:length(tmp)) {
        
        ## Write data to temp file
        for (name in names(tmp[[my.i]]$data)) assign(name, tmp[[my.i]]$data[[name]])
        save(list=names(tmp[[my.i]]$data), file=in.files[my.i])   # save objects from tmp[[my.i]]$data
        
        ## Create R script
        sink(R.files[my.i])
        cat(paste(c(
            ## Write subunit PID to known location
            paste0("sink(\"",pid.files[my.i],"\")"),
            "cat(Sys.getpid())",
            "sink()",
            ## Load data
            paste0("load(\"",in.files[my.i],"\")"),
            ## Run commands
            tmp[[my.i]]$commands,
            ## Write output object to temp file
            paste0("save(result, file=\"",out.files[my.i],"\")")
        ), collapse="\n"))
        sink()
        
        ## Execute R script in background
        system(paste("R --vanilla <",R.files[my.i],">",Rout.files[my.i],"&"))
    }
    
    ## Get PIDs
    Sys.sleep(5)  # pause to ensure last process has written PID file
    N <- length(tmp)  # reset N, since it might have been overwritten in object assignments above
    for (i in 1:N) pids[i] <- scan(pid.files[i],quiet=TRUE)
    
    ## Babysit; check every minute
    M <- N
    message(paste("PIDs:",paste(sort(pids),collapse=",")))
    message(paste("Babysitting",M,"processes:",Sys.time()))
    wait <- TRUE
    
    while (wait) {
        Sys.sleep(60)
        pid.ps <- lapply(pids, function(x) suppressWarnings(system(paste("ps -p",x), intern=TRUE)) )
        pid.running <- sapply(pid.ps, function(x) length(x)==2 )
        nr <- sum(pid.running)
        if (nr>0 & nr<M) message(paste("Babysitting",nr,"processes:",Sys.time()))  # count down as processes drop off
        M <- nr
        wait <- M>0
    }
    
    ## Read in results
    message(paste("All processes complete:",Sys.time()))
    for (i in 1:N) {
        if (file.exists(out.files[i])) {
            load(out.files[i])  # MUST CONTAIN ONLY ONE OBJECT, NAMED 'result' !!!
            outputs[[i]] <- result
        } else {
            warning(paste0("Call #",key," failed to produce the expected output file!\n"))
        }
    }
    
    ## Clean up
    system(paste0("rm -f ",master.prefix,"*"))
    
    ## Return results
    outputs
}


apa.names$dev <- c(apa.names$dev, "cluster.subunit")
cluster.subunit <- function(data, verbose=FALSE) {
    
    ## This is the first of three variants.  It executes ALL given jobs in parallel.
    ## 'data' must be a list of jobs, all at first level, one element per job.
    
    ## runs multiple 1-core clustering jobs in parallel.
    ## 'data' is a list of data to be clustered.
    ## output object will be a list of outputs, one for each element of 'data'.
    ## 
    ## each element of 'data' must be a list with AT LEAST two elements, 'matrix' and 'command':
    ##  1. data[[i]]$matrix: a numeric matrix to be clustered
    ##  2. data[[i]]$command: a string which, when executed in R -- via eval(parse(text="cmd")) -- will cluster data[[i]]$matrix.
    ##    A. data[[i]]$command must refer to data[[i]]$matrix as 'x', e.g. data[[i]]$command="hclust(dist(x),\"average\")"
    ##    B. data[[i]]$command must not contain single-quotes.
    ##  3. data[[i]]$libraries is an optional vector of R COMMANDS to run before clustering, i.e. to load libraries or source scripts.
    ##  4. other elements of data[[i]] may be included, if the clustering command requires additional data objects.
    ##    A. be sure to name the elements the same way they are called in the command:
    ##       for instance, if data[[i]]$command="hclust(dist(x,method=\"minkowski\",p=power))", then make sure data[[i]]$power exists.
    ##    B. no element may be named 'x'; this is reserved for the matrix being clustered.
    
    ## Objects
    N <- length(data)
    pids <- rep(NA,N)
    prefixes <- rep(NA,N)
    outputs <- vector("list", length=N)
    names(outputs) <- names(data)
    
    ## Files
    master.prefix <- paste(c("cluster.subunit.tmp",Sys.getpid(),abs(now.seed())),collapse="-")
    prefixes <- paste0(master.prefix,"-",1:N,".")
    pid.files <- paste0(prefixes,"pid")
    in.files <- paste0(prefixes,"input")
    out.files <- paste0(prefixes,"output")
    
    ## It is assumed that 'command' double-quotes are already escaped.
    ## This escapes the escapes so that 'command' can itself be inside a command.
    ## Escaping escapes is not possible in R (poorly handled regular expressions), so this just re-escapes the quotes.
    escapeq <- function(x) gsub("\"","\\\\\"",x)  
    
    ## Compose and execute individual clustering jobs
    for (i in 1:N) {
        
        ## Write matrix to temp file
        xnames <- setdiff(names(data[[i]]), c("matrix","command","libraries"))  # look for extra objects
        libs <- data[[i]]$libraries  # may not exist
        if ("x" %in% xnames) stop(paste0("No element of data[[",i,"]] may be named 'x'!\n"))
        for (n in xnames) assign(n, data[[i]][[n]])  # unpack objects by name
        x <- data[[i]]$matrix
        save(list=c("x",xnames), file=in.files[i])   # save 'x' and any extra objects from data[[i]]
        
        block <- paste(c(
            ## Write subunit PID to known location
            paste0("sink(\"",pid.files[i],"\")"),
            "cat(Sys.getpid())",
            "sink()",
            ## Load libraries / source scripts, if any
            libs,
            ## Load data
            paste0("load(\"",in.files[i],"\")"),
            ## Cluster matrix
            paste0("result <- eval(parse(text=\"",escapeq(data[[i]]$command),"\"))"),
            ## Write output object to temp file
            paste0("save(result, file=\"",out.files[i],"\")")
        ), collapse="; ")
        
        ## Execute code block in background
        if (verbose) {
            system(paste0("R --vanilla -e '",block,"' &"))
        } else {
            system(paste0("R --vanilla -e '",block,"' >/dev/null &"))
        }
    }
    
    ## Get PIDs
    Sys.sleep(5)  # pause to ensure last process has written PID file
    for (i in 1:N) {
        pids[i] <- scan(pid.files[i],quiet=TRUE)
        if (verbose) message(paste("Process",i,"PID",pids[i]))
    }
    
    ## Babysit; check every minute
    M <- N
    if (!verbose) message(paste("PIDs:",paste(sort(pids),collapse=",")))  # if verbose, already saw pids above.  If not, show condensed PID list here.
    message(paste("Babysitting",M,"processes:",Sys.time()))
    wait <- TRUE
    
    while (wait) {
        Sys.sleep(60)
        pid.ps <- lapply(pids, function(x) suppressWarnings(system(paste("ps -p",x), intern=TRUE)) )
        pid.running <- sapply(pid.ps, function(x) length(x)==2 )
        nr <- sum(pid.running)
        if (nr>0 & nr<M) message(paste("Babysitting",nr,"processes:",Sys.time()))  # count down as processes drop off
        M <- nr
        wait <- M>0
    }
    
    ## Read in results
    message(paste("All processes complete:",Sys.time()))
    for (i in 1:N) {
        if (file.exists(out.files[i])) {
            load(out.files[i])  # MUST CONTAIN ONLY ONE OBJECT, NAMED 'result' !!!
            outputs[[i]] <- result
        } else {
            warning(paste0("Call #",key," failed to produce the expected output file!\n"))
        }
    }
    
    ## Clean up
    system(paste0("rm -f ",master.prefix,"*"))
    
    ## Return results
    outputs
}


apa.names$dev <- c(apa.names$dev, "cluster.subunit2")
cluster.subunit2 <- function(data, verbose=FALSE) {
    
    ## This is the second of three variants.  It executes jobs in serial batches, and all jobs within a batch are run in parallel.
    ## 'data' must be a list of batches, all at first level, one element per batch.
    ##  each batch element 'data[[i]]' must be a list of jobs for that batch, all at second level, one element per job.
    
    ## runs multiple 1-core clustering jobs in parallel.
    ## 'data' is a list of data to be clustered.
    ## output object will be a list of outputs, one for each element of 'data'.
    ## 
    ## each element of 'data' must be a list with AT LEAST two elements, 'matrix' and 'command':
    ##  1. data[[i]]$matrix: a numeric matrix to be clustered
    ##  2. data[[i]]$command: a string which, when executed in R -- via eval(parse(text="cmd")) -- will cluster data[[i]]$matrix.
    ##    A. data[[i]]$command must refer to data[[i]]$matrix as 'x', e.g. data[[i]]$command="hclust(dist(x),\"average\")"
    ##    B. data[[i]]$command must not contain single-quotes.
    ##  3. data[[i]]$libraries is an optional vector of R COMMANDS to run before clustering, i.e. to load libraries or source scripts.
    ##  4. other elements of data[[i]] may be included, if the clustering command requires additional data objects.
    ##    A. be sure to name the elements the same way they are called in the command:
    ##       for instance, if data[[i]]$command="hclust(dist(x,method=\"minkowski\",p=power))", then make sure data[[i]]$power exists.
    ##    B. no element may be named 'x'; this is reserved for the matrix being clustered.
    
    ## It is assumed that 'command' double-quotes are already escaped.
    ## This escapes the escapes so that 'command' can itself be inside a command.
    ## Escaping escapes is not possible in R (poorly handled regular expressions), so this just re-escapes the quotes.
    escapeq <- function(x) gsub("\"","\\\\\"",x)  
    
    ## Objects
    B <- length(data)  ## BATCHES OF JOBS
    outputs <- vector("list", length=B)
    names(outputs) <- names(data)
    master.prefix <- paste(c("cluster.subunit.tmp",Sys.getpid(),abs(now.seed())),collapse="-")
    
    ## Run each batch separately
    for (b in 1:B) {
        
        N <- length(data[[b]])  # JOBS WITHIN BATCH
        pids <- rep(NA,N)
        prefixes <- rep(NA,N)
        outputs[[b]] <- vector("list", length=N)
        names(outputs[[b]]) <- names(data[[b]])
        
        ## Files
        prefixes <- paste0(master.prefix,"-B",b,"-",1:N,".")
        pid.files <- paste0(prefixes,"pid")
        in.files <- paste0(prefixes,"input")
        out.files <- paste0(prefixes,"output")
        
        ## Compose and execute individual clustering jobs within batch
        ## All jobs from batch b must complete before moving on to batch b+1
        for (i in 1:N) {
            
            ## Write matrix to temp file
            xnames <- setdiff(names(data[[b]][[i]]), c("matrix","command","libraries"))  # look for extra objects
            rm(list=xnames)  # remove last batch's objects, just for safety
            libs <- data[[b]][[i]]$libraries  # may not exist
            if ("x" %in% xnames) stop(paste0("No element of data[[",i,"]] may be named 'x'!\n"))
            for (n in xnames) assign(n, data[[b]][[i]][[n]])  # unpack objects by name
            x <- data[[b]][[i]]$matrix
            save(list=c("x",xnames), file=in.files[i])   # save 'x' and any extra objects from data[[b]][[i]]
            
            block <- paste(c(
                ## Write subunit PID to known location
                paste0("sink(\"",pid.files[i],"\")"),
                "cat(Sys.getpid())",
                "sink()",
                ## Load libraries / source scripts, if any
                libs,
                ## Load data
                paste0("load(\"",in.files[i],"\")"),
                ## Cluster matrix
                paste0("result <- eval(parse(text=\"",escapeq(data[[b]][[i]]$command),"\"))"),
                ## Write output object to temp file
                paste0("save(result, file=\"",out.files[i],"\")")
            ), collapse="; ")
            
            ## Execute code block in background
            if (verbose) {
                system(paste0("R --vanilla -e '",block,"' &"))
            } else {
                system(paste0("R --vanilla -e '",block,"' >/dev/null &"))
            }
        }
        
        ## Get PIDs
        Sys.sleep(5)  # pause to ensure last process has written PID file
        for (i in 1:N) {
            pids[i] <- scan(pid.files[i],quiet=TRUE)
            if (verbose) message(paste("Process",i,"PID",pids[i]))
        }
        
        ## Babysit; check every minute
        M <- N
        if (!verbose) message(paste("PIDs:",paste(sort(pids),collapse=",")))  # if verbose, already saw pids above.  If not, show condensed PID list here.
        message(paste("Babysitting",M,"processes:",Sys.time()))
        wait <- TRUE
        
        while (wait) {
            Sys.sleep(60)
            pid.ps <- lapply(pids, function(x) suppressWarnings(system(paste("ps -p",x), intern=TRUE)) )
            pid.running <- sapply(pid.ps, function(x) length(x)==2 )
            nr <- sum(pid.running)
            if (nr>0 & nr<M) message(paste("Babysitting",nr,"processes:",Sys.time()))  # count down as processes drop off
            M <- nr
            wait <- M>0
        }
        
        ## Read in results
        message(paste("All processes complete:",Sys.time()))
        for (i in 1:N) {
            if (file.exists(out.files[i])) {
                load(out.files[i])  # MUST CONTAIN ONLY ONE OBJECT, NAMED 'result' !!!
                outputs[[b]][[i]] <- result
            } else {
                warning(paste0("Call #",key," failed to produce the expected output file!\n"))
            }
        }
    }
    
    ## Clean up
    system(paste0("rm -f ",master.prefix,"*"))
    
    ## Return results
    outputs
}


apa.names$dev <- c(apa.names$dev, "cluster.subunit3")
cluster.subunit3 <- function(data, verbose=FALSE) {
    
    ## This will be the third of three variants.  It executes jobs in rolling parallel, with no more than B running at a time.
    ## Like the first variant, 'data' must be a list of jobs, all at first level, one element per job.
    
}
