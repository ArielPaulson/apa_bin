

apa.names$graphics <- c(apa.names$graphics, "show.styles")
show.styles <- function() {
    
    ## Plots pch, font, lty, lwd styles

    par(mar=c(1,1,2,1))
    null.plot(xlim=c(0.6,5), ylim=c(0,26))
    points(rep(1.1,26), 0:25, pch=25:0, col=1)
    text(rep(1.1,26), 25:0, labels=0:25, pos=2)
    rect(0.82, -0.5, 1.18, 4.5, col=NA, border=1)
    text(0.63, 2, labels="Have\n'bg'")
    
    text(rep(2.5,6), seq(16,24,2)+1, labels=paste("Font",5:1), font=5:1)
    
    segments(rep(2,6), seq(1,11,2), rep(3,6), seq(1,11,2), lty=6:1)
    text(rep(2,6), seq(1,11,2), labels=6:1, pos=2)

    lwds <- c(11:1,0.5,0.1)
    segments(rep(4,6), seq(1,25,2), rep(5,6), seq(1,25,2), lty=1, lwd=lwds)
    text(rep(4,6), seq(1,25,2), labels=lwds, pos=2)
    text(4, -0.25, "...", font=2, pos=2)
    
    text(c(1.1,2.5,2.5,4.5), c(26.5,26.5,13,26.5), labels=paste(c("PCH","FONT","LTY","LWD"),"STYLES"), font=2)
}


apa.names$graphics <- c(apa.names$graphics, "null.plot")
null.plot <- function(main="", xlab="", ylab="", ...) {
    
    ## Plots a completely blank plot (spacer plot to use in multi-plot images)
    ## Use '...' to pass in other parameters to "plot", if desired
    ## Can include a title, if it is useful to mark a grid position for unplottable data
    ## Also use "x" and "y" if dimensions matter, e.g. blank plot as backdrop for preformatted text with x/y coords, etc.
    
    plot(x=c(0,1), y=c(0,1), col=0, axes=FALSE, main=main, xlab=xlab, ylab=ylab, ...)
}


apa.names$graphics <- c(apa.names$graphics, "masked.map")
masked.map <- function(map, data, type, alpha.max=0.85, base.col="grey50") {
    
    ## "type = sets" means 'data' is a list of length=k, each element being a vector of row indexes.
    ## "type = map" means 'data' is a vector of cluster membership numbers with length = nrow(map).
    
    if (type == "map") {
        unq <- unique(data)
        clusters <- vector("list", length=length(unq))
        for (i in 1:length(unq)) { clusters[[i]] <- which(data == unq[i]) }
    } else if (type == "sets") {
        clusters <- data
    } else {
        stop("Unknown data type!  Must be one of 'map' or 'sets'.\n")
    }
    rowmap <- unlist(clusters)
    newmap <- map[rowmap,rowmap]
    mask <- matrix(data=0, nrow=nrow(newmap), ncol=ncol(newmap))
    for (clust in clusters) {
        for (i in 1:length(clust)) {
            for (j in 1:length(clust)) {
                mask[clust[i],clust[j]] <- 1	
            }
        }
    }
    mask <- mask[rowmap,rowmap]
    mask.ramp <- mask.palette(base.col=base.col, alpha.max=alpha.max)
    myImagePlotUltra(newmap, mask=mask, mask.ramp=mask.ramp)
}


apa.names$plots <- c(apa.names$plots, "tree.cuts")
tree.cuts <- function(map, yrange, horiz=FALSE, lty=1, lwd=1) {
    
    ## 'map' is an integer grouping vector for clusters on a dendrogram, e.g. cutree() output.  Any NA entries will be ignored.
    ##  - could also use kmeans() output, but this is often discontiguous on a dendrogram.
    ##  - EITHER WAY, MAP MUST BE IN DENDROGRAM ORDER!!!!
    ## 'yrange' is the y range bounding where the rectangle or bar is drawn.  Look at the y-axis of the dendrogram and decide.
    ##  - if cutree() was used, it is most best to set yrange=c(0,h) where 'h' was the height of the cut (if known).
    ## set 'horiz' = TRUE if you used "horiz=T" in your plot call.
    ## 'lty', 'lwd' as usual.
    ## !!! Assumes dendrogram has already been plotted in an active device.  This adds the rect() calls to that plot.
    
    cu <- real(unique(map))
    cl <- new.list(cu)
    N <- length(cu)
    contig <- rep(TRUE, length(cu))
    cols <- rainbow(N+1)[1:N]
    for (i in 1:N) {
        cl[[i]] <- which(map==cu[i])
        if (!all(diff(cl[[i]])==1)) contig[i] <- FALSE
    }
    if (all(contig)) {   # all clusters contiguous -- plot rectangles
        for (i in 1:N) {
            rect(min(cl[[i]]), yrange[1], max(cl[[i]]), yrange[2], col=NA, bord=cols[i], lty=lty, lwd=lwd)
        }
    } else {   # some clusters discontiguous -- plot color bar
        for (i in 1:N) {
            for (j in 1:length(cl[[i]])) segments(cl[[i]][j], yrange[1], cl[[i]][j], yrange[2], col=cols[i], lty=lty, lwd=lwd)
        }
    }
}


apa.names$plots <- c(apa.names$plots, "pairs.basic")
pairs.basic <- function(obj, col=1, pch=1, ab.col=2, cex.pch=1, cex.text=1) {
	N <- ncol(obj)
	par(mfrow=c(N,N), mar=c(1,1,1,1), oma=c(3,3,3,3), las=1, xaxt="n", yaxt="n")
	for (i in 1:N) { for (j in 1:N) {
		if (i == j) {
			null.plot(frame.plot=TRUE)
			text(0.5, 0.5, colnames(obj)[i], cex=cex.text)
		} else {
			plot(obj[,j], obj[,i], col=col, pch=pch, cex=cex.pch)
			abline(0,1,col=ab.col)
		}
	} }
}

apa.names$plots <- c(apa.names$plots, "plot.fc.lines")
plot.fc.lines <- function(folds, slope=1, reg.vecs=NULL, stdev=NULL, color.bands=NULL, col=1, lty=1, lwd=1, col.diag=col, lty.diag=lty, lwd.diag=lwd, col.reg=col, lty.reg=lty, lwd.reg=lwd) {
    
    ## Plots fold-change lines on a diagonal scatterplot.
    ## "folds" is a vector of fold-change positions to plot.  MAKE SURE THIS IS IN THE PROPER SCALE FOR THE PLOT...
    ## "slope" allows changing of the slope of the diagonal (and therefore fold-change lines) if for some reason it is not 1.
    ## "reg.vecs=list(x,y)" plots a regression line for the x/y scatter.
    ## "stdev", if non-null, uses this stdev value to plot standard deviation lines, not fold-change lines
    ## "color.bands" controls the replacement of lines with bands of point colors.  If specified it must be a list of 1-2 elements:
    ##   [[1]] must be a 2-col matrix with points plotted (REQUIRED), [[2]] must be a vector of colors for the bands (OPTIONAL).
    ## col, lty, lwd are the normal parameters.
    ## col.diag, lty.diag, lwd.diag are versions for the diagonal ONLY.  Only apply if the diagonal itself is in 'folds'.
    ## col.reg, lty.reg, lwd.reg are versions for the regression line ONLY.  Only apply if 'reg.vecs' is non-null.
    
    ## # color.bands NOT READY TO GO YET
    
    theta <- thetacon(slope, "slope", "radians")	# from apa_functions.R
    fac <- ifelse (is.null(stdev), 1, stdev)
    scale <- fac / cos(theta)
    if (is.nan(scale)) scale <- 1
    ##IM(theta, scale)
    
    if (is.null(color.bands)) {
        for (i in 1:length(folds)) { 
            if (folds[i] == 0) {
                abline(folds[i]*scale, slope, col=col.diag, lty=lty.diag, lwd=lwd.diag) 
            } else {
                abline(folds[i]*scale, slope, col=col, lty=lty, lwd=lwd) 
            }
        }
    } else {
        x <- color.bands[[1]][,1]
        y <- color.bands[[1]][,2]
        if (length(color.bands)==2) {
            band.cols <- color.bands[[2]]
        } else {
            band.cols <- c(1,4,3,2,5,6,7)	# supports differential coloring up to 6 bands
        }
        band.max <- length(band.cols)
        band.sets <- fc.sets(x, y, max(fc.lines), slope)
        band.pcts <- rep(0, length(band.sets))
        for (f in 1:length(band.sets)) { 
            points(x[band.sets[[f]]], y[band.sets[[f]]], pch=pch, col=band.cols[f]) 
            band.pcts[f] <- round(100 * length(band.sets[[f]]) / length(ok), 1)
        }
        fcl.col <- 8
      	legend(x="bottomright", bty="n", text.col=band.cols, legend=paste(band.pcts,"%",sep=""))
    }
    if (!is.null(reg.vecs)) { 
        linm <- lm(reg.vecs[[2]] ~ reg.vecs[[1]])
        abline(linm[[1]][1], linm[[1]][2], col=col.reg, lty=lty.reg, lwd=lwd.reg) 
        invisible(linm) 
    }
}


apa.names$plots <- c(apa.names$plots, "plot.contours")
plot.contours <- function(x, k=10, cols=NULL, n=100, ltys=1, lwds=1) {
    ## adds contour lines to an existing plot
    ## 'x' is a 2-col matrix with col 1 = x, col 2 = y coords
    require(MASS)
    z <- kde2d(x[,1], x[,2], n=n)
    if (length(cols)==0) cols <- rainbow(k+1)[1:k]
    if (length(ltys)==1) ltys <- rep(ltys,k)
    if (length(lwds)==1) lwds <- rep(lwds,k)
    levs <- seq(min(z$z),max(z$z),length.out=k+1)[1:k]
    levs <- levs+diff(levs)[1]/2
    contour(z, drawlabels=FALSE, levels=levs, col=rev(cols), lty=ltys, lwd=lwds, add=TRUE)
    invisible(z)
}


apa.names$plots <- c(apa.names$plots, "butterfly.plot")
butterfly.plot <- function(x, border=1, ...) {
	
	## Butterflied boxplots; i.e. + and - fold-change sets get boxplotted separately in the same column.  Zeroes are assigned to positive side.
	## 'x' is an object to be boxplotted
	## 'border' is a vector of length 1 or 2 indicating color(s) for + and - boxplots, respectively.  Try 'border=c(2,4)'.  Overrides any 'border' value in '...'.
	## '...' are all other args passed to graphics::boxplot()
	
	pos.args <- neg.args <- list(...)
	
	if (is.list(x)) {  # or data.frame
		pos <- lapply(x, function(n){n[n>=0]})
		neg <- lapply(x, function(n){n[n<0]})
	} else if (is.nlv(x)) {
		pos <- x[x>=0]
		neg <- x[x<0]
	} else if (is.matrix(x)) {
		pos <- apply(x, 2, function(n){n[n>=0]})
		neg <- apply(x, 2, function(n){n[n<0]})
	} else {
		stop("'x' must be a list, data.frame, matrix, or numeric vector!\n")
	}
	
	if (length(border)==1) border[2] <- border[1]
	
	pos.args$x <- pos
	pos.args$border <- border[1]
	neg.args$x <- neg
	neg.args$border <- border[2]
	neg.args$add=TRUE
	neg.args$names=NA
	neg.args$axes=F
	
	do.call(boxplot, pos.args)
	do.call(boxplot, neg.args)
	invisible(list(pos=pos,neg=neg))
}


apa.names$plots <- c(apa.names$plots, "half.butterfly.plot")
half.butterfly.plot <- function(obj, shared=FALSE, cols=c("firebrick3","dodgerblue3","white"), dirlabels=c("Up Terms","Down Terms"), scorelabel="-Log10(p)", main=NULL, xseq=NULL, cex=1, pmar=c(2,2)) {
    
    ## 'obj' is a 2-3 column ROWNAMED matrix:
    ##  - col 1 = score; rownames are descriptors for the score (see description below)
    ##  - col 2 = 1|-1 (which side of plot they go to)
    ##  - optional col 3 = N units contributing to score
    ## initially designed for displaying selected GO terms from mut/wt comparisons:
    ##  - col 1 is -log10(p-value) for GO terms for mut/wt sig-DE genes (row names are the GO terms themselves)
    ##  - col 2 is sign of fold-change for mut/wt gene set (i.e. upreg, downreg) to which GO term pertains
    ##  - col 3 is N genes contributing to sig GO term call
    ## MA data is also an obvious candidate, which would not use column 3
    
    x <- obj
    scores <- x[,1]
    scores[x[,2]<0] <- -1 * scores[x[,2]<0]
    x <- x[order(scores),]
    scores <- scores[order(scores)]
    scores2 <- c(NA,scores,NA)
    cols2 <- c(NA, rep(cols[2],sum(scores<0)), rep(cols[1],sum(scores>0)), NA)
    space <- 0.35  # barplot 'space' arg
    
    segx <- round(range(scores),0)  # initially, anyway
    bar.xlim <- c( min(min(scores),segx[1]), max(max(scores),segx[2]) )
    chars.per.unit <- 26/(10.2*cex)  # scaled to units of default X11 window size, family="mono"
    units.per.row <- t(sapply(1:nrow(x), function(i){ tx=x[i,2] * nchar(rownames(x)[i])/chars.per.unit + x[i,1]; c(scores[i],nchar(rownames(x)[i]),tx,scores[i]+tx) }))
	names(units.per.row) <- NULL
    text.range <- range(units.per.row[,4])
    dimnames(units.per.row) <- list(rownames(x),c("Score","Nchar","Text","Sum"))
#    return(units.per.row)
    
    par(mar=c(2,pmar[1],2,pmar[2]), family="mono", cex=cex)
    
    if (shared) {
		
		## plot +, - bars with same title on same line
		
        unames <- sort(unique(rownames(x)))
        u <- matrix(NA, length(unames), 4, F, list(unames,c("Score.Dn","N.Dn","Score.Up","N.Up")))
        for (i in 1:nrow(u)) {
            w.d <- rownames(x)==unames[i] & x[,2]==-1
            w.u <- rownames(x)==unames[i] & x[,2]==1
            if (any(w.d)) u[i,1:2] <- x[w.d,c(1,3)]
            if (any(w.u)) u[i,3:4] <- x[w.u,c(1,3)]
        }
        
        o1 <- which(!is.na(u[,1]) & is.na(u[,3]))
        o2 <- which(!is.na(u[,1]) & !is.na(u[,3]))
        o3 <- which(is.na(u[,1]) & !is.na(u[,3]))
#        uord <- c( o1[rev(order(u[o1,1]))], o2[rev(order(rowSums(u[o2,c(1,3)])))], o3[rev(order(u[o3,3]))] )  # order shared by sum score
        uord <- c( o1[rev(order(u[o1,1]))], o2[rev(order(u[o2,1]))], o3[rev(order(u[o3,3]))] )  # order shared by down score
#        uord <- c( o1[rev(order(u[o1,1]))], o2[rev(order(u[o2,3]))], o3[rev(order(u[o3,3]))] )  # order shared by up score
        u <- u[rev(uord),]
        u[,1] <- -1*u[,1]

        b <- (1:nrow(u))-0.5+(1:nrow(u))*space
        barplot(u[,1], col=cols[2], border=cols[2], space=space, beside=TRUE, horiz=TRUE, axes=FALSE, xlab="", ylab="", names=NA, xlim=text.range, ylim=c(-2,max(b)+0.5), main=main)
        barplot(u[,3], col=cols[1], border=cols[1], space=space, beside=TRUE, horiz=TRUE, axes=FALSE, xlab="", ylab="", names=NA, add=TRUE)
        segments(0,0, 0,max(b)+0.5)
        
        w.dn <- which(!is.na(u[,1]))
        w.up <- which(is.na(u[,1]))
        for (i in w.dn) {
            text(u[i,1]-0.5, b[i], pos=2, labels=rownames(u)[i])
            text(-0.65, b[i], labels=u[i,2], col=cols[3], font=2)
            if (!is.na(u[i,3])) text(0.65, b[i], labels=u[i,4], col=cols[3], font=2)
        }
        for (i in w.up) {
            text(u[i,3]+0.5, b[i], pos=4, labels=rownames(u)[i])
            text(0.65, b[i], labels=u[i,4], col=cols[3], font=2)
        }
        
        gap <- 0.5+space
        last.pos <- which(is.na(u[,1]))[1]
        segy <- 0
        if (length(xseq)>0) {
            scale <- xseq
            nticks <- length(xseq)
            segx <- range(scale)
        } else {
            nticks <- 7
            scale <- trunc(seq(segx[1],segx[2],length=nticks))
        }
        tick.ht <- gap*space
        
        text(0, b[length(b)]+gap*1.5, pos=2, labels=dirlabels[2], col=cols[2])
        text(0, b[length(b)]+gap*1.5, pos=4, labels=dirlabels[1], col=cols[1])
        text(0, segy-tick.ht*5, pos=1, labels=scorelabel)
        
        segments(segx[1],segy, segx[2],segy)
        for (i in 1:nticks) {
            segments(scale[i],segy, scale[i],segy-tick.ht)
            text(scale[i], segy-tick.ht*3, labels=abs(scale[i]))
        }
        
    } else {
		
		## plot +, - bars with same title on separate lines
        
        b <- barplot(scores2, col=cols2, border=cols2, space=space, xlim=text.range, beside=TRUE, horiz=TRUE, axes=FALSE, xlab="", ylab="", names=NA, main=main)
        for (i in 1:length(scores)) text(scores2[i+1], b[i+1], pos=ifelse(scores2[i+1]<0,2,4), labels=rownames(x)[i])
        
        gap <- diff(b)[1]
        last.pos <- match(1,x[,2])
        segy <- b[last.pos]+gap*0.5
        if (length(xseq)>0) {
            scale <- xseq
            nticks <- length(xseq)
            segx <- range(scale)
        } else {
            nticks <- 7
            scale <- trunc(seq(segx[1],segx[2],length=nticks))
#            scale <- c(-7,-5,-3,-1,0,1,3)  # hardcoded for Paternal KEGG
        }
#        message(segx); message(paste(seq(segx[1],segx[2],length=nticks))); message(scale)
        tick.ht <- gap*space
        
        text(0, b[1]-tick.ht/2, pos=2, labels=dirlabels[2], col=cols[2])
        text(0, b[length(b)]+tick.ht/2, pos=4, labels=dirlabels[1], col=cols[1])
        text(mean(scale[scale<=0]), segy+tick.ht*4, pos=3, labels=scorelabel)
        text(mean(scale[scale>=0]), segy-tick.ht*4, pos=1, labels=scorelabel)
        
        for (i in 1:length(scores)) text(sign(scores[i])*0.75, b[i+1], labels=x[i,3], col=cols[3], font=2)
        
        segments(segx[1],segy, segx[2],segy)
        for (i in 1:nticks) {
            if (scale[i] < 0) {
                segments(scale[i],segy, scale[i],segy+tick.ht)
                text(scale[i], segy+tick.ht*2, labels=-scale[i])
            } else {
                if (scale[i]==0) next
                segments(scale[i],segy, scale[i],segy-tick.ht)
                text(scale[i], segy-tick.ht*2, labels=scale[i])
            }
        }
        
    }
}


apa.names$plots <- c(apa.names$plots, "boxplot.outlier.bounds")
boxplot.outlier.bounds <- function(bp, range=NULL, plot=FALSE, pch="-", col=2, cex=2) {
    
    ## Plots and/or returns a matrix of outlier boundaries for a boxplot object.
    ## Returnable is a matrix with row format of:
    ##   col 1 = number of unit boxplot (since there are usually > 1 elements being boxplotted).
    ##   col 2 = -1 or 1 (-1 = low threshold, 1 = high threshold).
    ##   col 3 = value for that threshold
    ## "bp" is a boxplot object with one or more unit boxplots.
    ## "range" is the 'range' value from the original boxplot call, IF not default.
    ## "plot" switch causes the results to appear as dash-marks on an existing boxplot.
    ## "col" specifies color for the dashes in the plot, if "plot=T".
    
    if (is.null(range)) { 
        co <- capture.output(args(boxplot.default))
        re <- regexpr("range = [0-9.]+",co)
        range <- as.numeric(unlist(strsplit(regmatches(co,re)," "))[3])
    }
    cutoffs <- matrix(data=0, nrow=2*length(bp$n), ncol=3)
    for (i in 1:length(bp$n)) { 
        j <- (i-1)*2+1; k <- j+1
        cutoffs[j,1] <- i; cutoffs[k,1] <- i
        cutoffs[j,2] <- -1; cutoffs[k,2] <- 1
        IQR <- bp$stats[4,i] - bp$stats[2,i]
        cutoffs[j,3] <- bp$stats[2,i] - IQR*range
        cutoffs[k,3] <- bp$stats[4,i] + IQR*range
    }
    if (plot == TRUE) { points(cutoffs[,c(1,3)], pch=pch, col=col, cex=cex) }
    invisible(cutoffs)
}


apa.names$plots <- c(apa.names$plots, "stretch.attrib")
stretch.attrib <- function(x, N, label) {
    ## where 'x' is an attribute vector (probably of length 1), N is the length it should be, and 'label' is for the error message
    L <- length(x)
    if (L==1) {
        rep(x, N)
    } else if (L==N) {
        x
    } else if (N %% L == 0) {
        rep(x, N/L)
    } else {
        IM(paste("Warning:",label,"attribute length",L,"is not a multiple of",N))
        rep(x, ceiling(N/L))[1:N]
    }
}


apa.names$plots <- c(apa.names$plots, "error.bars")
error.bars <- function(x, y, width, method=c("sd","sem","iqr","range"), horizontal=FALSE, cross=NULL, col=1, lty=1, lwd=1) {
    
    ## Plots errors bars on existing plot
    ## Designed for barplots, but can be adapted to others
    ## Give 'x' pos for bars and 'y' height for bars
    ## 'width' is a vector, matrix, or list:
    ##  - Vector: indicates error-bar half-length; for each x, each error bar = 2 half-lengths extending from the corresponding y position.
    ##  - Matrix: nrow=2, ncol=length(x); row 1 gives max y value and row 2 = min y value. 
    ##  - List: list of length x, elements = vectors of data points at each position along x; MUST SPECIFY 'method' as error bars will be calculated on the fly.
    ## if 'horizontal=TRUE', 'x' and 'y' get transposed on the plot, and bars go horizontal instead of the default vertical.
    ## 'cross' gives the width of the cross-piece (at top and bottom of error bars) in pixels.  NULL = auto-calculate based on range of 'x'.
    ## col, lty, lwd as usual
    
    method <- match.arg(method)
    N <- length(x)
    if (length(y) != N) stop("'x' and 'y' must be same length!\n")
    if (is.matrix(width)) {  # y max, y min
        if (nrow(width)==2 & ncol(width)==length(x)) {
            width2 <- width
            method <- "range"
        } else {
            stop("'width' must be a vector or list of same length as x, or a 2-row matrix with ncol=length(x)\n")
        }
    } else if (is.nlv(width) & length(width)==length(x)) {  # abs distance from bar terminus
        width2 <- width
    } else if (is.ndfl(width) & length(width)==N) {
        width2 <- switch(method,
                         "sd"=sapply(width, sd),
                         "sem"=sapply(width, SEM),
                         "iqr"=sapply(width, function(w){ diff(quantile(w,c(0.25,0.75))) }),
                         "range"=t(sapply(width, range))   # RETURNS 2-COLUMN MATRIX
                         )
    } else {
        stop("'width' must be a vector or list of same length as x, or a 2-row matrix with ncol=length(x)\n")
    }
    if (length(cross)==0) cross <- diff(range(x))/100
    
    attribs <- list(col=col,lty=lty,lwd=lwd)
    for (i in 1:length(attribs)) attribs[[i]] <- stretch.attrib(attribs[[i]], N, names(attribs)[i])
    
    pos.mat <- matrix(NA, N, 12, F, list(1:N,qw(e.x1,e.y1,e.x2,e.y2, t.x1,t.y1,t.x2,t.y2, b.x1,b.y1,b.x2,b.y2)))
    ybot <- ternary(method=="range", width2[1,], y-width2)
    ytop <- ternary(method=="range", width2[2,], y+width2)
    pos.mat[,ternary(horizontal, c(2,4), c(1,3))] <- cbind(x,x)                # x pos, error bar (initial, final)
    pos.mat[,ternary(horizontal, c(1,3), c(2,4))] <- cbind(ybot,ytop)          # y pos, error bar
    pos.mat[,ternary(horizontal, c(6,8), c(5,7))] <- cbind(x-cross,x+cross)    # x pos, top crossbar
    pos.mat[,ternary(horizontal, c(5,7), c(6,8))] <- cbind(ytop,ytop)          # y pos, top crossbar
    pos.mat[,ternary(horizontal, c(10,12), c(9,11))] <- cbind(x-cross,x+cross) # x pos, bottom crossbar
    pos.mat[,ternary(horizontal, c(9,11), c(10,12))] <- cbind(ybot,ybot)       # y pos, bottom crossbar
    
    for (i in 1:N) {
        segments(pos.mat[i,1], pos.mat[i,2], pos.mat[i,3], pos.mat[i,4], col=attribs$col[i], lty=attribs$lty[i], lwd=attribs$lwd[i])      # error bar
        segments(pos.mat[i,5], pos.mat[i,6], pos.mat[i,7], pos.mat[i,8], col=attribs$col[i], lty=attribs$lty[i], lwd=attribs$lwd[i])      # bottom crossbar
        segments(pos.mat[i,9], pos.mat[i,10], pos.mat[i,11], pos.mat[i,12], col=attribs$col[i], lty=attribs$lty[i], lwd=attribs$lwd[i])   # top crossbar
    }
    
    invisible(pos.mat)
}


apa.names$plots <- c(apa.names$plots, "ellipsify")
ellipsify <- function(x, nsd=2, pts=100, col=1, lty=1, lwd=1, rslope=NULL, hull=FALSE, debug=FALSE) {

    ## Plots a mean+Nsd ellipse around a specified set of scatterplot points (plot must already be active)
    ## 'x' = 2-col matrix of x,y coords
    ## 'nsd' = n stdevs for ellipse axes
    ## 'pts' = n points for ellipse circumference
    ## 'col', 'lty', 'lwd' as usual
    ## 'rslope', if specified, forces the slope of the initial regression line
    ## 'hull' draws the convex hull instead of an ellipse
    
    ## PROBLEM: like many conical section plots, ellipses have erroneous rotation when x range != y range
    
    ## diagonal for plot area
#    xlim <- c()  # specify later
#    ylim <- c()
#    xyr <- rbind(x=xlim,y=ylim)
#    m <- quot(rev(apply(xyr,1,diff)))
#    b <- xyr[2,2]-m*xyr[1,2]
    
    if (hull) {
        
        conv.hull <- chull(x)
        for (v in 1:length(conv.hull)) {
            i <- conv.hull[v]
            j <- ifelse(v==length(conv.hull),conv.hull[1],conv.hull[v+1])
            segments(x[i,1],x[i,2], x[j,1],x[j,2], col=col, lty=lty, lwd=lwd)
        }
        
    } else {
        
        ## original centroid
        cent.x <- colMeans(x)
        if (debug) points(cent.x[1], cent.x[2], pch=3, col=col, cex=1.5)
        
        ## original regression line
        model.0 <- lm(x[,2] ~ x[,1])
        b.0 <- model.0$coef[[1]]
        m.0 <- model.0$coef[[2]]
        if (length(rslope)>0) {
            m.0 <- rslope  # with the current intercept, this new slope will not intersect the centroid
            y.gap <- cent.x[2]-(m.0*cent.x[1]+b.0)  # (true centroid y) - (y value of centroid x, using new slope)
            b.0 <- b.0+y.gap
        }
        if (debug) {
            abline(b.0, m.0, col=col)
            IM("Model:",b.0, m.0)
        }
        
        ## center data points at origin
        y <- cbind(x[,1]-cent.x[1], x[,2]-cent.x[2])
        
        ## shifted centroid
        cent.y <- colMeans(y)
        
        ## long axis = regression line
#        model.1 <- lm(y[,2] ~ y[,1])
#        b.1 <- model.1$coef[[1]]
#        m.1 <- model.1$coef[[2]]
        b.1 <- 0    # should be essentially 0
        m.1 <- m.0  # should not change
        
        ## short axis = perp to reg line, intersects centroid
        m.2 <- -1/m.1
        b.2 <- cent.y[2]-m.2*cent.y[1]
        
        ## theta for centroid->x, via long axis
        theta.1 <- atan(m.1)
        
        ## clockwise rotation matrix for long axis -> x
        rot.1 <- matrix(c(cos(-theta.1),sin(-theta.1),-sin(-theta.1),cos(-theta.1)), ncol=2)
#        for (i in 1:2) IM(rot.1)
        
        ## counterclockwise rotation matrix for long axis -> x
        rot.1.rev <- matrix(c(cos(theta.1),sin(theta.1),-sin(theta.1),cos(theta.1)), ncol=2)
#        for (i in 1:2) IM(rot.1.rev)
        
        ## long-axis-rotated points
        y.1r <- t(rot.1 %*% t(y))
        
        ## long-axis m+sd values for rotated points
        cm.1r <- colMeans(y.1r)
        sd.x <- nsd*sd(y.1r[,1])
        sd.y <- nsd*sd(y.1r[,2])
        msd.1r <- matrix(c(-sd.x,sd.x,cm.1r[2],cm.1r[2],cm.1r[1],cm.1r[1],-sd.y,sd.y), ncol=2)
        
        ## construct unrotated ellipse matrices
        el.x <- seq(msd.1r[1,1], msd.1r[2,1], length=pts)
        r1 <- diff(msd.1r[1:2,1])/2
        r2 <- diff(msd.1r[3:4,2])/2
        ternary(r1>r2, {a<-r1;b<-r2}, {a<-r2;b<-r1})
        el.top <- el.bot <- cbind(el.x, sqrt(1-(el.x/r1)^2)*r2)
        el.bot[,2] <- -el.top[,2]
        
        ## rotate + shift ellipse
        el.top.r <- t(rot.1.rev %*% t(el.top))
        el.bot.r <- t(rot.1.rev %*% t(el.bot))
        msd.1 <- t(rot.1.rev %*% t(msd.1r))
        for (i in 1:2) {
            el.top.r[,i] <- el.top.r[,i] + cent.x[i]
            el.bot.r[,i] <- el.bot.r[,i] + cent.x[i]
            msd.1[,i] <- msd.1[,i] + cent.x[i]
        }
        lines(el.top.r, col=col, lty=lty, lwd=lwd)
        lines(el.bot.r, col=col, lty=lty, lwd=lwd)
    }
}


apa.names$plots <- c(apa.names$plots, "smoothScatter2")
smoothScatter2 <- function(x, y = NULL, nbin = 256, bandwidth = NULL, colramp = palettizer("terrain.plus"), 
			nrpoints = 100, fhat.scale = NULL, pch = ".", cex = 1, col = "black", transformation = function(x) x^0.25, 
			postPlotHook = box, xlab = NULL, ylab = NULL, xlim, ylim, xaxs = par("xaxs"), yaxs = par("yaxs"), verbose=FALSE, ...) {
	
	## This is a slightly-streamlined copy of smoothScatter from R 2.10.1, with six hacks:
	##  1. The background color now extends the full range of xlim, ylim.
	##  2. x, y range + bandwidth calculations are not screwed up if x = 2-col matrix / y = null.
	##  3. xlim, ylim do not break bandwidth, since it is now calculated up-front.
	##  4. Bandwidth is now scaled to x and y ranges; no more oblong spots!  
	##     Also, single-bandwidths are scaled for both axes, and auto-bandwidths will not be too small.
	##     And, for reference, the effective bandwidths are reported to screen! (if not user-specified)
	##  5. "palettizer" palette selection is available, e.g. 'colramp="terrain.plus"'.
	##  6. fhat.scale alters density-to-color mappings by specifying a different fhat distribution than produced by grDevices:::.smoothScatterCalcDensity
	##	   Value should be the fhat object returned from a different smoothScatter2 call, e.g. "fhat.scale=smoothScatter2(...)$fhat"
	##	   THIS IS CURRENTLY NOT AVAILABLE -- under construction
	
	if (!is.numeric(nrpoints) | (nrpoints < 0) | (length(nrpoints) != 1)) { stop("'nrpoints' should be numeric scalar with value >= 0.") }
	if (length(y)==0) { 
		if (nrow(x)==0) {
			invisible(c())  # complicated way to skip execution without stopping (which breaks loops) or blowing up return value (which damages lists)
			return()
		}
	}
	
	###### HACK 1 + REARRANGED CODE ######
	
	## Hack 1 plots correct background extent when using custom xlim, ylim values 
	
	if (is.matrix(x)) {
		xlabel <- deparse(substitute(x))
		if (is.null(y)) {	
			if (ncol(x) == 2) {	# assumes col 1 = x, col 2 = y
				y <- x[,2]
				x <- x[,1]
				ylabel <- paste(xlabel, "[,2]", sep="")		################## FIX THIS
			} else {		# single- or multicolumn matrix?  treat as vector...
				x <- as.vector(x)
				ylabel <- paste(xlabel, "[,1]", sep="")		################## FIX THIS
			}
		} else if (length(x) == length(y)) {
			x <- as.vector(x)
			y <- as.vector(y)
			ylabel <- deparse(substitute(y))
		} else {
			stop ("x and y are of unequal length!\n")
		}
	} else {
		if (!missing(x)) xlabel <- deparse(substitute(x))
		if (!missing(y)) ylabel <- deparse(substitute(y))
	}
	
	xy <- xy.coords(x, y, xlabel, ylabel)
	xlab <- ifelse (is.null(xlab), xy$xlab, xlab)
	ylab <- ifelse (is.null(ylab), xy$ylab, ylab)
	x <- cbind(xy$x, xy$y)[is.finite(xy$x) & is.finite(xy$y), , drop = FALSE]
	if (!missing(xlim)) {
		stopifnot(is.numeric(xlim), length(xlim) == 2, is.finite(xlim))
		x <- x[min(xlim) <= x[, 1] & x[, 1] <= max(xlim), ]
	} else {
		xlim <- range(x[, 1])
	}
	if (!missing(ylim)) {
		stopifnot(is.numeric(ylim), length(ylim) == 2, is.finite(ylim))
		x <- x[min(ylim) <= x[, 2] & x[, 2] <= max(ylim), ]
	} else {
		ylim <- range(x[, 2])
	}
	
	###### END HACK 1 + REARRANGED CODE ######
	
	###### HACK 2 ######
	
	## Hack 2 enables:
	##  Independent bandwidths for x & y axes; by default will scale y to x so that density spots are always circular.
	##  Range-based color application; can assign color range in plot B based on color-to-density mapping from plot A.
	
	MN <- 85   # 'magic number' used for bandwidth scaling; smoothScatter default is 25
	bandwidth.def <- diff(apply(x,2,quantile,probs=c(0.05,0.95))) / 25   #### ORIGINAL METHOD
	bandwidth.def[bandwidth.def==0] <- 1   #### ORIGINAL METHOD
	xyrange <- signif(c(xlim[2]-xlim[1], ylim[2]-ylim[1]), 4)
	if (length(bandwidth)==0) {
		bandwidth2 <- c(MN,MN)
	} else if (length(bandwidth)==1) {
		bandwidth2 <- c(bandwidth,bandwidth)
	} else {
		# manually-specified x,y bandwidths
		bandwidth2 <- bandwidth[1:2]
	}
	bandwidth <- signif(xyrange / bandwidth2, 4)
#	bandwidth <- bandwidth2
	bandwidth[bandwidth == 0] <- 1
	
	eb1r <- signif(bandwidth[1],3)
	eb2r <- signif(bandwidth[2],3)
	xdiv <- round(xyrange[1]/bandwidth[1],1)
	ydiv <- round(xyrange[2]/bandwidth[2],1)
	divfc <- round(log2(xdiv/ydiv),4)
	
	XN <- 10  # 'magic number' used for range expansion of density map; KernSmooth::bkde2D default is 1.5
	xexp <- XN*bandwidth[1]
	yexp <- XN*bandwidth[2]
	xlim2 <- c(xlim[1]-xexp, xlim[2]+xexp)  # range extension method lifted from KernSmooth::bkde2D
	ylim2 <- c(ylim[1]-yexp, ylim[2]+yexp)
	
	if (verbose) {
		message(paste(c("Band2:",bandwidth2),collapse=" "))
		message(paste(c("BandW:",bandwidth),collapse=" "))
		message(paste(c("BandD:",bandwidth.def),collapse=" "))
		message(paste(c("xlim:",xlim),collapse=" "))
		message(paste(c("xlim2:",xlim2),collapse=" "))
		message(paste(c("x,y exps:",xexp,yexp),collapse=" "))
		message(paste(c("ylim:",ylim),collapse=" "))
		message(paste(c("ylim2:",ylim2),collapse=" "))
		message(paste(c("xy range:",xyrange[1],"/",xyrange[2]),collapse=" "))
		message("Effective bandwidth: x=", eb1r , " (", xdiv, "), y=", eb2r, " (", ydiv, ") : ", divfc)
	}
#	map <- grDevices:::.smoothScatterCalcDensity(x, nbin, bandwidth)			#### ORIGINAL
	map <- grDevices:::.smoothScatterCalcDensity(x=x, nbin=nbin, bandwidth=bandwidth, range.x=list(xlim2,ylim2))
	map$fhat <- transformation(map$fhat)
	# values <- head(sort(unique(c(map$fhat))))
	# steps <- diff(values)
	# if (steps[1]<steps[2]/10) {
		# ## density rounding error or something, essentially producing "zeroes with nonzero values"
		# IM("zeroing",sum(map$fhat==values[2]),"values")
		# map$fhat[map$fhat==values[2]] <- 0  # restore to zero
	# }
# #	map$fhat <- map$fhat/sum(map$fhat)   # useful for the time when 'fhat.scale' is a operating argument
	
	## 1. Incoming 'colramp' may or may not be a function
	color.bins <- 256
	if (is(colramp, "function")) {		# colramp is a colorRampPalette() function
		colramp2 <- colramp
	} else  {		# colramp is not a colorRampPalette() function
		colramp2 <- palettizer(colramp, n.colors=NA)	# convert palette name to ramp function
		if (!exists("colramp2")) colramp2 <- palettizer("terrain.plus", n.colors=NA)	# palette not found; default to my usual palette for this function
	}
	## 2. 'colramp2' is now a colorRamp function
	cols <- colramp2(color.bins)
	
	## On the operation of 'fhat.scale':
	## A wide variety of approaches have been attempted and all have failed.
	## Multiple issues with comparing fhats must be resolved for it to work:
	## 1. Some fhats have extreme, usually invisible, low-end noise problems which distort the value->color mappings.
	## 2. The number of unique data values varies, which impacts value->color mapping.
	## 3. fhats are not scaled; sums vary widely.
	## 4. It is clear that singletons are not color-mapped equivalently, investigation shows the data is not ratio.
	## 5. Further, the difference between singleton maxima is not the same as between global maxima, so not a linear scaling problem.
	## 6. Given #4-5 it appears that differences in fhat maxima are meaningful, but cannot be properly scaled?
	## 7. Even if #6 is resolved, fhats must be properly denoised/scaled/quantized to create comparable distributions of value->color mappings.
	
	## mixture of various attempts below:
	# if (length(fhat.scale)>0) {
		# fhat.unq1 <- luniq(c(map$fhat))
		# fhat.unq2 <- luniq(c(fhat.scale))
		# fhat.range1 <- c(min(map$fhat[map$fhat>0]), max(map$fhat))
		# fhat.range2 <- c(min(fhat.scale[fhat.scale>0]), max(fhat.scale))
		# fhat.width <- c(diff(fhat.range1), diff(fhat.range2))
		# fhat.ratio <- fhat.unq1/fhat.unq2
# #		color.bins2 <- round(color.bins*fhat.ratio, 0)
		# color.bins2 <- fhat.unq2
		# max.col <- colramp2(color.bins)[color.bins]
		# if (verbose) message(paste(c("this fhat max=",max(map$fhat),", fhat.max=",fhat.max,", fhat.scale=",fhat.scale,", color.bins=",color.bins,", color.bins2=",color.bins2,collapse="")))
		# if (fhat.ratio > 1) {
			# # these levels > scale levels; max density color will saturate at fhat.max instead of max(map$fhat) 
			# # color.bins2 < color.bins
			# pal2 <- c(colramp2(color.bins2), rep(max.col,color.bins-color.bins2))
		# } else {
			# # this max <= scale max; density colors will end where max(map$fhat) resides on the range from 0:fhat.max
			# # color.bins2 >= color.bins
			# pal2 <- colramp2(color.bins2)[1:color.bins]
		# }
		# # cols <- colorRampPalette(pal2)
		# cols <- palettizer(pal2, n.colors=color.bins)
	# } else {
		# cols <- colramp2(color.bins)
	# }
	## 3. cols is now a series of 256 colors
	
	###### END HACK 2 ######
	
	xm <- map$x1
	ym <- map$x2
	dens <- map$fhat
#	dens[] <- transformation(dens)
#	image(xm, ym, z = dens, col = colramp(col.res), xlab = xlab, ylab = ylab, xlim = xlim, ylim = ylim, xaxs = xaxs, yaxs = yaxs, ...)	#### ORIGINAL
	image(xm, ym, z = dens, col = cols, xlab = xlab, ylab = ylab, xlim = xlim, ylim = ylim, xaxs = xaxs, yaxs = yaxs, ...)	#### HACKED
	if (!is.null(postPlotHook)) 
		postPlotHook()
	if (nrpoints > 0) {
		nrpoints <- min(nrow(x), ceiling(nrpoints))
		stopifnot((nx <- length(xm)) == nrow(dens), (ny <- length(ym)) == ncol(dens))
		ixm <- 1L + as.integer((nx - 1) * (x[, 1] - xm[1])/(xm[nx] - xm[1]))
		iym <- 1L + as.integer((ny - 1) * (x[, 2] - ym[1])/(ym[ny] - ym[1]))
		sel <- order(dens[cbind(ixm, iym)])[seq_len(nrpoints)]
		points(x[sel, ], pch = pch, cex = cex, col = col)
	}
	invisible(map)
}


apa.names$plots <- c(apa.names$plots, "pairs2")
pairs2 <- function (x, labels, panel=points, ..., lower.panel=panel, upper.panel=panel, diag.panel=NULL, text.panel=textPanel, label.pos=0.5 + has.diag/3, cex.labels=NULL, font.labels=1, row1attop=TRUE, gap=1, abcol=1, abslope=1, ablty=1, ablwd=1) 
{
    textPanel <- function(x = 0.5, y = 0.5, txt, cex, font) text(x, 
        y, txt, cex = cex, font = font)
    localAxis <- function(side, x, y, xpd, bg, col = NULL, main, 
        oma, ...) {
        if (side%%2 == 1) 
            Axis(x, side = side, xpd = NA, ...)
        else Axis(y, side = side, xpd = NA, ...)
    }
	plotdiag <- function(slope, col, lty, lwd) { if (slope==0) { abline(h=0, col=col, lty=lty, lwd=lwd) } else if (slope == 1) { abline(0, 1, col=col, lty=lty, lwd=lwd) } }
    ##localPlot <- function(..., main, oma, font.main, cex.main, plotab) { plot(...); if (plotab) plotdiag(abslope, abcol, ablty, ablwd) }
    localPlot <- function(..., main, oma, font.main, cex.main) plot(...)
    localLowerPanel <- function(..., main, oma, font.main, cex.main, plotab) { lower.panel(...); if (plotab) plotdiag(abslope, abcol, ablty, ablwd) }
    localUpperPanel <- function(..., main, oma, font.main, cex.main, plotab) { upper.panel(...); if (plotab) plotdiag(abslope, abcol, ablty, ablwd) }
    localDiagPanel <- function(..., main, oma, font.main, cex.main) diag.panel(...)
    dots <- list(...)
    nmdots <- names(dots)
    if (!is.matrix(x)) {
        x <- as.data.frame(x)
        for (i in seq_along(names(x))) {
            if (is.factor(x[[i]]) || is.logical(x[[i]])) 
                x[[i]] <- as.numeric(x[[i]])
            if (!is.numeric(unclass(x[[i]]))) 
                stop("non-numeric argument to 'pairs'")
        }
    }
    else if (!is.numeric(x)) 
        stop("non-numeric argument to 'pairs'")
    panel <- match.fun(panel)
    if ((has.lower <- !is.null(lower.panel)) && !missing(lower.panel)) 
        lower.panel <- match.fun(lower.panel)
    if ((has.upper <- !is.null(upper.panel)) && !missing(upper.panel)) 
        upper.panel <- match.fun(upper.panel)
    if ((has.diag <- !is.null(diag.panel)) && !missing(diag.panel)) 
        diag.panel <- match.fun(diag.panel)
    if (row1attop) {
        tmp <- lower.panel
        lower.panel <- upper.panel
        upper.panel <- tmp
        tmp <- has.lower
        has.lower <- has.upper
        has.upper <- tmp
    }
    nc <- ncol(x)
    if (nc < 2) 
        stop("only one column in the argument to 'pairs'")
    has.labs <- TRUE
    if (missing(labels)) {
        labels <- colnames(x)
        if (is.null(labels)) 
            labels <- paste("var", 1L:nc)
    }
    else if (is.null(labels)) 
        has.labs <- FALSE
    oma <- if ("oma" %in% nmdots) 
        dots$oma
    else NULL
    main <- if ("main" %in% nmdots) 
        dots$main
    else NULL
    if (is.null(oma)) {
        oma <- c(4, 4, 4, 4)
        if (!is.null(main)) 
            oma[3L] <- 6
    }
    opar <- par(mfrow = c(nc, nc), mar = rep.int(gap/2, 4), oma = oma)
    on.exit(par(opar))
    dev.hold()
    on.exit(dev.flush(), add = TRUE)
    for (i in if (row1attop) 
        1L:nc
    else nc:1L) for (j in 1L:nc) {
		plotab <- i!=j
        localPlot(x[, j], x[, i], xlab = "", ylab = "", axes = FALSE, 
            type = "n", ...)
        if (i == j || (i < j && has.lower) || (i > j && has.upper)) {
            box()
            if (i == 1 && (!(j%%2) || !has.upper || !has.lower)) 
                localAxis(1 + 2 * row1attop, x[, j], x[, i], 
                  ...)
            if (i == nc && (j%%2 || !has.upper || !has.lower)) 
                localAxis(3 - 2 * row1attop, x[, j], x[, i], 
                  ...)
            if (j == 1 && (!(i%%2) || !has.upper || !has.lower)) 
                localAxis(2, x[, j], x[, i], ...)
            if (j == nc && (i%%2 || !has.upper || !has.lower)) 
                localAxis(4, x[, j], x[, i], ...)
            mfg <- par("mfg")
            if (i == j) {
                if (has.diag) 
                  localDiagPanel(as.vector(x[, i]), ...)
                if (has.labs) {
                  par(usr = c(0, 1, 0, 1))
                  if (is.null(cex.labels)) {
                    l.wid <- strwidth(labels, "user")
                    cex.labels <- max(0.8, min(2, 0.9/max(l.wid)))
                  }
                  text.panel(0.5, label.pos, labels[i], cex = cex.labels, 
                    font = font.labels)
                }
            }
            else if (i < j) 
                localLowerPanel(as.vector(x[, j]), as.vector(x[, 
                  i]), plotab=plotab, ...)
            else localUpperPanel(as.vector(x[, j]), as.vector(x[, 
                i]), plotab=plotab, ...)
            if (any(par("mfg") != mfg)) 
                stop("the 'panel' function made a new plot")
        }
        else par(new = FALSE)
    }
    if (!is.null(main)) {
        font.main <- if ("font.main" %in% nmdots) 
            dots$font.main
        else par("font.main")
        cex.main <- if ("cex.main" %in% nmdots) 
            dots$cex.main
        else par("cex.main")
        mtext(main, 3, 3, TRUE, 0.5, cex = cex.main, font = font.main)
    }
    invisible(NULL)
}


apa.names$plots <- c(apa.names$plots, "cross.pairs")
cross.pairs <- function(x, y=NULL, xname=NULL, yname=NULL, col="#00000044", pch=1, abcol=4, ablty=1, pt.cex=0.75, text.cex=1, R=FALSE) {
    
    ## Like pairs(), but can plot columns of matrix x vs matrix y.  Also has ablines.
    
    if (length(y)==0) {
        y <- x
    } else if (nrow(x)!=nrow(y)) {
        stop("'x' and 'y' must have same number of rows!\n")
    }

    NCX <- ncol(x)+1
    NCY <- ncol(y)+1
    xrange <- range(c(x)[!is.infinite(c(x))], na.rm=TRUE)
    yrange <- range(c(y)[!is.infinite(c(y))], na.rm=TRUE)
    
    if (length(xname)>0) {
        xnames <- paste(xname, colnames(x), sep="\n")
    } else {
        xnames <- colnames(x)
    }
    xnames <- c("", xnames)
    if (length(yname)>0) {
        ynames <- paste(yname, colnames(y), sep="\n")
    } else {
        ynames <- colnames(y)
    }
    ynames <- c(ynames, "")
    
    par(mfcol=c(NCX,NCY), mar=c(2,2,0,0), las=1)
    
    for (i in 1:NCX) {
        yaxt <- ifelse (i==2, "s", "n")
        if (i==1) {
            ## first col; plot y names
            for (j in 1:NCY) {
                plot(0, 0, col=0, xlab="", ylab="", main="", xaxt="n", yaxt="n", frame.plot=j!=NCY)
                if (j==NCY) next
                text(0, 0, font=2, cex=text.cex*1.2, labels=ynames[j])
            }
        } else {
            for (j in 1:NCY) {
                xaxt <- ifelse (j==NCY-1, "s", "n")
                if (j==NCY) {
                    ## last row; plot x names
                    plot(0, 0, col=0, xlab="", ylab="", main="", xaxt="n", yaxt="n")
                    text(0, 0, font=2, cex=text.cex*1.2, labels=xnames[i])
                } else {
                    xy <- cbind(x[,i-1], y[,j])
                    xy <- xy[apply(!is.na(xy)&!is.infinite(xy), 1, all),]
                    plot(xy, col=col, pch=pch, cex=pt.cex, xlim=xrange, ylim=yrange, xlab="", ylab="", main="", xaxt=xaxt, yaxt=yaxt)
                    abline(0, 1, col=abcol, lty=ablty)
                    if (R) text(mean(xrange), max(yrange)*0.95, font=2, col=abcol, cex=text.cex, labels=paste("R =",round(cor(xy[,1],xy[,2]),3)))
                }
            }
        }
    }
}


apa.names$plots <- c(apa.names$plots, "legend2")
legend2 <- function (x, y=NULL, legend, fill=NULL, col=par("col"), border="black", lty, lwd, pch, angle=45, density=NULL, 
	bty="o", bg=par("bg"), box.lwd=par("lwd"), box.lty=par("lty"), box.col=par("fg"), pt.bg=NA, cex=1, pt.cex=cex, pt.lwd=lwd, 
	xjust=0, yjust=1, x.intersp=1, y.intersp=1, adj=c(0, 0.5), text.width=NULL, text.col=par("col"), merge=do.lines && 
		has.pch, trace=FALSE, plot=TRUE, ncol=1, horiz=FALSE, title=NULL, inset=0, xpd, title.col=text.col, font=1) {

	# lots of code streamlining, but only one very slight hack, to support the use of "font" attribute

	if (missing(legend) && !missing(y) && (is.character(y) || is.expression(y))) {
		legend <- y
		y <- NULL
	}
	mfill <- !missing(fill) || !missing(density)
	if (!missing(xpd)) {
		op <- par("xpd")
		on.exit(par(xpd = op))
		par(xpd = xpd)
	}
	title <- as.graphicsAnnot(title)
	if (length(title) > 1) { stop("invalid title") }
	legend <- as.graphicsAnnot(legend)
	n.leg <- ifelse (is.call(legend), 1, length(legend))
	if (n.leg == 0) { stop("'legend' is of length 0") }
	auto <- ifelse (is.character(x), match.arg(x, c("bottomright","bottom","bottomleft","left","topleft","top","topright","right","center")), NA)
	if (is.na(auto)) {
		xy <- xy.coords(x, y)
		x <- xy$x
		y <- xy$y
		nx <- length(x)
		if (nx < 1 || nx > 2) { stop("invalid coordinate lengths") }
	} else { nx <- 0 }
	xlog <- par("xlog")
	ylog <- par("ylog")
	rect2 <- function(left, top, dx, dy, density = NULL, angle, ...) {
		r <- left + dx
		if (xlog) {
			left <- 10^left
			r <- 10^r
		}
		b <- top - dy
		if (ylog) {
			top <- 10^top
			b <- 10^b
		}
		rect(left, top, r, b, angle = angle, density = density, ...)
	}
	segments2 <- function(x1, y1, dx, dy, ...) {
		x2 <- x1 + dx
		if (xlog) {
			x1 <- 10^x1
			x2 <- 10^x2
		}
		y2 <- y1 + dy
		if (ylog) {
			y1 <- 10^y1
			y2 <- 10^y2
		}
		segments(x1, y1, x2, y2, ...)
	}
	points2 <- function(x, y, ...) {
		if (xlog) { x <- 10^x }
		if (ylog) { y <- 10^y }
		points(x, y, ...)
	}
	text2 <- function(x, y, ...) {
		if (xlog) { x <- 10^x }
		if (ylog) { y <- 10^y }
		text(x, y, ...)
	}
	if (trace) { catn <- function(...) do.call("cat", c(lapply(list(...), formatC), list("\n"))) }
	cin <- par("cin")
	Cex <- cex * par("cex")
	if (is.null(text.width)) { text.width <- max(abs(strwidth(legend, units = "user", cex = cex))) 
	} else if (!is.numeric(text.width) || text.width < 0) { stop("'text.width' must be numeric, >= 0") }
	xc <- Cex * xinch(cin[1L], warn.log = FALSE)
	yc <- Cex * yinch(cin[2L], warn.log = FALSE)
	if (xc < 0) { text.width <- -text.width }
	xchar <- xc
	xextra <- 0
	yextra <- yc * (y.intersp - 1)
	ymax <- yc * max(1, strheight(legend, units = "user", cex = cex)/yc)
	ychar <- yextra + ymax
	if (trace) { catn("  xchar=", xchar, "; (yextra,ychar)=", c(yextra, ychar)) }
	if (mfill) {
		xbox <- xc * 0.8
		ybox <- yc * 0.5
		dx.fill <- xbox
	}
	do.lines <- (!missing(lty) && (is.character(lty) || any(lty > 0))) || !missing(lwd)
	n.legpercol <- if (horiz) {
		if (ncol != 1) { warning("horizontal specification overrides: Number of columns := ", n.leg) }
		ncol <- n.leg
		1
	} else { ceiling(n.leg/ncol) }
	has.pch <- !missing(pch) && length(pch) > 0
	if (do.lines) {
		x.off <- ifelse (merge, -0.7, 0)
	} else if (merge) { warning("'merge = TRUE' has no effect when no line segments are drawn") }
	if (has.pch) {
		if (is.character(pch) && !is.na(pch[1L]) && nchar(pch[1L], type = "c") > 1) {
			if (length(pch) > 1) { warning("not using pch[2..] since pch[1L] has multiple chars") }
			np <- nchar(pch[1L], type = "c")
			pch <- substr(rep.int(pch[1L], np), 1L:np, 1L:np)
		}
	}
	if (is.na(auto)) {
		if (xlog) { x <- log10(x) }
		if (ylog) { y <- log10(y) }
	}
	if (nx == 2) {
		x <- sort(x)
		y <- sort(y)
		left <- x[1L]
		top <- y[2L]
		w <- diff(x)
		h <- diff(y)
		w0 <- w/ncol
		x <- mean(x)
		y <- mean(y)
		if (missing(xjust)) { xjust <- 0.5 }
		if (missing(yjust)) { yjust <- 0.5 }
	} else {
		h <- (n.legpercol + (!is.null(title))) * ychar + yc
		w0 <- text.width + (x.intersp + 1) * xchar
		if (mfill) 
			w0 <- w0 + dx.fill
		if (do.lines) 
			w0 <- w0 + (2 + x.off) * xchar
		w <- ncol * w0 + 0.5 * xchar
		if (!is.null(title) && (abs(tw <- strwidth(title, units = "user", 
			cex = cex) + 0.5 * xchar)) > abs(w)) {
			xextra <- (tw - w)/2
			w <- tw
		}
		if (is.na(auto)) {
			left <- x - xjust * w
			top <- y + (1 - yjust) * h
		} else {
			usr <- par("usr")
			inset <- rep(inset, length.out = 2)
			insetx <- inset[1L] * (usr[2L] - usr[1L])
			left <- switch(auto, bottomright = , topright = , 
				right = usr[2L] - w - insetx, bottomleft = , 
				left = , topleft = usr[1L] + insetx, bottom = , 
				top = , center = (usr[1L] + usr[2L] - w)/2)
			insety <- inset[2L] * (usr[4L] - usr[3L])
			top <- switch(auto, bottomright = , bottom = , bottomleft = usr[3L] + 
				h + insety, topleft = , top = , topright = usr[4L] - 
				insety, left = , right = , center = (usr[3L] + 
				usr[4L] + h)/2)
		}
	}
	if (plot && bty != "n") {
		if (trace) { catn("  rect2(", left, ",", top, ", w=", w, ", h=", h, ", ...)", sep = "") }
		rect2(left, top, dx = w, dy = h, col = bg, density = NULL, lwd = box.lwd, lty = box.lty, border = box.col)
	}
	xt <- left + xchar + xextra + (w0 * rep.int(0:(ncol - 1), rep.int(n.legpercol, ncol)))[1L:n.leg]
	yt <- top - 0.5 * yextra - ymax - (rep.int(1L:n.legpercol, ncol)[1L:n.leg] - 1 + (!is.null(title))) * ychar
	if (mfill) {
		if (plot) {
			fill <- rep(fill, length.out = n.leg)
			rect2(left = xt, top = yt + ybox/2, dx = xbox, dy = ybox, col = fill, density = density, angle = angle, border = border)
		}
		xt <- xt + dx.fill
	}
	if (plot && (has.pch || do.lines)) { col <- rep(col, length.out = n.leg) }
	if (missing(lwd)) { lwd <- par("lwd") }
	if (do.lines) {
		seg.len <- 2
		if (missing(lty)) { lty <- 1 }
		lty <- rep(lty, length.out = n.leg)
		lwd <- rep(lwd, length.out = n.leg)
		ok.l <- !is.na(lty) & (is.character(lty) | lty > 0)
		if (trace) { catn("  segments2(", xt[ok.l] + x.off * xchar, ",", yt[ok.l], ", dx=", seg.len * xchar, ", dy=0, ...)") }
		if (plot) { segments2(	xt[ok.l] + x.off * xchar, yt[ok.l], dx = seg.len * xchar, dy = 0, lty = lty[ok.l], 
					lwd = lwd[ok.l], col = col[ok.l] ) }
		xt <- xt + (seg.len + x.off) * xchar
	}
	if (has.pch) {
		pch <- rep(pch, length.out = n.leg)
		pt.bg <- rep(pt.bg, length.out = n.leg)
		pt.cex <- rep(pt.cex, length.out = n.leg)
		pt.lwd <- rep(pt.lwd, length.out = n.leg)
		ok <- !is.na(pch) & (is.character(pch) | pch >= 0)
		x1 <- (if (merge && do.lines) { xt - (seg.len/2) * xchar } else { xt })[ok]
		y1 <- yt[ok]
		if (trace) { catn("  points2(", x1, ",", y1, ", pch=", pch[ok], ", ...)") }
		if (plot) { points2(x1, y1, pch = pch[ok], col = col[ok], cex = pt.cex[ok], bg = pt.bg[ok], lwd = pt.lwd[ok]) }
	}
	xt <- xt + x.intersp * xchar
	if (plot) {
		if (!is.null(title)) { text2(left + w/2, top - ymax, labels = title, adj = c(0.5, 0), cex = cex, col = title.col) }
		text2(xt, yt, labels = legend, adj = adj, cex = cex, col = text.col, font = font)
	}
	invisible(list(rect = list(w = w, h = h, left = left, top = top), text = list(x = xt, y = yt)))
}


apa.names$plots <- c(apa.names$plots, "CAT.enrichment.frame")
CAT.enrichment.frame <- function(a, N, fixed, limit) {

	if (fixed) {
		breaks <- seq(0, length(a), N)
		if (length(a) %% N > 0) breaks <- c(breaks, length(a))
	} else {
		breaks <- floor( seq(0, length(a), length.out=N) )
	}
	B <- length(breaks)

	xmax <- ceiling(B*limit/100)		# x axis plot limit, in terms of # bins
	if (xmax <= 10) {	# don't make custom axes -- use actual bins
		axbins <- 1:xmax
		axlabs <- breaks[1:xmax]
	} else {
		scale <- trunc(xmax / 10)
		if (xmax %% 10 > 0) scale <- scale + 1
		axbins <- seq(1, xmax, scale)
		if (limit == 100 && length(axbins) <= 10) axbins <- c(axbins, length(breaks))
		axlabs <- breaks[axbins]
	}
	
	list(breaks=breaks, B=B, xmax=xmax, axbins=axbins, axlabs=axlabs)
}

	
apa.names$plots <- c(apa.names$plots, "CAT.plot")
CAT.plot <- function(a, b, N, fixed=TRUE, decreasing=TRUE, add.line=FALSE, limit.pct=100, xlim=NULL, ylim=c(0,1), diag=TRUE, main=NULL, col=1, lty=1, lwd=1, R.line=FALSE, R.log=FALSE, R.col=1, R.lty=3, R.lwd=1) {
	
	## Takes two NAMED numeric vectors of equal length (a, b) and makes a CAT (Correspondence-At-the-Top) plot from them.
	## "N": bin increment for breaking up the input list - CAT scores checked at each break.
	## "fixed": interpret "N" as N items per bin (TRUE) or as N bins for whole list (FALSE)?
	## "decreasing": if false, sort vectors increasing (i.e. lowest values first)-- get CAB (Correspondence-At-the-Bottom) plot.
	## "add.line = T": add CAT plot as a line to an existing plot .
	## "add.line = F": generate a new plot.
	## "col", "lty", "lwd" control plot line appearance (all work for either "add.line" mode).
	## "R.line = T": add a new line, plotting the correlation value for the set overlaps.  ("RAT" plot: "R-value-at-the-top").
	## "R.log = T": correlate log-values (otherwise, linear).
	## "R.col", "R.lty", "R.lwd" apply to the R line.
	## The following only apply for "add.line = F":
	##   "limit.pct": percent cutoff re: how much of the list tops the plot should show (don't plot beyond the top limit.pct%).
	##   "diag": plots the diagonal (line of random enrichment; grey dashed line).
	##   "main": gives a title to the CAT plot.
	
	if ( length(a) != length(b) ) stop("Vectors a, b must be of same length!\n")
	if ( is.null(names(a)) | is.null(names(b)) ) stop("Vectors a, b must both be named! (i.e. have non-null names()\n")
	a <- a[order(a, decreasing=decreasing)]
	b <- b[order(b, decreasing=decreasing)]
	
	vars <- CAT.enrichment.frame(a, N, fixed, limit.pct)
	breaks <- vars$breaks
	B <- vars$B
	xmax <- vars$xmax
	axbins <- vars$axbins
	axlabs <- vars$axlabs
	
	data <- list(set.size=breaks, overlap=c(0), overlap.pct=c(0), overlap.names=vector("list", length=B))
	
	if (length(B) > 1000) {
		message("High bin count; this may take a minute...\n")
		flush.console()
	}
	if (R.line) {
		message("Correlation line added; this will take extra time...\n")
		flush.console()
	}
	
	for (i in 2:B) {
		N.a <- names(a)[1:breaks[i]]
		N.b <- names(b)[1:breaks[i]]
		I <- intersect(N.a, N.b)
		U <- union(N.a, N.b)
		if (length(I) > 0) data$overlap[i] <- length(I)
		data$overlap.pct[i] <- length(I) / length(U)
		if (R.line) { 
			if (length(I) > 3) {
				x <- a[match(I,names(a))]
				y <- b[match(I,names(b))]
				data$overlap.corr[i] <- ifelse(R.log, cor(log(x), log(y), method="pearson"), cor(x, y, method="pearson"))
			} else {
				data$overlap.corr[i] <- NA
			}
		}
		data$overlap.names[[i]] <- I
#		report.index(i, 5000)
	}
	
	if (add.line) {
		lines(1:B, data$overlap.pct, col=col, lty=lty, lwd=lwd) 
	} else {
		if (is.null(xlim)) xlim=c(1,xmax)
		if (is.null(main)) main <- ifelse(decreasing, "CAT Plot", "CAB Plot")
		plot(1:B, data$overlap.pct, type="n", ylim=ylim, xlim=xlim, ylab="Percent Overlap", xlab="Set Size", main=main, xaxt="n")
		if (diag) segments(1, 0, B, 1, lty=2, col="grey50")
		lines(1:B, data$overlap.pct, col=col, lty=lty, lwd=lwd)
		axis(1, at=axbins, labels=axlabs)
	}
	
	if (R.line) lines(1:B, data$overlap.corr, col=R.col, lty=R.lty, lwd=R.lwd)
	
	invisible(data)
}


apa.names$plots <- c(apa.names$plots, "enrichment.curve")
enrichment.curve <- function(a, N, fixed=TRUE, add.line=FALSE, limit=100, ylim=c(0,1), diag=TRUE, main=NULL, col=1, lty=1, lwd=1) {
	
	## Takes a sorted numeric or binary vector and plots and enrichment curve, basically the CDF for a GSEA-style metric.
	## "N": bin increment for breaking up the input list - CAT scores checked at each break.
	## "fixed": interpret "N" as N items per bin (TRUE) or as N bins for whole list (FALSE)?
	## "decreasing": if false, sort vectors increasing (i.e. lowest values first)-- get CAB (Correspondence-At-the-Bottom) plot
	## "add.line = T": add CAT plot as a line to an existing plot 
	## "add.line = F": generate a new plot
	## "col", "lty", "lwd" control plot line appearance (all work for either "add.line" mode)
	## The following only apply for "add.line = F":
	##   "limit": percent cutoff re: how much of the list tops the plot should show (don't plot beyond the top limit%)
	##   "diag": plots the diagonal (line of random enrichment; grey dashed line)
	##   "main": gives a title to the plot
	
	vars <- CAT.enrichment.frame(a, N, fixed, limit)
	breaks <- vars$breaks
	B <- vars$B
	xmax <- vars$xmax
	axbins <- vars$axbins
	axlabs <- vars$axlabs
	
	data <- list(set.size=breaks, overlap=c(0), overlap.pct=c(0), overlap.names=vector("list", length=B))
	
	if (add.line == T) {
		lines(1:B, data$overlap.pct, col=col, lty=lty, lwd=lwd) 
	} else {
		if (is.null(main)) ternary ( decreasing, main <- "CAT Plot", main <- "CAB Plot" )
		plot(	1:B, data$overlap.pct, type="n", ylim=ylim, xlim=c(1,xmax), 
			ylab="Percent Overlap", xlab="Set Size", main=main, xaxt="n" )
		if (diag == T) segments(1, 0, B, 1, lty=2, col="grey50")
		lines(1:B, data$overlap.pct, col=col, lty=lty, lwd=lwd)
		axis(1, at=axbins, tick=TRUE, labels=axlabs)
	}
	invisible(data)
}


apa.names$plots <- c(apa.names$plots, "color.scale")
color.scale <- function(val.range, pal, main=NULL, breaks=11, hv=2, las=2, cex=par()$cex, cex.axis=par()$cex.axis) {
    
    ## plots a color scale, given a range of numeric values (val), a palette (pal), the number of 'val' breaks to display (breaks), and a horiz/vert flag (hv)
    ## like axes, hv=1 for horizontal and hv=2 for vertical.
    
    pal.val <- 1:length(pal)
    pal.r <- range(pal.val)
    if (hv == 1) {
        arg <- c(length(pal.val), 1, 1)  # image nrow, image ncol, axis side
    } else if (hv == 2) {
        arg <- c(1, length(pal.val), 2)
    } else {
        stop("'hv' must be 1 (horizontal) or 2 (vertical)!\n")
    }
    ax.seq <- seq(pal.r[1],pal.r[2],length.out=breaks)
    ax.lab <- sapply(seq(val.range[1],val.range[2],length.out=breaks),FUN=function(x){signif(x,3)})
    image(1, pal.val, matrix(pal.val, arg[1], arg[2]), col=pal, xlab="", ylab="", xaxt="n", yaxt="n", main=main)
    axis(arg[3], at=ax.seq, labels=ax.lab, las=las, cex.axis=cex.axis)
}


apa.names$plots <- c(apa.names$plots, "venn.diag")
venn.diag <- function(obj, names=NULL, include=c("both","up","down","opp"), dirs=NULL, universe=NULL, map=FALSE, as.pct=FALSE, showN=FALSE, colorize=FALSE, radius=2, main=NULL, calibrate=FALSE) {
    
    ## Venn diagram function; plotting code is an extensively-rewritten version of Thomas Girke's 2008/11/06 original:
    ##   source("http://faculty.ucr.edu/~tgirke/Documents/R_BioCond/My_R_Scripts/vennDia.R")
    ## This one is much more flexible with inputs, and doesn't have the incorrect 4-circle diagram option.
    ## "..." may be: a list with vectors describing sets, 
    ##		 a decideTests-type numeric matrix, 
    ##  		 the logical equivalent of a decideTests-type matrix, or 
    ##		 a venn.areas()-style list of venn area counts.
    ## In any case, # vectors, length of vector list, or ncol(matrix) must be between 1 and 5.
    ## Actual set processing is done by venn.areas(), my code.
    
    objname <- deparse(substitute(obj))
    include <- match.arg(include)
    if (is(obj, "area.list")) {	# already an area.list object
        areas <- obj
    } else if (is.matrix(obj)) {		# input not an area.list object; convert into area.list
        if (length(rownames(obj))==0) rownames(obj) <- 1:nrow(obj)
        if (length(colnames(obj))==0) colnames(obj) <- 1:ncol(obj)
        areas <- venn.areas(obj, include=include, dirs=dirs, universe=universe)
    } else if (length(obj)>0&length(obj)<=5) {		# input not an area.list object; convert into area.list
        if (length(names(obj))==0) {
            if (length(names)==0) {
                names(obj) <- names
            } else {
                names(obj) <- 1:length(obj)
            }
        }
        areas <- venn.areas(obj, include=include, dirs=dirs, universe=universe)
    } else if (length(obj)>5) {			# too large
        null.plot(); text(0, 0, "Too many vectors!")
        IM("Cannot plot > 5 vectors!\n")
        return()
    } else {
        null.plot()
        IM("Cannot plot an empty object!\n")
        return()
    }
    
    trueN <- length(areas)
    N <- switch(as.character(trueN), "1"=, "2"=1, "3"=, "4"=2, "7"=, "8"=3, "15"=, "16"=4, "31"=, "32"=5)
    maxN <- switch(as.character(N), "1"=2, "2"=4, "3"=8, "4"=16, "5"=32)	# insurance, for area.list objects lacking the exclusion set
    if (!N %in% 1:5) { stop(paste("Can only diagram 1-5 sets, not ",N,"!\n",sep="")) }
    
    all.cols <- c(2,3,4,"gold2","darkorchid")
    generics <- c("v","w","x","y","z")
    ternary (colorize, acols <- all.cols[1:N], acols <- rep(1,N))
    tcol <- lcol <- diacol <- 1
    radii <- rep(radius,N)
    ternary (map, labels <- generics[1:N], labels <- names(areas)[1:N])
    area.names <- paste("q", 1:maxN, sep="")
    lims <- c(0,10)
    count <- listLengths(areas)
    
    if (as.pct) {
        total <- sum(count[1:maxN-1])
        count <- round(100 * count / total, 1)
    }
    
    if (calibrate) count <- rep("000",length(count))
    
    if (is.null(main)) { 
#		main <- paste("Venn Diagram, ", objname, sep="")
        main <- objname
        if(!is.null(attr(areas, "include"))) { main <- paste(main,", ",include,sep="") }
    }
    
    basic.venn.plot <- function(count, main) {
        ## get most data from parent namespace
        symbols(symb.pos$x, symb.pos$y, circles=radii, fg=acols, xlim=lims, ylim=lims, inches=FALSE, main=main, xlab="", ylab="", xaxt="n", yaxt="n", bty="n")
        text(text.pos$x, text.pos$y, count, col=1)
        text(lab.pos$x, lab.pos$y, labels, col=acols)
    }
    
    plotellipse <- function (center=c(1,1), radius=c(1,2), rotate=1, segments=360, xlab="", ylab="", col=1) {
        angles <- (0:segments) * 2 * pi/segments  
        rotate <- rotate * pi / 180
        ellipse <- cbind(radius[1] * cos(angles), radius[2] * sin(angles))
        ellipse <- cbind( ellipse[,1]*cos(rotate) + ellipse[,2]*sin(rotate), ellipse[,2]*cos(rotate) - ellipse[,1]*sin(rotate) )
        ellipse <- cbind(center[1]+ellipse[,1], center[2]+ellipse[,2])	
        lines(ellipse, type="l", xlim=lims, ylim=lims, xlab="", ylab="", col=col)
##	points(center[1], center[2], pch=15, col=col)   # mark ellipse centers?
    }
    
    if (N == 1) {
        text.pos <- data.frame(x=c(5,9), y=c(6.1,0.5))
        symb.pos <- data.frame(x=5, y=6)
        lab.pos <- data.frame(x=5, y=8.8)
        if (map) {
            count <- area.names
            main <- "Mapping Venn Diagram"
        }
        basic.venn.plot(count, main)
    }
    
    if (N == 2) {
        text.pos <- data.frame(x=c(3.1, 7.0, 5.0, 9), y=c(6.1, 6.1, 6.1, 0.5))
        symb.pos <- data.frame(x=c(4, 6), y=c(6, 6))
        lab.pos <- data.frame(x=c(2.0, 8.0), y=c(8.8, 8.8))
        if (map) {
            count <- area.names
            main <- "Mapping Venn Diagram"
        }
        basic.venn.plot(count, main)
    }
    
    if (N == 3) {
        text.pos <- data.frame(x=c(3.0, 7.0, 5.0, 5.0, 3.8, 6.3, 5.0, 9), y=c(6.5, 6.5, 3.0, 6.9, 4.6, 4.6, 5.4, 0.5))
        symb.pos <- data.frame(x=c(4, 6, 5), y=c(6, 6, 4))
        lab.pos <- data.frame(x=c(2.0, 8.0, 5.0), y=c(8.8, 8.8, 1.1))
        if (map) {
            count <- area.names
            main <- "Mapping Venn Diagram"
        }
        basic.venn.plot(count, main)
    }
    
    if (N == 4) {
        text.pos <- data.frame(
            x=c(1.5, 3.5, 6.5, 8.5, 2.9, 3.1, 5.0, 5.0, 6.9, 7.1, 3.6, 5.8, 4.2, 6.4, 5.0, 9), 
            y=c(4.8, 7.2, 7.2, 4.8, 5.9, 2.2, 0.7, 6.0, 2.2, 5.9, 4.0, 1.4, 1.4, 4.0, 2.8, 0.5)
        )
        lab.pos <- data.frame(x=c(0.4, 2.8, 7.5, 9.4), y=c(7.7, 8.7, 8.7, 7.7))
        ## Plot ellipse as 4-way venn diagram
        ellipseVenn <- function(count, main, tcex=1.3) {   ## Get most data from parent namespace
            plot(lims, lims, type="n", xlim=lims, ylim=lims, main=main, xlab="", ylab="", xaxt="n", yaxt="n", bty="n")
            plotellipse(center=c(3.5,3.6), radius=c(2,4), rotate=-35, segments=360, xlab="", ylab="", col=acols[1])
            plotellipse(center=c(4.7,4.4), radius=c(2,4), rotate=-35, segments=360, xlab="", ylab="", col=acols[2])
            plotellipse(center=c(5.3,4.4), radius=c(2,4), rotate=35, segments=360, xlab="", ylab="", col=acols[3])
            plotellipse(center=c(6.5,3.6), radius=c(2,4), rotate=35, segments=360, xlab="", ylab="", col=acols[4])
            text(text.pos$x, text.pos$y, count, col=tcol)
            text(lab.pos$x, lab.pos$y, labels, col=acols)
        }
        if (map) {
            count <- area.names
            main <- "Mapping Venn Diagram"
        }
        ellipseVenn(count, main)
    }

    if (N == 5) {
        text.pos <- data.frame(
            x=c(4.1,1.2,3.4,7.9,8.2, 3.30,5.20,6.50,6.45,2.45, 2.45,7.60,5.20,3.30,7.70, 4.50,3.12,6.85,5.50,6.05, 6.70,2.80,2.80,7.60,4.05, 3.70,5.90,6.90,5.30,3.20, 5,9), 
            y=c(8.8,5.4,1.4,2.3,7.1, 7.20,7.70,2.75,7.55,4.20, 5.90,5.70,2.20,2.80,4.30, 7.15,6.77,6.30,2.50,7.32, 3.60,5.10,3.70,4.75,3.15, 6.40,6.75,5.05,3.00,4.50, 5,0)
        )
##		labxy <- 5+5*cbind(cos(theta2),sin(theta2))  # initial label points, see theta2 in ellipseVenn func below
        lab.pos <- data.frame(x=c(4.1, 0.5, 3.4, 7.7, 8.2), y=c(10.2, 7.3, 0.1, 1.0, 8.4))
        ## Plot ellipse as 5-way venn diagram
        ellipseVenn <- function(count, main, tcex=1.3) {   ## Get most data from parent namespace
            elrad <- c(2,4); rad <- 1; ca <- -15; ra <- -18; theta <- 72*0:4; theta2 <- (0.55*pi)+(theta+ca)*pi/180
            plot(lims, lims, type="n", xlim=lims, ylim=lims, main=main, xlab="", ylab="", xaxt="n", yaxt="n", bty="n")
            plotellipse(center=c(5+rad*cos(theta2[1]),5+rad*sin(theta2[1])), radius=elrad, rotate=-theta[1]+ra, segments=360, xlab="", ylab="", col=acols[1])
            plotellipse(center=c(5+rad*cos(theta2[2]),5+rad*sin(theta2[2])), radius=elrad, rotate=-theta[2]+ra, segments=360, xlab="", ylab="", col=acols[2])
            plotellipse(center=c(5+rad*cos(theta2[3]),5+rad*sin(theta2[3])), radius=elrad, rotate=-theta[3]+ra, segments=360, xlab="", ylab="", col=acols[3])
            plotellipse(center=c(5+rad*cos(theta2[4]),5+rad*sin(theta2[4])), radius=elrad, rotate=-theta[4]+ra, segments=360, xlab="", ylab="", col=acols[4])
            plotellipse(center=c(5+rad*cos(theta2[5]),5+rad*sin(theta2[5])), radius=elrad, rotate=-theta[5]+ra, segments=360, xlab="", ylab="", col=acols[5])
            text(text.pos$x, text.pos$y, count, col=tcol)
            text(lab.pos$x, lab.pos$y, labels, col=acols)
        }
        if (map) {
            count <- area.names
            main <- "Mapping Venn Diagram"
        }
        ellipseVenn(count, main)
    }
    invisible(areas)
}


apa.names$plots <- c(apa.names$plots, "dhist")
dhist <- function(vecs, vnames=NULL, points=FALSE, add=FALSE, legend="auto", verbose=TRUE, logscale=NA, dens.n=2^9, xlab="", xmin=NA, force.unit=FALSE, imgname=NULL, imgdim=c(700,600), device=c("png","pdf"), cex=par()$cex, denormalize=FALSE, pch="|", plot=TRUE, ...) {
    
    ## Density-histogram shortcut.
    ## 'vecs' is a list of vectors, matrix, or dataframe.
    ## 'vnames' names the list, if not already named.
    ## 'col' is a vector of colors, one for each element of 'vecs'.  If null, rainbow(length(vecs)) gets used.
    ## 'points=T' plots the point spread on the x-axis.  Not recommended for many-line histograms.
    ## 'add=T' allows dhist lines to be addd to an existing plot (e.g., another dhist using a different 'adjust' value)
    ## 'logscale' can be one of c(NA, "log", "log2", "log10"), indicating plotting in linear (NA) or log something.
    ## 'legend' indicates position of legend (e.g. "topleft"); NA for no legend; "auto" to make dhist() decide between "topleft" and "topright".
    ## "..." are other args are for either hist(), density(), or legend().
    ## use "dens.n" for density() 'n' argument
    ## "xlab" as usual
    ## 'xmin' specifies minimum x-axis value.  NA sets xmin = data min.
    ## ***** na.rm == TRUE automatically *****
    
    other.args <- list(...)
    dens.argnames <- c("x","bw","adjust","kernel","weights","window","width","give.Rkern","from","to","cut","na.rm")
    hist.argnames <- c("x","breaks","freq","probability","include.lowest","right","density","angle","col","border","main","sub","xlim","ylim","xlab","ylab","axes","plot","labels","nclass","xaxt","yaxt")
    legend.argnames <- c("x","y","legend","fill","col","border","lty","lwd","pch","angle","density","bty","bg","box.lwd","box.lty","box.col","pt.bg","cex","pt.cex","pt.lwd","xjust","yjust","x.intersp","y.intersp","adj","text.width","text.col","merge","trace","plot","ncol","horiz","title","inset","xpd","title.col","text.col")
    if (!is.na(logscale)) { match.arg(logscale, c("log", "log2", "log10")) }
    
    if (!is.na(device[1])) device <- match.arg(device)
    plot2file <- ifelse(is.na(device)|length(imgname)==0, FALSE, TRUE)
    
    xname <- deparse(substitute(vecs))
    if (is.ndfl(vecs)) {
        ## ok
    } else if (is.data.frame(vecs)) {
        vecs <- as.list(vecs)
    } else if (is.matrix(vecs)) {
        vecs <- as.list(as.data.frame(vecs))
    } else if (is.nlv(vecs)) {
        vecs <- list(vecs)
    } else {
        stop("'vecs' must be a list, matrix, or dataframe!\n")
    }

    for (i in 1:length(vecs)) { 
        if (length(vecs[[i]])>0) {
            vecs[[i]] <- real(vecs[[i]])  # strip NAs, Infinites
        } else {
            vecs[[i]] <- numeric(0)   # replace NULL with something not-null
        }
    }
    nvec <- length(vecs)
    llv <- listLengths(vecs)
    scales <- zapsmall(llv/max(llv))
#    message(paste(c("scales: ",scales),collapse=" "))
    
    if (length(names(vecs))==0) { 		
        ternary(length(vnames)==0, names(vecs) <- 1:nvec, names(vecs) <- vnames)
    } else {
        if (length(vnames)>0) names(vecs) <- vnames     # override existing names if 'vnames' is specified
    }
    vnames <- names(vecs)  # pass back to ensure 'vnames' is also set
    
    dens.args <- other.args[names(other.args) %in% dens.argnames]
    hist.args <- other.args[names(other.args) %in% hist.argnames]
    legend.args <- other.args[names(other.args) %in% legend.argnames]
    lost.args <- setdiff( names(other.args), c(names(hist.args), names(dens.args), names(legend.args)) )
    if (length(lost.args) > 0) IM("Warning: the following '...' arguments do not belong to density() or hist() (as of 2.11.1):", paste(lost.args, collapse=", "))
    
    col <- ternary (length(other.args$col)==0, 1, other.args$col)
    if (length(col) < nvec) { ternary(nvec <= 8, col <- 1:nvec, col <- rainbow(nvec)) }
    lty <- ternary (length(other.args$lty)==0, 1, other.args$lty)
    if (length(lty) < nvec) { times <- ceiling(nvec / length(lty)); lty <- rep(lty, times) }
    lwd <- ternary (length(other.args$lwd)==0, 1, other.args$lwd)
    if (length(lwd) < nvec) { times <- ceiling(nvec / length(lwd)); lwd <- rep(lwd, times) }
    
    maxlen <- max(listLengths(vecs))
    dens <- vecs
    drops <- rep(FALSE, length(vecs))
    ally <- allx <- new.list(names(vecs))
    for (i in 1:nvec) { 
        vecs[[i]] <- nameless(real(vecs[[i]]))
        if (sum(!is.na(vecs[[i]])) >= 2) {
            if (!is.na(logscale)) {
                vecs[[i]] <- switch(logscale,
                                    log = log(vecs[[i]]),
                                    log2 = log2(vecs[[i]]),
                                    log10 = log10(vecs[[i]])
                                    )
            }
            dens.args$x <- allx[[i]] <- vecs[[i]]
            dens.args$n <- dens.n
            dens.args$na.rm <- TRUE
            dens[[i]] <- do.call(density, dens.args)
            if (denormalize) dens[[i]]$y <- dens[[i]]$y*scales[i]
            ally[[i]] <- if (force.unit) { percentify(dens[[i]]$y, range=TRUE) } else { dens[[i]]$y }
            names(ally[[i]]) <- seq(min(vecs[[i]]), max(vecs[[i]]), length=dens.n)
        } else {
            if (verbose) IM(paste("Dropping vector #",i,": not enough observations!",sep=""))
            drops[i] <- TRUE
            if (nvec == 1) { 
                null.plot(main=paste("Unable to plot",xname))
                IM("Not enough data to make a density histogram.\n") 
                return()
            } 
            dens[[i]] <- NA
        }
    }
    
    if (is.null(hist.args$xlim)) {
        hist.args$xlim[1] <- ifelse(is.na(xmin), min(real(unlist(vecs))), xmin)
        hist.args$xlim[2] <- max(real(unlist(vecs)))
        if (is.infinite(hist.args$xlim[2])) hist.args$xlim[2] <- 0	# no real() results...
    }
    if (is.null(hist.args$ylim)) {
        hist.args$ylim[1] <- 0
        hist.args$ylim[2] <- max(real(unlist(ally)))
        if (is.infinite(hist.args$ylim[2])) hist.args$ylim[2] <- 0	# no real() results...
    }
    if (is.null(hist.args$main)) hist.args$main <- paste("Density Histogram of",xname)
    if (is.null(hist.args$ylab)) hist.args$ylab <- "Density"
    hist.args$xlab <- xlab
    hist.args$x <- sort(unlist(allx))
    hist.args$col <- 0
    hist.args$border <- 0
    hist.args$freq <- 0
    
    if (points) {	# plot each set of points on slightly different y values to make them more visible
        yincr <- hist.args$ylim[2] / 50 # y-point gap: 1/50th visible Y range
        yoffset <- -1 * yincr		# y-distance buffer
        point.ymax <- (nvec-1) * yincr
#        IM(yoffset, point.ymax, yincr)
        point.y <- yoffset - rev(seq(0, point.ymax, yincr))	# should get length = nvec!
        hist.args$ylim[1] <- yoffset - point.ymax 		# plot points BELOW x-axis
    }
    
    if (plot) {
        if (!plot2file) {
            ## do nothing
        } else if (device == "png") {
            png(imgname, imgdim[1], imgdim[2])
        } else if (device == "pdf") {
            pdf(imgname, imgdim[1]/100, imgdim[2]/100)
        }
        
        cex <- ifelse(length(cex)>0, cex, ifelse(plot2file, ifelse(device=="png", 1.2, 1), 1))
        par(cex=cex, las=1)
        
        if (!add) do.call(graphics::hist, hist.args)
        for (i in 1:nvec) { 
            lines(dens[[i]], col=col[i], lty=lty[i], lwd=lwd[i]) 
            if (points) points(vecs[[i]], rep(rev(point.y)[i], length(vecs[[i]])), pch=pch, cex=cex*0.55, col=col[i]) 
        }
        if (nvec >= 1 & !is.na(legend)) { 
            if (legend == "auto") {
                ymid <- diff(hist.args$ylim)/2 + hist.args$ylim[1]
                xmid <- diff(hist.args$xlim)/2 + hist.args$xlim[1]
                right.mass <- left.mass <- 0
                for (i in 1:nvec) {
                    xrange <- range(vecs[[i]])
                    if (!drops[i]) {
                        y <- rescale(which(dens[[i]]$y >= ymid), to=xrange, from=c(0,dens.n))   # line regions in the upper 50% of plot area -> translate to original x-values
                        right.mass <- right.mass + sum(y > xmid)
                        left.mass <- left.mass + sum(y <= xmid)
                    }
                }
#                IM(left.mass,right.mass,"|",hist.args$xlim,xmid,"|",hist.args$ylim,ymid)
                legend <- ifelse(right.mass>left.mass, "topleft", "topright")
            }
            legend(x=legend, legend=vnames, bty="n", col=col, lty=lty, lwd=lwd) 
        }

        if (plot2file) dev.off()
    }
    ## OLD SETTINGS -- give false impression of x,y consistency -- now replaced with true density() outputs
    ##hist.args$x <- allx
    ##hist.args$y <- rownameless(do.call(cbind,ally))
    if (points) hist.args$point.y <- point.y
    hist.args$density <- dens
    invisible(hist.args)
}


apa.names$plots <- c(apa.names$plots, "dotplot")
dotplot <- function(obj, legend="topright", r.names=NULL, c.names=NULL, rect.data=NULL, drop.na=TRUE, y.thresh=c(-Inf,Inf,0), col=1, pch=1, cex=1, las=par()$las, xaxt=par()$xaxt, ...) {

	## Takes a vector, matrix or dataframe and plots the rows as points.
	## "legend", if not null, specifies location of the legend.
    ## "r.names" replaces object rownames.
    ## "c.names" replaces object colnames.
#    ## "x.labs" indicates whether to use the object colnames as the x axis labels.
	## "drop.na" indicates whether to remove all-NA (incl NaN, Inf) entries from the legend.
    ## "y.thresh" prevents outlier datapoints (< y.thresh[1] or > y.thresh[2]) from affecting "ylim" calculations.
    ##   "y.thresh" also requires a third argument: 0 or 1, 0 = leave outliers alone, 1 = set outliers to NA.
	## "..." are other arguments passed to the initial plot() call, or to legend().
	##	 NOTE: if "pch" is supplied, points get plotted on the points.
	
	plot.argnames <- c("x","y","type","pch","xlim","ylim","log","main","sub","xlab","ylab","ann","axes","frame.plot","panel.first","panel.last","asp","las","xaxt","yaxt","cex")
	legend.argnames <- c("legend","fill","col","border","pch","angle","density","bty","bg","box.col","pt.bg","cex","pt.cex","pt.lwd","xjust","yjust","x.intersp","y.intersp","adj","text.width","text.col","merge","trace","plot","ncol","horiz","title","inset","xpd","title.col","text.col")
     ## legendx and legendy are also argnames, but transferred to legend.args below
    
	objname <- deparse(substitute(obj))
	if (is.nlv(obj)) { obj <- matrix(obj, nrow=1) }    # recast as matrix
    if (length(r.names)>0) { rownames(obj) <- r.names }
    if (length(c.names)>0) { colnames(obj) <- c.names }
    if (length(colnames(obj))==0) { colnames(obj) <- 1:ncol(obj) }
    if (class(obj) %in% c("matrix","data.frame")) {
        rows <- nrow(obj)
        cols <- ncol(obj)
    } else {
        stop("Object must be a numeric vector, numeric matrix, or data frame!\n")
    }
    
	if (drop.na) { 
		use.points <- which(apply(obj, 1, FUN=function(x){any(real(x,logical=TRUE))}))
		if (length(use.points)==0) { stop("No useable points with drop.na=TRUE!\n") }
	} else {
		use.points <- 1:nrow(obj)
	}
	
	other.args <- list(...)
	plot.args <- other.args[names(other.args) %in% plot.argnames]
	legend.args <- other.args[names(other.args) %in% legend.argnames]
	lost.args <- setdiff( names(other.args), c(names(plot.args), names(legend.args)) )   # par() calls wind up here
	
	if (!is.null(other.args$legendx)) { legend.args$x <- other.args$legendx }
	if (!is.null(other.args$legendy)) { legend.args$y <- other.args$legendy }
    
    if (length(col) < rows) {
        reps <- ceiling(rows / length(col))
        col <- rep(col, reps)
    }
    if (length(pch) < rows) {
        reps <- ceiling(rows / length(pch))
        pch <- rep(pch, reps)
    }
	
	if (is.null(plot.args$ylim)) {
        if (y.thresh[3] == 1) {
            obj[obj<y.thresh[1]] <- NA
            obj[obj>y.thresh[2]] <- NA
        }
        plot.args$ylim[1] <- min(real(obj[obj>y.thresh[1]]))
        plot.args$ylim[2] <- max(real(obj[obj<y.thresh[2]]))
	}
	if (is.null(plot.args$main)) { plot.args$main <- paste("Dot plot of",objname) }
	if (is.null(plot.args$xlab)) { plot.args$xlab <- objname }
	if (is.null(plot.args$ylab)) { plot.args$ylab <- "Value" }
	
	plot.args$xaxt <- "n"   # FOR INITIAL PLOTTING ONLY: does not reflect user-input 'xaxt' value
    plot.args$col <- col[1]
    plot.args$pch <- pch[1]
    plot.args$cex <- cex
    plot.args$las <- las
	plot.args$x <- 1:cols
	plot.args$y <- obj[1,]
	plot.args <- c(plot.args, lost.args)	# assuming "lost" are par() calls...
#     return(plot.args)
#     return(legend.args)

	do.call(plot, plot.args)
	if (!is.null(rect.data)) {
		rect(rect.data[1],plot.args$ylim[1],rect.data[2],plot.args$ylim[2],col=rect.data[3],border=NA)
		for (i in 1:rows) { points(1:cols, obj[i,], col=col[i], pch=pch[i], cex=cex) }
	} else {
		if (rows > 1) {
			for (i in 1:rows) { points(1:cols, obj[i,], col=col[i], pch=pch[i], cex=cex) }
		}
	}
	if (xaxt != "n") { axis(1, at=1:cols, labels=colnames(obj), las=las) }
	for (i in 1:rows) { points(1:cols, obj[i,], col=col[i], pch=pch[i], cex=cex) }
	if (rows > 1 & !is.null(legend)) { graphics::legend(x=legend, legend=rownames(obj)[use.points], bty="n", col=col[use.points], pch=pch[use.points]) } 
#	if (rows > 1 & !is.null(legend)) { do.call(legend, legend.args) } 
}


apa.names$plots <- c(apa.names$plots, "lineplot")
lineplot <- function(obj, legend="topright", r.names=NULL, c.names=NULL, trend.only=FALSE, trend.add=NULL, trend.err=NULL, rect.data=NULL, drop.na=TRUE, y.thresh=c(-Inf,Inf,0), 
                     offset=0, col=NULL, lty=1, lwd=1, pch=NULL, las=par()$las, xaxt=par()$xaxt, gaps=NULL, gap.col="white", gap.lty=1, gap.lwd=1, ...) {

    ## Takes a vector, matrix or dataframe and plots the rows as lines.
    ## "legend", if not null, specifies location of the legend.
    ## "r.names" replaces object rownames.
    ## "c.names" replaces object colnames.
    ## "trend.add", if not null, adds the specified trend line TO AN EXISTING line plot
    ## "trend.err" specified error bar types for the trendline; only works if "trend.add" is specified.
    ## "rect.data" plots a rectangle of color rect.data[3] on the whole y range, on x=rect.data[1:2].
    ## "drop.na" indicates whether to remove all-NA (incl NaN, Inf) entries from the legend.
    ## "y.thresh" prevents outlier datapoints (< y.thresh[1] or > y.thresh[2]) from affecting "ylim" calculations.
    ## "offset" shifts x-positions of the given line(s) by x (intended as a controlled jitter function).
    ## "gaps" may be a list of (start, stop) x coords indicating breaks in the plotted lines
    ## "gap.col" and "gap.lty", indicate how to draw lines in the gaps given by "gaps"
    ##   "y.thresh" also requires a third argument: 0 or 1, 0 = leave outliers alone, 1 = set outliers to NA.
    ## "..." are other arguments passed to the initial plot() call, or to legend().
    ##	 NOTE: if "pch" is supplied, points get plotted on the lines.
    
    plot.argnames <- c("x","y","type","lty","lwd","pch","xlim","ylim","log","main","sub","xlab","ylab","ann","axes","frame.plot","panel.first","panel.last","asp","las","xaxt","yaxt")
    legend.argnames <- c("legend","fill","col","border","lty","lwd","pch","angle","density","bty","bg","box.lwd","box.lty","box.col","pt.bg","cex","pt.cex","pt.lwd","xjust","yjust","x.intersp","y.intersp","adj","text.width","text.col","merge","trace","plot","ncol","horiz","title","inset","xpd","title.col","text.col")
    ## legendx and legendy are also argnames, but transferred to legend.args below
    if (!is.null(trend.add)) trend.add <- match.arg(trend.add, c("mean","median"))
    if (!is.null(trend.err)) trend.err <- match.arg(trend.err, c("se","sd","iqr"))
    
    objname <- deparse(substitute(obj))
    if (is.nlv(obj)) { 
        n <- names(obj)
        obj <- matrix(obj, nrow=1)     # recast as matrix
        colnames(obj) <- n
    }
    if (length(r.names)>0) rownames(obj) <- r.names
    if (length(c.names)>0) colnames(obj) <- c.names
    if (length(colnames(obj))==0) colnames(obj) <- 1:ncol(obj)
    if (class(obj) %in% c("matrix","data.frame")) {
        rows <- nrow(obj)
        cols <- ncol(obj)
    } else {
        stop("Object must be a numeric vector, numeric matrix, or data frame!\n")
    }
    
    if (drop.na) { 
        use.lines <- which(apply(obj, 1, FUN=function(x) any(real(x,logical=TRUE)) ))
        if (length(use.lines)==0) stop("No useable lines with drop.na=TRUE!\n")
    } else {
        use.lines <- 1:nrow(obj)
    }
    
    other.args <- list(...)
    plot.args <- other.args[names(other.args) %in% plot.argnames]
    legend.args <- other.args[names(other.args) %in% legend.argnames]
    lost.args <- setdiff( names(other.args), c(names(plot.args), names(legend.args)) )   # par() calls wind up here
    
    if (!is.null(other.args$legendx)) legend.args$x <- other.args$legendx
    if (!is.null(other.args$legendy)) legend.args$y <- other.args$legendy
    
    if (length(col)==0) {
        if (rows <= 8) {
            col <- 1:rows
        } else {
            col <- rainbow(rows)
        }
    } else if (length(col) < rows) {
        reps <- ceiling(rows / length(col))
        col <- rep(col, reps)
    }
    if (length(lty) < rows) {
        reps <- ceiling(rows / length(lty))
        lty <- rep(lty, reps)
    }
    if (length(lwd) < rows) {
        reps <- ceiling(rows / length(lwd))
        lwd <- rep(lwd, reps)
    }
    if (length(pch) < rows) {
        reps <- ceiling(rows / length(pch))
        pch <- rep(pch, reps)
    }
    
    if (is.null(plot.args$ylim)) {
        if (y.thresh[3] == 1) {
            obj[obj<y.thresh[1]] <- NA
            obj[obj>y.thresh[2]] <- NA
        }
        plot.args$ylim[1] <- min(real(obj[obj>y.thresh[1]]))
        plot.args$ylim[2] <- max(real(obj[obj<y.thresh[2]]))
    }
    if (is.null(plot.args$main)) plot.args$main <- paste("Line plot of",objname)
    if (is.null(plot.args$xlab)) plot.args$xlab <- ""
    if (is.null(plot.args$ylab)) plot.args$ylab <- "Value"
    plot.args$xaxt <- "n"   # FOR INITIAL PLOTTING ONLY: does not reflect user-input 'xaxt' value

    plot.args$col <- col[1]
    plot.args$lty <- lty[1]
    plot.args$lwd <- lwd[1]
    plot.args$pch <- pch[1]
    plot.args$las <- las
    plot.args$x <- c(1:cols)+offset
    plot.args$y <- obj[1,]
    plot.args$type <- "l"
    plot.args$frame.plot <- TRUE
    plot.args <- c(plot.args, lost.args)	# assuming "lost" are par() calls...
    if (is.null(plot.args$axes)) plot.args$axes <- TRUE
    if (is.null(plot.args$ann)) plot.args$ann <- TRUE
#     return(plot.args)
#     return(legend.args)
    
    plot.trend <- function() {
        obj[!real(obj, logical=TRUE)] <- NA
        if (trend.add == "mean") {
            trendline <- colMeans(obj, na.rm=TRUE)
        } else if (trend.add == "median") {
            trendline <- colMedians(obj, na.rm=TRUE)
        } else {
            stop("'trend.add' must be one of 'mean' or 'median'!\n")
        }
        lines(1:cols+offset, trendline, col=col, lty=lty, lwd=lwd)   # trendline
        if (!is.null(trend.err)) {
            if (trend.err == "sd") {
                errs <- colSDs(obj, na.rm=TRUE)
                err.hl <- rbind(trendline+errs, trendline-errs)
            } else if (trend.err == "se") {
                errs <- apply(obj, 2, SEM, na.rm=TRUE)
                err.hl <- rbind(trendline+errs, trendline-errs)
            } else if (trend.err == "iqr") {
                err.hl <- apply(obj, 2, FUN=function(x) quantile(x,c(0.25,0.75),na.rm=TRUE) )
            } else {
                stop("'trend.err' must be one of 'sd', 'se', or 'iqr'!\n")
            }
            for (i in 1:cols) {
                j <- i + offset
                segments(j, err.hl[1,i], j, err.hl[2,i], col=col, lty=lty, lwd=lwd)             # error bar
                segments(j-0.05, err.hl[1,i], j+0.05, err.hl[1,i], col=col, lty=lty, lwd=lwd)   # bottom crossbar
                segments(j-0.05, err.hl[2,i], j+0.05, err.hl[2,i], col=col, lty=lty, lwd=lwd)   # top crossbar
            }
        }
    }
    
    if (trend.only) {
        plot.args$col <- 0
        do.call(graphics::plot, plot.args)
        if (!is.null(rect.data)) {
            rect(rect.data[1],plot.args$ylim[1],rect.data[2],plot.args$ylim[2],col=rect.data[3],border=NA)
        }
        plot.trend()
    } else if (!is.null(trend.add)) {
        plot.trend()
    } else {
#        return(plot.args)
        do.call(graphics::plot, plot.args)
        if (!is.null(rect.data)) {
            rect(rect.data[1],plot.args$ylim[1],rect.data[2],plot.args$ylim[2],col=rect.data[3],border=NA)
            for (i in 1:rows) lines(1:cols, obj[i,], col=col[i], lty=lty[i], lwd=lwd[i])
        } else {
            if (rows > 1) {
                for (i in 1:rows) lines(1:cols+offset, obj[i,], col=col[i], lty=lty[i], lwd=lwd[i])
            }
        }
        if (length(gaps)>0) {
            for (i in 1:length(gaps)) {
                x <- gaps[[i]][1]
                y <- gaps[[i]][2]
                for (i in 1:rows) lines(x:y+offset, obj[i,x:y], col=gap.col, lty=gap.lty, lwd=gap.lwd)
            }
        }
        if (!is.null(pch)) {
            for (i in 1:rows) points(1:cols, obj[i,], col=col[i], pch=pch[i])
        }
        if (plot.args$ann & rows > 1 & !is.null(legend)) { 
            if (length(rownames(obj)[use.lines])>0) {
                graphics::legend(x=legend, legend=rownames(obj)[use.lines], bty="n", col=col[use.lines], lty=lty[use.lines], lwd=lwd[use.lines], pch=pch[use.lines]) 
            }
        } 
#	if (rows > 1 & !is.null(legend)) { do.call(legend, legend.args) } 
    }
    if (plot.args$axes & xaxt != "n") axis(1, at=1:cols, labels=colnames(obj), las=las)
}


apa.names$plots <- c(apa.names$plots, "ribbon.plot")
ribbon.plot <- function(x, fill=NULL, border=NULL, main=NULL, lty=1, lwd=1, line.col=1, names.arg=NULL, names.y=0.5, height="100%", shapes=NULL) {
	
	## takes "x", 4-col data.frame (group, start, stop, name).
	## returns a line spanning min(starts):max(stops) connecting a series of boxes, one for each start/stop pair.
	## boxes can be altered by "fill" = fill color(s), "border" = border color(s), "shapes" = primitive shape name(s) to use instead of rectangles.
	## names will be plotted is present; can override names with "names.arg".  "names.y" ranges from 0 (print below box) to 1 (print above box).
	## base line connecting boxes affected by line.col, lty, lwd.
	## "height.pct" is the height of plotted boxes.  If numeric, that # pixels.  If character and ends with "%", treated as percent of line length.
	
	#####  SHAPES ARGUMENT NOT YET READY  #####
	
#	if (ncol(x)==1) stop("'x' must be have >= 2 columns!\n")
#	if (is.matrix(x)) {
#		if (ncol(x)>2) stop("'x' must be 2 columns if matrix!\n")
#		xnames <- rownames(x)
#	}
	if (is.data.frame(x)) {
		if (ncol(x)!=4) stop("'x' must be 4 columns if data.frame!\n")
		xnames <- x[,4]
	}
	if (length(xnames)==0 || all(x=="")) xnames <- names.arg
	
	groups <- unique(x[,1])
	N <- length(groups)
	unit.coords <- t(sapply(groups, function(g){ y=x[x[,1]==g,]; c(Start=min(y[,2]),End=max(y[,3])) }))
	IM(dim(unit.coords))
	total.coords <- c(1, max(unit.coords[,2]-unit.coords[,1]+1))
	
	total.height <- 2*N
	unit.height <- ifelse(is.numeric(height), height, as.numeric(sub("%$","",height))/100)
	pct.height <- ifelse(is.numeric(height), FALSE, TRUE)
	
	null.plot(xlim=total.coords, ylim=c(0,total.height), main=main)
	
	rev.N <- N:1
	for (i in 1:N) {
		set <- x[x[,1]==i,]
		start <- min(set[,2])
		end <- max(set[,3])
		y.max <- rev.N[i]
		segments(start,y.max-0.45, end,y.max-0.45, lty=lty, lwd=lwd, col=line.col)  # base line
		for (j in 2:nrow(set)) {  # for the moment, record 1 is always the full-region-length record
			col.n <- ifelse(j%%length(fill)==0, length(fill), j%%length(fill))
			bord.n <- ifelse(j%%length(border)==0, length(border), j%%length(border))
			rect(set[j,2],y.max, set[j,3],y.max-0.9, col=fill[col.n], border=border[bord.n])
		}
	}
	
	
}


apa.names$clustering <- c(apa.names$clustering, "cluster.lineplots")
cluster.lineplots <- function(obj, map=NULL, cnames=NULL, col=1, trend.only=FALSE, ablines=NULL, map.ord=NULL, trend.line="mean", trend.err="sd", trend.col="red", 
	trend.lwd=2, y.thresh=c(-Inf,Inf,0), wide=FALSE, cex=par()$cex, layout=NULL, templates=NULL, temp.col=4, temp.lwd=2, ...) {
	
	# takes object(s) and makes a line plot for each cluster.  Input is either:
	#  1. obj=matrix/df; map=integer cluster mapping vector. (will call: split(obj, map))
	#  2. obj=list of matrices/dfs, one per cluster; map=NULL.
	
	if (length(map)==0) {
		if (is.ndfl(obj)) {
			N <- length(obj)
			clusters <- obj
		} else {
			stop("If 'map' is NULL, 'obj' must be a list of matrices/dfs per cluster!\n")
		}
		if (length(cnames)==0) cnames <- 1:N
	} else {
		good <- !is.na(map)
		map <- map[good]
		obj <- obj[good,]
		if (length(rownames(obj))==0) rownames(obj) <- 1:nrow(obj)
		N <- luniq(map)
		temp <- split(rownames(obj), map)
		if (length(map.ord)>0) {
			if (length(map.ord)==N) {
				temp <- temp[match(map.ord,names(temp))]
			} else {
				warning("map.ord is not 1:1 with unique map names!\n")
				temp <- temp[match(map.ord,names(temp))]
#				IM(length(temp), ":", match(map.ord,names(temp)))
			}
		}
		if (length(cnames)==0) cnames <- names(temp)
		clusters <- new.list(cnames)
		for (i in 1:N) {
			if (length(temp[[i]])>0) clusters[[i]] <- obj[match(temp[[i]],rownames(obj)),]
		}
	}
#	clusters <- clusters[listLengths(clusters)>0]
#	IM(N,":",listLengths(clusters,"nrow"))
	N <- length(clusters)
	
	plot.argnames <- c("x","y","type","pch","lty","lwd","xlim","ylim","log","main","sub","xlab","ylab","ann","axes","frame.plot","panel.first","panel.last","asp","las","xaxt","yaxt")
	other.args <- list(...)
	plot.args <- other.args[names(other.args) %in% plot.argnames]
	if ("ylim" %in% names(plot.args)) {
		ylim <- plot.args$ylim
	} else {
		ylim <- range(obj)
		plot.args$ylim <- ylim
	}
	
	do.templates <- FALSE
	if (length(templates)>0) {
		do.templates <- TRUE
		templates[templates==0] <- ylim[1]
		templates[templates==1] <- ylim[2]
		ntemplates <- translate(templates,ylim,rev(ylim))
	}
	if (length(layout)==0) layout <- MA.scatter.plotdim(N, wide=wide)   # irows icols iheight iwidth
#	IM(layout)
	
	par(mfrow=layout[1:2], cex=cex)
	for (i in 1:N) {
		nrc <- ifelse(!is.null(nrow(clusters[[i]])), nrow(clusters[[i]]), ifelse(length(clusters[[i]])>0, 1, 0))   # matrix or df, ELSE non-list vector, ELSE empty df or 0x0-matrix
		genes <- ifelse(nrc==1, "gene", "genes")
		title <- ifelse( cnames[i]==i, paste("Cluster ",i,": ",nrc," ",genes,sep=""), paste("Cluster '",cnames[i],"': ",nrc," ",genes,sep="") )
		IM(i, length(clusters), nrc)
		if (nrc>0) {
			if (trend.only) {
				do.call(lineplot, c(list(obj=clusters[[i]], c.names=colnames(clusters[[i]]), xlab="", trend.only=TRUE, trend.add=trend.line, trend.err=trend.err, legend=NULL, main=title, col=col), plot.args)) 
#				lineplot(clusters[[i]], c.names=colnames(clusters[[i]]), las=las, xlab="", trend.only=TRUE, legend=NULL, main=title) 
#				lineplot(clusters[[i]], trend.add=trend.line, trend.err=trend.err, col=trend.col, lwd=trend.lwd)
			} else {
				do.call(lineplot, c(list(obj=clusters[[i]], c.names=colnames(clusters[[i]]), xlab="", legend=NULL, main=title, col=col), plot.args)) 
#				lineplot(clusters[[i]], c.names=colnames(clusters[[i]]), las=las, xlab="", col=col, legend=NULL, main=title) 
				lineplot(clusters[[i]], trend.add=trend.line, trend.err=trend.err, col=trend.col, lwd=trend.lwd, xaxt="n")
			}
			if (length(ablines)>0) {
				if (length(ablines$h)>0) abline(h=ablines$h[[1]], col=ablines$h[[2]], lty=ablines$h[[3]], lwd=ablines$h[[4]])
				if (length(ablines$v)>0) abline(v=ablines$v[[1]], col=ablines$v[[2]], lty=ablines$v[[3]], lwd=ablines$v[[4]])
			}
		} else {
			null.plot(main=title)
		}
		if (do.templates) {
			j <- map.ord[i]
			if (j < 0) {
				lines(1:ncol(obj), ntemplates[-j,], col=temp.col, lwd=temp.lwd)
			} else {
				lines(1:ncol(obj), templates[j,], col=temp.col, lwd=temp.lwd)
			}
		}
	}
	invisible(plot.args)
}


apa.names$clustering <- c(apa.names$clustering, "kmeans.plots")
kmeans.plots <- function(x, map, func=mean, cex=1, col.bars=NULL, pal.hm=NULL, hm.ord=NULL) {
    
    ## takes clustered object 'x' and a kmeans clustering vector 'map'
    ## plots the cluster trend lineplots and the cluster size barplots
    ## trend is determined by the function passed to 'func', e.g. mean, median, etc.
    ## 'cex' and 'col are as usual
    ## 'troubleshoot' causes the legend-position function to plot the spatial map, separately, in case the legend seems out of place
    ## 'hm.ord' allows an existing cluster order to be applied to this map, e.g. from some other kmeans.plots image.
    ##  - Such an ordering may not be appropriate for given heatmap, and no compatibility checks are made, caveat emptor.
    ##  - A correctly-formatted hm.ord value is also the invisible output of this function, inspect this object for details.
    
    mm <- max(map)
    umap <- 1:mm
    names(umap) <- umap
    
    trends <- t(sapply(umap, function(i) apply(zerofy(x[map==i,,drop=FALSE]),2,func) ))
    lpos <- legend.position(cbind(x=rep(1:ncol(trends),each=nrow(trends)),y=c(trends)))
    nc <- ncol(x)
    nc.1 <- max(c(1,round(nc/10,0)))
    xr <- range(real(c(x)))
    
    if (length(hm.ord)>0) {
        trend.ord <- hm.ord$trend.ord
        clust.ord <- hm.ord$clust.ord
    } else {
        trend.ord <- reorder.hclust2(hclust(dist(trends),"average"), trends, sum)$order
        clust.ord <- lapply(sort(trend.ord), function(i) {
            w <- which(map==i)
            w[hclust(dist(zerofy(x[w,,drop=FALSE])),"average")$order]
        })
#        xco <- do.call(rbind, lapply(trend.ord, function(i) {
#            y=x[map==i,,drop=FALSE]
#            cbind(
#                y[hclust(dist(zerofy(y)),"average")$order,,drop=FALSE],
#                colrep(rep(i,nrow(y)),nc.1)
#            )
#        }))
        hm.ord <- list(trend.ord=trend.ord,clust.ord=clust.ord)
    }
    
    xco <- do.call(rbind, lapply(trend.ord, function(i) {
        y <- x[clust.ord[[i]],,drop=FALSE]
        cbind(y, colrep(rep(i,nrow(y)),nc.1))
    }))
    trends2 <- trends[,colSums(is.na(trends))==0]
    xlab <- paste("Mean Scaled Euc Dist:",round(mean(dist(trends2))/diff(range(trends2)),3))
    
    par(mfrow=c(1,3), las=1, cex=cex)
    
    if (length(col.bars)==0) col.bars <- ternary(mm<=8, 1:mm, rainbow(mm))
    lineplot(trends, col=col.bars, main="Cluster Trends", xlab=xlab, legend=lpos)
    barplot(table(map), col=col.bars, main="Cluster Sizes")
    
    if (any(xr>0) & any(xr<0)) {
        if (length(pal.hm)==0) pal.hm <- "RWB"
        mipu(xco, pal=pal.hm, col.center=0, att.col=(nc+1):ncol(xco), att.pal=col.bars, show.scale=FALSE, main="Cluster Heatmap")
    } else if (all(xr>=0)) {
        if (length(pal.hm)==0) pal.hm <- "Reds0"
        mipu(xco, pal=pal.hm, att.col=(nc+1):ncol(xco), att.pal=col.bars, show.scale=FALSE, main="Cluster Heatmap")
    } else if (all(xr<=0)) {
        if (length(pal.hm)==0) pal.hm <- "Blues0"
        mipu(xco, pal=pal.hm, rev.pal=TRUE, att.col=(nc+1):ncol(xco), att.pal=col.bars, show.scale=FALSE, main="Cluster Heatmap")
    } else {
        message(paste("Failed to identify data range!",xr,"\n"))
    }
    
    invisible(list(trends=trends,hm.ord=hm.ord))
}


apa.names$clustering <- c(apa.names$clustering, "compare.cluster.trends")
compare.cluster.trends <- function(maps, mats, cols=NULL, wide=TRUE, fun="mean", las=1, cex=1, lty=1, lwd=1, xlab="", ylab="", layout=NULL) {
	
	# plot trendlines of same-numbered clusters together (e.g. all cluster "1" trendlines plotted in same plot, all "2" trendlines on next plot, etc.).
	# "mats" is a list of matrices that were clustered.
	# "maps" is a list of cluster mappings, same respective order as "mats".
	# *** It is advised to run translate() on maps 2-N, to make their clustering numbers match the respective numbers from cluster 1.  
	#     That way all clusters with same numbers have same trends too.
	# Results are a multi-plot with one sub-plot per cluster number.
	# "cols" specifies colors per mapping (default 1:N; colors recycle if N > 8).
	# "wide" specifies that plot layout, if non-square, prefers wider layout (as opposed to taller).  Actual nrow, ncol from MA.scatter.plotdim().
	# "fun" specifies to take cluster trend by this function (so column mean, median, etc)
	
	N <- length(mats)
	if (length(maps) != N) stop("'mats' and 'maps' must have same length!\n")
	M <- max(sapply(maps,luniq))
	if (length(layout)==0) layout <- MA.scatter.plotdim(M, wide=wide)   # irows icols iheight iwidth
	if (length(cols)==0) cols <- 1:N
	
	par(mfrow=layout[1:2], cex=cex, las=las)
	for (m in 1:M) {  # clusters
		legx <- ifelse(m == 1, "topright", NA)
		x <- do.call(rbind, lapply(1:N, function(i){ apply(mats[[i]][maps[[i]]==m,], 2, fun) }))
		dimnames(x) <- list(names(mats), colnames(mats[[1]]))
		lineplot(x, legend=legx, lty=lty, lwd=lwd, col=cols, xlab=xlab, ylab=ylab, main=paste("Cluster",m))
	}
}


apa.names$general <- c(apa.names$general, "barplot.shuffle")
barplot.shuffle <- function(mat, cols, plot=FALSE, legend="topright", ...) {
	
	col.mat <- colrep(cols, ncol(mat))
	for (i in 1:ncol(mat)) {
		x <- order(mat[,i], decreasing=TRUE)
		mat[,i] <- mat[x,i]
		col.mat[,i] <- col.mat[x,i]
	}
	factors <- rownames(mat)
	
	if (plot) {
		bp.args <- list(...)
		bp.args$height <- mat[1,]
		bp.args$col <- col.mat[1,]
		bp.args$names <- colnames(mat)
		bp.args$beside <- TRUE
		do.call(barplot, bp.args)
		
		bp.args$names <- NA
		bp.args$add <- TRUE
		bp.args$xaxt <- "n"
		bp.args$yaxt <- "n"

		for (i in 2:nrow(mat)) {
			bp.args$height <- mat[i,]
			bp.args$col <- col.mat[i,]
			do.call(barplot, bp.args)
		}
		legend(legend, bty="n", col=cols, pch=15, cex=1.5, legend=factors)
	}
	
	mat <- rownameless(mat)  # rownames no longer meaningful
	invisible(list(mat=mat, cols=col.mat))
}


apa.names$general <- c(apa.names$general, "MA.scatter.plotdim")
MA.scatter.plotdim <- function(N, pixels=500, cap.dim=NA, square=FALSE, wide=TRUE) {
	
	## Determines plot rows, columns, and dimensions based on the number of plots (N), pixels per axis, and the square flag (square).
	## 'pixels' gives the external plot device (png, jpg) pixels per axis, so 'pixels=500' allocates 500x500 per plot.
	## 'square=T' fits the data to the nearest MxM plot layout.
	## 'wide=T' makes the plot layout wider than high
	
	if (square) {
		Q <- sqrt(N)
		if (Q == trunc(Q)) { 	# N == Q^2
			irows <- icols <- Q
		} else {
			irows <- icols <- ceiling(Q)
		}
	} else {
		## Determine plot dimensions -- calculable for N up to 101^2-1.
		## if cap.dim specified: if wide=T, max nrow=cap.dim and ncol will float; if wide=F, transpose the situation
		if (N > 101^2-1) { stop("MA.scatter.plotdim cannot process a panel count exceeding 101^2-1.\n") }
		squares <- c(1:100)^2   # here we assume that no-one will try to get an automated layout for > 101^2-1 panels...
		irows <- rev(which(squares-N<=0))[1]  # this is the nearest integer whose square is <= N (thus N can be up to 101^2-1 and still return irows=100)
		if (!is.na(cap.dim)) {
			if (irows > cap.dim) irows <- cap.dim
		}
		icols <- ceiling(N/irows)
	}
	
	if (wide) {
		x <- c(irows, icols, irows*pixels, icols*pixels)  # wide=T by default
	} else {
		x <- c(icols, irows, icols*pixels, irows*pixels)  # transpose
	}
	names(x) <- c("irows","icols","iheight","iwidth")
	return(x)
}


apa.names$plots <- c(apa.names$plots, "legend.position")
legend.position <- function(m, plot=FALSE) {
    
    ## give a matrix of values that will be plotted
    ## returns lowest density position for legend (of the named positions)
    
    thirds <- as.data.frame(apply(m,2,function(x) min(x,na.rm=TRUE)+diff(range(x,na.rm=TRUE))*c(1/3,2/3) ))
    colnames(thirds) <- c("x","y")
    ## Tile Positions:
    ## 1 2 3
    ## 4 5 6
    ## 7 8 9
    td <- c(  # tile densities
        T1=sum( falsify(m[,1]<thirds$x[1])                              & falsify(m[,2]>thirds$y[2])                              ),
        T2=sum( falsify(m[,1]>thirds$x[1]) & falsify(m[,1]<thirds$x[2]) & falsify(m[,2]>thirds$y[2])                              ),
        T3=sum( falsify(m[,1]>thirds$x[2])                              & falsify(m[,2]>thirds$y[2])                              ),
        T4=sum( falsify(m[,1]<thirds$x[1])                              & falsify(m[,2]>thirds$y[1]) & falsify(m[,2]<thirds$y[2]) ),
        T5=sum( falsify(m[,1]>thirds$x[1]) & falsify(m[,1]<thirds$x[2]) & falsify(m[,2]>thirds$y[1]) & falsify(m[,2]<thirds$y[2]) ),
        T6=sum( falsify(m[,1]>thirds$x[2])                              & falsify(m[,2]>thirds$y[1]) & falsify(m[,2]<thirds$y[2]) ),
        T7=sum( falsify(m[,1]<thirds$x[1])                              & falsify(m[,2]<thirds$y[1])                              ),
        T8=sum( falsify(m[,1]>thirds$x[1]) & falsify(m[,1]<thirds$x[2]) & falsify(m[,2]<thirds$y[1])                              ),
        T9=sum( falsify(m[,1]>thirds$x[2])                              & falsify(m[,2]<thirds$y[1])                              )
    )
    ## troubleshooting plot
    if (plot) {
        tmids <- apply(thirds, 2, function(x){ d=abs(diff(x)); c(x[2]+d/2,mean(x),x[1]-d/2) })
        tmids <- cbind(rep(rev(tmids[,1]),3),rep(tmids[,2],each=3))
        dev.new(); plot(m); abline(h=thirds$y,v=thirds$x); for (i in 1:9) text(tmids[i,1], tmids[i,2], td[i], font=2, col=2)
    }
    
    switch(
        names(td)[which.min(td)],
        "T1"="topleft",
        "T2"="top",
        "T3"="topright",
        "T4"="left",
        "T5"="center",
        "T6"="right",
        "T7"="bottomleft",
        "T8"="bottom",
        "T9"="bottomleft"
    )
}


apa.names$microarray <- c(apa.names$microarray, "MA.scatter.decorate")
MA.scatter.decorate <- function(pars) {
	
	### Function for adding fold-change lines, fold-change color bands, correlation/regression values, etc. to scatter and MA plots
	### 'pars' is a parameters list with named elements; see unpacking list below ...
	### DO NOT use any variable names that are being imported!!! 
	
	## unpack variables	(code is much easier to read without all the "pars$" prefixes...)
	x <- pars$x    # x plot-data vector
	y <- pars$y    # y plot-data vector
	i <- pars$i    # plot instance
	j <- pars$j    # comparison sample 1 (if any)
	k <- pars$k    # comparison sample 2 (if any)
	foldcolor <- pars$foldcolor
	smooth <- pars$smooth
	fc.lines <- pars$fc.lines
	fc.stdev <- pars$fc.stdev
	slope <- pars$slope
	regress <- pars$regress
	pch <- pars$pch
	cdat <- pars$cdat
	sat.mat <- pars$sat.mat
	sat.cols <- pars$sat.cols
    plot <- pars$plot
    sigs <- pars$sigs
	
	## Plot fold-change color bands, if indicated
	ok <- intersect( which(!is.na(x)), which(!is.na(y)) )
	if (foldcolor & !smooth) {	# fold-coloring not possible with smoothScatter!
		foldcols <- c(1,4,3,2,5,6,7)	# supports differential coloring up to logFC=6
		fold.sets <- fc.sets(x, y, max(fc.lines), slope)
		fold.pcts <- rep(0, length(fold.sets))
		for (f in 1:length(fold.sets)) { 
			points(x[fold.sets[[f]]], y[fold.sets[[f]]], pch=pch, col=foldcols[f]) 
			fold.pcts[f] <- round(100 * length(fold.sets[[f]]) / length(ok), 1)
		}
		fcl.col <- 8
	} else {
		fcl.col <- 2
          if (plot == "MA") {      # NOT plotting significant points if fold-coloring is applied...
               if (!is.null(sigs)) {
                    up <- intersect(sigs, which(y > 0))
                    dn <- intersect(sigs, which(y < 0))
                    if (length(up > 0)) { points(x[up], y[up], pch=pch, col=2) }
                    if (length(dn > 0)) { points(x[dn], y[dn], pch=pch, col=3) }
               }
          }
	}
	
	if (!is.null(sat.mat)) {
		if (mode(sat.mat) == "character") {		# RG data
			sat.x <- which(sat.mat[cdat$nonCtl,j] == type)
			sat.y <- which(sat.mat[cdat$nonCtl,k] == type)
			points(x[sat.x], y[sat.x], col=sat.cols[1], pch=pch)
			points(x[sat.y], y[sat.y], col=sat.cols[2], pch=pch)
			sltext <- c( paste(length(sat.x),"saturated (x)"), paste(length(sat.y),"saturated (y)") )
		} else if (mode(sat.mat) == "numeric") {	# MA/fit data
			sat.hi <- which(sat.mat[cdat$nonCtl,i] >= 0.5)
			sat.lo <- which(sat.mat[cdat$nonCtl,i] < 0.5)
			points(x[sat.hi], y[sat.hi], col=sat.cols[1], pch=pch)
			points(x[sat.lo], y[sat.lo], col=sat.cols[2], pch=pch)
			sltext <- c( paste(length(sat.x),">= 50% saturated"), paste(length(sat.y),"< 50% saturated") )
		}
	}
	
	## Plot fold-change lines, if indicated
	ternary (regress, reg.vecs <- list(x,y), reg.vecs <- NULL)
	if (!is.null(fc.lines)) { plot.fc.lines(fc.lines, reg.vecs=reg.vecs, slope=slope, stdev=fc.stdev, col=fcl.col, lty=2, lwd=1, col.diag=fcl.col, lty.diag=1, lwd.diag=1, col.reg=6, lty.reg=3, lwd.reg=1) }
	abline(0, slope, col=fcl.col)
	
	## Plot legends OVER ablines...
	if (foldcolor & !smooth) { legend(x="bottomright", bty="n", text.col=foldcols, legend=paste(fold.pcts,"%",sep="")) }
	if (!is.null(sat.mat)) { legend(x="bottom", bty="n", pch=pch, col=sat.cols, legend=sltext) }
	## Plot R value
	if (plot == "scatter") {
		tcol <- tcex <- 1
		if (smooth) { tcol <- "white"; tcex <- 1.2 }
		legend( x="topleft", bty="n", cex=tcex, text.col=tcol, legend=paste("R =",signif(cor(x[ok], y[ok], method="pearson"),3)) )
		if (!is.null(sigs)) { legend( x="topright", bty="n", cex=tcex, text.col=tcol, legend=paste("Sig DE =",length(sigs)) ) }
	} else if (plot == "MA") {
		tcol <- tcex <- 1
		if (smooth) { tcol <- "white"; tcex <- 1.2 }
          R <- 2^(x + y/2)
          G <- 2^(x - y/2)
		legend( x="topleft", bty="n", cex=tcex, text.col=tcol, legend=paste("R =",signif(cor(R[ok], G[ok], method="pearson"),3)) )
		if (!is.null(sigs)) { legend( x="topright", bty="n", cex=tcex, text.col=tcol, legend=paste("Sig DE =",length(sigs)) ) }
     }
}


apa.names$microarray <- c(apa.names$microarray, "MA.scatter.plot")
MA.scatter.plot <- function(obj, type, plot, IDcol=NULL, smooth=FALSE, fc.lines=c(-2:2), foldcolor=FALSE, monoscale=FALSE, significants=NULL, compares=NULL, names=NULL, arrayID=NULL, plot.ctls="yes", regress=FALSE, filename=NULL) {
	
	## 'arrayID', if supplied, must be an array ID from the library file "S:/Genomics/Molbio_Users/APA/R_Things/microarray_library.R"
	
	#### Check if 'obj', 'type', 'plot' are valid 
	
	match.arg(plot, c("MA", "scatter"))
	if (!is.null(type)) { match.arg(type, c("M","A","R","G")) }
    sigstop <- FALSE
	
     #### Check if 'obj' is valid; if so, set some values and create either 'mat' or 'MA.obj' objects
	
	if (is.matrix(obj) & mode(obj) == "numeric") {
        if (!is.null(significants)) { 
            if (!is.logical(significants)) { sigstop <- TRUE } 
            if (all(dim(significants) != dim(obj))) { sigstop <- TRUE } 
        }
		IDs <- rownames(obj)
		if (is.null(IDs)) { cat("Since rownames are not probe IDs, controls will not be identifiable.\n"); flush.console() }
		if (plot == "MA") {
			if (ncol(obj) == 2) { 
				MA.obj <- list(M=obj[,1], A=obj[,2])
			} else {
				stop ("Numeric matrix input for MA plot must have ncol=2 only!\n") 
			}
		} else {
			## n-column matrix with no ID: 'compares' will be used if given; otherwise all-by-all scatterplot matrix
            mat <- obj
		}
		rows <- nrow(obj)
	} else {
		if (is(obj, "MAList")) {
            if (!is.null(significants)) { 
                if (all(dim(significants) != dim(obj$M))) { sigstop <- TRUE } 
            }
			if (plot == "scatter") {
				mat <- switch(type, M=obj$M, A=obj$A)
				msg <- paste("Cannot extract matrix of type '",type,"' from an object of class 'MAList'!\n",sep="")
				if (is.null(mat)) { stop(msg) }
			} else if (plot == "MA") {
				MA.obj <- obj
			}
			rows <- nrow(obj$M)
		} else if (is(obj, "RGList")) {
            if (!is.null(significants)) { 
                if (all(dim(significants) != dim(obj$R))) { sigstop <- TRUE } 
            }
			if (plot == "scatter") {
				mat <- switch(type, R=log2(obj$R), G=log2(obj$G))
				msg <- paste("Cannot extract matrix of type '",type,"' from an object of class 'RGList'!\n",sep="")
				if (is.null(mat)) { stop(msg) }
			} else if (plot == "MA") {
				stop("Objects of class 'RGList' cannot be used for MA plots!\n")
			}
			rows <- nrow(obj$R)
		} else if (is(obj, "MArrayLM")) {
            if (!is.null(significants)) { 
                if (all(dim(significants) != dim(obj$coefficients))) { sigstop <- TRUE } 
            }
			if (plot == "scatter") {
				ternary (type == "M", mat <- obj$coefficients, stop("Class MArrayLM allows MA plots and M scatters only!\n"))
				type <- "Limma"
			} else if (plot == "MA") {
				ternary ("Ameans" %in% names(obj), Ameans <- cbind(obj$Amean,obj$Amean,obj$Amean), Ameans <- obj$Ameans)
				MA.obj <- list(M=obj$coefficients, A=Ameans)
			}
			rows <- nrow(obj$coefficients)
		} else { 
			stop("Object must be a numeric matrix, or of classes MAList, RGList, or MArrayLM!\n")
		}
		
		if (!is.null(IDcol)) {
			IDs <- obj$genes[,IDcol]	# custom column
		} else {
			IDs <- obj$genes$ProbeName	# AFE
			if (length(IDs) == 0) { IDs <- obj$genes$ID }	# GPR
			if (length(IDs) == 0) { stop("Cannot locate gene identifiers!\n") }	# toast
		}
	}
     if (sigstop) { stop("If specified, 'significants' must be a logical matrix of the same dimension as 'obj'!\n") }
	
	#### Other validity checks
	
	if (foldcolor & is.null(fc.lines)) { 
		IM("'foldcolor' requires 'fc.lines' to be defined!\n")
		foldcolor <- FALSE
	}
	if (is.null(plot.ctls) | plot.ctls == "no") {
		plot.ctls <- "no"	# in case null
		ctl.plot <- FALSE
		pcol <- 1
	} else if (plot.ctls == "yes") {
		ctl.plot <- TRUE
		pcol <- 1
	} else if (plot.ctls == "only") {
		ctl.plot <- TRUE
		pcol <- 0
		if (smooth) {
			IM("Warning: 'smooth' cannot be used for control-only plots!  Ignoring.\n")
			smooth <- FALSE
		}
	} else {
		IM("Unknown value for 'plot.ctls'!  Must be 'yes', 'no', or 'only': defaulting to 'no'\n")
		plot.ctls <- "no"
		ctl.plot <- FALSE
		pcol <- 1
	}
	
	#### Initialize default params for plot styles, identify any saturation, and get any controls
	
	if (smooth) {
		ss.ramp <- colorRampPalette(c(4, terrain.colors(7)[1:5], "white"), interp="spline")	# "avocado plot"
		ss.band <- 0.25
		ss.nbin <- 128
		ss.pch <- pch <- "."
          sat.cols <- NULL
	} else {
		pch <- 4	# or "x"	# MAKE SURE these do not overlap with defined control pchs in parse.controls()!
		sat.cols <- c("cyan","cyan3")	# MAKE SURE these do not overlap with defined control colors in parse.controls()!
	}
		
	if (is(obj, "RGList")) {
		sat.mat <- get.saturation(obj)
	} else if ("saturation.pct" %in% names(obj)) {
		sat.mat <- obj$saturation.pct
	} else {
		sat.mat <- NULL
	}
	
	#### Figure out if controls are being plotted (or anything else)
	
	cdat <- NULL
	if (ctl.plot) {		# plot controls
		if (plot.ctls == "only") {	# plot ONLY controls
			if (is.null(arrayID)) {		# no controls to plot
				stop("Nothing to plot: cannot get controls without 'arrayID' value!\n")
			} else {			# may have controls...
				cdat <- parse.controls(IDs, arrayID)
				if (length(cdat$allCtl) == 0) {	# no controls after all
					stop(paste("Nothing to plot: no controls for arrayID",arrayID,"have been annotated in the microarray library file!\n"))
				} else { 			# we have controls
					scalerows <- rowset <- cdat$allCtl
				}
			}
		} else {			# plot controls and everything else
			if (is.null(arrayID)) {		# no controls to plot
				ctl.plot <- FALSE
				scalerows <- rowset <- 1:rows
			} else {			# may have controls...
				cdat <- parse.controls(IDs, arrayID)
				if (length(cdat$allCtl) == 0) {	# no controls after all
					scalerows <- rowset <- 1:rows
				} else {			# we have controls
					scalerows <- 1:rows
					rowset <- cdat$nonCtl
				}
			}
		}
	} else {		# do not plot controls
		if (is.null(arrayID)) {		# but we don't even know what the controls are...
			IM(paste("No arrayID specified: controls cannot be removed.\n"))
			scalerows <- rowset <- 1:rows
		} else {			# may have controls...
			cdat <- parse.controls(IDs, arrayID)
			if (length(cdat$allCtl) == 0) {	# no controls after all
				scalerows <- rowset <- 1:rows
			} else {			# we have controls
				scalerows <- rowset <- cdat$nonCtl
			}
		}
	}
	
	#### Further object prep; set plot x/ylims, layout & image dimensions; arrange 'compares' list if necessary
	if (plot == "MA") {
		
		slope <- 0
		if (ctl.plot) {
			if (cdat$arrayDef$Provider == "Agilent" & cdat$arrayDef$Assay == "expr") {		# redefine smooth plot params if MAplot + Agilent + spikes
				greyscale <- c("#F7F7F7","#CCCCCC","#969696","#636363","#252525","#000000")	# equivalent of c(brewer.pal(5,"Greys"),1)
				ramp <- colorRampPalette(greyscale)
			}
		}
		if (monoscale) {
			xmin <- min(MA.obj$A[scalerows,], na.rm=TRUE)
			xmax <- max(MA.obj$A[scalerows,], na.rm=TRUE)
			ymin <- min(MA.obj$M[scalerows,], na.rm=TRUE)
			ymax <- max(MA.obj$M[scalerows,], na.rm=TRUE)
		}
		dims <- MA.scatter.plotdim(ncol(MA.obj$M))
		
	} else if (plot == "scatter") {
		
		slope <- 1
		if (monoscale) {  
			xmin <- ymin <- min(mat[scalerows,], na.rm=TRUE)
			xmax <- ymax <- max(mat[scalerows,], na.rm=TRUE)
		}
		if (is.null(compares)) {
			## convert 'compares' into an all-by-all comparison list
			compares <- vector("list", length=ncol(mat)^2)
			k <- 0
			for (i in 1:ncol(mat)) {
				for (j in 1:ncol(mat)) {
					k <- k + 1
					compares[[k]] <- c(i,j)
				}
			}
			
			lcomp <- length(compares)
#			dims <- MA.scatter.plotdim(ncol(mat), square=TRUE)
			dims <- c(ncol(mat), ncol(mat), 500*ncol(mat), 500*ncol(mat))
		} else if (is.list(compares)) {
			lcomp <- length(compares)
			dims <- MA.scatter.plotdim(lcomp)
		} else {
			stop("'compares' must be a list, if specified!\n")
		}
		
		## Check directions of comparisons
		dirs <- compares
		for (i in 1:lcomp) { 
			ternary( type == "A", dirs[[i]] <- c(1,1), dirs[[i]] <- sign(compares[[i]]) ) # A-values immune to dyeswaps
			compares[[i]] <- abs(compares[[i]])	# after sign capture, remove sign
		}
	}
	
	#### Set image and plot layout dimensions; open png device if filename given
	
	irows <- dims[1]
	icols <- dims[2]
	iheight <- dims[3]
	iwidth <- dims[4]
	
	if (!is.null(filename)) { 
		png(filename, height=iheight, width=iwidth) 
		par(mfrow=c(irows, icols), cex=1.2)
	} else {
		par(mfrow=c(irows, icols))
	}
	
	decorate.pars <- list(foldcolor=foldcolor, smooth=smooth, fc.lines=fc.lines, slope=slope, regress=regress, pch=pch, cdat=cdat, sat.mat=sat.mat, sat.cols=sat.cols, plot=plot)
	do.decorate <- TRUE
     
	#### Do the actual plotting

	if (plot == "MA") {
		for (i in 1:ncol(MA.obj$M)) {
			
			x <- MA.obj$A[rowset,i]
			y <- MA.obj$M[rowset,i]
			
			if (!monoscale) {  
				xmin <- min(x[scalerows], na.rm=TRUE)
				xmax <- max(x[scalerows], na.rm=TRUE)
				ymin <- min(y[scalerows], na.rm=TRUE)
				ymax <- max(y[scalerows], na.rm=TRUE)
			}
            
			if (smooth) {
				smoothScatter2(x, y, nbin=ss.nbin, bandwidth=ss.band, pch=ss.pch, colramp=ss.ramp, xlim=c(xmin,xmax), ylim=c(ymin,ymax), ylab="M", xlab="A", main=colnames(MA.obj$M)[i]) 
                    do.decorate=FALSE
			} else {
				plot(x, y, pch=pch, col=pcol, xlim=c(xmin,xmax), ylim=c(ymin,ymax), ylab="M", xlab="A", main=colnames(MA.obj$M)[i]) 
			}
			
			if (ctl.plot) {
				if (length(cdat$ctlSets) > 0) {
					for (j in 1:(length(cdat$ctlSets))) { 
						points(MA.obj$A[cdat$ctlSets[[j]],i], MA.obj$M[cdat$ctlSets[[j]],i], pch=cdat$ctlAtt$pch[j], col=cdat$ctlAtt$col[j])
					}
				}
				if (length(cdat$spikeSets) > 0) {
					for (j in 1:length(cdat$spikeSets)) { 
						points(MA.obj$A[cdat$spikeSets[[j]],i], MA.obj$M[cdat$spikeSets[[j]],i], pch=cdat$spikeAtt$pch[j], col=cdat$spikeAtt$col[j])
					}
					abline(h=log2(cdat$spikeLines$y), lty=2, col=cdat$spikeLines$col)
				}
			}
			
			if (do.decorate & plot.ctls != "only") {
				decorate.pars$i <- i
				decorate.pars$x <- x
				decorate.pars$y <- y
                    decorate.pars$sigs <- intersect(rowset,which(significants[,i]))
                    MA.scatter.decorate(decorate.pars)
	#			decorate()
			}
		}
		
	} else if (plot == "scatter") {
		for (i in 1:lcomp) {
			
			j <- compares[[i]][1]
			k <- compares[[i]][2]
			dj <- dirs[[i]][1]
			dk <- dirs[[i]][2]
			ternary (dj < 0, jf <- " (rev)", jf <- "")
			ternary (dk < 0, kf <- " (rev)", kf <- "")
			title <- paste(colnames(mat)[j],jf," - ",colnames(mat)[k],kf,", ",type," Values",sep="")
			jlab <- paste(colnames(mat)[j],jf,sep="")
			klab <- paste(colnames(mat)[k],kf,sep="")
			x <- mat[rowset,j] * dj
			y <- mat[rowset,k] * dk
			
			if (!monoscale) {  
				xmin <- min(x[scalerows], na.rm=TRUE)
				xmax <- max(x[scalerows], na.rm=TRUE)
				ymin <- min(y[scalerows], na.rm=TRUE)
				ymax <- max(y[scalerows], na.rm=TRUE)
			}
			
			if (smooth) {
				smoothScatter2(x, y, nbin=ss.nbin, bandwidth=ss.band, pch=ss.pch, colramp=ss.ramp, xlim=c(xmin,xmax), ylim=c(ymin,ymax), xlab=jlab, ylab=klab, main=title)
                    do.decorate=FALSE
			} else {
				plot(x, y, pch=pch, col=pcol, xlim=c(xmin,xmax), ylim=c(ymin,ymax), xlab=jlab, ylab=klab, main=title)
			}
			
			if (ctl.plot) {
				if (length(cdat$ctlSets) > 0) {
					for (j in 1:(length(cdat$ctlSets))) { 
						points(MA.obj$A[cdat$ctlSets[[j]],i], MA.obj$M[cdat$ctlSets[[j]],i], pch=cdat$ctlAtt$pch[j], col=cdat$ctlAtt$col[j])
					}
				}
				if (length(cdat$spikeSets) > 0) {
					for (j in 1:length(cdat$spikeSets)) { 
						points(MA.obj$A[cdat$spikeSets[[j]],i], MA.obj$M[cdat$spikeSets[[j]],i], pch=cdat$spikeAtt$pch[j], col=cdat$spikeAtt$col[j])
					}
					abline(h=log2(cdat$spikeLines$y), lty=2, col=cdat$spikeLines$col)
				}
			} 
			
			if (do.decorate & plot.ctls != "only") {
				decorate.pars$i <- i
				decorate.pars$j <- j
				decorate.pars$k <- k
				decorate.pars$x <- x
				decorate.pars$y <- y
                decorate.pars$sigs <- intersect(rowset,which(significants[,i]))
				MA.scatter.decorate(decorate.pars)
	#			decorate()
			}
		}
	}
	
	#### Close png device, if it was opened
	
	if (!is.null(filename)) { dev.off() }
}


# MA.plot(obj, smooth=FALSE, fc.lines=NULL, foldcolor=FALSE, monoscale=FALSE, names=NULL, arrayID=NULL, filename=NULL)
# scatter.plot <- function(obj, type="M", smooth=FALSE, fc.lines=c(-2:2), foldcolor=FALSE, monoscale=FALSE, compares=NULL, names=NULL, arrayID=NULL, filename=NULL)


apa.names$microarray <- c(apa.names$microarray, "MA.plot")
MA.plot <- function(obj, smooth=FALSE, fc.lines=NULL, foldcolor=FALSE, monoscale=FALSE, significants=NULL, names=NULL, arrayID=NULL, filename=NULL) {
	
	MA.scatter.plot(obj, type=NULL, plot="MA", smooth=smooth, fc.lines=fc.lines, foldcolor=foldcolor, monoscale=monoscale, significants=significants, names=names, arrayID=arrayID, filename=filename)
	
}


apa.names$microarray <- c(apa.names$microarray, "scatter.plot")
scatter.plot <- function(obj, type="M", smooth=FALSE, fc.lines=c(-2:2), foldcolor=FALSE, monoscale=FALSE, significants=NULL, compares=NULL, names=NULL, arrayID=NULL, filename=NULL) {
	
	MA.scatter.plot(obj, type=type, plot="scatter", smooth=smooth, fc.lines=fc.lines, foldcolor=foldcolor, monoscale=monoscale, significants=significants, compares=compares, names=names, arrayID=arrayID, filename=filename)
	
}


apa.names$microarray <- c(apa.names$microarray, "SVG.scatterplot")
SVG.scatterplot <- function(x, style=c("MA","volcano","scatter"), filename, sig.p=0.05, sig.fc=0, sig.x=-Inf, cex=1, las=1, col=c("grey","red","green3"), view=FALSE, handlers=FALSE, page.title=NULL, main=NULL, xlim=NULL, ylim=NULL, xlab=NULL, ylab=NULL) {
    
    ## 'x' is a 4-col data.frame.  Columns 1 and 2 are plot values; columns 3 and 4 are p-value (or 0) and gene label
    ##  - for 2-sample scatter plot, columns 1-2 are expression values or whatever
    ##  - for MA or volcano plot, column 1 is mean expr (A); column 2 is log2FC (M); also for volcano plots, col 3 must not be all 0.
    ##  - 'x' may also have columns 5-N; these are considered more gene annots, and will be displayed on the popups along with the gene label.
    ##
    ## 'filename' is the output SVG file that devSVGTips() will write to.  It will not write to screen.
    ## 'sig.p' indicates at which p-value the points start being colored (red=up, green=down).  Setting "sig.p=NA" turns this off.
    ## 'sig.fc', if not NA, is further restriction on which points get colored.  Works with or without 'sig.p'.
    ## 'pch' and 'sig.pch' control pch for non-sig and sig points, respectively.
    ## 'col' is a length-3 vector of color names, being non-sig, sig-up, and sig-down colors, respectively.
    ## 'view' launches Firefox (on *nix systems) to view the resulting plot.
    
    require(RSVGTipsDevice)
    
    style <- match.arg(style)
    ann <- x[,4:ncol(x),drop=FALSE]
    
    if (style=="MA") {
        mat <- x[,1:2]
        lfc <- x[,2]
        if (length(xlab)==0) xlab <- "Log2 Mean"
        if (length(ylab)==0) ylab <- "Log2 Fold-Change"
        if (length(main)==0) main <- "MA Plot"
        if (length(page.title)==0) page.title <- "MA Plot"
    } else if (style=="volcano") {
        mat <- cbind(x[,2], -log10(x[,3]))  # input p-values should be unlogged, so -log10 them here
        lfc <- x[,2]
        if (length(xlab)==0) xlab <- "Log2 Fold-Change"
        if (length(ylab)==0) ylab <- "-Log10(P-Value)"
        if (length(main)==0) main <- "Volcano Plot"
        if (length(page.title)==0) page.title <- "Volcano Plot"
    } else if (style=="scatter") {
        mat <- x[,1:2]
        lfc <- log2(x[,1]/x[,2])
        if (length(xlab)==0) xlab <- colnames(x)[1]
        if (length(ylab)==0) ylab <- colnames(x)[2]
        if (length(main)==0) main <- "Scatter Plot"
        if (length(page.title)==0) page.title <- "Scatter Plot"
    }
    
    if (!is.na(sig.p) & !is.na(sig.fc)) {
        sig.up <- x[,3] <= sig.p & lfc >= sig.fc
        sig.dn <- x[,3] <= sig.p & lfc <= -sig.fc
    } else if (!is.na(sig.p)) {
        sig.up <- x[,3] <= sig.p & lfc > 0
        sig.dn <- x[,3] <= sig.p & lfc < 0
    } else if (!is.na(sig.fc)) {
        sig.up <- lfc >= sig.fc
        sig.dn <- lfc <= -sig.fc
    } else {
        sig.up <- sig.dn <- rep(FALSE, nrow(x))
    }
    if (!is.infinite(sig.x)) {
        sig.up <- sig.up & x[,1] >= sig.x
        sig.dn <- sig.dn & x[,1] >= sig.x
    }
    non.sig <- !sig.up & !sig.dn
    
    if (length(xlim)<2) xlim <- range(real(mat[,1]))
    if (length(ylim)<2) ylim <- range(real(mat[,2]))
    
    devSVGTips(filename, toolTipMode=1, title=page.title)  # this title is for the web page, NOT the image
    plot(0, 0, col=0, xlim=xlim, ylim=ylim, xlab=xlab, ylab=ylab, main=main, cex=cex, las=las)  # empty plot frame
    ## no tooltips (not sig DE)
    if (any(non.sig)) points(mat[non.sig,], col=col[1], pch=1, cex=cex)
    ## red tooltips (sig DE up)
    if (any(sig.up)) {
        invisible(sapply(which(sig.up), function(i) {
            setSVGShapeToolTip(title=paste(ann[i,],collapse="\n"))
            points(mat[i,1], mat[i,2], col=col[2], pch=1, cex=cex)
        }))
    }
    if (any(sig.dn)) {
        ## green tooltips (sig DE down)
        invisible(sapply(which(sig.dn), function(i) {
            setSVGShapeToolTip(title=paste(ann[i,],collapse="\n"))
            points(mat[i,1], mat[i,2], col=col[3], pch=1, cex=cex)
        }))
    }
    
    if (style=="MA") {
        abline(h=0, col=1)
    } else if (style=="volcano") {
        abline(v=0, col=1)
    } else if (style=="scatter") {
        abline(0, 1, col=1)
    }
    
    dev.off()
    
    if (!handlers) system(paste("perl -i -pe 's!SVGRoot.addEventListener!// SVGRoot.addEventListener!'",filename))  # knock out JS even listeners -- Chrome & FF do it better, natively
    if (view) system(paste("firefox",filename,"&"))  # only works on *nix systems
}


apa.names$plots <- c(apa.names$plots, "volcano.plot")
volcano.plot <- function(x, sig=NULL, main=NULL) {
    ## 'x' is a 2-col matrix or dataframe: LFC,FDR (NOT -log10 FDR)
    x[,2] <- -log10(x[,2])
    if (length(main)==0) main <- "Volcano Plot"
    if (!is.null(sig)) {
        is.sig <- x[,2] >= -log10(sig)
        plot(x, col=0, xlab="Log2 Fold Change", ylab="-Log10(FDR)", main=main)
        points(x[!is.sig,,drop=FALSE], col=8)
        for (p in 1:2) {  # double-plotting makes points "bold"
            points(x[is.sig&x[,1]>0,,drop=FALSE], col=2)
            points(x[is.sig&x[,1]<0,,drop=FALSE], col=3)
        }
        ltext <- c( paste(sum(is.sig&x[,1]>0),"Up"), paste(sum(is.sig&x[,1]<0),"Down") )
        legend("topright", col=2:3, pch=1, legend=ltext)
    } else {
        plot(x, xlab="Log2 Fold Change", ylab="-Log10(FDR)", main=main)
    }
    abline(v=0, col=1)
}


apa.names$plots <- c(apa.names$plots, "strandedness.plot")
strandedness.plot <- function(x, label, style=c("density","MA"), minimum=0, pseudo=0, jitter=FALSE, ...) {
    
    ## 'x' is a 2-col expression matrix with rows = genes and col 1 = sense, col 2 = antisense values.
    ## 'label' is a short descriptive string for values in 'x', e.g. 'sample X mRNA counts'.
    ## 'style' is the plot style; either "density" for sense-pct, anti-pct density histogram, or "MA" for sense/anti MA plot.
    ## 'minimum' ignores genes with less than 'minimum' total counts.
    ## 'pseudo' adds this pseudocount to 'x' before making calculations.
    ## 'jitter' applies only if 'style' is "MA"; applies 1% jitter in both dimensions; jitter attenuates for larger values.
    
    style <- match.arg(style)
    x <- x[apply(x>=minimum,1,any),]
    all.sense.pct <- round(100*sum(x[,1])/sum(x),1)  # DO THIS BEFORE ADDING PSEUDOCOUNT
    if (!is.na(pseudo)) x <- x+pseudo
    nr <- nrow(x)
    A <- log2(rowSums(x))
    M <- log2(x[,1]/x[,2])
    M0 <- M==0 ; MP <- M>0 ; MN <- M<0
    pN <- sum(MP,na.rm=TRUE) ; nN <- sum(MN,na.rm=TRUE)
    pPct <- round(100*pN/(pN+nN),0) ; nPct <- round(100*nN/(pN+nN),0)
    pLabel <- paste0("S>A: ",pN," genes (",pPct,"%)")
    nLabel <- paste0("A>S: ",nN," genes (",nPct,"%)")
    title <- paste0(label,"\nSense Expr: ",all.sense.pct,"% Total\nGenes: ",nr)
    
    if (style == "density") {
        rs <- rowSums(x)
        L <- list(`Sense Pct per Gene`=100*x[,1]/rs, `Anti Pct per Gene`=100*x[,2]/rs)
        d <- dhist(L, main=title, legend="top", col=c(2,3), xlim=c(0,100), ...)
        Yr <- abs(diff(d$ylim))/100
        text(50, d$ylim[2]/2+Yr*3, pLabel, col=2)
        text(50, d$ylim[2]/2-Yr*3, nLabel, col=3)
    } else if (style == "MA") {
        Ar <- abs(diff(range(A)))/100
        Mr <- abs(diff(range(M)))/100
        if (jitter) {
            A <- A + runif(length(A),-Ar,Ar) * (1-A/max(A))^2
            M <- M + runif(length(M),-Mr,Mr) * (1-M/max(M))^2
        }
        plot(A, M, col=0, pch=".", main=title, ylab="Log2(Sense/Anti)", xlab="Log2(Sense+Anti)", ...)
        abline(h=0)
        points(A[M0], M[M0], col="#0000FF66", main=title, ylab="M", xlab="A")
        points(A[MN], M[MN], col="#00FF0066", main=title, ylab="M", xlab="A")
        points(A[MP], M[MP], col="#FF000066", main=title, ylab="M", xlab="A")
        text(min(real(A)), max(real(M)), pLabel, c(0.05,0.5), col=2)
        text(min(real(A)), min(real(M)), nLabel, c(0.05,0.2), col=3)
    }
}


apa.names$plots <- c(apa.names$plots, "placement.graph")
placement.graph <- function(place.list, label) {
    ## designed for place.peak() output??
    types <- rep(0,3); names(types) <- c("EXON","INTR","ITGC")
    dists <- c()
    for (i in 1:length(place.list)) {
        if (length(place.list[[i]]$EXON) > 0) {
            types[1] <- types[1] + 1
        } else if (length(place.list[[i]]$INTR) > 0) {
            types[2] <- types[2] + 1
        } else {
            types[3] <- types[3] + 1
            dists <- c(dists, min(place.list[[i]]$ITGC[,7]))
        }
    }
    par(mfrow=c(1,2), cex=1.2)
    if (length(dists) > 2) {
        dhist(list(log2(dists)), legend=NULL, main="Nearest-Neighbor Distance, Log2", xlab="Log2 Bp")
    } else {
        null.plot(main="Nearest-Neighbor Distance, Log2")
    }
    barplot(rev(types), horiz=TRUE, main=paste("Features Hit By Peaks:",label))
}


apa.names$hacks <- c(apa.names$hacks, "plot.phylo2")
plot.phylo2 <- function (x, type="phylogram", use.edge.length=TRUE, node.pos=NULL, show.tip.label=TRUE, show.node.label=FALSE, edge.color="black", edge.width=1, edge.lty=1, font=3, cex=par("cex"), adj=NULL, 
    srt=0, no.margin=FALSE, root.edge=FALSE, label.offset=0, underscore=FALSE, x.lim=NULL, y.lim=NULL, direction="rightwards", lab4ut="horizontal", tip.color="black", plot=TRUE, leaf.just=FALSE, lab.just=FALSE, ...) {
	
	require("ape")
	stuff1 <- stuff2 <- c()
    Ntip <- length(x$tip.label)
    if (Ntip == 1) {
        warning("found only one tip in the tree")
        return(NULL)
    }
    if (any(tabulate(x$edge[, 1]) == 1)) { stop("there are single (non-splitting) nodes in your tree; you may need to use collapse.singles()") }
    .nodeHeight <- function(Ntip, Nnode, edge, Nedge, yy) {
		.C("node_height", as.integer(Ntip), as.integer(Nnode), as.integer(edge[,1]), as.integer(edge[, 2]), as.integer(Nedge), as.double(yy), DUP = FALSE, PACKAGE = "ape")[[6]]
	}
    .nodeDepth <- function(Ntip, Nnode, edge, Nedge) {
		.C("node_depth", as.integer(Ntip), as.integer(Nnode), as.integer(edge[,1]), as.integer(edge[, 2]), as.integer(Nedge), double(Ntip + Nnode), DUP = FALSE, PACKAGE = "ape")[[6]]
    }
	.nodeDepthEdgelength <- function(Ntip, Nnode, edge, Nedge, edge.length) {
		.C("node_depth_edgelength", as.integer(Ntip), as.integer(Nnode), as.integer(edge[, 1]), as.integer(edge[,2]), as.integer(Nedge), as.double(edge.length), double(Ntip + Nnode), DUP = FALSE, PACKAGE = "ape")[[7]]
    }
	Nedge <- dim(x$edge)[1]
    Nnode <- x$Nnode
    ROOT <- Ntip + 1
    type <- match.arg(type, c("phylogram", "cladogram", "fan", "unrooted", "radial"))
    direction <- match.arg(direction, c("rightwards", "leftwards", "upwards", "downwards"))
    if (is.null(x$edge.length)) { use.edge.length <- FALSE }
    if (type %in% c("unrooted", "radial") || !use.edge.length || is.null(x$root.edge) || !x$root.edge) { root.edge <- FALSE }
    if (type == "fan" && root.edge) {
		warning("drawing root edge with type = 'fan' is not yet supported")
        root.edge <- FALSE
    }
    phyloORclado <- type %in% c("phylogram", "cladogram")
    horizontal <- direction %in% c("rightwards", "leftwards")
    xe <- x$edge
    if (phyloORclado) {
        phyOrder <- attr(x, "order")
        if (is.null(phyOrder) || phyOrder != "cladewise") {
            x <- reorder(x)
            if (!identical(x$edge, xe)) {
                ereorder <- match(x$edge[, 2], xe[, 2])
                if (length(edge.color) > 1) {
					edge.color <- rep(edge.color, length.out = Nedge)
					edge.color <- edge.color[ereorder]
                }
                if (length(edge.width) > 1) {
					edge.width <- rep(edge.width, length.out = Nedge)
					edge.width <- edge.width[ereorder]
                }
                if (length(edge.lty) > 1) {
					edge.lty <- rep(edge.lty, length.out = Nedge)
					edge.lty <- edge.lty[ereorder]
                }
            }
        }
        yy <- numeric(Ntip + Nnode)
        TIPS <- x$edge[x$edge[, 2] <= Ntip, 2]
        yy[TIPS] <- 1:Ntip
    }
    z <- reorder(x, order = "pruningwise")
    if (phyloORclado) {
        if (is.null(node.pos)) {
            node.pos <- 1
            if (type == "cladogram" && !use.edge.length) { node.pos <- 2 }
        }
        if (node.pos == 1) { 
			yy <- .nodeHeight(Ntip, Nnode, z$edge, Nedge, yy) 
		} else {
            ans <- .C("node_height_clado", as.integer(Ntip), as.integer(Nnode), as.integer(z$edge[, 1]), as.integer(z$edge[,2]), as.integer(Nedge), double(Ntip + Nnode), as.double(yy), DUP = FALSE, PACKAGE = "ape")
            xx <- ans[[6]] - 1
            yy <- ans[[7]]
        }
        if (!use.edge.length) {
            if (node.pos != 2) {  xx <- .nodeDepth(Ntip, Nnode, z$edge, Nedge) - 1 }
            xx <- max(xx) - xx
        } else {
            xx <- .nodeDepthEdgelength(Ntip, Nnode, z$edge, Nedge, z$edge.length)
        }
    } else {
		switch(type, 
			fan = {
				TIPS <- x$edge[which(x$edge[, 2] <= Ntip), 2]
				xx <- seq(0, 2 * pi * (1 - 1/Ntip), 2 * pi/Ntip)
				theta <- double(Ntip)
				theta[TIPS] <- xx
				theta <- c(theta, numeric(Nnode))
				theta <- .nodeHeight(Ntip, Nnode, z$edge, Nedge, theta)
				if (use.edge.length) {
					r <- .nodeDepthEdgelength(Ntip, Nnode, z$edge, Nedge, z$edge.length)
				} else {
					r <- .nodeDepth(Ntip, Nnode, z$edge, Nedge)
					r <- 1/r
				}
				xx <- r * cos(theta)
				yy <- r * sin(theta)
			}, 
			unrooted = {
				nb.sp <- .nodeDepth(Ntip, Nnode, z$edge, Nedge)
				XY <- if (use.edge.length) {
						unrooted.xy(Ntip, Nnode, z$edge, z$edge.length, nb.sp) 
					} else { 
						unrooted.xy(Ntip, Nnode, z$edge, rep(1, Nedge), nb.sp)
					}
				xx <- XY$M[, 1] - min(XY$M[, 1])
				yy <- XY$M[, 2] - min(XY$M[, 2])
			}, 
			radial = {
				X <- .nodeDepth(Ntip, Nnode, z$edge, Nedge)
				X[X == 1] <- 0
				X <- 1 - X/Ntip
				yy <- c((1:Ntip) * 2 * pi/Ntip, rep(0, Nnode))
				Y <- .nodeHeight(Ntip, Nnode, z$edge, Nedge, yy)
				xx <- X * cos(Y)
				yy <- X * sin(Y)
			}
		)
	}
    if (phyloORclado) {
        if (!horizontal) {
            tmp <- yy
            yy <- xx
            xx <- tmp - min(tmp) + 1
        }
        if (root.edge) {
            if (direction == "rightwards") { xx <- xx + x$root.edge }
            if (direction == "upwards") { yy <- yy + x$root.edge }
        }
    }
    if (no.margin) { par(mai = rep(0, 4)) }
    if (is.null(x.lim)) {
        if (phyloORclado) {
            if (horizontal) {
                x.lim <- c(0, NA)
                pin1 <- par("pin")[1]
                strWi <- strwidth(x$tip.label, "inches")
                xx.tips <- xx[1:Ntip] * 1.04
                alp <- try(uniroot(function(a) max(a * xx.tips + strWi) - pin1, c(0, 1e+06))$root, silent = TRUE)
                if (is.character(alp)) {
					tmp <- max(xx.tips) * 1.5
                } else {
                  tmp <- ifelse (show.tip.label, max(xx.tips + strWi/alp), max(xx.tips))
                }
                x.lim[2] <- tmp
            } else {
				x.lim <- c(1, Ntip)
			}
        } else {
			switch(type, 
				fan = {
					if (show.tip.label) {
						offset <- max(nchar(x$tip.label) * 0.018 * max(yy) * cex)
						x.lim <- c(min(xx) - offset, max(xx) + offset)
					} else {
						x.lim <- c(min(xx), max(xx))
					}
				}, 
				unrooted = {
					if (show.tip.label) {
						offset <- max(nchar(x$tip.label) * 0.018 * max(yy) * 
						  cex)
						x.lim <- c(0 - offset, max(xx) + offset)
					} else x.lim <- c(0, max(xx))
				},
				radial = {
					if (show.tip.label) {
						offset <- max(nchar(x$tip.label) * 0.03 * cex)
						x.lim <- c(-1 - offset, 1 + offset)
					} else x.lim <- c(-1, 1)
				}
			)
		}
	} else if (length(x.lim) == 1) {
        x.lim <- c(0, x.lim)
        if (phyloORclado && !horizontal) { x.lim[1] <- 1 }
        if (type %in% c("fan", "unrooted") && show.tip.label) { x.lim[1] <- -max(nchar(x$tip.label) * 0.018 * max(yy) * cex) }
        if (type == "radial") { x.lim[1] <- ifelse (show.tip.label, -1 - max(nchar(x$tip.label) * 0.03 * cex), -1) }
    }
    if (phyloORclado && direction == "leftwards") { xx <- x.lim[2] - xx }
    if (is.null(y.lim)) {
        if (phyloORclado) {
            if (horizontal) {
                y.lim <- c(1, Ntip)
			} else {
                y.lim <- c(0, NA)
                pin2 <- par("pin")[2]
                strWi <- strwidth(x$tip.label, "inches")
                yy.tips <- yy[1:Ntip] * 1.04
                alp <- try(uniroot(function(a) max(a * yy.tips + strWi) - pin2, c(0, 1e+06))$root, silent = TRUE)
                if (is.character(alp)) {
					tmp <- max(yy.tips) * 1.5
                } else {
					tmp <- ifelse (show.tip.label, max(yy.tips + strWi/alp), max(yy.tips))
                }
                y.lim[2] <- tmp
            }
        } else {
			switch(type, 
				fan = {
					if (show.tip.label) {
						offset <- max(nchar(x$tip.label) * 0.018 * max(yy) * cex)
						y.lim <- c(min(yy) - offset, max(yy) + offset)
					} else {
						y.lim <- c(min(yy), max(yy))
					}
				}, unrooted = {
					if (show.tip.label) {
						offset <- max(nchar(x$tip.label) * 0.018 * max(yy) * cex)
						y.lim <- c(0 - offset, max(yy) + offset)
					} else {
						y.lim <- c(0, max(yy))
					}
				}, radial = {
					if (show.tip.label) {
						offset <- max(nchar(x$tip.label) * 0.03 * cex)
						y.lim <- c(-1 - offset, 1 + offset)
					} else {
						y.lim <- c(-1, 1)
					}
				}
			)
		}
    } else if (length(y.lim) == 1) {
        y.lim <- c(0, y.lim)
        if (phyloORclado && horizontal) { y.lim[1] <- 1 }
        if (type %in% c("fan", "unrooted") && show.tip.label) { y.lim[1] <- -max(nchar(x$tip.label) * 0.018 * max(yy) * cex) }
        if (type == "radial") { y.lim[1] <- ifelse (show.tip.label, -1 - max(nchar(x$tip.label) * 0.018 * max(yy) * cex), -1) }
    }
    if (phyloORclado && direction == "downwards") { yy <- y.lim[2] - yy }
    if (phyloORclado && root.edge) {
        if (direction == "leftwards") { x.lim[2] <- x.lim[2] + x$root.edge }
        if (direction == "downwards") { y.lim[2] <- y.lim[2] + x$root.edge }
    }
    asp <- ifelse(type %in% c("fan", "radial", "unrooted"), 1, NA)
	stuff1 <- list(x=0, type = "n", xlim = x.lim, ylim = y.lim, ann = FALSE, axes = FALSE, asp = asp, ...)
    plot(0, type = "n", xlim = x.lim, ylim = y.lim, ann = FALSE, axes = FALSE, asp = asp, ...)
    if (plot) {
        if (is.null(adj)) { adj <- ifelse (phyloORclado && direction == "leftwards", 1, 0) }
		if (phyloORclado && show.tip.label) {
            MAXSTRING <- max(strwidth(x$tip.label, cex = cex))
            loy <- 0
            if (direction == "rightwards") {
                lox <- label.offset + MAXSTRING * 1.05 * adj
            }
            if (direction == "leftwards") {
                lox <- -label.offset - MAXSTRING * 1.05 * (1 - adj)
            }
            if (!horizontal) {
                psr <- par("usr")
                MAXSTRING <- MAXSTRING * 1.09 * (psr[4] - psr[3])/(psr[2] - psr[1])
                loy <- label.offset + MAXSTRING * 1.05 * adj
                lox <- 0
                srt <- 90 + srt
                if (direction == "downwards") {
					loy <- -loy
					srt <- 180 + srt
                }
            }
        }
        if (type == "phylogram") {
            phylogram.plot(x$edge, Ntip, Nnode, xx, yy, horizontal, edge.color, edge.width, edge.lty)
        } else {
            if (type == "fan") {
                ereorder <- match(z$edge[, 2], x$edge[, 2])
                if (length(edge.color) > 1) {
					edge.color <- rep(edge.color, length.out = Nedge)
					edge.color <- edge.color[ereorder]
                }
                if (length(edge.width) > 1) {
					edge.width <- rep(edge.width, length.out = Nedge)
					edge.width <- edge.width[ereorder]
                }
                if (length(edge.lty) > 1) {
					edge.lty <- rep(edge.lty, length.out = Nedge)
					edge.lty <- edge.lty[ereorder]
                }
				stuff2 <- list(z.edge=z$edge, Ntip=Ntip, Nnode=Nnode, xx=xx, yy=yy, theta=theta, r=r, edge.color=edge.color, edge.width=edge.width, edge.lty=edge.lty)
                circular.plot(z$edge, Ntip, Nnode, xx, yy, theta, r, edge.color, edge.width, edge.lty)
			} else {
				stuff2 <- list(x.edge=x$edge, xx=xx, yy=yy, edge.color=edge.color, edge.width=edge.width, edge.lty=edge.lty)
				cladogram.plot(x$edge, xx, yy, edge.color, edge.width, edge.lty)
			}
        }
        if (root.edge) 
            switch(direction, 
				rightwards = segments(0, yy[ROOT], x$root.edge, yy[ROOT]), 
				leftwards = segments(xx[ROOT], yy[ROOT], xx[ROOT] + x$root.edge, yy[ROOT]), 
				upwards = segments(xx[ROOT], 0, xx[ROOT], x$root.edge), 
				downwards = segments(xx[ROOT], yy[ROOT], xx[ROOT], yy[ROOT] + x$root.edge)
			)
        if (show.tip.label) {
            if (is.expression(x$tip.label)) { underscore <- TRUE }
            if (!underscore) { x$tip.label <- gsub("_", " ", x$tip.label) }
            if (phyloORclado) { text(xx[1:Ntip] + lox, yy[1:Ntip] + loy, x$tip.label, adj = adj, font = font, srt = srt, cex = cex, col = tip.color) }
            if (type == "unrooted") {
                if (lab4ut == "horizontal") {
					y.adj <- x.adj <- numeric(Ntip)
					sel <- abs(XY$axe) > 0.75 * pi
					x.adj[sel] <- -strwidth(x$tip.label)[sel] * 1.05
					sel <- abs(XY$axe) > pi/4 & abs(XY$axe) < 0.75 * pi
					x.adj[sel] <- -strwidth(x$tip.label)[sel] * (2 * abs(XY$axe)[sel]/pi - 0.5)
					sel <- XY$axe > pi/4 & XY$axe < 0.75 * pi
					y.adj[sel] <- strheight(x$tip.label)[sel]/2
					sel <- XY$axe < -pi/4 & XY$axe > -0.75 * pi
					y.adj[sel] <- -strheight(x$tip.label)[sel] * 0.75
					text(xx[1:Ntip] + x.adj * cex, yy[1:Ntip] + y.adj * cex, x$tip.label, adj = c(adj, 0), font = font, srt = srt, cex = cex, col = tip.color)
                } else {
					adj <- abs(XY$axe) > pi/2
					srt <- 180 * XY$axe/pi
					srt[adj] <- srt[adj] - 180
					adj <- as.numeric(adj)
					xx.tips <- xx[1:Ntip]
					yy.tips <- yy[1:Ntip]
					if (label.offset) {
						xx.tips <- xx.tips + label.offset * cos(XY$axe)
						yy.tips <- yy.tips + label.offset * sin(XY$axe)
					}
					font <- rep(font, length.out = Ntip)
					tip.color <- rep(tip.color, length.out = Ntip)
					cex <- rep(cex, length.out = Ntip)
					for (i in 1:Ntip) { 
						text(xx.tips[i], yy.tips[i], cex = cex[i], x$tip.label[i], adj = adj[i], font = font[i], srt = srt[i], col = tip.color[i])
					}
                }
            }
            if (type %in% c("fan", "radial")) {
                xx.tips <- xx[1:Ntip]
                yy.tips <- yy[1:Ntip]
                rawangle <- atan2(yy.tips, xx.tips)
                if (label.offset) {
					xx.tips <- xx.tips + label.offset * cos(angle)
					yy.tips <- yy.tips + label.offset * sin(angle)
                }
                s <- xx.tips < 0
                angle <- rawangle * 180/pi
                angle[s] <- angle[s] + 180
                adj <- as.numeric(s)
                font <- rep(font, length.out = Ntip)
                tip.color <- rep(tip.color, length.out = Ntip)
                cex <- rep(cex, length.out = Ntip)
				radii <- sapply(1:Ntip, FUN=function(i){sqrt(xx.tips[i]^2+yy.tips[i]^2)})
                for (i in 1:Ntip) {
					tx <- xx.tips[i]
					ty <- yy.tips[i]
					if (lab.just) {
						just <- max(radii) - radii[i] + 1
						tx <- tx + just * cos(rawangle[i])
						ty <- ty + just * sin(rawangle[i])
					}
					text(tx, ty, x$tip.label[i], font = font[i], cex = cex[i], srt = angle[i], adj = adj[i], col = tip.color[i], family = "mono")
				}
            }
        }
        if (show.node.label) {
            text(xx[ROOT:length(xx)] + label.offset, yy[ROOT:length(yy)], x$node.label, adj = adj, font = font, srt = srt, cex = cex)
		}
    }
    L <- list(type = type, use.edge.length = use.edge.length, 
        node.pos = node.pos, show.tip.label = show.tip.label, 
        show.node.label = show.node.label, font = font, cex = cex, 
        adj = adj, srt = srt, no.margin = no.margin, label.offset = label.offset, 
        x.lim = x.lim, y.lim = y.lim, direction = direction, 
        tip.color = tip.color, Ntip = Ntip, Nnode = Nnode)
    assign("last_plot.phylo", c(L, list(edge = xe, xx = xx, yy = yy)), envir = .PlotPhyloEnv)
#	return(list(stuff1, stuff2))
    invisible(L)
}


apa.names$hacks <- c(apa.names$hacks, "circular.plot2")
circular.plot2 <- function (edge, Ntip, Nnode, xx, yy, theta, r, edge.color, edge.width, edge.lty, leaf.just) {
	
	### UNDER CONSTRUCTION -- will plot justified (cladogram-style) leaf edges which extend to the margin
	
    r0 <- r[edge[,1]]
    r1 <- r[edge[,2]]
    theta0 <- theta[edge[,2]]
    costheta0 <- cos(theta0)
    sintheta0 <- sin(theta0)
    x0 <- r0 * costheta0
    y0 <- r0 * sintheta0
    x1 <- r1 * costheta0
    y1 <- r1 * sintheta0
    segments(x0, y0, x1, y1, col = edge.color, lwd = edge.width, lty = edge.lty)
    tmp <- which(diff(edge[,1]) != 0)
    start <- c(1, tmp + 1)
    Nedge <- dim(edge)[1]
    end <- c(tmp, Nedge)
    foo <- function(edge.feat, default) {
        if (length(edge.feat) == 1) {
            return(rep(edge.feat, Nnode))
        } else {
            edge.feat <- rep(edge.feat, length.out = Nedge)
            feat.arc <- rep(default, Nnode)
            for (k in 1:Nnode) {
                tmp <- edge.feat[start[k]]
                if (tmp == edge.feat[end[k]]) { feat.arc[k] <- tmp }
            }
        }
        feat.arc
    }
    co <- foo(edge.color, "black")
    lw <- foo(edge.width, 1)
    ly <- foo(edge.lty, 1)
    for (k in 1:Nnode) {
        i <- start[k]
        j <- end[k]
        X <- rep(r[edge[i,1]], 100)
        Y <- seq(theta[edge[i,2]], theta[edge[j,2]], length.out = 100)
        lines(X * cos(Y), X * sin(Y), col = co[k], lwd = lw[k], lty = ly[k])
    }
}


apa.names$plots <- c(apa.names$plots, "gradient.census")
gradient.census <- function(x, axis, breaks, pal=NULL, alpha=0.25, width=NULL, ablines=FALSE, labels=NULL) {
	
	## histograms a vector 'x' according to 'breaks', then returns membership counts for each bin.
	## 'breaks' is either a vector of > 1 break values, or a single value indicating how many breaks.  If a vector, defines length(breaks)-1 bins.
	## if 'x' has been plotted, this will plot transparent color bands onto the plot, with membership numbers.
	## 'axis' = 1/2, indicating that breaks are applied to x-axis (1) or y-axis(2)
	## 'pal' indicates the palette to use; must have one color per bin.  If NULL then no color bands appear.  DO NOT MAKE PALETTE ITSELF TRANSPARENT; use 'alpha'.
	## 'alpha' is an opacity percent on [0,1].
	## 'width' is also required to indicate the other dimensions of the color bands (which are rect() calls).  Thus if axis=1, need ymin & ymax for rect(), so set 'width=range(y)' or something.
	## 'ablines' will plot ablines at the breaks.
	## 'labels' same as 'x' in legend().  If specified, will plot the membership numbers in each band, in the color of that band (but not transparent).
	##   NOTE: if 'axis' = 1, only "right", "left", "center" are meaningful; for 'axis' = 2, only "top", "bottom", "center".
	
	if (axis != 1 & axis != 2) { stop("'axis' must be 1 or 2!\n") }
	if (length(breaks) == 1) {
		Nbr <- breaks
		breaks <- seq(min(x), max(x), length=Nbr)
	} else {
		Nbr <- length(breaks)
	}
	cts <- hist(x, breaks=breaks, plot=FALSE)$counts
	N <- length(cts)
	
	plot <- TRUE
	if (length(width)==0) {
		plot <- FALSE
	} else if (length(pal)==0) {
		plot <- FALSE
	}
	
	if (plot) {
		width[1] <- width[1] - diff(width) * 0.05
		width[2] <- width[2] + diff(width) * 0.05
		if (length(pal) == 1) {
			pal <- palettizer(pal, N)
		} else if (length(pal) != N) { 
			stop("palette length does not match # bins (which is # breaks - 1)\n") 
		}
		alpha.hex <- rebase(round(255*alpha,0), 16)
		alpha.pal <- paste(pal, alpha.hex, sep="")
		if (axis == 1) {
			for (i in 1:N) {
				rect(breaks[i],width[1], breaks[i+1],width[2], bord=NA, col=alpha.pal[i])
			}
		} else if (axis == 2) {
			for (i in 1:N) {
				rect(width[1],breaks[i], width[2],breaks[i+1], bord=NA, col=alpha.pal[i])
			}
		}
	}
	
	if (ablines) {
		for (i in 1:Nbr) {
			if (axis == 1) {
				abline(v=breaks)
			} else if (axis == 2) {
				abline(h=breaks)
			}
		}
	}
	
	if (!is.null(labels)) {
		if (axis == 1) {
			yat <- switch(labels, "top"=width[2], "bottom"=width[1], "center"=mean(width))
			ypos <- switch(labels, "top"=1, "bottom"=3, "center"=NULL)
			text(midpoints(breaks), yat, labels=paste("N =",cts), col=1, pos=ypos)
		} else if (axis == 2) {
			xat <- switch(labels, "right"=width[2], "left"=width[1], "center"=mean(width))
			xpos <- switch(labels, "right"=2, "left"=4, "center"=NULL)
			text(xat, midpoints(breaks), labels=paste("N =",cts), col=1, pos=xpos)
		}
	}
}


apa.names$dev <- c(apa.names$dev, "SVGMAplot")
SVGMAplot <- function(x, ann, imgname, sig=0.05, fc=0, minA=-Inf, show=FALSE, cols=c(2,3,8,1), main="MA Plot", page.title="MA Plot", xlab="Log2 Mean", ylab="Log2 Fold-Change", xlim=NULL, ylim=NULL, handlers=FALSE) {
    
    ## Plots an MA plot using SVG, which allows mouseover popups with gene data for significant points.
    ## 'x' is a 3-column dataframe: M, A, p-value (or some other score).  MUST HAVE ROWNAMES = GENE IDS.
    ## 'ann' is a 9-column gene annotation dataframe with gene IDs in col 1.  Expected columns in order: GeneID,Symbol,Chr,Start,End,Strand,Biotype,Status,Description.
    ## 'imgname' is an output image name (should have .svg suffix).
    ## 'sig' is a cutoff for determining significance (applied to x[,3]).
    ## 'fc' is an additional cutoff to be applied with 'sig', for restricting which points are significant.
    ##   cutoff will be applied + and -, thus "fc=3" selects for points >= 3 and <= -3.
    ## 'minA' is another additional cutoff to be applied with 'sig', which specific minimum x-axis value to flag point as significant.
    ## 'show'=T' launches SVG image in firefox
    ## 'cols' is a length=4 vector with colors for sig up, sig down, background, and abline
    
    require(RSVGTipsDevice)
    
    ## Point sets
    non.sig <- which(abs(x[,1])<fc | x[,2]<minA | x[,3]>sig)
    sig.up <- which(x[,1]>=fc & x[,2]>=minA & x[,3]<=sig)
    sig.dn <- which(x[,1]<=-fc & x[,2]>=minA & x[,3]<=sig)
    message(paste("UP:",length(sig.up),"| DOWN:",length(sig.dn)))
    
    ## Tip text format: "symbol\ngeneID\nchr:start-end:strand\nstatus biotype\ndescription"
    ann <- ann[match(rownames(x),ann[,1]),]
    tips <- paste(ann[,2],ann[,1],paste0(ann[,3],":",ann[,4],"-",ann[,5],":",ann[,6]),paste(ann[,8],ann[,7]),ann[,9],sep="\n")
    
    ## Other plot params
    if (length(xlim)==0) xlim <- range(x[,2], na.rm=TRUE)
    if (length(ylim)==0) ylim <- range(x[,1], na.rm=TRUE)
    
    ## base plot
    devSVGTips(imgname, toolTipMode=1, title=page.title)  # this title is for the web page
    plot(0, 0, col=0, xlim=xlim, ylim=ylim, xlab=xlab, ylab=ylab, main=main, las=1)  # empty plot frame
    ## no tooltips (not sig DE)
    points(x[non.sig,2:1], col=cols[3])
    abline(h=0, col=cols[4])
    ## red tooltips (sig DE up)
    invisible(sapply(sig.up, function(i) {
        setSVGShapeToolTip(title=tips[i])
        points(x[i,2], x[i,1], col=cols[1])  # points must have pch=1!  Popups don't appear otherwise.
    }))
    ## green tooltips (sig DE down)
    invisible(sapply(sig.dn, function(i) {
        setSVGShapeToolTip(title=tips[i])
        points(x[i,2], x[i,1], col=cols[2])  # points must have pch=1!  Popups don't appear otherwise.
    }))
    dev.off()
    ## knock out JS event listeners -- Chrome & FF do it better, natively -- now we don't have redundant, overlapping popups!
    if (!handlers) system(paste("perl -i -pe 's!SVGRoot.addEventListener!// SVGRoot.addEventListener!'",imgname))
    ## can be buggy, but works well enough to show you the plot
    if (show) system(paste("firefox",imgname,"&"))
    
    ## notes:
    ## do not use "desc" argument in setSVGShapeToolTip() -- paste lines together with "\n" and load into "title" argument
    ## perl call is not necessary, but plot has annoying double-display of popups without it -- first from JS, then from browser itself.
    ## points() calls within sapply apparently can't handle single-arg x,y coords: must give x, y explicitly
}


apa.names$hacks <- c(apa.names$hacks, "calculate.margin.width")
calculate.margin.width <- function(x) {
    
    ## Calculates minimum margin width value to accommodate vector of axis-label strings 'x'
    ## ASSUMES R DEFAULT FONT -- working as of R3.2.2/CentOS7
    ## ONLY TESTED FOR PNG (but the others should be very similar)
    ## Currently fixed for cex=1.2.  In future, range of cex possible?   ## PROBABLY NOT -- char width behavior not remotely linear when changing cex value in test script, see code at head of acsii_dimensions.txt
    
    cex <- 1.2      # required for now -- only scaling factor calculated
    start <- 1      # effective margin value where label starts
    extra <- 1      # "insurance" space to add
    factors <- c(   # scaling factor values 1-30, for cex values 0.1-3.0  (ONLY 1.2 IS POPULATED)
        1,1,1,1,1,1,1,1,1,1,        # 0.1 - 1.0  (1-10)
        1,18.5/17,1,1,1,1,1,1,1,1,  # 1.1 - 2.0  (11-20)
        1,1,1,1,1,1,1,1,1,1         # 2.1 - 3.0  (21-30)
    )
    asc <- read.delim(paste0(data.path,"/ascii_dimensions.txt"), as.is=TRUE, comment.char="#")
    rel <- sapply(x, function(y) sum(asc[match(unlist(strsplit(y,"")),asc[,1]),2]) )
    fac.idx <- as.integer(round(cex*10,0))
    max(rel) * factors[fac.idx] + start + extra
}


apa.names$hacks <- c(apa.names$hacks, "calculate.mono.width")
calculate.mono.width <- function(x, cex=1) {
    
    ## calculates minimum width in pixels to accomodate the largest element from a vector of strings 'x', when plotted with par(family="mono")
    ## holds for cex = { 0.8 1.0 1.2 1.4 1.6 } using png()
    ## tested on R2.14.1/Win7 and R3.1.0/CentOS6&Mac
    
    if (cex < 0.8 | cex > 1.6) message("WARNING: cex value outside 0.8-1.6 range: result may not be accurate!\n")
    pix.per.char <- 5.4 + round((cex-1)/0.2,0)   # empirically determined mean pixels per char when family="mono", see limitations above
    pix.per.char * max(nchar(x))
}


apa.names$hacks <- c(apa.names$hacks, "calculate.barplot.xmax")
calculate.barplot.xmax <- function(x, beside=FALSE) {
    
    ## calculates max x value when calling "barplot(x)"
    ## used when you want to auto-adjust x limits in the "barplot(x)" call,
    ##  without having to call "barplot(x)" first just to see what they are.
    
    if (is.vector(x)) {
        ## vector
        (length(x)-1)*1.2+0.7
    } else if (!beside) {
        ## matrix treated as a vector of stacked values
        (ncol(x)-1)*1.2+0.7
    } else {
        ## matrix, NOT stacked
        (nrow(x)*ncol(x)-1)+1.5+(ncol(x)-1)
    }
}


apa.names$hacks <- c(apa.names$hacks, "extend.xylim")
extend.xylim <- function(x, amount, percent=TRUE) {
    
    if (percent) amount <- abs(diff(range(x)))*amount
    c( min(x)-amount, max(x)+amount )
}


apa.names$general <- c(apa.names$general, "visible.segment")
visible.segment <- function(m, b, xlim, ylim, point=NULL) {
    
    ## calculates where, if at all, a given straight line passes through the plot area.
    ## the line is given by its 'm' (slope) and 'b' (intercept) values.
    ## 'xlim' and 'ylim' are the limits of the plot (each a vector of length 2)
    ## 'point', if given, is a vector c(x,y).  *** Only required when 'm' is infinite ***
    ## 
    ## output is a vector of length 5:
    ##   values 1-4 are for sides 1-4 (per par(), etc): either there is a value indicating the point of intersection, or NA to indicate no intersection.
    ##   value 5 is the length of the line contained within the plot limits (or NA).
    ## NOTE: this calculates the intersection with x and y limits, NOT the intersection with the PLOT BOX, which is always just outside the limits!!!
    ##   to better visualize the points of intersection on the plot, run "abline(b, m); abline(h=ylim, v=xlim, lty=3)"
    
    if (m==0) {
        if (b %within% ylim) {
            ## horizontal line inside plot
            c(0, b, 0, b, diff(ylim))
        } else {
            ## horizontal line outside plot
            rep(NA,5)
        }
    } else if (is.infinite(m)) {
        if (length(point)==0) stop("the slope is infinite, and 'point' was not specified: cannot place your line!\n")
        if (point[1] %within% xlim) {
            ## vertical line inside plot
            c(point[1], 0, point[1], 0, diff(xlim))
        } else {
            ## vertical line outside plot
            rep(NA,5)
        }
    } else {
        xcross <- c( ylim[1]-b, ylim[2]-b )/m
        ycross <- c( m*xlim[1]+b, m*xlim[2]+b )
        hits <- c(
            side1=ifelse(xcross[1] %within% xlim, xcross[1], NA),  # if hits side 1, point of crossing, else NA
            side2=ifelse(ycross[1] %within% ylim, ycross[1], NA),  # if hits side 2...
            side3=ifelse(xcross[2] %within% xlim, xcross[2], NA),  # if hits side 3...
            side4=ifelse(ycross[2] %within% ylim, ycross[2], NA),  # if hits side 4...
            length=NA
        )
        ## calculate line distance within x,y limits
        if (all(!is.na(hits[c(1,3)]))) {
            x1 <- hits[1]; x2 <- hits[3]
            y1 <- ylim[1]; y2 <- ylim[2]
        } else if (all(!is.na(hits[c(2,4)]))) {
            x1 <- xlim[1]; x2 <- xlim[2]
            y1 <- hits[2]; y2 <- hits[4]
        } else {
            x1 <- ifelse(!is.na(hits[1]), hits[1], hits[3])
            x2 <- ifelse(!is.na(hits[2]), xlim[1], xlim[2])
            y1 <- ifelse(!is.na(hits[2]), hits[2], hits[4])
            y2 <- ifelse(!is.na(hits[1]), ylim[1], ylim[2])
        }
        hits[5] <- sqrt((x2-x1)^2+(y2-y1)^2)
        hits
    }
}


apa.names$dev <- c(apa.names$dev, "plot.vector")
plot.vector <- function(x, pch=1, col=1, lty=1, origin=NULL) {
    
    ## plots point 'x' as a vector.
    ## ADDS TO AN EXISTING PLOT.
    ## 'origin' is the origin (where vector line originates from), which is all 0 unless otherwise specified.
    
    if (length(origin)==0) {
        origin <- rep(0,length(x))
    } else {
        if (length(origin) != length(x)) stop("'x' and 'origin' must have same length!\n")
    }
    
    points(x[1], x[2], col=col, pch=pch)
    segments(origin[1],origin[2], x[1],x[2], col=col, lty=lty)
}


apa.names$dev <- c(apa.names$dev, "plot.polygon")
plot.polygon <- function(x, add=FALSE, pch=1, col=1, lty=1, ...) {
    
    ## plots a 2-column matrix of points (col 1 = x, col 2 = y)
    ## '...' are other args passed to plot.default

    if (add) {
        points(x, pch=pch, col=col, ...)
    } else {
        plot(x, pch=pch, col=col, ...)
    }
    if (length(col)==1) col <- rep(col, nrow(x))
    if (length(lty)==1) lty <- rep(lty, nrow(x))
    seg.arg <- list(...)
    for (i in 1:nrow(x)) {
        j <- ifelse(i<nrow(x), i+1, 1)
        do.call(segments, c(seg.arg, x0=x[i,1],y0=x[i,2], x1=x[j,1],y1=x[j,2], col=col[i], lty=lty[i]))
    }
}


apa.names$bio.seq <- c(apa.names$bio.seq, "picard.metrics.plot")
picard.metrics.plot <- function(x, mrna=FALSE, plus=FALSE, genomebp=NULL, pmar=6, imgname=NULL, cex=par()$cex, col=NULL, lty=1, lwd=1, style=c("bptype","coverage"), device=c("png","pdf"), imgdim=NULL, view=FALSE, main=NULL) {
    
    ## Two plots for Picard's CollectRnaSeqMetrics output.
    ## 'x' is a matrix or data.frame with samples on rows and Picard stats on columns, e.g. from /home/apa/local/bin/mergeRnaSeqMetrics
    ## 'style=bptype' produces reads-per-feature-type barplot; 'style=coverage' produces CDS 5'->3' coverage lineplot
    ## 'view=TRUE' generates plot
    ## 'mRNA=TRUE' is for 'style=bptype' only, and indicates to merge cds/utr/ncRNA into a single category.
    ## 
    ## 'genomebp' is optional background-frequency bar for for plot style "bptypes":
    ##   This vector will indicate N bp found in: Genome, Intergenes, Introns, PC-UTRs, CDSs, NC-Exons, and Ribosomes, in that order.
    
    style <- match.arg(style)
    device <- match.arg(device)
#    cex <- ifelse(length(cex)>0, cex, ifelse(plot2file, ifelse(device=="png", 1.2, 1), 1))
    plot2file <- ifelse(is.na(device)|length(imgname)==0, FALSE, TRUE)
    
    if (colnames(x)[1]=="NAME") x <- rownamed.matrix(x)
    
    if (length(imgdim)!=2) {
        if (style == "bptype") {
            imgdim <- c(800, 200+17*nrow(x))
        } else if (style == "coverage") {
            imgdim <- c(800, 600)
        }
    }
    
    if (plot2file) {
        if (device == "png") {
            png(imgname, imgdim[1], imgdim[2])
        } else if (device == "pdf") {
            pdf(imgname, imgdim[1]/100, imgdim[2]/100)
        } else {
            stop(paste("Unknown device type'",device,"'!  Must be 'png', 'pdf', or NA.",sep=""))
        }
    }
    
    if (style == "bptype") {
        
        if (length(col)>0) {
            pal <- col
        } else {
            pal <- c("green3","blue","cyan","grey","yellow","red")
        }
        pal <- hsv.tweak(pal, s=-0.1, v=-0.1)  # less harsh on eyes
        if (plus) {
            bp.bars <- x[,c(5,6,3,4,7,8)]
            colnames(bp.bars) <- c("PC-CDS","PC-UTR","NCRNA","RIBO","INTRON","INTERGENE")
            bp.cols <- pal
        } else {
            bp.bars <- x[,c(4,5,3,6,7)]
            colnames(bp.bars) <- c("CDS","UTR+NCRNA","RIBO","INTRON","INTERGENE")
            bp.cols <- pal[-2]
        }
        have.ribo <- sum(as.numeric(bp.bars[,"RIBO"]))>0
        
        if (length(genomebp)>0) {
            if (plus) {
                gbar <- genomebp[c(5,4,6,7,3,2)]
            } else {
                gbar <- genomebp[c(5,4,7,3,2)]
            }
            names(gbar) <- NULL
            bp.bars <- rbind2(bp.bars, unlist(gbar))
            rownames(bp.bars)[nrow(bp.bars)] <- "GENOME"
        }
        
        if (!have.ribo) {
            if (plus) {
                bp.bars <- bp.bars[,-4]  # drop empty ribo column
                bp.cols <- bp.cols[-4]
            } else {
                bp.bars <- bp.bars[,-3]  # drop empty ribo column
                bp.cols <- bp.cols[-3]
            }
            if (plus) {
                colnames(bp.bars)[3] <- "NCRNA+RIBO"
            } else {
                colnames(bp.bars)[2] <- "UTR+NC+RIBO"
            }
        }
        
        if (mrna) {
            nc <- ncol(bp.bars)  # may or may not have ribo column
            if (plus) {
                bp.bars[,3] <- rowSums(bp.bars[,1:3])
                bp.bars <- bp.bars[,3:nc]
                bp.cols <- bp.cols[3:nc]
            } else {
                bp.bars[,2] <- rowSums(bp.bars[,1:2])
                bp.bars <- bp.bars[,2:nc]
                bp.cols <- bp.cols[2:nc]
            }
            colnames(bp.bars)[1] <- "MRNA+NCRNA"
#            bp.cols[1] <- "#4455AA"  # RGB average of green3, blue, cyan
            bp.cols[1] <- "steelblue"
        }
        
	title <- ifelse(length(main)>0, main, "Sequenced Bp Per Genomic Feature")
	
        bp.bars2 <- bp.bars/rowSums(bp.bars)
        par(mar=c(5,pmar,4,2), cex=cex, las=1, yaxs="i")
        barplot(t(100*bp.bars2[nrow(bp.bars2):1,]), col=bp.cols, horiz=TRUE, main=title, xlab="Percent Sample Bp In Feature Type", xlim=c(0,130), xaxt="n")
        axis(1, seq(0,100,20))
        legend("topright", pch=15, pt.cex=1.5, bty="n", col=bp.cols, legend=colnames(bp.bars2))
        
    } else if (style == "coverage") {
        
        if (length(col)>0) {
            pal <- col
        } else {
            pal <- rainbow(nrow(x))
        }
        par(cex=cex, las=1)
        if (ncol(x)==101) {
            covg <- x  # looks like coverage data only
        } else if (plus) {
            covg <- x[,28:128]  # assuming full CollectRnaSeqMetrics matrix (plus mode)
        } else {
            covg <- x[,26:126]  # assuming full CollectRnaSeqMetrics matrix (normal mode)
        }
	
	title <- ifelse(length(main)>0, main, "Read Coverage Across Top 1000 Genes")
	
        lineplot(covg, col=pal, lty=lty, lwd=lwd, legend="topleft", main=title, xlab="100 Bins", xaxt="n", ylim=c(0,max(covg)))
        axis(1, at=c(1,51,101), labels=c("5'","<--  100 Bins Along Transcript  -->","3'"))
        
    }
    
    if (plot2file) dev.off()
    if (view) gthumb(imgname)
    if (style == "bptype") invisible(bp.bars2)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "align.stat.plot")
align.stat.plot <- function(x, imgname, imgdim=NULL, cex=par()$cex, device=c("png","pdf"), style=c("tophat","bowtie2-se","bowtie2-pe-reads","bowtie2-pe-pairs","bowtie2-pe-singles","star"), horiz=FALSE, view=FALSE, las=1) {
    
    ## Standard plots for various "align_summary.txt"-type files.
    ## 'x' is either the filename, or a matrix read in from the file
    ## writes directly to 'imgname' using device 'device'
    ## invisibly returns plotted matrix
    
    style <- match.arg(style)
    if (!is.na(device)[1]) device <- match.arg(device)
    
    if (length(x)==1) {  # hopefully, filename
        align <- as.matrix(read.delim(x, as.is=TRUE, row.names=1))
    } else if (is.matrix(x)) {
        align <- x
    } else if (is.data.frame(x)) {
        if (sum(is.na(as.character(x[,1])))==0) {
            ## df with rownames in column 1
            align <- rownamed.matrix(x)
        } else {
            align <- as.matrix(x)
        }
    } else {
        stop("'x' must be a matrix, data.frame, or filename!\n")
    }
    
    ## Refine matrix to be barplotted
    if (style == "tophat" | style == "star") {
        title <- ifelse(style=="tophat","Tophat","STAR")
        if (ncol(align)<5 | ncol(align)>6) stop("'align' matrix must have 5-6 columns!")
                                        # no column rearrangements: already (TOTAL, MAPPED, MONO, MULTI [, OVER], UNMAPPED
        if (ncol(align)==6) {
            colors <- c(1,4,3,7,6,2)   # 6-col has over-multi in col 5; 5-col lacks over-multi
            overN <- sub("Over","",colnames(align)[5])
            colnames(align) <- qw(Total,Mapped,Mono,Multi,Over,Unmapped)
            colnames(align)[5] <- paste(colnames(align)[5],overN,sep="")
        } else {
            colors <- c(1,4,3,7,2)
            colnames(align) <- qw(Total,Mapped,Mono,Multi,Unmapped)
        }
    } else if (style == "bowtie2-se") {
        title <- "Bowtie2 SE"
        if (ncol(align)<5) stop("'align' matrix must have at least 5 columns!")
        colors <- c(1,4,3,7,2)
        align <- align[,1:5]  # TOTAL, MAPPED, MONO, MULTI, UNMAPPED (skipping OVER)
        colnames(align) <- qw(Total,Mapped,Mono,Multi,Unmapped)
    } else if (style == "bowtie2-pe-reads") {
        title <- "Bowtie2 PE, All-Read"
        if (ncol(align)<12) stop("'align' matrix must have at least 12 columns!")
        colors <- c(1,4,3,7,6,2,8,5)
        for (i in 3:4) align[,i] <- 2*align[,i]+align[,(i+5)]
        for (i in 5:7) align[,i] <- 2*align[,i]
        align <- align[,c(1,12,3,4,5,10,11,7)]  # all ends: TOTAL, MAPPED, MONO, MULTI, MAYBE, UNMAPPED, SINGLE, PAIRED
        colnames(align) <- qw(Total,Mapped,Mono,Multi,Discordant,Unmapped,Align-Single,Align-Paired)
    } else if (style == "bowtie2-pe-pairs") {
        title <- "Bowtie2 PE, Paired"
        if (ncol(align)<12) stop("'align' matrix must have at least 12 columns!")
        colors <- c(1,4,3,7,6,2)
        align <- align[,c(2,7,3:6)]  # paired ends: TOTAL, MAPPED, MONO, MULTI, DISCORD, UNMAPPED
        colnames(align) <- qw(Total,Mapped,Mono,Multi,Discordant,Unmapped)
    } else if (style == "bowtie2-pe-singles") {
        title <- "Bowtie2 PE, Unpaired"
        if (ncol(align)<12) stop("'align' matrix must have at least 12 columns!")
        colors <- c(1,4,3,7,2)
        align <- align[,c(6,11,8:10)]  # unpaired ends: TOTAL, MAPPED, MONO, MULTI, UNMAPPED
        align[,1] <- 2*align[,1]
        colnames(align) <- qw(Total,Mapped,Mono,Multi,Unmapped)
    }
    
    ## Set layout and area proportions
    if (horiz) {
        
        layout.mat <- matrix(c(1,1,1,0,6,6,6, 2,3,4,0,7,8,9, 0,5,0,0,0,10,0), nrow=3, ncol=7, byrow=TRUE)
        barmax <- (ncol(align)+1)*nrow(align)  # because 'align' barplots transposed
        xblock <- c(100, 10*barmax, 150)  # default
        heights.vec <- c(80,400,80)  # default
        xspacer <- 40
        
        if (length(imgdim)==0) {
            widths.vec <- c(xblock, 50, xblock)
            imgdim <- c(sum(widths.vec), sum(heights.vec))
        } else {
            heights.vec[2] <- trunc(imgdim[2]-heights.vec[1]-heights.vec[3])
            xblock[2] <- trunc((imgdim[1]-xblock[1]*2-xblock[3]*2-xspacer)/2)
            widths.vec <- c(xblock, 50, xblock)
        }
        
    } else {
        
        layout.mat <- matrix(c(1,1,1, 2,3,4, 0,5,0, 0,0,0, 6,6,6, 7,8,9, 0,10,0), nrow=7, ncol=3, byrow=TRUE)
        barmax <- (ncol(align)+1)*nrow(align)  # because 'align' barplots transposed
        widths.vec <- c(100, 10*barmax, 150)   # default
        yblock <- c(80,400,80)  # default
        yspacer <- 40
        
        if (length(imgdim)==0) {
            heights.vec <- c(yblock, 50, yblock)
            imgdim <- c(sum(widths.vec), sum(heights.vec))
        } else {
            widths.vec[2] <- trunc(imgdim[1]-widths.vec[1]-widths.vec[3])
            yblock[2] <- trunc((imgdim[2]-yblock[1]*2-yblock[3]*2-yspacer)/2)
            heights.vec <- c(yblock, 50, yblock)
        }
        
    }
    
    ## Initialize image
    if (device == "png") {
        png(imgname, imgdim[1], imgdim[2])
                                        #		cex <- 1.2
    } else if (device == "pdf") {
        pdf(imgname, imgdim[1]/100, imgdim[2]/100)
                                        #		cex <- 0.9
    } else {
        stop(paste("Unknown device type'",device,"'!  Must be 'png', 'pdf', or NA.",sep=""))
    }
    par(cex=cex, las=las, xaxs="i")
    nf <- layout(layout.mat, heights=heights.vec, widths=widths.vec, respect=TRUE)
    ## layout.show(10); dev.off(); view.image(imgname); return(layout.mat)
    
    ## Plot Counts Title
    par(mar=c(0,0,0,0), cex=cex, las=las, xaxs="i", yaxs="i")
    null.plot()
    text(0.5, 0.5, labels=paste(title,"Alignments, Counts"), font=2, cex=2)
    
    ## Plot Counts Y-Axis
    par(mar=c(0,0,0,0), cex=cex, las=las, xaxs="i", yaxs="i")
    digits <- as.numeric(unlist(strsplit(format(as.numeric(max(align[,1])),sci=TRUE,digits=2),"e")))  # lead value and magnitude
    dmax <- round(digits[1]+0.01,0)
    axseq <- seq(0, dmax, length.out=dmax+1)
    if (digits[2]<4) {  # max value < 10,000 (rare)
        axlab <- axseq
    } else {
        mod <- digits[2]%%3
        digits[1] <- digits[1]*10^mod  # shift into ones/tens/hundreds form -- whatever is largest order within a power of 1000
        dmax2 <- dmax*10^mod
        digits[2] <- digits[2]-mod  # becomes a power of 1000
        axseq <- seq(0, dmax2, length.out=dmax+1)  # reboot axseq with new dmax 
        axlab <- paste0(axseq, qw(K,M,B,T)[digits[2]/3]) # not going higher than a trillion
    }
    axseq <- axseq*10^digits[2]
    datarange <- c(0,max(c(max(align),max(axseq))))
    null.plot(ylim=datarange)
    axis(2, at=axseq, line=-4, labels=axlab)
    
    ## Plot Counts Bars
    par(mar=c(0,0,0,0), cex=cex, las=las, xaxs="i", yaxs="i")
    b <- barplot(t(align), beside=TRUE, col=colors, xlim=c(1,barmax), ylim=datarange, cex.names=0.9, xaxt="n", yaxt="n")
    
    ## Plot Counts Legend
    par(mar=c(0,0,0,0), cex=cex, las=las, xaxs="i", yaxs="i")
    null.plot()
    legend("top", bty="n", col=colors, pch=15, pt.cex=1.5, legend=colnames(align))
    
    ## Plot Counts X-Axis
    par(mar=c(0,0,0,0), cex=cex, las=las, xaxs="i", yaxs="i")
    null.plot(xlim=c(0.5,barmax))
    axis(1, at=colMeans(b), line=-4, tick=FALSE, labels=rownames(align), padj=0.5)
    
    ## Plot Percents Title
    par(mar=c(0,0,0,0), cex=cex, las=las, xaxs="i", yaxs="i")
    null.plot()
    text(0.5, 0.5, labels=paste(title,"Alignments, Percents"), font=2, cex=2)
    
    ## Plot Percents Y-Axis
    par(mar=c(0,0,0,0), cex=cex, las=las, xaxs="i", yaxs="i")
    axseq <- seq(0, 100, 10)
    null.plot(ylim=c(0,100))
    axis(2, at=axseq, line=-4, labels=axseq)
    
    ## Plot Percents Bars
    par(mar=c(0,0,0,0), cex=cex, las=las, xaxs="i", yaxs="i")
    barplot(100*t(align/align[,1]), beside=TRUE, col=colors, xlim=c(1,barmax), ylim=c(0,100), cex.names=0.9, xaxt="n", yaxt="n")
    
    ## Plot Percents Legend
    par(mar=c(0,0,0,0), cex=cex, las=las, xaxs="i", yaxs="i")
    null.plot()
    legend("top", bty="n", col=colors, pch=15, pt.cex=1.5, legend=colnames(align))
    
    ## Plot Percents X-Axis
    par(mar=c(0,0,0,0), cex=cex, las=las, xaxs="i", yaxs="i")
    null.plot(xlim=c(0.5,barmax))
    axis(1, at=colMeans(b), line=-4, tick=FALSE, labels=rownames(align), padj=0.5)
    
    ## Finish
    dev.off()
    if (view) view.image(imgname)
    invisible(align)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "tophat.align.plot")
tophat.align.plot <- function(x, imgname, imgdim=NULL, cex=par()$cex, device=c("png","pdf"), horiz=FALSE, view=FALSE, las=1) {
    align.stat.plot(x, imgname, imgdim=imgdim, cex=cex, device=device, style="tophat", horiz=horiz, view=view, las=las)
}

apa.names$bio.seq <- c(apa.names$bio.seq, "idxstats.plot")
idxstats.plot <- function(x, readlen, style=c(1:3), imgname=NULL, chrs=NULL, extra.name="Randoms", extra.strings=c("_"), extra.method=c("ignore","merge"), device=c("png","pdf"), imgdim=NULL, cex=NULL, lwd=1) {
	
	## Standard plot for an "all.idxstats.txt" file.
	## 'x' is either the filename, or a matrix read in from the file
	## 'readlen' is the FULL MATE-PAIR read length for the analysis, so enter '200' for PE 100bp reads, e.g.
	## 'style' indicates which plot to plot:
	##         1 = sequencing depth per chrom (lineplot)
	##         2 = alignments per chrom, as % total alignments (lineplot)
	##         3 = mitochondrial seq % per sample (barplot)
	## 
	## invisibly returns one or more plotted matrices
	## 'chrs' selects only these chrs to plot
	## 
	## 'ignore' is a vector of strings to anti-grep from list (e.g. 'ignore=c("random","Un")' remove any chrs with these strings)
	
	device <- match.arg(device)
	extra.method <- match.arg(extra.method)
	if (length(style)==3) style <- style[1]
	if (!(style %in% 1:3)) stop ("'style' argument must be 1, 2, or 3!\n")
	plot2file <- ifelse(is.na(device)|length(imgname)==0, FALSE, TRUE)
	cex <- ifelse(length(cex)>0, cex, ifelse(plot2file, ifelse(device=="png", 1.2, 1), 1))
	
	if (length(x)==1) {  # hopefully, filename
		istat.raw <- as.matrix(read.delim(x, as.is=T, row.names=1))
	} else if (is.matrix(x)) {
		istat.raw <- x
	} else if (is.data.frame(x)) {
		istat.raw <- rownamed.matrix(x)
	} else {
		stop("'x' must be a matrix, data.frame, or filename!\n")
	}
	
	if (length(chrs)>0) {  # select only these chrs
		istat.raw <- istat.raw[match(chrs,rownames(istat.raw)),]
	} else if (length(extra.strings)>0) {  # manage "extra" chromosomes
		w.extra <- mgrepl(extra.strings,rownames(istat.raw))
		if (extra.method == "ignore") {
			istat.raw <- istat.raw[!w.extra,]
		} else if (extra.method == "merge") {
			istat.x <- colSums(istat.raw[w.extra,])
			istat.raw <- rbind2(istat.raw[!w.extra,], istat.x)
			rownames(istat.raw)[nrow(istat.raw)] <- extra.name
		}
	}
	
	chrlens <- istat.raw[,1]
	istat <- istat.raw[,2:ncol(istat.raw)]
	istat.pct <- readlen*istat/chrlens
	mt.seq.pct <- istat[rownames(istat)=="chrM",]/colSums(istat)
	output <- list(
		depth=t(istat.pct[order(rowSums(istat.pct),decreasing=TRUE),]),
		aligns=t(istat)/rowSums(t(istat)),
		mito=100*sort(mt.seq.pct)
	)
	output$aligns <- output$aligns/rowSums(output$aligns)
	
	if (style == 3) {
		if (length(imgdim)==0) imgdim <- c(600,200+50*ncol(istat))
		mar <- c(4,6,4,2)
		xaxs <- "r"
		las <- 1
	} else {
		if (length(imgdim)==0) imgdim <- c(700,600)
		mar <- c(6,5,4,2)
		xaxs <- "i"
		las <- 2
	}
	if (plot2file) png(imgname, imgdim[1], imgdim[2])
	par(mar=mar, cex=cex, las=las, xaxs=xaxs)
	
	if (style == 1) {
		N <- nrow(output$depth)
		lineplot(log10(output$depth), ylim=c(-3,4), col=rainbow(N+1)[1:N], main="Log10 Mean Sequencing Depth per Chromosome", yaxt="n", xlab="", ylab="", lwd=lwd)
		axis(2, at=-3:4, labels=10^c(-3:4))
	} else if (style == 2) {
		N <- nrow(output$aligns)
		lineplot(output$aligns, col=rainbow(N+1)[1:N], main="Alignments per Chromosome, as Pct Total", xlab="", ylab="", lwd=lwd)
	} else if (style == 3) {
		maxpct <- max(output$mito)
		xmax <- ifelse(maxpct-floor(maxpct)>0.25, ceiling(maxpct), maxpct)
		barplot(output$mito, beside=TRUE, horiz=TRUE, xlim=c(0,xmax), main="Mitochondrial Sequence Percent")
	}
	
	if (plot2file) dev.off()
	invisible(output)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "seq.unq.plot")
seq.unq.plot <- function(fqr, histo=FALSE, style=c("bars","lines","cdf")) {
    
    ## Various fastq-sequence-uniqueness plots
    
    stop("Function 'seq.unq.plot' ready to run!")  # under construction

    fqr <- as.matrix(read.delim("fqReads.txt", row.names=1))
    png("images/unq_seq_bars.png", 600, 500)
    par(cex=1.1, las=1)
    barplot(fqr[,3], beside=T, main="Fastq Unique Sequence Percent")
    dev.off(); gthumb("images/unq_seq_bars.png")

    fqr2 <- as.matrix(read.delim("fqReads2.txt", row.names=1))
    colnames(fqr2) <- sub("^X","",sub("10.x","10+x",colnames(fqr2)))
    fqr2.n <- fqr2[,2:11]
    fqr2.p <- fqr2[,12:21]
    fqr2.nx <- t( t(fqr2.n)*c(1:10) )  # multiply seq counts times their number of occurrences
    fqr2.nx[,10] <- fqr2.nx[,10] + (fqr2[,1]-rowSums(fqr2.nx))  # any leftover is from the "10+" population; add to "10+"
    fqr2.px <- fqr2.nx/fqr[,1]
    fqr2.cp <- t(apply(fqr2.px,1,cumsum))
    colnames(fqr2.cp) <- c("1x",sub("PCT.","\U2264",colnames(fqr2.p)[2:10]))
    colnames(fqr2.p) <- sub("PCT.","",colnames(fqr2.p))

    ## recapitulates fastqc's histo, but with _real values_ on the y axis!
    png("images/unq_seq_histo.png", 600, 500)
    par(cex=1.2, las=1)
    lineplot(fqr2.px, col=1:8, main="Fastq Sequence Uniqueness Histogram")
    dev.off(); gthumb("images/unq_seq_histo.png")

    par(cex=1.2, las=1)
    lineplot(100*fqr2.cp, col=1:8, lwd=2, main="Fastq Sequence Uniqueness, CDF", legend="topleft", xlab="Pct Reads \U2264 Given x")

    
}


apa.names$bio.seq <- c(apa.names$bio.seq, "alndup.plot")
alndup.plot <- function(x, imgname, device=c("png","pdf")) {
    
    ## plots sequence duplication levels, given a bam_stats output txt file.
    ## 'x' is either the filename, or a matrix read in from the file
    ## writes directly to 'imgname' using device 'device'
    ## invisibly returns plotted matrix
    
    bstat <- t(read.delim(x, as.is=T, row.names=1))
    bstat <- bstat[c(1,3,5:6,8,10:12,2,4,7,9),]
    
    png(imgname, 1000, 600)
    par(mfrow=c(1,2), mar=c(4,7,4,2), cex=1.2, las=1)
    pct <- 100*sort(bstat[8,]/bstat[7,])
    maxpct <- max(pct)
    xmax <- ifelse(maxpct-floor(maxpct)>25, ceiling(maxpct), maxpct)
    barplot(pct, col="cornflowerblue", horiz=T, xlim=c(0,xmax), main="% Unique Pos in All Alignments")
    barplot(100*bstat[11:12,order(bstat[11,])], col=c("olivedrab","gold3"), horiz=T, main="Primary vs Secondary Alignments %")
    mtext("Primary",3,-1,at=0,adj=0); mtext("Secondary",3,-1,at=100,adj=1)
    dev.off()
    
    invisible(bstat)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "aln.cons.heatmap")
aln.cons.heatmap <- function(x, view=FALSE, too.low=0.25, cex=1, pmar=c(5,5)) {
    
    ## Turn a multiple alignment, formatted as a character matrix (rows=genes, cols=MA positions) into a consensus-heatmap
    ## MA consensus is called and compared to columns.  In each column, integers -2:5 represent (and default colors are):
    ##   -2: gaps (white)
    ##   -1: uncallable consensus (grey)
    ##    0: singleton calls (dodgerblue3)
    ##    1: alt, insufficient coverage (pink1)
    ##    2: consensus, insufficient coverage (seagreen1)
    ##    3: alt calls, sufficient coverage (red3)
    ##    4: consensus calls, sufficient coverage (green3)
    ##    5: stops (black); ONLY IF stops=TRUE
    ## The heatmap matrix is numeric, and can be plotted automatically (view=TRUE).
    ## If 'consensus=TRUE', a consensus row is added.
    ##  *** INACTIVE *** 'too.low' is a threshold for the percent of sequences reporting at a position.  
    ##   If % reporting sequences at position x is <= too.low, the position is considered "too low" for consensus-calling and calls are given a different value.
    ##   This does not conflict with singleton-reporting positions, which are always given their own value.
    ##   Also, 'too.low' doubles as a callable-consensus cutoff in the same way: If percent of consensus residues at position x is <= too.low, then no consensus is called
    ## 'stops' is either NULL, or a color top plot stop codons with.  If NULL, stops are treated as though they were amino acids.
    ##   Use of 'stops' also extends value-color mappings; stop positions get -2 and col = c(stops, col)
    
    mtl <- merge.table.list(apply(x, 2, table))
    mtl2 <- mtl[,ncol(mtl):1]
#    if (!gap.cons) mtl2 <- mtl2[,colnames(mtl2)!="-"]
#    cons <- colnames(mtl2)[apply(mtl2,1,which.max)]   # reverse columns on mtl so that non-residues like "-", "*" are least accessible to which.max
    cons <- rep("",ncol(x))
    call.solo <- rowSums(mtl2[,colnames(mtl2)!="-"]) == 1                  # positions for which N calls == 1
#    call.toolow <- rowSums(mtl2[,colnames(mtl2)!="-"])/nrow(x) <= too.low  # positions for which N calls are too low
#    cons.toolow <- apply(mtl2,1,max)/ncol(mtl) <= too.low                  # positions for which N consensus calls are too low
    hm <- x
    col <- c("white","grey","dodgerblue","lightcoral","green3","red4","darkgreen","black")  # default palette
    pal <- data.frame(VALUE=-2:5,COLOR=col,MEANING=c("Gap","No Consensus","Singleton","Alt, too low to call","Cons, too low to call","Alt, high enough to call","Cons, high enough to call","Stop codon (optional)"))
    stats <- data.frame(STAT=qw(OK,LOWCALL1,LOWCALL2,LOWCONS,SOLO), N=rep(0,5))
    for (i in 1:ncol(x)) {
        nongap <- which(x[,i]!="-")
        frq.gap <- table(x[,i])
        frq.nongap <- table(x[nongap,i])
        xcons.gap <- names(frq.gap)[which.max(frq.gap)]
        xcons.nongap <- names(frq.nongap)[which.max(frq.nongap)]
        if (call.solo[i]) {
            istat <- "SOLO"
            hm[nongap,i] <- 0
            cons[i] <- "."
#        } else if (call.toolow[i]) {
#            ## to few calls to allow consensus
#            if (sum(x[nongap,i]==xcons.nongap) == 1) {
#                ## more than one non-gap call, but none agree
#                istat <- "LOWCALL1"
#                hm[nongap,i] <- -1  # won't call a consensus of 1
#                cons[i] <- ""
#            } else {
#                ## more than one non-gap call, and at least two agree
#                istat <- "LOWCALL2"
#                hm[nongap[x[nongap,i]==xcons.nongap],i] <- 2
#                hm[nongap[x[nongap,i]!=xcons.nongap],i] <- 1
#                cons[i] <- tolower(xcons.nongap)
#            }
#        } else if (cons.toolow[i]) {
#            istat <- "LOWCONS"
#            hm[nongap,i] <- -1
#            cons[i] <- "."
        } else if (length(frq.nongap)>1 & length(unique(frq.nongap))==1) {
            ## more than one non-gap call exists, and all have same freq; consensus impossible
            hm[nongap,i] <- -1
        } else {
            istat <- "OK"
            if (xcons.gap=="-") {
                ## gap is most-frequent "base"
                hm[x[,i]==xcons.nongap,i] <- 2
                hm[nongap[x[nongap,i]!=xcons.nongap],i] <- 1
                cons[i] <- xcons.gap
            } else {
                ## a non-gap base is most frequent
                hm[x[,i]==xcons.nongap,i] <- 4
                hm[nongap[x[nongap,i]!=xcons.nongap],i] <- 3
                cons[i] <- xcons.nongap
            }
        }
        hm[x[,i]=="-",i] <- -2
        stats[stats[,1]==istat,2] <- stats[stats[,1]==istat,2] + 1
    }
    if (any(x=="*")) {
        hm[x=="*"] <- 5
    } else {
        col <- col[1:7]  # remove black from last position; don't need it
    }
    mode(hm) <- "numeric"
    if (view) myImagePlotUltra(hm, palette=col, show.scale=FALSE, cex=cex, pmar=pmar, main="Multialignment Conservation")
    invisible(list(hm=hm,cons=cons,palette=pal,table=mtl,stats=stats))
}


