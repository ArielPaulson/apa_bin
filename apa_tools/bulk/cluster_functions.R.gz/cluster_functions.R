

apa.names$clustering <- c(apa.names$clustering, "template.match")
template.match <- function(obj, templates, tiebreak=c("random","both","drop"), p.values=TRUE, anti=FALSE) {
	
	## MeV-style "Pavlidis Template Matching" which takes a dataset and correlates each row to a set of templates.
	## 'templates' is vector, list of vectors, or numeric matrix (of row vectors); each vector specifies an abstract trend across samples (e.g. c(0,0,0,1,1,1), c(1,2,3,2,1), etc.).
	## - Template length must equal ncol(obj)
	## Rows are assigned to the template to which they correlate most strongly.
	## - In the rare case that a vector matches 2 templates equally strongly, 'tiebreak' takes effect.
	## - 'tiebreak' indicates whether to assign row to one best template randomly, or assign to both, or to not assign the row at all.
	## 'p.values' controls returning of p-values along with R-values
	## 'anti' controls the allowing of anticorrelators to go into their own clusters:
	## - if FALSE: template N (+) corrs assigned to 'N'
	## - if TRUE:  template N (+) corrs assigned to 'N' and (-) corrs assigned to '-N' 
	
	tiebreak <- match.arg(tiebreak)
	if (is.nlv(templates)) {
		temp.names <- 1
		templates <- list(templates)
	} else if (is.list(templates)) {
		temp.names <- ternary(length(names(templates))==0, 1:length(templates), names(templates))
	} else if (is.matrix(templates)) {
		temp.names <- ternary(length(rownames(templates))==0, 1:nrow(templates), rownames(templates))
		templates <- lapply(1:nrow(templates), function(i){templates[i,]})
	} else {
		stop ("Unknown object type for 'templates': must be vector, list, or matrix!\n")
	}
	T <- length(templates)
	R <- nrow(obj)
	if (T==0) stop("No templates to correlate to!\n")
	if (R==0) stop("'obj' is empty!\n")
	if(!is.matrix(obj)) obj <- as.matrix(obj)
	multi <- FALSE
	matches <- new.list(qw(template,R,p.val))
	if (p.values) {
		cor.p <- matrix(0, nrow(obj), T*2)
		for (i in 1:T) {
#			IM(" Template",i)
			j <- (i-1)*2+1
			suppressWarnings(x <- apply(obj, 1, function(x) unlist(cor.test(x,templates[[i]])[c(4,3)]) ))
			cor.p[,c(j,j+1)] <- t(x)
			# if (is.matrix(x)) {
				# cor.p[i] <- t(x)
			# } else {
				# cor.p[i] <- do.call(rbind, x)
			# }
		}
#		cor.p <- do.call(cbind, cor.p)
		cors <- as.matrix(cor.p[,seq(1, T*2, 2)])  # R value columns
		pval <- as.matrix(cor.p[,seq(2, T*2, 2)])  # p value columns
		pval[is.na(pval)] <- 1
		apval <- apply(pval, 2, p.adjust, method="BH")
	} else {
		suppressWarnings(cors <- as.matrix(sapply(templates, function(x) cor(x, t(obj)) )))
	}
	na <- which(apply(is.na(cors), 1, all))
	if (length(na)>0) {   # invariant genes exist
		invar <- which(apply(is.na(cors), 2, all))   # does an invariant template exist?
		if (length(invar)>1) { 
			IM("More than one invariant template exists!  Selecting first one.\n") 
			invar <- invar[1]
		}
		cors[na,invar] <- 1   # assign invariant genes to invariant template
	}
#	return(cors)
#	maxpos <- as.list(apply(cors, 1, function(i){which(i==max(i))}))
	if (anti) {
		maxany <- as.list(apply(abs(zerofy(cors)), 1, function(i) which(i==max(i)) ))
		maxneg <- as.list(apply(zerofy(cors), 1, function(i) which(i==min(i)) ))
	} else {
		maxany <- as.list(apply(zerofy(cors), 1, function(i) which(i==max(i)) ))
	}
	x <- which(listLengths(maxany)>1)
	if (length(x)>0) {
		IM(length(x),"rows had > 1 best template!\n")
		if (tiebreak == "both") {
			multi <- TRUE
		} else {
			if (tiebreak == "drop") {
				# maxany[[x]] <- maxpos[[x]] <- maxneg[[x]] <- NA
				for (i in x) maxany[[i]] <- NA
			} else {
				for (i in x) maxany[[i]] <- sample(maxany[[i]], 1)
#				if (maxany[[x]] %in% maxpos[[x]]) maxpos[[x]] <- maxany[[x]]
#				if (maxany[[x]] %in% maxmin[[x]]) maxmin[[x]] <- maxany[[x]]
			}
		}
	}
	# matches$template <- maxpos
	# matches$R <- lapply(1:length(maxpos), function(i){ cors[i,maxpos[[i]]] })
	matches$template <- maxany
	matches$R <- lapply(1:length(maxany), function(i) ifelse(is.na(i),i,cors[i,maxany[[i]]]) )
	if (p.values) {
		# matches$p.val <- lapply(1:length(maxpos), function(i){ pval[i,maxpos[[i]]] })
		matches$p.val <- lapply(1:length(maxany), function(i) pval[i,maxany[[i]]] )
		matches$adj.p.val <- lapply(1:length(maxany), function(i) apval[i,maxany[[i]]] )
	}
	if (multi) {
		if (anti) {
			for (i in 1:length(matches$R)) {
				n <- which(matches$R[[i]] %in% maxneg[[i]])
				if (length(n)>0) matches$R[[i]][n] <- -1 * matches$R[[i]][n]
			}
		}
	} else {
		for (i in 1:length(matches)) matches[[i]] <- unlist(matches[[i]])
		matches <- as.matrix(do.call(cbind, matches))  # if matches are singular, we can compress data structure
		if (anti) matches[,1] <- matches[,1] * sign(matches[,2])
	}
	return(matches)
}


apa.names$clustering <- c(apa.names$clustering, "slope.clust")
slope.clust <- function(obj, dirs=c(-1,0,1), tolerance=NA) {
    
    ## ********  THIS METHOD INTENDED FOR Z-SCORE ROW-NORMALIZED DATA ONLY  ********
    ## Profile-based clustering of genes using a "qualitative" method based on slope signs.
    ## All possible clusters are defined in advance, then genes are assigned to each based on profile characteristics.
    ## In a nutshell, for each gene, the slopes between sample points can be either increasing, decreasing, or invariant (within some tolerance).
    ## Thus 3 choices ^ (N-1) slopes => possible clusters.
    ## Choose invariance tolerance (if any), and assign genes to their appropriate cluster.
    ## 'tolerance' sets invariance tolerance, as the maximum number of standard deviations (distance on z-scale) of ignorable change between two points.
    ## - 'tolerance=NA' results in template matching to the cluster profiles.
    ## 'DBI' turns on reporting of DBI/intracluster variance.  These may crash for large datasets.  Not available if tolerance is NA.
    
    tmatch <- ifelse(is.na(tolerance), TRUE, FALSE)
    ndirs <- data.frame(c(-1,0,1), qw(DN,NC,UP))
    N <- ncol(obj)-1
    
    profiles <- t(apply(permn2(length(dirs), N, replacement=TRUE), 1, function(x) dirs[x] ))
    P <- nrow(profiles)
    map <- matrix("NA", nrow(obj), 1, F, list(rownames(obj),"Cluster"))
    centers <- matrix(0, P, ncol(obj))
    
    clusters <- vector("list", length=P+1)  # extra 1 for the "unclusterable cluster", just in case
    names(clusters) <- c(apply(profiles, 1, function(x) paste( ndirs[match(x,ndirs[,1]),2], collapse="." ) ), "NA")
    sets <- new.list(names(clusters))
    lost <- rep(0, P)
    
    ## Clustering
    if (tmatch) {
        V <- 1:ncol(obj)   # template values
        templates <- matrix(0, nrow(profiles), ncol(obj))
        for (i in 1:P) {
            templates[i,1] <- 0
            for (j in 1:N) {
                templates[i,(j+1)] <- templates[i,j] + profiles[i,j]
            }
        }
        tmatches <- template.match(obj, templates, p.values=FALSE, anti=FALSE)
        map <- names(clusters)[tmatches[,1]]
    } else {
        prof <- t(apply(obj, 1, function(x) diff(x) ))
        sprof <- sign(prof)
        if (!is.na(tolerance)) {
            sub.tol <- abs(prof) <= tolerance
            sprof[sub.tol] <- 0  # slopes within tolerance limit become "no-slopes"
        }
        for (i in 1:P) {
            set <- apply(sprof, 1, function(x) all(x==profiles[i,]) )
            map[set] <- names(clusters)[i]
        }
    }
    
    return(map)
}


apa.names$clustering <- c(apa.names$clustering, "binary.clust","bclust")
bclust <- binary.clust <- function(obj, method=c("euclidean","pearson","spearman","mean","min-mean","max-mean","median","min-median","max-median"), linkage=c("average","median","centroid","ward","mcquitty","single","complete"), present=NA, by.max=FALSE, by.min=FALSE) {
    
    ## Pre-clusters rows in a heatmap into blocks, according to which columns are present/absent
    ## Then hierarchically clusters within blocks, according to distance method 'method'
    ## present/absent cutoff determined by value of 'present', which is minimum present value.  Values < 'present' treated as NA.
    ## 'obj' is a numeric matrix
    ## output is length-2 list: 1=row ordering vector, 2=list of clusters
    ## 'by.max=TRUE' changes block definitions from present/absent to which.max on columns (thus rows with max in col 1 come first, then rows with max in col 2, etc)
    
    method <- match.arg(method)
    linkage <- match.arg(linkage)
    if (by.max & by.min) stop("'by.max' and 'by.min' cannot both be TRUE !\n")
    
    if (nrow(obj)==1) return(list(order=1,clusters=list(1)))
    
    if (length(rownames(obj))==0) rownames(obj) <- 1:nrow(obj)
    old.rownames <- rownames(obj)
    
    if (by.max) {
        row.blocks <- apply(obj, 1, which.max)
    } else if (by.min) {
        row.blocks <- apply(obj, 1, which.min)
    } else {
        ##block.patterns <- permn2(0:1, ncol(obj), TRUE)
        ##block.patterns <- block.patterns[order(rowSums(block.patterns),decreasing=TRUE),ncol(obj):1]
        ##block.codes <- apply(block.patterns, 1, paste, collapse="")
        
        obj.bin <- obj
        for (i in 1:ncol(obj)) {  # going by column in case of very large matrices -- may be unable to subscript entire thing
            if (is.na(present)) {
                obj.bin[!is.na(obj.bin[,i]),i] <- 1
                obj.bin[is.na(obj.bin[,i]),i] <- 0
            } else {
                obj.bin[obj.bin[,i]<present,i] <- NA
                obj.bin[obj.bin[,i]>=present,i] <- 1
                obj.bin[is.na(obj.bin[,i]),i] <- 0
            }
        }
        obj.codes <- apply(obj.bin, 1, paste, collapse="")
        block.codes <- rev(sort(unique(obj.codes)))  # not the exhaustive list -- which could take hours to calculate on a large dataset
        row.blocks <- sapply(obj.codes, function(x) which(block.codes==x) )
    }
    
    block.rows <- split(1:nrow(obj), row.blocks)
    block.rows <- blocks.ord <- blocks.clust <- block.rows[order(as.numeric(names(block.rows)))]  # put blocks in numeric order, if >= 10 blocks
    B <- length(block.rows)
    
    ##ordfun <- get(ifelse(by.max, "max", ifelse(by.min, "min", "mean")))
    clustfun <- switch(
        method,
        "euclidean"=function(x){ reorder.hclust2(hclust(dist(zerofy(x)),linkage),zerofy(x),mean)$order },
        ##"euclidean"=function(x){ reorder.hclust2(hclust(dist(zerofy(x)),linkage),zerofy(x),ordfun)$order },
        "pearson"=function(x){ hclust(distance(zerofy(x)),linkage)$order },
        "spearman"=function(x){ hclust(distance(zerofy(x),"spearman"),linkage)$order },
        "mean"=function(x){ rev(order(rowMeans(zerofy(x)))) },
        "min-mean"=function(x){ rev(order(rowMeans(zerofy(x[,which.min(x[1,])])))) },
        "max-mean"=function(x){ rev(order(rowMeans(zerofy(x[,which.max(x[1,])])))) },
        "median"=function(x){ rev(order(rowMedians(zerofy(x)))) },
        "min-median"=function(x){ rev(order(rowMedians(zerofy(x[,which.min(x[1,])])))) },
        "max-median"=function(x){ rev(order(rowMedians(zerofy(x[,which.max(x[1,])])))) }
    )
    
    for (i in 1:B) {
        if (length(block.rows[[i]])>1) {
            blocks.ord[[i]] <- block.rows[[i]][clustfun(obj[block.rows[[i]],,drop=FALSE])]
        } else {
            blocks.ord[[i]] <- block.rows[[i]]
        }
        blocks.clust[[i]] <- obj[blocks.ord[[i]],,drop=FALSE]
    }
    names(blocks.ord) <- colnames(obj)[as.numeric(names(blocks.ord))]
    
    return(list(order=nameless(unlist(blocks.ord)),clusters=blocks.ord))
}


apa.names$clustering <- c(apa.names$clustering, "split.clust")
split.clust <- function(x, p, by=c("rows","cols"), method="euclidean", linkage="average", reorder=FALSE, p.clust=FALSE) {
    ## 'x' is a matrix to cluster
    ## 'p' is a list of vectors partitioning the rows OR cols of 'x'
    ## 'by' indicates that 'p' applies to rows of x, or cols of x
    ## 'p.clust' also clusters the means of the rows/cols of 'p', thus reordering elements of 'p'
    ## 'method' is passed to dist() (or distance(), if needed); 'minkowski' not supported.
    ## 'linkage' is passed to hclust()
    ## returns a modified 'p', where each vector is now clustered
    
    by <- match.arg(by)
    psum <- sum(listLengths(p))
    x <- as.matrix(x)
    P <- length(p)
    if (by=="rows") {
        if (psum!=nrow(x)) stop(psum," != ",nrow(x))
        x2 <- lapply(p, function(v) x[v,] )
    } else if (by=="cols") {
        if (psum!=ncol(x)) stop(psum," != ",ncol(x))
        x2 <- lapply(p, function(v) t(x[,v]) )
    }
    
    if (!(linkage %in% c("ward.D","ward.D2","single","complete","average","mcquitty","median","centroid"))) {
        stop("Unknown 'linkage'\n")
    }
    
    if (method %in% c("euclidean","maximum","manhattan","canberra","binary")) {
        d <- dist
    } else if (method %in% c("pearson","pearson2","spearman","spearman2","kendall","r2","adjusted.r2","shape","silhouette","mahalanobis","jaccard","venn","edit","tile")) {
        d <- distance
    } else {
        stop(paste0("Unknown method '",method,"'\n"))
    }
    if (reorder) {
        x3 <- lapply(1:P, function(i) p[[i]][reorder.hclust2(hclust(d(x2[[i]],method),linkage),x2[[i]],mean)$order] )
    } else {
        x3 <- lapply(1:P, function(i) p[[i]][hclust(d(x2[[i]],method),linkage)$order] )
    }
    
    if (p.clust) {
        x2m <- do.call(rbind,lapply(x2,colMeans))
        if (reorder) {
            p.ord <- reorder.hclust2(hclust(d(x2m,method),linkage),x2m,mean)$order
        } else {
            p.ord <- hclust(d(x2m,method),linkage)$order
        }
        x3 <- x3[p.ord]
    }
    
    x3
}


apa.names$clustering <- c(apa.names$clustering, "subcluster")
subcluster <- subcluster <- function(x, map, ord, method=c("reordered.euclidean","euclidean","binary","manhattan","canberra","pearson","spearman","mean","mean-min","mean-max","median","median-min","median-max"), linkage=c("average","median","centroid","ward","mcquitty","single","complete")) {
    
    ## Breaks an object into row-slices, clusters them separately, then re-assembles.
    ## 'x' is a numeric matrix to cluster.
    ## 'map' is a row grouping vector for 'x'.
    ## 'ord' is an ordering, a vector of unique values in 'map', in the order to reassemble them.
    
    method <- match.arg(method)
    linkage <- match.arg(linkage)
    if (nrow(x)==1) return(list(order=1,clusters=list(1)))
    
    if (!is.matrix(x) | !(is.numeric(x) | is.integer(x))) stop("")
    blocks.ord <- new.list(ord)
    block.rows <- split(1:nrow(x), map)
    block.rows <- block.rows[match(ord, names(block.rows))]
    B <- length(block.rows)
    
    clusterfunc <- switch(
        method,
        "reordered.euclidean"=function(x){ reorder.hclust2(hclust(dist(zerofy(x)),linkage),zerofy(x),mean)$order },
        "euclidean"=function(x){                           hclust(dist(zerofy(x)),linkage)$order                 },
        "binary"=function(x){                              hclust(dist(zerofy(x),"binary"),linkage)$order        },
        "manhattan"=function(x){                           hclust(dist(zerofy(x),"manhattan"),linkage)$order     },
        "canberra"=function(x){                            hclust(dist(zerofy(x),"canberra"),linkage)$order      },
        "pearson"=function(x){                             hclust(distance(zerofy(x)),linkage)$order             },
        "spearman"=function(x){                            hclust(distance(zerofy(x),"spearman"),linkage)$order  },
        "mean"=function(x){                rev(order(rowMeans(zerofy(x))))                                       },
        "mean-min"=function(x){            rev(order(rowMeans(zerofy(x[,which.min(x[1,])]))))                    },
        "mean-max"=function(x){            rev(order(rowMeans(zerofy(x[,which.max(x[1,])]))))                    },
        "median"=function(x){              rev(order(rowMedians(zerofy(x))))                                     },
        "median-min"=function(x){          rev(order(rowMedians(zerofy(x[,which.min(x[1,])]))))                  },
        "median-max"=function(x){          rev(order(rowMedians(zerofy(x[,which.max(x[1,])]))))                  }
    )
    
    for (i in 1:B) {
        li <- length(block.rows[[i]])
        if (li==0) next
        do.clust <- ifelse(li>2 | (li>1 & method %in% qw(mean,median)), TRUE, FALSE)
        if (do.clust) {
            blocks.ord[[i]] <- block.rows[[i]][clusterfunc(x[block.rows[[i]],,drop=FALSE])]
        } else {
            blocks.ord[[i]] <- block.rows[[i]]
        }
    }

    cl.id <- rep(ord,times=listLengths(blocks.ord))
    return(list( order=nameless(unlist(blocks.ord)), clusters=blocks.ord, clust.id=cl.id, clust.bin=(as.numeric(factor2(cl.id))%%2==1)+0 ))
}


apa.names$clustering <- c(apa.names$clustering, "kmeans.consensus")
kmeans.consensus <- function(obj, centers, iter.max=5000, nstart=1, algorithm=c("Hartigan-Wong","Lloyd","Forgy","MacQueen"), trials=11, r.thresh=1, stable=0.5, more=FALSE, verbose=FALSE) {
    
    ## Iterates a k-means for 'trials' trials and assigns genes to clusters based on the most-prevalent mapping.
    ## Genes which have no consensus mapping go to "Outlier" cluster.
    ## Consensus clustering maps are made from trials with 1:1 cluster relationships.  
    ##   This is ascertained by cluster profile correlations between trial pairs; each trial-i cluster must have 1 and only 1 trial-j cluster with max R and R >= 'r.thresh'.
    ##   Thus cluster identity across trials means deciding which trial-j cluster correlates most with given trial-i cluster, as long as the R value passes the threshold.
    ##   If any trial-i cluster has 0 or > 1 best correlator in trial j, then the two trials are not 1:1.
    ## It can emerge that a given dataset has > 1 stable maps, i.e., 2+ ways in which it can be repeatably clustered:
    ##   For this reason 'trials' should be odd, to facilitate tie-breaking.
    ## 'r.thresh' is an R value on [-1,1].  Higher values = higher stringency for cluster similarity.
    ## 'stable' is a stability threshold percent on [0,1].  
    ##   A gene is assigned to a cluster if it occurs in that cluster in > 'stable'% of trials.  Thus 'stable' should always be >= 0.5
    ## 'more' returns not just the final clustering(s), but a variety of intermediate data for inspection or debugging
    
    algorithm <- match.arg(algorithm)
    if (is.data.frame(obj)) obj <- as.matrix(obj)
    if (is.na(r.thresh)) r.thresh <- -2  # below lowest possible
    nr <- nrow(obj)
    nc <- ncol(obj)
    if (length(centers)>1) {
        centers <- as.matrix(centers)
        N <- nrow(centers)
    } else {
        N <- centers
    }
    km <- vector("list", length=trials)  # initially
    km2km <- vector("list", length=trials)
    names(km2km) <- paste0("Trial", 1:trials)
    genemap.init <- matrix(0, nrow(obj), trials, F, list(rownames(obj),1:trials))
    
    for (i in 1:trials) {
        if (verbose) IM("Running Trial",i)
        km2km[[i]] <- vector("list", length=trials)  # one element per row, col
        km[[i]] <- kmeans(x=obj, centers=centers, iter.max=iter.max, nstart=nstart, algorithm=algorithm)
        genemap.init[,i] <- km[[i]]$cluster
    }
    
    if (verbose) IM("Evaluating Trials")
    trial.equiv <- matrix(0, trials, trials)
    for (i in 1:trials) {
        iclusters <- lapply(split(1:nr, km[[i]]$cluster), function(x) obj[x,] )
        icm <- t(sapply(iclusters, colMeans))
        rownames(icm) <- paste0("Trial",i,".Cluster",1:N)
        trial.equiv[i,i] <- 1
        for (j in 1:trials) {
            if (i <= j)  next    # keep it triangular; compare later trials to earlier
            jclusters <- lapply(split(1:nr, km[[j]]$cluster), function(x) obj[x,] )
            jcm <- t(sapply(jclusters, colMeans))
            rownames(jcm) <- paste0("Trial",j,".Cluster",1:N)
            km2km[[i]][[j]] <- list(icm=icm, jcm=jcm, corr=corr.mat(t(icm),t(jcm)))  # correlate cluster mean profiles
            ## equivalence decided on max R value, but only if R >= r.thresh; may return > 1
            km2km[[i]][[j]]$eq <- lapply(1:N, function(x){ y=zapsmall(km2km[[i]][[j]]$corr[,x]); z=which(y==max(y)&y>=r.thresh); ifelse(length(z)>0,z,NA) })  # TEST ON COLS NOT ROWS: always j relative to i
            one2one <- all(sapply(km2km[[i]][[j]]$eq,length)==1) & length(unique(unlist(km2km[[i]][[j]]$eq)))==N
            if (one2one) {
                onto <- sum(!sapply(km2km[[i]][[j]]$eq, is.na))==N
                if (onto) trial.equiv[i,j] <- trial.equiv[j,i] <- 1  # bijective trial pairs
            }
        }
        km2km[[i]] <- km2km[[i]][listLengths(km2km[[i]])>0]  # drop all unfilled [[j]] elements
    }
    
    if (verbose) IM("Finalizing")
    trial.sets <- clustermap <- gene.stability <- conn.mat.subgraphs(trial.equiv)  # a mapping consists of a set of equivalent trials.  Ideally there will be only one.
    print(trial.sets)
    tso <- hclust(dist(trial.equiv,"binary"),"average")$order
    teo <- trial.equiv[tso,tso]; dimnames(teo) <- list(tso,tso)
    tNA <- !(rownames(teo) %in% unlist(trial.sets))
    teo[tNA,tNA][teo[tNA,tNA]==1] <- 0.5
    dev.new(); mipu(teo)
    
    if (length(trial.sets)==0) { 
        IM("Failed: trials were 0% stable.\n")
        if (more) {
            return(list(km2km=km2km, genemap.init=genemap.init, trial.equiv=trial.equiv))
        } else {
            return()
        }
    } else {
        lm <- length(trial.sets)
        llm <- listLengths(trial.sets)
        trial.sets <- trial.sets[order(llm,decreasing=TRUE)]
        clustermap.complete <- clustermap
        for (i in 1:lm) {
            clustermap[[i]] <- matrix(0, N, length(trial.sets[[i]]), F, list(1:N,trial.sets[[i]]))
            clustermap[[i]][,1] <- 1:N  # reference
            mapi <- trial.sets[[i]][1]
            for (j in 2:length(trial.sets[[i]])) {
                mapj <- trial.sets[[i]][j]
                clustermap[[i]][,j] <- unlist(km2km[[mapj]][[mapi]]$eq)  # mapj is the trial being compared; mapi is the trial it is compared to
            }
            clustermap.complete[[i]] <- clustermap[[i]][,colSums(is.na(clustermap[[i]]))==0]
        }
        
        topm.t <- max(sapply(clustermap,ncol))  # n trials in top map(s)
        topm.n <- sum(sapply(clustermap,ncol)==topm.t)  # n top map(s)
        topm.w <- which(sapply(clustermap,ncol)==topm.t)  # which top map(s)
        topm.c <- sapply(clustermap.complete[topm.w], ncol)  # n bijective trials in top map(s)
        top.top <- which(topm.c==max(topm.c))  # most bijective trials of the top map(s)
        if (topm.n > 1 & length(top.top)>1) {
            IM(paste("Failed:",topm.n,"top-ranked clustermaps observed, with ",topm.t,"/",trials," trials and ",max(topm.c)," bijectives!  Increase 'trials', 'nstart' or maybe 'iter.max' to break tie.\n"))
            if (more) {
                return(list(trial.sets=trial.sets, km2km=km2km, genemap.init=genemap.init, clustermap=clustermap, trial.equiv=trial.equiv))
            } else {
                return()
            }
        }
        
        IM(paste0("Succeeded: 1 best clustermap with ",topm.t,"/",trials," trials, of which ",max(topm.c)," were bijective.\n"))
        init.clustering <- matrix(genemap.init[,1:lm], nrow(obj), lm, F, list(rownames(obj),1:lm))  # initialize
        genemap.final <- genemap.init
        for (i in 1:lm) {
            maptrials <- as.numeric(colnames(clustermap[[i]]))
            nmt <- length(maptrials)
            maptrials.ok <- maptrials[colSums(is.na(clustermap[[i]]))==0]
            nmo <- length(maptrials.ok)
            init.clustering[,i] <- genemap.init[,maptrials.ok[1]]
            gene.stability[[i]] <- apply(genemap.init[,maptrials], 1, function(x) sum(x==clustermap[[i]][x[1],]) )
            init.clustering[which(sapply(gene.stability[[i]], function(x) x<=stable*nmt )),i] <- NA   # the "unstable" cluster
            for (j in 2:nmt) {
                convert.from <- clustermap[[i]][,j]
                convert.to <- clustermap[[i]][,1]
                convert.to[is.na(convert.from)] <- NA
                genemap.final[,maptrials[j]] <- translate(genemap.init[,maptrials[j]], convert.from, convert.to)  # change cluster numbers to match first cluster
            }
        }
#        return(list(init.clustering=init.clustering, trial.sets=trial.sets, km2km=km2km, gene.stability=gene.stability, genemap.init=genemap.init, clustermap=clustermap, trial.equiv=trial.equiv))
        
        if (FALSE) {
#        if (lm > 1) {  # multiple trial.sets = multiple clustering configurations
            map.equiv <- matrix(0, lm, lm)   # test to see if trial.sets, though disjoint, are still equivalent (same gene assignments) -- merge if so
            for (i in 1:lm) {
                for (j in 1:lm) {
                    if (all(falsify(init.clustering[,i]==init.clustering[,j]))) map.equiv[i,j] <- 1
                }
            }
            
            equivalents <- conn.mat.subgraphs(map.equiv)
            le <- length(equivalents)
            final.clustering <- matrix(rep(genemap.init[,1],le), nrow(obj), le, F, list(rownames(obj),1:le))
            for (i in 1:le) {
                final.clustering[,i] <- init.clustering[,equivalents[[i]][1]]  # take first from each set of equivalent trial.sets
            }
        } else {
            map.equiv <- c()
            final.clustering <- init.clustering
        }
	
        if (more) {
            return(list(final.clustering=final.clustering, init.clustering=init.clustering, trial.sets=trial.sets, km2km=km2km, 
                        gene.stability=gene.stability, genemap.init=genemap.init, genemap.final=genemap.final, clustermap=clustermap, trial.equiv=trial.equiv, teo=teo)) #, map.equiv=map.equiv))
        } else {
            return(final.clustering)
        }
    }
}


apa.names$clustering <- c(apa.names$clustering, "kmeans.krange")
kmeans.krange <- function(obj, centers, iter.max=5000, nstart=100, algorithm=c("Hartigan-Wong","Lloyd","Forgy","MacQueen"), trials=11, r.thresh=1, stable=0.5, plot=FALSE) {
	
	## Executes kmeans.consensus() over a range of k and selects best based on Davies-Bouldin Index (DBI)
	## Mostly same args as kmeans.consensus(), but 'centers' must be a vector with the values of k.
	##  Different args: 'more' is not an option, 'plot' is.  Setting 'plot=T' will plot the DBI across range of k.
	
	per.k <- new.list(centers)
	NC <- length(centers)
	
	for (i in 1:NC) {
		IM("K =",centers[i])
		kdata <- kmeans.consensus(obj, centers[i], iter.max, nstart, algorithm, trials, r.thresh, stable, TRUE)
		if (length(kdata$clustermap)>0) {
			per.k[[i]] <- kdata
#			DBI[i] <- kdata$DBI[kdata$trial.sets[[1]][1]]  # DBI for first memeber of majority trial set
		}
	}
	# minDBI <- min(DBI,na.rm=TRUE)
	# minDBIx <- which(DBI==minDBI)
	
	# if (plot) {
		# plot(1:NC, DBI, type="l", ylab="DBI", xlab="k", main="DBI across k", xaxt="n", las=1)
		# points(1:NC, DBI, cex=1.5)
		# points(minDBIx, minDBI, cex=1.5, col=2, lwd=2)
		# axis(1, 1:NC, labels=centers)
	# }
	
	# invisible(list(per.k=per.k, minDBI=DBI))
	invisible(per.k)
}


apa.names$clustering <- c(apa.names$clustering, "pair.assoc")
pair.assoc <- function(pairs, map1, map2) {
    
    ## pre-chi-square matrix building, for whether gene pairs exhibit significant trending.
    ## 'pairs' is either:
    ##  - a 2-col matrix; col 1 = gene 1 and col 2 = gene 2 (many-to-one, many-to-many relationships allowed).
    ##  - a named list, where names = gene 1s and list elements = vectors of gene 2s.
    ## 'map1' is a named numeric vector (or rownamed 1-col matrix) = cluster mapping for gene 1s, e.g. output from kmeans().  Names=genes; values=cluster numbers.
    ## 'map2' is the cluster mapping for the gene 2s -- need not have same number of clusters as map1
    
    if (is.list(pairs)) {
        if (is.data.frame(pairs)) {
            pairs <- as.matrix(pairs)
        } else {
            pairs <- breakout(pairs,rev=TRUE)
        }
    } else if (is.matrix(pairs)) {
        # ok
    } else {
        stop("'pairs' must be a list or matrix/data.frame!\n")
    }
    if (ncol(pairs) != 2) stop("'pairs' must have 2 columns! (gene 1s, gene 2s)\n")

    if (is.matrix(map1)) { x=map1[,1]; names(x)=rownames(map1); map1=x }
    if (is.matrix(map2)) { y=map2[,1]; names(y)=rownames(map2); map2=y }
    if (!is.numeric(map1) | length(names(map1))==0) stop("'map1' must be a named numeric vector!\n")
    if (!is.numeric(map2) | length(names(map2))==0) stop("'map2' must be a named numeric vector!\n")
#    if (length(map1) != luniq(pairs[,1])) stop("'map1' length not equal to number of 'gene 1's!\n")
#    if (length(map2) != luniq(pairs[,2])) stop("'map2' length not equal to number of 'gene 2's!\n")
    map1 <- map1[!is.na(map1)]
    map2 <- map2[!is.na(map2)]
    N1 <- length(unique(map1))
    N2 <- length(unique(map2))
    
    OBS <- matrix(0,N1,N2)
    for (i in 1:N1) {
        others <- pairs[pairs[,1] %in% names(map1)[map1==i],2]
        oclust <- table(map2[names(map2) %in% others])
        OBS[i,] <- as.numeric(oclust[match(1:N2,names(oclust))])
    }
    OBS <- zerofy(OBS)
    EXP <- round(outer(rowSums(OBS),colSums(OBS))/sum(OBS),0)
    return(list(OBS=OBS, EXP=EXP, `O-E`=OBS-EXP, X2=chisq.test(x=OBS,y=EXP)))
}


apa.names$clustering <- c(apa.names$clustering, "distance")
distance <- function(obj, method=c("pearson","pearson2","spearman","spearman2","kendall","r2","adjusted.r2","shape","silhouette","mahalanobis","jaccard","venn","edit","tile","euclidean"), dist=TRUE) {
     
    ## Some distance metrics not found in dist()
    
    method <- match.arg(method)
    squared = c("pearson2","spearman2")
    nonsquared = c("pearson","spearman")
    lmdist <- c("r2","adjusted.r2")
    use.lm <- method %in% lmdist
    
    if (is.matrix(obj)) {
        ## ok
    } else if (is.data.frame(obj)) {
        if (use.lm) {
            ## leave alone; may have factors
        } else {
            obj <- as.matrix.data.frame(obj)
            if (mode(obj) == "character") stop("object not coercible to numeric matrix!  Check your data types.\n")  # 'contaminated' df
        }
    } else {
        stop("object must be a matrix or data frame!\n")
    }
    if (!use.lm) obj[is.infinite(obj)] <- NA
    nr <- nrow(obj)
    nc <- ncol(obj)
    
    corr.d <- function(mat, method) {
        dm <- matrix(0, nrow=nr, ncol=nr)
        do.square <- FALSE
        s <- which(squared %in% method)
        if (length(s)>0) {
            method <- nonsquared[s]
            do.square <- TRUE
        }
        dm <- zerofy(cor(t(mat), method=method, use="pairwise.complete.obs"))
        if (do.square) dm <- dm^2
        return(1-dm)   # distance, not similarity
    }
    
    lm.d <- function(mat, method) {
        ## 'mat' may be a matrix OR data.frame
        elem.name <- switch(method, "r2"="r.squared", "adjusted.r2"="adj.r.squared")
        dm <- matrix(0, nrow=nr, ncol=nr)
        for (i in 1:nr) {
            for (j in 1:nr) {
                dm[i,j] <- ifelse(is.factor(mat[,j]), NA, zerofy(summary(lm(mat[,j]~mat[,i]))[[elem.name]]))
            }
        }
        if (method == "adjusted.r2") dm[dm<0] <- 0  # adj. r2 often produces negative values; threshold at zero
        return(1-dm)   # distance, not similarity
    }
    
    euc.d <- function(mat) {   # euclidean
        dm <- matrix(0, nrow=nr, ncol=nr)
        for (i in 1:nr) {
            for (j in 1:nr) {
                if (i > j) {    # keep matrix triangular to save space/time
                    dm[i,j] <- sqrt(sum((mat[i,]-mat[j,])^2, na.rm=TRUE))
                }
            }
        }
        return(upper.triangle.fill(dm, 1))
    }
    
    venn.d <- function(mat) {   # normalized "venn" distance between two binary/logical vectors (0=identical, 1=disjoint)
        mode(mat) <- "logical"
        dm <- matrix(0, nrow=nr, ncol=nr)
        for (i in 1:nr) {
            for (j in 1:nr) {
                if (i > j) {    # keep matrix triangular to save space/time
                    dm[i,j] <- sum(mat[i,] & mat[j,]) / nc
                }
            }
        }
        dm <- upper.triangle.fill(dm, 1)
        return(1-dm)
    }
    
    jaccard.d <- function(mat) {
        dm <- matrix(0, nrow=nr, ncol=nr)
        for (i in 1:nr) {
            for (j in 1:nr) {
                if (i > j) {    # keep matrix triangular to save space/time
                    dm[i,j] <- length(intersect(mat[i,], mat[j,])) / length(union(mat[i,], mat[j,]))
                }
            }
        }
        dm <- upper.triangle.fill(dm, 1)
        return(1-dm)
    }
    
    edit.d <- function(mat) {   # edit distance between two sequences
        dm <- matrix(0, nrow=nr, ncol=nr)
        for (i in 1:nr) {
            for (j in 1:nr) {
                if (i > j) {    # keep matrix triangular to save space/time
                    dm[i,j] <- sum(mat[i,] != mat[j,])
                }
            }
        }
        dm <- upper.triangle.fill(dm, 1)
        return(dm)
    }
    
    tile.d <- function(mat) {   # tile distance between two sequences of equal length (i.e. do they overlap: dist = offset for j start relative to i start; if dist==seqlen then no overlap)
        dm <- matrix(0, nrow=nr, ncol=nr)
        for (i in 1:nr) {
            for (j in 1:nr) {
                if (i > j) {   # keep matrix triangular to save space/time
                    tiles.i <- tiles.j <- rep(FALSE, nc)
                    for (k in 1:nc) {
                        if (all(mat[i,k:nc] == mat[j,1:(nc-k+1)])) { tiles.i[k] <- TRUE }
                        if (all(mat[j,k:nc] == mat[i,1:(nc-k+1)])) { tiles.j[k] <- TRUE }
                    }
                    min.i <- ifelse (any(tiles.i), min(which(tiles.i))-1, nc)
                    min.j <- ifelse (any(tiles.j), min(which(tiles.j))-1, nc)
                    if (dist) {
                        dm[i,j] <- ifelse(min.i <= min.j, min.i, min.j)    # no negatives going into as.dist()
                    } else {
                        dm[i,j] <- ifelse(min.i <= min.j, min.i, -min.j)   # give min.j as a negative
                    }
                }
            }
        }
        dm <- upper.triangle.fill(dm, 1)
        return(dm)
    }
    
    dist.mat <- switch(
        method,
        "pearson"=corr.d(obj, "pearson"),
        "pearson2"=corr.d(obj, "pearson2"),    # squared pearson
        "spearman"=corr.d(obj, "spearman"),
        "spearman2"=corr.d(obj, "spearman2"),  # squared spearman
        "kendall"=corr.d(obj, "kendall"),
        "euclidean"=euc.d(obj),
        "shape"=shape.d(obj),
        "silhouette"=silh.d(obj),
        "mahalanobis"=maha.d(obj),
        "jaccard"=jaccard.d(obj),    # aka Tanimoto
        "venn"=venn.d(obj),        # binary vector overlap
        "edit"=edit.d(obj),        # for biological sequence
        "tile"=tile.d(obj)         # for biological sequence
    )
    rownames(dist.mat) <- colnames(dist.mat) <- rownames(obj)
    
    if (dist) {
        return(as.dist(dist.mat))
    } else {
        return(dist.mat)
    }
}


apa.names$clustering <- c(apa.names$clustering, "reorder.hclust2")
reorder.hclust2 <- function (hc, obj, method, heights=NULL) {
	
    ## Reorders an hclust object based on some row statistic.
    ## probably modified from gclus::reorder.hclust()
    ## 'hc' = hclust object
    ## 'obj' = matrix that was clustered.  It has no NAs, since you couldn't have clustered it if it did.
    ## 'method' IS A FUNCTION, NOT A FUNCTION NAME.  E.g. mean, not "mean".
    ## 'heights' = NULL or length-2 vector giving the height range of target nodes for rearrangement.  This allows one to reorder only at finer or grosser scales; NULL = full reorder.
    ##  - if one end of the interval is open, use 0 or Inf as appropriate.  E.g. can use "height=c(0,10)" or "height=c(5,100)" or "height=c(23,Inf)"
    

    if (!(length(heights) %in% c(0,2))) {
        warn("'heights' must be length 2 or NULL!")
        return()
    }
    if (is.null(heights)) heights <- c(0,Inf)
    
    ##get.metrics <- function(x) method(c(x))/length(c(x))  # NORMALIZE TO LENGTH
    get.metrics <- function(x) method(c(x))
    row.metrics <- apply(obj, 1, method)
    
    n <- nrow(hc$merge)
    clusters <- as.list(1:n)
    for (i in 1:n) {
        j <- hc$merge[i, 1]
        k <- hc$merge[i, 2]
        if (hc$height[i] <= heights[1] | hc$height[i] >= heights[2]) {
            ## out of range -- don't reorder
            if ((j < 0) & (k < 0)) {
                ## two single rows
                clusters[[i]] <- c(-j, -k)
            } else if (j < 0) {
                ## one single row to a cluster
                clusters[[i]] <- c(-j, clusters[[k]])
            } else if (k < 0) {
                ## a cluster to one single row
                clusters[[i]] <- c(clusters[[j]], -k)
            } else {
                ## two clusters
                clusters[[i]] <- c(clusters[[j]], clusters[[k]])
            }
        } else {
            ## in range -- reorder
            if ((j < 0) & (k < 0)) {
                ## comparing two single rows
                clusters[[i]] <- if (row.metrics[-j] > row.metrics[-k]) { c(-j, -k) } else { c(-k, -j) }
            } else if (j < 0) {
                ## comparing one single row to a cluster
                mk <- get.metrics(obj[clusters[[k]],])
                clusters[[i]] <- if (row.metrics[-j] > mk) { c(-j, clusters[[k]]) } else { c(clusters[[k]], -j) }
            } else if (k < 0) {
                ## comparing a cluster to one single row
                mj <- get.metrics(obj[clusters[[j]],])
                clusters[[i]] <- if (mj > row.metrics[-k]) { c(clusters[[j]], -k) } else { c(-k, clusters[[j]]) }
            } else {
                ## comparing two clusters
                mj <- get.metrics(obj[clusters[[j]],])
                mk <- get.metrics(obj[clusters[[k]],])
                clusters[[i]] <- if (mj > mk) { c(clusters[[j]], clusters[[k]]) } else { c(clusters[[k]], clusters[[j]]) }
            }
        }
    }
    hc$order <- clusters[[n]]
    hc
}


apa.names$clustering <- c(apa.names$clustering, "hclust2")
hclust2 <- function(d, method="average", members=NULL, x) {
    
    ## same args as hclust() but with better default linkage
    ## extra arg 'x' is the matrix being clustered (thus 'd' is dist(x,...))
    ## always passes through reorder.hclust2()
    
    reorder.hclust2(hclust(d,method,members), x, mean)
}


apa.names$clustering <- c(apa.names$clustering, "flip.hclust")
flip.hclust <- function(x) {
    
    ## flips an hclust tree upside-down
    x$order <- rev(x$order)
    x$labels <- rev(x$labels)
    x
}


apa.names$clustering <- c(apa.names$clustering, "flip.dendrogram")
flip.dendrogram <- function(x) {
#    
#    ## flips an dendrogram tree upside-down
#    ## FAIL: not yet able to recalculate 'midpoint' attributes; leaf order is OK but tree is jacked
#    
#    recurse <- function(y, i) {
#        i <- i + 1
#        if (length(y)==2) {
#           z <- y
#            z[[2]] <- recurse(y[[1]], i)
#            z[[1]] <- recurse(y[[2]], i)
#            z
#        } else {
#            y
#        }
#    }
#    recurse(x, 0)
}


apa.names$clustering <- c(apa.names$clustering, "partial.reorder.dendrogram")
partial.reorder.dendrogram <- function(x, ord) {
    
    ## 'x' is a dendrogram object
    ## 'ord' is a list of paths through 'x' to nodes which should be reversed (paths are vectors of 1s and 2s).
    
    recurse.and.flip <- function(y, path, xpath, j) {
        y[[ path[1] ]] <- 
            if (length(path)==1) {
                rev( y[[ path[1] ]] )
            } else {
                recurse.and.flip(y[[ path[1] ]], path[2:length(path)], path[1], j+1)
            }
        y
    }
    
    r <- x
    for (i in 1:length(ord)) r <- recurse.and.flip(r, ord[[i]], ord[[i]], 1)
    stats:::midcache.dendrogram(r)
}


apa.names$clustering <- c(apa.names$clustering, "dendrogram.labels")
dendrogram.labels <- function(x) {
    
    ## Returns leaf label order for a dendrogram
    ## Original intended use was to be able to hclust a matrix, convert hclust to dendrogram (which reorders tree), then be able to reorder matrix to match dendrogram
    
    recurse <- function(y, LL) {
        if (is.leaf(y[[1]]) & is.leaf(y[[2]])) {
            LL[[2]][LL[[1]]+1] <- attr(y[[1]],"label")
            LL[[2]][LL[[1]]+2] <- attr(y[[2]],"label")
            LL[[1]] <- LL[[1]]+2
            return( LL )
        } else if (is.leaf(y[[1]])) {
            LL[[2]][LL[[1]]+1] <- attr(y[[1]],"label")
            LL[[1]] <- LL[[1]]+1
            return( recurse(y[[2]], LL) )
        } else if (is.leaf(y[[2]])) {
            stop("Assumptions have broken!!!\n")
        } else {
            LL2 <- recurse(y[[1]], LL)
            return( recurse(y[[2]], LL2) )
        }
    }
    
    LL.final <- recurse(x, list(0, rep("", attr(x,"members"))))
    LL.final[[2]]
}


apa.names$clustering <- c(apa.names$clustering, "get.phylo.ord")
get.phylo.ord <- function(phylo) {
	
    ## returns the leaf order for an object of class "phylo"
	
    ord <- phylo$edge[phylo$edge[, 2] <= length(phylo$tip.label), 2]
    return(ord)
}


apa.names$clustering <- c(apa.names$clustering, "logify.tree")
logify.tree <- function(x, logfun=log2, adjust.zero=FALSE) {
	
    ## log-converts tree heights in objects of class 'hclust' and 'dendrogram'.
	## 'logfun': A FUNCTION, NOT A NAME, e.g. log, log2, log10, or some other log function.
	## 'adjust.zero=TRUE' adds 1 to tree heights, to prevent them from going negative when logged.  This does distort the relative heights a bit.
	##   1. only necessary if any heights < 1.
	##   2. plot.hclust will crash with negative heights, but plot.dendrogram won't.
	##   3. so, if your tree has heights < 1 and 'adjust.zero=FALSE', logify.tree will stop if class is 'hclust', but only warn if class if 'dendrogram'
	
	adjustment <- ifelse(adjust.zero, 1, 0)
	
    if (is(x, "hclust")) {
		
		if (any(x$height < 1) & !adjust.zero) stop("hclust has heights < 1: cannot convert unless 'adjust.zero=TRUE'\n")
		x$height <- logfun(x$height + adjustment)
		
	} else if (is(x, "dendrogram")) {
		
		recurse.and.log <- function(y, i) {
			for (j in 1:2) {
				if (is.leaf(y[[j]])) {
					attr(y[[j]],"height") <- log2( attr(y[[j]],"height") + adjustment )
				} else {
					attr(y[[j]],"height") <- log2( attr(y[[j]],"height") + adjustment )
					y[[j]] <- recurse.and.log(y[[j]], i + 1)
				}
			}
			return(y)
		}
		
		if (!adjust.zero) warning("adjust.zero = FALSE: leaf distances (and maybe some others) will become negative!\n")
		attr(x,"height") <- log2( attr(x,"height") + adjustment )
		x <- recurse.and.log(x, 0)
		
	} else {
		
		stop("'logify.tree' only works with objects of class 'hclust' or 'dendrogram'!\n")
		
	}
	x
}


apa.names$clustering <- c(apa.names$clustering, "km.hc.order")
km.hc.order <- function(map, mat, hc, metric="euclidean", linkage="average", p=NULL, sort.by.k=FALSE, reord=NULL, reverse=FALSE) {
	
	# hclust-reorders rows within each kmeans cluster, for a better-looking kmeans heatmap
	# 'metric' may be any 'method' value for dist() or distance()
	# 'linkage' may be any 'method' value for hclust()
	# 'p' is same as in dist(), if using minkowski distance
	# 'sort' indicates to sort output by cluster number as well (if cluster mapping is numeric)
	# 'reord=method' invokes reorder.hclust2() on each cluster hclust object.  "method" must be a FUNCTION NOT A NAME, a metric to rank rows by, e.g. mean, median, etc.
	
	if (metric %in% qw(euclidean,maximum,manhattan,canberra,binary,minkowski)) {
		distfun <- dist
	} else if (metric %in% qw(pearson,pearson2,spearman,spearman2,kendall,shape,silhouette,mahalanobis,jaccard,venn,edit,tile)) {
		distfun <- distance
	} else {
		stop("No function known for given distance metric!\n")
	}
	
	k <- unique(map[hc$order])
	if (sort.by.k) k <- sort(k)
#	cs <- c(0,cumsum(k))
	reordered <- new.list(k)
	for (i in 1:length(k)) {
		w <- which(map==k[i])
		khc <- hclust(distfun(mat[w,],method=metric), method=linkage)
		if (length(reord)>0) khc <- reorder.hclust2(khc, mat[w,], method=reord)
		reordered[[i]] <- w[khc$order]
		if (reverse) reordered[[i]] <- rev(reordered[[i]])
	}
	nameless(unlist(reordered))
}


apa.names$clustering <- c(apa.names$clustering, "sort.hc.ord")
sort.hc.ord <- function(map, hco) {
    
    ## creates a modified version of hc$order based on cutree() results or something equivalent
    ## basically, new ordering will put clusters 1-N in decreasing order, leaving intra-cluster ordering untouched.
    ## Thus 'map' vector MUST BE NUMERIC.
    ## 'hco' is the 'order' element from an hclust object, e.g. 'x$order'
    
    ord <- new.list(sort(unique(map)))
    map <- map[hco]
    if (mode(map)!="numeric" | !is.nlv(map)) stop("'map' must be a numeric vector!\n")
    for (i in 1:length(ord)) ord[[i]] <- hco[which(map==as.numeric(names(ord)[i]))]
    unlist(ord)
}


apa.names$clustering <- c(apa.names$clustering, "best.tree")
best.tree <- function(x, z=FALSE) {
    
    ## 'x' is a matrix to be clustered (on columns)
    ## tests most distances and all linkages to see which one gives the highest CCC
    ## if 'z=TRUE' also tests 'x' in z-score format
    
    linkages <- c("average","complete","single","median","centroid","ward.D","ward.D2","mcquitty")
    names(linkages) <- linkages
    distances <- c("euclidean","maximum","manhattan","canberra")
    names(distances) <- distances
    distances2 <- c("pearson","spearman")  # NOT KENDALL -- extremely long runtime
    names(distances2) <- distances2
    
    m <- list(x=x)
    if (z) m <- c(m, list(z=t(scale(t(x)))))
    
    dst <- hc <- lapply(m, function(y) {
        c(
            lapply(distances, function(d) dist(t(y),d)),
            lapply(distances2, function(d) distance(t(y),d))
        )
    })
    
    alldist <- c(distances,distances2)
    D <- length(alldist)
    L <- length(linkages)
    M <- length(m)
    N <- D*L*M
    ccc <- data.frame(
        Dataset=rep(names(m),each=N/M),
        Distance=rep(rep(alldist,each=N/D/M),M),
        Linkage=rep(linkages,N/L),
        ccc=rep(0,N)
    )
    rownames(ccc) <- apply(ccc[,1:3],1,paste,collapse=":")
    
    n <- 0
    for (i in 1:M) {
        hc[[i]] <- lapply(dst[[i]], function(d) lapply(linkages, function(L) hclust(d,L) ))
        for (j in 1:length(dst[[i]])) {
            for (k in 1:L) {
                n <- n+1
                ccc[n,4] <- cor(dst[[i]][[j]],cophenetic(hc[[i]][[j]][[k]]))
            }
        }
    }
    
    best <- ccc[which.max(ccc[,4]),4]
    names(best) <- rownames(ccc)[which.max(ccc[,4])]
    message(paste(names(best),"=",best[[1]]))
    
    invisible(list(best=best, matrix=m, dist=dst, hclust=hc, ccc=ccc))
}


apa.names$clustering <- c(apa.names$clustering, "match.clusters")
match.clusters <- function(ref, maps, ref.mat, maps.mat=NULL, plot=FALSE) {
	
	# the basic idea is, I have a hc cutree map (k=6) and a kmeans map (k=6); I want all cluster 1s, 2s, 3s, to have the same trend.
	# re-IDs a list of 1 or more cluster mappings ('maps') to match a reference mapping ('refs').  'maps' can be just one mapping vector, not a list of them.
	# a "mapping" is basically a numeric vector, preferably named, indicating cluster membership for rows in some matrix.
	# "some matrix" is 'ref.mat', and optionally 'maps.mat', if 'maps' maps came from a different matrix.
	# 'ref.mat' and 'maps.mat' must contain ONLY columns used for clustering.
	# clearly, only works if all mappings have the same number of clusters.
	# also, 'maps' clusters must be close enough to reference to have only one best correlating ref clust.
	
	maps.list <- TRUE
	if (!is.list(maps)) {
		maps <- list(maps)
		maps.list <- FALSE  # was not given as a list
	}
	if (length(maps.mat)==0) maps.mat <- ref.mat
	N <- length(maps)
	k <- luniq(ref)
	ref.c <- sapply(mat.split(ref.mat, ref), colMeans)
	maps.c <- lapply(maps, function(x){ sapply(mat.split(maps.mat, x), colMeans) })

	new.maps <- maps
	remap <- matrix(0, N, k)
	mean.corrs <- new.list(1:N)
	
	for (i in 1:N) {
		x <- cor(ref.c, maps.c[[i]])
		corrs <- apply(x, 1, max, na.rm=TRUE)
		doppels <- as.numeric(colnames(x)[apply(x, 1, which.max)])
		ref.ord <- as.numeric(rownames(x))
		if (is.nlv(doppels)) {
			if (luniq(doppels)==k) {
				new.maps[[i]] <- translate(maps[[i]], doppels, ref.ord)
			} else {
				IM("Maps",i,"trends are not 1:1 to reference (1)!\n")
				new.maps[[i]] <- rep(0,length(maps[[i]]))
			}
		} else {
			IM("Maps",i,"trends are not 1:1 to reference (2)!\n")
			new.maps[[i]] <- rep(0,length(maps[[i]]))
		}
		names(new.maps[[i]]) <- names(maps[[i]])
		mean.corrs[[i]] <- mean(corrs)
	}
	
	if (plot) compare.cluster.trends(c(list(ref),new.maps), list(ref.mat,maps.mat))
	
	if (maps.list) {
		return(new.maps)
	} else {
		return(new.maps[[1]])
	}
	invisible(mean.corrs)
}


apa.names$general <- c(apa.names$general, "corr.mat","dist.mat","corr.dist.mat")
corr.mat <- dist.mat <- corr.dist.mat <- function(obj1, obj2=NULL, names1=NULL, names2=NULL, metric="pearson", use=c("pairwise.complete.obs","complete.obs","all.obs"), 
                     with.p=FALSE, lower=FALSE, limits=c(-Inf,Inf), reorder=FALSE, palette="KBY", rev.pal=FALSE, pmar=c(5,5), scale.min=NULL,
                     scale.max=NULL, main=NULL, diagonal=NULL, reord.metric="euclidean", reord.linkage="average", view=FALSE, imgname=NULL,
                     imgdim=c(700,600), device=c("png","pdf"), nonzero=FALSE, plot=NULL, cex=1, drop.diag=FALSE, ...) {
                
    ## obj1 is any 2-D object; so is (optional) obj2.
    ##  - these are probably matrices, but may also be DFs with factors, if using r-squared metrics.
    ##  - if obj1 & obj2 given, columns of 1 are compared to columns of 2.
    ##  - if obj1 only, columns of obj1 are compared to themselves.
    ## "metric" is how to make pairwise comparisons:
    ##  1. Correlations: methods for cor()/cor.test(), i.e. "pearson", "spearman", or "kendall"
    ##  2. R-Squareds: "r2" or "adjusted.r2" [from summary(lm(...))]; can have ".dist" suffix to convert them to distances.
    ##  3. Distances: methods for dist(), e.g. euclidean, binary, manhattan, etc...
    ##  4. More Distances: methods for distance(), i.e. "pearson.dist", "spearman.dist", "kendall.dist", etc. USED AS DISTANCE NOT AS CORRELATION
    ##  These are NOT to be confused with "reord.metric" which does REORDERING of the resulting object...
    
    xargs <- list(...)
    if (length(xargs$filename)>0 & length(imgname)==0) imgname <- xargs$filename  # legacy call using 'filename'
    if (length(names1)>0) colnames(obj1) <- names1
    is.limited <- ifelse (all(is.infinite(limits)), FALSE, TRUE)
    use <- match.arg(use)
    device <- match.arg(device)
    plot2file <- ifelse(is.na(device)|length(imgname)==0, FALSE, TRUE)
    if (plot2file) view <- TRUE
    if (!is.null(plot)) view <- plot   # legacy support
    cex <- ifelse(length(cex)>0, cex, ifelse(plot2file, ifelse(device=="png", 1.2, 1), 1))
    
    r.metrics <- c("r2","r2.signed","adjusted.r2","adjusted.r2.signed")  # special subset of cor.metrics
    cor.metrics <- c("pearson", "spearman","kendall","r2","r2.signed","adjusted.r2","adjusted.r2.signed")
    dist.metrics <- c("euclidean","maximum","manhattan","canberra","binary")
    distance.metrics <- c("pearson.dist","spearman.dist","kendall.dist","r2.dist","adjusted.r2.dist")
    
    ## Test main metric
    Metric <- gsub("\\.","",sub(".dist$","",paste0(toupper(substr(metric,1,1)),substr(metric,2,nchar(metric)))))
    if (metric %in% cor.metrics) {
        is.corr <- TRUE; is.dist <- FALSE; is.distance <- FALSE
        is.r <- metric %in% r.metrics  # subset of cor.metrics
        if (is.r) Metric <- sub("r2","R^2",Metric)
        if (is.null(main)) main <- paste("Sample",Metric,"Correlations")
    } else if (metric %in% dist.metrics) {
        is.r <- FALSE; is.corr <- FALSE; is.dist <- TRUE; is.distance <- FALSE
        if (is.null(main)) main <- paste("Sample",Metric,"Distance")
    } else if (metric %in% distance.metrics) {
        dmetric <- sub(".dist$","",metric)
        is.r <- FALSE; is.corr <- FALSE; is.dist <- FALSE; is.distance <- TRUE
        if (is.null(main)) main <- paste("Sample",Metric,"Distance")
    } else {
        stop(paste("'",metric,"' is not a recognized correlation or distance metric!\n",sep=""))
    }
    
    ## Test reordering metric
    if (reord.metric %in% cor.metrics) {
        is.corr.reord <- TRUE; is.dist.reord <- FALSE; is.distance.reord <- FALSE
    } else if (reord.metric %in% dist.metrics) {
        is.corr.reord <- FALSE; is.dist.reord <- TRUE; is.distance.reord <- FALSE
    } else if (reord.metric %in% distance.metrics) {
        reord.dmetric <- sub(".dist$","",reord.metric)
        is.corr.reord <- FALSE; is.dist.reord <- FALSE; is.distance.reord <- TRUE
    } else {
        stop(paste("'",reord.metric,"' is not a recognized correlation or distance metric!\n",sep=""))
    }
    
    if (!(metric %in% cor.metrics) & with.p) {   # asked for p's but can't get
        IM("Warning: p-values are unavailable with this metric!\n")
        with.p <- FALSE
    }
    
    fill <- ifelse(lower, NA, 0)
    if (length(obj2)>0) {
        ## correlating columns of obj1 to obj2
        if (nrow(obj1) != nrow(obj2)) stop("Matrices have differing numbers of rows: cannot compare columns!\n")
        if (length(names2)>0) colnames(obj2) <- names2
        cmat <- matrix(fill, nrow=ncol(obj1), ncol=ncol(obj2))
        rownames(cmat) <- colnames(obj1)
        colnames(cmat) <- colnames(obj2)
        single.obj <- FALSE
    } else {
        ## correlating columns of obj1 to each other
        cmat <- matrix(fill, nrow=ncol(obj1), ncol=ncol(obj1))
        rownames(cmat) <- colnames(cmat) <- colnames(obj1)
        obj2 <- obj1
        single.obj <- TRUE
    }
    
    if (!is.r) {
        ## do not interfere with columns if some of them may be factors
        obj1[is.infinite(obj1)] <- NA
        obj2[is.infinite(obj2)] <- NA
        if (nonzero) {
            obj1 <- obj1[apply(obj1!=0,1,any),]
            obj2 <- obj2[apply(obj2!=0,1,any),]
            if (nrow(obj1)==0 | nrow(obj2)==0) stop("No non-zero rows!  Nothing to correlate.\n")
        }
    }
    if (with.p) pmat <- cmat
    
    if (is.r) {
        ## separate handling if some of the columns may be factors
        elem.name <- switch(metric, "r2"="r.squared", "r2.signed"="r.squared", "adjusted.r2"="adj.r.squared", "adjusted.r2.signed"="adj.r.squared")
        signed <- grepl(".signed$",metric)
        for (i in 1:ncol(obj1)) {
            for (j in 1:ncol(obj2)) {
                if (i==j) {
                    ## don't waste time fitting a column to itself
                    cmat[i,j] <- 1
                    if (with.p) pmat[i,j] <- 0
                } else if (is.factor(obj2[,j])) {
                    ## can't explain a factor with a linear model
                    cmat[i,j] <- NA
                    if (with.p) pmat[i,j] <- NA
                } else {
                    LM <- lm(obj2[,j]~obj1[,i])
                    cmat[i,j] <- zerofy(summary(lm(obj2[,j]~obj1[,i]))[[elem.name]])
                    if (signed) cmat[i,j] <- cmat[i,j] * sign(LM[[1]][[2]])
                    if (with.p) pmat[i,j] <- anova(LM)[[5]][[1]]
                }
            }
        }
        if (any(is.na(cmat))) {
            ## symmetrize: if any is.na(cmat[i,j]), replace with any non-NA cmat[j,i]
            for (i in 1:ncol(obj1)) {
                for (j in 1:ncol(obj2)) {
                    if (is.na(cmat[i,j])) cmat[i,j] <- cmat[j,i]
                    if (with.p) if (is.na(pmat[i,j])) pmat[i,j] <- pmat[j,i]
                }
            }
        }
    } else if (single.obj & !with.p & !is.limited) {
        ## single object, no p-values, no limits: simplest case
        if (is.corr) {
            cmat <- cor(obj1, method=metric, use=use)
        } else if (is.dist) {
            cmat <- as.matrix(dist(t(obj1)))
        } else if (is.distance) {
            cmat <- as.matrix(distance(t(obj1), method=dmetric))
        }
    } else {
        for (i in 1:ncol(obj1)) {
            ok1 <- real(obj1[,i],logical=TRUE) & falsify(obj1[,i]>=limits[1]) & falsify(obj1[,i]<=limits[2])
            for (j in 1:ncol(obj2)) {
                if (single.obj & i<j) next  # lower triangular object + diagonal only
                ok2 <- real(obj2[,j],logical=TRUE) & falsify(obj2[,j]>=limits[1]) & falsify(obj2[,j]<=limits[2])
                ok <- ok1 & ok2
                if (length(ok) >= 3) {
                    if (is.corr) {
                        if (with.p) {
                            x <- cor.test(obj1[ok,i], obj2[ok,j], method=metric)
                            cmat[i,j] <- x[[4]]
                            pmat[i,j] <- x[[3]]
                        } else {
                            cmat[i,j] <- cor(obj1[ok,i], obj2[ok,j], method=metric)
                        }
                    } else if (is.dist) {
                        cmat[i,j] <- dist(rbind(obj1[ok,i],obj2[ok,j]), method=metric)[1]
                    } else if (is.distance) {
                        cmat[i,j] <- distance(rbind(obj1[ok,i],obj2[ok,j]), method=dmetric)[1]
                    }
                    if (is.na(cmat[i,j])) cmat[i,j] <- 0
                } else {
                    cmat[i,j] <- 0
                    if (with.p) pmat[i,j] <- 1
                }
            }
        }
        if (single.obj & !lower) {
            cmat <- upper.triangle.fill(cmat)
            if (with.p) pmat <- upper.triangle.fill(pmat)
        }
    }
    
    if (reorder) {
        if (is.corr.reord) {
            reord.dist <- as.dist(cor(zerofy(cmat), method=reord.metric))
        } else if (is.dist.reord) {
            reord.dist <- dist(zerofy(cmat), method=reord.metric)
        } else if (is.distance.reord) {
            reord.dist <- distance(zerofy(t(obj1)), method=reord.dmetric)
        }
        hc <- hclust(reord.dist, method=reord.linkage)
        cmat <- cmat[hc$order,hc$order]
        if (with.p) pmat <- pmat[hc$order,hc$order]
    }
    
    if (length(diagonal)>0) diag(cmat) <- diagonal
    
    if (view) {
        if (!plot2file) {
            ## do nothing
        } else if (device == "png") {
            png(imgname, width=imgdim[1], height=imgdim[2])
            cex <- 1.2
        } else if (device == "pdf") {
            pdf(imgname, width=imgdim[1]/100, height=imgdim[2]/100)
            cex <- 0.9
        }
        
        cmat.scale <- cmat
        if (drop.diag) diag(cmat.scale) <- Inf
        scale.min <- ifelse(is.null(scale.min), min(real(cmat.scale)), scale.min)
        scale.max <- ifelse(is.null(scale.max), max(real(cmat.scale)), scale.max)
        myImagePlotUltra(cmat.scale, palette=palette, rev.pal=rev.pal, pmar=pmar, col.limits=c(scale.min,scale.max), main=main, cex=cex, NA.col=8, Inf.col="white", ...)
        if (!is.null(imgname)) dev.off()
    }
    
    if (with.p) {
        invisible(list(cmat=cmat, pmat=pmat))
    } else {
        invisible(cmat)
    }
}


apa.names$clustering <- c(apa.names$clustering, "cvm")
cvm <- function(clustering, mat, method=c("balance.cv","dbi","dunn","silhouette","partition","separation","isolation","class.ent","fuzzy.hyper","c.index","gamma.index","cs","fom","calinski-harabasz","goodman-kruskal"), na.rm=FALSE) {
    
    ## cluster validation metrics
    ## 'mat' is matrix of clustered data
    ## 'clustering' is a vector specifying cluster membership for rows of 'mat'
    ## 'method' is the CVM desired
    ## 'na.rm' as in other functions
    
    method <- match.arg(method)
    clustering2 <- as.numeric(as.factor(clustering))
    K <- max(clustering2)
    NR <- nrow(mat)
    clusters <- lapply(1:K, function(i) mat[clustering2==i,] )
    centers <- t(sapply(clusters, function(x) colMeans(x, na.rm=na.rm) ))
    
    CVM <- list(
        "balance.cv"=function(x) {
            CV(table(clustering))
        },
        
        "dbi"=function(x){
            Dsum <- 0
            S <- rep(0, K)
# intracluster distance
            for (i in 1:K) {
                d <- dist(rbind(centers[i,],clusters[[i]]))		# distance from cluster vectors to centroid
                nr <- ifelse(is.null(nrow(clusters[[i]])), 1, nrow(clusters[[i]]))   # to correct for R's stupid handling of single-row matrices (hint: they are not matrices)
                S[i] <- max(as.matrix(d)[,1])/nr				# col 1 only, because row 1 is the centroid: all vectors' distances here
            }
# intercluster distance
            for (i in 1:K) {
                R <- rep(0, K)
                for (j in 1:K) {
                    if (j != i) {
                        M <- as.matrix(dist(centers[c(i,j),]))[1,2]   # cluster i / cluster j inter-centroid distance
                        R[j] <- (S[i]+S[j])/M
                    }
                }
                Dsum <- Dsum + max(R)
            }
            Dsum / K
        },
        
        "dunn"=function(x){
            Dsum <- 0
            dprime <- rep(NA, K)
# intracluster distance
            for (i in 1:K) {
                dprime[i] <- max(as.matrix(dist(rbind(centers[i,],clusters[[i]])))[,1])		# distance from cluster vectors to centroid | col 1 only, because row 1 is the centroid: all vectors' distances here
            }
            max.dprime <- max(dprime)
# intercluster distance
            d <- as.matrix(dist(centers))
# sum of min ratios
            R.i <- rep(NA, K)
            for (i in 1:K) {
                R.j <- rep(Inf, K)
                for (j in 1:K) {
                    if (j != i) {
                        R.j[j] <- d[i,j]/max.dprime
                    }
                }
                R.i[i] <- min(R.j)
            }
            min(R.i)
        },
        
        "silhouette"=function(x){
            S <- rep(NA, NR)
            for (i in 1:NR) {
                this.clust <- clustering2[i]
                clusteringX <- clustering2
                clusteringX[i] <- 0   # remove self
                rest <- mat[clusteringX==this.clust,]
                nr.this <- nrow(rest)
                a <- mean(as.matrix(dist(rbind(mat[i,],rest)))[2:nr.this,1])		# mean distance from vector i to rest of cluster(vector i goes first)
                b.d <- rep(Inf, K)
                for (j in 1:K) {
                    if (j != this.clust) {
                        b.d[j] <- as.matrix(dist(rbind(mat[i,],centers[j,])))[1,2]		# mean distance from vector i to each other cluster (calculating distance from i to [cluster j mean], not mean of [all i to all vec in j])
                    }
                }
                b <- min(b.d)
                S[i] <- (b-a)/max(c(a,b))
            }
            mean(S)
        },
        
        "partition"=function(x){
        },
        
        "separation"=function(x){
        },
        
        "isolation"=function(x){
        },
        
        "class.ent"=function(x){
        },
        
        "fuzzy.hyper"=function(x){
        },
        
        "c.index"=function(x){
            C <- rep(NA,K)
            S.all <- dist(mat)
            for (i in 1:K) {
                clust <- clusters[[i]]
                L <- (nrow(clust)^2-nrow(clust))/2   # all vector pairs such that i != j
                S <- sum(dist(clust))
                S.min <- sort(S.all)[1:L]
                S.max <- sort(S.all,decreasing=TRUE)[1:L]
                C[i] <- (S-S.min)/(S.max-S.min)
            }
            sum(C)
        },
        
        "gamma.index"=function(x){
            d.all <- as.matrix(dist(mat))
            within <- between <- matrix(FALSE, NR, NR)
            for (i in 1:NR) {
                clust.i <- clustering2[i]
                for (j in 1:(i-1)) {
                    d.ij <- d.all[i,j]
                    clust.j <- clustering2[j]
                    if (clust.i == clust.j) {
                        within[i,j] <- TRUE
                    } else {
                        between[i,j] <- TRUE
                    }
                }
            }
            d.within <- d.all[as.dist(within)==1]
            d.between <- d.all[as.dist(between)==1]
            n.within <- length(d.within)
            n.between <- length(d.between)
            d.cross <- matrix(NA, n.within, n.between)
            for (i in 1:n.within) {
                for (j in 1:n.between) {
                    if (d.within[i] < d.between[i]) { 
                        d.cross[i,j] <- TRUE 
                    } else if (d.within[i] > d.between[i]) {
                        d.cross[i,j] <- FALSE 
                    }
                }
            }
            consistent <- sum(d.cross, na.rm=TRUE)
            inconsistent <- sum(!d.cross, na.rm=TRUE)
            (consistent-inconsistent)/(consistent+inconsistent)
        },
        
        "CS"=function(x){
        },
        
        "FOM"=function(x){
        },
        
        "calinski-harabasz"=function(x){
            B <- sum(dist(centers)^2)
            W <- 0
            for (i in 1:K) {
                W <- W + sum(dist(clusters[[i]])^2)
            }
            (B*(K-1))/(W*(NR-K))
        }
    )
    CVM$`goodman-kruskal` <- CVM$gamma.index
    
    return(CVM[[method]](mat))
}


apa.names$dev <- c(apa.names$dev, "reorder.hclust.x")
reorder.hclust.x <- function(x, rowStats, ...) {
	
	## Based on someone else's function.  It does reorder, but not in any useful way.
	## Use reorder.hclust2 instead.
	
	stat.mat <- outer(rowStats, rowStats, "-")
    merges <- x$merge
    n <- nrow(merges)
    endpoints <- matrix(0, n, 2)
    dir <- matrix(1, n, 2)
    for (i in 1:n) {
        j <- merges[i, 1]
        k <- merges[i, 2]
        if ((j < 0) && (k < 0)) {
            endpoints[i, 1] <- -j
            endpoints[i, 2] <- -k
        } else if (j < 0) {
            j <- -j
            endpoints[i, 1] <- j
            if (stat.mat[j, endpoints[k, 1]] < stat.mat[j, endpoints[k, 2]]) {
                endpoints[i, 2] <- endpoints[k, 2]
            } else {
                endpoints[i, 2] <- endpoints[k, 1]
                dir[i, 2] <- -1
            }
        } else if (k < 0) {
            k <- -k
            endpoints[i, 2] <- k
            if (stat.mat[k, endpoints[j, 1]] < stat.mat[k, endpoints[j, 2]]) {
                endpoints[i, 1] <- endpoints[j, 2]
                dir[i, 1] <- -1
            } else {
                endpoints[i, 1] <- endpoints[j, 1]
            }
        } else {
            d11 <- stat.mat[endpoints[j, 1], endpoints[k, 1]]
            d12 <- stat.mat[endpoints[j, 1], endpoints[k, 2]]
            d21 <- stat.mat[endpoints[j, 2], endpoints[k, 1]]
            d22 <- stat.mat[endpoints[j, 2], endpoints[k, 2]]
            dmin <- min(d11, d12, d21, d22)
            if (dmin == d21) {
                endpoints[i, 1] <- endpoints[j, 1]
                endpoints[i, 2] <- endpoints[k, 2]
            } else if (dmin == d11) {
                endpoints[i, 1] <- endpoints[j, 2]
                endpoints[i, 2] <- endpoints[k, 2]
                dir[i, 1] <- -1
            } else if (dmin == d12) {
                endpoints[i, 1] <- endpoints[j, 2]
                endpoints[i, 2] <- endpoints[k, 1]
                dir[i, 1] <- -1
                dir[i, 2] <- -1
            } else {
                endpoints[i, 1] <- endpoints[j, 1]
                endpoints[i, 2] <- endpoints[k, 1]
                dir[i, 2] <- -1
            }
        }
    }
    for (i in n:2) {
        if (dir[i, 1] == -1) {
            m <- merges[i, 1]
            if (m > 0) {
                m1 <- merges[m, 1]
                merges[m, 1] <- merges[m, 2]
                merges[m, 2] <- m1
                if (dir[m, 1] == dir[m, 2]) { dir[m, ] <- -dir[m, ] }
            }
        }
        if (dir[i, 2] == -1) {
            m <- merges[i, 2]
            if (m > 0) {
                m1 <- merges[m, 1]
                merges[m, 1] <- merges[m, 2]
                merges[m, 2] <- m1
                if (dir[m, 1] == dir[m, 2]) { dir[m, ] <- -dir[m, ] }
            }
        }
    }
    clusters <- as.list(1:n)
    for (i in 1:n) {
        j <- merges[i, 1]
        k <- merges[i, 2]
        if ((j < 0) && (k < 0)) {
            clusters[[i]] <- c(-j, -k)
        } else if (j < 0) {
            clusters[[i]] <- c(-j, clusters[[k]])
        } else if (k < 0) {
            clusters[[i]] <- c(clusters[[j]], -k)
        } else {
			clusters[[i]] <- c(clusters[[j]], clusters[[k]])
		}
    }
    x1 <- x
    x1$merge <- merges
    x1$order <- clusters[[n]]
    x1
}


apa.names$dev <- c(apa.names$dev, "dendroCAT")
dendroCAT <- function(x, y, plot=FALSE, ignore.singletons=FALSE) {
    
    ## CAT-plot-like approach to comparing dendrogram topology.
    ## Cuts two dendrograms from k=1 to k=N (N = elements that were clustered);
    ##   at each K, pairs clusters (one from 'x' with one from 'y') that have greatest gene overlap*,
    ##   then sums the gene overlaps from all paired clusters (n).  0 <= n <= N.
    ##   E.g. if clusters A1 (from 'x') and A2 (from 'y') are considered paired, and gene X is found in both A1 and A2, n+=1.
    ## If topologies are identical, n=N for every K.
    ## If topologies have no relation, n will rapidly approach some random value after k=1.
    ## Also able to compare a dendrogram (x) to a static clustering (y),
    ##   and see at what k the dendrogram most resembles the clustering.
    ##
    ## * if Mxy is a k-by-k matrix where rows = x clusters, cols = y clusters, and cells = gene overlap counts, 
    ##   then 'greatest gene overlap' is found by ordering rows/cols such that the diagonal is maximized (Hungarian algorithm).
    ##   Then, for i from 1:k, clusters corresponding to row i and col i are considered 'paired'.
    ##   The total gene overlap, n, is the diagonal sum.
    ##
    ## 'plot=TRUE' will plot n/N for all k
    ## 'ignore.singletons=TRUE' will throw out single-gene clusters before calculating n.
    ## If 'y' is a named numeric clustering vector and 'plot=TRUE', plot shows ablines for max(n) (red) and for length(unique(y)) (blue).
    
    require(clue)
    if (!is(x,"hclust")) stop("'x' must be an 'hclust' object!\n")
    Nx <- length(x$order)
    if (is(y,"hclust")) {
        ## y is another hclust
        y.fixed <- FALSE
        Ny <- length(y$order)
        x.is.y <- all(x$labels==y$labels)  # same sample set, not necessarily same hclust
        ccc <- cor(cophenetic(x), cophenetic(y))
        message("CCC:",ccc)
    } else if (is.vector(y) & mode(y)=="numeric" & length(names(y))>0) {
        ## y is a cutree vector or something like it (a fixed clustering vector to compare to cutree k=1:Nmin)
        ## MUST BE NAMED
        y.fixed <- TRUE
        Ny <- length(y)
        Ky <- length(unique(y))
        x.is.y <- all(x$labels%in%names(y))
        if (x.is.y) y <- y[match(x$labels,names(y))]
    } else {
        stop("'y' is neither an 'hclust' object nor a named clustering vector.\n")
    }
    Nmin <- min(c(Nx,Ny))
    diag.sums <- rep(NA, Nmin)
    title <- "Percent Labels Assigned to Compatible Clusters"
    xlab <- "N Clusters"
    ylab <- "Percent"
    ylim <- c(0,100)
    if (y.fixed) Cy <- y
    for (k in 1:Nmin) {
        Cx <- cutree(x,k=k)
        if (y.fixed) {
            x.gt.y <- k > Ky
        } else {
            x.gt.y <- FALSE
            Cy <- cutree(y,k=k)
        }
        if (x.is.y) {
            Mxy <- table(Cx,Cy)
        } else {
            Mxy <- matrix(0, k, k)  # x=rows, y=cols
            for (i in 1:k) {
                for (j in 1:k) Mxy[i,j] <- length(intersect(names(Cx)[Cx==i],names(Cy)[Cy==j]))
            }
        }
        if (ignore.singletons) {
            Mxy <- Mxy[rowSums(Mxy)>1,,drop=FALSE]
            Mxy <- Mxy[,colSums(Mxy)>1,drop=FALSE]
            if (nrow(Mxy)==0 | ncol(Mxy)==0) {
                message(paste0("k=",k,", Mxy is empty!  Stopping.\n"))
                if (plot) {
                    dev.new(); lineplot(100*diag.sums/Nmin, las=1, ylim=ylim, xlab=xlab, ylab=ylab, main=title)
                }
                if (y.fixed) abline(v=c(which.max(diag.sums),Ky), col=c(2,4))
                return(diag.sums)
            }
            x.gt.y <- nrow(Mxy) > ncol(Mxy)
        }
        if (x.gt.y) Mxy <- t(Mxy)
        MxyS <- solve_LSAP(Mxy, maximum=TRUE)  # find optimal row-column assignments by maximizing the diagonal sum
        if (x.gt.y) MxyS <- t(MxyS)
        diag.sums[k] <- sum(diag(Mxy[,as.numeric(MxyS)]))
    }
    if (plot) {
        dev.new(); lineplot(100*diag.sums/Nmin, las=1, ylim=ylim, xlab=xlab, ylab=ylab, main=title)
    }
    if (y.fixed) abline(v=c(which.max(diag.sums),Ky), col=c(2,4))
    return(diag.sums)
}


apa.names$dev <- c(apa.names$dev, "cluster.validity")
cluster.validity <- function(x, maps, method="all", ext=FALSE) {
    
    ## wrapper for clusterCrit package flagship functions, intCriteria() and extCriteria()
    
    require(clusterCrit)
    M <- length(maps)
    if (length(names(maps))==0) names(maps) <- 1:M
    intC <- do.call(rbind, lapply(1:M, function(i){ message(paste("Internal:",names(maps)[i])); unlist(intCriteria(x, maps[[i]], method)) }))
    rownames(intC) <- names(maps)
    
    optim <- list(
        max=c("calinski_harabasz","dunn","gamma","gdi11","gdi12","gdi13","gdi21","gdi22","gdi23","gdi31","gdi32","gdi33","gdi41","gdi42","gdi43","gdi51","gdi52","gdi53","pbm","point_biserial","ratkowsky_lance","silhouette","tau","wemmert_gancarski"),  # max score is best
        min=c("banfeld_raftery","c_index","davies_bouldin","g_plus","mcclain_rao","ray_turi","scott_symons","sd_scat","sd_dis","s_dbw","xie_beni"),  # min score is best
        maxdiff=c("ball_hall","ksq_detw","trace_w","trace_wib"),  # max second derivative is best
        mindiff=c("det_ratio","log_det_ratio","log_ss_ratio")   # min second derivative is best
    )
    matsym <- list(
        sym=c("czekanowski_dice","folkes_mallows","hubert","jaccard","kulczynski","phi","rand","rogers_tanimoto","russel_rao","sokal_sneath1","sokal_sneath2"),  # symmetric score matrices
        asym=c("mcnemar","precision","recall")  # asymmetric score matrices
    )
    
    intC.ranks <- intC
    for (j in 1:ncol(intC)) {
        intC.ranks[,j] <-
            if (colnames(intC)[j] %in% optim$max) {
                match(1:M,rev(order(intC.ranks[,j])))
            } else if (colnames(intC)[j] %in% optim$min) {
                match(1:M,order(intC.ranks[,j]))
            } else if (colnames(intC)[j] %in% optim$maxdiff) {
                deriv2 <- diff(diff(intC.ranks[,j]))
                match(1:M,rev(order(deriv2))+1)
            } else if (colnames(intC)[j] %in% optim$mindiff) {
                deriv2 <- diff(diff(intC.ranks[,j]))
                match(1:M,order(deriv2)+1)
            } else {
                message(paste0("Unknown internal cluster validity index '",colnames(intC)[j],"'!  Please add a handler.\n"))
                rep(NA,M)
            }
    }
    
    pre.mono <- apply(intC.ranks, 2, function(x) {
        na <- sum(is.na(x))
        y <- x[!is.na(x)]
        d <- diff(y)
        if (y[1] < y[length(y)]) {
            monotonic <- is.monotonic(y, decreasing=FALSE)
            sequential <- sum(d==1)+na+1
            all.flips <- sum(d==-1)
            single.flips <- all(d %in% -1:3)
        } else {
            monotonic <- is.monotonic(y, decreasing=TRUE)
            sequential <- sum(d==-1)+na+1
            all.flips <- sum(d==1)
            single.flips <- all(d %in% -3:1)
       }
       c(mono=monotonic,sequ=sequential,f.all=all.flips,f.single=single.flips)
    })
    near.mono <- pre.mono[4,]==1
    intC.mono <- matrix(NA, 2, ncol(pre.mono), FALSE, list(c("monotonic","monotonic with N flips"),colnames(pre.mono)))
    intC.mono[1,] <- pre.mono[1,]
    intC.mono[2,near.mono] <- pre.mono[3,near.mono]
    
    output <- list(intCriteria=intC, intRanks=intC.ranks, intMonotonic=intC.mono)
    
    if (ext) {
        pre.extC <- vector("list", length=M)
        for (i in 1:M) {
            message(paste("External:",names(maps)[i]))
            pre.extC[[i]] <- vector("list", length=M)
            for (j in 1:M) pre.extC[[i]][[j]] <- extCriteria(maps[[i]],maps[[j]],method)
        }
        
        E <- length(pre.extC[[1]][[1]])
        En <- names(pre.extC[[1]][[1]])
        extC <- vector("list", length=E)
        names(extC) <- En
        blank <- matrix(NA, M, M, F, list(names(maps),names(maps)))
        for (e in 1:E) {
            extC[[e]] <- list(scores=blank, globalRank.sim=blank, globalRank.dif=blank)
            for (i in 1:M) {
                for (j in 1:M) extC[[e]]$scores[i,j] <- pre.extC[[i]][[j]][[e]]
            }
        }
        
        get.ranks <- function(x) {
            if (is.matrix(x)) diag(x) <- NA
            uvals.dif <- sort(unique(x))
            uvals.sim <- rev(uvals.dif)
            list(sim=match(x,uvals.sim), dif=match(x,uvals.dif))
        }
        
        for (e in 1:E) {
            g.ranks <- get.ranks(extC[[e]]$scores)
            extC[[e]]$globalRank.sim[1:M^2] <- g.ranks$sim
            extC[[e]]$globalRank.dif[1:M^2] <- g.ranks$dif
            r.ranks <- apply(extC[[e]]$scores,1,get.ranks)
            extC[[e]]$rowRank.sim <- do.call(rbind, lapply(r.ranks, "[[", "sim"))
            extC[[e]]$rowRank.dif <- do.call(rbind, lapply(r.ranks, "[[", "dif"))
            colnames(extC[[e]]$rowRank.sim) <- colnames(extC[[e]]$rowRank.dif) <- names(maps)
            if (En[e] %in% matsym$asym) {
                ## if matrices symmetric, then col rankings same as row rankings above
                ## these are asymmetric, so need separate set of col rankings
                c.ranks <- apply(extC[[e]]$scores,2,get.ranks)
                extC[[e]]$colRank.sim <- do.call(cbind, lapply(c.ranks, "[[", "sim"))
                extC[[e]]$colRank.dif <- do.call(cbind, lapply(c.ranks, "[[", "dif"))
                rownames(extC[[e]]$colRank.sim) <- rownames(extC[[e]]$colRank.dif) <- names(maps)
            }
        }
        
        c(output, list(extCriteria=extC))
    } else {
        output
    }
}


