

apa.names$bio.seq <- c(apa.names$bio.seq, "make.kmers")
make.kmers <- function(k, alphabet=c("A","C","G","T")) {
    
    ## Makes all possible kmers for a given k
    ## "alphabet" indicates what characters should be used
    ## All kmers from 2-11 have been precalculated and are in S:/Genomics/Molbio_Users/APA/R_Things/kmer_library/kmers.stdn.<k>.txt
    
    N <- length(bases) ^ k
    mat <- matrix(data="", nrow=N, ncol=k)
    for (i in 1:k) {
        set <- c()
        unit.len <- length(bases)^i
        rep.len <- length(bases)^(i-1)
        for (b in bases) set <- c(set, rep(b, N/unit.len))
        mat[,i] <- rep(set, rep.len)
    }
    ks <- apply(mat, 1, paste, collapse="")
    write(ks, paste0("kmers.stdn.",k,".txt"), quote=FALSE, col.names=FALSE, row.names=FALSE)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "count.kmers")
count.kmers <- function(seq, k, bkg=NULL, N.rm=NULL, threshold=2E9, binary=FALSE, verbose=0) {
    
    ## Does k-mer enumeration on a sequence set
    ## "k" must be an integer
    ## "bkg" is an optional set of background kmers (all possible k-mers)
    ## "N.rm" ignores candidate kmers containing Ns: values = "any" or "all", indicating threshold N content.
    ## "threshold" is maximum # cells in pre-kmer matrix (over this, matrix gets split up and processed in pieces)
    ## "binary" indicates whether to tally kmers only once per sequence (TRUE) or report all kmer instances (FALSE)
    ## "verbose" reports object construction details to screen: 0=none, 1=summary-level only, 2=sequence-level
    ## output is a matrix with a row for all possible kmers; col 1 = kmer and col 2 = times kmer was seen
    
    basepath <- ifelse (.Platform$OS.type == "windows", "S:", "/n/facility")
    if (!(verbose %in% 0:2)) verbose <- 0

    main.func <- function(s) {  # 's' = single sequence.  Gets all but index 's' from count.kmers namespace
        bases <- toupper(unlist(strsplit(seq[s], "")))
        N <- length(bases)
        if (N < k) {
            IM("Sequence",s,"length",N,"has no words of length",k,"-- skipping.\n")
        } else {
            cells <- k * (N-k+1)
            if (verbose==2) IM("seq", s, ": dims", N-k+1, k, cells)
            if (cells > threshold) {   # probable that matrix call will break; split up data
                M <- ceiling(cells/threshold)
                offsets <- rep(0,M)
                offsets[1] <- 1
                rows <- running <- ceiling((N-k+1)/M)
                mat <- knames.M <- rmv <- vector("list", length=M)
            } else {
                M <- 1
                rows <- N-k+1
                mat <- knames.M <- rmv <- vector("list", length=1)
                offsets <- 1
            }
            if (verbose==2) IM(" prep", M)
            for (i in 1:M) {
                mat[[i]] <- matrix("", nrow=rows, ncol=k)
                if (i > 1) {
                    offsets[i] <- running + 1 	# starting bp for kmers in mat[[i]]
                    running <- running + nrow(mat[[i]])
                }
            }
            if (verbose==2) IM(" mat")
            if (M > 1) {
                extra <- M*rows-(N-k+1)	    # unused rows in final matrix, if any (result of ceiling estimate)
                if (verbose==2) IM(" rm",extra)
                if (extra > 0) mat[[M]] <- mat[[M]][-c(1:extra)]
            }
            for (i in 1:M) {
                mat[[i]] <- matrix("", nrow=rows, ncol=k)
                irows <- nrow(mat[[i]])
                startpos <- offsets[i] - 1
                for (j in 1:k) { 
                    first <- startpos + j
                    last <- startpos + irows + j - 1
                                        #					IM(i, j, first, last, last-first+1, irows, N)
                    mat[[i]][,j] <- bases[first:last] 
                }
                if (verbose==2) IM(" load",i)
            }
            if (!is.null(N.rm)) {
                if (N.rm == "any") {
                    for (i in 1:M) rmv[[i]] <- which(apply(mat[[i]], 1, FUN=function(x){any(x=="N")}))
                } else if (N.rm == "all") {
                    for (i in 1:M) rmv[[i]] <- which(apply(mat[[i]], 1, FUN=function(x){all(x=="N")}))
                } else {
                    stop(" 'N.rm' must be one of NULL, 'any', or 'all'!\n")
                }
                for (i in 1:M) { 
                    if (length(rmv[[i]]) > 0) {
                        nrm <- nrow(mat[[i]])
                        mat[[i]] <- mat[[i]][-rmv[[i]],] 
                        if (verbose==2) IM(" Removed",length(rmv[[i]]),"/",nrm,"kmers with Ns:",i)
                    }
                }
            }
            if (verbose==2) IM(" N.rm")
            for (i in 1:M) { 
                if (is.matrix(mat[[i]])) {      # retain matrix (2+ entries)
                    knames.M[[i]] <- apply(mat[[i]], 1, paste, collapse="")
                    if (verbose==2) IM(" collapse M",i)
                } else {                        # only vector left (single entry)
                    knames.M[[i]] <- paste(mat[[i]],collapse="")
                    if (verbose==2) IM(" collapse V",i)
                }
            }
            rm(mat)
            knames <- unlist(knames.M)
            names(knames) <- NULL
            if (verbose==2) IM(" knames", length(knames))
            return(knames)
        }
    }
    
    S <- length(seq)
    results <- lapply(1:S, main.func)
    if (verbose>0) IM("results", length(results))
    rmv <- c()
    for (i in 1:length(results)) { 
        if (length(results[[i]])==0) { 
            rmv <- c(rmv,i) 
        }
    }
    if (length(rmv) > 0) results <- results[-rmv]
    if (verbose>0) IM("rmv",length(rmv))
    if (length(results) > 0) {
#        if (binary) {
#            before <- sum(listLengths(results))
#            results <- lapply(results, unique)  # each kmer can only count once per peak
#            after <- sum(listLengths(results))
#            if (verbose>0) IM("binarized:", before, "=>", after)
#        }
#        tab <- table(unlist(results))
#        if (verbose>0) IM("table", length(tab), dim(tab))
#        kmers <- data.frame(names(tab), c(tab), stringsAsFactors=FALSE)
#        if (verbose>0) IM("kmers", dim(kmers))
#        colnames(kmers) <- c("Kmer", "Count")
#        return(kmers[order(kmers[,2], decreasing=TRUE),])
        ## NEW OUTPUT BLOCK
        bin.before <- sum(listLengths(results))
        uresults <- lapply(results, unique)  # each kmer can only count once per peak
        bin.after <- sum(listLengths(uresults))
        seq.with <- table(unlist(uresults))
        if (verbose>0) IM("binarized:", bin.before, "=>", bin.after)
        tab <- table(unlist(results))
        TK <- sum(tab)
        if (verbose>0) IM("table", length(tab), TK, dim(tab))
        kmers <- data.frame(Kmer=names(tab), Copies=c(tab), Pct.AllKmers=round(100*c(tab)/TK,4), N.Seqs=c(seq.with), Pct.Seqs=round(100*c(seq.with)/S,4), stringsAsFactors=FALSE)
        if (verbose>0) IM("kmers", dim(kmers))
        return(kmers[order(kmers[,2], decreasing=TRUE),])
        ## END BLOCK
    } else {
        IM("No results returned -- were sequence lengths < k value?\n")
    }
}


apa.names$bio.seq <- c(apa.names$bio.seq, "get.degen.words")
get.degen.words <- function(word) {
    
    ## Return all realizations (using ACGT only) of a degenerate DNA word.
    
    if (length(word)>1) stop("Cannot process > 1 word!\n")
    dict <- list(N=c("A","C","G","T"), H=c("A","C","T"), D=c("A","G","T"), V=c("A","C","G"), B=c("C","G","T"), R=c("A","G"), Y=c("C","T"), S=c("C","G"), W=c("A","T"), M=c("A","C"), K=c("G","T"), A="A", C="C", G="G", T="T")
    D <- listLengths(dict)
    bases <- unlist(strsplit(word,''))
    ibases <- match(bases, names(dict))
    if (any(is.na(ibases))) { 
        odd <- paste(c("[",unique(bases[is.na(ibases)]),"]"),collapse='')
        stop("Unrecognized bases",odd,"present!  Must be only IUPAC degenerate DNA characters [ACGTRYSWMKHDVBN]!\n") 
    }
    Nch <- length(bases)
    Nout <- 1
    for (i in 1:Nch) Nout <- Nout * D[ibases[i]]
    inst.mat <- matrix("", Nout, Nch)
    static <- which(bases %in% c("A","C","G","T"))
    degen <- which(!(bases %in% c("A","C","G","T")))
    if (length(static)>0) inst.mat[,static] <- rep(bases[static], each=Nout)
    if (length(degen)>0) {
        for (u in unique(bases[degen])) { 
            dbases <- dict[[which(names(dict)==u)]]
            ndeg <- length(dbases)
            x <- which(bases==u)
            for (i in x) {
                roots <- unique(inst.mat)
                for (j in 1:nrow(roots)) {
                    y <- which(apply(inst.mat, 1, function(r) all(r==roots[j,]) ))
                    inst.mat[y,i] <- rep(dbases,each=length(y)/ndeg)
                }
            }
        }
    }
    apply(inst.mat, 1, paste, collapse="")
}


apa.names$bio.seq <- c(apa.names$bio.seq, "degen2regex")
degen2regex <- function(x) {
    
    ## converts words with degenerate sequence to regular expressions
    ## e.g. CHNTYAGKCW -> C[ACT][ACGT]T[CT]AG[GT]C[AT]
    
    dict <- list(N="[ACGT]", H="[ACT]", D="[AGT]", V="[ACG]", B="[CGT]", R="[AG]", Y="[CT]", S="[CG]", W="[AT]", M="[AC]", K="[GT]")
    for (i in 1:length(dict)) x <- gsub(names(dict)[i],dict[[i]],x)
    x
}


apa.names$bio.seq <- c(apa.names$bio.seq, "word.exp")
word.exp <- function(word, freqs=NULL) {
    
    ## calculates the expected frequency of a DNA word, given bkg frequencies ( = vector length 4, MUST BE in 'ACGT' order!!!!)
    ## needs to be upgraded to be as robust as the apa_routines.pm version
    ## also, both this and the apa_routines.pm version need to be upgraded to handle joint bkg-PSSM expectations
    
    if (is.null(freqs)) { 
        freqs <- rep(0.25, 4)   # random
    } else if (length(freqs) != 4) { 
        stop("Background letter frequency vector must have length 4!\n")
    } else if (zapsmall(sum(freqs)) != 1) {
        stop("Background letter frequencies must sum to 1!\n")
    }
    chars <- toupper(unlist(strsplit(word,'',fixed=TRUE)))
    dcon <- list(
        R=c('A','G'), Y=c('C','T'), S=c('C','G'), 
        W=c('A','T'), K=c('G','T'), M=c('A','C'), 
        H=c('A','C','T'), D=c('A','G','T'), V=c('A','C','G'), 
        B=c('C','G','T'), N=c('A','C','G','T') 
    )
    ifreq <- data.frame(CHAR=unlist(strsplit('ACGTRYSWKMHDVBN','',fixed=TRUE)), N=rep(0,15), stringsAsFactors=FALSE)    # initial char freq
    ffreq <- data.frame(CHAR=unlist(strsplit('ACGT','',fixed=TRUE)), N=rep(1,4), stringsAsFactors=FALSE)                # final char freq
    expect <- 1
    
    for (i in chars) {
        x <- match(i, ifreq[,1])
        if (is.na(x)) stop("Word must contain only legal DNA + degenerate chars only: ACGTRYSWKMHDVBN!\n")
        ifreq[x,2] <- ifreq[x,2] + 1
    }
    ifreq <- ifreq[ifreq[,2]>0,]           # remove rows for unused chars
    
    for (i in 1:nrow(ifreq)) {
        x <- match(ifreq[i,1], ffreq[,1])  # also indexes 'freqs', since ACGT order is same
        for (n in 1:ifreq[i,2]) {          # for each time the char was seen
            if (is.na(x)) {                # degenerate base -- convert
                trues <- unlist(dcon[ifreq[i,1]])
                dfreq <- 0
                for (j in trues) {
                    y <- match(j, ffreq[,1])
                    dfreq <- dfreq + freqs[y]
                }
                ffreq[y,2] <- ffreq[y,2] * dfreq
            } else if (freqs[x] == 0) {    # normal base
                ffreq[,2] <- rep(0,4)      # zero frequency for required base: kmer prob then becomes zero
            } else {                       # normal base
                ffreq[x,2] <- ffreq[x,2] * freqs[x]
            }
        }
    }
    ffreq <- ffreq[ffreq[,2]>0,]           # remove rows for unused chars
    
    for (i in 1:nrow(ffreq)) expect <- expect * ffreq[i,2]
    expect <- 1/expect
    if (length(expect)==0) expect <- 0
    expect
}


apa.names$bio.seq <- c(apa.names$bio.seq, "words2PSSM")
words2PSSM <- function(words, alphabet="DNA", gapAsN=TRUE, row.names=FALSE) {
    
    ## takes a vector of same-length DNA/RNA (later adding AA) words and makes a seqLogo-style PSSM out of them
    
    alphabets <- list(
        DNA=c("A","C","G","T"),
        RNA=c("A","C","G","U"),
        AA=c("A","C","D","E","F","G","H","I","K","L","M","N","P","Q","R","S","T","V","W","Y")
    )
    
    degenerate <- list(
        DNA=list(
            A="A", C="C", G="G", T="T",
            R=c("A","G"), Y=c("C","T"), S=c("C","G"),
            W=c("A","T"), K=c("G","T"), M=c("A","C"),
            B=c("C","G","T"), D=c("A","G","T"),
            H=c("A","C","T"), V=c("A","C","G"),
            N=c("A","C","G","T")
        ),
        RNA=list(
            A="A", C="C", G="G", U="U",
            R=c("A","G"), Y=c("C","U"), S=c("C","G"),
            W=c("A","U"), K=c("G","U"), M=c("A","C"),
            B=c("C","G","U"), D=c("A","G","U"),
            H=c("A","C","U"), V=c("A","C","G"),
            N=c("A","C","G","U")
        ),
        AA=c(
            A="A",C="C",D="D",E="E",F="F",G="G",H="H",I="I",K="K",L="L",M="M",N="N",P="P",Q="Q",R="R",S="S",T="T",V="V",W="W",Y="Y",
            B=c("D","N"), Z=c("E","Q"), X=c("A","C","D","E","F","G","H","I","K","L","M","N","P","Q","R","S","T","V","W","Y")
        )
    )
    
    W <- length(words)
    lengths <- rep(0, W)
    for (i in 1:W) lengths[i] <- nchar(words[i])
    if (length(unique(lengths))>1) {
        stop("Words are of varying lengths!  Cannot continue.\n")
    } else {
        L <- lengths[1]
    }
    
    alpha <- alphabets[[alphabet]]
    degen <- degenerate[[alphabet]]
    pwm <- matrix(0, nrow=length(alpha), ncol=L)
    
    for (i in 1:W) {   # words
        chars <- toupper(unlist(strsplit(words[i],"")))
        if (gapAsN) chars[chars=="-"] <- "N"
        for (j in 1:L) {   # positions
            c2 <- degen[[chars[j]]]
            weight <- 1/length(c2)
            pwm[match(c2,alpha),j] <- pwm[match(c2,alpha),j] + rep(weight,length(c2))
        }
    }
    if (row.names) rownames(pwm) <- alpha
    pwm/W
}


apa.names$bio.seq <- c(apa.names$bio.seq, "PSSM2MEME")
PSSM2MEME <- function(PSSM, outpath, clobber=FALSE, N=1E4, max.denom=1E5, cycles=100, meme.exec="meme") {
    
    ## Converts a seqLogo-ready DNA PSSM into a realized sequence set.
    ## Runs the sequence set through MEME -mod oops to get a meme.html for the PSSM.
    ## 
    ## 'N' specifies a fixed number N of output sequences:
    ##   N is a maximum if needed -- if > necessary, then you will not get N sequences. 
    ##   if N < necessary, MEME PSSM will lose precision -- but require less computation.
    ## 'max.denom' = max sequences in set; also passed to fractions() as max.denominator;
    ##   if 'max.denom' too low, sequence set will have lower granularity than the given PSSM,
    ##   if 'max.denom' too high, algo drops to max 'max.denom' required for representative granularity, so GENERALLY the seq. set will not blow up
    ##   but: beware float issues with R -- VERY high max.denom (> 1E8) might get a denom size capable of resolving spurious float errors...
    ##        this will definitely make your seq. set size explode!
    ## 'cycles' is passed to MASS::fractions() as 'cycles'
    
    require("MASS")  # fractions()
    if (!is.matrix(PSSM)) PSSM <- as.matrix(PSSM)
    if (!is.matrix(PSSM)) stop("Input PSSM could not be recast as a matrix!\n")
    bases <- c("A","C","G","T")
    row <- 0
    mono <- FALSE
    
    pwd <- system("readlink -f .",intern=TRUE)
    outpath <- system(paste("readlink -f",outpath),intern=TRUE)
    if (outpath==pwd) stop("PSSM2MEME() output location cannot be the working directory!\n")
    if (clobber) system(paste("rm -rf",outpath))  ## and this is why...
    if (dir.exists(outpath)) stop("Requested output path already exists!  Will not overwrite.  You can set \"clobber=TRUE\".")
    system(paste("mkdir -p",outpath))
    if (!dir.exists(outpath)) stop("Failed to create requested output path!  Halting.")
   
    test <- PSSM
    test[test==0] <- 1
    if (all(c(test) >= 1)) {	# counts, not percents
        PSSM <- t( t(PSSM) / colSums(PSSM) )
    }
    
    if (ncol(PSSM) >= 8) {		# MEME requires sequences of width >= 8.
        unq.wts <- sort(unique(c(PSSM)))
        if (length(unq.wts) == 2) {
            if (all(unq.wts == c(0,1))) mono <- TRUE	# one-word PSSM (of passing width)
        }
    } else {		# Auto-pad PSSM to width 8
        pad <- matrix(0.25, nrow=4, ncol=8-ncol(PSSM))
        PSSM <- cbind(PSSM, pad)
        NC <- 8
    }
    
    NC <- ncol(PSSM)
    fracs <- matrix(0, nrow=nrow(PSSM)*ncol(PSSM), ncol=3)	# columns: PSSM column, local numerator, local denominator
    
    if (mono) {
        instance <- rep("", NC)
        for (i in 1:NC) instance[i] <- bases[which(PSSM[,i]==1)]
        seqs <- rep("",2)
        for (i in 1:2) seqs[i] <- paste(">sequence_",i,"\n",paste(instance,collapse=""),sep="")  # MEME requires 2+ sequences
    } else {
        ## get fractions
        for (j in 1:NC) {
            for (i in 1:nrow(PSSM)) {
                row <- row + 1
                if (is.na(PSSM[i,j])) { 	# missing position
                    fracs[row,] <- c(j,0,1)
                } else if (PSSM[i,j] == 1) { 	# fixed position
                    fracs[row,] <- c(j,1,1)
                } else {			# variable position
                    x <- as.numeric(unlist(strsplit(attr(fractions(PSSM[i,j], max.denominator=max.denom, cycles=cycles), 'frac'), '/')))  # fraction num, denom
                    if (length(x) == 1) x <- c(0,0) 	# PSSM[i,j] == 0 gets x == 0
                    fracs[row,] <- c(j, x)
                }
            }
        }
        
        ## convert fractions single denominator
        sort.d <- sort(unique(fracs[,3]), decreasing=TRUE)	# unique local denominators
                                        #		IM(sort.d)
        if (length(sort.d) == 1) {	# only 1 denom, so global = local: nothing else needed
            fracs2 <- fracs
            gdenom <- sort.d[1]
        } else {			# > 1 local denom: must unify
            gdenom <- LCD(1/sort.d)	# GLOBAL denominator (LCD of all local denominators)
            fracs2 <- fracs		# fracs2 = fracs but with global fractions, not local
            for (i in 1:length(sort.d)) {
                x <- which(fracs[,3] == sort.d[i])
                fracs2[x,2] <- fracs[x,2] * gdenom / fracs[x,3]
            }
            fracs2[is.na(fracs2)] <- 0
            fracs2[,3] <- rep(gdenom, nrow(fracs2))
        }
        ##nsums <- rep(0, NC)	# test vec: for each PSSM col, global numerators had better sum to global denominator
        ##for (i in 1:NC) { nsums[i] <- sum(fracs2[fracs2[,1]==i,2]) }
        ##IM(gdenom,":",nsums)
        
        ## generate representative sequences, using fracs2 as the probability model
        rdenom <- gdenom		# running denominator -- shrinks by 1 with each i
        seqmax <- ifelse(N > gdenom, gdenom, N)
        seqs <- rep("", seqmax)
        ##IM(gdenom, seqmax)
        for (i in 1:seqmax) {		# number of output sequences
            instance <- rep("", NC)
            for (j in 1:NC) {	# each position in seq
                x <- which(fracs2[,1]==j)
                probs <- fracs2[x,2] / rdenom
                last.warning <- c()
                if (any(probs == 1)) { 		# fixed position -- don't sample
                    ##IM(i,j,x)
                    instance[j] <- bases[probs==1]
                    y <- which(bases == instance[j])
                    fracs2[x[y],2] <- fracs2[x[y],2] - 1	# already used one instance; reduce probability going forward
                } else {
                    ##IM(i,j,':',probs)
                    instance[j] <- sample(bases, 1, prob=probs)
                    y <- which(bases == instance[j])
                    fracs2[x[y],2] <- fracs2[x[y],2] - 1	# already used one instance; reduce probability going forward
                }
                if (length(last.warning)>0) IM(i,j,":",x,fracs2[x,2],":",probs,":",probs*rdenom)
            }
            seqs[i] <- paste(instance,collapse="")
            rdenom <- rdenom - 1
        }
        names(seqs) <- paste0("sequence_",1:seqmax)
    }
    
    fa <- paste0(outpath,"/input.fa")
    write.fasta(seqs,fa)
    faB <- as.numeric(system(paste("cat",fa,"| wc -c"),intern=TRUE))
    meme.cmd <- paste(meme.exec,fa,"-oc",outpath,"-p 1 -dna -mod oops -w",NC,"-maxsize",faB*2)  # use '-oc' because we want to create the path first for confirmation, now requiring MEME to overwrite it.
    message(paste("Running:",meme.cmd))
    meme.err <- system(meme.cmd, intern=TRUE)
    message("MEME messages:")
    print(meme.err)
    if (exists("meme.err")) {
        message(paste0("\nMEME appeared to run sucessfully.  Results in '",outpath,"'.\n"))
    } else {
        message("\nMEME did not run sucessfully!\n")
    }
    invisible(seqs)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "PSSM.wordp")
PSSM.wordp <- function(word, PSSM, alphabet="DNA") {
    
    ## calculates the probability of getting a given word from a given PSSM.
    ## PSSM must be seqLogo formatted, i.e.:
    ##   DNA PSSM: 4 rows (1:4 = A,C,G,T), N columns for N positions; cols sum to 1.
    ##   DNA PSSM: 4 rows (1:4 = A,C,G,U), N columns for N positions; cols sum to 1.
    ##   AA PSSM: 20 rows (likewise in alphabetical order from 1 to 20), N columns for N positions; cols sum to 1.
    
    match.arg(alphabet, c("DNA","RNA","AA"))
    if (nchar(word) != ncol(PSSM)) stop("Word must have same width as PSSM!\n")
    bases <- unlist(strsplit(word, '', fixed=TRUE))
    legal <- list(
        DNA=c("A","C","G","T"),
        RNA=c("A","C","G","U"),
        AA=c("A","C","D","E","F","G","H","I","K","L","M","N","P","Q","R","S","T","V","W","Y")
    )
    if (!all(bases %in% legal[[alphabet]])) stop(paste("Word contains non-",alphabet," letters!\n",sep=""))
    xo <- match(bases, legal[[alphabet]])
    prob <- 1
    for (i in 1:length(xo)) prob <- prob * PSSM[xo[i],i]
    prob
}


apa.names$bio.seq <- c(apa.names$bio.seq, "PSSM.realize")
PSSM.realize <- function(PSSM, alphabet="DNA", N.as.N=TRUE) {
    
    ## calculates all possible words from a PSSM, with their PSSM probabilities.
    ## PSSM must be seqLogo formatted, i.e.:
    ##   DNA PSSM: 4 rows (1:4 = A,C,G,T), N columns for N positions; cols sum to 1.
    ##   DNA PSSM: 4 rows (1:4 = A,C,G,U), N columns for N positions; cols sum to 1.
    ##   AA PSSM: 20 rows (likewise in alphabetical order from 1 to 20), N columns for N positions; cols sum to 1.
    ## N.as.N will convert an N columns as "N", instead of creating A,C,G,T (or whatever alphabet) versions.
    ##   If alphabet is "AA", then "N.as.N" becomes "X.as.X", basically.
    
    ## NOT	## If PSSM has rownames, these take precedence in word-building.  Otherwise, "alphabet" MUST be specified.
    
    N <- 1
    NR <- nrow(PSSM)
    NC <- ncol(PSSM)
    
    bases <- list(
        DNA=c("A","C","G","T"),
        RNA=c("A","C","G","U"),
        AA=c("A","C","D","E","F","G","H","I","K","L","M","N","P","Q","R","S","T","V","W","Y")
    )
    rownames(PSSM) <- bases[[alphabet]]
    
    if (N.as.N) {
        ## split out ambig char as final row and give ambig columns perfect conservation
        if (alphabet=="AA") {
            w.X <- which(apply(PSSM, 2, luniq)==1)  # if all values same, then position is X
            PSSM <- rbind(PSSM[1:20,], rep(0,NC))
            rownames(PSSM)[21] <- "X"
            PSSM[1:20,w.X] <- 0
            PSSM[21,w.X] <- 1
        } else {
            w.N <- which(apply(PSSM, 2, luniq)==1)  # if all values same, then position is N
            PSSM <- rbind(PSSM[1:4,], rep(0,NC))
            rownames(PSSM)[5] <- "N"
            PSSM[1:4,w.N] <- 0
            PSSM[5,w.N] <- 1
        }
    }
    
    for (i in 1:NC) N <- N * sum(PSSM[,i]!=0)
    message(paste(N,ifelse(N==1,"word","words"),"will be generated"))
    
    if (N==1) {
        
        ## all positions are 1|0; easy solution
        word <- paste(apply(PSSM, 2, function(x) rownames(PSSM)[x==1] ), collapse="")
        space <- data.frame(word, 1, 1, stringsAsFactors=FALSE)
        
    } else {
        
        ## positions are complex; hard solution
        words <- rep("", N)
        cprob <- rep(0, N)
        aprob <- rep(0, N)
        
        counter <- 0
        recurse <- function(root, cprb, aprb, col) {
            if (col > NC) {
                ## GLOBAL ASSIGNMENTS !!!!
                counter <<- counter + 1
                words[counter] <<- root
                cprob[counter] <<- cprb
                aprob[counter] <<- aprb
            } else {
                roots <- rep(root, NR)
                cprbs <- rep(cprb, NR)
                aprbs <- rep(aprb, NR)
                for (row in 1:NR) {
                    if (PSSM[row,col] != 0) {
                        roots[row] <- paste(roots[row], rownames(PSSM)[row], sep="")
                        cprbs[row] <- cprbs[row] * PSSM[row,col]
                        aprbs[row] <- aprbs[row] + PSSM[row,col]
                        recurse(roots[row], cprbs[row], aprbs[row], col+1)
                    }
                }
            }
        }
        recurse('', 1, 0, 1)  # loads 'words', 'cprob', and 'aprob'
        words <- sapply(words, FUN=function(x) sub(" ","",x) )
        space <- data.frame(words, cprob, aprob, stringsAsFactors=FALSE)
        space[,3] <- space[,3] / NC	 # now, average
        space <- nameless(space[order(space[,2], decreasing=TRUE),])
    }
    colnames(space) <- c("Word","Cum.Prob","Avg.Prob")
    space
}


apa.names$bio.seq <- c(apa.names$bio.seq, "PSSM.align")
PSSM.align <- function(pwms, ref=1, min.overlap=4) {
    
    ## 'pwms' is a list of seqLogo-ready PWMs; 4 rows, in A,C,G,T order; cols are positions
    ## 'ref' is the index (in 'pwms') of the 'reference' PWM, to which all the others are aligned
    ##  - eventually the default will be a 2-iteration approach which uses the averaged aligned PWM from iter 1 as the reference for iter 2
    ## 'min.overlap' indicates the minimum number of positions required for alignment
    ## returned: list with 'stats' = offsets and dirs; 'aligned' with fully-justified, optimally-aligned PWMs

    align <- function(mot, ref, mov) {

        ## 'mot' is motif pwm; 'ref' is reference-motif pwm, 'mov' is min.overlap
        ##
        ##  Progression of pairwise alignments (MOT vs REF) from offset positions -max.overhang to max.refpos (examples of 5 basic positions):
        ##  Progression of pairwise alignments (MOT vs REF) from offset positions -max.overhang to max.refpos (examples of 5 basic positions):
        ##
        ##   MOT < REF                          REF < MOT
        ##    
        ##       1 2 3 4 5 6 7 8 9 0                        1 2 3 4 5 6
        ##   1 2 3 4 5 6                        1 2 3 4 5 6 7 8 9 0
        ##    
        ##       1 2 3 4 5 6 7 8 9 0                        1 2 3 4 5 6
        ##       1 2 3 4 5 6                        1 2 3 4 5 6 7 8 9 0
        ##         
        ##       1 2 3 4 5 6 7 8 9 0                        1 2 3 4 5 6
        ##           1 2 3 4 5 6                        1 2 3 4 5 6 7 8 9 0
        ##         
        ##       1 2 3 4 5 6 7 8 9 0                        1 2 3 4 5 6
        ##               1 2 3 4 5 6                        1 2 3 4 5 6 7 8 9 0
        ##     
        ##       1 2 3 4 5 6 7 8 9 0                        1 2 3 4 5 6
        ##                   1 2 3 4 5 6                        1 2 3 4 5 6 7 8 9 0
        ##    
        
        rangemaker <- function(i) {
            mot.start <- ifelse(i>=0, 1, 1-i)
            ref.start <- ifelse(i<1, 1, i+1)
            overlap <- ifelse(i<=0, min(mot.len+i, ref.len), min(ref.len-ref.start+1, mot.len))
            mot.end <- ifelse(i<=0, ifelse(mot.len+i<=ref.len, mot.len, ref.len-i), ifelse(overlap>=mot.len, mot.len, overlap))
            ref.end <- ifelse(i<=0, ifelse(mot.len+i<=ref.len, overlap, ref.len), ifelse(overlap>=mot.len, ref.start+overlap-1, ref.len))
            list(REF=ref.start:ref.end, MOT=mot.start:mot.end, OVR=overlap, OFF=i)
        }
        
        ref.len <- ncol(ref)
        mot.len <- ncol(mot)
        max.overhang <- mot.len-mov  # max N bp for mot to overhang from ref
        max.refpos <- ref.len-mov+1  # right-most ref pos from which an alignment with mot can begin
        
        ranges <- lapply(-max.overhang:max.refpos, rangemaker)
        n <- length(ranges)
        
        cnames <- qw(Overlap,Offset,Cor,Info,RC.Cor,RC.Info)
        dat <- matrix(NA, n, length(cnames), F, list(1:n,cnames))
        sub.aligns <- list()
        mot.rev <- PSSM.revcomp(mot)
        
        for (i in 1:length(ranges)) {
            ref.cols <- ref[,ranges[[i]]$REF]      # positions in larger PWM being compared
            mot.cols <- mot[,ranges[[i]]$MOT]      # in smaller
            rev.cols <- mot.rev[,ranges[[i]]$MOT]  # same positions in revcomp (***NOT*** REVCOMP OF 'mot.cols' !!!!!)
            ref.info <- sum(seqLogo:::pwm2ic(ref.cols))                # info content of ref.cols
            mot.info <- min(ref.info, sum(seqLogo:::pwm2ic(mot.cols)))  # min info for blocks being compared (ref-mot comparison)
            rev.info <- min(ref.info, sum(seqLogo:::pwm2ic(rev.cols)))  # same for ref-rev comparison
            mot.corr <- cor(c(ref.cols),c(mot.cols))  # ref-mot correlation
            rev.corr <- cor(c(ref.cols),c(rev.cols))  # ref-rev correlation
            offset <- ranges[[i]]$OFF
            overlap <- ranges[[i]]$OVR
            dat[i,] <- c(overlap, offset, mot.corr, mot.corr*mot.info, rev.corr, rev.corr*rev.info)
            sub.aligns[[i]] <- rbind(ref.cols, mot.cols)  # ALWAYS mot.cols, NOT rev.cols
        }
        
        list(data=dat, aligns=sub.aligns)
    }
    
    
    ## #####  BEGIN MAIN FUNCTION  #####

    
    ok <- require(seqLogo)
    if (!ok) stop("Failed to load library 'seqLogo'!\n")
    N <- length(pwms)
    if (ref < 1 | ref > N) stop("Invalid 'ref' value: < 1, or > length(pwms)!\n")
    lens <- sapply(pwms, ncol)   # motif lengths
    revs <- lapply(pwms, PSSM.revcomp)   # motif revcomps
    dist <- sapply(1:N, function(i) lens[[i]]-lens[[ref]] )   # difference in lengths between motif and reference
    aligned <- pwms
    
    stats <- lapply(pwms, function(x) align(x,pwms[[ref]],min.overlap) )
    
    optima <- matrix(0, N, 2, F, list(1:N,qw(Offset,Dir)))
    for (i in 1:N) {
        gmax <- which.max(apply(stats[[i]]$data[,c(4,6)], 1, max))  # row with global max info score
        dmax <- which.max(stats[[i]]$data[gmax,c(4,6)])             # PWM match direction for that score
        optima[i,] <- c(stats[[i]]$data[gmax,2], c(1,-1)[dmax])  # export score, direction
    }
    
    best.rev <- which(optima[,2]==-1)
    if (length(best.rev)>0) {
        for (i in best.rev) {
            pwms[[i]] <- revs[[i]]
            stats[[i]] <- align(pwms[[i]],pwms[[ref]],min.overlap)
        }
        for (i in best.rev) {
            gmax <- which.max(apply(stats[[i]]$data[,c(4,6)], 1, max))
            dmax <- which.max(stats[[i]]$data[gmax,c(4,6)])
            optima[i,] <- c(stats[[i]]$data[gmax,2], c(1,-1)[dmax])
        }
    }
    
    optima <- cbind(optima, Adj.Offset=optima[,1]-min(optima[,1]))
    offset.range <- range(unlist(lapply(1:N, function(i) c(optima[i,1],lens[i]+optima[i,1]) )))
    W <- diff(offset.range)
    aligned <- lapply(pwms, function(x) matrix(0.25, 4, W) )   # fully justified PWMs
    for (i in 1:N) aligned[[i]][,(optima[i,3]+1):(optima[i,3]+lens[i])] <- pwms[[i]]  # no revcomps, because top-RC matches have been converted to non-RC matches

    list(stats=slice.list(stats,1), sub.aligns=slice.list(stats,2), optima=optima, aligned=aligned)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "PSSM.revcomp")
PSSM.revcomp <- function(x) {
    
    ## x is a 4-row PSSM (seqLogo style)
    
    lx <- ncol(x)
    rc <- x[,lx:1]
    for (i in 1:lx) rc[,i] <- rc[4:1,i]
    
    rc
}


apa.names$bio.seq <- c(apa.names$bio.seq, "word.similarity")
word.similarity <- function(kmers, max.mm=NA) {
    
    ## takes a vector of equal-length words and determines how many word-word conversions can be made using <= max.mm changes
    ##   basically, summarizes the lower-triangular Hamming distance matrix for the word set
    ## 'kmers' is the word vector
    ## 'max.mm=NA' will report all distances
    
    N <- length(kmers)
    vecs <- strsplit(kmers,"")
    mat <- matrix(NA, nrow=N, ncol=N)
    for (i in 1:N) {
        for (j in 1:(i-1)) {
            mat[i,j] <- sum(vecs[[i]] != vecs[[j]])
        }
    }
    summ1 <- table(c(mat))
    if (is.na(max.mm)) {
        summ2 <- c(summ1)
    } else {
        summ2 <- c(summ1)[as.numeric(names(summ1))<=max.mm+1]
        summ2[max.mm+1] <- sum( c(summ1)[as.numeric(names(summ1))>max.mm] )
    }
    summ3 <- as.matrix(as.numeric(summ2))
    colnames(summ3) <- "Pairs"
    rownames(summ3) <- c( names(summ2)[1:max.mm], paste(">",max.mm,sep="") )
    summ3
}


apa.names$general <- c(apa.names$general, "motif.killcurve")
motif.killcurve <- function(fg.p, bg.p, N=1000) {
	
	## Compares foreground vs background CDFs and finds crossover point, if any
	## Designed to compute a kill-curve-based p-value for PWM matches, given vectors of foreground and background p-values
	## Also for finding critical dropoffs with chipseq IP/inp-vs-inp/IP peak calls
	## 'N' specifies the sampling for the p-value CDF (N bins to break p-value range into)
	
	cdf <- get.killcurve.cdf(fg.p, bg.p, N)
	comp <- cdf$cdf[2,] > cdf$cdf[3,]
	pass <- FALSE
	
	if (sum(comp)==N) {  # FG hit rate exceeds BG hit rate (or vice versa) over whole range; min value is sufficient
		pass <- TRUE
		thresh <- cdf$cdf[1,1]
	} else if (sum(comp)>0) {
		x <- diff(comp)
		inits <- which(x==1)+1
		for (i in inits) {
			if (sum(comp[i:N])/(N-i+1) > 0.5) {  # FG exceeds BG (or vice versa) for over half the range?
				pass <- TRUE
				thresh <- cdf$cdf[1,i]
				break  # stop if true
			}
		}
	}
	if (pass) {
		pass.fg <- sum(fg.p<=thresh)
		pass.bg <- sum(bg.p<=thresh)
		passing <- c(FG=pass.fg, FG.PCT=pass.fg/length(fg.p), BG=pass.bg, BG.PCT=pass.bg/length(bg.p))
	} else {
		thresh <- NA   # only passing motifs return a p-value threshold 
		passing <- c(FG=NA, FG.PCT=NA, BG=NA, BG.PCT=NA)
	}
	
	c(cdf, list(threshold=thresh, abline=rescale(thresh,from=range(as.numeric(cdf$axis.lab)),to=c(1,N)), passing=passing))
}
