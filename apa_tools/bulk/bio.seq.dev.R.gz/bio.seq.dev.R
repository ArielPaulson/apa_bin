

apa.names$bio.seq <- c(apa.names$bio.seq, "bio.seq.rand")
bio.seq.rand <- function(N=100, lengths=100, len.fun="unif", alpha="N", degenerate=FALSE, nonstandard=FALSE, wildcards=FALSE, uracil=FALSE, freq=NULL, f.local=TRUE, f.guar=1, fasta=FALSE, filename=NULL) {
	
	## "N": number of sequences to generate.
	## "lengths": sequence length, as single integer or vector.  If vector (e.g. 100:200), lengths gets sampled randomly from vector.
	## "len.fun:" currently "unif" or "norm": if "lengths" was a vector, how to sample actual sequence lengths?
	## "alpha": "N" for nucleotide, "A" for amino acid.  If value is a vector, then this becomes the alphabet itself.
	## "freq": a NAMED vector of base frequencies, where elements = percents on [0,1] and names = bases.  If null, all bases are equally probable.
	## "f.local": T/F apply "freq" values locally (each individual sequence) or only globally (whole sequence set)?
	## "fasta": T/F return sequences as a fasta-formatted string?
	## "filename": if specified, results are printed directly to this file.
	##
	## The following only apply if alpha = "N" or "A":
	##   "degenerate": T/F include degenerate characters?  (NOT including full wildcards "N", "X").
	##   "nonstandard": T/F allow nonstandard bases/residues?
	##   "wildcards": allow full wildcards? (adds "N" if nucleotide, "X" if amino acid).
	##   "uracil": T/F use U instead of T? (only if alpha=N).
	
	if (length(lengths) == 1) { 
		seqlens <- rep(lengths, N)
	} else if (len.fun == "unif") {
		seqlens <- unif(N, lengths)
	} else if (len.fun == "norm") {
		prelens <- len.fun(N, mean=mean(lengths), sd=sd(lengths))
		seqlens <- quantize(prelens, lengths)
	}
	
	if (any(lengths < 1)) { stop("Negative sequence lengths not allowed!\n") }
	
	if (alpha == "N") {
		
		alphabet <- c("A","C","G","T")								# Basic nucleotide alphabet
		if (uracil) { alphabet[4] <- "U" }							# switch T to U
		if (degenerate) { alphabet <- c(alphabet, c("R","Y","S","W","K","M","B","D","H","V")) }	# tack on degenerate codes
		if (nonstandard) {  alphabet <- c(alphabet, c("I","Q","X","S","O","B","D")) }		# nonstandards, per http://www.chem.qmul.ac.uk/iupac/misc/naabb.html#symbol, but some are redundant to degen.
		if (wildcards) { alphabet <- c(alphabet, "N") }						# tack on X or N wildcard
		if (nonstandard & degenerate) { alphabet <- alphabet[!duplicated(alphabet)] }		# B, D redundant; remove duplicates		
		
	} else if (alpha == "A") {
		
		alphabet <- c("A","C","D","E","F","G","H","I","K","L","M","N","P","Q","R","S","T","V","W","Y")	# Basic amino acid alphabet
		if (degenerate) { alphabet <- c(alphabet, c("B","Z","J",)) }					# tack on degenerate codes
		if (nonstandard) {  alphabet <- c(alphabet, c("U","O")) }					# nonstandards, per Wikipedia
		if (wildcards) { alphabet <- c(alphabet, "X") }							# tack on X or N wildcard
		
	} else {
		
		if (length(alpha) == 1) { stop("Only 'N' or 'A' recognized for one-letter alphabets...  Custom alphabets need > 1 character!\n") }
		alphabet <- alpha
		
	}
	
	alphabet <- sort(alphabet)
	sequences <- vector("character", length=N)
	
	if (!is.null(freq)) {
		if (sum(freq) != 1) { stop("'freq' vector does not sum to 1!\n") }
		if (length(freq) != length(alphabet)) { stop("'freq' vector must have same length as alphabet!\n") }
	
		f2a <- match(names(freq), alphabet)
		if(any(is.na(f2a))) { stop("'freq' vector does not have 1:1 correspondence with the alphabet!\n") }
		freq <- freq[order(names(freq))]
	} else {
		freq <- rep(1/length(alphabet), length(alphabet))	# default base freq = uniform probability vector
	}
	

###########################################
if (FALSE) {
	
	## upgrade: specify frequencies for each base
	##          per-read base freq saturation from 0-100% (round % up to nearest mod)
	##	    saturation will be additionally less guaranteed for sequences sets of variable length
	## "Saturation" means "the [approximate] minimum probability that any single sequence will have the specified base frequencies."
	## 1. The shorter your read length, the harder it will be to get the saturation you want
	## 2. In order to satisfy both global and local frequency criteria, N may be increased internally, then only the original-N sequences returned.
	
	if (!is.null(freq)) {
		if (sum(freq) != 1) { stop("Base frequency vector does not sum to 1!\n") }
		code <- "C"	# for "custom"
		alphabets$C <- names(freq)
		ok.len <- TRUE
		minL <- freq
		for (i in freq) {
			minL <- f.guar * i
			if (lengths[1] * i < f.guar) { ok.len <- FALSE }
		}
		if (!ok.len) { 
			msg <- paste("Warning: minimum sequence length of ",min(minL)," is required to guarantee ",100*f.guar,"% saturation!\n",sep="")
			cat(msg); flush.console() 
		}
		if (var.len) {
			len.list <- rep(0, length=N)
			for (i in 1:N) { len.list[i] <- floor(lenDensFun(1, lengths[1], lengths[2])) }
		} else {
			len.list <- rep(lengths[1], N)
		}
		len.tot <- sum(len.list)
		
		
		
		############### WORKING HERE ###############
		## define num tiles in order to get target saturation per seq
		## increase seq N to make totalTileLen % totalSeqLen == 0
		## for each tile: apply required base freqs, load vector, then resample the whole thing (n times?) to randomize
		## cat all tiles, then chop string into N seqs	
		## crop N to output length
		
		
	} else {
		for (i in 1:N) { 
			len <- floor(lenDensFun(1, lengths[1], lengths[2]))
			seq <- paste(sample(alphabets[[code]], len, replace=TRUE), collapse="")
			if (fasta == 1) {
				sequences[i] <- paste(">", i, "\n", seq, sep="")
			} else {
				sequences[i] <- seq
			}
		}
	}
}
###########################################

	if (f.local) {
		for (i in 1:N) { 
			seq <- paste(sample(alphabet, seqlens[i], replace=TRUE, prob=freq), collapse="")
			sequences[i] <- ifelse (fasta == 1, paste(">", i, "\n", seq, sep=""), seq)
		}
	} else {
		tot.len <- sum(seqlens)
		tot.seq <- sample(alphabet, tot.len, replace=TRUE, prob=freq)
		end <- 0
		for (i in 1:N) { 
			start <- end + 1
			end <- end + seqlens[i]
			seq <- paste(tot.seq[start:end], collapse="") 
			sequences[i] <- ifelse (fasta == 1, paste(">", i, "\n", seq, sep=""), seq)
		}
	}
		
	if (!is.null(filename)) {
		write.table(sequences, file=filename, quote=FALSE, col.names=FALSE, row.names=FALSE)
	} else {
		return(sequences)
	}
}


apa.names$bio.seq <- c(apa.names$bio.seq, "bio.seq.QC")
bio.seq.QC <- function(seqs, extended=FALSE, chr=FALSE, imgfile="sequence.properties.pdf", txtfile=NULL) {
	
	## Summary statistics for a set of character sequences.
	## "extended=T": if char set is common to amino acids AND extended nucleotide alphabet, use nucleotide.
	## "chr=T" flags sequences as chromosomes; get some additional individual data per sequence.
	## If variable length: length histo.
	## If fixed length: positional bp freqs.
	## Char-count table.
	## As well as: # reads having base _, local/global bp freq densities, summary() for each local base freq + the global freqs.
	
	if (class(seqs) %in% c("BString","DNAString","RNAString","AAString")) {		# Biostrings object
		
	} else {	# regular R object? (vector, list, matrix)
		if (is.matrix(seqs)) {
			seqnames <- rownames(seqs)
			ternary ( ncol(seqs) == 1, seqs <- seqs[,1], stop("Input cannot be a multicolumn matrix!\n") )
		} else {
			seqnames <- names(seqs)
			seqs <- unlist(seqs)	# in case of a list
		}
		N <- length(seqs)
		lendist.t <- sapply(seqs, simplify=TRUE, nchar)
		names(lendist.t) <- NULL
		lendist.u <- unique(lendist.t)
	}
	
	## alphabet assignment
	alphabets <- list(
		N=c("A","C","G","T","U","N"),
		X=c("A","C","G","T","U","R","Y","S","W","K","M","B","D","H","V","N"),
		A=c("A","C","D","E","F","G","H","I","K","L","M","N","P","Q","R","S","T","V","W","Y","X")
		####### Add other alphabets here
	)
	
	tables <- list()
	Nalpha <- length(alphabets)
	catseq <- paste(seqs, collapse="")
	bseq <- unlist(strsplit(catseq, split=""))	# single vector of all characters in seqs
	chars <- sort(unique(bseq))	# unique chars
	Nc <- length(chars)
	contained <- rep(TRUE,Nalpha )
	for (i in 1:Nalpha ) {
		for (j in chars) {
			if (!j %in% alphabets[[i]]) { contained[i] <- FALSE }
		}
	}
	
	charcols <- NULL
	if (contained[1]) {		# basic nucleotide
		alpha <- 1
		charcols <- data.frame(CHAR=alphabets[[1]], COL=c(2,"gold3",3,4,5,8), stringsAsFactors=FALSE)
	} else if (contained[3]) {	# amino acid
		alpha <- 3
		# nonpolars = green-blue, polars = red-yellow, acids = brown, bases = purple, X = gray
		charcols <- data.frame(CHAR=alphabets[[3]], COL=c(2,"gold3","salmon",6,7,"red4","darkorange2",3,4,5,"dodgerblue3","green4","lightskyblue2","olivedrab1","aquamarine3","cadetblue4","purple3","plum","lightgoldenrod4","darkolivegreen",8), stringsAsFactors=FALSE)
		if (contained[2] && !extended) { IM("Warning: characters are common subset of amino acids *and* IUPAC extended nucleotides.  Assuming amino acid...\n") }
	} else if (contained[2]) {	# least likely -- extended nucleotide
		alpha <- 2
		charcols <- data.frame(CHAR=alphabets[[2]], COL=c(2,"gold3",3,4,5,"salmon","lightgoldenrod4",6,"dodgerblue3",7,"purple3","red4","green4","orange2","thistle",8), stringsAsFactors=FALSE)
		
	####### Add other alphabet tests here
		
	} else {				# who knows what
		IM("Warning: character set not contained in known alphabets.\n")
		alpha <- Nalpha + 1
		alphabets[[alpha]] <- chars
	}
	
	if (Nc < 10) {
		imgwidth <- 5
		lgcols <- 1
		if (is.null(charcols)) {  }
	} else if (Nc < 25) {
		imgwidth <- 7
		lgcols <- 1
		if (is.null(charcols)) {  }
	} else if (Nc > 25) {
		imgwidth <- 8
		lgcols <- ceiling(Nc/20)
		if (is.null(charcols)) { charcols <- hsv(seq(0,1,length.out=Nc+1)[1:Nc],c(1,0.5),c(0.5,1)) }
	}
	if (is.null(imgfile)) { imgfile <- "sequence.properties.pdf" }
	pdf(imgfile, height=5, width=imgwidth)
	par(mar=c(5,5,4,2), cex=0.7)
	bcol <- "dodgerblue3"
	
	## character census
	alphalen <- length(alphabets[[alpha]])
	local.census <- matrix(data=0, nrow=N, ncol=alphalen)
	colnames(local.census) <- alphabets[[alpha]]
	for (i in 1:alphalen) {
		local.census[,i] <- sapply(seqs, simplify=TRUE, FUN=function(x,a){sum(unlist(strsplit(x,""))==a)},alphabets[[alpha]][i])
	}
	global.census <- colSums(local.census) / length(bseq)	# as percent
	names(global.census) <- alphabets[[alpha]]
	local.census <- local.census / lendist.t		# as percent
	
	tables$local.census <- local.census
	tables$global.census <- global.census
	
	for (i in which(colSums(local.census) == 0)) { local.census[,i] <- rep(NA, N) }
	global.census[global.census==0] <- NA
	barplot(global.census, beside=TRUE, space=0.4, col=bcol, border=bcol, ylab="Percent of All Bases", main="Base Content for All Fragments")
	boxplot(local.census, ylab="Percent of Fragment", main="Base Content per Fragment")
	abline(h=1/Nc, col=2, lty=2)
	
	## chromosomal analyses
	# lengths, GC content plots
	if (chr) { barplot(log10(lendist.t), beside=TRUE, names.arg=names(seqs), main="Chromosome Lengths") }	
	
	if (alpha == 1) {
		GCP <- rowSums(local.census[,2:3])
		hist(GCP, col=0, border=0, freq=F, xlab="GC Percent", main="GC Content per Fragment")
		lines(density(GCP))
		abline(v=sum(global.census[2:3]), col=2, lty=2)
	}
	
	## reads with N unique bases
	char.PA <- matrix(data=0, nrow=2, ncol=alphalen)
	rownames(char.PA) <- c("Present","Absent")
	colnames(char.PA) <- alphabets[[alpha]]
	withN <- matrix(nrow=1, ncol=alphalen)
	rownames(withN) <- "withNBases"
	colnames(withN) <- 1:alphalen
	for (i in 1:alphalen) {
		char.PA[1,i] <- sum(local.census[,i] > 0, na.rm=T)
		char.PA[2,i] <- sum(local.census[,i] == 0, na.rm=T)
		withN[1,i] <- sum(apply(local.census, 1, FUN=function(x,i){sum(x!=0,na.rm=T)==i},i) > 0)
	}
	char.PA <- t( t(char.PA) / N )	# as percent
	char.PA[2,which(char.PA[1,] == 0)] <- 1
	withN <- withN / N			# as percent
	
	tables$char.PA <- char.PA
	tables$with.N <- withN
	
	withN[withN == 0] <- NA
	char.PA[char.PA == 0] <- NA
	barplot(char.PA[1,], beside=TRUE, space=0.4, col=bcol, border=bcol, ylim=c(0,1), ylab="Percent", main="Percent of Reads Containing Given Base")
	barplot(withN, beside=TRUE, axis.lty=1, offset=0.005, col=bcol, border=bcol, ylim=c(0,1), ylab="Percent of Fragments", main="Fragments with N Unique Bases")
	
	## length-specific analyses
	if (length(lendist.u) == 1) {	
		if (lendist.u[1] <= 100) {	# positional analysis for constant length, < 100bp only
			## positional bp frequencies
			positional <- matrix(data=0, nrow=lendist.u, ncol=alphalen)
			colnames(positional) <- alphabets[[alpha]]
			pos.mat <- matrix(bseq, byrow=TRUE, nrow=N, ncol=lendist.u)
			for (i in 1:alphalen) { positional[,i] <- colSums(pos.mat == alphabets[[alpha]][i]) }
			positional <- t( t(positional) / N )	# as percent
			
			tables$positional <- positional
			
			for (i in which(colSums(positional) == 0)) { positional[,i] <- rep(NA, lendist.u) }
			ylims <- c(min(positional,na.rm=T),max(positional,na.rm=T))
			plot(1:lendist.u, 1:lendist.u, type="l", ylim=ylims, xlab="Position in Fragment", ylab="Percent Occurrance", main="Positional Base Frequencies")
			for (i in 1:ncol(positional)) { lines(1:lendist.u, positional[,i], col=charcols[i,2]) }
			abline(h=1/Nc, col=1, lty=2)
			
			plot(0:1, 0:1, type="n", axes=F, xlab="", ylab="", main="Positional Base Frequencies Legend")
			ternary(lgcols == 1, xslots <- 0.5, xslots <- seq(0, 1, length.out=lgcols+2)[1:lgcols+1])
			yblocks <- ceiling(Nc/lgcols)
			lgrows <- 20
			if (Nc > lgrows) { 
				off1 <- ifelse (Nc %% lgcols == 1, TRUE, FALSE) 
				yslots <- seq(0, 1, length.out=lgrows+1)
			} else {
				off1 <- FALSE
				yslots <- seq(0, 1, length.out=lgrows)
			}
			assigned <- 0
			for (i in 1:lgcols) {	# assign char entries to a particular column
				a <- assigned + 1
				b <- assigned + yblocks
				assigned <- assigned + yblocks
				remain <- Nc - assigned
				if (off1) {
					if (remain == 1) {	# tack on last one, don't start new column...
						b <- b + 1
						cha <- chars[a:b]
					} else {			# tack on spacer instead
						cha <- c(chars[a:b], "")
					}
				} else {
					cha <- chars[a:b]
				}
				col <- charcols[match(cha,charcols[,1]),2]
				yL <- length(cha)
				ysrange <- (length(yslots)-yL+1):length(yslots)
				segments(rep(xslots[i]-0.15,yL), yslots[ysrange], rep(xslots[i]-0.05,yL), yslots[ysrange], col=rev(col))
				text(rep(xslots[i],yL), yslots[ysrange], labels=rev(cha), pos=4)
			}
		} else {
			IM("Too long for positional analysis: up to 100bp only.\n")
		}
	} else {
		## length histogram
		if (max(lendist.t) - min(lendist.t) <= 20) {	# bins of length 1
			breaks <- length(lendist.u)
		} else {	# let hist decide
			breaks <- "Sturges"
		}
		hist(lendist.t, xlab="Length", ylab="", breaks=breaks, main="Fragment Lengths")
		abline(v=mean(lendist.t), lty=2)
		
		
	}
	dev.off()
	invisible(tables)
}
