

## Modified and extended functions from the seqLogo package.


apa.names$bio.seq <- c(apa.names$bio.seq, "seqLogo.title") 
seqLogo.title <- function (pwm, title=NULL, y.scale=FALSE, ic.scale = TRUE, xaxis = TRUE, yaxis = TRUE, xfontsize = 15, yfontsize = 15) {
	
	require("seqLogo")
    if (class(pwm) == "pwm") {
        pwm <- pwm@pwm
    } else if (class(pwm) == "data.frame") {
        pwm <- as.matrix(pwm)
    } else if (class(pwm) != "matrix") {
        stop("pwm must be of class matrix or data.frame")
    }
    if (any(abs(1 - apply(pwm, 2, sum)) > 0.01)) stop("Columns of PWM must add up to 1.0")
    chars <- c("A", "C", "G", "T")
    letters <- list(x = NULL, y = NULL, id = NULL, fill = NULL)
    npos <- ncol(pwm)
    if (ic.scale) {
        ylim <- 2
        ylab <- "Information content"
        facs <- seqLogo:::pwm2ic(pwm)
    } else {
        ylim <- 1
        ylab <- "Probability"
        facs <- rep(1, npos)
    }
    yscale <- ifelse(is.logical(y.scale), ifelse(y.scale, max(facs), ylim), y.scale)
    wt <- 1
    x.pos <- 0
    for (j in 1:npos) {
        column <- pwm[, j]
        hts <- 0.95 * column * facs[j]
        letterOrder <- order(hts)
        y.pos <- 0
        for (i in 1:4) {
            letter <- chars[letterOrder[i]]
            ht <- hts[letterOrder[i]]
            if (ht > 0) letters <- seqLogo:::addLetter(letters, letter, x.pos, y.pos, ht, wt)
            y.pos <- y.pos + ht + 0.01
        }
        x.pos <- x.pos + wt
    }
    grid.newpage()
    bottomMargin = ifelse(xaxis, 2 + xfontsize/3.5, 2)
    leftMargin = ifelse(yaxis, 2 + yfontsize/3.5, 2)
    pushViewport(plotViewport(c(bottomMargin, leftMargin, 2, 2)))
#    pushViewport(dataViewport(0:ncol(pwm), 0:ylim, name = "vp1"))
    pushViewport(dataViewport(0:ncol(pwm), 0:ylim, name = "vp1", yscale=c(0,yscale)))
    grid.polygon(x = unit(letters$x, "native"), y = unit(letters$y, "native"), id = letters$id, gp = gpar(fill = letters$fill, col = "transparent"))
    if (xaxis) {
        grid.xaxis(at = seq(0.5, ncol(pwm) - 0.5), label = 1:ncol(pwm), gp = gpar(fontsize = xfontsize))
        xlab <- ifelse(is.null(title), "Position", paste("Position along",title))
        grid.text(xlab, y = unit(-3, "lines"), gp = gpar(fontsize = xfontsize))
    }
    if (yaxis) {
        grid.yaxis(gp = gpar(fontsize = yfontsize))
        grid.text(ylab, x = unit(-3, "lines"), rot = 90, gp = gpar(fontsize = yfontsize))
    }
    popViewport()
    popViewport()
    par(ask = FALSE)
    invisible(facs)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "plotLogo")
plotLogo <- function(x, imgname, title=NULL, y.scale=FALSE, ic.scale=TRUE, xaxis=TRUE, yaxis=TRUE, xfontsize=15, yfontsize=15) {
	
	## seqLogo.title()->png() wrapper with constant letter scales
	
	require("seqLogo")
	N <- ncol(x)
	png(imgname, 170+60*N, 400)  # 400px high; 170px base width + 60px per letter
	par(xaxs="i")
	seqLogo.title(x, title=title, y.scale=y.scale, ic.scale=ic.scale, xaxis=xaxis, yaxis=yaxis, xfontsize=xfontsize, yfontsize=yfontsize)
	dev.off()
}


apa.names$bio.seq <- c(apa.names$bio.seq, "logo.batchpdf")
logo.batchpdf <- function(pwms, imgname, ppi=100) {
	
	## plot a list of logos ('pwms') to a multi-page PDF
    ## ppi' = pixels per inch, to convert image dims into inches for pdf()
        
	require("seqLogo")
	pdf(imgname, width=(170+60*ncol(pwms[[1]]))/ppi, height=400/ppi)  # inches
#	pdf(imgname)
	for (i in 1:length(pwms)) seqLogo.title(pwms[[i]], title=names(pwms)[i])
	dev.off()
}


apa.names$seqLogo2 <- c(apa.names$seqLogo2, "pwm2cons2")
pwm2cons2 <- function (pwm, alphabet) {
	if (class(pwm) != "matrix") {
		warning("pwm argument must be of class matrix")
	}
	if (alphabet == "DNA") {
		letters1 <- c("A","C","G","N","T")	# input rows must be in this order, OR lack "N"
		letters2 <- c("A","C","G","T")
	} else if (alphabet == "RNA") {
		letters1 <- c("A","C","G","N","U")	# input rows must be in this order, OR lack "N"
		letters2 <- c("A","C","G","U")
	} else if (alphabet == "AA") {
		letters1 <- c("A","C","D","E","F","G","H","I","K","L","M","N","P","Q","R","S","T","V","W","X","Y")	# input rows must be in this order, OR lack "X"
		letters2 <- c("A","C","D","E","F","G","H","I","K","L","M","N","P","Q","R","S","T","V","W","Y")
	}
	paste(apply(pwm, 2, function(x) { letters[rev(order(x))[1]] }), collapse = "")
}


apa.names$seqLogo2 <- c(apa.names$seqLogo2, "makePWM2")
makePWM2 <- function (pwm, alphabet = "AA") {
	if (is.data.frame(pwm)) { pwm <- as.matrix(pwm) }
	if (!is.matrix(pwm)) { stop("pwm must be a matrix or a dataframe") }
	if (alphabet == "DNA") {
		if (nrow(pwm) < 4 | nrow(pwm) > 5) { 
			stop("PWM for DNA motifs must have 4-5 rows")
		} else if (nrow(pwm) == 5) {
			for (i in 1:ncol(pwm)) { pwm[,i] <- pwm[,i] + pwm[4,i]/4 }	# add N/4 to all other bases at all N positions
			pwm <- pwm[-4,]	# drop N row
			rownames(pwm) <- c("A","C","G","T")
		}
	} else if (alphabet == "RNA") {
		if (nrow(pwm) < 4 | nrow(pwm) > 5) { 
			stop("PWM for RNA motifs must have 4-5 rows")
		} else if (nrow(pwm) == 5) {
			for (i in 1:ncol(pwm)) { pwm[,i] <- pwm[,i] + pwm[4,i]/4 }	# add N/4 to all other bases at all N positions
			pwm <- pwm[-4,]	# drop N row
			rownames(pwm) <- c("A","C","G","U")
		}
	} else if (alphabet == "AA") {
		if (nrow(pwm) < 20 | nrow(pwm) > 21) {
			stop("PWM for AA motifs must have 20-21 rows")
		} else if (nrow(pwm) == 21) {
			for (i in 1:ncol(pwm)) { pwm[,i] <- pwm[,i] + pwm[20,i]/20 } # add X/20 to all other bases at all N positions
			pwm <- pwm[-20,]	# drop X row
			rownames(pwm) <- c("A","C","D","E","F","G","H","I","K","L","M","N","P","Q","R","S","T","V","W","Y")
		}
	} else {
		stop("alphabet must be either DNA, RNA, or AA")
	}
	
	if (any(abs(1 - colSums(pwm)) > 0.01)) {
		print(1-colSums(pwm))
		warning("Columns of PWM must add up to 1.0")
	}
	width <- ncol(pwm)
	colnames(pwm) <- 1:width
	cons <- pwm2cons2(pwm, alphabet)
	ic <- seqLogo:::pwm2ic(pwm)
	new("pwm", pwm = pwm, consensus = cons, ic = ic, width = width, alphabet = alphabet)
}


apa.names$seqLogo2 <- c(apa.names$seqLogo2, "addLetter2")
addLetter2 <- function (alphabet, letters, which, x.pos, y.pos, ht, wt) {
	if (alphabet == "DNA") {
		chars <- c("A","C","G","T")
	} else if (alphabet == "RNA") {
		chars <- c("A","C","G","U")
	} else if (alphabet == "AA") {
		chars <- c("A","C","D","E","F","G","H","I","K","L","M","N","P","Q","R","S","T","V","W","Y")
	} else {
		stop("alphabet must be either DNA, RNA, or AA")
	}
	if (which == "A") {
		letter <- letterA(x.pos, y.pos, ht, wt)
	} else if (which == "C") {
		letter <- letterC(x.pos, y.pos, ht, wt)
	} else if (which == "G") {
		letter <- letterG(x.pos, y.pos, ht, wt)
	} else if (which == "T") {
		letter <- letterT(x.pos, y.pos, ht, wt)
	} else {
		stop("which must be one of A,C,G,T")
	}
	letters$x <- c(letters$x, letter$x)
	letters$y <- c(letters$y, letter$y)
	lastID <- ifelse(is.null(letters$id), 0, max(letters$id))
	letters$id <- c(letters$id, lastID + letter$id)
	letters$fill <- c(letters$fill, letter$fill)
	letters
}


apa.names$seqLogo2 <- c(apa.names$seqLogo2, "seqLogo2")
seqLogo2 <- function (pwm, title=NULL, alphabet = "DNA", ic.scale = TRUE, xaxis = TRUE, yaxis = TRUE, xfontsize = 15, yfontsize = 15) {
	if (class(pwm) == "pwm") {
		pwm <- pwm@pwm
	} else if (class(pwm) == "data.frame") {
		pwm <- as.matrix(pwm)
	} else if (class(pwm) != "matrix") {
		stop("pwm must be of class matrix or data.frame")
	}
	if (alphabet == "DNA") {
		chars <- c("A","C","G","T")
	} else if (alphabet == "RNA") {
		chars <- c("A","C","G","U")
	} else if (alphabet == "AA") {
		chars <- c("A","C","D","E","F","G","H","I","K","L","M","N","P","Q","R","S","T","V","W","Y")
	} else {
		stop("alphabet must be either DNA, RNA, or AA")
	}
	if (any(abs(1 - apply(pwm, 2, sum)) > 0.01)) { stop("Columns of PWM must add up to 1.0") }
	letters <- list(x = NULL, y = NULL, id = NULL, fill = NULL)
	npos <- ncol(pwm)
	if (ic.scale) {
		ylim <- 2
		ylab <- "Information content"
		facs <- seqLogo:::pwm2ic(pwm)
	}
	else {
		ylim <- 1
		ylab <- "Probability"
		facs <- rep(1, npos)
	}
	wt <- 1
	x.pos <- 0
	for (j in 1:npos) {
		column <- pwm[, j]
		hts <- 0.95 * column * facs[j]
		letterOrder <- order(hts)
		y.pos <- 0
		for (i in 1:length(chars)) {
			letter <- chars[letterOrder[i]]
			ht <- hts[letterOrder[i]]
#			if (ht > 0) { letters <- addLetter2(alphabet, letters, letter, x.pos, y.pos, ht, wt) }
			if (ht > 0) { letters <- seqLogo:::addLetter(letters, letter, x.pos, y.pos, ht, wt) }
			y.pos <- y.pos + ht + 0.01
		}
		x.pos <- x.pos + wt
	}
	grid.newpage()
	bottomMargin = ifelse(xaxis, 2 + xfontsize/3.5, 2)
	leftMargin = ifelse(yaxis, 2 + yfontsize/3.5, 2)
	pushViewport(plotViewport(c(bottomMargin, leftMargin, 2, 2)))
	pushViewport(dataViewport(0:ncol(pwm), 0:ylim, name = "vp1"))
	grid.polygon(x = unit(letters$x, "native"), y = unit(letters$y, "native"), 
		id = letters$id, gp = gpar(fill = letters$fill, col = "transparent"))
	if (xaxis) {
		grid.xaxis(at = seq(0.5, ncol(pwm) - 0.5), label = 1:ncol(pwm), gp = gpar(fontsize = xfontsize))
		xlab <- ifelse(is.null(title), "Position", paste(title,"Position"))
		grid.text(xlab, y = unit(-3, "lines"), gp = gpar(fontsize = xfontsize))
	}
	if (yaxis) {
		grid.yaxis(gp = gpar(fontsize = yfontsize))
		grid.text(ylab, x = unit(-3, "lines"), rot = 90, gp = gpar(fontsize = yfontsize))
	}
	popViewport()
	popViewport()
	par(ask = FALSE)
}


