## intended to be loaded by apa_tools.R

apa.names$dev <- c(apa.names$dev, "post.EdgeR.old")
post.EdgeR.old <- function(edgeR.out, FDR=0.05, outpath="EdgeR_out", clobber=FALSE, functional.org=NULL, func.FDR=0.05, term.min.genes=3, GO.ID.conv=NULL, KEGG.ID.conv=NULL, SPIA.ID.conv=NULL, GO.DB=NULL, KEGG.DB=NULL, SPIA.paths=NULL, SPIA.rdata.dir=NULL, debug=FALSE) {
    
    ## extracts/processes significant genes and creates outputs
    ## 'edgeR.out' is an output object from run.EdgeR()
    ## 'GO.ID.conv', if specified, must be a 2-column file with rownames from the original 'counts' matrix sent to EdgeR in col 1, and ;-delim strings of GO DB identifiers in col 2.
    ##  - which GO identifier is needed depends on the organism; look up in GO db.  Typically, Fly=Flybase ID, Yeast=SGD ID, Mouse=MGI ID, Danio=Zfin ID, Human & most others=Uniprot ID.
    ## 'KEGG.ID.conv' works same as 'GO.ID.conv', but col 2 must have KEGG DB identifiers (my KEGG DB builds use Ensembl IDs).
    
    message("")  # provide visual gap in STDOUT stream
    launchpath <- getwd()
    if (file.exists(outpath)) {
        if (!clobber) stop(paste0("Output path '",outpath,"' already exists: will not clobber unless 'clobber=TRUE'!\n"))
    } else {
        ## clobbering DOES NOT delete existing directory; there may be other things in it.
        ## clobbering only overwrites files
        system(paste("mkdir -p",outpath))
    }
    outpath <- normalizePath(outpath)
    
    functional <- FALSE
    if (length(functional.org)>0) {
        ## expecting "Genus species" string, e.g. "Homo sapiens"
        if (grepl("_",functional.org)) message(paste0("WARNING: you probably didn't want those underscores in '",functional.org,"'.  May or may not fail below..."))
        odat <- unlist(strsplit(sub("^ +","",system(paste0("bash -c '/home/apa/local/bin/showTaxa | grep \"",functional.org,"\"'"), intern=TRUE)), " +"))
        taxon <- as.numeric(odat[[1]])  # e.g. 9606
        kegg.org <- paste0(tolower(substr(odat[[2]],1,1)),substr(odat[[3]],1,2))  # e.g. "hsa"
#        no.GO.hosts <- "mango"
        no.GO.hosts <- c()
        no.GO.server <- ifelse(.HOSTNAME %in% no.GO.hosts, TRUE, FALSE)  # servers from which GO DB not accessible (e.g. OS-related Perl DBI issues)
        functional <- TRUE
        do.SPIA <- FALSE  # initially
        
        if (length(GO.DB)==0) {
            if (no.GO.server) {
                message(paste0("GO databases not accessible from this server (",.HOSTNAME,").  Skipping GO analysis."))
                GO.DB <- NA
            } else {
                if (length(taxon)==0) {
                    message(paste("Unable to identify organism '",functional.org,"'!  Skipping GO analysis."))
                } else {
                    GO.DB <- system("bash -c '/home/apa/local/bin/GO_Tools --showdbs | grep . | tail -n +2 | head -1'", intern=TRUE)
                    if (length(GO.DB)>0) {
                        message(paste0("Found latest GO DB '",GO.DB,"'"))
                    } else {
                        message(paste("Unable to find any GO DBs -- check availability of server 'mysql-dev'?  Skipping GO analysis."))
                        GO.DB <- NA
                    }
                }
            }
        }
        do.GO <- ifelse(is.na(GO.DB), FALSE, TRUE)
        
        if (length(KEGG.DB)==0) {
            KEGG.DB <- system(paste0("bash -c 'ls /n/data1/KEGG/",kegg.org,"/*/*_DB.txt | grep -v current | sort | tail -1'"), intern=TRUE)  # sort | tail -1 should get latest, as dirs are 'yyyymm'
            if (length(KEGG.DB)>0) {
                message("Found latest pertinent KEGG DB '",KEGG.DB,"'")
            } else {
                message("Unable to identify KEGG DB for KEGG org code '",KEGG.org,"'!  Skipping KEGG and SPIA analysis.")
                KEGG.DB <- NA
            }
        }
        do.KEGG <- ifelse(is.na(KEGG.DB), FALSE, TRUE)
        
        if (length(SPIA.ID.conv)>0) {
            ## SPIA ID converter given, so run SPIA
            do.SPIA <- TRUE
        } else if (!any(is.na(as.numeric(rownames(edgeR.out$input$counts))))) {
            ## given gene IDs are all numeric, assume Entrez IDs
            do.SPIA <- TRUE
        }
        if (do.SPIA) {
            SPIA.rdata <- system(paste0("bash -c 'ls /n/data1/KEGG/",kegg.org,"/*/*RData | grep -v current | sort | tail -1'"), intern=TRUE)  # sort | tail -1 should get latest, as dirs are 'yyyymm'
            if (length(SPIA.rdata)==0) {
                if (!(functional.org %in% c("Homo sapiens","Mus musculus"))) {
                    message("*** Failed to identify any SPIA RData objects!  Default objects exist only for human & mouse.  No SPIA analysis will be performed\n")
                    sleep(1)
                    do.SPIA <- FALSE
                }
            } else {
                message(paste0("Found latest pertinent SPIA RData '",SPIA.rdata,"'"))
                SPIA.rdata.dir <- sub("/[^/]+$","/",SPIA.rdata)
            }
        }
        
        if (!do.GO & !do.KEGG & !do.SPIA) {
            functional <- FALSE
        } else {
            ## Directory prep for functional analysis outputs
            if (do.GO | do.KEGG) {
                FC.dir <- paste0(outpath,"/FatiClone")
                system(paste("mkdir -p",FC.dir))
                FC.dir <- normalizePath(FC.dir)
                if (do.GO) {
                    GODB.g.dir <- paste0(FC.dir,"/GODB.g")
                    GODB.o.dir <- paste0(FC.dir,"/GODB.o")
                    if (!file.exists(GODB.g.dir)) system(paste("mkdir",GODB.g.dir))
                    if (!file.exists(GODB.o.dir)) system(paste("mkdir",GODB.o.dir))
                    GODB.g.dir <- normalizePath(GODB.g.dir)
                    GODB.o.dir <- normalizePath(GODB.o.dir)
                }
                if (do.KEGG) {
                    KEGG.g.dir <- paste0(FC.dir,"/KEGG.g")
                    KEGG.o.dir <- paste0(FC.dir,"/KEGG.o")
                    if (!file.exists(KEGG.g.dir)) system(paste("mkdir",KEGG.g.dir))
                    if (!file.exists(KEGG.o.dir)) system(paste("mkdir",KEGG.o.dir))
                    KEGG.g.dir <- normalizePath(KEGG.g.dir)
                    KEGG.o.dir <- normalizePath(KEGG.o.dir)
                }
            }
            if (do.SPIA) {
                SPIA.dir <- paste0(outpath,"/SPIA")
                SPIA.data.dir <- paste0(SPIA.dir,"/data")
                if (!file.exists(SPIA.data.dir)) system(paste("mkdir -p",SPIA.data.dir))  # also makes SPIA.dir in the process
                SPIA.dir <- normalizePath(SPIA.dir)
                SPIA.data.dir <- normalizePath(SPIA.data.dir)
                if (length(SPIA.rdata.dir)>0) SPIA.rdata.dir <- paste0(normalizePath(SPIA.rdata.dir),"/")  # SPIA requires trailing backslash
            }
        }
    }
    
    C <- length(edgeR.out$input$contrasts)
    Cnames <- names(edgeR.out$input$contrasts)
    Cprefix <- paste0(outpath,"/",Cnames)
    cnull <- sig.tab <- new.list(Cnames)
    vnull <- new.list(c("up","down","all"))  # shell for venn diagram areas (up-DE, down-DE, all-DE versions)
    fnull <- new.list(Cnames, elem=new.list(c("GO","KEGG","SPIA")))  # shell for functional data
    if (length(FDR)==1) FDR <- rep(FDR,C)
    
    output <- list(
        input=list(       # inputs to post.EdgeR()
            edgeR.out=deparse(substitute(edgeR.out)),
            FDR=FDR,
            outpath=outpath,
            clobber=clobber,
            functional.org=functional.org,
            func.FDR=func.FDR,
            term.min.genes=term.min.genes,
            GO.ID.conv=GO.ID.conv,
            KEGG.ID.conv=KEGG.ID.conv,
            GO.DB=GO.DB,
            KEGG.DB=KEGG.DB
        ),
        xls=c(),          # master XLS dataset with everything except contrast-wise EdgeR data
        sig=cnull,        # 'top' subsets for significant genes
        hmx=cnull,        # DE genes log2(RPKM+1) heatmap
        hmz=cnull,        # DE genes zscore heatmap
        hcx=cnull,        # row and column clustering for 'hmx' (orderings only, no hclust() objects)
        hcz=cnull,        # row and column clustering for 'hmz' (orderings only, no hclust() objects)
        to.GO=cnull,      # lists of DE genes for functional analysis
        venn=vnull,       # venn.areas objects for DE genes
        functional=fnull  # functional enrichment datasets
    )
    
    rn.master <- rownames(edgeR.out$input$counts)  ## ALL DATASETS SHOULD HAVE THIS ROW ORDER
    all.top <- lapply(1:C, function(i) {
        x <- edgeR.out$top[[i]]
        x$DE[x$FDR>FDR[i]] <- 0
        colnames(x) <- paste0(Cnames[i],".",colnames(x))
        x
    })  # single dataframe with all 'top' columns from all contrasts; 'DE' columns corrected according to FDR cutoff
    de.mat <- do.call(cbind, lapply(all.top, "[", , 4))  # "DE column, whatever its actual name
    n.de.up <- sum(apply(de.mat==1,1,any))
    n.de.down <- sum(apply(de.mat==-1,1,any)) # this approach allows a single gene to count towards up AND down, if it is so in different contrasts
    
    if (any(grepl("GeneID",colnames(edgeR.out$input$annot)))) {
        ## assuming /n/data1/genomes/indexes-style genedata.txt was provided
        ID.cols <- edgeR.out$input$annot[,1:2]
        annot.cols <- edgeR.out$input$annot[,3:ncol(edgeR.out$input$annot)]
        freezecol <- 2
    } else {
        ## patch in 'GeneID' column as rownames from 'top' -- need this column below
        ID.cols <- matrix(rn.master, ncol=1, dimnames=list(c(),"GeneID"))
        annot.cols <- edgeR.out$input$annot
        freezecol <- 1
    }
    xls.all <- list(
        all.genes.1=ID.cols,
        all.genes.2=data.frame(edgeR.out$expr$rpkms.avg, edgeR.out$expr$rpkms.sd, edgeR.out$expr$counts.avg, edgeR.out$expr$counts.sd, annot.cols, stringsAsFactors=FALSE, check.names=FALSE),
        sample.rpkms=data.frame(ID.cols, edgeR.out$expr$rpkms.all, stringsAsFactors=FALSE, check.names=FALSE),
        sample.counts=data.frame(ID.cols, edgeR.out$expr$counts.all, stringsAsFactors=FALSE, check.names=FALSE)
    )
    
    message("\nProcessing contrasts...")
    for (i in 1:C) {
        
        this.top <- edgeR.out$top[[i]]  # has same row order as xls.all
        this.top$DE[this.top$FDR>FDR[i]] <- 0
        output$sig[[i]] <- this.top[this.top$DE!=0,]
        nsig <- nrow(output$sig[[i]])
        w.up <- which(this.top$DE==1)
        w.dn <- which(this.top$DE==-1)
        n.up <- length(w.up)
        n.dn <- length(w.dn)
        
        x <- table(this.top$DE)
        sig.tab[[i]] <- x[match(-1:1,names(x))]  # N up, non, down
        svg.use.cols <- real(mgrep(c("Gene.?ID","(Gene.?)?Symbol","(Gene.?)?Name","(Gene.?)?SimpleBiotype","(Gene.?)?Description"),colnames(edgeR.out$input$annot)))
        if (length(svg.use.cols)<3) svg.use.cols <- 1:ifelse(ncol(edgeR.out$input$annot)>5,5,ncol(edgeR.out$input$annot))  ## Some other kind of dataset, apparently.  Just take up to first 5 cols where possible.
        svg.ann <- edgeR.out$input$annot[,svg.use.cols]  # for SVG plot
        message(paste0(" ",Cnames[i]," FDR:",FDR[i]," UP:",sum(this.top$DE==1)," DOWN:",sum(this.top$DE==-1)))
        
        ## MA plots, static
        png(paste0(Cprefix[i],".MA.png"), 600, 600)
        par(cex=1.2, las=1)
        ma <- this.top[,c("A","M")]
        plot(ma, col=0, xlab="Log2 Mean Expr", ylab="Log2 Fold Change", main=paste(Cnames[i],"MA Plot"))
        abline(h=0, col=1)
        points(ma[this.top$DE==0,,drop=FALSE], col=8)
        for (p in 1:2) {  # overplotting makes points "bold"
            points(ma[w.up,,drop=FALSE], col=2)
            points(ma[w.dn,,drop=FALSE], col=3)
        }
        legend("topright", col=2:3, pch=1, legend=c(paste(length(w.up),"Up"),paste(length(w.dn),"Down")))
        dev.off()
        
        ## Volcano plots, static
        png(paste0(Cprefix[i],".volcano.png"), 600, 600)
        par(cex=1.2, las=1)
        vp <- cbind(this.top$M, -log10(this.top$FDR))
        plot(vp, col=0, xlab="Log2 Fold Change", ylab="-Log10(FDR)", main=paste(Cnames[i],"Volcano Plot"))
        points(vp[this.top$DE==0,,drop=FALSE], col=8)
        for (p in 1:2) {  # overplotting makes points "bold"
            points(vp[w.up,,drop=FALSE], col=2)
            points(vp[w.dn,,drop=FALSE], col=3)
        }
        abline(v=0, col=1)
        legend("topright", col=2:3, pch=1, legend=c(paste(length(w.up),"Up"),paste(length(w.dn),"Down")))
        dev.off()
        
        ## MA & Volcano plots, interactive
        df <- data.frame(ma,this.top$FDR,svg.ann)
        #message("ANN DF: ",nrow(df))
        SVG.scatterplot(df, style="MA", paste0(Cprefix[i],".MA.svg"), cex=1.2, main=paste(Cnames[i],"MA Plot"))
        SVG.scatterplot(df, style="volcano", paste0(Cprefix[i],".volcano.svg"), cex=1.2, main=paste(Cnames[i],"Volcano Plot"))
        
        if (nsig>0) {
            
            output$to.GO[[i]] <- cbind(GENE=rownames(output$sig[[i]]),GROUP=paste0(sub("1","",sign(output$sig[[i]]$DE)),Cnames[i]))
            colnames(output$to.GO[[i]]) <- qw("GENE","GROUP")
            output$to.GO[[i]] <- list( GODB=output$to.GO[[i]], KEGG=output$to.GO[[i]] )
            if (length(GO.ID.conv)>0) output$to.GO[[i]]$GODB[,1] <- GO.ID.conv[match(output$to.GO[[i]]$GODB[,1],GO.ID.conv[,1]),2]
            if (length(KEGG.ID.conv)>0) output$to.GO[[i]]$KEGG[,1] <- KEGG.ID.conv[match(output$to.GO[[i]]$KEGG[,1],KEGG.ID.conv[,1]),2]
            
            output$hmx[[i]] <- as.matrix(log2(edgeR.out$expr$rpkms.all[c(w.up,w.dn),,drop=FALSE]+1))
            colnames(output$hmx[[i]]) <- sub(".Rpkm","",colnames(output$hmx[[i]]))
            output$hmz[[i]] <- t(scale(t(output$hmx[[i]])))  # gene z-scores
            ncols <- ncol(output$hmx[[i]])
            hmx.avg <- as.matrix(log2(edgeR.out$expr$rpkms.avg[c(w.up,w.dn),,drop=FALSE]+1))
            hmz.avg <- t(scale(t(hmx.avg)))
            
            output$hcx[[i]] <- output$hcz[[i]] <- new.list(c("row","col.all","col.grp"))
            if (n.up>0) {
                up.rows <- 1:n.up  # 'up' rows (arranged first in output$hmx[[i]])
            } else {
                up.rows <- c()
            }
            if (n.dn>1) {
                dn.rows <- (n.up+1):nrow(output$hmx[[i]])  # 'down' rows (arranged second in output$hmx[[i]])
            } else if (n.dn>0) {
                dn.rows <- n.up+1  # 'down' rows (arranged second in output$hmx[[i]])
            } else {
                dn.rows <- c()
            }
            #IM("UP:",up.rows)
            #IM("DN:",dn.rows)
            
            ## Set heatmap row orders
            if (n.up>2) {
                up.ordx <- up.rows[reorder.hclust2(hclust(dist    (output$hmx[[i]][up.rows,,drop=FALSE]),"average"), output$hmx[[i]], mean)$order]   # cluster up separately
                up.ordz <- up.rows[reorder.hclust2(hclust(distance(output$hmz[[i]][up.rows,,drop=FALSE]),"average"), output$hmz[[i]], mean)$order]
            } else if (length(up.rows)>1) {
                up.ordx <- up.ordz <- up.rows[rev(order(rowMeans(output$hmx[[i]][up.rows,,drop=FALSE])))]
            } else if (length(up.rows)>0) {
                up.ordx <- up.ordz <- up.rows
            } else {
                up.ordx <- up.ordz <- c()
            }
            if (n.dn>2) {
                dn.ordx <- dn.rows[reorder.hclust2(hclust(dist    (output$hmx[[i]][dn.rows,,drop=FALSE]),"average"), output$hmx[[i]], mean)$order]  # cluster down separately
                dn.ordz <- dn.rows[reorder.hclust2(hclust(distance(output$hmz[[i]][dn.rows,,drop=FALSE]),"average"), output$hmz[[i]], mean)$order]
            } else if (length(dn.rows)>1) {
                dn.ordx <- dn.ordz <- dn.rows[rev(order(rowMeans(output$hmx[[i]][dn.rows,,drop=FALSE])))]
            } else if (length(dn.rows)>0) {
                dn.ordx <- dn.ordz <- dn.rows
            } else {
                dn.ordx <- dn.ordz <-c()
            }
            output$hcx[[i]]$row <- c(up.ordx,dn.ordx)
            output$hcz[[i]]$row <- c(up.ordz,dn.ordz)
            
            ## Set heatmap column orders
            if (ncols>2) {
                output$hcx[[i]]$col.all <- reorder.hclust2(hclust(dist(t(output$hmx[[i]])),"average"), t(output$hmx[[i]]), mean)$order
                output$hcz[[i]]$col.all <- hclust(distance(t(output$hmz[[i]])),"average")$order
            } else {  # guaranteed at least 2 cols, else no DE!!  (actually, 2+ reps required, so really min 4 cols...)
                output$hcx[[i]]$col.all <- rev(order(colMeans(output$hmx[[i]])))
                output$hcz[[i]]$col.all <- output$hcx[[i]]$col.all
            }
            
            ## Correct group-vector -> hmx.avg col-number correspondence, if necessary
            grp.n <- as.numeric(edgeR.out$input$group)
            if (min(grp.n)>1) grp.n <- grp.n-min(grp.n)+1
            
            ## Initialize grouped col order by clustering within groups
            output$hcx[[i]]$col.grp <- lapply( split(1:ncol(output$hmx[[i]]), grp.n), function(x) {
                if (length(x)>2) {
                    x[ reorder.hclust2(hclust(dist(t(output$hmx[[i]][,x,drop=FALSE])),"average"), t(output$hmx[[i]][,x,drop=FALSE]), mean)$order ]
                } else if (length(x)>1) {
                    x[ rev(order(colMeans(output$hmx[[i]][,x,drop=FALSE]))) ]
                } else {
                    x
                }
            })
            output$hcz[[i]]$col.grp <- lapply( split(1:ncol(output$hmz[[i]]), grp.n), function(x) {
                if (length(x)>2) {
                    x[ hclust(distance(t(output$hmz[[i]][,x,drop=FALSE])),"average")$order ]
                } else if (length(x)>1) {
                    x[ rev(order(colMeans(output$hmx[[i]][,x,drop=FALSE]))) ]
                } else {
                    x
                }
            })
            ## Cluster between groups and unpack orderings
            ## ONLY WORKS IF HMX.AVG COLUMNS IN SAME ORDER AS 'GROUP'!!!
            if (ncol(hmx.avg)>2) {
                output$hcx[[i]]$col.grp <- unlist(output$hcx[[i]]$col.grp[ reorder.hclust2(hclust(dist(t(hmx.avg)),"average"), t(hmx.avg), mean)$order ])
                output$hcz[[i]]$col.grp <- unlist(output$hcz[[i]]$col.grp[ hclust(distance(t(hmz.avg)),"average")$order ])   ## ONLY WORKS IF HMZ.AVG COLUMNS IN 'GROUP' ORDER!!!
            } else {
                output$hcx[[i]]$col.grp <- unlist(output$hcx[[i]]$col.grp[rev(order(colMeans(hmx.avg)))])
                output$hcz[[i]]$col.grp <- unlist(output$hcz[[i]]$col.grp[rev(order(colMeans(hmx.avg)))])   ## ONLY WORKS IF HMZ.AVG COLUMNS IN 'GROUP' ORDER!!!
            }
            
            ## Plot heatmaps
            imgwd <- 400+30*ncol(output$hmx[[i]])
            imght <- max(c(500,250+nrow(output$hmx[[i]])))

            png(paste0(Cprefix[i],".hmx.ordered.png"), imgwd, imght)
            mipu(output$hmx[[i]][output$hcx[[i]]$row,,drop=FALSE], pal="Reds", cex=1.2, pmar=c(10,1), main=paste0(Cnames[i],", ",nsig," DE Gene Log2(RPKMs+1)"))
            dev.off()
            
            png(paste0(Cprefix[i],".hmx.clust.all.png"), imgwd, imght)
            mipu(output$hmx[[i]][output$hcx[[i]]$row,output$hcx[[i]]$col.all,drop=FALSE], pal="Reds", cex=1.2, pmar=c(10,1), main=paste0(Cnames[i],", ",nsig," DE Gene Log2(RPKMs+1)"))
            dev.off()
            
            png(paste0(Cprefix[i],".hmx.clust.grp.png"), imgwd, imght)
            mipu(output$hmx[[i]][output$hcx[[i]]$row,output$hcx[[i]]$col.grp,drop=FALSE], pal="Reds", cex=1.2, pmar=c(10,1), main=paste0(Cnames[i],", ",nsig," DE Gene Log2(RPKMs+1)"))
            dev.off()
            
            png(paste0(Cprefix[i],".hmz.ordered.png"), imgwd, imght)
            mipu(output$hmz[[i]][output$hcz[[i]]$row,,drop=FALSE], pal="RWB", col.center=0, col.limits=c(-4,4), cex=1.2, pmar=c(10,1), main=paste0(Cnames[i],", ",nsig," DE Gene Z-Scores"))
            dev.off()
            
            png(paste0(Cprefix[i],".hmz.clust.all.png"), imgwd, imght)
            mipu(output$hmz[[i]][output$hcz[[i]]$row,output$hcz[[i]]$col.all,drop=FALSE], pal="RWB", col.center=0, col.limits=c(-4,4), cex=1.2, pmar=c(10,1), main=paste0(Cnames[i],", ",nsig," DE Gene Z-Scores"))
            dev.off()
            
            png(paste0(Cprefix[i],".hmz.clust.grp.png"), imgwd, imght)
            mipu(output$hmz[[i]][output$hcz[[i]]$row,output$hcz[[i]]$col.grp,drop=FALSE], pal="RWB", col.center=0, col.limits=c(-4,4), cex=1.2, pmar=c(10,1), main=paste0(Cnames[i],", ",nsig," DE Gene Z-Scores"))
            dev.off()
        }
    }
    
    all.sig.genes <- sort(unique(unlist(lapply(output$sig,rownames))))
    sig.gene.rows <- match(all.sig.genes,rn.master)
    message(paste(" TOTAL SIG GENES:",length(sig.gene.rows)))
    
    ## N DE Genes Barplots ##
    
    nde.bars.1 <- merge.table.list(sig.tab)[,c(3,1,2),drop=FALSE]
    write.table2(nde.bars.1, paste0(outpath,"/N_DE.txt"), row.head="Contrast", col.names=qw(Up,Down,Non))
    nde.bars <- t(nde.bars.1[,1:2,drop=FALSE])  # up, down only
    nde.bars[2,] <- -1*nde.bars[2,]  # 'down' becomes negative
    ylim <- range(c(nde.bars))
    
    png(paste0(outpath,"/N_DE.bars.png"), 400+50*C, 600)
    par(cex=1.2, las=1)
    b <- barplot(nde.bars[1,], col="tomato", bord="tomato", ylim=ylim, names=colnames(nde.bars), main="DE Genes Per Contrast")
    barplot(nde.bars[2,], col="dodgerblue", bord="dodgerblue", add=TRUE)
    abline(h=0)
    text(b, 0, nde.bars[1,], pos=3)
    text(b, 0, -nde.bars[2,], pos=1)
    dev.off()
    
    ## Venn Diagrams ##
    
    if (C>1 & C<=5) {  # can have venn diags with 2-5 sets
        png(paste0(outpath,"/venn.up.png"), 1200, 600)
        par(mfrow=c(1,2), cex=1.2)
        output$venn$up <- venn.diag(lapply(output$sig, function(x) rownames(x)[x$DE==1] ), colorize=TRUE, main="Up DE Genes")
        venn.diag(lapply(output$sig, function(x) rownames(x)[x$DE==1] ), as.pct=TRUE, colorize=TRUE, main="As Pct Total")
        dev.off()
        
        png(paste0(outpath,"/venn.down.png"), 1200, 600)
        par(mfrow=c(1,2), cex=1.2)
        output$venn$down <- venn.diag(lapply(output$sig, function(x) rownames(x)[x$DE==-1] ), colorize=TRUE, main="Down DE Genes")
        venn.diag(lapply(output$sig, function(x) rownames(x)[x$DE==-1] ), as.pct=TRUE, colorize=TRUE, main="As Pct Total")
        dev.off()
        
        png(paste0(outpath,"/venn.all.png"), 1200, 600)
        par(mfrow=c(1,2), cex=1.2)
        output$venn$all <- venn.diag(lapply(output$sig, rownames), colorize=TRUE, main="All DE Genes")
        venn.diag(lapply(output$sig, rownames), as.pct=TRUE, colorize=TRUE, main="As Pct Total")
        dev.off()
    }
    
    to.GO.KEGG <- do.call(rbind, lapply(output$to.GO, "[[", "KEGG"))
    to.GO.GODB <- do.call(rbind, lapply(output$to.GO, "[[", "GODB"))
    write.table2(to.GO.KEGG, paste0(outpath,"/to.GO.KEGG.txt"))
    write.table2(to.GO.GODB, paste0(outpath,"/to.GO.GODB.txt"))
    
    if (functional) {
        
        read.fc.files <- function(path,opp=FALSE) {
            terms <- paste0(path,"/FatiClone_Fishers_",ifelse(opp,"ALL","OVER"),"_significant_terms.txt")
            genes <- paste0(path,"/FatiClone_Fishers_",ifelse(opp,"ALL","OVER"),"_significant_genelist.txt")
            terms <- suppressWarnings(try(read.delim(terms, as.is=TRUE), silent=TRUE))  # will not exist if no sig terms found
            genes <- suppressWarnings(try(read.delim(genes, as.is=TRUE), silent=TRUE))  # same
            if (is(terms,"try-error")) terms <- data.frame( Map="", Enriched_In="", DB="", Level=0, Term_Acc="", Term_Name="", Clust_Term_Pct=0, Bkg_Term_Pct=0, Pct_LFC=0, DB_Term_Pct=0, Enrichment="", Raw_P=0, Adj_P=0, Odds=0, `0.95_CI_Lo`=0, `0.95_CI_Up`=0, Clust_With=0, Clust_Without=0, Bkg_With=0, Bkg_Without=0, DB_With=0, Input_Symbols="", Input_Names="", Input_Xrefs="", Mapped_Symbols="", Mapped_Names="", Mapped_Xrefs="", Input_Rows="" )[0,]  # same format as FatiClone terms output
            if (is(genes,"try-error")) genes <- data.frame( Map="", Enriched_In="", DB="", Level=0, Sig_Term_Acc="", Sig_Term_Name="", Row=0, Input_Xref="", `Original_ID(s)`="", Other_Terms="" )[0,]  # same format as FatiClone genes output
            list(terms=terms,genes=genes)
        }
        
        ## GO ANALYSIS ##
        
        if (do.GO) {
            
            GO.g.cmd <- paste0("/home/apa/local/bin/FatiClone -f ",outpath,"/to.GO.GODB.txt -d ",GO.DB[1]," -x ",taxon," -a ",func.FDR," -t 1 -b genome -w ",GODB.g.dir," --no_sig_parents --nounder")
            GO.o.cmd <- paste0("/home/apa/local/bin/FatiClone -f ",outpath,"/to.GO.GODB.txt -d ",GO.DB[1]," -x ",taxon," -a ",func.FDR," -t 1 -b opposite -w ",GODB.o.dir," --no_sig_parents")
            message(paste("\nTesting whole-genome GO enrichments...\nRunning:",GO.g.cmd))
            if (!debug) system(GO.g.cmd)
            message(paste("\nTesting head-to-head GO enrichments...\nRunning:",GO.o.cmd))
            if (!debug) system(GO.o.cmd)
            
            fc.go <- list( genome=read.fc.files(GODB.g.dir,FALSE), opposite=read.fc.files(GODB.o.dir,TRUE) )
            message(paste(sum(sapply(fc.go, function(x) nrow(x$terms) )),"GO result rows"))
            
            ## GO DB gene IDs may not be same as analysis gene IDs; add analysis IDs column to sig-term-genes dataset
            for (i in 1:length(fc.go)) {
                fc.go[[i]]$genes <- fc.go[[i]]$genes[,c(1:8,8:9)]
                colnames(fc.go[[i]]$genes)[8:9] <- c("GO.DB.IDs","Analysis.IDs")
                if (length(GO.ID.conv)>0) {
                    fc.go[[i]]$genes[,9] <- sapply(fc.go[[i]]$genes[,8], function(x) paste(sort(unique(GO.ID.conv[GO.ID.conv[,2]==x,1])), collapse="; ") )
                } else {
                    fc.go[[i]]$genes[,9] <- fc.go[[i]]$genes[,8]
                }
            }
            
            for (i in 1:C) {
                ## Add functional results to output object
                output$functional[[i]]$GO <- fc.go
                cl.names <- c(Cnames[i],paste0("-",Cnames[i]))  # e.g. c("test","-test")
                for (j in 1:length(fc.go)) {
                    x <- fc.go[[j]]$terms[fc.go[[j]]$terms$Cluster %in% cl.names,-1]  # TERMS: DROP MAP COLUMN
                    colnames(x) <- c("Enriched_In","DB","Level","Term_Acc","Term_Name","Clust_Term_Pct","Bkg_Term_Pct","Pct_LFC","DB_Term_Pct","Enrichment","Raw_P","Adj_P","Odds","0.95_CI_Lo","0.95_CI_Up","Clust_With","Clust_Without","Bkg_With","Bkg_Without","DB_With","Input_Symbols","Input_Names","Input_Xrefs","Mapped_Symbols","Mapped_Names","Mapped_Xrefs","Input_Rows")
                    y <- unique(fc.go[[j]]$genes[fc.go[[j]]$genes$Cluster %in% cl.names,-c(1:2)])  # GENES: DROP MAP, CLUSTER COLUMNS
                    colnames(y) <- c("DB","Level","Sig_Term_Acc","Sig_Term_Name","Row","Input_Xref","Original_ID(s)","Other_Terms")
                    if (nrow(x)>0) {
                        if (nrow(y)==0) warning("GO error: have term rows but no gene rows!\n")
                        x <- x[rev(order(x$Clust_Term_Pct)),]  # first sort by prevalence
                        x <- x[c(which(x$DB=="BP"),which(x$DB=="CC"),which(x$DB=="MF")),]  # order by BP, CC, MF, (in that order)
                        x$Pct_LFC <- log2(((x$Clust_With+0.5)/(x$Clust_With+x$Clust_Without+0.5))/((x$Bkg_With+0.5)/(x$Bkg_With+x$Bkg_Without+0.5)))  # recalculate to eliminate INFs etc, and actually put in Log2.
                        for (n in c("Clust_Term_Pct","Bkg_Term_Pct","DB_Term_Pct")) x[[n]] <- x[[n]]/100
                        x$DB <- paste0("GO-",x$DB)  # e.g. "BP" -> "GO-BP"
                        if (nrow(y)>0) y$DB <- paste0("GO-",y$DB)  # e.g. "BP" -> "GO-BP"
                        if (names(fc.go)[j]=="genome") {
                            u <- x[x$Enriched_In==cl.names[1],]   # "up" set
                            d <- x[x$Enriched_In==cl.names[2],]   # "down" set
                        } else if (names(fc.go)[j]=="opposite") {
                            u <- x[x$Enrichment=="OVER",]   # "up" set
                            d <- x[x$Enrichment=="UNDER",]  # "down" set
                        } else {
                            message(paste0("\n\n\n**********  WARNING: Background model '",names(fc.go)[j],"' is not supported!  Data is probably being handled incorrectly.  **********\n\n\n"))
                            Sys.sleep(10)
                        }
                        message(paste(Cnames[i],names(fc.go)[j],"GO :",nrow(u),"up",nrow(d),"down"))
                        if (nrow(u)>0) u$Enriched_In <- paste(cl.names[1],"Up")
                        if (nrow(d)>0) d$Enriched_In <- paste(cl.names[1],"Down")
                        x <- rbind(u,d)
                        x <- x[x$Clust_With>=term.min.genes , !(colnames(x) %in% c("Odds","0.95_CI_Lo","0.95_CI_Up","Enrichment","Input_Symbols","Input_Names","Mapped_Xrefs","Input_Rows"))]
                        if (nrow(x)>0) {
                            keep.genes <- sort(unique(unlist(strsplit(x$Input_Xrefs, "; "))))
                            y <- y[y$Input_Xref %in% keep.genes,]
                            y <- y[order(y$Input_Xref),]
                        } else {
                            y <- y[0,]
                        }
                    }
                    output$functional[[i]]$GO[[j]]$terms <- x
                    output$functional[[i]]$GO[[j]]$genes <- y
                }
            }
        }
        
        ## KEGG ANALYSIS ##
        
        if (do.KEGG) {
            
            KEGG.g.cmd <- paste0("/home/apa/local/bin/FatiClone -f ",outpath,"/to.GO.KEGG.txt -o ",KEGG.DB[1]," -a ",func.FDR," -t 1 -b genome -w ",KEGG.g.dir," --no_sig_parents --nounder")
            KEGG.o.cmd <- paste0("/home/apa/local/bin/FatiClone -f ",outpath,"/to.GO.KEGG.txt -o ",KEGG.DB[1]," -a ",func.FDR," -t 1 -b opposite -w ",KEGG.o.dir," --no_sig_parents")
            message(paste("\nTesting whole-genome KEGG enrichments...\nRunning:",KEGG.g.cmd))
            if (!debug) system(KEGG.g.cmd)
            message(paste("\nTesting head-to-head KEGG enrichments...\nRunning:",KEGG.o.cmd))
            if (!debug) system(KEGG.o.cmd)
            
            fc.kegg <- list( genome=read.fc.files(KEGG.g.dir,FALSE), opposite=read.fc.files(KEGG.o.dir,TRUE) )
            message(paste(sum(sapply(fc.kegg, function(x) nrow(x$terms) )),"KEGG result rows"))
            
            ## KEGG DB gene IDs may not be same as analysis gene IDs; add analysis IDs column to sig-term-genes dataset
            for (i in 1:length(fc.kegg)) {
                fc.kegg[[i]]$genes <- fc.kegg[[i]]$genes[,c(1:8,8:9)]
                colnames(fc.kegg[[i]]$genes)[8:9] <- c("KEGG.DB.IDs","Analysis.IDs")
                if (nrow(fc.kegg[[i]]$genes)>0) {
                    if (length(KEGG.ID.conv)>0) {
                        fc.kegg[[i]]$genes[,9] <- sapply(fc.kegg[[i]]$genes[,8], function(x) paste(sort(unique(KEGG.ID.conv[KEGG.ID.conv[,2]==x,1])), collapse="; ") )
                        kegg.key <- unique(breakout(lapply(split(KEGG.ID.conv[,1],KEGG.ID.conv[,2]), function(x) sort(unique(edgeR.out$input$annot[match(x,edgeR.out$input$annot[,1]),2])) ), reverse=TRUE))
                    } else {
                        fc.kegg[[i]]$genes[,9] <- fc.kegg[[i]]$genes[,8]
                        kegg.key <- edgeR.out$input$annot[,1:2]
                    }
                }
            }
            
            for (i in 1:length(fc.kegg)) {
                ## Because KEGG currently uses Ensembl IDs -- and has no symbol mappings, unlike the GO DBs -- we have to add symbols manually
                if (nrow(fc.kegg[[i]]$terms)>0) {
                    fc.kegg[[i]]$terms$Mapped_Symbols <- FatiClone.KEGG.convert(kegg.key, from=fc.kegg[[i]]$terms$Input_Xrefs)
                }
            }
            
            for (i in 1:C) {
                ## Add functional results to output object
                output$functional[[i]]$KEGG <- fc.kegg
                cl.names <- c(Cnames[i],paste0("-",Cnames[i]))  # e.g. c("test","-test")
                for (j in 1:length(fc.kegg)) {
                    x <- fc.kegg[[j]]$terms[fc.kegg[[j]]$terms$Cluster %in% cl.names,-1]  # TERMS: DROP MAP COLUMN
                    colnames(x) <- c("Enriched_In","DB","Level","Term_Acc","Term_Name","Clust_Term_Pct","Bkg_Term_Pct","Pct_LFC","DB_Term_Pct","Enrichment","Raw_P","Adj_P","Odds","0.95_CI_Lo","0.95_CI_Up","Clust_With","Clust_Without","Bkg_With","Bkg_Without","DB_With","Input_Symbols","Input_Names","Input_Xrefs","Mapped_Symbols","Mapped_Names","Mapped_Xrefs","Input_Rows")
                    y <- unique(fc.kegg[[j]]$genes[fc.kegg[[j]]$genes$Cluster %in% cl.names,-c(1:2)])  # GENES: DROP MAP, CLUSTER COLUMNS
                    colnames(y) <- c("DB","Level","Sig_Term_Acc","Sig_Term_Name","Row","Input_Xref","Original_ID(s)","Other_Terms")
                    if (nrow(x)>0) {
                        if (nrow(y)==0) stop("KEGG error: have term rows but no gene rows!\n")
                        x <- x[rev(order(x$Clust_Term_Pct)),]  # first sort by prevalence
                        x$Pct_LFC <- log2(((x$Clust_With+0.5)/(x$Clust_With+x$Clust_Without+0.5))/((x$Bkg_With+0.5)/(x$Bkg_With+x$Bkg_Without+0.5)))  # recalculate to eliminate INFs etc, and actually put in Log2.
                        for (n in c("Clust_Term_Pct","Bkg_Term_Pct","DB_Term_Pct")) x[[n]] <- x[[n]]/100
                        if (names(fc.kegg)[j]=="genome") {
                            u <- x[x$Enriched_In==cl.names[1],]   # "up" set
                            d <- x[x$Enriched_In==cl.names[2],]   # "down" set
                        } else if (names(fc.kegg)[j]=="opposite") {
                            u <- x[x$Enrichment=="OVER",]   # "up" set
                            d <- x[x$Enrichment=="UNDER",]  # "down" set
                        } else {
                            message(paste0("\n\n\n**********  WARNING: Background model '",names(fc.kegg)[j],"' is not supported!  Data is probably being handled incorrectly.  **********\n\n\n"))
                            Sys.sleep(10)
                        }
                        message(paste(Cnames[i],names(fc.kegg)[j],"KEGG :",nrow(u),"up",nrow(d),"down"))
                        if (nrow(u)>0) u$Enriched_In <- paste(cl.names[1],"Up")
                        if (nrow(d)>0) d$Enriched_In <- paste(cl.names[1],"Down")
                        x <- rbind(u,d)
                        x <- x[x$Clust_With>=term.min.genes , !(colnames(x) %in% c("Odds","0.95_CI_Lo","0.95_CI_Up","Enrichment","Input_Symbols","Input_Names","Mapped_Xrefs","Input_Rows"))]
                        if (nrow(x)>0) {
                            keep.genes <- sort(unique(unlist(strsplit(x$Input_Xrefs, "; "))))
                            y <- y[y$Input_Xref %in% keep.genes,]
                            y <- y[order(y$Input_Xref),]
                        } else {
                            y <- y[0,]
                        }
                    }
                    output$functional[[i]]$KEGG[[j]]$terms <- x
                    output$functional[[i]]$KEGG[[j]]$genes <- y
                }
            }
        }
        
        ## SPIA ANALYSIS ##
        
        if (do.SPIA) {
            
            library(SPIA)
            library(pathview)
            setwd(SPIA.dir)  # switch to output dir; 'spia' function writes images to current dir
            
            if (length(SPIA.ID.conv)>0) {
                ## must convert from analysis IDs to Entrez IDs
                all <- rownames(remap.matrix(edgeR.out$input$counts[,1,drop=FALSE], e2t, mean))
            } else {
                ## if do.SPIA, then analysis IDs assumed to be Entrez IDs
                all <- rownames(edgeR.out$input$counts)
            }
            
            for (i in 1:C) {
                message(paste("SPIA:",Cnames[i]))
                if (length(SPIA.ID.conv)>0) {
                    de <- remap.matrix(output$sig[[i]][,1,drop=FALSE], e2t, mean)
                } else {
                    de <- output$sig[[i]][,1,drop=FALSE]
                }
                if (length(SPIA.paths)>0) SPIA.paths <- sub("^[a-z]+","",SPIA.paths)
                if (!debug) spia.df <- spia(de=named.vector(c(de),rownames(de)), all=all, organism=kegg.org, data.dir=SPIA.rdata.dir, pathids=SPIA.paths, plots=TRUE)  #,nB=2000,verbose=TRUE,beta=NULL,combine="fisher")
                message("")   # make up for poorly-programmed spia()'s habit of putting newlines at the start of messages and NOT the end...
                if (debug) {
##                    spia.out.master <<- spia.df  ############ uncomment one time for pre-debugging run only !!!!!!!!!
                    spia.df <- spia.out.master
                }
                if (!debug) system(paste0("mv -f SPIAPerturbationPlots.pdf SPIAPerturbationPlots.",Cnames[i],".pdf")) 
                for (j in c(5,7:10)) if (any(is.na(spia.df[,j]))) spia.df[which(is.na(spia.df[,j])),j] <- 1  # correct any NA p-values
                
                plotP.thresh <- ifelse(any(spia.df$pGFdr<=func.FDR), func.FDR, 1)
                png(paste0(Cnames[i],".2way_evidence.png"), 600, 600); plotP(spia.df, thresh=plotP.thresh); dev.off() 
                spia.df$ID <- paste0(kegg.org,spia.df$ID)
                output$functional[[i]]$SPIA <- spia.df <- cbind(spia.df, Significant=spia.df$pGFdr<=func.FDR)[,c(1:10,13,11:12)]  # REPLACE SPIA.DF TOO
                write.table(spia.df, paste0(Cnames[i],".spia_results.txt"), sep="\t", quote=FALSE, row.names=FALSE)
                
                ## Now, find SPIA-sig pathways and do pathview() plots
                fc.all <- threshold(remap.matrix(edgeR.out$top[[i]][,1,drop=FALSE], SPIA.ID.conv, mean), thresh=4, method="gt", absolute=TRUE)
                fc.sig <- threshold(remap.matrix(output$sig[[i]][,1,drop=FALSE], SPIA.ID.conv, mean), thresh=4, method="gt", absolute=TRUE)
                sig.paths <- spia.df$ID[spia.df$Significant]
                message(paste(Cnames[i],"SPIA :",length(sig.paths),"sig"))
                select <- AnnotationDbi:::select   # if select() gets masked by other packages (and it does), pathview() calls will break
                for (path in sig.paths) {
                    IM(path,": ALL",nrow(fc.all))
                    pathview(gene.data=fc.all, pathway.id=path, species=kegg.org, kegg.dir=SPIA.data.dir, gene.idtype="entrez", node.sum="mean", limit=list(gene=2,cpd=2), both.dirs=list(gene=TRUE,cpd=TRUE), mid=list(gene="white",cpd="white"), na.col="grey", out.suffix=paste0(Cnames[i],".all-genes"))
                    IM(path,": SIG",nrow(fc.sig))
                    pathview(gene.data=fc.sig, pathway.id=path, species=kegg.org, kegg.dir=SPIA.data.dir, gene.idtype="entrez", node.sum="mean", limit=list(gene=2,cpd=2), both.dirs=list(gene=TRUE,cpd=TRUE), mid=list(gene="white",cpd="white"), na.col="grey", out.suffix=paste0(Cnames[i],".sig-genes"))
                }
                
            }
            
            setwd(launchpath)  # switch back to launch dir for final outputs
        }
        
    }
    
    ## Finalize Excel objects
    output$xls <- list(
        all.genes=cbind(xls.all$all.genes.1, do.call(cbind,all.top), xls.all$all.genes.2),
        sample.rpkms=data.frame(ID.cols, edgeR.out$expr$rpkms.all, stringsAsFactors=FALSE, check.names=FALSE),
        sample.counts=data.frame(ID.cols, edgeR.out$expr$counts.all, stringsAsFactors=FALSE, check.names=FALSE)
    )
    
    wd <- getwd()
    projid <- ifelse (grepl("/code$",wd), sub(".*/","",sub("/code$","",getwd())), "[UNKNOWN]")

    xls.tab.1 <- lapply(1:C, function(i) {
        x <- output$sig[[i]][rev(order(output$sig[[i]]$logFC)),]
        colnames(x) <- paste0(Cnames[i],".",colnames(x))
        xord <- match(rownames(x),xls.all$all.genes.1[,1])  # MATCH TO GENE ID COLUMN -- MAY NOT BE CALLED 'GeneID' THOUGH
        other.i <- setdiff(1:C, i)
        if (length(other.i)>0) {
            other.top <- do.call(cbind, all.top[other.i])[xord,]
            all.genes=cbind(xls.all$all.genes.1[xord,], x, other.top, xls.all$all.genes.2[xord,])
        } else {
            all.genes=cbind(xls.all$all.genes.1[xord,], x, xls.all$all.genes.2[xord,])
        }
    })
    names(xls.tab.1) <- Cnames
    
    xls.tabs.2.N <- list(
        sample.rpkms=data.frame(ID.cols, edgeR.out$expr$rpkms.all, stringsAsFactors=FALSE, check.names=FALSE)[sig.gene.rows,],
        sample.counts=data.frame(ID.cols, edgeR.out$expr$counts.all, stringsAsFactors=FALSE, check.names=FALSE)[sig.gene.rows,]
    )
    
    collate.func.data <- function(bkg) {
        ## 'bkg' is either 'genome' or 'opposite'
        ## produces one data.frame for all contrasts, both GO & KEGG, for that background type
        use <- lapply(output$functional, function(x) {
            nr.go <- nr.kegg <- 0
            if ("GO" %in% names(x)) {
                go <- x$GO[[bkg]]$terms
                nr.go <- nrow(go)
            }
            if ("KEGG" %in% names(x)) {
                kegg <- x$KEGG[[bkg]]$terms
                nr.kegg <- nrow(kegg)
            }
#            if (nr.go>0 & nr.kegg>0) {
                y <- rbind(go,kegg)
#            } else if (nr.go>0) {
#                y <- go
#            } else if (nr.kegg>0) {
#                y <- kegg
#            }
            if (nrow(y)>0) {
                usets <- unique(y$Enriched_In)
                y <- y[c(which(y$DB=="GO-BP"),which(y$DB=="GO-CC"),which(y$DB=="GO-MF"),which(y$DB=="KEGG")),]  # first sort by DB type
                y <- mat.split(y, y$Enriched_In)  # then split by gene set
                do.call(rbind, y[match(usets,names(y))])  # reorder list in usets (original) gene set order and recombine
            } else {
                y
            }
        })
        do.call(rbind, use)
    }
    
    functional.blurb.1 <- NULL
    functional.blurb.2 <- NULL
    if (functional) {
        sep1 <- ifelse(do.GO&do.SPIA,", ",ifelse(do.GO," and ",""))
        sep2 <- ifelse(do.GO|do.KEGG," and ","")
        functional.blurb.1 <- paste0(
            "Functional analysis was performed with ",
            ifelse(do.GO, paste0("GO DB '",GO.DB,"'"), ""),
            ifelse(do.KEGG, paste0(sep1,"KEGG DB '",sub(".*/","",KEGG.DB),"'"), ""),
            ifelse(do.SPIA, paste0(sep2,system("date +%Y%m%d",intern=TRUE)," SPIA pathway definitions"), "")
        )
        if (do.GO|do.KEGG) functional.blurb.2 <- "Two background models were used for functional analysis; tab \"func.genome\" compares each up, down list to the rest of the genome, \"func.opposite\" compares the up & down lists to each other."
    }
    
    xls.README <- as.data.frame(do.call(rbind, list(
        c(paste0("This Excel file contains EdgeR data for significant-DE genes from project ",projid,", [STRANDED / UNSTRANDED] gene counts."),""),
        c(paste0("Counts were obtained from [DESCRIBE METHODS AND GENE SET]."),""),
        if (C>1 & length(unique(FDR))>1) {
            c(paste0("DE genes were selected by EdgeR, default methods, contrast FDRs: ",paste(paste(Cnames,FDR,sep="="),collapse=","),", for ",C," contrast",ifelse(C>1,"s",""),"."),"")
        } else {
            c(paste0("DE genes were selected by EdgeR, default methods, FDR = ",FDR[1],ifelse(C>1,", for all contrasts.",".")),"")
        },
        c(paste0(nrow(edgeR.out$input$counts)," genes were analyzed, [EXPLAIN GENE SELECTION CRITERIA]."),""),
        c(paste0(ifelse(C>1,"Across all contrasts, ",""),n.de.up," genes were significantly upregulated, ",n.de.down," significantly downregulated."),""),
        if (length(functional.blurb.1)>0) { c(functional.blurb.1,"") },
        if (length(functional.blurb.2)>0) { c(functional.blurb.2,"") },
        c("",""),
        c("",""),
        c("Explanation of columns on tab \"all.genes\":",""),
        c("",""),
        c("GeneID","Ensembl Gene ID"),
        c("Symbol","Ensembl Gene Symbol"),
        c("*.logFC","EdgeR Contrast Log2FC"),
        c("*.PValue","EdgeR Contrast Raw P-Value"),
        c("*.FDR","EdgeR Contrast BH-Adjusted P-Value"),
        c("*.DE","Direction of Contrast Log2FC"),
        c("*.RpkmAvg","Sample RPKM Means"),
        c("*.RpkmSd","Sample RPKM StDevs"),
        c("*.CpmAvg","Sample CPM Means"),
        c("*.CpmSd","Sample CPM StDevs"),
        c("Chr","Ensembl Gene Chrom"),
        c("Start","Ensembl Gene Start"),
        c("End","Ensembl Gene End"),
        c("Strand","Ensembl Gene Strand"),
        c("Tot_Len","End-Start+1"),
        c("Exonic_Len","Exonic Bp in Gene"),
        c("N_Trans","N Known Transcripts"),
        c("N_Exons","N Known Unique Exons"),
        c("Biotype","Ensembl Gene Biotype"),
        c("SimpleBiotype","Simplified Biotype"),
        c("Status","Ensembl Gene Status"),
        c("Description","Ensembl Gene Description"),
        c("",""),
        c("",""),
        c("Explanation of columns on tabs \"sample.rpkms\" and \"sample.counts\":",""),
        c("",""),
        c("CPMs (counts-per-million) or RPKMs per sample per gene.",""),
        c("","")
    )))
    
    if (functional) {
        
        if (do.GO | do.KEGG) {
            xls.README <- rbind(
                xls.README,
                as.data.frame(do.call(rbind, list(
                    c("",""),
                    c("Explanation of columns on tab \"func.genome\" and \"func.opposite\":",""),
                    c("",""),
                    c("Enriched_In","Which gene set has the enrichment"),
                    c("DB","Term database of origin"),
                    c("Level","Term level of GO database"),
                    c("Term_Acc","Term accession"),
                    c("Term_Name","Term name"),
                    c("List_Term_Pct","Percent of foreground genes with term"),
                    c("Bkg_Term_Pct","Percent of background genes with term"),
                    c("Pct_LFC","Basically log2( List_Term_Pct / Bkg_Term_Pct ), but using adjusted counts to prevent divide-by-0."),
                    c("DB_Term_Pct","Percent of all genes in DB with term, which are also in the foreground set"),
                    c("Raw_P","Raw Fisher's Exact Test P-value"),
                    c("Adj_P","BH-Adjusted Fisher's Exact Test P-value"),
                    c("List_With","Number of genes in foreground set which have term"),
                    c("List_Without","Number of genes in foreground set which DO NOT have term"),
                    c("Bkg_With","Number of genes in background set which have term"),
                    c("Bkg_Without","Number of genes in background set which DO NOT have term"),
                    c("DB_With","Number of genes in DB with term"),
                    c("Input_Xrefs","Input gene IDs"),
                    c("Mapped_Symbols","Mapped gene symbols"),
                    c("Mapped_Names","Mapped gene names (only available for GO terms)"),
                    c("","")
                )))
            )
            xls.tabs.2.N <- c( xls.tabs.2.N, list( func.genome=collate.func.data("genome"), func.opposite=collate.func.data("opposite") ) )
        }
        
        if (do.SPIA) {
            xls.README <- rbind(
                xls.README,
                as.data.frame(do.call(rbind, list(
                    c("",""),
                    c("Explanation of columns on tab \"SPIA\":",""),
                    c("",""),
                    c("Name","KEGG Pathway Name"),
                    c("ID","KEGG Pathway ID"),
                    c("pSize","N genes in pathway"),
                    c("NDE","N DE genes in pathway"),
                    c("pNDE","Hypergeometric p-value for N DE genes in pathway"),
                    c("tA","Total perturbation in pathway"),
                    c("pPERT","p-value for tA"),
                    c("pG","Combined p-value for pNDE and pPERT"),
                    c("pGFdr","BH-adjusted pG"),
                    c("pGFWER","Bonferroni-adjusted pG"),
                    c("Significant","Is pGFdr significant at given FDR cutoff?"),
                    c("Status","Do DE genes indicate pathway is Activated or Inhibited?"),
                    c("KEGGLINK","Link to annotated pathway map at KEGG website"),
                    c("","")
                )))
            )
            xls.tabs.2.N <- c( xls.tabs.2.N, list( SPIA=do.call(rbind, lapply(1:C, function(i) cbind(Contrast=Cnames[i],output$functional[[i]]$SPIA))) ) )
        }
        
    }
    
    write.output <- function(xls, filename) {
        xls.dim <- sapply(xls, dim)
        if (all(xls.dim[1,]<=65535 & xls.dim[2,]<=255)) {
            ## Not too large for WriteXLS
            try(WriteXLS2(xls, filename, BoldHeaderRow=TRUE, row.names=FALSE, FreezeRow=1, FreezeCol=freezecol))
        } else {
            ## Too large for WriteXLS; write each tab to separate txt file
            for (i in 1:length(xls)) write.table(xls[[i]], paste0(filename,names(xls)[i],".txt"), sep="\t", quote=FALSE, row.names=FALSE)
        }
    }
    
    message("Writing final datasets...")
    output$xls$README <- xls.README
    xls.sig <- c( list(README=xls.README), xls.tab.1, xls.tabs.2.N )
    write.output(output$xls, paste0(outpath,"/all.edgeR.genes.xlsx"))
    write.output(xls.sig, paste0(outpath,"/sig.edgeR.genes.xlsx"))
    save(output, file=paste0(outpath,"/post.EdgeR.RData"))
    
    output
}


apa.names$dev <- c(apa.names$dev, "functional.analysis.old")
functional.analysis.old <- function(gene.sets, annots, outpath, functional.org, FDR=0.05, term.min.genes=3, clobber=FALSE, ID.convert=NULL, DB=NULL, post.EdgeR.data=NULL, SPIA.paths=NULL, SPIA.rdata.dir=NULL, debug=FALSE, raw.p=FALSE) {
    
    ## INPUT: a list of gene sets, gene annotation data.frame, and some arguments.
    ## OUTPUT: GO and KEGG term enrichments (Fisher's Exact Test), and SPIA results.
    ## 
    ## It is assumed that input gene IDs are Ensembl, that KEGG DB is also keyed on Ensembl IDs, and that GO and SPIA are NOT keyed with Ensembl IDs.
    ##  Thus, if you want to run GO or SPIA (which will run by default) you must supply the appropriate ID conversion tables via 'ID.convert'.
    ## 
    ## Arguments:
    ## 'gene.sets': a list with one or more elements, one for each gene set.  List names are gene set names.  Each element is a named log2-fold-change vector; vector names are gene IDs.
    ## 'annots': data.frame of gene annotations; ID in column 1. *** MUST INCLUDE ALL GENES, not just those in 'gene.sets', since it will also define the background gene set ***.
    ## 'outpath': location to write results.
    ## 'functional.org': the string "Genus species" for the organism in question, e.g. "Mus musculus".  Must match organisms from the sitewide command 'showTaxa'.
    ## 'FDR': significance cutoff for adjusted p-values
    ## 'raw.p=TRUE' will switch from selecting on adjusted p-values (FDR) to selecting on the raw p-values
    ## 'term.min.genes': minimum N genes for a GO or KEGG term to be retained
    ## 'clobber': if 'outpath' already exists, overwite?
    ## 
    ## 'ID.convert': list of ID converter(s), one element per ID type, each element being a 2-col matrix, col 1 = analysis ID (Ensembl), col 2 = database ID.
    ##   List names must be 'GO, 'KEGG', and/or 'SPIA', indicating which database(s) the converter(s) is for.  I.e. "ID.conv=list(GO=<matrix>, KEGG=<matrix>, SPIA=<matrix>)" to specify all 3.
    ##   If analysis IDs are Ensembl, then an SPIA converter is always necessary (uses Entrez IDs), and a GO converter is most likely necessary (ID type depends on organism, see below).
    ##   GO ID types for major orgs: Mouse=MGI, Yeast=SGD, Fly=FBid, most everything else uses Uniprot.
    ## 'DB': OPTIONAL list of database versions to use.  Names work the same as 'ID/convert'.  Databases are sought as standard locations:
    ##   GO will be the latest "go_yyymm" on host mysql-dev ; KEGG will be latest "yyyymm" in /n/data1/KEGG/<org>/ ; SPIA is from Bioconductor install on R's .libPaths() (can't specify alternate at the moment).
    ##   I.e. "DB=list(GO="alt_go_db_name", KEGG="/path/to/KEGG/Ensembl_term_DB.txt").
    ##
    ## 'post.EdgeR.data': this is only for data being passed to functional.analysis() by post.EdgeR().
    
    if (!is.ndfl(gene.sets) | !all(sapply(gene.sets,is.nlv))) stop("'gene.sets' must be a list of vectors!\n")
    G <- length(gene.sets)
    setnames <- names(gene.sets)
    output <- new.list(setnames)
    if (length(setnames)==0) stop("'gene.sets' elements must have names!\n")
    if (grepl("_",functional.org)) message(paste0("WARNING: you probably didn't want those underscores in '",functional.org,"'.  May or may not fail below..."))
    
    all.genes <- annots[,1]
    odat <- unlist(strsplit(sub("^ +","",system(paste0("bash -c '/home/apa/local/bin/showTaxa | grep \"",functional.org,"\"'"), intern=TRUE)), " +"))
    taxon <- as.numeric(odat[[1]])  # e.g. 9606 for Human
    kegg.org <- paste0(tolower(substr(odat[[2]],1,1)),substr(odat[[3]],1,2))  # e.g. "hsa"
    message(paste("Using",functional.org,"| NCBI taxon ID",taxon,"| KEGG code",kegg.org))
    no.GO.hosts <- c()
    no.GO.server <- ifelse(.HOSTNAME %in% no.GO.hosts, TRUE, FALSE)  # servers from which GO DB not accessible (e.g. OS-related Perl DBI issues)
    do.SPIA <- FALSE  # initially
    
    known <- sapply(gene.sets, function(x) all(names(x) %in% annots[,1]) )
    if (!all(known)) stop(paste("Some gene names in 'gene.sets' are not found in 'annots'!  Halting."))
    maxw <- max(nchar(setnames))
    usable <- sapply(gene.sets, function(x) suppressWarnings(all(!is.na(as.numeric(x)))) )
    if (any(!usable)) stop(paste("Gene sets",paste0(which(!usable),collapse=","),"are not usable!  Make sure these are vectors of log2-fold-changes (or all '0' if no LFC available), with names = gene IDs.\n"))
    paired <- sapply(gene.sets, function(x) any(x>0) & any(x<0) )   # basically, if LFC values have BOTH + AND - members, then this was a 2-sample comparison, thus samples were "paired"
    has.FC <- sapply(gene.sets, function(x) any(x>0) | any(x<0) )   # if not 'paired', then at least some nonzero values, which indicate the values themselves are important -- i.e. not all "0" just to get the gene list in the door.
    sp.format <- paste0("%-",maxw,"s  %6s  %6s")
    message(sprintf(sp.format, "Set", "Paired", "Has.FC"))
    for (i in 1:G) message(sprintf(sp.format, setnames[i], paired[i], has.FC[i]))

    launchpath <- getwd()
    if (file.exists(outpath)) {
        if (!clobber) stop(paste0("Output path '",outpath,"' already exists: will not clobber unless 'clobber=TRUE'!\n"))
    } else {
        ## only create working directory AFTER initial checkpoints cleared
        ## clobbering DOES NOT delete existing directory; there may be other things in it.
        ## clobbering only overwrites files
        system(paste("mkdir -p",outpath))
    }
    outpath <- normalizePath(outpath)
    
    if (length(DB$GO)==0) {
        ## no GO DB specified
        if (no.GO.server) {
            message(paste0("GO databases not accessible from this server (",.HOSTNAME,").  Skipping GO analysis."))
            DB$GO <- NA
        } else {
            if (length(taxon)==0) {
                message(paste("Unable to identify organism '",functional.org,"'!  Skipping GO analysis."))
            } else {
                DB$GO <- system("bash -c '/home/apa/local/bin/GO_Tools --showdbs | grep . | tail -n +2 | head -1'", intern=TRUE)
                if (length(DB$GO)>0) {
                    message(paste0("Found latest GO DB '",DB$GO,"'"))
                } else {
                    message(paste("Unable to find any GO DBs -- check availability of server 'mysql-dev'?  Skipping GO analysis."))
                    DB$GO <- NA
                }
            }
        }
    }
    do.GO <- ifelse(is.na(DB$GO), FALSE, TRUE)
    
    if (length(DB$KEGG)==0) {
        ##DB$KEGG <- system(paste0("bash -c 'ls /n/data1/KEGG/",kegg.org,"/*/*_Ensembl_term_DB.txt | sort | tail -1'"), intern=TRUE)  # sort | tail -1 should get latest, as dirs are 'yyyymm'
        DB$KEGG <- system(paste0("bash -c 'ls /n/data1/KEGG/",kegg.org,"/*/*_DB.txt | grep -v current | sort | tail -1'"), intern=TRUE)  # sort | tail -1 should get latest, as dirs are 'yyyymm'
        if (length(DB$KEGG)>0) {
            message(paste0("Found latest pertinent KEGG DB '",DB$KEGG,"'"))
        } else {
            message(paste("Unable to identify KEGG DB for KEGG org code '",KEGG.org,"'!  Skipping KEGG and SPIA analysis."))
            DB$KEGG <- NA
        }
    }
    do.KEGG <- ifelse(is.na(DB$KEGG), FALSE, TRUE)
    
    sigspia <- ifelse(raw.p,"pG","pGFdr")
    if ("SPIA" %in% names(ID.convert) && any(has.FC)) {
        ## SPIA ID converter given, AND at least one gene.set has fold-change data, so run SPIA
        ## Again, functional.analysis() assumes the analysis gene IDs are Ensembl.
        if (length(all.genes)>0) {
            do.SPIA <- TRUE
        } else {
            message("Cannot run SPIA if 'all.genes' argument is empty!  Skipping SPIA analysis.\n")
            do.SPIA <- FALSE
        }
    }
    if (do.SPIA) {
        SPIA.rdata <- system(paste0("bash -c 'ls /n/data1/KEGG/",kegg.org,"/*/*RData | grep -v current | sort | tail -1'"), intern=TRUE)  # sort | tail -1 should get latest, as dirs are 'yyyymm'
        if (length(SPIA.rdata)==0) {
            if (!(functional.org %in% c("Homo sapiens","Mus musculus"))) {
                message("*** Failed to identify any SPIA RData objects!  Default objects exist only for human & mouse.  No SPIA analysis will be performed\n")
                sleep(1)
                do.SPIA <- FALSE
            }
        } else {
            message(paste0("Found latest pertinent SPIA RData '",SPIA.rdata,"'"))
            SPIA.rdata.dir <- sub("/[^/]+$","/",SPIA.rdata)
        }
    }
    
    if (!do.GO & !do.KEGG & !do.SPIA) {
        stop("Unable to validate prerequisites for GO, KEGG or SPIA!  Stopping.\n")
    } else if (do.GO | do.KEGG) {
        ## Directory prep for FatiClone outputs
        FC.dir <- paste0(outpath,"/FatiClone")
        system(paste("mkdir -p",FC.dir))
        FC.dir <- normalizePath(FC.dir)
    }
    
    func.bg <- if (any(paired)) { c("genome","opposite") } else { "genome" }
    
    convert.FC <- function (names,data,group) cbind(GENE=names[data!=0], GROUP=paste0(sub("1","",sign(data[data!=0])),group))  # IF DATA IS LFC, IGNORE UNCHANGED GENES
    convert.noFC <- function (names,data,group) cbind(GENE=names, GROUP=group)  # RETAIN UNCHANGED GENES -- ENTIRE LIST COULD BE 0 (need more specific handling for the trivial-gene-list case)
    read.fc.files <- function (path,opp=FALSE) {
        terms <- try(read.delim(paste0(path,"/FatiClone_Fishers_",ifelse(opp,"ALL","OVER"),"_significant_terms.txt"), as.is=TRUE), silent=TRUE)
        genes <- try(read.delim(paste0(path,"/FatiClone_Fishers_",ifelse(opp,"ALL","OVER"),"_significant_genelist.txt"), as.is=TRUE), silent=TRUE)
        if (is(terms,"try-error")) terms <- data.frame( Map="", Enriched_In="", DB="", Level=0, Term_Acc="", Term_Name="", Clust_Term_Pct=0, Bkg_Term_Pct=0, Pct_LFC=0, DB_Term_Pct=0, Enrichment="", Raw_P=0, Adj_P=0, Odds=0, `0.95_CI_Lo`=0, `0.95_CI_Up`=0, Clust_With=0, Clust_Without=0, Bkg_With=0, Bkg_Without=0, DB_With=0, Input_Symbols="", Input_Names="", Input_Xrefs="", Mapped_Symbols="", Mapped_Names="", Mapped_Xrefs="", Input_Rows="" )[0,]  # same format as FatiClone terms output
        if (is(genes,"try-error")) genes <- data.frame( Map="", Enriched_In="", DB="", Level=0, Sig_Term_Acc="", Sig_Term_Name="", Row=0, Input_Xref="", `Original_ID(s)`="", Other_Terms="" )[0,]  # same format as FatiClone genes output
        list(terms=terms,genes=genes)
    }
    
    sigflag <- paste0(" -a ",FDR)
    if (raw.p) sigflag <- paste0(sigflag," -j NA")
    
    ## GO ANALYSIS ##
    
    if (do.GO) {
        message("Running GO analysis...")
        
        ## Prepare GO output directories
        GO.g.dir <- paste0(FC.dir,"/all.GO.g")
        if (!file.exists(GO.g.dir)) system(paste("mkdir",GO.g.dir))
        GO.g.dir <- normalizePath(GO.g.dir)
        
        if (any(paired)) {
            GO.o.dir <- paste0(FC.dir,"/all.GO.o")
            if (!file.exists(GO.o.dir)) system(paste("mkdir",GO.o.dir))
            GO.o.dir <- normalizePath(GO.o.dir)
        }
        
        ## Write out GO ID files
        if ("GO" %in% names(ID.convert)) {
            ids.to.go <- lapply(1:G, function(i) {
                x <- remap.matrix(as.matrix(gene.sets[[i]]), ID.convert$GO, mean)
                if (has.FC[i]) {
                    convert.FC(rownames(x),x,setnames[i])
                } else {
                    convert.noFC(rownames(x),x,setnames[i])
                }
            })
        } else {
            ids.to.go <- lapply(1:G, function(i) {
                if (has.FC[i]) {
                    convert.FC(names(gene.sets[[i]]),gene.sets[[i]],setnames[i])
                } else {
                    convert.noFC(names(gene.sets[[i]]),gene.sets[[i]],setnames[i])
                }
            })
        }
        write.table(do.call(rbind,ids.to.go), paste0(outpath,"/IDs_to_GO.txt"), sep="\t", quote=FALSE, row.names=FALSE, col.names=TRUE)
        
        ## Run FatiClone for GO
        GO.g.cmd <- paste0("/home/apa/local/bin/FatiClone -f ",outpath,"/IDs_to_GO.txt -d ",DB$GO[1]," -x ",taxon,sigflag," -t 1 -b genome -w ",GO.g.dir," --no_sig_parents --nounder")
        message(paste("\nTesting whole-genome GO enrichments...\nRunning:",GO.g.cmd))
        if (!debug) system(GO.g.cmd)
        
        if (any(paired)) {
            GO.o.cmd <- paste0("/home/apa/local/bin/FatiClone -f ",outpath,"/IDs_to_GO.txt -d ",DB$GO[1]," -x ",taxon,sigflag," -t 1 -b opposite -w ",GO.o.dir," --no_sig_parents")
            message(paste("\nTesting head-to-head GO enrichments...\nRunning:",GO.o.cmd))
            if (!debug) system(GO.o.cmd)
        }
        
        ## Read in FatiClone results
        fc.go <- new.list(func.bg)
        fc.go$genome <- read.fc.files(GO.g.dir,FALSE)
        if (any(paired)) fc.go$opposite <- read.fc.files(GO.o.dir,TRUE)
        message(paste(sum(sapply(fc.go, function(x) nrow(x$terms) )),"GO result rows"))
        
        ## GO DB gene IDs may not be same as analysis gene IDs; add analysis IDs column to sig-term-genes dataset
        for (j in 1:length(fc.go)) {
            fc.go[[j]]$genes <- as.data.frame(as.list(fc.go[[j]]$genes[c(1:8,8:9)]))  # extra effort required to make this work when $genes has 0 rows...
            names(fc.go[[j]]$genes)[8:9] <- c("GO.DB.IDs","Analysis.IDs")
            if (nrow(fc.go[[j]]$genes)>0) {
                if (length(ID.convert$GO)>0) {
                    fc.go[[j]]$genes[,9] <- sapply(fc.go[[j]]$genes[,8], function(x) paste(sort(unique(ID.convert$GO[ID.convert$GO[,2]==x,1])), collapse="; ") )
                } else {
                    fc.go[[j]]$genes[,9] <- fc.go[[j]]$genes[,8]
                }
            }
        }
        
        ## Add GO results to output object
        for (i in 1:G) {
            output[[i]]$GO <- fc.go
            cl.names <- c(setnames[i],paste0("-",setnames[i]))  # e.g. c("test","-test")
            for (j in 1:length(fc.go)) {
                term <- fc.go[[j]]$terms[fc.go[[j]]$terms$Cluster %in% cl.names,-1]  # TERMS: DROP MAP COLUMN
                colnames(term) <- c("Enriched_In","DB","Level","Term_Acc","Term_Name","Clust_Term_Pct","Bkg_Term_Pct","Pct_LFC","DB_Term_Pct","Enrichment","Raw_P","Adj_P","Odds","0.95_CI_Lo","0.95_CI_Up","Clust_With","Clust_Without","Bkg_With","Bkg_Without","DB_With","Input_Symbols","Input_Names","Input_Xrefs","Mapped_Symbols","Mapped_Names","Mapped_Xrefs","Input_Rows")
                gene <- unique(fc.go[[j]]$genes[fc.go[[j]]$genes$Cluster %in% cl.names,-c(1:2)])  # GENES: DROP MAP, CLUSTER COLUMNS
                colnames(gene) <- c("DB","Level","Sig_Term_Acc","Sig_Term_Name","Row","Input_Xref","Original_ID(s)","Other_Terms")
                if (nrow(term)>0) {
                    if (nrow(gene)==0) warning("GO error: have term rows but no gene rows!\n")
                    term <- term[rev(order(term$Clust_Term_Pct)),]  # first sort by prevalence
                    term <- term[c(which(term$DB=="BP"),which(term$DB=="CC"),which(term$DB=="MF")),]  # order by BP, CC, MF, (in that order)
                    term$Pct_LFC <- log2(((term$Clust_With+0.5)/(term$Clust_With+term$Clust_Without+0.5))/((term$Bkg_With+0.5)/(term$Bkg_With+term$Bkg_Without+0.5)))  # recalculate to eliminate INFs etc, and actually put in Log2.
                    for (n in c("Clust_Term_Pct","Bkg_Term_Pct","DB_Term_Pct")) term[[n]] <- term[[n]]/100
                    term$DB <- paste0("GO-",term$DB)  # e.g. "BP" -> "GO-BP"
                    if (nrow(gene)>0) gene$DB <- paste0("GO-",gene$DB)  # e.g. "BP" -> "GO-BP"
                    if (names(fc.go)[j]=="genome") {
                        u <- term[term$Enriched_In==cl.names[1],]   # "up" set, or only-set if unpaired data
                        d <- term[term$Enriched_In==cl.names[2],]   # "down" set
                    } else if (names(fc.go)[j]=="opposite") {
                        u <- term[term$Enrichment=="OVER",]   # "up" set, or only-set if unpaired data
                        d <- term[term$Enrichment=="UNDER",]  # "down" set
                    } else {
                        message(paste0("\n\n\n**********  WARNING: Background model '",names(fc.go)[j],"' is not supported!  Data is probably being handled incorrectly.  **********\n\n\n"))
                        Sys.sleep(10)
                    }
                    if (paired[i]) {
                        message(paste(setnames[i],names(fc.go)[j],"GO :",nrow(u),"up",nrow(d),"down"))
                    } else {
                        message(paste(setnames[i],names(fc.go)[j],"GO :",nrow(u),"genes"))
                    }
                    if (paired[i]) {
                        if (nrow(u)>0) u$Enriched_In <- paste(cl.names[1],"Up")
                        if (nrow(d)>0) d$Enriched_In <- paste(cl.names[1],"Down")
                    }
                    term <- rbind(u,d)
                    term <- term[term$Clust_With>=term.min.genes , !(colnames(term) %in% c("Odds","0.95_CI_Lo","0.95_CI_Up","Enrichment","Input_Symbols","Input_Names","Mapped_Xrefs","Input_Rows"))]
                    message(paste(nrow(term),"GO",names(fc.go)[i],"rows remained after filtering!"))
                    if (nrow(term)>0) {
                        keep.genes <- sort(unique(unlist(strsplit(term$Input_Xrefs, "; "))))
                        gene <- gene[gene$Input_Xref %in% keep.genes,]
                        gene <- gene[order(gene$Input_Xref),]
                    } else {
                        gene <- gene[0,]
                    }
                }
                output[[i]]$GO[[j]]$terms <- term
                output[[i]]$GO[[j]]$genes <- gene
            }
        }
    }
    
    ## KEGG ANALYSIS ##
    
    if (do.KEGG) {
        message("Running KEGG analysis...")
        
        ## Write out KEGG ID files
        if ("KEGG" %in% names(ID.convert)) {
            ids.to.kegg <- lapply(1:G, function(i) {
                x <- remap.matrix(as.matrix(gene.sets[[i]]), ID.convert$KEGG, mean)
                if (has.FC[i]) {
                    convert.FC(rownames(x),x,setnames[i])
                } else {
                    convert.noFC(rownames(x),x,setnames[i])
                }
            })
        } else {
            ids.to.kegg <- lapply(1:G, function(i) {
                if (has.FC[i]) {
                    convert.FC(names(gene.sets[[i]]),gene.sets[[i]],setnames[i])
                } else {
                    convert.noFC(names(gene.sets[[i]]),gene.sets[[i]],setnames[i])
                }
            })
        }
        write.table(do.call(rbind,ids.to.kegg), paste0(outpath,"/IDs_to_KEGG.txt"), sep="\t", quote=FALSE, row.names=FALSE, col.names=TRUE)
        
        ## Prepare KEGG output directories
        ## Run FatiClone for KEGG
        KEGG.g.dir <- paste0(FC.dir,"/all.KEGG.g")
        if (!file.exists(KEGG.g.dir)) system(paste("mkdir",KEGG.g.dir))
        KEGG.g.dir <- normalizePath(KEGG.g.dir)
        
        KEGG.g.cmd <- paste0("/home/apa/local/bin/FatiClone -f ",outpath,"/IDs_to_KEGG.txt -o ",DB$KEGG[1],sigflag," -t 1 -b genome -w ",KEGG.g.dir," --no_sig_parents --nounder")
        message(paste("\nTesting whole-genome KEGG enrichments...\nRunning:",KEGG.g.cmd))
        if (!debug) system(KEGG.g.cmd)
        
        if (any(paired)) {
            KEGG.o.dir <- paste0(FC.dir,"/all.KEGG.o")
            if (!file.exists(KEGG.o.dir)) system(paste("mkdir",KEGG.o.dir))
            KEGG.o.dir <- normalizePath(KEGG.o.dir)
            
            KEGG.o.cmd <- paste0("/home/apa/local/bin/FatiClone -f ",outpath,"/IDs_to_KEGG.txt -o ",DB$KEGG[1],sigflag," -t 1 -b opposite -w ",KEGG.o.dir," --no_sig_parents")
            message(paste("\nTesting head-to-head KEGG enrichments...\nRunning:",KEGG.o.cmd))
            if (!debug) system(KEGG.o.cmd)
        }
        
        ## Read in FatiClone results
        fc.kegg <- new.list(func.bg)
        fc.kegg$genome <- read.fc.files(KEGG.g.dir,FALSE)
        if (any(paired)) fc.kegg$opposite <- read.fc.files(KEGG.o.dir,TRUE)
        message(paste(sum(sapply(fc.kegg, function(x) nrow(x$terms) )),"KEGG result rows"))
        
        ## KEGG DB gene IDs may not be same as analysis gene IDs; add analysis IDs column to sig-term-genes dataset
        for (j in 1:length(fc.kegg)) {
            fc.kegg[[j]]$genes <- fc.kegg[[j]]$genes[,c(1:8,8:9)]
            colnames(fc.kegg[[j]]$genes)[8:9] <- c("KEGG.DB.IDs","Analysis.IDs")
            if (nrow(fc.kegg[[j]]$genes)>0) {
                if (length(ID.convert$KEGG)>0) {
                    fc.kegg[[j]]$genes[,9] <- sapply(fc.kegg[[j]]$genes[,8], function(x) paste(sort(unique(ID.convert$KEGG[ID.convert$KEGG[,2]==x,1])), collapse="; ") )
                    kegg.key <- unique(breakout(lapply(split(ID.convert$KEGG[,1],ID.convert$KEGG[,2]), function(x) sort(unique(annots[match(x,annots[,1]),2])) ), reverse=TRUE))
                } else {
                    fc.kegg[[j]]$genes[,9] <- fc.kegg[[j]]$genes[,8]
                    kegg.key <- annots[,1:2]
                }
                ## Because KEGG currently uses Ensembl IDs -- and has no symbol mappings, unlike the GO DBs -- we have to add symbols manually
                fc.kegg[[j]]$terms$Mapped_Symbols <- FatiClone.KEGG.convert(kegg.key, from=fc.kegg[[j]]$terms$Input_Xrefs)
            }
        }
        
        ## Add KEGG results to output object
        for (i in 1:G) {
            output[[i]]$KEGG <- fc.kegg
            cl.names <- c(setnames[i],paste0("-",setnames[i]))  # e.g. c("test","-test")
            for (j in 1:length(fc.kegg)) {
                term <- fc.kegg[[j]]$terms[fc.kegg[[j]]$terms$Cluster %in% cl.names,-1]  # DROP MAP COLUMN
                colnames(term) <- c("Enriched_In","DB","Level","Term_Acc","Term_Name","Clust_Term_Pct","Bkg_Term_Pct","Pct_LFC","DB_Term_Pct","Enrichment","Raw_P","Adj_P","Odds","0.95_CI_Lo","0.95_CI_Up","Clust_With","Clust_Without","Bkg_With","Bkg_Without","DB_With","Input_Symbols","Input_Names","Input_Xrefs","Mapped_Symbols","Mapped_Names","Mapped_Xrefs","Input_Rows")
                gene <- unique(fc.kegg[[j]]$genes[fc.kegg[[j]]$genes$Cluster %in% cl.names,-c(1:2)])  # DROP MAP, CLUSTER COLUMNS
                colnames(gene) <- c("DB","Level","Sig_Term_Acc","Sig_Term_Name","Row","Input_Xref","Original_ID(s)","Other_Terms")
                if (nrow(term)>0) {
                    if (nrow(gene)==0) warning("KEGG error: have term rows but no gene rows!\n")
                    term <- term[rev(order(term$Clust_Term_Pct)),]  # first sort by prevalence
                    term$Pct_LFC <- log2(((term$Clust_With+0.5)/(term$Clust_With+term$Clust_Without+0.5))/((term$Bkg_With+0.5)/(term$Bkg_With+term$Bkg_Without+0.5)))  # recalculate to eliminate INFs etc, and actually put in Log2.
                    for (n in c("Clust_Term_Pct","Bkg_Term_Pct","DB_Term_Pct")) term[[n]] <- term[[n]]/100
                    if (names(fc.kegg)[j]=="genome") {
                        u <- term[term$Enriched_In==cl.names[1],]   # "up" set, or only-set if unpaired data
                        d <- term[term$Enriched_In==cl.names[2],]   # "down" set
                    } else if (names(fc.kegg)[j]=="opposite") {
                        u <- term[term$Enrichment=="OVER",]   # "up" set, or only-set if unpaired data
                        d <- term[term$Enrichment=="UNDER",]  # "down" set
                    } else {
                        message(paste0("\n\n\n**********  WARNING: Background model '",names(fc.kegg)[j],"' is not supported!  Data is probably being handled incorrectly.  **********\n\n\n"))
                        Sys.sleep(10)
                    }
                    if (paired[i]) {
                        message(paste(setnames[i],names(fc.kegg)[j],"KEGG :",nrow(u),"up",nrow(d),"down"))
                    } else {
                        message(paste(setnames[i],names(fc.kegg)[j],"KEGG :",nrow(u),"genes"))
                    }
                    if (paired[i]) {
                        if (nrow(u)>0) u$Enriched_In <- paste(cl.names[1],"Up")
                        if (nrow(d)>0) d$Enriched_In <- paste(cl.names[1],"Down")
                    }
                    term <- rbind(u,d)
                    term <- term[term$Clust_With>=term.min.genes , !(colnames(term) %in% c("Odds","0.95_CI_Lo","0.95_CI_Up","Enrichment","Input_Symbols","Input_Names","Mapped_Xrefs","Input_Rows"))]
                    message(paste(nrow(term),"KEGG",names(fc.kegg)[i],"rows remained after filtering!"))
                    if (nrow(term)>0) {
                        keep.genes <- sort(unique(unlist(strsplit(term$Input_Xrefs, "; "))))
                        gene <- gene[gene$Input_Xref %in% keep.genes,]
                        gene <- gene[order(gene$Input_Xref),]
                    } else {
                        gene <- gene[0,]
                    }
                }
                output[[i]]$KEGG[[j]]$terms <- term
                output[[i]]$KEGG[[j]]$genes <- gene
            }
        }
    }
    
    ## SPIA ANALYSIS ##
    
    if (do.SPIA) {
        message("Running SPIA analysis...")
        
        require(SPIA)
        require(pathview)
        
        ## Prepare SPIA output directory
        SPIA.dir <- paste0(outpath,"/SPIA")
        SPIA.data.dir <- paste0(SPIA.dir,"/data")
        if (!file.exists(SPIA.data.dir)) system(paste("mkdir -p",SPIA.data.dir))  # also makes SPIA.dir in the process
        SPIA.dir <- normalizePath(SPIA.dir)
        SPIA.data.dir <- normalizePath(SPIA.data.dir)
        if (length(SPIA.rdata.dir)>0) SPIA.rdata.dir <- paste0(normalizePath(SPIA.rdata.dir),"/")  # SPIA requires trailing backslash
        
        ## Prepare gene sets
        if ("SPIA" %in% names(ID.convert)) {
            de.to.spia <- lapply(gene.sets, function(x) remap.matrix(as.matrix(x), ID.convert$SPIA, mean)[,1] )
            if (length(post.EdgeR.data)>0) {
                all.to.spia.fc <- lapply(post.EdgeR.data$top, function(x) remap.matrix(as.matrix(x[,1,drop=FALSE]), ID.convert$SPIA, mean)[,1] )
                all.to.spia <- lapply(all.to.spia, names)
            } else {
                all.to.spia <- real(unique(ID.convert$SPIA[ID.convert$SPIA[,1] %in% all.genes,2]))
            }
        } else {
            de.to.spia <- gene.sets
            if (length(post.EdgeR.data)>0) {
                all.to.spia.fc <- lapply(post.EdgeR.data$top, function(x) named.vector(x[,1],rownames(x)) )
                all.to.spia <- lapply(all.to.spia, names)
            } else {
                all.to.spia <- all.genes
            }
        }
        
        ## Change to SPIA directory, temporarily
        setwd(SPIA.dir)
        
        ## Run SPIA
        for (i in 1:G) {
            if (!has.FC[i]) {
                message(paste("SPIA:",setnames[i],": no fold-change data; skipping"))
                next
            }
            message(paste("SPIA:",setnames[i]))
            if (length(SPIA.paths)>0) SPIA.paths <- sub("^[a-z]+","",SPIA.paths)
            if (!debug) spia.df <- spia(de=de.to.spia[[i]], all=all.to.spia, organism=kegg.org, data.dir=SPIA.rdata.dir, pathids=SPIA.paths, plots=TRUE)  #,nB=2000,verbose=TRUE,beta=NULL,combine="fisher")
            message("")   # make up for spia()'s poorly-programmed habit of putting newlines at the start of messages and NOT the end...
            if (debug) {
##                spia.out.master <<- spia.df  ############ uncomment once for pre-debugging run only !!!!!!!!!
                spia.df <- spia.out.master
            }
            if (!debug) system(paste0("mv -f SPIAPerturbationPlots.pdf ",setnames[i],".SPIAPerturbationPlots.pdf"))
            for (j in c(5,7:10)) if (any(is.na(spia.df[,j]))) spia.df[which(is.na(spia.df[,j])),j] <- 1  # correct any NA p-values
            plotP.thresh <- ifelse(any(spia.df$pGFdr<=FDR), FDR, 1)
            png(paste0(setnames[i],".2way_evidence.png"), 600, 600); plotP(spia.df, thresh=plotP.thresh); dev.off()
            spia.df$ID <- paste0(kegg.org,spia.df$ID)
            output[[i]]$SPIA <- spia.df <- cbind(spia.df, Significant=spia.df[[sigspia]]<=FDR)[,c(1:10,13,11:12)]  # ALSO REPLACE SPIA.DF HERE
            write.table(spia.df, paste0(setnames[i],".SPIA_results.txt"), sep="\t", quote=FALSE, row.names=FALSE)
            
            ## Now, find SPIA-sig pathways and do pathview() plots
            fc.de <- threshold(as.matrix(de.to.spia[[i]]), thresh=4, method="gt", absolute=TRUE)
            if (length(post.EdgeR.data)>0) fc.all <- threshold(as.matrix(all.to.spia.fc[[i]]), thresh=4, method="gt", absolute=TRUE)
            select <- AnnotationDbi:::select   # if select() gets masked by other packages (and it does), pathview() calls will break
            sig.paths <- sub(kegg.org,"",spia.df$ID[spia.df$Significant])
            message(paste("\n",setnames[i],"SPIA :",length(sig.paths),"sig"))  # leading '\n' since prior spia() messages do not end in newlines, stupidly
            for (path in sig.paths) {
                IM(" ",path,kegg.org,SPIA.data.dir)
                pathview(gene.data=fc.de, pathway.id=path, species=kegg.org, kegg.dir=SPIA.data.dir, gene.idtype="entrez", node.sum="mean", limit=list(gene=2,cpd=2), both.dirs=list(gene=TRUE,cpd=TRUE), mid=list(gene="white",cpd="white"), na.col="grey", out.suffix=paste0(setnames[i],".sig-genes"))
                if (length(post.EdgeR.data)>0) {
                    pathview(gene.data=fc.all, pathway.id=path, species=kegg.org, kegg.dir=SPIA.data.dir, gene.idtype="entrez", node.sum="mean", limit=list(gene=2,cpd=2), both.dirs=list(gene=TRUE,cpd=TRUE), mid=list(gene="white",cpd="white"), na.col="grey", out.suffix=paste0(setnames[i],".all-genes"))
                }
            }
        }
        
        setwd(launchpath)  # switch back to launch dir for final outputs
    }
    
    ## Finalize Excel objects
    message("Summarizing analysis...")
    projid <- ifelse (grepl("/code$",launchpath), sub(".*/","",sub("/code$","",launchpath)), "[UNKNOWN]")
    xls.tabs.2.N <- list()
    
    if (length(post.EdgeR.data)>0) {
        xls.tab.1 <- post.EdgeR.data$xls.tab.1
        n.all.genes <- post.EdgeR.data$n.all.genes
        n.de.up <- post.EdgeR.data$n.de.up
        n.de.dn <- post.EdgeR.data$n.de.dn
    } else {
        ## If not supplied by a post.EdgeR() call, generate these objects here.
        xls.tab.1 <- cbind( matrix(NA,nrow(annots),G,FALSE,list(c(),setnames)), annots )
        for (i in 1:G) xls.tab.1[match(names(gene.sets[[i]]),annots[,1]),i] <- ternary(paired[i], gene.sets[[i]], rep("X",length(gene.sets[[i]])))
        n.all.genes <- length(unique(unlist(lapply(gene.sets,names))))
        if (any(paired)) {
            n.de.up <- length(unique(unlist(lapply(gene.sets, function(x) names(x)[x>0] ))))
            n.de.dn <- length(unique(unlist(lapply(gene.sets, function(x) names(x)[x<0]))))
        } else {
            n.de <- length(unique(unlist(lapply(gene.sets, function(x) names(x)[x<0]))))
        }
    }
    
    collate.func.data <- function(bkg) {
        ## 'bkg' is either 'genome' or 'opposite'
        ## produces one data.frame for all contrasts, both GO & KEGG, for that background type
        use <- lapply(output, function(x) {
            nr.go <- nr.kegg <- 0
            if ("GO" %in% names(x)) {
                if (bkg %in% names(x$GO)) {
                    go <- x$GO[[bkg]]$terms
                    nr.go <- nrow(go)
                }
            }
            if ("KEGG" %in% names(x)) {
                if (bkg %in% names(x$KEGG)) {
                    kegg <- x$KEGG[[bkg]]$terms
                    nr.kegg <- nrow(kegg)
                }
            }
#            if (nr.go>0 & nr.kegg>0) {
                y <- rbind(go,kegg)
#            } else if (nr.go>0) {
#                y <- go
#            } else if (nr.kegg>0) {
#                y <- kegg
#            }
            message(paste(bkg,":",nrow(y),"terms"))
            if (nrow(y)>0) {
                usets <- unique(y$Enriched_In)
                y <- y[c(which(y$DB=="GO-BP"),which(y$DB=="GO-CC"),which(y$DB=="GO-MF"),which(y$DB=="KEGG")),]  # first sort by DB type
                y <- mat.split(y, y$Enriched_In)  # then split by gene set
                do.call(rbind, y[match(usets,names(y))])  # reorder list in usets (original) gene set order and recombine
            } else {
                y
            }
        })
        do.call(rbind, use)
    }
    
    functional.blurb.1 <- NULL
    functional.blurb.2 <- NULL
    sep1 <- ifelse(do.GO&do.SPIA,", ",ifelse(do.GO," and ",""))
    sep2 <- ifelse(do.GO|do.KEGG," and ","")
    cont.blurb <- ifelse(G>1,"Across all contrasts, ","")
    functional.blurb.1 <- paste0(
        "Functional analysis was performed with ",
        ifelse(do.GO, paste0("GO DB '",DB$GO,"'"), ""),
        ifelse(do.KEGG, paste0(sep1,"KEGG DB '",sub(".*/","",DB$KEGG),"'"), ""),
        ifelse(do.SPIA, paste0(sep2,system("date +%Y%m%d",intern=TRUE)," SPIA pathway definitions"), "")
    )
    if (do.GO|do.KEGG) {
        if (any(paired)) {
            functional.blurb.2 <- "Two background models were used for functional analysis; tab \"func.genome\" compares each up, down list to the rest of the genome, \"func.opposite\" compares the up & down lists to each other."
        } else {
            functional.blurb.2 <- "One background model was used for functional analysis: tab \"func.genome\" compares each up, down list to the rest of the genome."
        }
    }
    
    xls.README <- as.data.frame(do.call(rbind, list(
        c(paste0("This Excel file contains EdgeR data for significant-DE genes from project ",projid,", [STRANDED / UNSTRANDED] gene counts."),""),
        c(paste0("Counts were obtained from [DESCRIBE METHODS AND GENE SET]."),""),
        if (G>1 & length(unique(FDR))>1) {
            c(paste0("DE genes were selected by EdgeR, default methods, contrast FDRs: ",paste(paste(setnames,FDR,sep="="),collapse=","),", for ",G," contrast",ifelse(G>1,"s",""),"."),"")
        } else {
            c(paste0("DE genes were selected by EdgeR, default methods, FDR = ",FDR[1],ifelse(G>1,", for all contrasts.",".")),"")
        },
        c(paste0(n.all.genes," genes were analyzed, [EXPLAIN GENE SELECTION CRITERIA]."),""),
        ternary(
            any(paired),
            c( paste0(cont.blurb,n.de.up," genes were significantly upregulated, ",n.de.dn," significantly downregulated."), ""),
            c( paste0(cont.blurb,n.de," genes significantly changed."), "")
        ),
        if (length(functional.blurb.1)>0) { c(functional.blurb.1,"") },
        if (length(functional.blurb.2)>0) { c(functional.blurb.2,"") },
        c("",""),
        c("",""),
        c("Explanation of columns on tab \"all.genes\":",""),
        c("",""),
        c("GeneID","Ensembl Gene ID"),
        c("Symbol","Ensembl Gene Symbol"),
        c("*.logFC","EdgeR Contrast Log2FC"),
        c("*.PValue","EdgeR Contrast Raw P-Value"),
        c("*.FDR","EdgeR Contrast BH-Adjusted P-Value"),
        c("*.DE","Direction of Contrast Log2FC"),
        c("*.RpkmAvg","Sample RPKM Means"),
        c("*.RpkmSd","Sample RPKM StDevs"),
        c("*.CpmAvg","Sample CPM Means"),
        c("*.CpmSd","Sample CPM StDevs"),
        c("Chr","Ensembl Gene Chrom"),
        c("Start","Ensembl Gene Start"),
        c("End","Ensembl Gene End"),
        c("Strand","Ensembl Gene Strand"),
        c("Tot_Len","End-Start+1"),
        c("Exonic_Len","Exonic Bp in Gene"),
        c("N_Trans","N Known Transcripts"),
        c("N_Exons","N Known Unique Exons"),
        c("Biotype","Ensembl Gene Biotype"),
        c("SimpleBiotype","Simplified Biotype"),
        c("Status","Ensembl Gene Status"),
        c("Description","Ensembl Gene Description"),
        c("",""),
        c("",""),
        c("Explanation of columns on tabs \"sample.rpkms\" and \"sample.counts\":",""),
        c("",""),
        c("CPMs (counts-per-million) or RPKMs per sample per gene.",""),
        c("","")
    )))
    
    if (do.GO | do.KEGG) {
        xls.README <- rbind(
            xls.README,
            as.data.frame(do.call(rbind, list(
                c("",""),
                c("Explanation of columns on tab \"func.genome\" and \"func.opposite\":",""),
                c("",""),
                c("Enriched_In","Which gene set has the enrichment"),
                c("DB","Term database of origin"),
                c("Level","Term level of GO database"),
                c("Term_Acc","Term accession"),
                c("Term_Name","Term name"),
                c("List_Term_Pct","Percent of foreground genes with term"),
                c("Bkg_Term_Pct","Percent of background genes with term"),
                c("Pct_LFC","Basically log2( List_Term_Pct / Bkg_Term_Pct ), but using adjusted counts to prevent divide-by-0."),
                c("DB_Term_Pct","Percent of all genes in DB with term, which are also in the foreground set"),
                c("Raw_P","Raw Fisher's Exact Test P-value"),
                c("Adj_P","BH-Adjusted Fisher's Exact Test P-value"),
                c("List_With","Number of genes in foreground set which have term"),
                c("List_Without","Number of genes in foreground set which DO NOT have term"),
                c("Bkg_With","Number of genes in background set which have term"),
                c("Bkg_Without","Number of genes in background set which DO NOT have term"),
                c("DB_With","Number of genes in DB with term"),
                c("Input_Xrefs","Input gene IDs"),
                c("Mapped_Symbols","Mapped gene symbols"),
                c("Mapped_Names","Mapped gene names (only available for GO terms)"),
                c("","")
            )))
        )
        collated <- list()
        collated$func.genome <- collate.func.data("genome")
        if (any(paired)) collated$func.opposite <- collate.func.data("opposite")
        xls.tabs.2.N <- c( xls.tabs.2.N, collated )
    }
    
    if (do.SPIA) {
        xls.README <- rbind(
            xls.README,
            as.data.frame(do.call(rbind, list(
                c("",""),
                c("Explanation of columns on tab \"SPIA\":",""),
                c("",""),
                c("Name","KEGG Pathway Name"),
                c("ID","KEGG Pathway ID"),
                c("pSize","N genes in pathway"),
                c("NDE","N DE genes in pathway"),
                c("pNDE","Hypergeometric p-value for N DE genes in pathway"),
                c("tA","Total perturbation in pathway"),
                c("pPERT","p-value for tA"),
                c("pG","Combined p-value for pNDE and pPERT"),
                c("pGFdr","BH-adjusted pG"),
                c("pGFWER","Bonferroni-adjusted pG"),
                c("Significant",paste("Is",sigspia,"significant at given FDR cutoff?")),
                c("Status","Do DE genes indicate pathway is Activated or Inhibited?"),
                c("KEGGLINK","Link to annotated pathway map at KEGG website"),
                c("","")
            )))
        )
        xls.tabs.2.N <- c( xls.tabs.2.N, list( SPIA=do.call(rbind, lapply(1:G, function(i) cbind(Contrast=setnames[i],output[[i]]$SPIA))) ) )
    }
    
    message("Writing final datasets...")
#    message(paste("README:",nrow(xls.README),"TAB 1:",nrow(xls.tab.1),"TABS 2-N:",paste(sapply(xls.tabs.2.N,nrow),collapse=" ")))
    output$xls <- c( list(README=xls.README), list(genes=xls.tab.1), xls.tabs.2.N )
    xls.dim <- sapply(output$xls, dim)
    if (all(xls.dim[1,]<=65535 & xls.dim[2,]<=255)) {
        ## Not too large for WriteXLS
        try(WriteXLS2(output$xls, paste0(outpath,"/functional.analysis.xlsx"), BoldHeaderRow=TRUE, row.names=FALSE, FreezeRow=1))
    } else {
        ## Too large for WriteXLS; write each tab to separate txt file
        for (i in 1:length(output$xls)) write.table(output$xls[[i]], paste0(outpath,"/functional.analysis.xlsx.",names(output$xls)[i],".txt"), sep="\t", quote=FALSE, row.names=FALSE)
    }
    save(output, file=paste0(outpath,"/functional.analysis.RData"))
    
    output
}


