
apa.names$graphics <- c(apa.names$graphics, "view.colormap")
view.colormap <- function() {
    view.image(paste(data.path,"RColorMap.png",sep="/"))
}


apa.names$graphics <- c(apa.names$graphics, "viewPalette")
viewPalette <- function (ramp=palette(), main=NULL, ranges=NULL, labels=NULL, bgcol=0, fontcol=1, cex=1, rgb.mcv=FALSE, values=TRUE) {
    
    ## Visualizes an arbitrary palette, with or without an associated numeric range.
    ## ramp = char vector of hex values for palette.
    ## ranges = num vector of length 2, i.e. c(start, end) of numeric ranges to be associated with color breaks.
    ## ann = T/F, show axis annotations? (supercedes showranges).
    ## title = character string; a title for the plot.
    ## bgcol = color name or default palette number; changes background color.  
    ## fontcol = color name or default palette number; changes text color.  
    
    showranges <- ifelse(length(ranges)==0, FALSE, TRUE)
    ramp <- rev(ramp)
    N <- length(ramp)
    yvar <- 1/N
    yvals <- vector("numeric", length=2*N)
    breaks <- seq(0, 1, by=yvar)       # color block edges, range labels
    label.y <- breaks[1:N] + yvar/2    # all other labels
    
    if (length(labels)>0) {
        if (length(labels) != N) stop("Length of 'labels' and 'ramp' must be equal!\n")
        labels <- rev(labels)
    } else {
        labels <- ramp
    }
    
    ## There will be 3 general columns: Left=ranges (may be hidden); Center=color blocks; Right=labels & values (4 sprintf-ed columns)
    ## Separating between blocks and annotations given by 'anngap'
    ## Careful when modifying; these are hard-wired config settings for an expected plot layout 
    anngap <- 0.1  # gap between color blocks and block names
    cgap <- "   "  # gap between sprintf-ed columns
    block.x <- 1:2
    annot.x <- block.x[2]+anngap
    range.x <- 1-3:1*anngap
    xlim <- c(1,ifelse(values,7,3))
    
    if (showranges) {
        if (length(ranges)-1 == length(ramp)) {
            ## expectedsituation
            range.labs <- ranges
        } else if (length(ranges)==2) {
            ## gave range start-end, apparently?  interpolate breaks.
            range.labs <- seq(ranges[1], ranges[2], length=N+1)
        } else {
            ## give up
            stop("Length of 'ranges' not conformable to length of 'ramp'!")
        }
        
        range.vec <- c("Ranges",ranges)
#        range.labs <- sprintf(paste("%-",max(nchar(range.vec)),"s",sep=""), range.vec)
        xlim[1] <- 0  # make room for ranges on left side
    }
    
    labs1 <- as.matrix(do.call(cbind, list(
        Labels=c("Labels",labels),
        Hex=c("Hex",rgb2(col2rgb(ramp))),
        RGB=c("RGB",apply(col2rgb(ramp),2,function(x) sprintf("%03d,%03d,%03d",x[1],x[2],x[3]))),
        HSV=c("HSV",apply(round(col2hsv(ramp),3),2,function(x) sprintf("%4.3f,%4.3f,%4.3f",x[1],x[2],x[3])))
    )))
    
    if (rgb.mcv) {
        labs1[,3] <- c("RGB (M,CV)",apply(col2rgb(ramp),2,function(x) sprintf("%03d,%03d,%03d (%03d,%3.2f)",x[1],x[2],x[3],round(mean(x),0),CV(x))))
        colnames(labs1)[3] <- "RGB (M,CV)"
    }
    
    labw <- sapply(1:ncol(labs1), function(i) max(nchar(c(names(labs1)[i],labs1[,i]))) )
    labs <- sapply(1:nrow(labs1), function(i){
        x <- labs1[i,]
        rampi <- i-1
        if (rampi>0) if (is.na(ramp[rampi])) x[2:4] <- NA  # because labs1[1,] is the header and labs1[2:nrow,] correspond to ramp
        if (values) {
            sprintf(paste0("%-",labw[1],"s",cgap,"%-",labw[2],"s",cgap,"%-",labw[3],"s",cgap,"%-",labw[4],"s"), x[1], x[2], x[3], x[4])
        } else {
            sprintf(paste0("%-",labw[1],"s"), x[1])
        }
    })
    label.headers <- labs[1]
    labs <- labs[2:length(labs)]
    
    ## Plot color blocks
    par(mar=c(1,0,ifelse(length(main)>0,3,1),0), family="mono", bg=bgcol, yaxs="i")
    null.plot(xlim=xlim, col.main=fontcol, cex.main=2)
    for (i in 1:N) {
        ternary(is.na(ramp[i]), dens <- 10, dens <- NULL)
        rect(block.x[1], breaks[i], block.x[1]+1, breaks[i+1], density=dens, col=ramp[i], border=FALSE)
    }
    
    ## Annotate plot
    if (length(main)>0) mtext(main, 3, 1.5, FALSE, mean(xlim), NA, NA, cex, 1, 2, las=1)  # surrogate plot 'main'
    mtext('Color', 3, 0, FALSE, mean(block.x), NA, NA, cex, fontcol, 2, las=1)            # color block column header
    mtext(label.headers, 3, 0, FALSE, annot.x, 0, NA, cex, fontcol, 2, las=1)             # annotations column header
    text(annot.x, label.y, adj=c(0,0.5), col=fontcol, labels=labs, cex=cex)               # annotations column labels & values
    
    if (showranges) {
        segments(range.x[3], breaks[1], range.x[3], breaks[N+1], col=fontcol)                                     # vertical tick baseline
        for (i in 1:(N+1)) segments(range.x[3], breaks[i], range.x[2], breaks[i], col=fontcol)                    # ticks
        text(range.x[1], breaks, adj=c(1,0.5), col=fontcol, labels=format(range.labs, digits=2), cex=cex, las=2)  # range labels
        text(range.x[1], col.header.y, adj=c(1,0.5), col=fontcol, labels="Ranges", cex=cex, font=2, las=2)        # ranges column header
    }
}


apa.names$graphics <- c(apa.names$graphics, "palettizer")
palettizer <- function (palette=NULL, n.colors=NA, interpolate=NULL, halves=NULL, reverse=FALSE) {
    
    ## Custom & RColorBrewer palette support for functions in apa_tools.R
    ## "n.colors=NA" returns the ramp function itself; othwerise the specified number of ramp colors
    ##  Note: the system color functions { rainbow heat.colors topo.colors terrain.colors } cannot be reversed until actualized as a palette.
    ## 'halves' is for working with centered color ranges, and returns 2 half-palettes instead of 1 full palette.  Arg value is length-2 vector with resolution depth for each half.
    
    if (!is.na(n.colors)) {
        if (n.colors > 512) {
            message("n.colors may not exceed 512!  Setting to 512.\n")
            n.colors <- 512
        }
    }
    interp <- function(default) ifelse(is.null(interpolate), default, interpolate)
    
    ## Define multiple-use colorsets here
    
    rb6 <- rev(c("red","orange","yellow","green","blue","purple3"))  #aka ROYGBP; basis for some other palettes below
    col17 <- c("deeppink2","magenta","red","red4","darkorange","yellow","gold3","chartreuse","green3","green4","cyan","darkcyan","dodgerblue","blue","purple3","sienna4","grey30")
   
    ## Define palettes here -- add new palettes to 'allramps' unless they require special construction, then add below
    
    rcb.reds <- c("#FFF5F0","#FEE0D2","#FCBBA1","#FC9272","#FB6A4A","#EF3B2C","#CB181D","#A50F15","#67000D")   # RColorBrewer "Reds"
    rcb.greens <- c("#F7FCF5","#E5F5E0","#C7E9C0","#A1D99B","#74C476","#41AB5D","#238B45","#006D2C","#00441B") # RColorBrewer "Greens"
    rcb.blues <- c("#F7FBFF","#DEEBF7","#C6DBEF","#9ECAE1","#6BAED6","#4292C6","#2171B5","#08519C","#08306B")  # RColorBrewer "Blues"
    
    ## Default palette set in 'allramps' declaration; built with every call.
    ## Additional palettes defined below that, but not built/loaded unless called for.
    ## Each element in 'allramps' is c(color scheme, default interpolation, palette type, description)
    
    allramps <- list(
        
        ## Sequential Palettes
        BY=list(c("blue","yellow"), interp("linear"), "seq", "Blue Yellow"),
        KBY=list(c("black","blue","yellow"), interp("linear"), "seq", "Black Blue Yellow"),
        KPBY=list(c("black","purple3","blue","yellow"), interp("linear"), "seq", "Black Purple Blue Yellow"),
        KPBG=list(c("black","purple3","blue","green"), interp("linear"), "seq", "Black Purple Blue Green"),
        BCGY=list(c("blue","cyan","green","yellow"), interp("linear"), "seq", "Blue Cyan Green Yellow"),
        RYG=list(c("red","yellow","green"), interp("spline"), "seq", "Red Yellow Green"),
        ROYGC=list(c("red","darkorange","yellow","green","cyan"), interp("spline"), "seq", "Red Yellow Green Cyan"),
        RGB=list(c("red","green","blue"), interp("spline"), "seq", "Red Green Blue"),
        KW=list(c("white","black"), interp("linear"), "seq", "Black White"),
        rainblo=list(rb6, interp("spline"), "seq", "ROYGBP"),
        rainblo.k=list(c("black",rb6), interp("spline"), "seq", "ROYGBP Black"),
        
        ## Sequential System Palettes & Their Derivatives
        grey=list(grey.colors(2), interp("linear"), "seq", "system"),
        gray=list(gray.colors(2), interp("linear"), "seq", "system"),
        rainbow=list(rainbow, "", "seq", "system"),
        topo=list(topo.colors, "", "seq", "system"),
        terrain=list(terrain.colors, "", "seq", "system"),
        terrain.plus=list(c("blue",terrain.colors(7),"white"), interp("linear"), "seq", "Blue [terrain.colors] White"),
        heat=list(heat.colors, "", "seq", "system"),
        heat.plus=list(c(heat.colors(5),"lemonchiffon","white"), interp("linear"), "seq", "[heat.colors] Lemonchiffon White"),
        
        ## Modified Sequential RColorBrewer Palettes
        Reds0=list(c("white",rcb.reds), interp("linear"), "seq", "RColorBrewer 'Reds', terminates in white"),
        Greens0=list(c("white",rcb.greens), interp("linear"), "seq", "RColorBrewer 'Greens', terminates in white"),
        Blues0=list(c("white",rcb.blues), interp("linear"), "seq", "RColorBrewer 'Blues', terminates in white"),
        
        ## Diverging Palettes
        cm=list(cm.colors, "", "div", "system"),							# system palette
        cm2=list(cm.colors(3), interp("linear"), "div", "system, but with linear interpolation"),
        CKY=list(c("cyan","black","yellow"), interp("spline"), "div", "Cyan Black Yellow"),
        CWY=list(c("cyan","white","yellow"), interp("spline"), "div", "Cyan White Yellow"),
        RKG=list(c("green3","black","red"), interp("spline"), "div", "Red Black Green"),
        RWG=list(c("green3","white","red"), interp("spline"), "div", "Red White Green"),
        RKB=list(c("blue","black","red"), interp("spline"), "div", "Red Black Blue"),
        RWB=list(c("blue","white","red"), interp("spline"), "div", "Red White Blue"),
        VKA=list(c("gold","black","magenta2"), interp("spline"), "div", "Violet Black Amber"),
        VWA=list(c("gold","white","magenta2"), interp("spline"), "div", "Violet White Amber"),
        GCWYR=list(c("green",5,"white",7,2), interp("linear"), "div", "Green Cyan White Yellow Red"),
        
        ## Definitions for various user-requested odds and ends
        ROYGm=list(c("firebrick3","darkorange","gold","forestgreen"), interp("spline"), "seq", "Red Orange Yellow Green (muted)"),
        heatm=list(c("firebrick3","darkorange","gold","white"), interp("linear"), "seq", "[heat.colors]-ish muted, fade to white"),
        heatb1=list(c("firebrick3","darkorange","gold","black"), interp("linear"), "seq", "[heat.colors]-ish muted, fade to black"),
        heatb2=list(c("firebrick3","darkorange","gold","forestgreen","black"), interp("linear"), "seq", "[heat.colors]-ish muted, fade to green, black"),
        
        ## Categorical Palettes
        super18=list(c(rb6, hsv.tweak(rb6,s=-0.6), hsv.tweak(rb6,v=-0.6)), "", "cat", "18 colors: {bright ROYGBP} + {pale ROYGBP} + {dark ROYGBP}"),
        super34=list(c(col17, hsv.tweak(col17,s=-0.5,v=-0.1)), "", "cat", "34 colors: {col-17} + {greyed col-17}")
        
    )
    
    ## Palettes with special handling go here
    
    if (length(palette) == 0) {

        pnames <- names(allramps)
        types <- unlist(slice.list(allramps,3))
        descs <- unlist(slice.list(allramps,4))
        fmt <- paste0(" %-",max(nchar(c(pnames,"Aparna.Reds","blackbody.2","blackbody.10"))),"s   %s")
        
        message(paste(c(
            "\nNo name or value for 'palette' given!\nAvailable built-in palette names:",
            "\n Sequential:",
            sapply(which(types=="seq"), function(i) sprintf(fmt, pnames[i], descs[i]) ),
            sprintf(fmt, "Aparna.Reds", "RColorBrewer 'Reds', blued up slightly"),
            sprintf(fmt, "blackbody.2", "CIE 1931 2-degree CMFs w/ Judd-Voss Corrections"),
            sprintf(fmt, "blackbody.10", "CIE 1964 10-degree CMFs"),
            "\n Diverging:",
            sapply(which(types=="div"), function(i) sprintf(fmt, pnames[i], descs[i]) ),
            "\n Categorical:",
            sapply(which(types=="cat"), function(i) sprintf(fmt, pnames[i], descs[i]) ),
            "\n And all RColorBrewer palette names\n"
        ),collapse="\n"))
        return()
        
    } else {
        
        ## 'Aparna.Reds' -- only create if invoked
        ## A slightly blued-up version of RColorBrewer's "Reds"; more cherry-red than blood-red
        if (palette[1] == "Aparna.Reds") {
            if (!require("RColorBrewer")) stop("Palette 'Aparna.Reds' requires the RColorBrewer library, but it couldn't be loaded.\n")
            RCB.Reds <- colorRampPalette( brewer.pal(brewer.pal.info[match("Reds",rownames(brewer.pal.info)),1],"Reds"), interp("spline") )
            Aparna.Reds <- col2rgb(RCB.Reds(256))
            Aparna.Reds[2,] <- round(Aparna.Reds[2,]-10,0)  # reduce green
            Aparna.Reds[3,] <- round(Aparna.Reds[3,]+10,0)  # boost blue
            Aparna.Reds[Aparna.Reds<0] <- 0
            Aparna.Reds[Aparna.Reds>255] <- 255
            allramps$Aparna.Reds=list(c("white",rgb(t(Aparna.Reds)/255)), interp("linear"), "seq", "RColorBrewer 'Reds', blued up slightly")
        }
        
        ## 'Blackbody.*' -- only load (from file) if invoked
        if (grepl("^blackbody",palette[1])) {
            if (!exists("blackbody.colors")) {
                ## blackbody radiation colors, taken from tables at http://www.vendian.org/mncharity/dir3/blackbody/UnstableURLs/bbr_color.html
                temp <- read.delim(paste(data.path,"blackbody_colors.txt",sep="/"), sep="\t", as.is=TRUE, skip=1)
                #####  GLOBAL ASSIGN  !!!!!
                blackbody.colors <<- list(CIE2deg=temp[temp[,2]=="1931 2 deg",c(1,3)], CIE10deg=temp[temp[,2]=="1964 10 deg",c(1,3)])
                #####  GLOBAL ASSIGN !!!!!
                apa.names$data <<- unique(c(apa.names$data,"blackbody.colors"))
            }
            ## blackbody radation colors, CIE 1931 2-degree CMFs w/ Judd-Voss Corrections
            allramps$blackbody.2 <- list(blackbody.colors$CIE2deg[,2], interp("linear"), "seq", "CIE 1931 2-degree CMFs w/ Judd-Voss Corrections")
            ## blackbody radation colors, CIE 1964 10-degree CMFs
            allramps$blackbody.10 <- list(blackbody.colors$CIE10deg[,2], interp("linear"), "seq", "CIE 1964 10-degree CMFs")
        }
        
        if (length(palette) > 1) {
            
            ## Custom palette vector, NOT a name
            
            ColorRamp <- 
                if (reverse) { 
                    colorRampPalette(rev(palette), interpolate=interp("linear"))
                } else {
                    colorRampPalette(palette, interpolate=interp("linear"))
                }
            ## assume diverging if odd num colors.  At least, can treat as diverging.
            paltype <- ifelse(length(palette) %% 1 == 0, 'div', 'seq')
            
        } else {
            
            ## Named palette
            
            oknames <- paste(names(allramps), collapse="', '")
            diemsg <- paste("Palette name must be one of:\n '",oknames,"'\n Also supports RColorBrewer palette names, if library is loaded.\n",sep="")
            
            if (!is.character(palette)) { 
                
                ## what?
                stop(diemsg) 
                
            } else if (palette %in% names(allramps)) {
                
                ## Palette name found in 'allramps'
                ramp <- allramps[[palette]]
                if (is.function(ramp[[1]])) {
                    ## system palette functions
                    ColorRamp <- ramp[[1]]
                    paltype <- 'func'
                } else if (ramp[[3]] == "cat") {
                    if (length(ramp[[1]]) < n.colors) stop(paste0("Requested colors (",n.colors,") exceeds categorical Palette '",palette,"' maximum (",length(ramp[[1]]),")!"))
                    ColorRamp <- ramp[[1]]
                    paltype <- ramp[[3]]
                } else {
                    ## color vectors to convert into functions
                    ColorRamp <- 
                        if (reverse) { 
                            colorRampPalette(rev(ramp[[1]]), interpolate=ramp[[2]])
                        } else {
                            colorRampPalette(ramp[[1]], interpolate=ramp[[2]])
                        }
                    paltype <- ramp[[3]]
                }
                
            } else {
                
                ## Palette name not found; check RColorBrewer
                if (require("RColorBrewer")) {
                    RCB.ok <- match(palette, rownames(brewer.pal.info))
                    if (is.na(RCB.ok)) {
                        ## RColorBrewer loaded, but does not contain your palette
                        stop(diemsg)
                    } else {
                        ## RColorBrewer loaded and your palette was found
                        rcb.ncol <- brewer.pal.info[RCB.ok,1]
                        paltype <- as.character(brewer.pal.info[RCB.ok,2])
                        if (paltype == "qual") {
                            if (rcb.ncol < n.colors) stop(paste0("Requested colors (",n.colors,") exceeds categorical RColorBrewer palette '",palette,"' maximum (",rcb.ncol,")!"))
                            ColorRamp <- brewer.pal(rcb.ncol,palette)
                            paltype <- "cat"
                        } else {
                            ## OK palette to convert
                            ColorRamp <- 
                                if (reverse) {
                                    colorRampPalette( rev(brewer.pal(rcb.ncol,palette)), interpolate=interp("spline") )
                                } else {
                                    colorRampPalette( brewer.pal(rcb.ncol,palette), interpolate=interp("spline") ) 
                                }
                        }
                    }
                } else {
                    stop("Unknown palette name, and couldn't check RColorBrewer because library couldn't be loaded.\n")
                }
                
            }
        }
    }
    
    if (length(halves)==2) {
        
        ## Usually used for divergent palette, centered at zero, but applied to imbalanced data range.  Create two half-palette functions.
        
        if (paltype != "div") stop("Halves are only returned for diverging palettes!\n")
        realized <- ColorRamp(257)  # always realize at maximum resolution (> max because we need an odd number)
        half.ramps <- list( LOWER=colorRampPalette(realized[1:128]), CENTER=colorRampPalette(realized[129]), UPPER=colorRampPalette(realized[130:257]) )  # midpoint color MUST BE SEPARATE
        if (is.na(n.colors)) {
            half.ramps
        } else {
            list( LOWER=half.ramps$LOWER(halves[1]), CENTER=half.ramps$CENTER(1), UPPER=half.ramps$UPPER(halves[2]) )
        }
        
    } else if (length(halves)==2) {
        
        stop("'halves' value must be an integer vector of length 2!\n")
        
    } else {
        
        ## Normal palette handling
        
        if (is.na(n.colors)) {
            ColorRamp
        } else if (paltype == 'func') {
            ## if actualizing a system color function, we can reverse it here
            ternary(reverse, rev(ColorRamp(n.colors)), ColorRamp(n.colors))
        } else if (paltype == "cat") {
            ## categorical palettes are not interpolated
            ColorRamp[1:n.colors]
        } else {
            ColorRamp(n.colors)
        }
    }
}


apa.names$graphics <- c(apa.names$graphics, "mask.palette")
mask.palette <- function (base.col="grey50", levels=2, alpha.min=0, alpha.max=0.75) {
    
    ## Creates a transparency palette for masking myImagePlotUltra, heat.map, etc (using image(add=T))
    
    ColorRamp <- colorRampPalette(c(base.col,"white"), interpolate="linear")
    amin.255 <- round(255 * alpha.min, 0)
    amax.255 <- round(255 * alpha.max, 0)
    alpha.grad <- as.hexmode(seq(amax.255, amin.255,length.out=levels)[1:(levels-1)])
    ramp <- ColorRamp(levels)
    ramp[levels] <- amin.255
    ramp[1:(levels-1)] <- paste(ramp[1:(levels-1)], alpha.grad, sep="")
    return(ramp)
}


apa.names$graphics <- c(apa.names$graphics, "rgb2")
rgb2 <- function(x, pct=FALSE) {
    
    ## Modified rgb() function designed to handle col2rgb() output directly, instead of in pieces; also single vectors.
    ## Example: Create an RGB matrix with col2rgb(), then try to convert back using rgb() on the matrix.
    ##          Doesn't work!  Must input 3-4 rows separately: rgb2() fixes this.
    ## 		Also cannot process atomic vectors with rgb(): rgb2() fixes this.
    ## x = 1. a 3-4 component vector as c(R,G,B) or c(R,G,B,alpha), or 
    ##     2. a 3-4 row matrix, e.g. col2rgb() output or something like it (rows 1,2,3 = R,G,B; 1 col per color; optional row 4 = alpha).
    ## pct = T/F: either 'x' has integers on [0,255] and "pct=F", or 'x' has decimals on [0,1] with "pct=T"
    
    if (!pct) {
        if (any(zapsmall(x)!=trunc(x))) {
            stop("Non-integer 'x' detected, but 'pct' is FALSE.  Stopping.")
        } else if (max(x) <= 1 & !all(c(x)==0)) {
            warning("Input values are on [0,1], but 'pct' is FALSE: are you sure?\n", call. = TRUE, immediate. = TRUE)
        }
        x <- x / 255	# normalize to [0,1]; rgb() assumes maxColorValue==1
    }
    if (is.null(dim(x))) {
        if (length(x) == 4) {		# alpha-containing vector
            rgb(x[1],x[2],x[3],alpha=x[4])
        } else if (length(x) == 3) {	# plain RGB vector
            rgb(x[1],x[2],x[3])
        } else {
            stop("Input vector was not of length 3 or 4!\n")
        }
    } else {
        if (nrow(x) == 4) {		# alpha-containing matrix
            apply(x, 2, FUN=function(v) rgb(v[1],v[2],v[3],alpha=v[4]) )
        } else if (nrow(x) == 3) {	# plain RGB matrix
            apply(x, 2, FUN=function(v) rgb(v[1],v[2],v[3]) )
        } else {
            stop("Input matrix was not of dimension 3xN or 4xN!\n")
        }
    }
}


apa.names$graphics <- c(apa.names$graphics, "hsv2")
hsv2 <- function(x) {
    
    ## Modified hsv() function designed to handle rgb2hsv() output directly, instead of in pieces; also single vectors.
    ## Example: Create an HSV matrix with rgb2hsv(), then try to convert back using hsv() on the matrix.
    ##          Doesn't work!  Must input 3-4 rows separately.  hsv2() fixes this.
    ## 		Also cannot process atomic vectors with hsv().  hsv2() fixes this.
    ## x = 1. a 3-4 component vector as c(H,S,V) or c(H,S,V,alpha), or 
    ##     2. a 3-4 row matrix, e.g. rgb2hsv() output or something like it (rows 1,2,3 = H,S,V; 1 col per color; optional row 4 = alpha).
    
    if (is.null(dim(x))) {
        if (length(x) == 4) {		# alpha-containing vector
            hsv(x[1], x[2], x[3], alpha=x[4])
        } else if (length(x) == 3) {	# plain HSV vector
            hsv(x[1], x[2], x[3]) 
        } else {			# what?
            stop("Input vector was not of length 3 or 4!\n")
        }
    } else {
        if (nrow(x) %in% 3:4) {
            apply(x, 2, hsv2)
        } else {
            stop("Input matrix was not of dimension 3xN or 4xN!\n")
        }
    }
}


apa.names$graphics <- c(apa.names$graphics, "rgb2hsv2")
rgb2hsv2 <- function(x, maxColorValue=255) { 
    
    ## Standard rgb2hsv doesn't support 4-channel (alpha-specified) RGB values, but rgb2hsv2 does.
    ## x = 1. a 4-component vector as c(R,G,B,alpha), or 
    ##     2. a 4 row matrix, e.g. col2rgb(X, alpha=T) output or something like it (rows 1,2,3,4 = R,G,B,alpha; 1 col per color).
    ## gamma = pass-in to rgb2hsv() call; see ?rgb2hsv.
    ## maxColorValue = pass-in to rgb2hsv() call; see ?rgb2hsv.
    
    if (is.null(dim(x))) {
        if (length(x) %in% 3:4) {
            result <- rbind(rgb2hsv(x[1], x[2], x[3]))
            if (length(x) == 4) result <- rbind(result, alpha=x[4]/maxColorValue)
        } else {
            stop("Input vector was not of length 3 or 4!\n")
        }
    } else {
        if (nrow(x) %in% 3:4) {
            result <- rgb2hsv(x[1:3,])
            if (nrow(x) == 4) result <- rbind(result, alpha=x[4,]/maxColorValue)
        } else {
            stop("Input matrix was not of dimension 3xN or 4xN!\n")
        }
    }
    result 
}


apa.names$graphics <- c(apa.names$graphics, "col2hsv")
col2hsv <- function(x, alpha=FALSE) { 
    
    ## Because base R apparently didn't think of that.
    ## Works as col2rgb()
    
    rgb2hsv2(col2rgb(x,alpha=alpha))
}


apa.names$graphics <- c(apa.names$graphics, "hsv2rgb")
hsv2rgb <- function(h, s=NULL, v=NULL, alpha=NULL) { 
    
    ## No standard HSV -> RGB conversion function in R.  This saves a few steps.  Handles vector, matrix, or h,s,v (separate) inputs.
    ## h = 1. hue value on [0,1], or
    ##     2. a 3-4 component vector as c(H,S,V) or c(H,S,V,alpha), or 
    ##     3. a 3-4 row matrix, e.g. rgb2hsv() output or something like it (rows 1,2,3 = H,S,V; 1 col per color; optional row 4 = alpha).
    ## s = saturation value on [0,1].
    ## v = value value on [0,1].
    ## alpha = transparency value on [0,1].  *** IGNORED if h is an object with existing alpha components
    
    use.alpha <- FALSE
    if (is.null(s) & is.null(v)) {
        if (is.null(dim(h))) {
            if (length(h) == 4) {		# alpha-containing vector
                x <- h
                use.alpha <- TRUE
            } else if (length(h) == 3) {	# plain HSV vector
                use.alpha <- !is.null(alpha)
                x <- if (use.alpha) { h } else { c(h,alpha) }
            } else {				# what?
                stop("Input vector was not of length 3 or 4!\n")
            }
        } else {
            if (nrow(h) == 4) {			# alpha-containing matrix
                x <- h
                use.alpha <- TRUE
            } else if (nrow(h) == 3) {	# plain HSV matrix
                use.alpha <- !is.null(alpha)
                x <- if (use.alpha) { h } else { rbind(h,rep(alpha,ncol(h))) }
            } else {					# what?
                stop("Input matrix was not of dimension 3xN or 4xN!\n")
            }
        }
    } else {
        if (s < 0) {
            stop(paste("Invalid s value",s,"!\n"))
        } else if (v < 0) {
            stop(paste("Invalid v value",v,"!\n"))
        } else {
            use.alpha <- !is.null(alpha)
            x <- if(use.alpha) { c(h,s,v) } else { c(h,s,v,alpha) }
        }
    }
    col2rgb(hsv2(x), alpha=use.alpha)
    
} 


apa.names$graphics <- c(apa.names$graphics, "hsv.tweak")
hsv.tweak <- function(colors, s.adj=0, v.adj=0, a.adj=0) {
    
    ## Shortcut function to adjust saturation, value, and alpha (opacity) values for colors not in HSV format.
    ## 'colors' is a vector of names, numbered, or hex colors
    ## 's.adj','v.adj','a.adj' are adjustments to saturation, value, alpha respectively.
    ##   adjustment values must be on [0,1] and are added (thus if negative, get subtracted).
    ##   if adjustments result in values outside [0,1], these are re-adjusted to be 0 or 1.
    
    if (!is.atomic(colors)) { stop("'colors' must be an atomic vector!\n") }
    
    alphas <- rep(0,length(colors))
    is.hex <- grepl("^#",colors)
    if (any(is.hex)) alphas[is.hex] <- strtoi(sapply(colors[is.hex],substr,8,9),base=16)/255
    any.alphas <- any(alphas!=0)
    alphas[alphas==0]  <- 1
    
    adjusted <- rgb2hsv(col2rgb(colors))
    adjusted[2,] <- adjusted[2,] + s.adj
    adjusted[3,] <- adjusted[3,] + v.adj
    if (any.alphas | a.adj != 0) {
        adjusted <- rbind(adjusted, alphas)
        adjusted[4,] <- adjusted[4,] + a.adj
    }
    adjusted[adjusted < 0] <- 0
    adjusted[adjusted > 1] <- 1
    out <- hsv2(adjusted)
    out[is.na(colors)] <- NA
    out
}


apa.names$graphics <- c(apa.names$graphics, "hsv.spectrum")
hsv.spectrum <- function(h=c(0,1), s=c(0,1), v=c(0,1), rotate=0, gradient=100) {
    
    ## Generates annotated HSV color maps.
    ## h = hue, single number or c(min,max).  Values on [0,1].
    ## s = saturation, single number or c(min,max).  Values on [0,1].
    ## v = value, single number or c(min,max).  Values on [0,1].
    ## overlap = T/F: cause s and v gradients to overlap?  
    ##           "F" creates a diverging map with s,v maxima in the middle and minima at the edges.
    ##           overlap is set to "F" internally if s or v are single-valued, for obvious reasons.
    ## rotate = shift spectrum by this many degrees (degrees > 0 = shift right, degrees < 0 = shift left).
    
    h <- zapsmall(h)
    s <- zapsmall(s)
    v <- zapsmall(v)
    if (length(h)==1) h <- c(h,h)
    if (length(s)==1) s <- c(s,s)
    if (length(v)==1) v <- c(v,v)
    overlap <- s[1]==s[2] | v[1]==v[2]
    nxlabs <- 10  # ALWAYS 10 AXIS LABELS
    
    xgradient <- gradient  # N hue columns
    xaxdif <- diff(1:xgradient)[1]/2
    xbound <- cbind(c(1:xgradient)-xaxdif, c(1:xgradient)+xaxdif)
    xaxpos <- seq(1, xgradient, length.out=nxlabs)
    
    yrows <- ifelse(!overlap & gradient%%2==0, gradient+1, gradient)
    ygradient <- ifelse(overlap, yrows, trunc(yrows/2))
    yaxdif <- diff(1:yrows)[1]/2
    ybound <- cbind(c(1:yrows)-yaxdif, c(1:yrows)+yaxdif)
    
    if (h[1]>h[2]) {  # wraps around red
        neg <- 1 - h[1]
        hues <-        seq(0, h[2]+neg, length.out=xgradient)
        xlab <- signif(seq(0, h[2]+neg, length.out=nxlabs   ),3)
        hues <- hues - neg
        xlab <- xlab - neg
        h0 <- which(hues>=0)[1]  # MUST TEST HERE: first hues value after (or exactly on) 0/1 boundary
        hues[hues<0] <- hues[hues<0] + 1
        xlab[xlab<0] <- xlab[xlab<0] + 1
        hues[hues==1] <- 0
        xlab[xlab==1] <- 0
        if (hues[h0]==0) {
            vline <- h0
        } else {
            vline <- h0 - hues[h0] / diff(hues[h0:(h0+1)])
        }
    } else {
        hues <- seq(h[1], h[2], length.out=xgradient)
        xlab <- signif(seq(h[1], h[2], length.out=nxlabs),3)
        vline <- NULL
    }

    interval <- trunc(360/xgradient)
    even <- ifelse(rotate%%interval==0, TRUE, FALSE)
    shift <- trunc(xgradient*rotate/360)
    if (shift<0) shift <- xgradient+shift
    if (shift>0) {	# cannot be < 0 at this point
        shift <- gradient - shift
        rotated <- c(shift:gradient,1:(shift-1))
        hues <- hues[rotated]
    }
    
    if (overlap) {
        sats  <- signif(seq(s[1], s[2], length.out=gradient), 3)
        vals  <- signif(seq(v[1], v[2], length.out=gradient), 3)
        slabs <- signif(seq(s[1], s[2], length.out=nxlabs), 3)
        vlabs <- signif(seq(v[1], v[2], length.out=nxlabs), 3)
        nylabs <- nxlabs
    } else {
        if (gradient %% 2 == 0) gradient <- gradient + 1  # MUST BE ODD
        gradient1 <- gradient - 1
        halfgr <- zapsmall((gradient1 / 2) + 1)
        halfnl <- nxlabs / 2
        sats  <- signif(c(seq(s[1], s[2], length.out=halfgr), rep(1,halfgr-1)), 3)
        vals  <- signif(c(rep(1,halfgr-1), seq(v[2], v[1], length.out=halfgr)), 3)
        slabs <- signif(c(seq(s[1], s[2], length.out=halfnl+1), rep(1, halfnl)), 3)
        vlabs <- signif(c(rep(1, halfnl), seq(v[2], v[1], length.out=halfnl+1)), 3)
        nylabs <- nxlabs+1
    }
    yaxpos <- seq(1, yrows, length.out=nylabs)
    
    fmt <- paste0("%-",max(nchar(sats)),"s  %-",max(nchar(vals)),"s")
    ylabs <- sprintf(fmt, format(slabs), format(vlabs))
    yhead <- c(rep("", length(ylabs)), sprintf(fmt,"Sat","Val"))
    
    cellcol <- matrix(NA, yrows, xgradient)
    for (i in 1:xgradient) cellcol[,i] <- hsv2(rbind(hues[i],sats,vals))
    cellcol <- cellcol[nrow(cellcol):1,]  # otherwise prints upside down
    
    par(mar=c(5,8,3,1), las=1, cex=1.2, family="mono")
    plot(1, 1, pch="", xlim=range(xbound), ylim=range(ybound), axes=FALSE, ylab="", xlab="", font.lab=2, main="HSV Spectrum")
    axis(1, xaxpos, format(xlab), font=2, las=2)
    axis(2, yaxpos, rev(ylabs), font=2)
    mtext("Hue", 1, 1, FALSE, min(xaxpos)-diff(xaxpos)[1]*0.75, NA, 1, 1.2, 1, 2, las=2)
    mtext(yhead, 2, 1, FALSE, max(yaxpos)+diff(yaxpos)[1]*0.75, NA, 1, 1.2, 1, 2, las=2)
    for (i in 1:nrow(cellcol)) for (j in 1:ncol(cellcol)) rect(xbound[j,1],ybound[i,1], xbound[j,2],ybound[i,2], col=cellcol[i,j], border=NA)
    if (length(vline)>0) abline(v=vline, lty=3)
}


apa.names$graphics <- c(apa.names$graphics, "nearest.named.color")
nearest.named.color <- function(x, color=c("hex","rgb","hsv"), space=c("rgb","hsv"), nearest=TRUE) {
    
    ## takes a color in hex, rgb, or hsv and find the closes R-base-named color to it.
    ## color may contain alpha channel, but it will be ignored
    ## 'color' indicates incoming value of color 'x'
    ## 'space' indicates to calculate distance in rgb or hsv colorspace
    ## 'nearest=TRUE' returns only nearest color(s).
    ## 'nearest=FALSE' returns entire named distance vector.
    
    color <- match.arg(color)
    space <- match.arg(space)
    xrgb <- switch( color, hex=col2rgb(x), rgb=x, hsv=hsv2rgb(c(x)) )
    
    if (space == "rgb") {
        d <- as.matrix(dist(rbind(c(xrgb), t(sapply(colors(), col2rgb)))))
    } else if (space == "hsv") {
        xhsv <- rgb2hsv(xrgb)
        d <- as.matrix(dist(rbind(c(xhsv), t(sapply(colors(), function(y) rgb2hsv(col2rgb(y)) )))))
    }
    
    d <- zapsmall(d[2:nrow(d),1])
    if (nearest) {
        d[d==min(d)]
    } else {
        d
    }
    
}


apa.names$graphics <- c(apa.names$graphics, "colorNeighborhood")
colorNeighborhood <- function(col=NULL, h=c(0,1), s=c(0,1), v=c(0,1), sort=NULL, neutrals=TRUE) {
    
    ## Displays named R colors within predefined HSV ranges.
    ## "col=<colorname>" overrides h,s,v entries.
    ## "sort" can be "h", "s", or "v"; visual sort order by HSV values.
    ## "neutrals=F" eliminates all proper neutrals (but not necessarily the output category).
    
    IM("0")
    if (length(h) != 2) stop("'h' must be a vector of length 2!\n")
    if (length(s) != 2) stop("'s' must be a vector of length 2!\n")
    if (length(v) != 2) stop("'v' must be a vector of length 2!\n")
    ## sat.lim, val.lim define cutoffs below which a color is "pale" or "dark", respectively.
    sat.lim <- 0.5
    val.lim <- 0.6
    val.med <- 0.81
    sat.lo <- 0.2
    wht.lim <- 0.2
    sorts <- list(h=1, s=2, v=3)
    allcolors.rgb <- col2rgb(colors())
    allcolors <- rgb2hsv(allcolors.rgb)
    all.neutrals <- which(colSDs(allcolors.rgb) == 0)
    near.neutrals <- setdiff(which(colCVs(allcolors.rgb) <= 0.05), all.neutrals)
    gray.block <- c(153:253)
    gray.blocks <- c(gray.block,261:361)
    if (!is.null(col)) {
        match.arg(col, c("red","orange","yellow","green","cyan","blue","purple","violet","magenta","brown","white","grey","gray"))
        s <- v <- c(0,1)
        
        if (col == "grey" | col == "gray") {	# special case
            w <- c()
        } else if (col == "white") {
            h <- c(0,1)
            s <- c(0,0.1)
            v <- c(0.9,1)
        } else {
            h <- switch(
                col, 
                "red"=c(0.95,0.05),
                "orange"=c(0.05,0.11),
                "yellow"=c(0.11,0.2),
                "green"=c(0.2,0.45),
                "cyan"=c(0.45,0.55),
                "blue"=c(0.55,0.72),
                "purple"=,
                "violet"=c(0.72,0.87),
                "magenta"=c(0.83,0.94),
                "brown"=c(0.05,0.15)
            )
        }
    } else {
        col <- ""	# dummy value
    }
    
    hues <- sats <- vals <- vector("list", length=2)
    hues[[1]] <- h; sats[[1]] <- s; vals[[1]] <- v
    if (h[2] < h[1]) {		# break across 0/1
        hues[[1]] <- c(h[1], 1)
        hues[[2]] <- c(0, h[2])
    }
    
#	Later will support 0/1-split s, v ranges
#	if (s[2] < s[1]) {
#		sats[[1]] <- c(s[1], 1)
#		sats[[2]] <- c(0, s[2])
#	}
#	if (v[2] < v[1]) {
#		vals[[1]] <- c(v[1], 1)
#		vals[[2]] <- c(0, v[2])
#	}
    
    matches <- list(Neutral=c(),Dim=c(),Pale=c(),Light=c(),Bright=c(),Medium=c(),Dark=c())
    
    for (i in 1:length(hues)) {
        if (col != "grey" & col != "gray") {	# grey colors skip this
            x <- which(allcolors[1,] >= hues[[i]][1] & allcolors[1,] <= hues[[i]][2])
            x <- setdiff(x, gray.blocks)	# remove giant grey/gray blocks
            if (!neutrals) { x <- setdiff(x, all.neutrals) }	# remove all neutrals, period.
            y <- x[which(allcolors[2,x] >= s[1] & allcolors[2,x] <= s[2])]
            z <- x[which(allcolors[3,x] >= v[1] & allcolors[3,x] <= v[2])]
            w <- intersect(y,z)
        }
        lslmv <- w[which(allcolors[2,w] < sat.lim & allcolors[3,w] < val.med)]
        greys <- lslmv[which(allcolors[2,lslmv] <= sat.lo)]
        dims <- setdiff(lslmv, greys)
        lshv <- w[which(allcolors[2,w] < sat.lim & allcolors[3,w] >= val.med)]
        hslv <- w[which(allcolors[2,w] >= sat.lim & allcolors[3,w] < val.lim)]
        hsmv <- w[which(allcolors[2,w] >= sat.lim & allcolors[3,w] >= val.lim & allcolors[3,w] < val.med)]
        hshv <- w[which(allcolors[2,w] >= sat.lim & allcolors[3,w] >= val.med)]
        pale <- lshv[which(abs(allcolors[2,lshv]-1+allcolors[3,lshv]) <= wht.lim)]
        lshv <- setdiff(lshv, pale)
        matches$Neutral <- c(matches$Neutral, greys)
        matches$Dim <- c(matches$Dim, dims)
        matches$Pale <- c(matches$Pale, pale)
        matches$Light <- c(matches$Light, lshv)
        matches$Bright <- c(matches$Bright, hshv)
        matches$Medium <- c(matches$Medium, hsmv)
        matches$Dark <- c(matches$Dark, hslv)
    }
    
    if (col == "brown") {	# eliminate too-strong colors
        pre <- unlist(matches[3:6])	# Pale, Light, Bright, Medium
        drop1 <- pre[which(allcolors[2,pre] > 0.85 & allcolors[3,pre] > 0.85)]
        drop2 <- pre[which(allcolors[2,pre] <= 0.2 & allcolors[3,pre] > 0.99)]
        drop3 <- pre[which(allcolors[2,pre] > 0.4 & allcolors[3,pre] > 0.93)]
        drop.34 <- c(drop2, drop3)
        drop.56 <- c(drop1)
        for (i in 3:4) { matches[[i]] <- setdiff(matches[[i]], drop.34) }
        for (i in 5:6) { matches[[i]] <- setdiff(matches[[i]], drop.56) }
        if (is.null(sort)) { sort13 <- "v"; sort47 <- "s" }
    } else {
        if (is.null(sort)) { sort13 <- "v"; sort47 <- "h" }
    }
    
    matches$Neutral <- matches$Neutral[order(allcolors[sorts[[sort13]],matches$Neutral])]
    matches$Dim <- matches$Dim[order(allcolors[sorts[[sort13]],matches$Dim])]
    matches$Pale <- matches$Pale[order(allcolors[sorts[[sort13]],matches$Pale])]
    matches$Light <- matches$Light[order(allcolors[sorts[[sort47]],matches$Light])]
    matches$Bright <- matches$Bright[order(allcolors[sorts[[sort47]],matches$Bright])]
    matches$Medium <- matches$Medium[order(allcolors[sorts[[sort47]],matches$Medium])]
    matches$Dark <- matches$Dark[order(allcolors[sorts[[sort47]],matches$Dark])]
    
    message(paste(length(unlist(matches)),"colors found.\n"))
    ok <- which(listLengths(matches) > 0)
    if (length(ok) > 0) {
        par(mfrow=c(1,length(ok)), mar=c(1,1,2,6), las=2)
        for (i in ok) { 
            x <- matches[[i]]
            y <- t(as.matrix(length(x):1))
            image(y, col=colors()[x], main=names(matches)[i], axes=FALSE) 
            axis(4, col=0, tick=FALSE, line=-0.8, cex=0.9, at=seq(0,1,length.out=length(x)), labels=colors()[x[length(x):1]], las=2)
        }
        invisible(matches)
    } else {
        stop("No colors found in that range!\n")
    }
}


apa.names$graphics <- c(apa.names$graphics, "colorNeighborhood2")
colorNeighborhood2 <- function(color=NULL, hues=c(0,1), sats=c(0,1), vals=c(0,1), sort=NULL, cex=1, pmar=0) {

    ## UNDER CONSTRUCTION -- see /n/projects/apa/R/hsv_explore.R for dev work
    ## Improved colorNeighborhood, also with neutral color support.
    ## Displays named R colors within predefined HSV ranges.
    ## "color=<colorname>" overrides hues/sats/vals entries.
    ## "sort" can be "h", "s", or "v"; visual sort order by HSV values.
    
    if (is.null(color)) color <- ""
    neutral.names <- c("white","black","grey","gray","true-neutral")
    color.names <- c("red","orange","yellow","green","cyan","blue","purple","violet","magenta","brown")
    match.arg(color, c("",color.names,neutral.names))
    
    if (length(hues) != 2) stop("'hues' must be c(min,max)!\n")
    if (length(sats) != 2) stop("'sats' must be c(min,max)!\n")
    if (length(vals) != 2) stop("'vals' must be c(min,max)!\n")
    
    ## named-color stats
    all.col <- colors()
    all.rgb <- col2rgb(all.col)
    all.hsv <- rgb2hsv(all.rgb)
    all.cv <- zerofy(colCVs(all.rgb))
    all.mn <- colMeans(all.rgb)
    neut <- all.hsv[2,]==0
    col.col <- all.col[!neut]
    col.hsv <- all.hsv[,!neut]
    col.rgb <- all.rgb[,!neut]
    sv.mn <- colMeans(col.hsv[2:3,])
    col.cv <- all.cv[!neut]
    col.mn <- all.mn[!neut]
    
    ## core color intervals, by hue (left-closed, i.e. x>=first and x<second)
    h.ranges <- list(
            red=list( c(0.00,0.05), c(0.95,1.00) ),
         orange=list( c(0.05,0.11) ),
         yellow=list( c(0.11,0.20) ),
          green=list( c(0.20,0.437) ),
           cyan=list( c(0.437,0.54) ),
           blue=list( c(0.54,0.72) ),
         purple=list( c(0.73,0.87) ),
         violet=list(),
        magenta=list( c(0.83,0.94) ),
          brown=list( c(0.05,0.15) )
    )
    h.ranges$violet <- h.ranges$purple
    which.hue <- lapply(h.ranges, function(x) unlist(lapply(x, function(y) which(col.hsv[1,]>=y[1] & col.hsv[1,]<y[2]) )))
    
    ## some specific definitions
    is.truegreen <- col.hsv[1,]>=0.32 & col.hsv[1,]<=0.34  # green hue +- 0.01
    is.trueblue  <- col.hsv[1,]>=0.65 & col.hsv[1,]<=0.67   # blue hue +- 0.01
    is.bluepur <- col.hsv[1,]>=h.ranges$blue[[1]][1] & col.hsv[1,]<=h.ranges$purple[[1]][2]
    bluepur.deval <- is.bluepur & col.hsv[3,]<0.9
    
    ## neutral and near-neutral definitions
    gray.blocks <- list(153:253,261:361)   # positions of giant gray/grey0-100 blocks
    ghsv <- rgb2hsv(col2rgb(colors()[gray.blocks[[1]]]))  # all sat == 0 !
    true.neutrals <- which(all.hsv[2,] == 0)   ## these are the only true neutrals, all the others are near-neutral
    neuts <- list(   ## ALL THESE ARE NEAR-NEUTRAL // NO TRUE NEUTRALS (except black and white)
        black=which(col.mn<=40 | (is.bluepur & col.mn<=50) ),
        white=which(col.mn>=240),
        greyL=which(col.cv <= 0.3 & col.hsv[3,]<=0.4),
        greyML=which(col.cv <= 0.3 & col.hsv[3,]>0.4 & col.hsv[3,]<=0.8 & col.hsv[2,]>0.2),
        greyMH=which(col.cv <= 0.3 & col.hsv[3,]>0.4 & col.hsv[3,]<=0.8 & col.hsv[2,]<=0.2),
        greyH=which(col.cv <= 0.3 & col.hsv[3,]>0.7 & col.hsv[3,]>0.8 & col.hsv[2,]<=0.2)
    )
    for (i in 1:length(neuts)) neuts[[i]] <- setdiff(neuts[[i]], true.neutrals)
    neuts$black <- c(neuts$black, which(colors()=="black"))
    neuts$white <- c(neuts$white, which(colors()=="white"))
    length(true.neutrals); listLengths(neuts)
    
    ## named-colorspace fault lines
    satlines <- c(0.36,0.64,0.97)
    vallines <- c(0.67,0.89)
    satlines1 <- c(-0.02,satlines,1.03)  # with min/max  # *lines1 intended for use with col.hsv NOT all.hsv
    vallines1 <- c(0.27,vallines,1.03)   # with min/max
    sv.blocks <- named.list(unlist(lapply(length(vallines1):2, function(v) lapply(2:length(satlines1), function(s){
        w <- which(col.hsv[3,]<vallines1[v] & col.hsv[3,]>vallines1[v-1] & col.hsv[2,]>satlines1[s-1] & col.hsv[2,]<satlines1[s])
#        IM(v,vallines1[v-1],vallines1[v],":",s,satlines1[s-1],satlines1[s],":",length(w))
        w
    })), recursive=FALSE), 1:12)
#    listLengths(sv.blocks); sum(listLengths(sv.blocks)); sum(listLengths(sv.blocks))+length(neut)
    ## 1=pal, 2=lit, 3=brt, 4=brt, 5=pal, 6=lit, 7=med, 8=med, 9=dim, 10=dim, 11=drk, 12=drk
    sets <- list(
        neutral=c(),
        dim=sort(unlist(sv.blocks[c(5,9)])),
        pale=sort(unlist(sv.blocks[c(1)])),
        light=sort(unlist(sv.blocks[c(2,6)])),
        bold=sort(unlist(sv.blocks[c(3,4)])),
        medium=sort(unlist(sv.blocks[c(7,8)])),
        dark=sort(unlist(sv.blocks[c(10,11,12)]))
    )
    sets$neutral
#    listLengths(sets)
    ### NOTES:
    ## red: P/L ok; Dm/Dk ol
    ## orange: P/L ol, Dm/Dk ol
    ## yellow: P/L ol, Dm/Dk ol
    ## green: 
    ## cyan: 
    ## blue: 
    ## purple: 
    ## magenta: 
    
    if (color %in% neutral.names) {
        
        if (color == "grey" | color == "gray" | color == "Neutral") {
            matches$`Grays-1` <- graysLo
            matches$`Grays-2` <- graysML
            matches$`Grays-3` <- graysMH
            matches$`Grays-4` <- graysHi
            if (color == "Neutral") matches <- list(`Near-White`=neuts[whites], matches, `Near-Black`=neuts[blacks])
        } else if (color == "white") {
            matches$`Near-White` <- neuts[whites]
        } else if (color == "black") {
            matches$`Near-Black` <- neuts[blacks]
        }
        
    } else {
        
        matches <- lapply(sets, function(x) intersect(x, which.hue) )
        
        if (color == "brown") {	  # eliminate vivid colors (these will be oranges and yellows)
            pre <- unlist(matches[3:6])	  # Pale, Light, Bold, Medium
            drop1 <- pre[which(col.hsv[2,pre] > 0.85 & col.hsv[3,pre] > 0.85)]
            drop2 <- pre[which(col.hsv[2,pre] <= 0.2 & col.hsv[3,pre] > 0.99)]
            drop3 <- pre[which(col.hsv[2,pre] > 0.4 & col.hsv[3,pre] > 0.93)]
            drop.34 <- c(drop2, drop3)
            drop.56 <- c(drop1)
            for (i in 3:4) matches[[i]] <- setdiff(matches[[i]], drop.34)
            for (i in 5:6) matches[[i]] <- setdiff(matches[[i]], drop.56)
        }
    }
    
#    sorts <- list(h=1, s=2, v=3)
#    if (length(sort)>0) {
#        for (i in 1:7) matches[[i]] <- matches[[i]][order(col.hsv[sorts[[sort]],matches[[i]]])]
#    } else {
#        sort13 <- "v"
#        sort47 <- ifelse(color=="brown", "s", "h")
#        for (i in 1:3) matches[[i]] <- matches[[i]][order(col.hsv[sorts[[sort13]],matches[[i]]])]
#        for (i in 4:7) matches[[i]] <- matches[[i]][order(col.hsv[sorts[[sort47]],matches[[i]]])]
#    }
    
    message(paste(length(unlist(matches)),"colors found.\n"))
    ok <- which(listLengths(matches) > 0)
    if (length(ok) > 0) {
        par(mfrow=c(1,length(ok)), mar=c(0,0,2,pmar), las=2, cex=cex)
        for (i in ok) {
            x <- col.col[matches[[i]]]
            x <- x[order(col.hsv[1,matches[[i]]])]
            if (length(x)<4) x <- c(x, rep(NA,4-length(x)))
            L <- length(x)
            y <- t(as.matrix(L:1))
            xh <- col.hsv[1,matches[[i]]]
            xs <- col.hsv[2,matches[[i]]]
            xv <- col.hsv[3,matches[[i]]]
            image(y, col=x, main=names(matches)[i], axes=FALSE)
            x[is.na(x)] <- ""  # remove color "name" after imaging
            if (pmar>0) {
                axis(4, col=0, tick=FALSE, line=-0.8, at=seq(0,1,length.out=L), labels=x[L:1], las=2)
            } else {
                if (all(xh>=0.54 & xh<=0.87)) {
                    lowval <- xs>0.4 & xv<0.6   # devalued blues/purples are visually much darker than other colors
                    lowval <- lowval | (abs(xh-0.66)<=0.01 & xv>0.9)  # also include high-valued true-blues 
                } else {
                    lowval <- xv<0.55   # all other colors
                }
                textcol <- 1  # default
#                textcol <- c("black","white")[lowval+1]
#                textcol <- ifelse(names(matches)[i]=="dark", "white", "black")
                ##text(-1, seq(0,1,length.out=L), x[L:1], pos=4, col=rev(textcol))  # print left-justified
                text(0, seq(0,1,length.out=L), x[L:1], col=rev(textcol))  # print centered
            }
        }
        invisible(matches)
    } else {
        stop("No colors found in that range!\n")
    }
}


apa.names$general <- c(apa.names$general, "quantile.distort")
quantile.distort <- function(x, n, d, r=1E6, resamp=FALSE) {
	
	## takes a vector x and a distribution d, and returns a vector of length n (# quantiles).
	## here we assume that x reflects a linear spread of values and d does not.
	## will not work unless length(x) < n < length(d).  x must be ordered, but not necessarily numeric.
	## r is maximum quantile resolution.  If n is large and d has high positive kurtosis, this can create extreme quantile resolutions.  If > r, algo will stop (instead of running forever)
	## also note: distributions do have a maximum quantile resolution, i.e. the number of quantiles for which unique quantile values can be calculated.  High kurtosis can reduce this number very fast.
	##  thus if n is too large for d, your result will be shorter than n (and you will get a warning).
	##
	## toy example: let's distort the range 1:5 via the normal distribution, returning a vector of length 20:
	##  x=1:5, n=10, d=rnorm(0, 1, 100)
	##  returns: c(
	
	lx <- length(x)
	lqt <- incr <- 0
	while (lqt-1 < lx) {   # requesting lx quantiles gets < lx unique quantiles: must increase # quantiles until lx uniques exist
		incr <- incr + 1
		qt <- quantile(real(d), seq(0,1,length=lx+incr))
		dupqt <- duplicated(qt)
		if (any(dupqt)) { qt <- qt[!dupqt] }     # identical quantiles exist (extreme positive kurtosis): merge and re-evaluate
		lqt <- length(qt)    # AFTER duplicate removal
	}
#	IM("increased",incr-1,"times")
	dq <- diff(qt)  # has length = length(qt)-1 = length(x)
	ndec <- sapply(dq, function(x){as.numeric(strsplit(format(abs(x), sci=TRUE),"-")[[1]][2])})   # number of decimals after 0 at which nonzero values begin
	ndec[is.na(ndec)] <- 0
	max1d <- max(ndec)  # order of smallest quantile difference
	max2d <- max(ndec[ndec<max(ndec)])  # order of next-smallest quantile difference
#	IM(max1d,max2d)
	if (max1d > max2d+2) {  # 2 is arbitrary outlier cutoff: this indicates that max1d is an outlier (usually one that should be 0.0 but gets #e-16, for instance)
		IM(max1d,">",max2d,"+2")
		dq[which.max(ndec)] <- round(dq[which.max(ndec)], max2d+2)  # bring order into non-outlier range
		ndec <- sapply(dq, function(x){as.numeric(strsplit(format(abs(x), sci=TRUE),"-")[[1]][2])})   # post-rounding: number of decimals after 0 at which nonzero values begin
		ndec[is.na(ndec)] <- 0
	}
	sigd <- max(ndec)  # how many sig dig do we have to use before we can fully resolve all quantile values?
	res <- 1 / 10^sigd
	qbins <- round((qt[lqt] - qt[1]) / res, 0)   # quantile resolution = how many bins will d be broken into using the smallest observed quantile
#	IM(lqt, length(dq), sigd, res, qbins, r)
	if (qbins > r) {   # quantile resolution too high; runtime could explode.  Value of n was too ambitious, or d is really skewed.
		stop(paste("Required quantile resolution of",qbins,"exceeds max resolution of",r,"\nDistribution too skewed!  Decrease n or increase r\n")) 
	}
	# if (qbins > r) {   # quantile resolution too high; runtime could explode.  Value of n was too ambitious, or d is really skewed.
		# IM("Required quantile resolution of",qbins,"exceeds max resolution of",r)
	# }
	pre <- rep(NA, qbins+1)   # initial size; will probably wind up extending beyond this
	end <- 0
	for (i in 1:lx) {  # for each color value,
		start <- end + 1
		end <- start + round(dq[i] / res,0)
#		IM(i, start, end, dq[i])
		pre[start:end] <- x[i]
	}
	out <- pre[round(seq(1,length(pre),length=n),0)]  # evenly downsample to meet length requirements
	return(out)
}


apa.names$plots <- c(apa.names$plots, "color.thresholds")
color.thresholds <- function(x, diverging=NULL, quant=0.95) {
    
    ## determine thresholding limits for a heatmap matrix being imaged
    ## basically, we want to throttle outliers to prevent colors getting washed out
    ## 'diverging' indicates use of a diverging values/palette; value is the central value of the distribution (normally 0)

    x <- real(x)
    if (length(x)>1E6) x <- sample(x,1E5)

    limit.old <- function(y) {
        p <- percentiles(y)
        pm <- median(nonzero(p))
        pf <- p/pm
        p[which(pf>=10)-1]
    }
    limit <- function(y) {
        if (min(y)>=0) {
            ## all pos
            nameless(c(0, quantile(y,quant)))
        } else if (max(y)<=0) {
            ## all neg
            nameless(c(-quantile(abs(y),quant), 0))
        } else if (min(y)<0 & max(y)>0) {
            ## straddles 0
            z <- y-median(y)
            yn <- abs(y[y<0])
            yp <- y[y>0]
            nnz <- sum(z==0)
            if (nnz%%2==0) {
                yn <- c(yn, rep(0,nnz/2))
                yp <- c(yp, rep(0,nnz/2))
            } else {
                yn <- c(yn, rep(0,floor(nnz/2)))
                yp <- c(yp, rep(0,ceiling(nnz/2)))
            }
            nameless(c( -quantile(yn,quant), quantile(yp,quant) ))
        }
    }
    
    if (is.null(diverging)) {
        limit(x)
    } else {
        diverging + limit(x-diverging)
        ##diverging + c( -limit(abs(x[x<0])), limit(x[x>0]) )
    }
}


apa.names$plots <- c(apa.names$plots, "palette.mapping")
palette.mapping <- function(val, pal, rev.pal=FALSE, col.limits=NULL, col.center=NULL, quant.cols=FALSE, max.cols=256, max.qres=1E6, interpolate=NULL) {
	
	## Function to handle color-to-value mapping and palette distortion
	## Intended for matrix-plotting functions like heat.map, myImagePlotUltra, etc.
	## 'val' is either a vector or matrix containing values to be plotted
	## 'pal' is a name/vector resolvable by palettizer()
	## other args are as they are for myImagePlotUltra, and with same defaults
	
	vrange <- range(val, na.rm=TRUE)	# plottable value range
    colctr <- FALSE						# col centering off, initially
	scale.range <- vrange				# color scale limits, initially
	
	lcl <- length(col.limits)
	lcc <- length(col.center)
	if (lcl!=0 & lcl!=2) stop("'col.limits' must be NULL or a length-2 vector!")
	if (lcc!=0 & lcc!=1) stop("'col.center' must be NULL or a length-1 vector!")
	
	if (lcl==2 & lcc==1) {
		
		stop("Not yet ready for color limiting and centering at the same time!")
		
		## CODE BELOW JUST DUMPED HERE
		
		scale.range <- col.limits
        scale.colors <- palettizer(pal, max.cols, interpolate, NULL, rev.pal)
        if (!exists("scale.colors")) stop("No palette to use: cannot proceed!\n")
        scale.values <- seq(scale.range[1], scale.range[2], length=length(scale.colors))	# initial color scale (may be too wide)
        terminal.values <- quantize(vrange, scale.values)
		terminal.positions <- quantize(vrange, scale.values, indices=TRUE)
		matrix.colors <- scale.colors[terminal.positions[1]:terminal.positions[2]]
		
		colctr <- TRUE
        ## make and arrange half-palettes if color scale is centered
        percol <- diff(scale.range) / max.cols
        col.fracs <- col.ranges <- c(0,0)
        col.fracs[1] <- (col.center - scale.range[1]) / percol   # fraction below center
        col.fracs[2] <- (scale.range[2] - col.center) / percol   # fraction above center
        half.palettes <- palettizer(pal, max.cols, interpolate, round(col.fracs,0), FALSE)  # palette, n.colors=NA, interpolate=NULL, halves=c(lower.res,upper.res), reverse=FALSE
        scale.colors <- unlist(half.palettes)
        scale.values <- seq(vrange[1], vrange[2], length=length(scale.colors))
		
    } else if (lcl==2) {
		
		scale.range <- col.limits
        scale.colors <- palettizer(pal, max.cols, interpolate, NULL, rev.pal)
        if (!exists("scale.colors")) stop("No palette to use: cannot proceed!\n")
        scale.values <- seq(scale.range[1], scale.range[2], length=length(scale.colors))	# initial color scale (may be too wide)
        terminal.values <- quantize(vrange, scale.values)
		terminal.positions <- quantize(vrange, scale.values, indices=TRUE)
		matrix.colors <- scale.colors[terminal.positions[1]:terminal.positions[2]]
		
    } else if (lcc==1) {
		
        colctr <- TRUE
        ## make and arrange half-palettes if color scale is centered
        percol <- diff(scale.range) / max.cols
        col.fracs <- col.ranges <- c(0,0)
        col.fracs[1] <- (col.center - scale.range[1]) / percol   # fraction below center
        col.fracs[2] <- (scale.range[2] - col.center) / percol   # fraction above center
        half.palettes <- palettizer(pal, max.cols, interpolate, round(col.fracs,0), FALSE)  # palette, n.colors=NA, interpolate=NULL, halves=c(lower.res,upper.res), reverse=FALSE
        matrix.colors <- scale.colors <- unlist(half.palettes)
        scale.values <- seq(vrange[1], vrange[2], length=length(scale.colors))
###     return(list(col.center=col.center, max.cols=max.cols, vrange=vrange, scale=scale, percol=percol, col.fracs=col.fracs, half.palettes=half.palettes, ColorLevels=ColorLevels))
		
	} else if (quant.cols) {
		
        cbins <- max.cols
        qcolors <- palettizer(pal, max.cols, interpolate, NULL, rev.pal)
        qt <- quantile(real(as.vector(unlist(val))), seq(0,1,length=cbins+1))
        dupqt <- duplicated(qt)
        if (any(dupqt)) qt <- qt[!dupqt]     # identical quantiles exist (extreme positive kurtosis): merge and re-evaluate
        cbins <- length(qt) - 1
        if (cbins != max.cols) qcolors <- palettizer(pal, max.cols, interpolate, NULL, rev.pal)  # bin count changed: have to re-make color vector
        d <- diff(qt)
        sigd <- as.numeric(strsplit(format(abs(min(d)), sci=TRUE),"-")[[1]][2])
        res <- 1 / 10^sigd
        qbins <- round((qt[cbins+1] - qt[1]) / res, 0)
###		IM(qt[1],qt[257],min(d),sigd,res,qbins)
        if (qbins > max.qres) {   # data distribution too skewed: zero-inflated data?
            if (min(real(unlist(c(val))))==0) { }   # doing what here??
            stop(paste("Data has too much positive kurtosis: minimum quantile size too small! | resolution=",qbins,", max resolution=",max.qres,"\nDecrease max.cols or increase max.qres\n",sep="")) 
        }
        scale.colors <- rep(0, qbins+1)
        end <- 0
        for (i in 1:cbins) {
            start <- end + 1
            end <- start + round(d[i] / res,0)
            scale.colors[start:end] <- qcolors[i]
        }
###		IM(cbins, qbins, qcolors[1], scale.colors[1], qcolors[cbins], scale.colors[qbins+1])
        scale.values <- seq(vrange[1], vrange[2], length=length(scale.colors))
###		return(list(qt,ColorLevels,scale.colors))
		matrix.colors <- scale.colors
		
    } else {
		
        matrix.colors <- scale.colors <- palettizer(pal, max.cols, interpolate, NULL, rev.pal)
        scale.values <- seq(vrange[1], vrange[2], length=length(scale.colors))
		
    }
	
#	IM(matrix.colors[1], matrix.colors[length(matrix.colors)])
#	IM(scale.colors[1], scale.colors[length(scale.colors)])
	return(list(matrix.colors=matrix.colors, scale.colors=scale.colors, scale.values=scale.values, data.range=vrange, scale.range=scale.range))
}


