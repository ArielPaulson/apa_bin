

apa.names$general <- c(apa.names$general, "aggregate2")
aggregate2 <- function(obj, by, func, na.rm=FALSE) {
    
    ## Like aggregate() but doesn't fail with large numbers
    
    NR <- length(obj)
    if (length(by)==0) {
        stop("'by' has length 0!\n")
    } else {
        for (i in 1:length(by)) {
            if (length(by[[i]]) != NR) stop("'by' element",i,"has length != length(obj)!\n")
        }
    }
    B <- length(by)
    if (length(names(by))==0) names(by) <- paste("Factor",1:B,sep="")
    by.mat <-  matrix(0, NR, B)
    for (i in 1:B) by.mat[,i] <- as.character(by[[i]])
    agg.grps <- apply(by.mat, 1, paste, collapse="-")
    ugrps <- sort(unique(agg.grps))
    NG <- length(ugrps)
    output <- rep(0,NG)
    for (i in 1:NG) output[i] <- func(as.numeric(obj[which(agg.grps==ugrps[i])]), na.rm=na.rm)
    nameless(data.frame(ugrps,output))
}


apa.names$hacks <- c(apa.names$hacks, "t.test2")
t.test2 <- function (x, y = NULL, alternative = c("two.sided", "less", "greater"), mu = 0, paired = FALSE, var.equal = FALSE, conf.level = 0.95, ...) {
    
    ## Removes the idiotic failure requirement if the data are invariant.  There is no law against t-testing invariant data.
    
    alternative <- match.arg(alternative)
    if (!missing(mu) && (length(mu) != 1 || is.na(mu))) 
        stop("'mu' must be a single number")
    if (!missing(conf.level) && (length(conf.level) != 1 || !is.finite(conf.level) || 
                                     conf.level < 0 || conf.level > 1)) 
        stop("'conf.level' must be a single number between 0 and 1")
    if (!is.null(y)) {
        dname <- paste(deparse(substitute(x)), "and", deparse(substitute(y)))
        if (paired) 
            xok <- yok <- complete.cases(x, y)
        else {
            yok <- !is.na(y)
            xok <- !is.na(x)
        }
        y <- y[yok]
    }
    else {
        dname <- deparse(substitute(x))
        if (paired) 
            stop("'y' is missing for paired test")
        xok <- !is.na(x)
        yok <- NULL
    }
    x <- x[xok]
    if (paired) {
        x <- x - y
        y <- NULL
    }
    nx <- length(x)
    mx <- mean(x)
    vx <- var(x)
    estimate <- mx
    if (is.null(y)) {
        if (nx < 2) 
            stop("not enough 'x' observations")
        df <- nx - 1
        stderr <- sqrt(vx/nx)
        if (stderr < 10 * .Machine$double.eps * abs(mx)) 
            warning("data are essentially constant")
        tstat <- (mx - mu)/stderr
        method <- ifelse(paired, "Paired t-test", "One Sample t-test")
        names(estimate) <- ifelse(paired, "mean of the differences", 
                                  "mean of x")
    }
    else {
        ny <- length(y)
        if (nx < 1 || (!var.equal && nx < 2)) 
            stop("not enough 'x' observations")
        if (ny < 1 || (!var.equal && ny < 2)) 
            stop("not enough 'y' observations")
        if (var.equal && nx + ny < 3) 
            stop("not enough observations")
        my <- mean(y)
        vy <- var(y)
        method <- paste(if (!var.equal) 
                            "Welch", "Two Sample t-test")
        estimate <- c(mx, my)
        names(estimate) <- c("mean of x", "mean of y")
        if (var.equal) {
            df <- nx + ny - 2
            v <- 0
            if (nx > 1) 
                v <- v + (nx - 1) * vx
            if (ny > 1) 
                v <- v + (ny - 1) * vy
            v <- v/df
            stderr <- sqrt(v * (1/nx + 1/ny))
        }
        else {
            stderrx <- sqrt(vx/nx)
            stderry <- sqrt(vy/ny)
            stderr <- sqrt(stderrx^2 + stderry^2)
            df <- stderr^4/(stderrx^4/(nx - 1) + stderry^4/(ny - 
                                                                1))
        }
        if (stderr < 10 * .Machine$double.eps * max(abs(mx), 
                                                    abs(my))) 
            warning("data are essentially constant")
        tstat <- (mx - my - mu)/stderr
    }
    if (alternative == "less") {
        pval <- pt(tstat, df)
        cint <- c(-Inf, tstat + qt(conf.level, df))
    }
    else if (alternative == "greater") {
        pval <- pt(tstat, df, lower.tail = FALSE)
        cint <- c(tstat - qt(conf.level, df), Inf)
    }
    else {
        pval <- 2 * pt(-abs(tstat), df)
        alpha <- 1 - conf.level
        cint <- qt(1 - alpha/2, df)
        cint <- tstat + c(-cint, cint)
    }
    cint <- mu + cint * stderr
    names(tstat) <- "t"
    names(df) <- "df"
    names(mu) <- if (paired || !is.null(y)) 
                     "difference in means"
                 else "mean"
    attr(cint, "conf.level") <- conf.level
    rval <- list(statistic = tstat, parameter = df, p.value = pval, 
                 conf.int = cint, estimate = estimate, null.value = mu, 
                 alternative = alternative, method = method, data.name = dname)
    class(rval) <- "htest"
    return(rval)
}


apa.names$hacks <- c(apa.names$hacks, "parse_args2")
parse_args2 <- function (object, args = commandArgs(trailingOnly = TRUE), print_help_and_exit = TRUE, positional_arguments = FALSE) {
	
	## Hacked parse_args() from optparse, which uses the hack getopt2()
	
	require(optparse)
    n_options <- length(object@options)
    spec <- matrix(NA, nrow = n_options, ncol = 5)
    for (ii in seq(along = object@options)) {
        spec[ii, ] <- optparse:::.convert_to_getopt(object@options[[ii]])
    }
    if (positional_arguments) {
        os_and_n_arg <- optparse:::.get_option_strings_and_n_arguments(object)
        original_arguments <- args
        args <- NULL
        arguments_positional <- character(0)
        is_taken <- FALSE
        for (argument in original_arguments) {
            if (is_taken) {
                args <- c(args, argument)
                is_taken <- FALSE
            } else {
                if (optparse:::.is_option_string(argument, object)) {
                  args <- c(args, argument)
                  if (optparse:::.requires_argument(argument, object)) is_taken <- TRUE
                } else {
                  arguments_positional <- c(arguments_positional, argument)
                }
            }
        }
    }
    options_list <- list()
    if (length(args)) {
        opt <- getopt2(spec = spec, opt = args)
    } else {
        opt <- list()
    }
    for (ii in seq(along = object@options)) {
        option <- object@options[[ii]]
        option_value <- opt[[sub("^--", "", option@long_flag)]]
        if (!is.null(option_value)) {
            if (option@action == "store_false") {
                options_list[[option@dest]] <- FALSE
            } else {
                options_list[[option@dest]] <- option_value
            }
        } else {
            if (!is.null(option@default) & is.null(options_list[[option@dest]]))  options_list[[option@dest]] <- option@default
        }
    }
    if (options_list[["help"]] & print_help_and_exit) {
        print_help(object)
        quit(status = 1)
    }
    if (positional_arguments) {
        return(list(options = options_list, args = arguments_positional))
    } else {
        return(options_list)
    }
}


apa.names$hacks <- c(apa.names$hacks, "getopt2")
getopt2 <- function (spec = NULL, opt = commandArgs(TRUE), command = get_Rscript_filename(), usage = FALSE, debug = FALSE) {
	
	## Hacked version of getopt's getopt(), which actually works.
	## I.e. does not think that unambiguous short flags are ambiguous.
	
    if (exists("argv", where = .GlobalEnv, inherits = FALSE)) opt = get("argv", envir = .GlobalEnv)
    ncol = 4
    maxcol = 6
    col.long.name = 1
    col.short.name = 2
    col.has.argument = 3
    col.mode = 4
    col.description = 5
    flag.no.argument = 0
    flag.required.argument = 1
    flag.optional.argument = 2
    result = list()
    result$ARGS = vector(mode = "character")
    if (is.null(spec)) {
        stop("argument \"spec\" must be non-null.")
    } else if (!is.matrix(spec)) {
        if (length(spec)/4 == as.integer(length(spec)/4)) {
            warning("argument \"spec\" was coerced to a 4-column (row-major) matrix.  use a matrix to prevent the coercion")
            spec = matrix(spec, ncol = ncol, byrow = TRUE)
        } else {
            stop("argument \"spec\" must be a matrix, or a character vector with length divisible by 4, rtfm.")
        }
    } else if (dim(spec)[2] < ncol) {
        stop(paste("\"spec\" should have at least \",ncol,\" columns.", sep = ""))
    } else if (dim(spec)[2] > maxcol) {
        stop(paste("\"spec\" should have no more than \",maxcol,\" columns.", sep = ""))
    } else if (dim(spec)[2] != ncol) {
        ncol = dim(spec)[2]
    }
    if (length(unique(spec[, col.long.name])) != length(spec[, col.long.name])) {
        stop(paste("redundant long names for flags (column ", col.long.name, ").", sep = ""))
    }
    if (length(na.omit(unique(spec[, col.short.name]))) != length(na.omit(spec[, col.short.name]))) {
        stop(paste("redundant short names for flags (column ", col.short.name, ").", sep = ""))
    }
    if (usage) {
        ret = ""
        ret = paste(ret, "Usage: ", command, sep = "")
        for (j in 1:(dim(spec))[1]) {
            ret = paste(ret, " [-[-", spec[j, col.long.name], "|", spec[j, col.short.name], "]", sep = "")
            if (spec[j, col.has.argument] == flag.no.argument) {
                ret = paste(ret, "]", sep = "")
            } else if (spec[j, col.has.argument] == flag.required.argument) {
                ret = paste(ret, " <", spec[j, col.mode], ">]", sep = "")
            } else if (spec[j, col.has.argument] == flag.optional.argument) {
                ret = paste(ret, " [<", spec[j, col.mode], ">]]", sep = "")
            }
        }
        if (ncol >= 5) {
            max.long = max(apply(cbind(spec[, col.long.name]), 1, function(x) length(strsplit(x, "")[[1]])))
            ret = paste(ret, "\n", sep = "")
            for (j in 1:(dim(spec))[1]) {
                ret = paste(ret, sprintf(paste("    -%s|--%-", 
                  max.long, "s    %s\n", sep = ""), spec[j, col.short.name], spec[j, col.long.name], spec[j, col.description]),  sep = "")
            }
        } else {
            ret = paste(ret, "\n", sep = "")
        }
        return(ret)
    }
    i = 1
    while (i <= length(opt)) {
        if (debug) print(paste("processing", opt[i]))
        current.flag = 0
        optstring = opt[i]
        if (substr(optstring, 1, 2) == "--") {
            if (debug) print(paste("  long option:", opt[i]))
            optstring = substring(optstring, 3)
            this.flag = NA
            this.argument = NA
            kv = strsplit(optstring, "=")[[1]]
            if (!is.na(kv[2])) {
                this.flag = kv[1]
                this.argument = paste(kv[-1], collapse = "=")
            } else {
                this.flag = optstring
            }
            rowmatch = grep(this.flag, spec[, col.long.name], fixed = TRUE)
            if (length(rowmatch) == 0) {
                stop(paste("long flag \"", this.flag, "\" is invalid", sep = ""))
            } else if (length(rowmatch) > 1) {
                rowmatch = which(this.flag == spec[, col.long.name])
                if (length(rowmatch) == 0) stop(paste("long flag \"", this.flag, "\" is ambiguous", sep = ""))
            }
            if (!is.na(this.argument)) {
                if (spec[rowmatch, col.has.argument] == flag.no.argument) {
                  stop(paste("long flag \"", this.flag, "\" accepts no arguments", sep = ""))
                } else {
                  storage.mode(this.argument) = spec[rowmatch, col.mode]
                  result[spec[rowmatch, col.long.name]] = this.argument
                  i = i + 1
                  next
                }
            } else {
                result[spec[rowmatch, col.long.name]] = TRUE
                current.flag = rowmatch
            }
        } else if (substr(optstring, 1, 1) == "-") {
            if (debug) print(paste("  short option:", opt[i]))
            these.flags = strsplit(optstring, "")[[1]]
            done = FALSE
            for (j in 2:length(these.flags)) {
                this.flag = these.flags[j]
##                rowmatch = grep(paste("^",this.flag,sep=""), spec[, col.short.name], fixed = TRUE)
#                rowmatch = which(spec[, col.short.name] == this.flag)
                rowmatch = grep(paste("^",this.flag,sep=""), spec[, col.short.name], fixed = FALSE)
                if (length(rowmatch) == 0) {
                  stop(paste("short flag \"", this.flag, "\" is invalid", sep = ""))
                } else if (length(rowmatch) > 1) {
                 stop(paste("short flag \"", this.flag, "\" is ambiguous:", sep = ""))
                } else if (j < length(these.flags) & spec[rowmatch, 
                  col.has.argument] == flag.required.argument) {
                  stop(paste("short flag \"", this.flag, "\" requires an argument, but has none", sep = ""))
                } else if (spec[rowmatch, col.has.argument] == flag.no.argument) {
                  result[spec[rowmatch, col.long.name]] = TRUE
                  done = TRUE
                } else {
                  result[spec[rowmatch, col.long.name]] = TRUE
                  current.flag = rowmatch
                  done = FALSE
                }
            }
            if (done) {
                i = i + 1
                next
            }
        }
        if (current.flag == 0) {
            stop(paste("\"", optstring, "\" is not a valid option, or does not support an argument", sep = ""))
        } else if (current.flag > 0) {
            if (debug) print("    dangling flag")
            if (length(opt) > i) {
                peek.optstring = opt[i + 1]
                if (debug) print(paste("      peeking ahead at: \"", peek.optstring, "\"", sep = ""))
                if ( substr(peek.optstring, 1, 1) != "-" | 
					(substr(peek.optstring, 1, 1) == "-" & regexpr("^-[0123456789]*\\.?[0123456789]+$", peek.optstring) > 0 & spec[current.flag, col.mode] ==  "double") | 
					(substr(peek.optstring, 1, 1) ==  "-" & regexpr("^-[0123456789]+$", peek.optstring) >  0 & spec[current.flag, col.mode] == "integer") ) {
                  if (debug) print(paste("        consuming argument *", peek.optstring, "*", sep = ""))
				  storage.mode(peek.optstring) = spec[current.flag, col.mode]
				  result[spec[current.flag, col.long.name]] = peek.optstring
				  i = i + 1
                } else if (substr(peek.optstring, 1, 1) == "-" & length(strsplit(peek.optstring, "")[[1]]) ==  1) {
                  if (debug) print("        consuming \"lone dash\" argument")
                  storage.mode(peek.optstring) = spec[current.flag, col.mode]
                  result[spec[current.flag, col.long.name]] = peek.optstring
                  i = i + 1
                } else {
                  if (debug) print("        no argument!")
                  if (spec[current.flag, col.has.argument] ==  flag.required.argument) {
                    stop(paste("flag \"", this.flag, "\" requires an argument",  sep = ""))
                  } else if (spec[current.flag, col.has.argument] ==  flag.optional.argument | spec[current.flag,  col.has.argument] == flag.no.argument) {
                    x = TRUE
                    storage.mode(x) = spec[current.flag, col.mode]
                    result[spec[current.flag, col.long.name]] = x
                  } else {
                    stop(paste("This should never happen.", "Is your spec argument correct?  Maybe you forgot to set",  "ncol=4, byrow=TRUE in your matrix call?"))
                  }
                }
            } else if (spec[current.flag, col.has.argument] ==  flag.required.argument) {
                stop(paste("flag \"", this.flag, "\" requires an argument",  sep = ""))
            } else if (spec[current.flag, col.has.argument] ==  flag.optional.argument) {
                x = TRUE
                storage.mode(x) = spec[current.flag, col.mode]
                result[spec[current.flag, col.long.name]] = x
            } else if (spec[current.flag, col.has.argument] ==  flag.no.argument) {
                x = TRUE
                storage.mode(x) = spec[current.flag, col.mode]
                result[spec[current.flag, col.long.name]] = x
            } else {
                stop("this should never happen (2).  please inform the author.")
            }
        } else {
        }
        i = i + 1
    }
    return(result)
}
