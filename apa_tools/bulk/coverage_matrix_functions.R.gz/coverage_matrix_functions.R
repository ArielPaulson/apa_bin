

apa.names$dev <- c(apa.names$dev, "coverage.matrix.generate")
coverage.matrix.generate <- function(bams, bed, path, nwin=100, ncpu=1, inputs=NULL, clobber=FALSE, skip=FALSE) {
    
    ## wrapper for cov.mat() from CoverageView package
    ## writes each matrix to an RData file
    ## 
    ## 'bams' is a NAMED vector of bam file paths.
    ## 'bed' is a bed file path
    ## 'path' is the output location; files will be named like "path/names(bams)[n].coverage_matrix_data.RData"
    ## 'nwin', 'ncpu' are further params for cov.mat()
    ## 'inputs' is a NAMED vector of ***input RData files*** with same length as 'bams'; enables IP/input fold-change matrices.
    ## 'inputs' can also be a LIST of such vectors, if any multiple IP/input pairings exist (e.g. IPs with 2 inputs, like mock and IgG).
    ## 'clobber' indicates to overwrite existing output file with same name; by default will not overwrite.
    
    suffix <- ".coverage_matrix_data.RData"
    
    require(CoverageView)

    B <- length(bams)
    bam.names <- names(bams)
    if (any(grepl("/",bam.names))) stop("Bam names must not contain slashes!\n")
    if (length(unique(bam.names)) < B) stop("Bam names must be unique!\n")
    bams.exist <- file.exists(bams)
    if (!all(bams.exist)) stop(paste("Some of these bam files do not exist!\n",paste0("  ",bams[!bams.exist],"\n")))
    bams.indexed <- file.exists(paste0(bams,".bai"))
    if (!all(bams.indexed)) stop(paste("Some of these bam files are not indexed!\n",paste0("  ",bams[!bams.indexed],"\n")))
    if (!file.exists(bed)) stop(paste0("Bed file '",bed,"' does not exist!\n"))
    
    outfiles <- paste0(path,"/",bam.names,suffix)
    names(outfiles) <- bam.names
    outfiles.exist <- file.exists(outfiles)
    if (any(outfiles.exist)) {
        filelist <- paste(paste0("  ",outfiles[outfiles.exist],"\n"),collapse="")
        if (clobber) {
            message(paste0("Some output files already exist: clobbering these\n",filelist))
        } else if (skip) {
            message(paste0("Some output files already exist: skipping these\n",filelist))
        } else {
            stop(paste0("Some output files already exist, but 'clobber' and 'skip' are both FALSE!  Halting...\n",filelist))
        }
    }
    
    I <- length(inputs)
    have.inputs <- FALSE
    if (I>0) {
        have.inputs <- TRUE
        if (is.nlv(inputs)) {
            inputs <- as.list(inputs)
            for (i in 1:length(inputs)) names(inputs[[i]]) <- names(inputs)[i]
            inputs <- nameless(inputs)
        }
        inputs <- lapply(inputs, function(x) x[sort(names(x))] )   # if > 1 element, then name sorting is important for future lookups
        inpN <- unlist(lapply(inputs,names))
        inpF <- unlist(inputs)
        uinpF <- real(unique(inpF))
        
        if (I!=B) {
            stop("If specified, 'inputs' must be same length as 'bams'!\n")
        } else if (!all(file.exists(uinpF))) {
            stop("Some 'inputs' files do not exist!\n")
        } else if (length(inpN)!=length(inpF)) {
            stop("Some 'inputs' files are missing names!\n")
        } else {
            input.logrpm <- new.list(1:B)
            for (i in 1:I) {
                if (all(is.na(inputs[[i]]))) {
                    ## leave input.logrpm[[i]] empty
                } else {
                    J <- length(inputs[[i]])
                    input.logrpm[[i]] <- new.list(names(inputs[[i]]))
                    for (j in 1:J) {
                        load(inputs[[i]][j])  # loads 'coverage.matrix.data'
                        input.logrpm[[i]][[j]] <- coverage.matrix.data$matrix$logrpm  # ONLY logrpm matrix, only used for IP/inp LFC
                    }
                }
            }
            rm(coverage.matrix.data)
        }
    }
    
    ## Finished with input-error-checking steps by now, so now can mkdir and write README.
    
    if (!file.exists(path)) system(paste("mkdir -p",path))
    if (!file.exists(path)) stop(paste0("Output path '",path,"' does not exist!\n"))
    
    aligns <- sapply(bams, function(x) as.numeric(system(paste("bash -c 'paste -s -d+ <(samtools idxstats",x,"| grep -vP \"^\\*\" | cut -f3) | bc'"), intern=TRUE)) )
    bed.names <- system(paste("cut -f4",bed), intern=TRUE)
    
    README <- c(
        "\nThis directory contains RData files with CoverageView coverage matrices + metadata.",
        "\nFiles were created with the function apa_tools.R::coverage.matrix.generate().",
        "\nThe bed file used to create these matrices is the only bed file in this directory.",
        "\nThere is one file per IP bam.  The IP may or may not have had associated inputs, which influences some content, see below.",
        "\nEach RData file contains one object named 'coverage.matrix.data', the structure of which is:",
        "\ncoverage.matrix.data <- list(",
        "    matrix=list(              # list of matrices of IP signal and transformations thereof.  Float values have been rounded to 3 places.",
        "        raw=matrix(...),      # Raw CoverageView::cov.matrix() output (transposed), such that rows = peaks, cols = coverageView bins.",
        "        logrpm=matrix(...),   # log2-adjusted-RPM, that is, log2(1E6*(raw+1)/M), where 'M' is the value of 'aligns' below.",
        "        pctmax=matrix(...),   # raw/max(raw).  To curb outliers, max(raw) is actually quantile(raw,0.99), and final matrix values > 1 have been thresholded down to 1.",
        "        zscore=matrix(...)    # the logrpm matrix, as row z-scores, i.e. t(scale(t(logrpm))).",
        "    ),",
        "    LFC.matrix=list(          # An empty list, OR, if N inputs supplied, then a list of N matrices, one for each input (usually, 0 or 1 inputs given).",
        "        input.i=matrix(...),  # IP 'logrpm' - input i 'logrpm'",
        "        ...,                  # ...",
        "        input.N=matrix(...)   # IP 'logrpm' - input N 'logrpm'",
        "    ),",
        "    aligns=aligns,            # N alignments in IP bam (samtools view IP.bam | wc -l)",
        "    bam=bams,                 # /path/to/IP.bam",
        "    bed=bed,                  # BED file supplied for CoverageView::cov.matrix()",
        "    inputs=inputs,            # vector of /path/to/input.bam(s), one for each matrix in 'LFC.matrix'.  Or, empty.",
        "    RData=outfiles            # /path/to/this.RData, just for reference.",
        ")",
        "\nThe function apa_tools.R::coverage.matrix.compile() can be used to lapply on a vector of RData filenames, and return a list of matrices.",
        "\nIf the file \"cov.mat.paths.RData\" exists (pipeline generated), it will contain a single list 'RDatas' which contains vectors of RData filenames, i.e. the directory tree in list format.\n"
    )
    write.vector(README, paste0(path,"/README.txt"))
    
    ## Process bams
    
    for (b in 1:B) {
        if (outfiles.exist[b] & skip) next
        M <- list()
        message(paste("Processing:",bams[b]))
        x <- suppressMessages(t(cov.matrix(CoverageBamFile(bams[b],reads_mapped=aligns[b]), coordfile=bed, no_windows=nwin, num_cores=ncpu)))
        message(paste("Post-processing:",bams[b]))
        rownames(x) <- bed.names
        bed.data <- read.bed(bed)
        
        M$raw <- x
        M$pctmax <- round(threshold(x/quantile(x,0.99),1,"gt"),3)
        a <- x+1                      ## ADJUST FIRST
        r <- 1E6*a/aligns[b]          ## RPM SECOND
        M$logrpm <- round(log2(r),3)  ## LOG THIRD
        M$zscore <- round(t(scale(t(M$logrpm))),3)
        mdim <- dim(M$logrpm)
        LFC <- NULL
        if (have.inputs) {
            LFC <- lapply(1:length(input.logrpm[[b]]), function(i) {
                idim <- dim(input.logrpm[[b]][[i]])
                #message(paste("IP",b,":",mdim[1],mdim[2]," INPUT",names(input.logrpm)[i],":",idim[1],idim[2]))
                M$logrpm - input.logrpm[[b]][[i]]
            })
            names(LFC) <- names(input.logrpm[[b]])
        }
        
        coverage.matrix.data <- list(
            matrix=M,
            LFC.matrix=LFC,
            aligns=aligns[b],
            bam=bams[b],
            bed=bed,
            inputs=inputs[[b]],
            RData=outfiles[b]
        )
        save(coverage.matrix.data, file=outfiles[b])
        message(paste("Completed:",bams[b]))
    }
    
    invisible(outfiles)
}


apa.names$dev <- c(apa.names$dev, "coverage.matrix.compile")
coverage.matrix.compile <- function(paths, matrix=c("logrpm","raw","pctmax","zscore","LFC"), LFC=1) {
    
    ## companion function to coverage.matrix.generate()
    ## returns a list of matrices from a list of coverage.matrix.generate() RData files
    ## 
    ## 'paths' is a NAMED vector of coverage.matrix.generate() RData objects.
    ## As each RData is loaded, the same matrix is extracted from it, and all matrices are returned in a list.
    ## 
    ## 'matrix' indicates what kind of matrix you want.
    ## 'LFC' only matters when using matrix="LFC": matrix will be taken from the "LFC.matrix" list; which one of them did you want?
    ##       NOTE 1: there is usually only one matrix in "LFC.matrix", so default value is 1.
    ##       NOTE 2: 'LFC' value can be an index number OR element name; will be inferred from the data type of the 'LFC' argument.
    ##
    ## Just to clarify:
    ## Matrices in 'coverage.matrix.data' objects are stored in one of two lists:
    ## coverage.matrix.data$matrix: four versions of the CoverageView matrix; raw, logrpm, zscore, and pct-of-max.
    ## coverage.matrix.data$LFC.matrix: for each associated input sample (if any), one log2(IP RPM / input RPM) matrix exists.
    ## 99% of the time, people only give one input per IP, thus the "LFC.matrix" list usually only has one matrix.
    
    matrix <- match.arg(matrix)
    paths.exist <- file.exists(paths)
    if (any(!paths.exist)) stop(paste("Some output files do not exist!\n",paste0("  ",paths[!paths.exist],"\n")))
    
    x <- lapply(1:length(paths), function(i) {
        suppressWarnings(rm(coverage.matrix.data))
        message(names(paths)[i])
        load(paths[i])  # gets 'coverage.matrix.data'
        LFC.names <- names(coverage.matrix.data$LFC.matrix)
        LFC.N <- length(coverage.matrix.data$LFC.matrix)
        if (matrix=="LFC") {
            if (is.character(LFC) && !(LFC %in% LFC.names)) stop(paste0("LFC.matrix name '",LFC,"' was not matched!\nExisting names: ",paste(LFC.names, collapse=", "),"\n"))
            if (is.numeric(LFC) && LFC>LFC.N) stop(paste0("LFC index ",LFC," exceeds LFC.matrix length of ",LFC.N,"!\n"))
            coverage.matrix.data$LFC.matrix[[LFC]]
        } else {
            coverage.matrix.data$matrix[[matrix]]
        }
    })
    
    if (length(names(paths))>0) {
        names(x) <- names(paths)
    } else {
        names(x) <- paths
    }
    x
}


apa.names$dev <- c(apa.names$dev, "coverage.matrix.bound")
coverage.matrix.bound <- function(heatmap, row.peaks, bam.peaks, extend=0, binarize=NULL, meta.data=NULL) {
    
    ## Takes a heatmap matrix (probably from coverage.matrix.generate()), the row peak list, the peak calls from the bam that the matrix was derived from,
    ##  and modified the matrix to indicate which peaks (rows) were considered "bound" by the sample peak calls.
    ## For example: you have a peak list from factor X and made CoverageView heatmaps from many bams, including the factor Y chipseq bam.
    ##              How many of these factor X peaks also had a peak call in the factor Y bam?  You could intersect peaks, but that would not illustrate it on your heatmap.
    ##              This function will keep factor-Y bound rows positive, and make factor-Y unbound rows negative.  Plot with Red->Blue palette, and see bound/unbound clearly.
    ## 
    ## 'heatmap':    a coverage heatmap matrix, say from t(CoverageView::cov.matrix()).
    ## 'row.peaks':  a peak list that was used to create 'heatmap', in same row order.  ORIGINAL PEAKS, NOT THE WULL-WINDOW PEAKS USED IN THE COV.MATRIX CALL.
    ## 'bam.peaks':  a separate set of peak calls from the bam used to create 'heatmap'.
    ## 'extend':     how far away may row.peaks be from bam.peaks and still be considered overlapping (default 0bp, must touch).
    ## 'binarize':   binarize the heatmap (see below) by giving the full heatmap row coords, i.e. the data from the bed file passed to cov.matrix().
    ## 'meta.data':  an optional metadata dataset for 'bam.peaks', in same row order.
    ## This function changes the sign of the rows in 'heatmap' to identify which rows (row.peaks) correspond to sample peak calls (bam.peaks).
    ## 
    ## More details:
    ## 'heatmap' is a heatmap-column matrix with rows = peaks and cols = spatial bins (returned by t(CoverageView::cov.matrix()), e.g.)
    ##           Matrix values MUST be non-negative, so DO NOT run this on a list of 'LFC' matrices.
    ## 'row.peaks' is a data.frame of peak coords from which rows of 'heatmap' were derived, and in same order.
    ##             HOWEVER:
    ##             These must be the ORIGINAL peaks, because we want to know if sample peaks intersect the original peaks.
    ##             The actual heatmap would probably have been generated from an extended version of these peaks, e.g. peak midpoint +-5kb.
    ##             The extended peaks, if they exist, can be supplied to 'binarize' if binarization is desired.
    ## 'bam.peaks' is a data.frame of peak coords, which are peak calls from the bam file used to create 'heatmap'.
    ##             ** These may be totally unrelated to 'row.peaks'. **
    ## 'extend' extends 'row.peaks' by this much on either side.  E.g. if 500, then sample peaks up to 500bp away from a row.peak will still be considered overlapping.
    ##          NOTE: negative values of 'extend' are allowed, but be careful with that.
    ## 'binarize' an optional extended version of 'row.peaks', same order -- but must be the full extended peaks used to create 'heatmap', i.e., as used by cov.matrix().
    ##            If supplied, 'heatmap' will be converted to 0/1 where 1=sample-bound region and 0=sample-unbound.
    ##            Knowing the full heatmap windows is necessary to determine which cells are covered by the sample peak calls.
    ##            Columns of 'heatmap' are probably bins.  If a sample peak call only partially overlaps a bin, the value will be the percent of bin overlapped (0 < value < 1).
    ## 'meta.data' is an optional metadata data.frame for 'bam.peaks', in same row order.
    ##             Tf specified, 'meta.data' will be returned with a new logical column, "Bound", simplifying separation of bound/non-bound rows.
    ## 
    ## 1. Rows of 'row.peaks' will be compared to 'bam.peaks' to find overlaps (co-binding events).
    ## 2. Rows of 'heatmap' for sample-bound peaks will remain positive, while rows for sample-unbound peaks will become negative (just a sign switch).
    ## 3. Resulting heatmaps can be plotted with a diverging palette, e.g. red->blue, and sample-bound coords will be red while sample-unbound will be blue.
    
    require(GenomicRanges)
    
    NR <- nrow(heatmap)
    NC <- ncol(heatmap)
    do.meta <- length(meta.data)>0
    do.bin  <- length(binarize)>0
    if (nrow(row.peaks) != NR) stop("'row.peaks' does not match N rows of 'heatmap'!\n")
    
    if (do.bin) {
        full.peaks <- binarize   # give the object a more appropriate working name
        full.peaks.gr <- bed2gr(full.peaks)
        row.peaks.gr <- bed2gr(row.peaks)
        bro <- suppressWarnings(as.matrix(findOverlaps(full.peaks.gr,row.peaks.gr)))
        ok <- length(unique(bro[,1]))==nrow(full.peaks) & length(unique(bro[,2]))==nrow(row.peaks)
        if (!ok) stop("'binarize' does not derive from 'row.peaks'!  Non-intersecting intervals exist.\n")
    }

    row.peaks2 <- row.peaks
    if (extend!=0) {
        row.peaks2[,2] <- row.peaks2[,2]-extend
        row.peaks2[,3] <- row.peaks2[,3]+extend
    }
    row.peaks2.gr <- bed2gr(row.peaks2)
    bam.peaks.gr <- bed2gr(bam.peaks)
    bound <- suppressWarnings(as.matrix(findOverlaps(row.peaks2.gr,bam.peaks.gr)))
    colnames(bound) <- c("Row.Peak","Bam.Peak")
    unbound <- setdiff(1:nrow(row.peaks), bound[,1])
    matched <- failed <- 0
    
    if (do.bin) {
        bppc <- round((full.peaks[1,3]-full.peaks[1,2])/NC, 0)  # mean bp per heatmap column; > 1 if binning took place
        f <- full.peaks[bound[,1],]
        b <- bam.peaks[bound[,2],]
        ob <- (as.matrix(b[,2:3])-f[,2])/bppc          # per row, bam.peak position within heatmap matrix, as c(start column, end column), but carrying decimals
        obi <- cbind(ceiling(ob[,1]),floor(ob[,2]))    # 'ob' as integer, which is start/end columns of 100% binding saturation
        obi[obi[,1]<1,1] <- 1                          # truncate 5' runoff
        obi[obi[,2]>100,2] <- 100                      # truncate 3' runoff
        obf <- ob-floor(ob)                            # fractional part of 'ob', which will be binding saturation % of flanking bins (1 on either side)
        heatmap <- matrix(0, NR, NC)                   # reboot heatmap with all 0 values
        for (i in 1:nrow(bound)) {
            j <- bound[i,1]
            if (obi[i,2]<obi[i,1]) {                   # extend>0 can lead to "bound" regions being entirely out of the window; skip these...
                failed <- failed + 1
            } else {
                #IM(i, nrow(bound), obi[i,1], obi[i,2])
                heatmap[j,obi[i,1]:obi[i,2]] <- 1
                if (obi[i,1]>1) heatmap[j,obi[i,1]-1] <- obf[i,1]    # fill in 5' flank value, if position contained within heatmap
                if (obi[i,2]<100) heatmap[j,obi[i,2]+1] <- obf[i,2]  # fill in 3' flank value, if position contained within heatmap
                matched <- matched + 1
            }
        }
        for (j in 1:NC) heatmap[heatmap[,j]>1,j] <- 1  # if overlapping bam peaks added up to > 1, truncate // by column to avoid excessive index vectors for large matrices
    } else {
        heatmap[unbound,] <- -1 * heatmap[unbound,]
    }
    message("PEAKS: ",nrow(bam.peaks)," | MATCH: ",matched," | FAIL: ",failed," | UN: ",length(unbound))
    
    if (do.meta) {
        meta.data <- cbind(meta.data, Bound=c(1:nrow(meta.data) %in% bound[,2]))
        list(heatmap=heatmap, bound=bound, meta.data=meta.data)
    } else {
        list(heatmap=heatmap, bound=bound)
    }
}


apa.names$dev <- c(apa.names$dev, "coverage.matrix.boundcolor")
coverage.matrix.boundcolor <- function(full, binary) {
    
    ## 'full': a list of heatmap matrices with bam-signal LFC0 (or other bam-signal values with minimum value=0)
    ## 'binary': the binarized version of 'full', after being run through coverage.matrix.bound()
    ## output: 'full', with sign switched for unbound regions.
    ##   Basically, based on 'binary', 'full' rows will either stay positive (bound) or become negative (unbound).
    ##   Then, you can cbind 'full' and plot it with a diverging palette, to see if the binarized version is acceptable, or whether peak call sig threshold should be changed, etc.
    
    if (length(full) != length(binary)) stop("'full' and 'binary' must be lists of equal length!\n")
    if (!all(sapply(full,dim) == sapply(binary,dim))) stop("'full' and 'binary' matrices must have same dimensions!\n")
    full.r <- sapply(full,range)
    bin.r <- sapply(binary,range)
    if (any(full.r<0)) stop("'full' values must all be >= 0!\n")
    if (any(bin.r<0 | bin.r>1)) stop("'binary' values must all be >= 0 and <= 1!\n")
    
    signed <- lapply(full,as.matrix)  # be ABSOLUTELY SURE that these are matrices
    for (i in 1:length(full)) {
        unbound <- which(rowSums(binary[[i]])==0)
        signed[[i]][unbound,] <- -signed[[i]][unbound,]
    }
    signed
}


apa.names$dev <- c(apa.names$dev, "coverage.matrix.cbind")
coverage.matrix.cbind <- function(x, spacer=10, sort.each=FALSE) {
    
    ## Takes a list of matrices 'x' and cbinds them all into one matrix, with NA spacers in between.
    ## Width of spacers, in columns, given by 'spacer'.
    ## 'sort.each=TRUE' will sort each matrix independently by rowSum (highest->lowest); matrices will NOT be cbound with the same row order (at least, same ordering is highly unlikely).
    ## Matrices MUST all have same N rows!
    
    L <- length(x)
    x <- lapply(x, as.matrix)
    spc <- matrix(NA, nrow(x[[1]]), spacer)
    if (sort.each) x <- lapply(x, function(y) y[rev(order(rowSums(y))),] )
    for (i in 1:(L-1)) x[[i]] <- cbind(x[[i]],spc)   # do not add spacer to final matrix
    y <- do.call(cbind, x)
    colnames(y) <- rep("",ncol(y))
    if (length(names(x))>0) colnames(y)[1] <- paste(names(x), collapse="; ")  # it's there if you want it
    y
}


apa.names$dev <- c(apa.names$dev, "coverage.matrix.compress")
coverage.matrix.compress <- function(x, reduce=10, spacer=NULL, binary=FALSE) {
    
    ## 'x' is either the output of coverage.matrix.cbind(), or the input to it.  Can be one matrix, or a list of them.
    ## reduces matrix columns by a factor of 'reduce', using the average.
    ## 'reduce' is the column reduction factor.
    ##   for instance if each matrix in 'x' if 100 columns, and 'reduce=20',
    ##   then 100/20 = 5 output columns, each one the mean of 20 original columns.
    ## 'spacer' only applies if 'x' was a matrix with spacer columns:
    ##   if 'NULL', then output will have same spacers as input
    ##   if numeric, then output will have spacers of that width (in columns).
    ##   if NA, output will not have spacer columns.
    ## 'binary' reduces each row to 0/1 based on whether nonzero values exist (assumes binarized bound/unbound heatmaps)
    
    if (is.ndfl(x)) {
        ## list of input matrices (we assume matrices)
        ## do nothing
        mat.in <- FALSE
        spacer.width <- NA
    } else if (is.matrix(x)) {
        ## cbound matrix
        ## convert cbound matrix back to the original list of input matrices
        mats <- find.runs(!is.na(x[1,]))  # columns of the original sub-matrices (non-spacer columns)
        x <- lapply(mats[ names(mats)=="TRUE" ], function(y) x[,y] )  # split into list of sub-matrices
        mat.in <- TRUE
        spacer.width <- diff(mats[[ which(names(mats)=="FALSE")[1] ]])+1
    } else {
        stop("'x' must be a matrix, or a list of matrices!\n")
    }

    if (binary) {
        y <- lapply(x, function(y) as.matrix(0+apply(y>0,1,any)) )
    } else {
        y <- lapply(x, function(y) {
            ends <- trunc(seq(0,ncol(y),length=reduce+1))
            starts <- ends[1:reduce]+1
            ends <- ends[2:(reduce+1)]
            sapply(1:reduce, function(i) rowMeans(y[,starts[i]:ends[i]]) )
        })
    }
    
    if (mat.in) {
        if (length(spacer)==0) {
            coverage.matrix.cbind(y, spacer.width)
        } else if (is.na(spacer)) {
            do.call(cbind,y)
        } else {
            coverage.matrix.cbind(y, spacer.width)
        }
    } else {
        y
    }
}


apa.names$dev <- c(apa.names$dev, "read.sample.peaks")
read.sample.peaks <- function(samps, paths) {
    
    S <- length(samps)
    out <- list( data=new.list(samps), files=name(rep("",S),samps) )
    paths <- gsub("//","/",paste0(paths,"/"))
    
    for (i in 1:S) {
        ## Look ONLY for "master" bed files elevated to the idr-root location (idr/), NOT all bed files (i.e. idr/*.bed, **NOT** idr/*/*.bed)
        allbeds <- c()
        for (p in paths) {
            spath <- paste0(p,samps[i])
            if (dir.exists(spath)) {
                candidates <- suppressWarnings(system(paste0("ls ",spath,"/idr/*.bed 2>/dev/null"), intern=TRUE))
                if (length(candidates)>0) {
                    out$files[i] <- candidates[1]  # take first, if for some reason > 1...
                    allbeds <- c(allbeds, candidates)
                }
            }
        }
        ## Post-test, was anything matched
        if (length(out$files[i])>0) {
            if (out$files[i]!="") {
                message(paste0("Sample '",samps[i],"' matched bed file: ",out$files[i]))
                b <- read.bed(out$files[i])
                ## data fixing -- not an issue with pipeline output, but if this runs on custom data...?
                if (ncol(b)<4) stop("Bed data must have at least 4 columns!!\n")
                if (ncol(b)<5) b <- cbind(b,1)
                if (ncol(b)<6) {
                    b <- cbind(b,"+")
                } else {
                    b[,6] <- "+"  # always ensure this -- can be an issue from pipeline IDR version, at the moment...
                }
                out$data[[i]] <- b
            } else {
                message(paste("No obvious sig-peaks bed file found for sample:",samps[i]))
                if (length(allbeds)>0) message(paste0("Found these beds files instead:\n",paste(paste("",allbeds),collapse="\n")))
            }
        } else {
            message(paste("No obvious sig-peaks bed file found for sample:",samps[i]))
            if (length(allbeds)>0) message(paste0("Found these beds files instead:\n",paste(paste("",allbeds),collapse="\n")))
        }
    }
    
    out
}


apa.names$dev <- c(apa.names$dev, "coverage.matrix.image")
coverage.matrix.image <- function(samp.df, cov.mat.paths, cov.mat.beds, sample.peaks, imgpref, bedname, kname="k5", extend=0, smooth=FALSE, spacer=10) {
    
    ## If all preliminary dataset generation is complete,
    ##  takes some arguments and writes two heatmaps: binarized and debugging
    ## Also returns a list with the heatmap components, matrices, hclust object, beds, etc.
    ## 'samp.df' is a dataframe with one row per sample to incorporate in heatmap, in order, and 4 columns:
    ##   col 1: sample name: names within cov.mat.paths[[bedname]][[kname]]
    ##   col 2: "IP or "input", indicating which dataset for that sample (usually "IP"!)
    ##   col 3: is the name of the matrix type from coverage.matrix.generate() you want the heatmap to use:
    ##          values can be 'raw', 'logrpm', 'pctmax', 'zscore', or 'LFC'.  Also can be 'zscore0' or 'LFC0' to use those matrices with negative values zeroed out.
    ##   col 4: ONLY when col 3 = "LFC" of "LFC0": which LFC matrix?  Usually "1", but in case of multiple inputs, give the number of the LFC matrix to use.
    ## 'cov.mat.paths' comes from calling load("/path/to/cov.mat.paths.RData") from some /home/apa/local/bin/prepareHeatmapMatrices run
    ## 'cov.mat.beds'  comes from calling load("/path/to/cov.mat.beds.RData"), which will be generated along with the above RData file.
    ## 'sample.peaks' is a list of peak-call bed-file data.frames, names of must be found in samp.df.  E.g. output of 'read.sample.peaks(...)$data'.
    ## 'imgpref' is n image prefix for the heatmap PNGs.  Writes <imgpref>.heatmap_binary.png and <imgpref>.heatmap_debugging.png.
    ## 'bedname' is a name within 'cov.mat.paths' and 'cov.mat.beds' indicating which peak set you want the heatmap based on.
    ## 'kname' is a matrix width value, like "k5" for 5kb, which is also a name within cov.mat.paths[[bedname]]
    ## 'extend' affects bound/unbound calls during heatmap binarization:
    ##   if two peaks are separated by this 'extend' bp or less, the region is considered "cobound".
    ## 'smooth' applies lowess smoothing to each matrix row
    
    if (bedname %nin% names(cov.mat.beds)) stop(paste0("Bed name '",bedname,"' not found in 'cov.mat.beds'!\n"))
    if (bedname %nin% names(cov.mat.paths)) stop(paste0("Bed name '",bedname,"' not found in 'cov.mat.paths'!\n"))
    if (kname %nin% names(cov.mat.paths[[bedname]])) stop(paste0("K-value name '",kname,"' does not exist for bed name '",bedname,"' in 'cov.mat.paths'!\n"))
    if (!all(samp.df[,1] %in% names(sample.peaks))) stop(paste0("Some sample names in 'samp.df' are not represented in 'sample.peaks'!\n"))
    if (!all(samp.df[samp.df[,2]=="IP",1] %in% names(cov.mat.paths[[bedname]][[kname]]$IP))) stop(paste0("Some sample names in 'samp.df' have no IP samples in for kname '",kname,"'!\n"))
    if (!all(samp.df[samp.df[,2]=="input",1] %in% names(cov.mat.paths[[bedname]][[kname]]$input))) stop(paste0("Some sample names in 'samp.df' have no input samples in for kname '",kname,"'!\n"))
    
    S <- nrow(samp.df)
    samples <- samp.df[,1]
    if (ncol(samp.df)==3) {
        ## add optional which.LFC column, if missing
        which.LFC=rep(NA,S)
        which.LFC[grep("LFC",samp.df[,3])] <- 1
        samp.df <- cbind(samp.df,which.LFC)
    }
    sample.peaks.tmp <- sample.peaks
    sample.peaks <- new.list(samp.df[,1])
    for (i in 1:S) sample.peaks[i] <- sample.peaks.tmp[which(names(sample.peaks.tmp)==names(sample.peaks)[i])]  # put in samp.df order; some may be empty
    rm(sample.peaks.tmp)
    
    message("Reading bed data...")
    ## get original row coords
    bed <- cov.mat.beds[[bedname]]$original
    k.ok <- bed[,which(colnames(bed)==paste0("OK.",kname))]
    bed <- bed[k.ok,1:6]
    ## get extended (heatmap) row coords
    bedx <- cov.mat.beds[[bedname]][[kname]]
    
    message("Loading heatmap matrices...")
    ## pull matrices for heatmap
    ## 'mats' will be in same order as samp.df
    mats <- lapply(1:S, function(i) coverage.matrix.compile(cov.mat.paths[[bedname]][[kname]][[samp.df[i,2]]][samp.df[i,1]], sub("0$","",samp.df[i,3]), samp.df[i,4])[[1]] )
    names(mats) <- samples
    if (smooth) {
        message("Applying lowess smoothing...")
        for (i in 1:S) {
            message(samples[i])
            mats[[i]] <- t(apply(mats[[i]], 1, function(x) lowess(x,f=0.1)$y ))
        }
    }
    ##if (any(grepl("0$",samp.df[,3]))) {
    ##    message("Zeroing out negative values...")
    ##    for (i in grep("0$",samp.df[,3])) mats[[i]] <- threshold(mats[[i]], 0, "lt")
    ##}
    message("Zeroing out negative values...")
    mats <- lapply(mats, function(x) threshold(x, 0, "lt") )  # REQUIRED FOR ALL MATRICES REGARDLESS OF TYPE: coverage.matrix.bound() requires nonnegative values only
    
    message("Binarizing heatmap matrices...")
    ## convert to binarized bound/unbound matrices
    bmats <- mats
    att.cols <- c()
    offset <- 0
    for (i in 1:S) {
        message(samples[i])
        nct <- ncol(mats[[i]]) + ifelse(i==S, 0, spacer)
        if (length(sample.peaks[[i]])==0) {
            ## no sample peaks; scale data to 0:1 for plottability with binary data
            ## list with only element 'heatmap' == faking the critical part of coverage.matrix.bound() output...
            if (samp.df[i,3]=="pctmax") {
                bmats[[i]] <- list(heatmap=threshold(mats[[i]],1,"gt"))
            } else {
                bmats[[i]] <- list(heatmap=mats[[i]]/max(mats[[i]]))
            }
            att.cols <- c(att.cols, (offset+1):(offset+nct))
        } else {
            bmats[[i]] <- coverage.matrix.bound(mats[[i]], bed, sample.peaks[[i]], extend=extend, binarize=bedx)
        }
        offset <- offset + nct
    }
    ## full binarized heatmap matrix for imaging, with 10-col NA spacers
    bmats2 <- coverage.matrix.cbind(lapply(bmats,"[[","heatmap"), spacer)
    
    message("Clustering...")
    ## compress 100-col matrices to 10-col matrices to accelerate clustering
    ##ALT: bmatsC <- coverage.matrix.compress(lapply(bmats,"[[","heatmap"), binary=TRUE)
    bmatsC <- lapply(bmats, function(x) rowSums(x$heatmap))
    ## compressed, spacerless heatmap matrix for clustering
    ##ALT: bmatsC2 <- coverage.matrix.cbind(bmatsC, 0)
    bmatsC2 <- do.call(cbind, bmatsC)
    ## row-hclust result for compressed heatmap matrix
    ##ALT: system.time({ bcl <- reorder.hclust2(hclust(dist(bmatsC2),"average"), bmatsC2, mean) })
    system.time({ bcl <- bclust(bmatsC2, present=1) })
    
    ## signed full version based on binding patterns (the "debugging" heatmap)
    dmats <- coverage.matrix.boundcolor(mats, lapply(bmats,"[[","heatmap"))
    ## signed version, as heatmap-ready matrix
    dmats2 <- coverage.matrix.cbind(lapply(dmats, function(x) {
        y <- threshold( threshold(x,quantile(nonzero(x),0.99,na.rm=TRUE),"gt"), quantile(nonzero(x),0.01,na.rm=TRUE),"lt")
        r <- range(y)
        for (i in 1:ncol(y)) {
            y[y[,i]<0,i] <- y[y[,i]<0,i]/abs(r[1])  # normalize all cols to [-1,1] so they all plot well with a single palette
            y[y[,i]>0,i] <- y[y[,i]>0,i]/abs(r[2])
        }
        y
    }),spacer)
        
    ## heatmap title
    #title <- gsub(";","   ",colnames(bmats2)[1])
    ## color thresholds for debugging heatmap
    #clim <- color.thresholds(sample(unlist(dmats),1E5), 0, 0.95)    # FIXME: THIS SHOULD NOW BE REDUNDANT
    ## img dims
    imgwd <- max(c(800, 100+112*S))
    imght <- max(c(800, nrow(bmats2)/12))
    
    message("Writing images...")
    ## plot binary bound/unbound heatmap
    png(paste0(imgpref,".heatmap_binary.png"), imgwd, imght)
    mipu(nameless(bmats2[bcl$order,]), pal="Reds0", show.scale=FALSE, main=samples, sub=paste("peaklist:",bedname), stagger=2)
    dev.off()
    message(paste0("Wrote: ",imgpref,"_binary.png"))
    
    ## plot signed-signal heatmap, with above row order
    png(paste0(imgpref,".heatmap_debugging.png"), imgwd, imght)
    #dm2 <- threshold(threshold(nameless(dmats2),clim[1],"lt"),clim[2],"gt")
    #IM(clim[1],clim[2])
    #return(dm2)
    attrib <- c()
    if (length(att.cols)>0) attrib <- list(list(cols=att.cols,palette="KW"))
    mipu(dmats2[bcl$order,], pal="RWB", col.center=0, show.scale=FALSE, main=samples, sub=paste("peaklist:",bedname), stagger=2, attrib=attrib)
    dev.off()
    message(paste0("Wrote: ",imgpref,"_debugging.png"))
    
    ## return data sets
    invisible(list(bed.name=bedname, k.name=kname, samples.df=samp.df, image.prefix=imgpref, extend=extend, smooth=smooth, spacer=spacer, sample.peaks=sample.peaks, full.matrices=mats, binary.matrices=bmats, debug.matrices=dmats, binary.clust=bcl, att.cols=att.cols))
}


apa.names$dev <- c(apa.names$dev, "coverage.matrix.replot")
coverage.matrix.replot <- function(x, sample.peaks, imgpref, spacer=10) {
    
    ## 'x' is the output from coverage.matrix.image()
    
    S <- nrow(x$samples.df)
    samples <- x$samples.df[,1]
    mats <- x$full.matrices
    dmats <- x$debug.matrices
    dmats2 <- coverage.matrix.cbind(dmats, spacer)
    bmats <- x$binary.matrices
    bmats2 <- coverage.matrix.cbind(lapply(bmats,"[[","heatmap"), spacer)
    bcl <- x$binary.clust
    
    sample.peaks.tmp <- sample.peaks
    sample.peaks <- new.list(x$samples.df[,1])
    for (i in 1:S) sample.peaks[i] <- sample.peaks.tmp[which(names(sample.peaks.tmp)==names(sample.peaks)[i])]  # put in samp.df order; some may be empty
    rm(sample.peaks.tmp)
    
    att.cols <- c()
    offset <- 0
    for (i in 1:S) {
        nct <- ncol(mats[[i]]) + ifelse(i==S, 0, spacer)
        if (length(sample.peaks[[i]])==0) {
            att.cols <- c(att.cols, (offset+1):(offset+nct))
        }
        offset <- offset + nct
    }
    
    ## heatmap title
    #title <- gsub(";","   ",colnames(bmats2)[1])
    ## color thresholds for debugging heatmap
    clim <- color.thresholds(sample(unlist(dmats),1E5), 0, 0.95)
    ## img dims
    imgwd <- max(c(800, 100+112*S))
    imght <- max(c(800, nrow(bmats2)/12))
    subtxt <- paste("peaklist:",x$bed.name)
    
    message("Writing images...")
    ## plot binary bound/unbound heatmap
    png(paste0(imgpref,".heatmap_binary.png"), imgwd, imght)
    mipu(nameless(bmats2[bcl$order,]), pal="Reds0", show.scale=FALSE, main=samples, sub=subtxt, stagger=2)
    dev.off()
    message(paste0("Wrote: ",imgpref,"_binary.png"))
    
    ## plot signed-signal heatmap, with above row order
    png(paste0(imgpref,".heatmap_debugging.png"), imgwd, imght)
    dm2 <- threshold(threshold(nameless(dmats2[bcl$order,]),clim[1],"lt"),clim[2],"gt")
    mipu(dm2, pal="RWB", col.center=0, show.scale=FALSE, main=samples, sub=subtxt, stagger=2, att.cols=att.cols, att.pal="KW")
    dev.off()
    message(paste0("Wrote: ",imgpref,"_debugging.png"))
    
    ## return data sets
    x$spacer <- spacer
    x$image.prefix <- imgpref
    x$sample.peaks <- sample.peaks
    x <- x[qw(bed.name,k.name,samples.df,image.prefix,extend,smooth,spacer,sample.peaks,full.matrices,binary.matrices,debug.matrices,binary.clust)]
    invisible(x)
}


