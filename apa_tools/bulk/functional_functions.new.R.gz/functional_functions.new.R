

apa.names$dev <- c(apa.names$dev, "pre.EdgeR")
pre.EdgeR <- function(counts, group, annot, contrasts, FDR=0.05, frange=c(1,10), model=NULL) {
    
    ## Stripped-down version of run.EdgeR that tests N DE genes at given FDR, for a range of minimum-count-per-gene thresholds
    ## The idea is that pre-restricting genes to only those with nonzero counts (in any sample) is less than optimal,
    ##  and that some (slightly) higher value (<= frange[2]) is the minimum-counts-per-gene, in any sample, to optimize EdgeR's SNR.
    ## pre.EdgeR takes a table of counts and runs EdgeR with varying minimum-expression filters to find the optimal filter, if any.

    FDR.list <- rev(c(0,10^-c(10:2),0.05,seq(0.1,1,0.1)))   # MUST MATCH FDR LIST FROM 'run.EdgeR'
    FDR.names <- c( round(FDR.list[FDR.list>=0.01],2), format(FDR.list[FDR.list<0.01],scientific=TRUE,digits=2) )  # print values
    f <- which(FDR.list==FDR)
    if (is.na(f)) stop(paste0("Given FDR '",FDR,"' is not a precalculated FDR limit!\nPlease use one of the following:\n ",paste(FDR.names,collapse=", "),"\n(Thresholds are applied as <=, except for FDR=1, which is <)"))

    out <- new.list(paste("Counts >=",frange[1]:frange[2]))
    for (i in frange[1]:frange[2]) {
        w <- which(rowSums(counts>=i)>0)
        message(paste0("Testing ",length(w)," genes with counts >= ",i," ..."))
        e <- run.EdgeR(counts[w,], group, annot[w,], contrasts, model, pre=TRUE)
        de <- do.call(rbind, lapply(e$DE.table, function(x) x[f,2:3]))
        de.vec <- unlist(lapply(1:nrow(de), function(i) de[i,] ))
        names(de.vec) <- paste0(rep(rownames(de),each=2),".",qw(UP,DN))
#        out[[i]] <- as.data.frame(c( pseudo.lib.size=list(e$dge$pseudo.lib.size), common.dispersion=list(e$dge$common.dispersion), as.list(de.vec)))
        out[[i]] <- as.data.frame(as.list(de.vec))
    }
    do.call(rbind, out)
}


apa.names$dev <- c(apa.names$dev, "run.EdgeR")
run.EdgeR <- function(counts, group, annot, contrasts, M=NULL, model=NULL, pre=FALSE) {
    
    ## runs basic EdgeR the way I usually do
    ## 'counts' is a gene counts matrix in linear scale
    ## 'group' is the group factor required by EdgeR
    ## 'annot' is a gene-annotation dataframe, same row order as 'counts'
    ## 'contrasts' is a list of pairs of factor levels to contrast; must be numeric, e.g. c(2,1); NUMERATOR FIRST, DENOMINATOR SECOND
    ## 'M' provides an alternate M value for RPKMs than colSums(counts).  This will become 'lib.size' in the DGEList() call.
    ## 'model' is a string with the model expression to fit, if not default
    ## 'pre' is intended only for use by pre.EdgeR(): stops calculation of expression datasets.
    
    require(edgeR)
    
    ## STAGE 0: test inputs, prepare output structures
    ###### still need to finish input-testing code
    if (nrow(counts)!=nrow(annot)) stop("'counts' and 'annot' must have same number of rows!\n")
    uxl <- mgrep(c("Uxon.?Len","Uxonic.?Len","Exon.?Len","Exonic.?Len","cDNA.?Len"),colnames(annot),TRUE)
    uxl <- uxl[!is.na(uxl)]
    if (length(uxl)>0) {
        exonic.len <- annot[,uxl[1]]
    } else {
        stop("Could not find a column in 'annot' which appears to have gene exonic length: need this for RPKM calculation!\n")
    }
    
    if (length(M)==0) M <- colSums(counts)
    C <- length(contrasts)
    if (length(names(contrasts))==0) names(contrasts) <- gsub(" ","",sprintf(paste0("Contrast%0",nchar(C),"i"),1:C))
    cnull <- new.list(names(contrasts))
    
    output <- list(
        input=list(     # inputs to run.EdgeR()
            counts=counts,
            annot=annot,
            group=group,
            factors=data.frame(LEVEL=as.numeric(group), LABEL=as.character(group), COLNAME=colnames(counts), stringsAsFactors=FALSE, check.names=FALSE),  # 'group' factor examination
            contrasts=contrasts,
            M=M,
            model=model
        ),
        expr=list(
            counts.all=c(),     # EdgeR-normalized counts
            counts.avg=c(),     # sample-average normalized counts
            counts.sd=c(),      # sample stdevs for normalized counts
            rpkms.all=c(),      # RPKMs based on above counts
            rpkms.avg=c(),      # sample-average RPKMs
            rpkms.sd=c(),       # sample stdevs for RPKMs
            EdgeR.logCPM=c()    # EdgeR logCPM (only one value per gene per dataset)
        ),
        dge=cnull,         # DGEList output
        et=cnull,          # exactTest output
        top=cnull,         # modified top$table output, including RPKM-based M,A values
        DE.table=cnull     # DE-at-FDR table
    )
    
    ## STAGE 1: initial EdgeR
    ######  NOT READY FOR CUSTOM MODELS  ######
    message("Running EdgeR...")
    output$dge <- estimateTagwiseDisp( estimateCommonDisp( calcNormFactors( DGEList(counts=counts, lib.size=M, group=group) ) ) )
    
    ## STAGE 2: expression values per dataset: normalized counts & RPKMs
    if (!pre) {
        message("Calculating expression datasets...")
        output$expr$counts.all <- zapsmall(output$dge$pseudo.counts)  # should have same row order as 'counts'
        output$expr$counts.all <- output$expr$counts.all
        output$expr$counts.avg <- zapsmall(aggregate.cols(output$expr$counts.all, list(group), mean))
        output$expr$counts.sd <- zapsmall(aggregate.cols(output$expr$counts.all, list(group), sd))
        colnames(output$expr$counts.all) <- paste0(colnames(output$expr$counts.all), ".Cpm")
        colnames(output$expr$counts.avg) <- paste0(colnames(output$expr$counts.avg), ".CpmAvg")
        colnames(output$expr$counts.sd) <- paste0(colnames(output$expr$counts.sd), ".CpmSd")
        
        output$expr$rpkms.all <- zapsmall(1E3*output$expr$counts.all/exonic.len)
        output$expr$rpkms.avg <- zapsmall(aggregate.cols(output$expr$rpkms.all, list(group), mean))
        output$expr$rpkms.sd <- zapsmall(aggregate.cols(output$expr$rpkms.all, list(group), sd))
        colnames(output$expr$rpkms.all) <- sub(".Cpm", ".Rpkm", colnames(output$expr$rpkms.all))
        colnames(output$expr$rpkms.avg) <- paste0(colnames(output$expr$rpkms.avg), ".RpkmAvg")
        colnames(output$expr$rpkms.sd) <- paste0(colnames(output$expr$rpkms.sd), ".RpkmSd")
    }
    
#### IGNORE -- we are not adjusting zeroes at all
#    ## ADJUST ZEROES __ONLY_AFTER__ ALL MATH HAS BEEN DONE  ...otherwise, you get strange behavior of present/absent points in the MA plots
#    output$expr$pseudo$count <- min(nonzero(output$expr$counts.all))/2
#    output$expr$pseudo$rpkm <- min(nonzero(output$expr$rpkms.all))/2
#    output$expr$counts.all[output$expr$counts.all==0] <- output$expr$pseudo$count
#    output$expr$counts.avg[output$expr$counts.avg==0] <- output$expr$pseudo$count
#    output$expr$rpkms.all[output$expr$rpkms.all==0] <- output$expr$pseudo$rpkm
#    output$expr$rpkms.avg[output$expr$rpkms.avg==0] <- output$expr$pseudo$rpkm
    
    ## STAGE 3: prepare post-DGE EdgeR datasets
    message(paste0("Preparing ",C," contrast dataset",ifelse(C>1,"s",""),"..."))
    FDR.list <- c(0,10^-c(10:2),0.05,seq(0.1,1,0.1))
    names(FDR.list) <- c("0",paste0("1E-",10:3),0.01,0.05,seq(0.1,0.9,0.1),"<1")
    FDR.list <- rev(FDR.list)  # decreasing order
    for (i in 1:C) {
        output$et[[i]] <- exactTest(output$dge, pair=rev(contrasts[[i]]))  # REVERSE CONTRAST: DENOMINATOR FIRST !!!!!
        output$top[[i]] <- topTags(output$et[[i]], nrow(counts))$table
        output$top[[i]] <- output$top[[i]][match(rownames(counts),rownames(output$top[[i]])),]  # put in rownames order
        output$top[[i]] <- data.frame(
            output$top[[i]][,c(1,3,4)],      # drop logCPM; junk statistic (but keeping a copy in output$expr)
            DE=sign(output$top[[i]]$logFC)   # 'DE' assumes p <= 1; filter later with 'post.EdgeR()'
        )
        if (!pre) {
            arp <- as.matrix(output$expr$rpkms.avg[,contrasts[[i]]])
            arp <- arp + min(nonzero(arp))/2
            output$top[[i]] <- cbind(
                output$top[[i]],
                A=log2(sqrt(apply(arp,1,prod))),  # RPKM-based 'A' value for MA plots
                M=log2(apply(arp,1,quot))         # RPKM-based 'M' value for MA & volcano plots
            )
        }
        output$DE.table[[i]] <- do.call(rbind, lapply(1:length(FDR.list), function(j) {
            is.sig <- output$top[[i]]$FDR<=FDR.list[j]
            if (FDR.list[j]==1) is.sig <- output$top[[i]]$FDR<1  # don't want <= 1; that would be all genes
            data.frame(FDR=names(FDR.list)[j], UP=sum(is.sig & output$top[[i]]$DE==1), DOWN=sum(is.sig & output$top[[i]]$DE==-1), stringsAsFactors=FALSE, check.names=FALSE)
        }))
    }
    rnames.et <- rownames(output$et[[1]]$table)
    if (!pre) output$expr$EdgeR.logCPM <- matrix(output$et[[1]]$table$logCPM[match(rownames(counts),rnames.et)], ncol=1, dimnames=list(rnames.et,"logCPM"))
    
    output
}


apa.names$dev <- c(apa.names$dev, "post.EdgeR")
post.EdgeR <- function(edgeR.out, outpath="EdgeR_out", functional.org=NULL, clobber=FALSE, raw.p=FALSE, FDR=0.05, func.FDR=0.05, term.min.genes=3, ID.convert=NULL, DB=NULL, SPIA.pathways=NULL, debug=FALSE) {
    
    ## extracts/processes significant genes and creates outputs
    ## 
    ## Arguments:
    ## 'edgeR.out' is an output object from run.EdgeR()
    ## 'outpath': location to write results.
    ## 'functional.org': the string "Genus species" for the organism in question, e.g. "Mus musculus".  Must match organisms from the sitewide command 'showTaxa'.
    ## 'clobber': if 'outpath' already exists, overwite?
    ## 'raw.p=TRUE' will switch from selecting on adjusted p-values (FDR) to selecting on the raw p-values
    ## 'FDR': significance cutoff for DE GENES, using adjusted p-values (or raw, if raw.p=TRUE)
    ## 'func.FDR': significance cutoff for ENRICHED TERMS, using adjusted p-values (or raw, if raw.p=TRUE)
    ## 'term.min.genes': minimum N genes for a GO or KEGG term to be retained
    ## 
    ## ID.convert is list with any of 2 elements, 'GOXREF' and 'ENTREZ'.  If specified, each must be a 2-col matrix/dataframe with column 1 = analysis IDs (usually Ensembl) and column 2 = the other IDs.
    ##   For 'ENTREZ', obviously, column 2 must be Entrez IDs.  For 'GOXREF', you have to know what ID type to use -- see next sentence.
    ##   If analyzing with an indexed genome/transcriptome, the GO_xref.txt and entrez.txt files already exist in the transcriptome directories, e.g. "mm10/Ens_80/mm10.Ens_80.{GO_xref,entrez}.txt" exist.
    ## 'DB': OPTIONAL list of database versions to use.  Names work the same as 'ID.convert'.  Databases are sought as standard locations:
    ##   GO will be the latest "go_yyymm" on host mysql-dev ; KEGG and SPIA will be latest "yyyymm" in /n/data1/KEGG/<org>/.
    ##    i.e. "DB=list(GO="alt_go_db_name", KEGG="/path/to/KEGG/Ensembl_term_DB.txt").
    ##
    
    message("")  # provide visual gap in STDOUT stream
    launchpath <- getwd()
    outpath <- fixpath(outpath, clobber="ignore")
    
    functional <- FALSE
    if (length(functional.org)>0) {
        ## expecting "Genus species" string, e.g. "Homo sapiens"
        if (grepl("_",functional.org)) message(paste0("WARNING: you probably didn't want those underscores in '",functional.org,"'.  May or may not fail below..."))
        odat <- unlist(strsplit(sub("^ +","",system(paste0("bash -c '/home/apa/local/bin/showTaxa | grep \"",functional.org,"\"'"), intern=TRUE)), " +"))
        taxon <- as.numeric(odat[[1]])  # e.g. 9606
        kegg.org <- paste0(tolower(substr(odat[[2]],1,1)),substr(odat[[3]],1,2))  # e.g. "hsa"
#        no.GO.hosts <- "mango"
        no.GO.hosts <- c()
        no.GO.server <- ifelse(.HOSTNAME %in% no.GO.hosts, TRUE, FALSE)  # servers from which GO DB not accessible (e.g. OS-related Perl DBI issues)
        functional <- TRUE
        do.SPIA <- FALSE  # initially
        
        if (length(DB$GO)==0) {
            if (no.GO.server) {
                message(paste0("GO databases not accessible from this server (",.HOSTNAME,").  Skipping GO analysis."))
                DB$GO <- NA
            } else {
                if (length(taxon)==0) {
                    message(paste("Unable to identify organism '",functional.org,"'!  Skipping GO analysis."))
                } else {
                    DB$GO <- system("bash -c '/home/apa/local/bin/GO_Tools --showdbs | grep . | tail -n +2 | head -1'", intern=TRUE)
                    if (length(DB$GO)>0) {
                        message(paste0("Found latest GO DB '",DB$GO,"'"))
                    } else {
                        message(paste("Unable to find any GO DBs -- check availability of server 'mysql-dev'?  Skipping GO analysis."))
                        DB$GO <- NA
                    }
                }
            }
        }
        do.GO <- ifelse(is.na(DB$GO), FALSE, TRUE)
        
        if (length(DB$KEGG)==0) {
            DB$KEGG <- system(paste0("bash -c 'ls /n/data1/KEGG/",kegg.org,"/*/*_DB.txt | grep -v current | sort | tail -1'"), intern=TRUE)  # sort | tail -1 should get latest, as dirs are 'yyyymm'
            if (length(DB$KEGG)>0) {
                message("Found latest pertinent KEGG DB '",DB$KEGG,"'")
            } else {
                message("Unable to identify KEGG DB for KEGG org code '",KEGG.org,"'!  Skipping KEGG and SPIA analysis.")
                DB$KEGG <- NA
            }
        }
        do.KEGG <- ifelse(is.na(DB$KEGG), FALSE, TRUE)
        
        if (length(SPIA.ID.conv)>0) {
            ## SPIA ID converter given, so run SPIA
            do.SPIA <- TRUE
        } else if (!any(is.na(as.numeric(rownames(edgeR.out$input$counts))))) {
            ## given gene IDs are all numeric, assume Entrez IDs
            do.SPIA <- TRUE
        }
        if (do.SPIA) {
            DB$SPIA <- system(paste0("bash -c 'ls /n/data1/KEGG/",kegg.org,"/*/*RData | grep -v current | sort | tail -1'"), intern=TRUE)  # sort | tail -1 should get latest, as dirs are 'yyyymm'
            if (length(DB$SPIA)==0) {
                if (!(functional.org %in% c("Homo sapiens","Mus musculus"))) {
                    message("*** Failed to identify any SPIA RData objects!  Default objects exist only for human & mouse.  No SPIA analysis will be performed\n")
                    sleep(1)
                    do.SPIA <- FALSE
                }
            } else {
                message(paste0("Found latest pertinent SPIA RData '",DB$SPIA,"'"))
            }
        }
        
        if (!do.GO & !do.KEGG & !do.SPIA) {
            functional <- FALSE
        } else {
            ## Directory prep for functional analysis outputs
            if (do.GO | do.KEGG) {
                FC.dir <- paste0(outpath,"/FatiClone")
                system(paste("mkdir -p",FC.dir))
                FC.dir <- normalizePath(FC.dir)
                if (do.GO) {
                    GODB.g.dir <- paste0(FC.dir,"/GODB.g")
                    GODB.o.dir <- paste0(FC.dir,"/GODB.o")
                    if (!dir.exists(GODB.g.dir)) system(paste("mkdir",GODB.g.dir))
                    if (!dir.exists(GODB.o.dir)) system(paste("mkdir",GODB.o.dir))
                    GODB.g.dir <- normalizePath(GODB.g.dir)
                    GODB.o.dir <- normalizePath(GODB.o.dir)
                }
                if (do.KEGG) {
                    KEGG.g.dir <- paste0(FC.dir,"/KEGG.g")
                    KEGG.o.dir <- paste0(FC.dir,"/KEGG.o")
                    if (!dir.exists(KEGG.g.dir)) system(paste("mkdir",KEGG.g.dir))
                    if (!dir.exists(KEGG.o.dir)) system(paste("mkdir",KEGG.o.dir))
                    KEGG.g.dir <- normalizePath(KEGG.g.dir)
                    KEGG.o.dir <- normalizePath(KEGG.o.dir)
                }
            }
            if (do.SPIA) {
                SPIA.dir <- paste0(outpath,"/SPIA")
                if (!dir.exists(SPIA.dir)) system(paste("mkdir",SPIA.dir))
                SPIA.dir <- normalizePath(SPIA.dir)
            }
        }
    }
    
    C <- length(edgeR.out$input$contrasts)
    Cnames <- names(edgeR.out$input$contrasts)
    Cprefix <- paste0(outpath,"/",Cnames)
    cnull <- sig.tab <- new.list(Cnames)
    vnull <- new.list(c("up","down","all"))  # shell for venn diagram areas (up-DE, down-DE, all-DE versions)
    fnull <- new.list(Cnames, elem=new.list(c("GO","KEGG","SPIA")))  # shell for functional data
    if (length(FDR)==1) FDR <- rep(FDR,C)
    
    output <- list(
        input=list(       # inputs to post.EdgeR()
            edgeR.out=deparse(substitute(edgeR.out)),
            FDR=FDR,
            outpath=outpath,
            clobber=clobber,
            functional.org=functional.org,
            func.FDR=func.FDR,
            term.min.genes=term.min.genes,
            GO.ID.conv=ID.convert$GOXREF,
            Entrez.ID.conv=ID.convert$ENTREZ,
            GO.DB=DB$GO,
            KEGG.DB=DB$KEGG,
            SPIA.DB=DB$SPIA
        ),
        xls=c(),          # master XLS dataset with everything except contrast-wise EdgeR data
        sig=cnull,        # 'top' subsets for significant genes
        hmx=cnull,        # DE genes log2(RPKM+1) heatmap
        hmz=cnull,        # DE genes zscore heatmap
        hcx=cnull,        # row and column clustering for 'hmx' (orderings only, no hclust() objects)
        hcz=cnull,        # row and column clustering for 'hmz' (orderings only, no hclust() objects)
        to.GO=cnull,      # lists of DE genes for functional analysis
        venn=vnull,       # venn.areas objects for DE genes
        functional=fnull  # functional enrichment datasets
    )
    
    rn.master <- rownames(edgeR.out$input$counts)  ## ALL DATASETS SHOULD HAVE THIS ROW ORDER
    all.top <- lapply(1:C, function(i) {
        x <- edgeR.out$top[[i]]
        x$DE[x$FDR>FDR[i]] <- 0
        colnames(x) <- paste0(Cnames[i],".",colnames(x))
        x
    })  # single dataframe with all 'top' columns from all contrasts; 'DE' columns corrected according to FDR cutoff
    de.mat <- do.call(cbind, lapply(all.top, "[", , 4))  # "DE column, whatever its actual name
    n.de.up <- sum(apply(de.mat==1,1,any))
    n.de.down <- sum(apply(de.mat==-1,1,any)) # this approach allows a single gene to count towards up AND down, if it is so in different contrasts
    
    if (any(grepl("GeneID",colnames(edgeR.out$input$annot)))) {
        ## assuming /n/data1/genomes/indexes-style genedata.txt was provided
        ID.cols <- edgeR.out$input$annot[,1:2]
        annot.cols <- edgeR.out$input$annot[,3:ncol(edgeR.out$input$annot)]
        freezecol <- 2
    } else {
        ## patch in 'GeneID' column as rownames from 'top' -- need this column below
        ID.cols <- matrix(rn.master, ncol=1, dimnames=list(c(),"GeneID"))
        annot.cols <- edgeR.out$input$annot
        freezecol <- 1
    }
    xls.all <- list(
        all.genes.1=ID.cols,
        all.genes.2=data.frame(edgeR.out$expr$rpkms.avg, edgeR.out$expr$rpkms.sd, edgeR.out$expr$counts.avg, edgeR.out$expr$counts.sd, annot.cols, stringsAsFactors=FALSE, check.names=FALSE),
        sample.rpkms=data.frame(ID.cols, edgeR.out$expr$rpkms.all, stringsAsFactors=FALSE, check.names=FALSE),
        sample.counts=data.frame(ID.cols, edgeR.out$expr$counts.all, stringsAsFactors=FALSE, check.names=FALSE)
    )
    
    message("\nProcessing contrasts...")
    for (i in 1:C) {
        
        this.top <- edgeR.out$top[[i]]  # has same row order as xls.all
        this.top$DE[this.top$FDR>FDR[i]] <- 0
        output$sig[[i]] <- this.top[this.top$DE!=0,]
        nsig <- nrow(output$sig[[i]])
        w.up <- which(this.top$DE==1)
        w.dn <- which(this.top$DE==-1)
        n.up <- length(w.up)
        n.dn <- length(w.dn)
        
        x <- table(this.top$DE)
        sig.tab[[i]] <- x[match(-1:1,names(x))]  # N up, non, down
        svg.use.cols <- real(mgrep(c("Gene.?ID","(Gene.?)?Symbol","(Gene.?)?Name","(Gene.?)?SimpleBiotype","(Gene.?)?Description"),colnames(edgeR.out$input$annot)))
        if (length(svg.use.cols)<3) svg.use.cols <- 1:ifelse(ncol(edgeR.out$input$annot)>5,5,ncol(edgeR.out$input$annot))  ## Some other kind of dataset, apparently.  Just take up to first 5 cols where possible.
        svg.ann <- edgeR.out$input$annot[,svg.use.cols]  # for SVG plot
        message(paste0(" ",Cnames[i]," FDR:",FDR[i]," UP:",sum(this.top$DE==1)," DOWN:",sum(this.top$DE==-1)))
        
        ## MA plots, static
        png(paste0(Cprefix[i],".MA.png"), 600, 600)
        par(cex=1.2, las=1)
        ma <- this.top[,c("A","M")]
        plot(ma, col=0, xlab="Log2 Mean Expr", ylab="Log2 Fold Change", main=paste(Cnames[i],"MA Plot"))
        abline(h=0, col=1)
        points(ma[this.top$DE==0,,drop=FALSE], col=8)
        for (p in 1:2) {  # overplotting makes points "bold"
            points(ma[w.up,,drop=FALSE], col=2)
            points(ma[w.dn,,drop=FALSE], col=3)
        }
        legend("topright", col=2:3, pch=1, legend=c(paste(length(w.up),"Up"),paste(length(w.dn),"Down")))
        dev.off()
        
        ## Volcano plots, static
        png(paste0(Cprefix[i],".volcano.png"), 600, 600)
        par(cex=1.2, las=1)
        vp <- cbind(this.top$M, -log10(this.top$FDR))
        plot(vp, col=0, xlab="Log2 Fold Change", ylab="-Log10(FDR)", main=paste(Cnames[i],"Volcano Plot"))
        points(vp[this.top$DE==0,,drop=FALSE], col=8)
        for (p in 1:2) {  # overplotting makes points "bold"
            points(vp[w.up,,drop=FALSE], col=2)
            points(vp[w.dn,,drop=FALSE], col=3)
        }
        abline(v=0, col=1)
        legend("topright", col=2:3, pch=1, legend=c(paste(length(w.up),"Up"),paste(length(w.dn),"Down")))
        dev.off()
        
        ## MA & Volcano plots, interactive
        df <- data.frame(ma,this.top$FDR,svg.ann)
        #message("ANN DF: ",nrow(df))
        SVG.scatterplot(df, style="MA", paste0(Cprefix[i],".MA.svg"), cex=1.2, main=paste(Cnames[i],"MA Plot"))
        SVG.scatterplot(df, style="volcano", paste0(Cprefix[i],".volcano.svg"), cex=1.2, main=paste(Cnames[i],"Volcano Plot"))
        
        if (nsig>0) {
            
            output$to.GO[[i]] <- cbind(GENE=rownames(output$sig[[i]]),GROUP=paste0(sub("1","",sign(output$sig[[i]]$DE)),Cnames[i]))
            colnames(output$to.GO[[i]]) <- qw("GENE","GROUP")
            output$to.GO[[i]] <- list( GODB=output$to.GO[[i]], KEGG=output$to.GO[[i]] )
            if (length(GO.ID.conv)>0) output$to.GO[[i]]$GODB[,1] <- GO.ID.conv[match(output$to.GO[[i]]$GODB[,1],GO.ID.conv[,1]),2]
            if (length(KEGG.ID.conv)>0) output$to.GO[[i]]$KEGG[,1] <- KEGG.ID.conv[match(output$to.GO[[i]]$KEGG[,1],KEGG.ID.conv[,1]),2]
            
            output$hmx[[i]] <- as.matrix(log2(edgeR.out$expr$rpkms.all[c(w.up,w.dn),,drop=FALSE]+1))
            colnames(output$hmx[[i]]) <- sub(".Rpkm","",colnames(output$hmx[[i]]))
            output$hmz[[i]] <- t(scale(t(output$hmx[[i]])))  # gene z-scores
            ncols <- ncol(output$hmx[[i]])
            hmx.avg <- as.matrix(log2(edgeR.out$expr$rpkms.avg[c(w.up,w.dn),,drop=FALSE]+1))
            hmz.avg <- t(scale(t(hmx.avg)))
            
            output$hcx[[i]] <- output$hcz[[i]] <- new.list(c("row","col.all","col.grp"))
            if (n.up>0) {
                up.rows <- 1:n.up  # 'up' rows (arranged first in output$hmx[[i]])
            } else {
                up.rows <- c()
            }
            if (n.dn>1) {
                dn.rows <- (n.up+1):nrow(output$hmx[[i]])  # 'down' rows (arranged second in output$hmx[[i]])
            } else if (n.dn>0) {
                dn.rows <- n.up+1  # 'down' rows (arranged second in output$hmx[[i]])
            } else {
                dn.rows <- c()
            }
            #IM("UP:",up.rows)
            #IM("DN:",dn.rows)
            
            ## Set heatmap row orders
            if (n.up>2) {
                up.ordx <- up.rows[reorder.hclust2(hclust(dist    (output$hmx[[i]][up.rows,,drop=FALSE]),"average"), output$hmx[[i]], mean)$order]   # cluster up separately
                up.ordz <- up.rows[reorder.hclust2(hclust(distance(output$hmz[[i]][up.rows,,drop=FALSE]),"average"), output$hmz[[i]], mean)$order]
            } else if (length(up.rows)>1) {
                up.ordx <- up.ordz <- up.rows[rev(order(rowMeans(output$hmx[[i]][up.rows,,drop=FALSE])))]
            } else if (length(up.rows)>0) {
                up.ordx <- up.ordz <- up.rows
            } else {
                up.ordx <- up.ordz <- c()
            }
            if (n.dn>2) {
                dn.ordx <- dn.rows[reorder.hclust2(hclust(dist    (output$hmx[[i]][dn.rows,,drop=FALSE]),"average"), output$hmx[[i]], mean)$order]  # cluster down separately
                dn.ordz <- dn.rows[reorder.hclust2(hclust(distance(output$hmz[[i]][dn.rows,,drop=FALSE]),"average"), output$hmz[[i]], mean)$order]
            } else if (length(dn.rows)>1) {
                dn.ordx <- dn.ordz <- dn.rows[rev(order(rowMeans(output$hmx[[i]][dn.rows,,drop=FALSE])))]
            } else if (length(dn.rows)>0) {
                dn.ordx <- dn.ordz <- dn.rows
            } else {
                dn.ordx <- dn.ordz <-c()
            }
            output$hcx[[i]]$row <- c(up.ordx,dn.ordx)
            output$hcz[[i]]$row <- c(up.ordz,dn.ordz)
            
            ## Set heatmap column orders
            if (ncols>2) {
                output$hcx[[i]]$col.all <- reorder.hclust2(hclust(dist(t(output$hmx[[i]])),"average"), t(output$hmx[[i]]), mean)$order
                output$hcz[[i]]$col.all <- hclust(distance(t(output$hmz[[i]])),"average")$order
            } else {  # guaranteed at least 2 cols, else no DE!!  (actually, 2+ reps required, so really min 4 cols...)
                output$hcx[[i]]$col.all <- rev(order(colMeans(output$hmx[[i]])))
                output$hcz[[i]]$col.all <- output$hcx[[i]]$col.all
            }
            
            ## Correct group-vector -> hmx.avg col-number correspondence, if necessary
            grp.n <- as.numeric(edgeR.out$input$group)
            if (min(grp.n)>1) grp.n <- grp.n-min(grp.n)+1
            
            ## Initialize grouped col order by clustering within groups
            output$hcx[[i]]$col.grp <- lapply( split(1:ncol(output$hmx[[i]]), grp.n), function(x) {
                if (length(x)>2) {
                    x[ reorder.hclust2(hclust(dist(t(output$hmx[[i]][,x,drop=FALSE])),"average"), t(output$hmx[[i]][,x,drop=FALSE]), mean)$order ]
                } else if (length(x)>1) {
                    x[ rev(order(colMeans(output$hmx[[i]][,x,drop=FALSE]))) ]
                } else {
                    x
                }
            })
            output$hcz[[i]]$col.grp <- lapply( split(1:ncol(output$hmz[[i]]), grp.n), function(x) {
                if (length(x)>2) {
                    x[ hclust(distance(t(output$hmz[[i]][,x,drop=FALSE])),"average")$order ]
                } else if (length(x)>1) {
                    x[ rev(order(colMeans(output$hmx[[i]][,x,drop=FALSE]))) ]
                } else {
                    x
                }
            })
            ## Cluster between groups and unpack orderings
            ## ONLY WORKS IF HMX.AVG COLUMNS IN SAME ORDER AS 'GROUP'!!!
            if (ncol(hmx.avg)>2) {
                output$hcx[[i]]$col.grp <- unlist(output$hcx[[i]]$col.grp[ reorder.hclust2(hclust(dist(t(hmx.avg)),"average"), t(hmx.avg), mean)$order ])
                output$hcz[[i]]$col.grp <- unlist(output$hcz[[i]]$col.grp[ hclust(distance(t(hmz.avg)),"average")$order ])   ## ONLY WORKS IF HMZ.AVG COLUMNS IN 'GROUP' ORDER!!!
            } else {
                output$hcx[[i]]$col.grp <- unlist(output$hcx[[i]]$col.grp[rev(order(colMeans(hmx.avg)))])
                output$hcz[[i]]$col.grp <- unlist(output$hcz[[i]]$col.grp[rev(order(colMeans(hmx.avg)))])   ## ONLY WORKS IF HMZ.AVG COLUMNS IN 'GROUP' ORDER!!!
            }
            
            ## Plot heatmaps
            imgwd <- 400+30*ncol(output$hmx[[i]])
            imght <- max(c(500,250+nrow(output$hmx[[i]])))

            png(paste0(Cprefix[i],".hmx.ordered.png"), imgwd, imght)
            mipu(output$hmx[[i]][output$hcx[[i]]$row,,drop=FALSE], pal="Reds", cex=1.2, pmar=c(10,1), main=paste0(Cnames[i],", ",nsig," DE Gene Log2(RPKMs+1)"))
            dev.off()
            
            png(paste0(Cprefix[i],".hmx.clust.all.png"), imgwd, imght)
            mipu(output$hmx[[i]][output$hcx[[i]]$row,output$hcx[[i]]$col.all,drop=FALSE], pal="Reds", cex=1.2, pmar=c(10,1), main=paste0(Cnames[i],", ",nsig," DE Gene Log2(RPKMs+1)"))
            dev.off()
            
            png(paste0(Cprefix[i],".hmx.clust.grp.png"), imgwd, imght)
            mipu(output$hmx[[i]][output$hcx[[i]]$row,output$hcx[[i]]$col.grp,drop=FALSE], pal="Reds", cex=1.2, pmar=c(10,1), main=paste0(Cnames[i],", ",nsig," DE Gene Log2(RPKMs+1)"))
            dev.off()
            
            png(paste0(Cprefix[i],".hmz.ordered.png"), imgwd, imght)
            mipu(output$hmz[[i]][output$hcz[[i]]$row,,drop=FALSE], pal="RWB", col.center=0, col.limits=c(-4,4), cex=1.2, pmar=c(10,1), main=paste0(Cnames[i],", ",nsig," DE Gene Z-Scores"))
            dev.off()
            
            png(paste0(Cprefix[i],".hmz.clust.all.png"), imgwd, imght)
            mipu(output$hmz[[i]][output$hcz[[i]]$row,output$hcz[[i]]$col.all,drop=FALSE], pal="RWB", col.center=0, col.limits=c(-4,4), cex=1.2, pmar=c(10,1), main=paste0(Cnames[i],", ",nsig," DE Gene Z-Scores"))
            dev.off()
            
            png(paste0(Cprefix[i],".hmz.clust.grp.png"), imgwd, imght)
            mipu(output$hmz[[i]][output$hcz[[i]]$row,output$hcz[[i]]$col.grp,drop=FALSE], pal="RWB", col.center=0, col.limits=c(-4,4), cex=1.2, pmar=c(10,1), main=paste0(Cnames[i],", ",nsig," DE Gene Z-Scores"))
            dev.off()
        }
    }
    
    all.sig.genes <- sort(unique(unlist(lapply(output$sig,rownames))))
    sig.gene.rows <- match(all.sig.genes,rn.master)
    message(paste(" TOTAL SIG GENES:",length(sig.gene.rows)))
    
    ## N DE Genes Barplots ##
    
    nde.bars.1 <- merge.table.list(sig.tab)[,c(3,1,2),drop=FALSE]
    write.table2(nde.bars.1, paste0(outpath,"/N_DE.txt"), row.head="Contrast", col.names=qw(Up,Down,Non))
    nde.bars <- t(nde.bars.1[,1:2,drop=FALSE])  # up, down only
    nde.bars[2,] <- -1*nde.bars[2,]  # 'down' becomes negative
    ylim <- range(c(nde.bars))
    
    png(paste0(outpath,"/N_DE.bars.png"), 400+50*C, 600)
    par(cex=1.2, las=1)
    b <- barplot(nde.bars[1,], col="tomato", bord="tomato", ylim=ylim, names=colnames(nde.bars), main="DE Genes Per Contrast")
    barplot(nde.bars[2,], col="dodgerblue", bord="dodgerblue", add=TRUE)
    abline(h=0)
    text(b, 0, nde.bars[1,], pos=3)
    text(b, 0, -nde.bars[2,], pos=1)
    dev.off()
    
    ## Venn Diagrams ##
    
    if (C>1 & C<=5) {  # can have venn diags with 2-5 sets
        png(paste0(outpath,"/venn.up.png"), 1200, 600)
        par(mfrow=c(1,2), cex=1.2)
        output$venn$up <- venn.diag(lapply(output$sig, function(x) rownames(x)[x$DE==1] ), colorize=TRUE, main="Up DE Genes")
        venn.diag(lapply(output$sig, function(x) rownames(x)[x$DE==1] ), as.pct=TRUE, colorize=TRUE, main="As Pct Total")
        dev.off()
        
        png(paste0(outpath,"/venn.down.png"), 1200, 600)
        par(mfrow=c(1,2), cex=1.2)
        output$venn$down <- venn.diag(lapply(output$sig, function(x) rownames(x)[x$DE==-1] ), colorize=TRUE, main="Down DE Genes")
        venn.diag(lapply(output$sig, function(x) rownames(x)[x$DE==-1] ), as.pct=TRUE, colorize=TRUE, main="As Pct Total")
        dev.off()
        
        png(paste0(outpath,"/venn.all.png"), 1200, 600)
        par(mfrow=c(1,2), cex=1.2)
        output$venn$all <- venn.diag(lapply(output$sig, rownames), colorize=TRUE, main="All DE Genes")
        venn.diag(lapply(output$sig, rownames), as.pct=TRUE, colorize=TRUE, main="As Pct Total")
        dev.off()
    }
    
    to.GO.KEGG <- do.call(rbind, lapply(output$to.GO, "[[", "KEGG"))
    to.GO.GODB <- do.call(rbind, lapply(output$to.GO, "[[", "GODB"))
    write.table2(to.GO.KEGG, paste0(outpath,"/to.GO.KEGG.txt"))
    write.table2(to.GO.GODB, paste0(outpath,"/to.GO.GODB.txt"))
    
    if (functional) {
        
        read.fc.files <- function(path,opp=FALSE) {
            terms <- paste0(path,"/FatiClone_Fishers_",ifelse(opp,"ALL","OVER"),"_significant_terms.txt")
            genes <- paste0(path,"/FatiClone_Fishers_",ifelse(opp,"ALL","OVER"),"_significant_genelist.txt")
            terms <- suppressWarnings(try(read.delim(terms, as.is=TRUE), silent=TRUE))  # will not exist if no sig terms found
            genes <- suppressWarnings(try(read.delim(genes, as.is=TRUE), silent=TRUE))  # same
            if (is(terms,"try-error")) terms <- data.frame( Map="", Enriched_In="", DB="", Level=0, Term_Acc="", Term_Name="", Clust_Term_Pct=0, Bkg_Term_Pct=0, Pct_LFC=0, DB_Term_Pct=0, Enrichment="", Raw_P=0, Adj_P=0, Odds=0, `0.95_CI_Lo`=0, `0.95_CI_Up`=0, Clust_With=0, Clust_Without=0, Bkg_With=0, Bkg_Without=0, DB_With=0, Input_Symbols="", Input_Names="", Input_Xrefs="", Mapped_Symbols="", Mapped_Names="", Mapped_Xrefs="", Input_Rows="" )[0,]  # same format as FatiClone terms output
            if (is(genes,"try-error")) genes <- data.frame( Map="", Enriched_In="", DB="", Level=0, Sig_Term_Acc="", Sig_Term_Name="", Row=0, Input_Xref="", `Original_ID(s)`="", Other_Terms="" )[0,]  # same format as FatiClone genes output
            list(terms=terms,genes=genes)
        }
        
        ## GO ANALYSIS ##
        
        if (do.GO) {
            
            GO.g.cmd <- paste0("/home/apa/local/bin/FatiClone -f ",outpath,"/to.GO.GODB.txt -d ",DB$GO," -x ",taxon," -a ",func.FDR," -t 1 -b genome -w ",GODB.g.dir," --no_sig_parents --nounder")
            GO.o.cmd <- paste0("/home/apa/local/bin/FatiClone -f ",outpath,"/to.GO.GODB.txt -d ",DB$GO," -x ",taxon," -a ",func.FDR," -t 1 -b opposite -w ",GODB.o.dir," --no_sig_parents")
            message(paste("\nTesting whole-genome GO enrichments...\nRunning:",GO.g.cmd))
            if (!debug) system(GO.g.cmd)
            message(paste("\nTesting head-to-head GO enrichments...\nRunning:",GO.o.cmd))
            if (!debug) system(GO.o.cmd)
            
            fc.go <- list( genome=read.fc.files(GODB.g.dir,FALSE), opposite=read.fc.files(GODB.o.dir,TRUE) )
            message(paste(sum(sapply(fc.go, function(x) nrow(x$terms) )),"GO result rows"))
            
            ## GO DB gene IDs may not be same as analysis gene IDs; add analysis IDs column to sig-term-genes dataset
            for (i in 1:length(fc.go)) {
                fc.go[[i]]$genes <- fc.go[[i]]$genes[,c(1:8,8:9)]
                colnames(fc.go[[i]]$genes)[8:9] <- c("GO.DB.IDs","Analysis.IDs")
                if (length(GO.ID.conv)>0) {
                    fc.go[[i]]$genes[,9] <- sapply(fc.go[[i]]$genes[,8], function(x) paste(sort(unique(GO.ID.conv[GO.ID.conv[,2]==x,1])), collapse="; ") )
                } else {
                    fc.go[[i]]$genes[,9] <- fc.go[[i]]$genes[,8]
                }
            }
            
            for (i in 1:C) {
                ## Add functional results to output object
                output$functional[[i]]$GO <- fc.go
                cl.names <- c(Cnames[i],paste0("-",Cnames[i]))  # e.g. c("test","-test")
                for (j in 1:length(fc.go)) {
                    x <- fc.go[[j]]$terms[fc.go[[j]]$terms$Cluster %in% cl.names,-1]  # TERMS: DROP MAP COLUMN
                    colnames(x) <- c("Enriched_In","DB","Level","Term_Acc","Term_Name","Clust_Term_Pct","Bkg_Term_Pct","Pct_LFC","DB_Term_Pct","Enrichment","Raw_P","Adj_P","Odds","0.95_CI_Lo","0.95_CI_Up","Clust_With","Clust_Without","Bkg_With","Bkg_Without","DB_With","Input_Symbols","Input_Names","Input_Xrefs","Mapped_Symbols","Mapped_Names","Mapped_Xrefs","Input_Rows")
                    y <- unique(fc.go[[j]]$genes[fc.go[[j]]$genes$Cluster %in% cl.names,-c(1:2)])  # GENES: DROP MAP, CLUSTER COLUMNS
                    colnames(y) <- c("DB","Level","Sig_Term_Acc","Sig_Term_Name","Row","Input_Xref","Original_ID(s)","Other_Terms")
                    if (nrow(x)>0) {
                        if (nrow(y)==0) warning("GO error: have term rows but no gene rows!\n")
                        x <- x[rev(order(x$Clust_Term_Pct)),]  # first sort by prevalence
                        x <- x[c(which(x$DB=="BP"),which(x$DB=="CC"),which(x$DB=="MF")),]  # order by BP, CC, MF, (in that order)
                        x$Pct_LFC <- log2(((x$Clust_With+0.5)/(x$Clust_With+x$Clust_Without+0.5))/((x$Bkg_With+0.5)/(x$Bkg_With+x$Bkg_Without+0.5)))  # recalculate to eliminate INFs etc, and actually put in Log2.
                        for (n in c("Clust_Term_Pct","Bkg_Term_Pct","DB_Term_Pct")) x[[n]] <- x[[n]]/100
                        x$DB <- paste0("GO-",x$DB)  # e.g. "BP" -> "GO-BP"
                        if (nrow(y)>0) y$DB <- paste0("GO-",y$DB)  # e.g. "BP" -> "GO-BP"
                        if (names(fc.go)[j]=="genome") {
                            u <- x[x$Enriched_In==cl.names[1],]   # "up" set
                            d <- x[x$Enriched_In==cl.names[2],]   # "down" set
                        } else if (names(fc.go)[j]=="opposite") {
                            u <- x[x$Enrichment=="OVER",]   # "up" set
                            d <- x[x$Enrichment=="UNDER",]  # "down" set
                        } else {
                            message(paste0("\n\n\n**********  WARNING: Background model '",names(fc.go)[j],"' is not supported!  Data is probably being handled incorrectly.  **********\n\n\n"))
                            Sys.sleep(10)
                        }
                        message(paste(Cnames[i],names(fc.go)[j],"GO :",nrow(u),"up",nrow(d),"down"))
                        if (nrow(u)>0) u$Enriched_In <- paste(cl.names[1],"Up")
                        if (nrow(d)>0) d$Enriched_In <- paste(cl.names[1],"Down")
                        x <- rbind(u,d)
                        x <- x[x$Clust_With>=term.min.genes , !(colnames(x) %in% c("Odds","0.95_CI_Lo","0.95_CI_Up","Enrichment","Input_Symbols","Input_Names","Mapped_Xrefs","Input_Rows"))]
                        if (nrow(x)>0) {
                            keep.genes <- sort(unique(unlist(strsplit(x$Input_Xrefs, "; "))))
                            y <- y[y$Input_Xref %in% keep.genes,]
                            y <- y[order(y$Input_Xref),]
                        } else {
                            y <- y[0,]
                        }
                    }
                    output$functional[[i]]$GO[[j]]$terms <- x
                    output$functional[[i]]$GO[[j]]$genes <- y
                }
            }
        }
        
        ## KEGG ANALYSIS ##
        
        if (do.KEGG) {
            
            KEGG.g.cmd <- paste0("/home/apa/local/bin/FatiClone -f ",outpath,"/to.GO.KEGG.txt -o ",DB$KEGG," -a ",func.FDR," -t 1 -b genome -w ",KEGG.g.dir," --no_sig_parents --nounder")
            KEGG.o.cmd <- paste0("/home/apa/local/bin/FatiClone -f ",outpath,"/to.GO.KEGG.txt -o ",DB$KEGG," -a ",func.FDR," -t 1 -b opposite -w ",KEGG.o.dir," --no_sig_parents")
            message(paste("\nTesting whole-genome KEGG enrichments...\nRunning:",KEGG.g.cmd))
            if (!debug) system(KEGG.g.cmd)
            message(paste("\nTesting head-to-head KEGG enrichments...\nRunning:",KEGG.o.cmd))
            if (!debug) system(KEGG.o.cmd)
            
            fc.kegg <- list( genome=read.fc.files(KEGG.g.dir,FALSE), opposite=read.fc.files(KEGG.o.dir,TRUE) )
            message(paste(sum(sapply(fc.kegg, function(x) nrow(x$terms) )),"KEGG result rows"))
            
            ## KEGG DB gene IDs may not be same as analysis gene IDs; add analysis IDs column to sig-term-genes dataset
            for (i in 1:length(fc.kegg)) {
                fc.kegg[[i]]$genes <- fc.kegg[[i]]$genes[,c(1:8,8:9)]
                colnames(fc.kegg[[i]]$genes)[8:9] <- c("KEGG.DB.IDs","Analysis.IDs")
                if (nrow(fc.kegg[[i]]$genes)>0) {
                    if (length(KEGG.ID.conv)>0) {
                        fc.kegg[[i]]$genes[,9] <- sapply(fc.kegg[[i]]$genes[,8], function(x) paste(sort(unique(KEGG.ID.conv[KEGG.ID.conv[,2]==x,1])), collapse="; ") )
                        kegg.key <- unique(breakout(lapply(split(KEGG.ID.conv[,1],KEGG.ID.conv[,2]), function(x) sort(unique(edgeR.out$input$annot[match(x,edgeR.out$input$annot[,1]),2])) ), reverse=TRUE))
                    } else {
                        fc.kegg[[i]]$genes[,9] <- fc.kegg[[i]]$genes[,8]
                        kegg.key <- edgeR.out$input$annot[,1:2]
                    }
                }
            }
            
            for (i in 1:length(fc.kegg)) {
                ## Because KEGG currently uses Ensembl IDs -- and has no symbol mappings, unlike the GO DBs -- we have to add symbols manually
                if (nrow(fc.kegg[[i]]$terms)>0) {
                    fc.kegg[[i]]$terms$Mapped_Symbols <- FatiClone.KEGG.convert(kegg.key, from=fc.kegg[[i]]$terms$Input_Xrefs)
                }
            }
            
            for (i in 1:C) {
                ## Add functional results to output object
                output$functional[[i]]$KEGG <- fc.kegg
                cl.names <- c(Cnames[i],paste0("-",Cnames[i]))  # e.g. c("test","-test")
                for (j in 1:length(fc.kegg)) {
                    x <- fc.kegg[[j]]$terms[fc.kegg[[j]]$terms$Cluster %in% cl.names,-1]  # TERMS: DROP MAP COLUMN
                    colnames(x) <- c("Enriched_In","DB","Level","Term_Acc","Term_Name","Clust_Term_Pct","Bkg_Term_Pct","Pct_LFC","DB_Term_Pct","Enrichment","Raw_P","Adj_P","Odds","0.95_CI_Lo","0.95_CI_Up","Clust_With","Clust_Without","Bkg_With","Bkg_Without","DB_With","Input_Symbols","Input_Names","Input_Xrefs","Mapped_Symbols","Mapped_Names","Mapped_Xrefs","Input_Rows")
                    y <- unique(fc.kegg[[j]]$genes[fc.kegg[[j]]$genes$Cluster %in% cl.names,-c(1:2)])  # GENES: DROP MAP, CLUSTER COLUMNS
                    colnames(y) <- c("DB","Level","Sig_Term_Acc","Sig_Term_Name","Row","Input_Xref","Original_ID(s)","Other_Terms")
                    if (nrow(x)>0) {
                        if (nrow(y)==0) stop("KEGG error: have term rows but no gene rows!\n")
                        x <- x[rev(order(x$Clust_Term_Pct)),]  # first sort by prevalence
                        x$Pct_LFC <- log2(((x$Clust_With+0.5)/(x$Clust_With+x$Clust_Without+0.5))/((x$Bkg_With+0.5)/(x$Bkg_With+x$Bkg_Without+0.5)))  # recalculate to eliminate INFs etc, and actually put in Log2.
                        for (n in c("Clust_Term_Pct","Bkg_Term_Pct","DB_Term_Pct")) x[[n]] <- x[[n]]/100
                        if (names(fc.kegg)[j]=="genome") {
                            u <- x[x$Enriched_In==cl.names[1],]   # "up" set
                            d <- x[x$Enriched_In==cl.names[2],]   # "down" set
                        } else if (names(fc.kegg)[j]=="opposite") {
                            u <- x[x$Enrichment=="OVER",]   # "up" set
                            d <- x[x$Enrichment=="UNDER",]  # "down" set
                        } else {
                            message(paste0("\n\n\n**********  WARNING: Background model '",names(fc.kegg)[j],"' is not supported!  Data is probably being handled incorrectly.  **********\n\n\n"))
                            Sys.sleep(10)
                        }
                        message(paste(Cnames[i],names(fc.kegg)[j],"KEGG :",nrow(u),"up",nrow(d),"down"))
                        if (nrow(u)>0) u$Enriched_In <- paste(cl.names[1],"Up")
                        if (nrow(d)>0) d$Enriched_In <- paste(cl.names[1],"Down")
                        x <- rbind(u,d)
                        x <- x[x$Clust_With>=term.min.genes , !(colnames(x) %in% c("Odds","0.95_CI_Lo","0.95_CI_Up","Enrichment","Input_Symbols","Input_Names","Mapped_Xrefs","Input_Rows"))]
                        if (nrow(x)>0) {
                            keep.genes <- sort(unique(unlist(strsplit(x$Input_Xrefs, "; "))))
                            y <- y[y$Input_Xref %in% keep.genes,]
                            y <- y[order(y$Input_Xref),]
                        } else {
                            y <- y[0,]
                        }
                    }
                    output$functional[[i]]$KEGG[[j]]$terms <- x
                    output$functional[[i]]$KEGG[[j]]$genes <- y
                }
            }
        }
        
        ## SPIA ANALYSIS ##
        
        if (do.SPIA) {
            
            library(SPIA)
            library(pathview)
            setwd(SPIA.dir)  # switch to output dir; 'spia' function writes images to current dir
            
            if (length(SPIA.ID.conv)>0) {
                ## must convert from analysis IDs to Entrez IDs
                all <- rownames(remap.matrix(edgeR.out$input$counts[,1,drop=FALSE], e2t, mean))
            } else {
                ## if do.SPIA, then analysis IDs assumed to be Entrez IDs
                all <- rownames(edgeR.out$input$counts)
            }
            
            for (i in 1:C) {
                message(paste("SPIA:",Cnames[i]))
                if (length(SPIA.ID.conv)>0) {
                    de <- remap.matrix(output$sig[[i]][,1,drop=FALSE], e2t, mean)
                } else {
                    de <- output$sig[[i]][,1,drop=FALSE]
                }
                if (length(SPIA.pathways)>0) SPIA.pathways <- sub("^[a-z]+","",SPIA.pathways)
                if (!debug) spia.df <- spia(de=named.vector(c(de),rownames(de)), all=all, organism=kegg.org, data.dir=sub("[^/]+$","",DB$SPIA), pathids=SPIA.pathways, plots=TRUE)  #,nB=2000,verbose=TRUE,beta=NULL,combine="fisher")
                message("")   # make up for poorly-programmed spia()'s habit of putting newlines at the start of messages and NOT the end...
                if (debug) {
                    ## spia.out.master <<- spia.df  ############ uncomment one time for pre-debugging run only !!!!!!!!!
                    spia.df <- spia.out.master
                }
                if (!debug) system(paste0("mv -f SPIAPerturbationPlots.pdf SPIAPerturbationPlots.",Cnames[i],".pdf")) 
                for (j in c(5,7:10)) if (any(is.na(spia.df[,j]))) spia.df[which(is.na(spia.df[,j])),j] <- 1  # correct any NA p-values
                
                plotP.thresh <- ifelse(any(spia.df$pGFdr<=func.FDR), func.FDR, 1)
                png(paste0(Cnames[i],".2way_evidence.png"), 600, 600); plotP(spia.df, thresh=plotP.thresh); dev.off() 
                spia.df$ID <- paste0(kegg.org,spia.df$ID)
                output$functional[[i]]$SPIA <- spia.df <- cbind(spia.df, Significant=spia.df$pGFdr<=func.FDR)[,c(1:10,13,11:12)]  # REPLACE SPIA.DF TOO
                
                ## Now, find SPIA-sig pathways and do pathview() plots
                fc.all <- threshold(remap.matrix(edgeR.out$top[[i]][,1,drop=FALSE], SPIA.ID.conv, mean), thresh=4, method="gt", absolute=TRUE)
                fc.sig <- threshold(remap.matrix(output$sig[[i]][,1,drop=FALSE], SPIA.ID.conv, mean), thresh=4, method="gt", absolute=TRUE)
                sig.paths <- spia.df$ID[spia.df$Significant]
                message(paste(Cnames[i],"SPIA :",length(sig.paths),"sig"))
                select <- AnnotationDbi:::select   # if select() gets masked by other packages (and it does), pathview() calls will break
                pathview.data.dir <- sub("[^/]+$","pathview_data",DB$SPIA)
                for (path in sig.paths) {
                    IM(path,": ALL",nrow(fc.all))
                    pathview(gene.data=fc.all, pathway.id=path, species=kegg.org, kegg.dir=pathview.data.dir, gene.idtype="entrez", node.sum="mean", limit=list(gene=2,cpd=2), both.dirs=list(gene=TRUE,cpd=TRUE), mid=list(gene="white",cpd="white"), na.col="grey", out.suffix=paste0(Cnames[i],".all-genes"))
                    IM(path,": SIG",nrow(fc.sig))
                    pathview(gene.data=fc.sig, pathway.id=path, species=kegg.org, kegg.dir=pathview.data.dir, gene.idtype="entrez", node.sum="mean", limit=list(gene=2,cpd=2), both.dirs=list(gene=TRUE,cpd=TRUE), mid=list(gene="white",cpd="white"), na.col="grey", out.suffix=paste0(Cnames[i],".sig-genes"))
                }
                
            }
            
            setwd(launchpath)  # switch back to launch dir for final outputs
        }
        
    }
    
    #blah=functional.analysis(gene.sets, annots, outpath, functional.org, FDR=0.05, term.min.genes=3, clobber=FALSE, ID.convert=NULL, DB=NULL, SPIA.pathways=NULL, post.EdgeR.data=NULL, debug=FALSE, raw.p=FALSE)

    ## Finalize Excel objects
    output$xls <- list(
        all.genes=cbind(xls.all$all.genes.1, do.call(cbind,all.top), xls.all$all.genes.2),
        sample.rpkms=data.frame(ID.cols, edgeR.out$expr$rpkms.all, stringsAsFactors=FALSE, check.names=FALSE),
        sample.counts=data.frame(ID.cols, edgeR.out$expr$counts.all, stringsAsFactors=FALSE, check.names=FALSE)
    )
    
    wd <- getwd()
    projid <- ifelse (grepl("/code$",wd), sub(".*/","",sub("/code$","",getwd())), "[UNKNOWN]")

    xls.tab.1 <- lapply(1:C, function(i) {
        x <- output$sig[[i]][rev(order(output$sig[[i]]$logFC)),]
        colnames(x) <- paste0(Cnames[i],".",colnames(x))
        xord <- match(rownames(x),xls.all$all.genes.1[,1])  # MATCH TO GENE ID COLUMN -- MAY NOT BE CALLED 'GeneID' THOUGH
        other.i <- setdiff(1:C, i)
        if (length(other.i)>0) {
            other.top <- do.call(cbind, all.top[other.i])[xord,]
            all.genes=cbind(xls.all$all.genes.1[xord,], x, other.top, xls.all$all.genes.2[xord,])
        } else {
            all.genes=cbind(xls.all$all.genes.1[xord,], x, xls.all$all.genes.2[xord,])
        }
    })
    names(xls.tab.1) <- Cnames
    
    xls.tabs.2.N <- list(
        sample.rpkms=data.frame(ID.cols, edgeR.out$expr$rpkms.all, stringsAsFactors=FALSE, check.names=FALSE)[sig.gene.rows,],
        sample.counts=data.frame(ID.cols, edgeR.out$expr$counts.all, stringsAsFactors=FALSE, check.names=FALSE)[sig.gene.rows,]
    )
    
    collate.func.data <- function(bkg) {
        ## 'bkg' is either 'genome' or 'opposite'
        ## produces one data.frame for all contrasts, both GO & KEGG, for that background type
        use <- lapply(output$functional, function(x) {
            nr.go <- nr.kegg <- 0
            if ("GO" %in% names(x)) {
                go <- x$GO[[bkg]]$terms
                nr.go <- nrow(go)
            }
            if ("KEGG" %in% names(x)) {
                kegg <- x$KEGG[[bkg]]$terms
                nr.kegg <- nrow(kegg)
            }
#            if (nr.go>0 & nr.kegg>0) {
                y <- rbind(go,kegg)
#            } else if (nr.go>0) {
#                y <- go
#            } else if (nr.kegg>0) {
#                y <- kegg
#            }
            if (nrow(y)>0) {
                usets <- unique(y$Enriched_In)
                y <- y[c(which(y$DB=="GO-BP"),which(y$DB=="GO-CC"),which(y$DB=="GO-MF"),which(y$DB=="KEGG")),]  # first sort by DB type
                y <- mat.split(y, y$Enriched_In)  # then split by gene set
                do.call(rbind, y[match(usets,names(y))])  # reorder list in usets (original) gene set order and recombine
            } else {
                y
            }
        })
        do.call(rbind, use)
    }
    
    functional.blurb.1 <- NULL
    functional.blurb.2 <- NULL
    if (functional) {
        sep1 <- ifelse(do.GO&do.SPIA,", ",ifelse(do.GO," and ",""))
        sep2 <- ifelse(do.GO|do.KEGG," and ","")
        functional.blurb.1 <- paste0(
            "Functional analysis was performed with ",
            ifelse(do.GO, paste0("GO DB '",DB$GO,"'"), ""),
            ifelse(do.KEGG, paste0(sep1,"KEGG DB '",sub(".*/","",DB$KEGG),"'"), ""),
            ifelse(do.SPIA, paste0(sep2,"SPIA DB '",sub(".*/","",DB$SPIA),"'"), "")
        )
        if (do.GO|do.KEGG) functional.blurb.2 <- "Two background models were used for functional analysis; tab \"func.genome\" compares each up, down list to the rest of the genome, \"func.opposite\" compares the up & down lists to each other."
    }
    
    xls.README <- as.data.frame(do.call(rbind, list(
        c(paste0("This Excel file contains EdgeR data for significant-DE genes from project ",projid,", [STRANDED / UNSTRANDED] gene counts."),""),
        c(paste0("Counts were obtained from [DESCRIBE METHODS AND GENE SET]."),""),
        if (C>1 & length(unique(FDR))>1) {
            c(paste0("DE genes were selected by EdgeR, default methods, contrast FDRs: ",paste(paste(Cnames,FDR,sep="="),collapse=","),", for ",C," contrast",ifelse(C>1,"s",""),"."),"")
        } else {
            c(paste0("DE genes were selected by EdgeR, default methods, FDR = ",FDR[1],ifelse(C>1,", for all contrasts.",".")),"")
        },
        c(paste0(nrow(edgeR.out$input$counts)," genes were analyzed, [EXPLAIN GENE SELECTION CRITERIA]."),""),
        c(paste0(ifelse(C>1,"Across all contrasts, ",""),n.de.up," genes were significantly upregulated, ",n.de.down," significantly downregulated."),""),
        if (length(functional.blurb.1)>0) { c(functional.blurb.1,"") },
        if (length(functional.blurb.2)>0) { c(functional.blurb.2,"") },
        c("",""),
        c("",""),
        c("Explanation of columns on tab \"all.genes\":",""),
        c("",""),
        c("GeneID","Ensembl Gene ID"),
        c("Symbol","Ensembl Gene Symbol"),
        c("*.logFC","EdgeR Contrast Log2FC"),
        c("*.PValue","EdgeR Contrast Raw P-Value"),
        c("*.FDR","EdgeR Contrast BH-Adjusted P-Value"),
        c("*.DE","Direction of Contrast Log2FC"),
        c("*.RpkmAvg","Sample RPKM Means"),
        c("*.RpkmSd","Sample RPKM StDevs"),
        c("*.CpmAvg","Sample CPM Means"),
        c("*.CpmSd","Sample CPM StDevs"),
        c("Chr","Ensembl Gene Chrom"),
        c("Start","Ensembl Gene Start"),
        c("End","Ensembl Gene End"),
        c("Strand","Ensembl Gene Strand"),
        c("Tot_Len","End-Start+1"),
        c("Exonic_Len","Exonic Bp in Gene"),
        c("N_Trans","N Known Transcripts"),
        c("N_Exons","N Known Unique Exons"),
        c("Biotype","Ensembl Gene Biotype"),
        c("SimpleBiotype","Simplified Biotype"),
        c("Status","Ensembl Gene Status"),
        c("Description","Ensembl Gene Description"),
        c("",""),
        c("",""),
        c("Explanation of columns on tabs \"sample.rpkms\" and \"sample.counts\":",""),
        c("",""),
        c("CPMs (counts-per-million) or RPKMs per sample per gene.",""),
        c("","")
    )))
    
    if (functional) {
        
        if (do.GO | do.KEGG) {
            xls.README <- rbind(
                xls.README,
                as.data.frame(do.call(rbind, list(
                    c("",""),
                    c("Explanation of columns on tab \"func.genome\" and \"func.opposite\":",""),
                    c("",""),
                    c("Enriched_In","Which gene set has the enrichment"),
                    c("DB","Term database of origin"),
                    c("Level","Term level of GO database"),
                    c("Term_Acc","Term accession"),
                    c("Term_Name","Term name"),
                    c("List_Term_Pct","Percent of foreground genes with term"),
                    c("Bkg_Term_Pct","Percent of background genes with term"),
                    c("Pct_LFC","Basically log2( List_Term_Pct / Bkg_Term_Pct ), but using adjusted counts to prevent divide-by-0."),
                    c("DB_Term_Pct","Percent of all genes in DB with term, which are also in the foreground set"),
                    c("Raw_P","Raw Fisher's Exact Test P-value"),
                    c("Adj_P","BH-Adjusted Fisher's Exact Test P-value"),
                    c("List_With","Number of genes in foreground set which have term"),
                    c("List_Without","Number of genes in foreground set which DO NOT have term"),
                    c("Bkg_With","Number of genes in background set which have term"),
                    c("Bkg_Without","Number of genes in background set which DO NOT have term"),
                    c("DB_With","Number of genes in DB with term"),
                    c("Input_Xrefs","Input gene IDs"),
                    c("Mapped_Symbols","Mapped gene symbols"),
                    c("Mapped_Names","Mapped gene names (only available for GO terms)"),
                    c("","")
                )))
            )
            xls.tabs.2.N <- c( xls.tabs.2.N, list( func.genome=collate.func.data("genome"), func.opposite=collate.func.data("opposite") ) )
        }
        
        if (do.SPIA) {
            xls.README <- rbind(
                xls.README,
                as.data.frame(do.call(rbind, list(
                    c("",""),
                    c("Explanation of columns on tab \"SPIA\":",""),
                    c("",""),
                    c("Name","KEGG Pathway Name"),
                    c("ID","KEGG Pathway ID"),
                    c("pSize","N genes in pathway"),
                    c("NDE","N DE genes in pathway"),
                    c("pNDE","Hypergeometric p-value for N DE genes in pathway"),
                    c("tA","Total perturbation in pathway"),
                    c("pPERT","p-value for tA"),
                    c("pG","Combined p-value for pNDE and pPERT"),
                    c("pGFdr","BH-adjusted pG"),
                    c("pGFWER","Bonferroni-adjusted pG"),
                    c("Significant","Is pGFdr significant at given FDR cutoff?"),
                    c("Status","Do DE genes indicate pathway is Activated or Inhibited?"),
                    c("KEGGLINK","Link to annotated pathway map at KEGG website"),
                    c("","")
                )))
            )
            xls.tabs.2.N <- c( xls.tabs.2.N, list( SPIA=do.call(rbind, lapply(1:C, function(i) cbind(Contrast=Cnames[i],output$functional[[i]]$SPIA))) ) )
        }
        
    }
    
    write.output <- function(xls, filename) {
        xls.dim <- sapply(xls, dim)
        if (all(xls.dim[1,]<=65535 & xls.dim[2,]<=255)) {
            ## Not too large for WriteXLS
            try(WriteXLS2(xls, filename, BoldHeaderRow=TRUE, row.names=FALSE, FreezeRow=1, FreezeCol=freezecol))
        } else {
            ## Too large for WriteXLS; write each tab to separate txt file
            for (i in 1:length(xls)) write.table(xls[[i]], paste0(filename,names(xls)[i],".txt"), sep="\t", quote=FALSE, row.names=FALSE)
        }
    }
    
    message("Writing final datasets...")
    output$xls$README <- xls.README
    xls.sig <- c( list(README=xls.README), xls.tab.1, xls.tabs.2.N )
    write.output(output$xls, paste0(outpath,"/all_edgeR_genes.xlsx"))
    write.output(xls.sig, paste0(outpath,"/sig_edgeR_genes_and_functional_analysis.xlsx"))
    save(output, file=paste0(outpath,"/post_EdgeR.RData"))
    message("post.EdgeR complete!")
    
    output
}


apa.names$dev <- c(apa.names$dev, "functional.analysis")
functional.analysis <- function(gene.sets, annots, outpath, functional.org, FDR=0.05, term.min.genes=3, clobber=FALSE, DB=NULL, ID.convert=NULL, SPIA.pathways=NULL, post.EdgeR.data=NULL, debug=FALSE, raw.p=FALSE) {
    
    ## INPUT: a list of gene sets, gene annotation data.frame, and some arguments.
    ## OUTPUT: GO and KEGG term enrichments (Fisher's Exact Test), and SPIA results.
    ## 
    ## It is assumed that input gene IDs are Ensembl, that KEGG/SPIA DB are keyes with Entrez IDs, and that GO is keyed with something else.
    ##  Thus, you must supply the appropriate ID conversion tables via 'ID.convert'.
    ## 
    ## Arguments:
    ## 'gene.sets': a list with one or more elements, one for each gene set.  List names are gene set names.  Each element is a data.frame with 2+ columns; 1 = geneID, 2 = LFC, 3+ = optional sub-groupings
    ## 'annots': data.frame of gene annotations; ID in column 1. *** MUST INCLUDE ALL GENES, not just those in 'gene.sets', since it will also define the background gene set ***.
    ## 'outpath': location to write results.
    ## 'functional.org': the string "Genus species" for the organism in question, e.g. "Mus musculus".  Must match organisms from the sitewide command 'showTaxa'.
    ## 'FDR': significance cutoff for adjusted p-values
    ## 'raw.p=TRUE' will switch from selecting on adjusted p-values (FDR) to selecting on the raw p-values
    ## 'term.min.genes': minimum N genes for a GO or KEGG term to be retained
    ## 'clobber': if 'outpath' already exists, overwite?
    ## 
    ## ID.convert is list with any of 2 elements, 'GOXREF' and 'ENTREZ'.  If specified, each must be a 2-col matrix/dataframe with column 1 = analysis IDs (usually Ensembl) and column 2 = the other IDs.
    ##   For 'ENTREZ', obviously, column 2 must be Entrez IDs.  For 'GOXREF', you have to know what ID type to use -- see next sentence.
    ##   If analyzing with an indexed genome/transcriptome, the GO_xref.txt and entrez.txt files already exist in the transcriptome directories, e.g. "mm10/Ens_80/mm10.Ens_80.{GO_xref,entrez}.txt" exist.
    ## 'DB': OPTIONAL list of database versions to use.  Names work the same as 'ID.convert'.  Databases are sought as standard locations:
    ##   GO will be the latest "go_yyymm" on host mysql-dev ; KEGG and SPIA will be latest "yyyymm" in /n/data1/KEGG/<org>/.
    ##    i.e. "DB=list(GO="alt_go_db_name", KEGG="/path/to/KEGG/Ensembl_term_DB.txt").
    ## 
    ## 'post.EdgeR.data': this is only for data being passed to functional.analysis() by post.EdgeR().
    
    if (!is.ndfl(gene.sets) | !all(sapply(gene.sets,is.data.frame))) stop("'gene.sets' must be a list of data.frames!\n")
    G <- length(gene.sets)
    setnames <- names(gene.sets)
    output <- new.list(setnames)
    if (length(setnames)==0) stop("'gene.sets' elements must have names!\n")
    #functional.org <- gsub("_"," ",functional.org)
    if (grepl("_",functional.org)) message(paste0("WARNING: you probably didn't want those underscores in '",functional.org,"'.  May or may not fail below..."))
    
    all.genes <- annots[,1]
    odat <- unlist(strsplit(sub("^ +","",system(paste0("bash -c '/home/apa/local/bin/showTaxa | grep \"",functional.org,"\"'"), intern=TRUE)), " +"))
    taxon <- as.numeric(odat[[1]])  # e.g. 9606 for Human
    kegg.org <- paste0(tolower(substr(odat[[2]],1,1)),substr(odat[[3]],1,2))  # e.g. "hsa"
    message(paste("Using",functional.org,"| NCBI taxon ID",taxon,"| KEGG code",kegg.org))
    no.GO.hosts <- c()
    no.GO.server <- ifelse(.HOSTNAME %in% no.GO.hosts, TRUE, FALSE)  # servers from which GO DB not accessible (e.g. OS-related Perl DBI issues)
    do.SPIA <- FALSE  # initially
    
    known <- sapply(gene.sets, function(x) all(x[,1] %in% annots[,1]) )
    if (!all(known)) stop(paste("Some gene names in 'gene.sets' are not found in 'annots'!  Halting."))
    maxw <- max(nchar(setnames))
    usable <- sapply(gene.sets, function(x) suppressWarnings(all(!is.na(as.numeric(x[,2])))) )
    if (any(!usable)) stop(paste("Gene sets",paste0(which(!usable),collapse=","),"are not usable!  Make sure these are vectors of log2-fold-changes (or all '0' if no LFC available), with names = gene IDs.\n"))
    paired <- sapply(gene.sets, function(x) any(x[,2]>0) & any(x[,2]<0) )   # basically, if LFC values have BOTH + AND - members, then this was a 2-sample comparison, thus samples were "paired"
    has.FC <- sapply(gene.sets, function(x) any(x[,2]>0) | any(x[,2]<0) )   # if not 'paired', then at least some nonzero values, which indicate the values themselves are important -- i.e. not all "0" just to get the gene list in the door.
    sp.format <- paste0("%-",maxw,"s  %6s  %6s")
    message(sprintf(sp.format, "Set", "Paired", "Has.FC"))
    for (i in 1:G) message(sprintf(sp.format, setnames[i], paired[i], has.FC[i]))
    
    launchpath <- getwd()
    outpath <- fixpath(outpath, clobber="ignore")
    
    if (length(DB)==0) DB <- list(GO="latest",KEGG="latest",SPIA="latest")
    DB2 <- list()
    if (length(DB$GO)>0) {
        known.GO <- system("bash -c '/home/apa/local/bin/GO_Tools --showdbs | grep ^go_'", intern=TRUE)
        if (length(taxon)==0) {
            stop("Unable to identify NCBI taxon ID for '",functional.org,"', which is required for GO analysis.")
        } else if (length(known.GO)==0) {
            stop("Unable to find any GO DBs -- check availability of server 'mysql-dev'?")
        } else if (DB$GO == "latest") {
            if (no.GO.server) {
                stop("GO databases not accessible from this server (",.HOSTNAME,").  Skipping GO analysis.")
            } else {
                message("Found latest GO DB '",known.GO[1],"'")
                DB2$GO <- c(known.GO[1], taxon, 'mysql-dev')
            }
        } else if (DB$GO %in% known.GO) {
            DB2$GO <- c(DB$GO, taxon, 'mysql-dev')
        } else {
            stop(paste(c(paste0("Requested GO DB '",DB$GO,"' does not exist!  Available DBs:"),paste(" ",known.GO)),collapse="\n"))
        }
    }
    
    if (length(DB$KEGG)>0) {
        known.KEGG <- system(paste0("bash -c 'ls ",kegg.root,kegg.org,"/*/*FatiClone_DB.txt | grep -v current | sort -r'"), intern=TRUE)
        known.KEGG <- cbind(VERSION=sub(".*/","",sub("/[^/]+$","",known.KEGG)), PATH=known.KEGG)
        if (length(kegg.org)==0) {
            stop("Unable to identify KEGG organism code for '",functional.org,"', which is required for KEGG/SPIA analysis.")
        } else if (nrow(known.KEGG)==0) {
            stop("Unable to find any KEGG DBs for org '",kegg.org,"' -- please see '",kegg.root,"'.")
        } else if (DB$KEGG == "latest") {
            message("Found latest KEGG DB '",known.KEGG[1,1],"' for org '",kegg.org,"'.")
            DB2$KEGG <- c(known.KEGG[1,1], kegg.org, known.KEGG[1,2])
        } else if (DB$KEGG %in% known.KEGG) {
            this.KEGG <- known.KEGG[match(DB$KEGG,known.KEGG[,1]),]
            DB2$KEGG <- c(this.KEGG[[1]], kegg.org, this.KEGG[[2]])
        } else {
            stop(paste(c(paste0("Requested KEGG DB '",DB$KEGG,"' does not exist!  Available DBs:"),paste(" ",known.KEGG[,1])),collapse="\n"))
        }
    }
    
    if (length(DB$SPIA)>0) {
        known.SPIA <- system(paste0("bash -c 'ls ",kegg.root,kegg.org,"/*/*SPIA.RData | grep -v current | sort -r'"), intern=TRUE)
        known.SPIA <- cbind(VERSION=sub(".*/","",sub("/[^/]+$","",known.SPIA)), PATH=sub("/[^/]+$","",known.SPIA))
        if (!any(has.FC)) {
            message("WARNING: SPIA analysis requested, but no gene sets have the required fold-change values!  Skipping SPIA analysis.\n")
        } else if (length(all.genes)==0) {
            message("Cannot run SPIA if 'all.genes' argument is empty!  Skipping SPIA analysis.\n")
        } else if (length(kegg.org)==0) {
            stop("Unable to identify KEGG organism code for '",functional.org,"', which is required for KEGG/SPIA analysis.")
        } else if (nrow(known.SPIA)==0) {
            stop("Unable to find any SPIA DBs for org '",kegg.org,"' -- please see '",kegg.root,"'.")
        } else if (DB$SPIA == "latest") {
            message("Found latest SPIA DB '",known.SPIA[1,1],"' for org '",kegg.org,"'.")
            DB2$SPIA <- c(known.SPIA[1,1], kegg.org, known.SPIA[1,2])
        } else if (DB$SPIA %in% known.SPIA[,1]) {
            this.SPIA <- known.SPIA[match(DB$SPIA,known.SPIA[,1]),]
            DB2$SPIA <- c(this.SPIA[[1]], kegg.org, this.SPIA[[2]])
        } else {
            stop(paste(c(paste0("Requested SPIA DB '",DB$SPIA,"' does not exist!  Available DBs:"),paste(" ",known.SPIA[,1])),collapse="\n"))
        }
    }
    
    if (length(DB2)==0) stop("No functional databases were validated!  Nothing to do...\n")
    
    if (any(c("GO","KEGG") %in% names(DB2))) {
        go.gene.sets <- lapply(gene.sets, function(x) x[,-2,drop=FALSE] )
        gokegg.res <- run.GO.KEGG(go.gene.sets, paste0(outpath,"FatiClone"), DB2, 0.05, 3, ID.convert, raw.p, clobber, debug=FALSE)
        ## work into output object
        for (i in 1:G) {
            for (db in names(gokegg.res[[i]])) {
                for (bg in names(gokegg.res[[i]][[db]])) {
                    output[[i]][[db]][[bg]] <- gokegg.res[[i]][[db]][[bg]]
                }
            }
        }
        rm(gokegg.res)
    }
    
    if ("SPIA" %in% names(DB2)) {
        test.olfactory <- TRUE
        if (length(SPIA.pathways)==1) {
            if (SPIA.pathways=="no-olfactory") {
                message("Pathway '",DB2$SPIA[2],"04740 Olfactory transduction' will be skipped!")
                SPIA.pathways <- NULL
                test.olfactory <- FALSE
            }
        }
        SPIA.gene.sets <- lapply(gene.sets, function(x) name(x[,2],x[,1]) )
        SPIA.res <- run.SPIA(SPIA.gene.sets, all.genes, paste0(outpath,"SPIA"), DB2$SPIA, FDR, ID.convert$KEGG, SPIA.pathways, raw.p, test.olfactory, clobber=clobber, debug=FALSE)
        ## work into output object
        for (i in 1:G) output[[i]]$SPIA <- SPIA.res[[i]]
        rm(SPIA.res)
    }
    
    ## Finalize Excel objects
    message("Summarizing analysis...")
    projid <- ifelse (grepl("/code$",launchpath), sub(".*/","",sub("/code$","",launchpath)), "[UNKNOWN]")
    xls.tabs.2.N <- list()
    
    if (length(post.EdgeR.data)>0) {
        xls.tab.1 <- post.EdgeR.data$xls.tab.1
        n.all.genes <- post.EdgeR.data$n.all.genes
        n.de.up <- post.EdgeR.data$n.de.up
        n.de.dn <- post.EdgeR.data$n.de.dn
    } else {
        ## If not supplied by a post.EdgeR() call, generate these objects here.
        xls.tab.1 <- cbind( matrix(NA,nrow(annots),G,FALSE,list(c(),setnames)), annots )
        for (i in 1:G) xls.tab.1[match(gene.sets[[i]][,1],annots[,1]),i] <- ternary(paired[i], gene.sets[[i]], rep("X",nrow(gene.sets[[i]])))
        n.all.genes <- length(unique(unlist(lapply(gene.sets,"[[",1))))
        if (any(paired)) {
            n.de.up <- length(unique(unlist(lapply(gene.sets, function(x) x[x[,2]>0,1] ))))
            n.de.dn <- length(unique(unlist(lapply(gene.sets, function(x) x[x[,2]<0,1] ))))
        } else {
            n.de <- length(unique(unlist(lapply(gene.sets, function(x) x[x[,2]!=0,1] ))))
        }
    }
    
    collate.func.data <- function(bkg) {
        ## 'bkg' is either 'genome' or 'opposite'
        ## produces one data.frame for all contrasts, both GO & KEGG, for that background type
        use <- lapply(output, function(x) {
            nr.go <- nr.kegg <- 0
            if ("GO" %in% names(x)) {
                if (bkg %in% names(x$GO)) {
                    go <- x$GO[[bkg]]$terms
                    nr.go <- nrow(go)
                }
            }
            if ("KEGG" %in% names(x)) {
                if (bkg %in% names(x$KEGG)) {
                    kegg <- x$KEGG[[bkg]]$terms
                    nr.kegg <- nrow(kegg)
                }
            }
            y <- rbind(go,kegg)
            message(paste(bkg,":",nrow(y),"terms"))
            if (nrow(y)>0) {
                usets <- unique(y$Enriched_In)
                y <- y[c(which(y$DB=="GO-BP"),which(y$DB=="GO-CC"),which(y$DB=="GO-MF"),which(y$DB=="KEGG")),]  # first sort by DB type
                y <- mat.split(y, y$Enriched_In)  # then split by gene set
                do.call(rbind, y[match(usets,names(y))])  # reorder list in usets (original) gene set order and recombine
            } else {
                y
            }
        })
        do.call(rbind, use)
    }
    
    functional.blurb.1 <- NULL
    functional.blurb.2 <- NULL
    sep1 <- ifelse(do.GO&do.SPIA,", ",ifelse(do.GO," and ",""))
    sep2 <- ifelse(do.GO|do.KEGG," and ","")
    cont.blurb <- ifelse(G>1,"Across all contrasts, ","")
    functional.blurb.1 <- paste0(
        "Functional analysis was performed with ",
        ifelse(do.GO, paste0("GO DB '",DB2$GO,"'"), ""),
        ifelse(do.KEGG, paste0(sep1,"KEGG DB '",sub(".*/","",DB2$KEGG),"'"), ""),
        ifelse(do.SPIA, paste0(sep2,"SPIA DB '",sub(".*/","",DB2$SPIA),"'"), "")
    )
    if (do.GO|do.KEGG) {
        if (any(paired)) {
            functional.blurb.2 <- "Two background models were used for functional analysis; tab \"func.genome\" compares each up, down list to the rest of the genome, \"func.opposite\" compares the up & down lists to each other."
        } else {
            functional.blurb.2 <- "One background model was used for functional analysis: tab \"func.genome\" compares each up, down list to the rest of the genome."
        }
    }
    
    xls.README <- as.data.frame(do.call(rbind, list(
        c(paste0("This Excel file contains EdgeR data for significant-DE genes from project ",projid,", [STRANDED / UNSTRANDED] gene counts."),""),
        c(paste0("Counts were obtained from [DESCRIBE METHODS AND GENE SET]."),""),
        if (G>1 & length(unique(FDR))>1) {
            c(paste0("DE genes were selected by EdgeR, default methods, contrast FDRs: ",paste(paste(setnames,FDR,sep="="),collapse=","),", for ",G," contrast",ifelse(G>1,"s",""),"."),"")
        } else {
            c(paste0("DE genes were selected by EdgeR, default methods, FDR = ",FDR[1],ifelse(G>1,", for all contrasts.",".")),"")
        },
        c(paste0(n.all.genes," genes were analyzed, [EXPLAIN GENE SELECTION CRITERIA]."),""),
        ternary(
            any(paired),
            c( paste0(cont.blurb,n.de.up," genes were significantly upregulated, ",n.de.dn," significantly downregulated."), ""),
            c( paste0(cont.blurb,n.de," genes significantly changed."), "")
        ),
        if (length(functional.blurb.1)>0) { c(functional.blurb.1,"") },
        if (length(functional.blurb.2)>0) { c(functional.blurb.2,"") },
        c("",""),
        c("",""),
        c("Explanation of columns on tab \"all.genes\":",""),
        c("",""),
        c("GeneID","Ensembl Gene ID"),
        c("Symbol","Ensembl Gene Symbol"),
        c("*.logFC","EdgeR Contrast Log2FC"),
        c("*.PValue","EdgeR Contrast Raw P-Value"),
        c("*.FDR","EdgeR Contrast BH-Adjusted P-Value"),
        c("*.DE","Direction of Contrast Log2FC"),
        c("*.RpkmAvg","Sample RPKM Means"),
        c("*.RpkmSd","Sample RPKM StDevs"),
        c("*.CpmAvg","Sample CPM Means"),
        c("*.CpmSd","Sample CPM StDevs"),
        c("Chr","Ensembl Gene Chrom"),
        c("Start","Ensembl Gene Start"),
        c("End","Ensembl Gene End"),
        c("Strand","Ensembl Gene Strand"),
        c("Tot_Len","End-Start+1"),
        c("Exonic_Len","Exonic Bp in Gene"),
        c("N_Trans","N Known Transcripts"),
        c("N_Exons","N Known Unique Exons"),
        c("Biotype","Ensembl Gene Biotype"),
        c("SimpleBiotype","Simplified Biotype"),
        c("Status","Ensembl Gene Status"),
        c("Description","Ensembl Gene Description"),
        c("",""),
        c("",""),
        c("Explanation of columns on tabs \"sample.rpkms\" and \"sample.counts\":",""),
        c("",""),
        c("CPMs (counts-per-million) or RPKMs per sample per gene.",""),
        c("","")
    )))
    
    if (do.GO | do.KEGG) {
        xls.README <- rbind(
            xls.README,
            as.data.frame(do.call(rbind, list(
                c("",""),
                c("Explanation of columns on tab \"func.genome\" and \"func.opposite\":",""),
                c("",""),
                c("Enriched_In","Which gene set has the enrichment"),
                c("DB","Term database of origin"),
                c("Level","Term level of GO database"),
                c("Term_Acc","Term accession"),
                c("Term_Name","Term name"),
                c("List_Term_Pct","Percent of foreground genes with term"),
                c("Bkg_Term_Pct","Percent of background genes with term"),
                c("Pct_LFC","Basically log2( List_Term_Pct / Bkg_Term_Pct ), but using adjusted counts to prevent divide-by-0."),
                c("DB_Term_Pct","Percent of all genes in DB with term, which are also in the foreground set"),
                c("Raw_P","Raw Fisher's Exact Test P-value"),
                c("Adj_P","BH-Adjusted Fisher's Exact Test P-value"),
                c("List_With","Number of genes in foreground set which have term"),
                c("List_Without","Number of genes in foreground set which DO NOT have term"),
                c("Bkg_With","Number of genes in background set which have term"),
                c("Bkg_Without","Number of genes in background set which DO NOT have term"),
                c("DB_With","Number of genes in DB with term"),
                c("Input_Xrefs","Input gene IDs"),
                c("Mapped_Symbols","Mapped gene symbols"),
                c("Mapped_Names","Mapped gene names (only available for GO terms)"),
                c("","")
            )))
        )
        collated <- list()
        collated$func.genome <- collate.func.data("genome")
        if (any(paired)) collated$func.opposite <- collate.func.data("opposite")
        xls.tabs.2.N <- c( xls.tabs.2.N, collated )
    }
    
    if (do.SPIA) {
        xls.README <- rbind(
            xls.README,
            as.data.frame(do.call(rbind, list(
                c("",""),
                c("Explanation of columns on tab \"SPIA\":",""),
                c("",""),
                c("Name","KEGG Pathway Name"),
                c("ID","KEGG Pathway ID"),
                c("pSize","N genes in pathway"),
                c("NDE","N DE genes in pathway"),
                c("pNDE","Hypergeometric p-value for N DE genes in pathway"),
                c("tA","Total perturbation in pathway"),
                c("pPERT","p-value for tA"),
                c("pG","Combined p-value for pNDE and pPERT"),
                c("pGFdr","BH-adjusted pG"),
                c("pGFWER","Bonferroni-adjusted pG"),
                c("Significant",paste("Is",sigspia,"significant at given FDR cutoff?")),
                c("Status","Do DE genes indicate pathway is Activated or Inhibited?"),
                c("KEGGLINK","Link to annotated pathway map at KEGG website"),
                c("","")
            )))
        )
        xls.tabs.2.N <- c( xls.tabs.2.N, list( SPIA=do.call(rbind, lapply(1:G, function(i) cbind(Contrast=setnames[i],output[[i]]$SPIA))) ) )
    }
    
    
    
    
    
    ## ############ FIXME: WORKING HERE, DOING WHAT TBD
    ## NEED TO TOGGLE DIFFERENT XLSX OUTPUT BEHAVIORS DEPENDING ON POST-EDGER OR NOT
    
    
    
    
    if (length(post.EdgeR.data)>0) {
        
        message("Writing final datasets...")
        output$xls$README <- xls.README
        xls.sig <- c( list(README=xls.README), xls.tab.1, xls.tabs.2.N )
        write.output(output$xls, paste0(outpath,"/all_edgeR_genes.xlsx"))
        write.output(xls.sig, paste0(outpath,"/sig_edgeR_genes_and_functional_analysis.xlsx"))
        save(output, file=paste0(outpath,"/post_EdgeR.RData"))
        
    } else {
        
        message("Writing final datasets...")
        ##message(paste("README:",nrow(xls.README),"TAB 1:",nrow(xls.tab.1),"TABS 2-N:",paste(sapply(xls.tabs.2.N,nrow),collapse=" ")))
        output$xls <- c( list(README=xls.README), list(genes=xls.tab.1), xls.tabs.2.N )
        xls.dim <- sapply(output$xls, dim)
        if (all(xls.dim[1,]<=65535 & xls.dim[2,]<=255)) {
            ## Not too large for WriteXLS
            try(WriteXLS2(output$xls, paste0(outpath,"/functional_analysis.xlsx"), BoldHeaderRow=TRUE, row.names=FALSE, FreezeRow=1))
        } else {
            ## Too large for WriteXLS; write each tab to separate txt file
            for (i in 1:length(output$xls)) write.table(output$xls[[i]], paste0(outpath,"/functional_analysis.xlsx.",names(output$xls)[i],".txt"), sep="\t", quote=FALSE, row.names=FALSE)
        }
        save(output, file=paste0(outpath,"/functional_analysis.RData"))
        
    }
    
    output
}


apa.names$dev <- c(apa.names$dev, "run.GO.KEGG")
run.GO.KEGG <- function(genes, outdir, DB, FDR=0.05, term.min.genes=3, ID.convert=NULL, raw.p=FALSE, clobber=FALSE, debug=FALSE) {
    
    ## 'genes' is a NAMED LIST of 2+ column matrices/dataframes; for each, col 1 = gene ID, and cols 2-N are mappings to analyze.
    ##   per mapping column, each unique value forms a subgroups that gets analyzed vs genome.
    ##   if any mapping column has only values "up" and "down", these will get an extra head-to-head analysis.
    ##   if any mapping column contains 2+ values which are NOT "up" and "down", then these get an extra each-vs-others analysis.
    ## 'outdir' is an output location.
    ## 'DB' is a list with any number of elements, at least one must be present:
    ##   DB$GO is the mysql-dev GO DB name, like "go_201705".
    ##   DB$KEGG is the KEGG build path under /n/data1/KEGG, like "mmu/201705" (thus pointing to "/n/data1/KEGG/mmu/201705").
    ##   DB$... (with some other name) is a path to some other database file that is FatiClone-compatible, i.e. tab-delim, 1 header row, 4 columns = Gene ID, Term Group, Term Accession, Term Name.
    ## 'FDR' is the significance cutoff.
    ## 'ID.convert' is also a list, with the same names as 'DB'; each element, if such is necessary, is a 2-col matrix or data.frame, with column 1 being the input gene IDs and column 2 being database IDs.
    ## 'raw.p' causes 'FDR' to apply to the raw p-values NOT the adjusted p-values.  Only recommended if your results are very bad.
    ## 'clobber' allows overwriting of existing 'outdir';
    ## 'debug' is not for general use.
    
    ## Check some inputs
    DB <- DB[!(names(DB) %in% "SPIA")]  # SPIA has its own function
    D <- length(DB)
    if (D==0) stop("'DB' must have at least one (non-SPIA) database to use!\n")
    outdir <- fixpath(outdir, clobber=ifelse(clobber,"yes","no"))
    
    ## Check genes
    G <- length(genes)
    if (G==0) stop("'genes' has length 0!\n")
    setnames <- names(genes)
    if (length(setnames)==0) stop("'genes' has no names!\n")
    if (any(grepl("^-",setnames))) stop("Gene set names may not begin with '-'!\n")
    for (i in 1:G) {
        if (is.matrix(genes)) {
            genes[[i]] <- as.data.frame(genes[[i]])
        } else if (!is.data.frame(genes[[i]])) {
            stop("genes[[",i,"]] is not a matrix or dataframe!\n")
        }
    }
    
    ## Custom functions
    ## Empty DFs in FatiClone output format
    term.blank <- data.frame( Map="", Enriched_In="", DB="", Level=0, Term_Acc="", Term_Name="", Clust_Term_Pct=0, Bkg_Term_Pct=0, Pct_LFC=0, DB_Term_Pct=0, Enrichment="", Raw_P=0, Adj_P=0, Odds=0, `0.95_CI_Lo`=0, `0.95_CI_Up`=0, Clust_With=0, Clust_Without=0, Bkg_With=0, Bkg_Without=0, DB_With=0, Input_Symbols="", Input_Names="", Input_Xrefs="", Mapped_Symbols="", Mapped_Names="", Mapped_Xrefs="", Input_Rows="" )[0,]
    gene.blank <- data.frame( Map="", Enriched_In="", DB="", Level=0, Sig_Term_Acc="", Sig_Term_Name="", Row=0, Input_Xref="", `Original_ID(s)`="", Other_Terms="" )[0,]
    maps.blank <- data.frame( Row=0, Input_IDs="", Mapped_IDs="", Gene_Products=0, GO_Terms="" )[0,]
    meta.blank <- rowname(as.matrix(c(0,0,0,0,0,0)), c("Genes In","Genes Converted","Genes Mapped (All Terms)","Genes Mapped (Sig Terms)","Total Terms","Sig Terms"))
    fcdat.blank <- list( terms=term.blank, genes=gene.blank, mappings=maps.blank )
    bgout.blank   <- list( terms=term.blank, genes=gene.blank, meta=meta.blank )
    
    read.fc.files <- function (path, is.geno) {
        enrich <- ifelse(is.geno,"OVER","ALL")
        fcterms <- try(read.delim(paste0(path,"FatiClone_Fishers_",enrich,"_significant_terms.txt")   , as.is=TRUE), silent=TRUE)
        fcgenes <- try(read.delim(paste0(path,"FatiClone_Fishers_",enrich,"_significant_genelist.txt"), as.is=TRUE), silent=TRUE)
        fcmaps  <- try(read.delim(paste0(path,"FatiClone_term_mappings.txt")                          , as.is=TRUE), silent=TRUE)
        if (is(fcterms,"try-error")) {
            fcterms <- term.blank  # if read error, data = rowless data.frame with expected format
        } else {
            for (i in 1:length(fcterms)) fcterms[[i]][fcterms[[i]]==""] <- NA
        }
        if (is(fcgenes,"try-error")) {
            fcgenes <- gene.blank  # if read error, data = rowless data.frame with expected format
        } else {
            for (i in 1:length(fcgenes)) fcgenes[[i]][fcgenes[[i]]==""] <- NA
        }
        if (is(fcmaps,"try-error")) {
            fcmaps <- maps.blank  # if read error, data = rowless data.frame with expected format
        } else {
            for (i in 1:length(fcmaps)) fcmaps[[i]][fcmaps[[i]]==""] <- NA
        }
        list( terms=fcterms, genes=fcgenes, mappings=fcmaps )
    }
    
    bkg <- c("genome","opposite","complement")
    B <- length(bkg)
    sigflag <- paste0(" -a ",FDR)
    if (raw.p) sigflag <- paste0(sigflag," -j NA")
    ugenes <- sort(unique(unlist(lapply(genes,"[[",1))))
    genes.conv <- genes.mapped <- as.data.frame(matrix(FALSE, length(ugenes), D, FALSE, list(ugenes,names(DB))))  # was gene X successfully: converted to IDs for DB Y, mapped to terms for DB Y
    output <- new.list(setnames, elem=new.list(names(DB), elem=new.list(bkg, elem=bgout.blank)))  # output object: output[[ gene set ]][[ DB ]][[ background model ]][[ FatiClone output ]]
    updown <- c("UP","Up","up","DOWN","Down","down","DN","Dn","dn","1","-1")
    
    ## Run analysis per gene set
    for (g in 1:G) {
        set.name <- setnames[g]
        set.dir <- fixpath(paste0(outdir,set.name), clobber="yes")
        
        ## Apply special formatting to gene object; detect background models to use
        set.genes <- genes[[g]]
        cng <- colnames(genes[[g]])
        map.cols <- 2:ncol(set.genes)
        M <- length(map.cols)
        if (length(cng)==0 | length(unique(cng[map.cols]))==1) colnames(genes[[g]]) <- c("GENE",paste0("MAP",map.cols-1))
        map.names <- colnames(genes[[g]])[map.cols]
        map.bkg <- rep("",M)
        
        for (m in 1:M) {
            mcol <- map.cols[m]
            un <- unique(set.genes[[mcol]])
            if (length(un)==1) {
                set.genes[[mcol]] <- set.name
                map.bkg[m] <- "genome"
            } else if (all(un %in% updown)) {
                set.genes[[mcol]][tolower(set.genes[[mcol]]) %in% c(1,"up")] <- set.name     # up =  "set.name"
                set.genes[[mcol]][set.genes[[mcol]]!=set.name] <- paste0("-",set.name)       # dn = "-set.name"
                map.bkg[m] <- "opposite"
            } else {
                ## probably cluster IDs; do not modify
                map.bkg[m] <- "complement"
            }
        }
        if (!("genome" %in% map.bkg)) {
            ## if not already, add single-group column so that whole-set-vs-genome analysis can run
            M <- M + 1
            map.bkg  <- c(map.bkg, "genome")
            map.cols <- c(map.cols, max(map.cols)+1)
            genes[[g]] <- cbind(genes[[g]], rep(1,nrow(genes[[g]])))
            colnames(genes[[g]])[ncol(genes[[g]])] <- ifelse("ALL"%in% cng, paste0("MAP",M-1), "ALL")
            map.names <- c(map.names, colnames(genes[[g]])[ncol(genes[[g]])])
        }
        
        set.bkg <- new.list(bkg)
        for (b in 1:B) set.bkg[[b]] <- bkg[b] %in% map.bkg
        
        ## Run analysis per DB
        for (d in 1:D) {
            db <- names(DB)[d]
            message(paste0("Running ",db," analysis for gene set '",set.name,"'..."))
            dbset.dir <- fixpath(paste0(set.dir,db), clobber="yes")
            db.convert <- db %in% names(ID.convert)
            
            ## Convert genes to DB IDs
            if (db.convert) {
                db.genes <- remap.matrix(set.genes, ID.convert[[db]], ids="column1")
                genes.conv[[db]][ugenes %in% ID.convert[[db]][,1]] <- TRUE
                colnames(db.genes)[1] <- "GENE"
            } else {
                db.genes <- set.genes
                genes.conv[[db]][1:length(ugenes)] <- TRUE
            }
            
            ## Prep FatiClone params
            if (db == "GO") {
                db.args <- paste("-d",DB$GO[1],"-x",DB$GO[2],"-h",DB$GO[3])
            } else {
                db.args <- paste("-o",DB[[db]][3])
            }
            
            ## Prepare output directories
            ## Write out DB ID files
            ## Prepare FatiClone commands
            ## Run FatiClone commands; read in results
            bkg.dirs <- bkg.files <- bkg.maps <- fcdat <- bkg.cmds <- new.list(bkg)
            for (b in 1:B) {
                bg <- bkg[b]
                
                if (set.bkg[[b]]) {
                    
                    bkg.dirs[[b]] <- fixpath(paste0(dbset.dir,names(bkg.dirs)[b]), clobber="yes")
                    bkg.files[[b]] <- paste0(dbset.dir,"IDs_to_FatiClone.",bg,".txt")
                    bkg.maps[[b]] <- map.bkg==bg  # T/F vector indicating if mapping column m is eligible to run background b
                    IM(b,bg,":",bkg.maps[[b]],":",map.cols[bkg.maps[[b]]])
                    write.table(db.genes[,c(1,map.cols[bkg.maps[[b]]])], bkg.files[[b]], sep="\t", quote=FALSE, row.names=FALSE)
                    bkg.cmds[[b]] <- paste("/home/apa/local/bin/FatiClone -f",bkg.files[[b]],db.args,sigflag,"-t 1 -b",bg,"-w",sub("/$","",bkg.dirs[[b]]),"--no_sig_parents",ifelse(bg=="genome","--nounder",""))
                    
                    message("\nTesting ",bg," ",db," enrichments...\nRunning: ",bkg.cmds[[b]])
                    if (!debug) system(bkg.cmds[[b]])
                    fcdat[[b]] <- read.fc.files(bkg.dirs[[b]],b==1)   # list with 3 elements; names = terms, genes, mappings
                    message(paste0(db," ",bg,": ",nrow(fcdat[[b]]$terms)," initial result rows"))
                    
                } else {
                    
                    ## get fcdat[[b]], empty or not
                    fcdat[[b]] <- fcdat.blank
                    tmp <- bgout.blank
                    
                }
                
                ## DB gene IDs may not be same as analysis gene IDs; add analysis IDs column to sig-term-genes dataset
                fcdat[[b]]$genes <- as.data.frame(as.list(fcdat[[b]]$genes[c(1:8,8:9)]))  # extra effort required to make this work in case $genes has 0 rows...
                names(fcdat[[b]]$genes)[8:9] <- c("DB.IDs","Analysis.IDs")
                if (nrow(fcdat[[b]]$genes)==0) {
                    if (nrow(fcdat[[b]]$genes)>0) {
                        if (db.convert) {
                            fcdat[[b]]$genes[,9] <- sapply(fcdat[[b]]$genes[,8], function(x) paste(sort(unique(ID.convert[[db]][ID.convert[[db]][,2]==x,1])), collapse="; ") )
                        } else {
                            fcdat[[b]]$genes[,9] <- fcdat[[b]]$genes[,8]
                        }
                        genes.mapped[[db]][ugenes %in% unlist(strsplit(fcdat[[b]]$genes[,9],"; "))] <- TRUE
                        if (is.na(fcdat[[b]]$terms$Mapped_Symbols)) {
                            ## Because other databases may have no symbol mappings, unlike the GO DBs -- we have to add symbols manually
                            if (db.convert) {
                                conv.key <- unique(breakout(lapply(split(ID.convert[[db]][,1],ID.convert[[db]][,2]), function(x) sort(unique(annots[match(x,annots[,1]),2])) ), reverse=TRUE))
                            } else {
                                conv.key <- annots[,1:2]
                            }
                            fcdat[[b]]$terms$Mapped_Symbols <- FatiClone.KEGG.convert(conv.key, from=fcdat[[j]]$terms$Input_Xrefs)  # can do more than just KEGG
                        }
                    }
                }
                
                ## Filter data and add to output dataset
                ## Give gene "A", "-A" gene subsets better output names
                if (nrow(fcdat[[b]]$term)>0) {
                    for (m in 1:M) {
                        map.name <- map.names[m]
                        sub.names <- set.genes[[map.cols[m]]]
                        
                        ## subset datasets for mapping m
                        term <- fcdat[[b]]$terms[fcdat[[b]]$terms$Map==map.names[m],]
                        gene <- unique(fcdat[[b]]$genes[fcdat[[b]]$genes$Map==map.names[m],])
                        maps <- unique(fcdat[[b]]$mappings[fcdat[[b]]$mappings$Input_IDs %in% gene$Input_Xref,-1])  # DROP ROW NUMBER COLUMN // this is ONLY used for some 'meta' stats, not stored
                        colnames(term) <- c("Map","Enriched_In","DB","Level","Term_Acc","Term_Name","Clust_Term_Pct","Bkg_Term_Pct","Pct_LFC","DB_Term_Pct","Enrichment","Raw_P","Adj_P","Odds","0.95_CI_Lo","0.95_CI_Up","Clust_With","Clust_Without","Bkg_With","Bkg_Without","DB_With","Input_Symbols","Input_Names","Input_Xrefs","Mapped_Symbols","Mapped_Names","Mapped_Xrefs","Input_Rows")
                        colnames(gene) <- c("Map","Cluster","DB","Level","Sig_Term_Acc","Sig_Term_Name","Row","Input_Xref","Original_ID(s)","Other_Terms")
                        term.nri <- nrow(term)
                        if (term.nri==0) {
                            message(paste(set.name,db,bg,": no terms!"))
                        } else {
                            if (nrow(gene)==0) warning(db," error: have term rows but no gene rows!\n")
                            ## First, filter out terms with too-few genes
                            term <- term[term$Clust_With>=term.min.genes,]
                            term.nro <- nrow(term)
                            message(paste(set.name,db,bg,":",term.nri,"terms in |",term.nro,"with minimum N genes"))
                            if (term.nro>0) {
                                ## Sort terms by prevalence
                                term <- term[rev(order(term$Clust_Term_Pct)),]
                                ## Recalculate LFCs to eliminate INFs etc, and actually put in Log2.
                                term$Pct_LFC <- log2(((term$Clust_With+0.5)/(term$Clust_With+term$Clust_Without+0.5))/((term$Bkg_With+0.5)/(term$Bkg_With+term$Bkg_Without+0.5)))
                                ## Improve GO DB names, for sorting
                                if (db=="GO") {
                                    term <- term[c(which(term$DB=="BP"),which(term$DB=="CC"),which(term$DB=="MF")),]  # if GO, order as BP then CC then MF
                                    term$DB <- paste0("GO-",term$DB)  # e.g. "BP" -> "GO-BP"
                                    if (nrow(gene)>0) gene$DB <- paste0("GO-",gene$DB)
                                }
                                ## Convert percents to Excel-friendly values
                                for (n in c("Clust_Term_Pct","Bkg_Term_Pct","DB_Term_Pct")) term[[n]] <- term[[n]]/100
                                ## Change "A"/"-A" subgroup naming into something more intuitive, if applicable
                                if (map.bkg[m]=="opposite") {
                                    ## this mapping was split into up,down groups (regardless of the pending bkg model used)
                                    up <- term[term$Enriched_In==set.name,]               ## either of these
                                    dn <- term[term$Enriched_In==paste0("-",set.name),]   ##  may not exist
                                    message(paste(set.name,db,bg,"terms:",nrow(up),"up",nrow(dn),"down"))
                                    if (nrow(up)>0) up$Enriched_In <- paste(set.names,"Up")
                                    if (nrow(dn)>0) dn$Enriched_In <- paste(set.names,"Down")
                                    term <- rbind(up,dn)
                                } else {
                                    ## this mapping was NOT split into up,down groups
                                    message(paste(set.name,db,bg,"terms:",nrow(term)))
                                }
                                ## Filter gene dataset based on retained terms
                                keep.genes <- sort(unique(unlist(strsplit(term$Input_Xrefs, "; "))))
                                gene <- gene[gene$Input_Xref %in% keep.genes,]
                                gene <- gene[order(gene$Input_Xref),]
                            }
                        }
                    }
                    
                    ## metadata section
                    ## CURRENTLY: only metadata per gene set
                    ## FUTURE: include meta-metadata covering all gene sets
                    u.genei <- unique(set.genes[,1])  # input IDs
                    u.genec <- unique(db.genes[,1])    # converted IDs
                    u.inp <- length(u.genei)
                    u.con <- sum(genes.conv[[db]][ugenes %in% u.genei])
                    u.map <- sum(genes.mapped[[db]][ugenes %in% u.genei])
                    u.sig <- t.all <- t.sig <- 0
                    if (nrow(gene)>0) u.sig <- length(unique(unlist(strsplit(gene[["Original_ID(s)"]],"; "))))
                    if (nrow(maps)>0) t.all <- length(unique(unlist(strsplit(maps$GO_Terms[maps$Input_IDs %in% u.genec],","))))  # this right here is the only reason we need to load the mappings file
                    if (nrow(term)>0) t.sig <- length(unique(term$Term_Acc))
                    meta <- rowname(as.matrix(c(u.inp,u.con,u.map,u.sig,t.all,t.sig)), c("Genes In","Genes Converted","Genes Mapped (All Terms)","Genes Mapped (Sig Terms)","Total Terms","Sig Terms"))
                    
                    ## Replace initial dummy output with real data
                    tmp <- list( terms=term, genes=gene, meta=meta )
                }
                
                ## Drop certain columns from certain datasets (dummy or not)
                ## Load output object
                tmp$term <- tmp$term[,!(colnames(tmp$term) %in% c("Odds","0.95_CI_Lo","0.95_CI_Up","Input_Symbols","Input_Names","Mapped_Xrefs","Input_Rows"))]
                tmp$gene <- unique(tmp$gene[tmp$gene$Map==map.names[m],-2])  # drop cluster column and take unique rows
                output[[g]][[d]][[b]] <- tmp
            }
        }
    }
    
    output
}


apa.names$dev <- c(apa.names$dev, "run.SPIA")
run.SPIA <- function(DE.genes, all.genes, outdir, DB, FDR=0.05, ID.convert=NULL, pathways=NULL, raw.p=FALSE, olfactory=TRUE, clobber=FALSE, debug=FALSE) {
    
    ## 'genes' is a list with 2 elements, 'DE' which is a vector of log2 fold-changes named with gene IDs (DE genes only), and 'all' which is a vector of all possible gene IDs (the background):
    ##   'all' can also be a vector of log2-fold-changes named with gene IDs, for the whole genome; then you will get extra "all-gene" PathView maps.
    ##   Gene IDs are preferably Entrez IDs, otherwise you must specify 'ID.convert', since KEGG/SPIA run on Entrez IDs.
    ## 'outdir' is an output location.
    ## 'DB' is a vector with 2 elements, element 1 is the directory containing the SPIA.RData object to use, and element 2 is the 3-letter KEGG org code.
    ## 'FDR' is the significance cutoff.
    ## 'ID.convert' is a 2-col matrix or data.frame, with column 1 being the input gene IDs (names of 'DE.genes' and maybe 'all.genes'), and column 2 being Entrez IDs.
    ## 'pathways' is an optional list of pathways to restrict SPIA analysis to.
    ## 'raw.p' causes 'FDR' to apply to the raw p-values (pG), NOT the adjusted ones (pGFdr).  Only recommended if your results are very bad.
    ##   Either way, the SPIA results don't change, just the pathview plots (well, the 'Significant' column will have more TRUE values).
    ## 'plot.all.genes' indicates that 'all' is also a named vector of LFCs, so make whole-genome pathview plots.
    ## 'olfactory' indicates if the olfactory-transduction pathway should be analyzed (this one pathway takes a LONG time).
    ## 'clobber' allows overwriting of existing 'outdir';
    ## 'debug' is not for general use (and does nothing in this version anyway!!).
    
    require(SPIA)
    require(pathview)
    select <- AnnotationDbi:::select   # if select() gets masked by other packages (and it does), pathview() calls will break
    
    ## Check some inputs
    kegg.ver <- DB[[1]]
    kegg.org <- DB[[2]]
    kegg.path <- DB[[3]]
    if (nchar(kegg.org)!=3) stop("kegg.org must be a three-letter KEGG organism code, like 'hsa', 'mmu', etc.\n")
    if (!dir.exists(kegg.path)) stop("kegg.path does not exist!\n")
    if (length(pathways)>0) pathways <- sub("^[a-z]+","",pathways)  # strip org code; numeric part only BUT NOT as.numeric: require leading zeroes
    
    ## Convert gene IDs, if needed
    if (length(ID.convert)>0) {
        DE.genes2 <- lapply(DE.genes, function(x) {
            y <- remap.matrix(as.matrix(x), ID.convert, mean)   # remap gene IDs; average values for many-to-one mappings
            name(y[,1], rownames(y))                            # restore to named vector
        })
    } else {
        DE.genes2 <- DE.genes
    }
    pv.de <- lapply(DE.genes2, function(x) threshold(as.matrix(x),4,"gt",absolute=TRUE) )  # crop all fold-changes to within -4:4
    
    ## If 'all.genes' is a named vector of fold-changes...
    plot.all.genes <- is.numeric(all.genes)
    if (plot.all.genes) {
        if (!is.numeric(all.genes)) stop("If using 'plot.all.genes=TRUE', then 'all.genes' must be a named vector of log2-fold-changes!\n")
        pv.all <- all.genes
        all.genes <- names(all.genes)  ## REPLACE W/ NAMES ONLY
        if (length(all.genes)==0) stop("'all.genes' was a vector of log2-fold-changes, but it had no names!\n")
        if (length(ID.convert)>0) pv.all <- remap.matrix(as.matrix(pv.all), ID.convert, mean)[,1,drop=FALSE]  # remap gene IDs; average values for many-to-one mappings
        pv.all <- threshold(as.matrix(pv.all), 4, "gt", absolute=TRUE)                                        # crop all fold-changes to within -4:4
    } else {
        if (is.numeric(all.genes)) stop("If using 'plot.all.genes=FALSE', then 'all.genes' must be a CHARACTER vector of Entrez gene IDs!\n")
        if (length(ID.convert)>0) all.genes <- real(sort(unique(ID.convert[ID.convert[,1] %in% all.genes,2])))  # 'real' in char context strips "" and NA
    }
    
    ## Prepare directories
    message("Preparing output locations and PathView temp data...")
    kegg.path <- fixpath(kegg.path, clobber="ignore")
    outdir <- fixpath(outdir, clobber=ifelse(clobber,"yes","no"))
    data.temp <- fixpath(paste0(outdir,"pathview_data/"), clobber="ignore")
    system(paste0("ln -sf ",kegg.path,"pathview_data/* ",data.temp))  # symlink existing build files into temp location
    rdata <- paste0(kegg.path,kegg.org,"SPIA",ifelse(olfactory,"","-no-olfactory"),".RData")
    IM(rdata)
    message(data.temp,kegg.org,"SPIA.RData")
    system(paste0("ln -sf ",rdata," ",data.temp,kegg.org,"SPIA.RData"))  # symlink desired RData file into temp location
    sigspia <- ifelse(raw.p,"pG","pGFdr")
    
    ## Run SPIA
    ## Make PathView plots for significant pathways
    spia.df <- new.list(names(DE.genes2))
    for (i in 1:length(DE.genes2)) {
        name <- names(DE.genes2)[i]
        namedir <- fixpath(paste0(outdir,name), clobber="yes")
        namepref <- paste0(namedir,name,".")
        evpng <- paste0(namepref,"2way_evidence.png")
        pppdf <- paste0(namepref,"SPIAPerturbationPlots.pdf")
        srtxt <- paste0(namepref,"SPIA_results.txt")
        
        spia.df[[i]] <- spia(de=DE.genes2[[i]], all=all.genes, organism=kegg.org, data.dir=data.temp, pathids=pathways, plots=TRUE)  #,nB=2000,verbose=TRUE,beta=NULL,combine="fisher")
        message("")   # make up for spia()'s poorly-programmed habit of putting newlines at the start of messages and NOT the end...
        system(paste0("mv -f SPIAPerturbationPlots.pdf ",pppdf))
        for (j in c(5,7:10)) if (any(is.na(spia.df[[i]][,j]))) spia.df[[i]][which(is.na(spia.df[[i]][,j])),j] <- 1  # correct any NA p-values
        
        plotP.thresh <- ifelse(any(spia.df$pGFdr<=FDR), FDR, 1)
        png(evpng, 600, 600); plotP(spia.df[[i]], thresh=plotP.thresh); dev.off()
        spia.df[[i]]$ID <- paste0(kegg.org,spia.df[[i]]$ID)
        spia.df[[i]] <- cbind(spia.df[[i]], PctDE=100*spia.df[[i]][,4]/spia.df[[i]][,3], Significant=spia.df[[i]][[sigspia]]<=FDR)[,c(1:4,13,5:10,14,11:12)]     # Add DE% and Significant=T/F columns
        sig.paths <- spia.df[[i]][spia.df[[i]]$Significant,c("ID","ID","Name")]
        sig.paths[,1] <- sub(kegg.org,"",sig.paths[,1])
        colnames(sig.paths) <- c("NUM","ID","NAME")
        message(paste(name,"SPIA :",nrow(sig.paths),"significant pathways"))
        write.table(spia.df[[i]], srtxt, sep="\t", quote=FALSE, row.names=FALSE)

        if (nrow(sig.paths)>0) {
            for (p in 1:nrow(sig.paths)) {
                pathnum <- sig.paths$NUM[p]
                pathlabel <- paste(sig.paths$ID[p], sig.paths$NAME[p])
                imgpref1 <- paste0(kegg.org,pathnum,".",name,".")
                imgpref2 <- paste0(namepref,pathnum,".")
                suppressWarnings(rm(korg))   ## prevent potential "Error in korg[ridx, coln] : subscript out of bounds"
                message(paste("PathView: ",name,pathnum,pathlabel))
               
                pathview(gene.data=pv.de[[i]], pathway.id=pathnum, species=kegg.org, kegg.dir=".", gene.idtype="entrez", node.sum="mean", limit=list(gene=2,cpd=2), both.dirs=list(gene=TRUE,cpd=TRUE), mid=list(gene="white",cpd="white"), na.col="grey", out.suffix=paste0(name,".sig-genes"))
                system(paste0("mv ",imgpref1,"sig-genes.png ",imgpref2,"sig-genes.png"))      # PATH.NAME -> NAME.PATH
                
                if (plot.all.genes) {
                    pathview(gene.data=pv.all, pathway.id=pathnum, species=kegg.org, kegg.dir=".", gene.idtype="entrez", node.sum="mean", limit=list(gene=2,cpd=2), both.dirs=list(gene=TRUE,cpd=TRUE), mid=list(gene="white",cpd="white"), na.col="grey", out.suffix=paste0(name,".all-genes"))
                    system(paste0("mv ",imgpref1,"all-genes.png ",imgpref2,"all-genes.png"))      # PATH.NAME -> NAME.PATH
                }
            }
        }
    }
    
    db.date <- sub(".*/","",sub("/$","",kegg.path))
    system(paste("rm -rf",data.temp))
    cmd <- paste("/home/apa/local/bin/scriptutils/spia_to_html.pl",outdir,kegg.org,db.date)
    message(cmd)
    system(cmd)
    spia.df
}


