


apa.names$hacks <- c(apa.names$hacks, "%nin%")
"%nin%" <- function(x, table) match(x, table, nomatch = 0) == 0  # the logical opposite of "%in%", but without having to write it as "!(x %in% y)"


apa.names$hacks <- c(apa.names$hacks, "%within%")
"%within%" <- function(x, range) x>=range[1] & x<=range[2]       # simpler to write one logical instead of two


apa.names$hacks <- c(apa.names$hacks, "ternary")
ifelse2 <- ternary <- function (test, expr1, expr2, return.value=TRUE) {
    
    ## Is this seriously R's first proper ternary operator??
    ## Not ifelse(), which is unable to return anything other than vectors of length 1.
    
    if (!is.logical(test)) stop("test condition must evaluate to TRUE/FALSE!\n")
    if (test) {
        if (return.value) {
            return(eval({expr1}))
        } else {
            eval({expr1})
            try(stop(),silent=TRUE)		# blocks return values
        }
    } else {
        if (return.value) {
            return(eval({expr2}))
        } else {
            eval({expr2})
            try(stop(),silent=TRUE)		# blocks return values
        }
    }
}


apa.names$hacks <- c(apa.names$hacks, "execute")
execute <- function (cmd, echo=TRUE, stopIfErr=TRUE) {
    ## Runs a system command, captures exit code, also reports code if non-zero
    ## If desired, dies on non-zero exit codes
    ## If desired, echoes command to screen
    if (echo) message(cmd)
    code <- system(cmd)
    if (code>0) {
        message(paste0("Command: '",cmd,"' had exit status ",ex,"!"))
        if (stopIfErr) stop("Halting.\n")
    }
}


apa.names$hacks <- c(apa.names$hacks, "ls.size")
ls.size <- function (envir=.GlobalEnv, human=FALSE, sort.by.size=FALSE) {
    
    ## object sizes for ls(envir)
    ## auto-subtracts 'apa.names' from base envir, at least until apa_tools.R becomes a formal package
    ## 'sort.by.size' sorts entries by size
    ## 'human' format numbers a la "df -h"
    
    if (deparse(substitute(envir)) == ".GlobalEnv") {
        x <- setdiff(ls(envir), unlist(apa.names))
    } else {
        x <- ls(envir)
    }
    y <- sapply(x, function(i){object.size(get(i))[[1]]})
    if (sort.by.size) { y <- sort(y, decreasing=TRUE) }
    
    humanize <- function(n) {
        if (n/1E12 >= 10) {
            paste(round(n/1E12,0),"T",sep="")
        } else if (n/1E12 >= 1) {
            paste(round(n/1E12,1),"T",sep="")
        } else if (n/1E9 >= 1) {
            paste(round(n/1E9,0),"G",sep="")
        } else if (n/1E6 >= 1) {
            paste(round(n/1E6,0),"M",sep="")
        } else if (n/1E3 >= 1) {
            paste(round(n/1E3,0),"K",sep="")
        } else {
            paste(n,"B",sep="")
        }
    }
    
    if (human) {
        data.frame(BYTES=sapply(y,humanize))
    } else {
        data.frame(BYTES=y)
    }
}


apa.names$hacks <- c(apa.names$hacks, "is.ndfl")
is.ndfl <- function (x) {
    
    ## is.non.data.frame.list()
    
    is.list(x) & !is.data.frame(x)
}


apa.names$hacks <- c(apa.names$hacks, "is.nlv")
is.nlv <- function (x) {
    
    ## is.non.list.vector()
    
    is.vector(x) & !is.list(x)
}


apa.names$hacks <- c(apa.names$hacks, "is.decimal")
is.decimal <- function (x) {
    
    ## do any numbers have any nonzero decimals
    
    x-trunc(x) != 0
}


apa.names$hacks <- c(apa.names$hacks, "as.numeric")
as.numeric <- function (x) {
    
    ## name-preserving as.numeric

    y <- base:::as.numeric(x)
    names(y) <- names(x)
    y
}


apa.names$hacks <- c(apa.names$hacks, "as.complex")
as.complex <- function (x) {
    
    ## name-preserving as.complex

    y <- base:::as.complex(x)
    names(y) <- names(x)
    y
}


apa.names$hacks <- c(apa.names$hacks, "as.logical")
as.logical <- function (x) {
    
    ## name-preserving as.logical

    y <- base:::as.logical(x)
    names(y) <- names(x)
    y
}


apa.names$hacks <- c(apa.names$hacks, "as.character")
as.character <- function (x) {
    
    ## name-preserving as.character

    y <- base:::as.character(x)
    names(y) <- names(x)
    y
}


apa.names$hacks <- c(apa.names$hacks, "npaste")
npaste <- function (..., sep=" ", collapse=NULL, which.names=1) {
    
    ## paste function that preserves names
    ## if multiple objects in '...' have names, 'which.names=rank' gives the rank of the object whose names will be used
    ##  - NOTE: this is not the rank of the object in '...', but the rank in the NAMED objects in '...'
    
    x <- paste(..., sep=sep, collapse=collapse)  # unnamed paste result
    L <- list(...)  # list of pasted things
    named <- which(sapply(L, function(l) length(names(l))>0 ))  # these things have names
    names(x) <- names(L[[ named[which.names] ]])
    x
}


apa.names$hacks <- c(apa.names$hacks, "npaste0")
npaste0 <- function (..., collapse=NULL, which.names=1) {
    
    npaste(..., sep="", collapse=collapse, which.names=which.names)
}


apa.names$hacks <- c(apa.names$hacks, "message2")
message2 <- function (..., domain = NULL, appendLF = TRUE, handle = stderr()) 
{
    args <- list(...)
    cond <- if (length(args) == 1L && inherits(args[[1L]], "condition")) {
        if (nargs() > 1L) 
            warning("additional arguments ignored in message()")
        args[[1L]]
    }
            else {
                msg <- .makeMessage(..., domain = domain, appendLF = appendLF)
                call <- sys.call()
                simpleMessage(msg, call)
            }
    defaultHandler <- function(c) {
        cat(conditionMessage(c), file = handle, sep = "")
    }
    withRestarts({
        signalCondition(cond)
        defaultHandler(cond)
    }, muffleMessage = function() NULL)
    invisible()
}


apa.names$hacks <- c(apa.names$hacks, "IM")
IM <- function (..., handle=stderr()) {
    
    ## "Instant Message", fastest way to report messages in real-time
    
    msg <- paste(unlist(list(...)), collapse=" ")
    message2(msg,handle=handle); flush.console()
}


apa.names$hacks <- c(apa.names$hacks, "report.index")
report.index <- function(i, n, N=NULL, msg=NULL, timestamp=FALSE) {
    
    ## Reports iteration i, every nth iteration of i.
    ## Optional message and/or timestamp can be appended
    
    fmt <- paste0("%",nchar(N),"i/",N)  # won't work without N
    if( !(i %% n) ) {
        rept <- ifelse(!is.null(N), sprintf(fmt,i), i)
        if (timestamp) msg <- paste(c(msg,paste0(": ",as.character(Sys.time()))),collapse=" | ")  # using collapse prevents extra ' | ' if no msg
        message(paste(rept,msg))
    }
}


apa.names$hacks <- c(apa.names$hacks, "sum.na")
sum.na <- function(x) {
    
    sum(is.na(x))
}


apa.names$hacks <- c(apa.names$hacks, "zapdiag")
zapdiag <- function(mat, value=NA) {
    
    diag(mat) <- value
    mat
}


apa.names$hacks <- c(apa.names$hacks, "maco")
maco <- function(x) {
    
    matrix(colnames(x))
}


apa.names$hacks <- c(apa.names$hacks, "maro")
maro <- function(x) {
    
    matrix(rownames(x))
}


apa.names$hacks <- c(apa.names$hacks, "mana")
mana <- function(x) {
    
    matrix(names(x))
}


apa.names$hacks <- c(apa.names$hacks, "mtable")
mtable <- function(x, order=FALSE, percent=FALSE) {
    
    y <- as.matrix(table(x))
    if (order) y <- y[rev(order(y[,1])),,drop=FALSE]
    if (percent) y <- cbind(N=y, Pct=y/sum(y))
    y
}


apa.names$hacks <- c(apa.names$hacks, "tabify.1")
tabify.1 <- function(x) {
    
    ## Adds tab to the first element of a vector, for spacing colnames correctly (since R cannot figure out how to align colnames when printing rownames as well)
    
    y <- x
    y[1] <- paste("\t",x[1],sep="")
    y
}


apa.names$hacks <- c(apa.names$hacks, "mgrep")
mgrep <- function(patterns, x, ignore.case=FALSE, perl=FALSE, value=FALSE, fixed=FALSE, useBytes=FALSE, invert=FALSE) {

    ## multi-grep; greps > 1 pattern at once

    if (invert) stop("Cannot use 'invert' yet, sorry!\n")
    w <- lapply(patterns, function(p) grep(p, x, ignore.case, perl, value, fixed, useBytes, invert) )
    w[listLengths(w)==0] <- NA
    return(unlist(w))
}


apa.names$hacks <- c(apa.names$hacks, "mgrepl")
mgrepl <- function(patterns, x, ignore.case=FALSE, perl=FALSE, fixed=FALSE, useBytes=FALSE) {
    
    ## multi-grepl; grepls > 1 pattern at once
    
    w <- sapply(patterns, function(p) grepl(p, x, ignore.case, perl, fixed, useBytes) )
    if (length(dim(w))==0) {  # vector return
        any(w)
    } else {  # w is a matrix with length(x) rows and length(patterns) columns
        apply(w, 1, any)
    }
}


apa.names$hacks <- c(apa.names$hacks, "fullpath")
fullpath <- function(x) {
    
    ## returns the full path of a file; multi-platform  ### WINDOWS COMMAND HAS PROBLEMS ON NETWORK DRIVES
    
    y <- switch(
        .Platform$OS.type, 
        "linux" = system(paste("readlink -f",x), intern=TRUE),
        "windows" = system(paste(Sys.getenv("COMSPEC")," /Q /C FOR %I IN (",x,") DO echo %~dpnxI",sep=""), intern=TRUE)
    )
    y
}


apa.names$hacks <- c(apa.names$hacks, "fixpath")
fixpath <- function(x, absolute=TRUE, trailing.slash=TRUE, mkdir=TRUE, clobber=c("ignore","no","yes")) {
    
    ## 'absolute' converts "path" to "/full/path/to/path"; only works if path currently exists
    ## 'trailing.slash' ensures "path" is "path/", to simplify "paste0(path,filename)" statements
    ## 'mkdir' makes the dir, if doesn't already exist
    ## 'clobber' values: 'yes' means existing dir gets rebooted, 'no' means death if dir already exists, 'ignore' does neither.
    
    clobber <- match.arg(clobber)
    if (!dir.exists(x)) {
        if (mkdir) {
            system(paste("mkdir -p",x))
        } else {
            if (absolute) x <- fullpath(x)   # this works on non-existant directories -- uses Linux 'readlink -f' -- has issues on Mac/Win
        }
    } else {
        if (absolute) x <- normalizePath(x)  # this only works on existing directories -- no OS issues
        if (clobber=="yes") {
            system(paste("rm -rf",x))
            system(paste("mkdir -p",x))
        } else if (clobber=="no") {
            stop("Directory '",x,"' already exists and 'clobber=no'!\n")
        }
    }
    if (trailing.slash & !grepl("/$",x)) x <- paste0(x,"/")
    
    x
}


apa.names$hacks <- c(apa.names$hacks, "fs.legal")
fs.legal <- function(x, convert='_', win2k=TRUE, linux=TRUE, whitespace=FALSE) {
    
    ## Takes a string x and converts all filesystem-illegal characters.
    ## "convert" specifies the replacement character for any illegal characters.
    ## "win2k=T" converts for windows platforms.
    ## "linux=T" converts for linux platforms.
    ## "whitespace=F" converts whitespace as well; otherwise gets left alone.
    ## Deprecated: "consecutive=T" leaves multiple consecutive converteds as-is; FALSE collapses them into a single convert char.
    
    whites <- c(" ","\t","\r","\n")
    chars <- unlist(strsplit(x,''))
    if (win2k) {
        illegal.first <- c(" ")
        illegal.any <- c(":","*","?","\"","<",">","/","\\","|")
        if (chars[1] %in% illegal.first) chars[1] <- convert
        chars[chars %in% illegal.any] <- convert
    }
    if (linux) {
        illegal.first <- c("-","~")
        illegal.any <- c("!","?","$","&",";","<",">","(",")","{","}","*","/","\\","|","\"","'","`")
        if (chars[1] %in% illegal.first) chars[1] <- convert
        chars[chars %in% illegal.any] <- convert
    }
    if (!whitespace) chars[chars %in% whites] <- convert
    y <- paste(chars, collapse='')
    y
}


apa.names$hacks <- c(apa.names$hacks, "trim.white")
trim.white <- function(x) {
    
    ## trims leading and trailing whitespace from a vector of strings
    
    sapply( sapply(x, function(s1){ sub("^[[:blank:]]+","",s1) }), function(s2){ sub("[[:blank:]]+$","",s2) })
}


apa.names$hacks <- c(apa.names$hacks, "suffix.duplicates")
suffix.duplicates <- function(x, alpha=FALSE) {
    
    ## "removes" duplicates by suffixing them with numbers (or letters)
    
    w1 <- which(duplicated(x))
    for (u in unique(x[w1])) {
        wu <- which(x == u)
        n <- length(wu)
        if (alpha) {
            if (n > 26) {
                reps <- ceiling(n/26)
                amat <- matrix("", ncol=reps, nrow=26*reps)
                for (i in 1:reps) {
                    amat[(26*(i-1)+1):(26*reps),i] <- letters
                }
                suff <- apply(amat[1:n,], 1, paste, collapse="")
            } else {
                suff <- letters[1:n]
            }
        } else {
            suff <- 1:n
        }
        x[wu] <- paste(x[wu],suff,sep=".")
    }
    x
}


apa.names$hacks <- c(apa.names$hacks, "head.list")
head.list <- function(lst, n=6) {
    
    ## Provides "head" method for list objects, especially with matrices / dataframes.
    
    named <- length(names(lst)) > 0
    for (i in 1:length(lst)) { 
        cap <- capture.output(head(lst[[i]], n=n))
        name <- ifelse(named, paste("$`",names(lst)[i],"`",sep=""), paste("[[",i,"]]",sep=""))
        message(name)
        for (j in 1:(n+1)) message(cap[j])
        message("\n")
    }
}


apa.names$hacks <- c(apa.names$hacks, "tail.list")
tail.list <- function(lst, n=6) {
    
    ## Provides "tail" method for list objects, especially with matrices / dataframes.
    
    named <- length(names(lst)) > 0
    for (i in 1:length(lst)) { 
        cap <- capture.output(tail(lst[[i]], n=n))
        name <- ifelse(named, paste("$`",names(lst)[i],"`",sep=""), paste("[[",i,"]]",sep=""))
        message(name)
        for (j in 1:(n+1)) message(cap[j])
        message("\n")
    }
}


apa.names$hacks <- c(apa.names$hacks, "head.list2")
head.list2 <- function(lst, max.depth=NA) {
    
    ## Provides a much more useful "head" method for list objects.
    ## "max.depth" sets max recursion depth.  "0" prevents recursion.  "NA" allows unlimited recursion.
    
    recurse <- function(lst, depth.now, max.depth) {
        depth.now = depth.now + 1
        for (i in 1:length(lst)) { 
            if (is.ndfl(lst[[i]])) {
                if (depth.now < max.depth) {	# then we can go one more level
                    heads[[i]] <- recurse(lst[[i]], depth.now, max.depth)
                } else {
                    IM("Max recurson depth",max.depth,"reached!")
                }
            } else {
                heads[[i]] <- capture.output(head(lst[[i]]))
            }
        }
    }
    
    if (is.na(max.depth)) { max.depth <- .Options$expressions }	# current recursion limit
    heads <- recurse(lst, 0, max.depth)
    print(heads, quote=FALSE)
}


apa.names$hacks <- c(apa.names$hacks, "slice.list")
slice.list <- function(lst, N, method=c("elem","cols","rows")) {
    
    ## Subsets each element of a list to create a new list from the subsets
    ## subset method must be one of "rows" or "cols" (if elements are dfs/mats) or "elem" (if elements are lists)
    ## 'N' is a vector specifying which rows/cols/elements are in each subset
    
    method <- match.arg(method)
    slc <- lst
    for (i in 1:length(lst)) {
        if (method == "elem") {
            declassified <- lst[[i]]
            suppressWarnings(class(declassified) <- "list")  # breaks method restrictions for list-like objects with exotic classes
            slc[i] <- declassified[N]
        } else if (method == "cols") {
            slc[i] <- if (length(lst[[i]])==0) { lst[i] } else { list(lst[[i]][,N]) }
        } else if (method == "rows") {
            slc[i] <- if (length(lst[[i]])==0) { lst[i] } else { list(lst[[i]][N,]) }
        }
    }
    slc
}


apa.names$hacks <- c(apa.names$hacks, "unpack.list")
unpack.list <- function(x, delim=".") {
    
    ## Converts a 2-level list (list where each element is a list with non-list elements)
    ##   into a 1-level list (where all elements are non-line elements)
    ## Example:
    ## unpack.list(list( A=list(x,y), B=list(z,w) )) => list( A.1=x, A.2=y, B.1=z, B.2=w )
    
    L <- length(x)
    ll <- listLengths(x)
    for (i in 1:L) if (length(names(x[[i]]))==0) names(x[[i]]) <- 1:length(x[[i]])
    out <- vector("list", length=sum(ll))
    j <- 0
    for (i in 1:L) {
        out[(j+1):(j+length(x[[i]]))] <- x[[i]]
        j <- j+length(x[[i]])
    }
    names(out) <- paste0(rep(names(x),times=ll),delim,unlist(lapply(x,names)))
    out
}


apa.names$hacks <- c(apa.names$hacks, "new.list")
new.list <- function(names, elements=NULL) {
    
    ## Shortcut function to create an empty, named list from a vector of names
    ## "elements", if not null, will assign "elements" to each element of the new list (e.g., additional empty list structure, empty matrix, etc.)
    
    if (is.null(elements)) { 
        nl <- vector("list", length=length(names))
    } else {
        nl <- lapply(names, FUN=function(x){elements})
    }
    names(nl) <- names
    nl
}


apa.names$hacks <- c(apa.names$hacks, "named.list", "named.vector")
named.list <- named.vector <- function(x, xnames) {
    
    ## Shortcut function to create a named list from a list object and a names vector
    
    names(x) <- xnames
    x
}


apa.names$hacks <- c(apa.names$hacks, "new.vector")
new.vector <- function(names, values=NA) {
    
    ## Shortcut function to create an empty, named vector from a vector of names
    ## "values" will be the vector values.  Can be length=1 (all vector = same values) or length > 1; gets recycled if length < length(names).
    
    LN <- length(names)
    LV <- length(values)
    
    if (LV==LN) {
        nv <- values
    } else if (LV==1) {
        nv <- rep(values, LN)
    } else {
        times <- ceiling(LN / LV)
        if (LN %% LV != 0) warning(paste("'names' length [",LN,"] is not a multiple of 'values' length [",LV,"]!",sep=""))
        nv <- rep(values, times)[1:LN]
    }
    names(nv) <- names
    nv
}


apa.names$hacks <- c(apa.names$hacks, "data.frame2")
data.frame2 <- function(types.list, nrows=0, dim.names=NULL) {
    
    ## Shortcut function to create an empty, named dataframe
    ## 'types.list' should be a list of type chars (like used in scan()), e.g. list("",0,T) for char, num, log
    ## 'types.list' can also be named if colnames desired.
    
    if (is.data.frame(types.list)) {
        df <- types.list[rep(1,nrows),]
        modes <- sapply(df, mode)
        for (i in 1:ncol(df)) df[,i] <- NA
        for (i in 1:ncol(df)) mode(df[[i]]) <- modes[i]
    } else {
        if (length(names(types.list))==0) { 
            names(types.list) <- paste("V",1:length(types.list),sep="") 
        }
        for (i in 1:length(types.list)) {
            types.list[[i]] <- rep(types.list[[i]], nrows)
        }
        types.list[[i+1]] <- FALSE
        names(types.list)[[i+1]] <- "stringsAsFactors"
        df <- do.call(data.frame, types.list)
        if (length(dim.names)>0) { 
            row.names(df) <- dim.names[[1]] 
            names(df) <- dim.names[[2]] 
        }
    }
    df
}


apa.names$hacks <- c(apa.names$hacks, "as.data.frame2")
as.data.frame2 <- function(..., stringsAsFactors=.Options$stringsAsFactors) {
    
    ## Shortcut function to make as.data.frame() share the vector-expanding abilities of cbind()
    
    pre <- list(...)  # matrices, dfs and/or vectors of any length
    x <- list(c()); n <- 0
    for (i in 1:length(pre)) {
        if (is.null(ncol(pre[[i]]))) {
            n <- n + 1
            x[[n]] <- pre[[i]]
        } else if (is.na(ncol(pre[[i]]))) {
            n <- n + 1
            x[[n]] <- pre[[i]]
        } else {   # must have columns?
            for (j in 1:ncol(pre[[i]])) {
                n <- n + 1
                x[[n]] <- pre[[i]][,j]
            }
        }
    }
    y <- x
    L <- listLengths(x)
    u <- unique(L)
    M <- max(L)
    rem <- M %% u
    if (any(rem>0)) {
        stop("Some vectors cannot be evenly recycled into max vector length!\n")
    }
    times <- M / L
    for (i in which(L<M)) { 
        y[[i]] <- rep(x[[i]], times=times[i]) 
    }
    as.data.frame(y, stringsAsFactors=stringsAsFactors)
}


apa.names$hacks <- c(apa.names$hacks, "real", "real.only")   # 'real' for legacy purposes
real <- real.only <- function(obj, logical=FALSE) {
    
    ## Removes NA, NaN, Inf, -Inf entries from an object
    ## "logical=T" returns a logical object instead
    ## IF CHARACTER: removes NA, "" entries
    
    unreal <- list(
        "logical"=c(NA),
        "character"=c(NA,""),
        "numeric"=c(NA,NaN,-Inf,Inf)
    )
    
    ok <- obj
    if (is.list(obj)) {
        for (i in 1:length(obj)) {
            keep <- !(obj[[i]] %in% unreal[[ mode(obj[[i]]) ]])
            if (logical) {
                ok[[i]] <- keep
            } else {
                ok[[i]] <- obj[[i]][keep]
            }
        }
    } else {
        keep <- !(obj %in% unreal[[mode(obj)]])
        if (logical) {
            ok <- keep
        } else {
            ok <- ok[keep]
        }
    }
    return(ok)
}


apa.names$hacks <- c(apa.names$hacks, "is.real")
is.real <- function(x) {
    
    !is.na(x) & !is.infinite(x) & !is.complex(x)
    
}


apa.names$general <- c(apa.names$general, "translate")
translate <- function(vec, x, y) {
    
    ## R port of Perl's tr/// function
    ## vec = input to translate x values into y values
    ## x=from, y=to, length(x)=length(y)
    ## x cannot have duplicate values, but y can
		
		new <- vec
		for (i in 1:length(x)) new[vec==x[i]] <- y[i]
		new
}


apa.names$general <- c(apa.names$general, "convert")
convert <- function(x, ids, column=1, na.action=c("ignore","remove","NA"), multi.action=c("first","concat"), delim=";") {
		
                                        # converts entries in x[,column] from values in ids[,1] to values in ids[,2], where possible
                                        # na.action indicates handling of unconvertibles: 
                                        #  "ignore" (leave unchanged), "drop" (drop row), or "NA" (convert to NA)
                                        # multi.action controls replacement by ids[,2] values when ids[,1] is not singular:
                                        #  "first" takes first matching value (default match() behavior), "concat" concatenates unique ids[,2] values with 'delim'
		
		na.action <- match.arg(na.action)
		multi.action <- match.arg(multi.action)
		w <- x[,column] %in% ids[,1]
		if (sum(w)==0) stop("No ids were matched!\n")
		if (multi.action == "first") {
        x[w,column] <- ids[match(x[w,column],ids[,1]),2]
		} else if (multi.action == "concat") {
        w2 <- which(ids[,1] %in% x[,column])
        ids2 <- breakout(lapply(split(ids[w2,2], ids[w2,1]), function(x) paste(sort(unique(x)), collapse=delim) ), reverse=TRUE)
        ids2 <- ids2[match(ids[w2,1],ids2[,1]),]
        x[w,column] <- ids2[match(x[w,column],ids2[,1]),2]
		}
		if (sum(w)<nrow(x)) {
        if (na.action == "ignore") {
            x
        } else if (na.action == "remove") {
            x[w,]
        } else if (na.action == "NA") {
            x[!w,2] <- NA
            x
        }
		} else {
        x
		}
}


apa.names$hacks <- c(apa.names$hacks, "NULL2NA")
NULL2NA <- function(x) {
    
    ## Converts any length-0 returns (incl. NULL) to NA
    
    if (length(x)==0) {
        NA
    } else {
        x
    }
}


apa.names$hacks <- c(apa.names$hacks, "NAfy")
NAfy <- function(obj, include=c(NaN,Inf,-Inf), add=NULL) {
    
    ## Converts all NaN, Inf, -Inf (or whatever is in 'include') to NA
    ## "add", if specified, is a vector of additional things to convert to NA (so don't have to re-enter the original list)
    
    include <- c(include, add)
    if (is.list(obj)) {		# mainly for data.frames
        for (i in 1:length(obj)) {
            obj[[i]][falsify(obj[[i]]%in%include)] <- NA 
        }
    } else {
        obj[falsify(obj%in%include)] <- NA
    }
    return(obj)
}


apa.names$hacks <- c(apa.names$hacks, "valuate")
valuate <- function(x, value) {
    
    ## Converts all NA/NaN, to 'value' 
    
    x[is.na(x)] <- value
    return(x)
}


apa.names$hacks <- c(apa.names$hacks, "numberize")
numberize <- function(x, sort=FALSE) {
    
    ## converts character levels to numbers
    
    ternary(sort, as.numeric(factor(x)), as.numeric(factor2(x)))
}


apa.names$hacks <- c(apa.names$hacks, "blankify")
blankify <- function(x) {
    
    ## Converts any length-0 subset, e.g. which(1:3==4), to an empty vector
    
    if (length(x)==0) {
        c()
    } else {
        x
    }
}


apa.names$hacks <- c(apa.names$hacks, "falsify")
falsify <- function(obj) {
    
    ## Converts all NA entries in logical obj to FALSE
    
    if (is.list(obj)) {		# mainly for data.frames
        for (i in 1:length(obj)) {
            obj[[i]][is.na(obj[[i]])] <- FALSE
        }
    } else {
        obj[is.na(obj)] <- FALSE
    }
    return(obj)
}


apa.names$hacks <- c(apa.names$hacks, "truthify")
truthify <- function(obj) {
    
    ## Converts all NA entries in logical obj to TRUE
    
    if (is.list(obj)) {		# mainly for data.frames
        for (i in 1:length(obj)) {
            obj[[i]][is.na(obj[[i]])] <- TRUE
        }
    } else {
        obj[is.na(obj)] <- TRUE
    }
    return(obj)
}


apa.names$hacks <- c(apa.names$hacks, "zerofy")
zerofy <- function(obj) {
    
    ## Numeric objects: convert NA, NaN to 0
    ## Character objects: convert NA, NaN to ""
    
    if (any(is.na(obj))) {
        if (is.list(obj)) {
            for (i in 1:length(obj)) {
                if (mode(obj[[i]]) == "character") {
                    obj[[i]][is.na(obj[[i]])] <- ""
                } else {
                    obj[[i]][is.na(obj[[i]])] <- 0
                }
            }
        } else {
            if (mode(obj) == "character") {
                                        #				for (i in 1:ncol(obj)) { obj[is.na(obj[,i]),i] <- "" }   # looping over columns here, because can crash trying to index very lg. objs all at once
                obj[is.na(obj)] <- ""
            } else {
                                        #				for (i in 1:ncol(obj)) { obj[is.na(obj[,i]),i] <- 0 }
                obj[is.na(obj)] <- 0
            }
        }
    }
    return(obj)
}


apa.names$hacks <- c(apa.names$hacks, "nonzero")
nonzero <- function(obj, na.rm=FALSE) {
    
    ## returns a vector of nonzero entries of 'obj'

    if (na.rm) {
        obj[falsify(obj!=0)]
    } else {
        obj[obj!=0]
    }
}


apa.names$general <- c(apa.names$general, "threshold")
threshold <- function(x, thresh, method=c("gt","ge","lt","le"), absolute=FALSE, replace.with=NULL, quantile=FALSE) {
    
    ## thresholds the values in an object (up or down, depending on "method")
    ## by default, thresholded values are changed to the threshold value.
    ## 'absolute=TRUE' will threshold +-thresh, preserving sign,
    ##  e.g. 'thresh=2, method="lt", absolute=T, replace.with=0' will cause values on (-2:2) to become 0.
    ##  e.g. 'thresh=2, method="ge", absolute=T, replace.with=0' will cause values on (-Inf,-2] and [2,Inf) to become 0.
    ## 'replace.with' will replace thresholded values with this value.
    ## 'quantile=TRUE' interprets 'thresh' as a quantile value (on [0,1])
    
    method <- match.arg(method)
    do.replace <- length(replace.with)>0
    greater <- grepl("^g",method)
    comp <- switch( method, gt=get(">"), ge=get(">="), lt=get("<"), le=get("<=") )
    rcomp <- switch( method, gt=get("<"), ge=get("<="), lt=get(">"), le=get(">=") )
    
    ## FIXME WORKING ON QUANTILE
    
    if (is.nlv(x) | is.matrix(x)) {
        if (absolute) {
            if (greater) {
                x[comp(x,thresh)] <- ifelse(do.replace, replace.with, thresh)
                x[rcomp(x,-thresh)] <- ifelse(do.replace, replace.with, -thresh)
            } else {
                x[rcomp(x,0) & comp(x,thresh)] <- ifelse(do.replace, replace.with, 0)
                x[comp(x,0) & rcomp(x,-thresh)] <- ifelse(do.replace, replace.with, 0)
            }
        } else {
            x[comp(x,thresh)] <- ifelse(do.replace, replace.with, thresh)
        }
    } else if (is.list(x) | is.data.frame(x)) {
        for (i in 1:ncol(x)) {
            if (absolute) {
                if (greater) {
                    x[comp(x[,i],thresh),i] <- ifelse(do.replace, replace.with, thresh)
                    x[rcomp(x[,i],-thresh),i] <- ifelse(do.replace, replace.with, -thresh)
                } else {
                    x[rcomp(x[,i],0) & comp(x[,i],thresh),i] <- ifelse(do.replace, replace.with, 0)
                    x[comp(x[,i],0) & rcomp(x[,i],-thresh),i] <- ifelse(do.replace, replace.with, 0)
                }
            } else {
                x[comp(x[,i],thresh),i] <- ifelse(do.replace, replace.with, thresh)
            }
        }
    } else {
        stop("Object to 'threshold' must be a numeric vector, list of numeric vectors, matrix, or data.frame!\n")
    }
    
    x
}


apa.names$hacks <- c(apa.names$hacks, "suniq")
suniq <- function(vec) {
    sort(unique(vec))
}


apa.names$hacks <- c(apa.names$hacks, "luniq")
luniq <- function(vec) {
    length(unique(vec))
}


apa.names$hacks <- c(apa.names$hacks, "linter")
linter <- function(...) {
#    length(intersect2(...))
    length(intersect(...))
}


apa.names$hacks <- c(apa.names$hacks, "lsetd")
lsetd <- function(...) {
#    length(setdiff2(...))
    length(setdiff(...))
}


apa.names$hacks <- c(apa.names$hacks, "expectation")
expectation <- function(x, round=NA) {
    ## 'x' is a numeric matrix
    ## returns expectation matrix for obs/exp calculations
    ## 'round' rounds output to that number of digits
    
    rp <- rowSums(x)/sum(x)
    cp <- colSums(x)/sum(x)
    y <- outer(rp,cp,"*")*sum(x)
    if (!is.na(round)) {
        round(y,round)
    } else {
        y
    }
}


apa.names$hacks <- c(apa.names$hacks, "duplicated2")
duplicated2 <- function(x) {
    
    ## broader version of duplicated()
    ## instead of asking, which entries *are duplicates*, asks: which entries *have duplicates*
    ## this is the set of all duplicates + all originals which have duplicates
    
    dup <- duplicated(x)
    x %in% x[duplicated(x)]
}


apa.names$general <- c(apa.names$general, "shift.case")
shift.case <- function(x, case) {
    
    ## changes case of the input (character) vector
    ## 'case' must be "upper", "lower", or "flip", indicating desired output case ('flip' flips all cases)
    
    if (!case %in% c("upper","lower","flip")) { stop("'case' must be one of 'upper', 'lower', or 'flip'!\n") }
    u2l <- cbind(LETTERS, letters)
    y <- x
    if (case == "upper") {
        lc <- match(x, u2l[,2])
        lcp <- which(!is.na(lc))
        y[lcp] <- u2l[lc[lcp],1]
    } else if (case == "lower") {
        uc <- match(x, u2l[,1])
        ucp <- which(!is.na(uc))
        y[ucp] <- u2l[uc[ucp],2]
    } else if (case == "flip") {
        lc <- match(x, u2l[,2])
        lcp <- which(!is.na(lc))
        uc <- match(x, u2l[,1])
        ucp <- which(!is.na(uc))
        y[lcp] <- u2l[lc[lcp],1]
        y[ucp] <- u2l[uc[ucp],2]
    }
    return(y)
}


apa.names$general <- c(apa.names$general, "qw")
qw <- function(...) {
	
    ## Similar to Perl's qw// operator: take an arbitrary number of literals and convert them to a character vector (so you don't have to type twice as many "s)
    ## Not perfect, however, due to R's rules for argument handling.  Basically R assumes the args must be legal symbol names or numeric values, so:
    ##  If any symbol is NOT a valid number or a valid R object name, it will fail:
    ##   Symbols with whitespace will fail (well, interpretation of whitespace will vary and may cause failure).
    ##   Symbols with numeric appearance will be evaluated first, thus the symbol 1.2.3 looks like an incorrect decimal and will fail.
    ##   Symbols with operators will usually fail.
    ##   Alphanumeric symbols which start with a number are neither numbers nor valid symbol names, and will fail.
    ## So it works well for words and most alphanumeric strings, but caveat emptor. 
    
    x <- as.character(deparse(substitute(list(...)),width.cutoff=500))
    if (length(x) > 1) {	# args > 500 bytes: deparse() will break them into multiple blocks
        for (i in 2:length(x)) { x[i] <- sub("^    ","",x[i]) }   # deparse adds 4 spaces for visual effect; remove them
    }
    y <- unlist(strsplit(gsub(" ","",gsub('\\"',"",sub("^list\\(","",sub("\\)$","",x)))), " *, *"))
    return(y)
}


apa.names$hacks <- c(apa.names$hacks, "rename")
rename <- function(x, names.list) {
	
	## changes dimnames of x using the list of names 'names.list'; names.list = list(rownames, colnames)
	
	if (length(names.list[[1]])>0) rownames(x) <- names.list[[1]]
	if (length(names.list[[2]])>0) colnames(x) <- names.list[[2]]
	x
}


apa.names$hacks <- c(apa.names$hacks, "dimnames2")
dimnames2 <- function(x, n) {
	
	## Competent version of dimnames() that can support NULL rownames or colnames on matrices
	
	ldx <- length(dim(x))
	if (length(n) != ldx) stop(paste("Length of dim names (",length(n),") not equal to number of dims (",ldx,")!",sep=""))
	if (ldx>2) {
		dimnames(x) <- n
	} else {
		rownames(x) <- n[[1]]
		colnames(x) <- n[[2]]
	}
	x
}


apa.names$hacks <- c(apa.names$hacks, "nameless")
nameless <- function(x, dims="ALL") {
	
	## Removes the names from an object
	## 'dims' is a vector of dimensions to remove names from (1=Rows, 2=cols; 3=Higher, arrays only)
	## 'dims=="ALL" strips names from all dimensions
	
	N <- length(dim(x))
	if (N == 0) {
		names(x) <- NULL
	} else {
		if (length(dims)==1) {
			if (dims=="ALL") {
				dims <- 1:N
			}
		}
		if (is.data.frame(x)) {
			if (1%in%dims) { rownames(x) <- NULL }
			if (2%in%dims) { colnames(x) <- paste("V", 1:ncol(x), sep="") }	# the "default" data.frame colnames
		} else {
			dimnames(x)[dims] <- list(NULL)
		}
	}
	return(x)
}


apa.names$hacks <- c(apa.names$hacks, "rownameless")
rownameless <- function(x, dims="ALL") {
	
	## Removes the rownames from an object
	
	rownames(x) <- NULL
	return(x)
}


apa.names$hacks <- c(apa.names$hacks, "colnameless")
colnameless <- function(x, dims="ALL") {
	
	## Removes the colnames from an object
	
	colnames(x) <- NULL
	return(x)
}


apa.names$hacks <- c(apa.names$hacks, "name")
name <- function(x, x.names) {
	
	## Sets names on an vector/list AND RETURNS OBJECT
	
	names(x) <- x.names
	return(x)
}


apa.names$hacks <- c(apa.names$hacks, "rowname")
rowname <- function(x, row.names) {
	
	## Sets rownames on an object AND RETURNS OBJECT
	
	rownames(x) <- row.names
	return(x)
}


apa.names$hacks <- c(apa.names$hacks, "colname")
colname <- function(x, col.names) {
	
	## Sets colnames on an object AND RETURNS OBJECT
	
	colnames(x) <- col.names
	return(x)
}


apa.names$hacks <- c(apa.names$hacks, "rename.list")
rename.list <- function(to, from) {
	
	## Applies names from one list to another
	
	names(to) <- names(from)
	to
}


apa.names$hacks <- c(apa.names$hacks, "rownamed.matrix")
rownamed.matrix <- function(df, class="numeric", stay.df=FALSE) { 
	
	## converts a data.frame with names in column 1 (and numeric data in cols 2:N) to a numeric matrix with rownames from col 1
    ## 'stay.df=TRUE' just a hack to return a rownamed data.frame with one less column
    
	rownames(df) <- df[,1]
    x <- df[,2:ncol(df),drop=FALSE]
    if (!stay.df) {
        x <- as.matrix(x)
        mode(x) <- class
    }
	x
}


apa.names$hacks <- c(apa.names$hacks, "matrix2dataframe")
matrix2dataframe <- function(mat, colname1="rownames") { 
		 
	## converts a matrix with rownames to a data.frame with rownames in column 1
	## basically the inverse of rownamed.matrix()

	df <- as.data.frame(mat)
	df <- cbind(rownames(mat), df)
	colnames(df)[1] <- colname1
	rownames(df) <- NULL
	df
}


apa.names$hacks <- c(apa.names$hacks, "zerofy.numeric")
zerofy.numeric <- function(mat) { 
	
	for (i in ncol(mat)) mat[,i] <- gsub("%","",gsub(",","",mat[,i]))  # strip commas and percent signs
	mode(mat) <- "numeric"
	zerofy(mat)
}


apa.names$hacks <- c(apa.names$hacks, "standardize")
standardize <- function(vec, na.rm=FALSE) {
    
    ## Remaps a vector into Z-score space
    ## "na.rm" same as in other functions
    
    if (na.rm) { vec <- real(vec) }
    x <- ( vec - mean(vec) ) / sd(vec)
    return(x)
}


apa.names$hacks <- c(apa.names$hacks, "zscore")
zscore <- function(x, value=NULL, na.rm=FALSE) {
    
    ## Converts a vector or matrix to z-scores.
    ## If 'value' is specified, returns the z-score for 'value', given 'x' as the distribution.
    ## "na.rm" as usual, only applies if 'value' used.

    if (length(value)>0) {
        ## unusual case -- using distrib 'x' to give a z-score to point 'value'
        ( value - mean(x,na.rm=na.rm) ) / sd(x,na.rm=na.rm)
    } else {
        ## usual case -- convert object 'x' to z-scores
        ## if matrix, converts along ROWS NOT COLUMNS
        if (is.list(x)) {
            stop("'x' must be a numeric matrix or vector!\n")
        } else if (is.matrix(x)) {
            t(scale(t(x)))
        } else {
            scale(x)
        }
    }
}


apa.names$hacks <- c(apa.names$hacks, "absmax")
absmax <- function(x, signed=FALSE, na.rm=FALSE) {
    
    r <- range(x, na.rm=na.rm)
    if (signed) {
        ifelse(abs(r[1])>abs(r[2]), r[1], r[2])
    } else {
        max(abs(r))
    }
}


apa.names$hacks <- c(apa.names$hacks, "absmin")
absmin <- function(x, signed=FALSE, na.rm=FALSE) {
    
    r <- range(x, na.rm=na.rm)
    if (signed) {
        ifelse(abs(r[1])<abs(r[2]), r[1], r[2])
    } else {
        min(abs(r))
    }
}


apa.names$hacks <- c(apa.names$hacks, "signlog")
signlog <- function(x, adjust=0, logfun=log2) {
    
    ## Converts absolute values into log
    ## Then signs the log values based on the originals
    
    #base <- as.numeric(sub("log","",deparse(substitute(logfun))))
    if (adjust<0) stop("Cannot adjust raw values with a negative number!")
    if (adjust>0 & adjust<1) stop("Cannot adjust raw values with a number smaller than 1!")
    y <- logfun(abs(x)+adjust)
    y[x<0] <- -y[x<0]
    y
}


apa.names$general <- c(apa.names$general, "percentify")
percentify <- function(vec, range=FALSE, na.rm=FALSE) {
    
    ## Converts a vector to a percent.
    ##  - "range=FALSE": values as percent of sum; intuitive treatment.
    ##  - "range=TRUE":  values as percent of range; basically, subtracts minimum value and divides by the remaining maximum.
    ## 'range' may also be c(min,max), indicating some other range.  If specified, converts vec to percent based on this range.
    ## "na.rm" same as in other functions.
    
    if (length(range)==1) {
        if (!is.logical(range)) {
            warning("'range' must be T/F or a length-2 numeric vector!")
            return()
        } else if (range) {
            if (length(vec)>1) {
                vec <- vec - min(vec, na.rm=na.rm)
                vec <- vec / max(vec, na.rm=na.rm)
            } else {
                vec <- 1
            }
        } else {
            if (length(vec)>1) {
                vec <- vec / sum(vec, na.rm=na.rm)
            } else {
                vec <- 1
            }
        }
    } else if (length(range)==2) {
        vec <- vec - range[1]
        vec <- vec / (range[2]-range[1])
    } else {
        warning("'range' cannot have length 0!")
        return()
    }
    return(vec)
}


apa.names$general <- c(apa.names$general, "sdpop")
sdpop <- function(x, na.rm=FALSE) {
    
    ## population sd (i.e. divisor is N not N-1)
    
    sqrt( sum((mean(x)-x)^2)/length(x) )
}


apa.names$general <- c(apa.names$general, "CV")
CV <- function(x, na.rm=FALSE) {
    
    ## Returns the coefficient of variation (CV) for a vector.
    ## na.rm same as in other functions.
    
    if (na.rm) x <- x[!is.na(x)]
    sd(x) / abs(mean(x))
}


apa.names$general <- c(apa.names$general, "CVpop")
CVpop <- function(x, na.rm=FALSE) {
    
    ## Returns the population coefficient of variation (CV) for a vector.
    ## Uses sdpop() not sd().
    ## na.rm same as in other functions.
    
    if (na.rm) x <- x[!is.na(x)]
    sdpop(x) / abs(mean(x))
}


apa.names$general <- c(apa.names$general, "MAD")
MAD <- function(x, na.rm=FALSE) {
    
    ## Mean Absolute Deviation
    ## alternative to Standard Deviation
    
    if (na.rm) x <- x[!is.na(x)]
    sum(abs(x-mean(x))) / length(x)
}


apa.names$general <- c(apa.names$general, "SEM")
SEM <- function(x, na.rm=FALSE) {
    
    ## Returns the Standard Error of the Mean for a vector.
    ## na.rm same as in other functions.
    
    if (na.rm) x <- x[!is.na(x)]
    sd(x) / sqrt(length(x))
}


apa.names$general <- c(apa.names$general, "SEMpop")
SEMpop <- function(x, na.rm=FALSE) {
    
    ## Returns the population Standard Error of the Mean for a vector.
    ## uses sdpop() not sd().
    ## na.rm same as in other functions.
    
    if (na.rm) x <- x[!is.na(x)]
    sdpop(x) / sqrt(length(x))
}


apa.names$general <- c(apa.names$general, "dimStats")
dimStats <- function(obj, dim.num, func, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    
    ## Generic row/column summarizer; backend for { row col } + { Sums Means Medians SDs CVs }
    ##  -- or anything else you want to plug into it; df- and array-compatible too
    ## "nonzero.only=T" supercedes "na.rm" in that it removes NA/NaNs AND zeroes. 
    ## "real=T" also supercedes "na.rm" in that it removes NA/NaNs AND +/-Inf.
    
    if (is.data.frame(obj)) obj <- as.matrix(obj)
    if (nonzero.only) { 
        obj[obj==0] <- NA 
        na.rm <- TRUE
    }
    if (real.only) { 
        obj[is.infinite(obj)] <- NA 
        na.rm <- TRUE
    }

    if (is.array(obj) || is.matrix(obj)) {
        apply(obj, dim.num, func, na.rm=na.rm)  # used to be wrapped in as.vector?
    } else {   # obj = single row/col = vector?
        sapply(obj, func, na.rm=na.rm)
    }
}


apa.names$general <- c(apa.names$general, "deciles")
deciles <- function(x, na.rm=FALSE) {
    quantile(x,seq(0,1,0.1),na.rm=na.rm)
}


apa.names$general <- c(apa.names$general, "percentiles")
percentiles <- function(x, na.rm=FALSE) {
    quantile(x,seq(0,1,0.01),na.rm=na.rm)
}


apa.names$general <- c(apa.names$general, "permilles")
permilles <- function(x, na.rm=FALSE) {
    quantile(x,seq(0,1,0.001),na.rm=na.rm)
}


apa.names$hacks <- c(apa.names$hacks, "quot")
quot <- function(x, na.rm=FALSE) { 
    Reduce("/", x)   # base has prod() for products, but nothing for quotients...
}


apa.names$hacks <- c(apa.names$hacks, "rowSums")
rowSums <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 1, base::sum, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "colSums")
colSums <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 2, base::sum, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "rowMeans")
rowMeans <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 1, base::mean, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "colMeans")
colMeans <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 2, base::mean, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "rowMedians")
rowMedians <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 1, stats::median, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "colMedians")
colMedians <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 2, stats::median, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "rowSDs")
rowSDs <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE, population=FALSE) {
    func <- if (population) { sdpop } else { sd }
    dimStats(obj, 1, func, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "colSDs")
colSDs <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE, population=FALSE) {
    func <- if (population) { sdpop } else { sd }
    dimStats(obj, 2, func, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "rowCVs")
rowCVs <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE, population=FALSE) { 
    func <- if (population) { CVpop } else { CV }
    dimStats(obj, 1, func, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "colCVs")
colCVs <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE, population=FALSE) { 
    func <- if (population) { CVpop } else { CV }
    dimStats(obj, 2, func, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "rowMax")
rowMax <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 1, base::max, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "colMax")
colMax <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 2, base::max, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "rowMin")
rowMin <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 1, base::min, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "colMin")
colMin <- function(obj, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) { 
    dimStats(obj, 2, base::min, na.rm, real.only, nonzero.only)
}


apa.names$hacks <- c(apa.names$hacks, "absMin")
absMin <- function(x, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) {
       if (real.only) x <- real(x)
       if (nonzero.only) x <- x[truthify(x>0)]
       min(abs(x),na.rm=na.rm)
}


apa.names$hacks <- c(apa.names$hacks, "absMax")
absMax <- function(x, na.rm=FALSE, real.only=FALSE, nonzero.only=FALSE) {
       if (real.only) x <- real(x)
       if (nonzero.only) x <- x[truthify(x>0)]
       max(abs(x),na.rm=na.rm)
}


apa.names$general <- c(apa.names$general, "midpoints")
midpoints <- function(vec) { 
	
	# treats 'vec' as a vector of breakpoints, and returns the midpoints
	
	N <- length(vec)
	apply(cbind(vec[1:(N-1)],vec[2:N]), 1, mean)
}


apa.names$general <- c(apa.names$general, "colrep")
colrep <- function(col, n) { 
	
	## Just like rep(), but using columns.  Returns a matrix.
	
	mat <- matrix(nrow=length(col), ncol=n)
	if (!is.null(names(col))) rownames(mat) <- names(col)
	for (i in 1:n) mat[,i] <- col
	return(mat)
}


apa.names$general <- c(apa.names$general, "rowrep")
rowrep <- function(row, n) { 
	
	## Just like rep(), but using rows.  Returns a matrix or dataframe.
	
	if (is.nlv(row)) {
		mat <- matrix(nrow=n, ncol=length(row))
		if (!is.null(names(row))) colnames(mat) <- names(row)
		for (i in 1:n) mat[i,] <- row
		mat
	} else if (is.data.frame(row)) {
		do.call(rbind,new.list(1:n, elem=row))
	} else {
		stop("row is not a non-list vector or data.frame: cannot reshape!\n")
	}
}


apa.names$hacks <- c(apa.names$hacks, "rbind2")
rbind2 <- function(...) { 
    
    ## rbind() without the colnames matching
    
    ldot <- list(...)
    cnames <- colnames(ldot[[1]])
    x <- do.call(rbind, lapply(ldot, function(y){
        if (is.matrix(y) | is.data.frame(y)) {
            colnames(y)=1:ncol(y)
            y
        } else {
            names(y)=1:length(y)
            t(as.matrix(y))
        }
    }))
    colnames(x) <- cnames
    x
}


apa.names$general <- c(apa.names$general, "ragged.cbind")
ragged.cbind <- function(..., named=FALSE) { 
    
    ## cbind() for vectors of uneven length
    
    x <- list(...)
    if (length(x)==1) x <- x[[1]]
    N <- length(x)
    xnames <- names(x)
    if (length(xnames)==0) xnames <- 1:N
    y <- vector("list", length=N)
    names(y) <- xnames
    if (named) {
        all.names <- sort(unique(unlist(lapply(x,names))))
        blank <- rep(NA,length(all.names))
        names(blank) <- all.names
        for (i in 1:N) {
            y[[i]] <- blank
            y[[i]][match(names(x[[i]]),all.names)] <- x[[i]]
        }
    } else {
        longest <- max(sapply(x,length),na.rm=TRUE)
        for (i in 1:N) {
            y[[i]] <- rep(NA,longest)
            y[[i]][1:length(x[[i]])] <- x[[i]]
        }
    }
    do.call(cbind, y)
}


apa.names$hacks <- c(apa.names$hacks, "rows.same")
rows.same <- function(mat) { 
	
	## Returns T/F for all rows in 'mat' being same
	
	all(apply(mat, 2, luniq)==1)
}


apa.names$hacks <- c(apa.names$hacks, "cols.same")
cols.same <- function(mat) { 
	
	## Returns T/F for all cols in 'mat' being same
	
	all(apply(mat, 1, luniq)==1)
}


apa.names$hacks <- c(apa.names$hacks, "unlist2")
unlist2 <- function(x, delim=NA) { 
	
	## unlist() without screwing up the names -- uses original names (what a concept!)
	## unless 'delim' specified: then attaches padded numeric extensions, 'delim'-delimited
	
	L <- listLengths(x)
	NAMES <- sort(detable(L))
	U <- unlist(x)   # THIS SORTS BY NAME
	if (!is.na(delim)) {
		for (n in names(L)) {
			w <- which(NAMES==n)
			fmt <- paste(n,delim,"%0",nchar(length(w)),"i",sep="")
			NAMES[w] <- sprintf(fmt, 1:length(w))
		}
	}
	names(U) <- NAMES
	U
}


apa.names$general <- c(apa.names$general, "upper.triangle.fill")
upper.triangle.fill <- function(mat) {
	## mirrors lower-triangular matrix and optionally fills diagonal
	as.matrix(as.dist(mat))
}


apa.names$general <- c(apa.names$general, "listLengths")
listLengths <- function(lst, method=length, ...) { 
	
	## Returns a vector with the lengths of each element (must be ALL vectors or ALL matrices) in a list.  A small shortcut function.
	## Very useful inside a 'table' call.
	## "mat.len" switch only works if list elements are matrices: 
	##  mat.len="length": length = nrow*ncol.
	##  mat.len="nrow": length = nrow.
	##  mat.len="ncol": length = ncol.
	##  mat.len="sum" is used when list elements are logical vectors and only the sum of these vectors (i.e. TRUE elements) is desired; "na.rm=T" used.
	
	if (is.character(method)) method <- get(method)
	method.name <- deparse(substitute(method))
	if (length(lst)==0) {
		IM("Error: list of length 0\n")
		return(NULL)
	} else {
		v <- sapply(lst, method, ...)  # '...' may include na.rm=TRUE, e.g.
	}
    if (is.list(v)) {  # missing entries; get NULL
        for (i in 1:length(v)) if (is.null(v[[i]])) v[[i]] <- 0
        v <- unlist(v)
    }
	return(v)
}


apa.names$general <- c(apa.names$general, "access.list")
access.list <- function(lst, path) {
	
	# 'lst' is a list and 'path' is a numeric vector specifying, recursively, the list elements.
	# E.g. path=c(3,1,2) accesses lst[[3]][[1]][[2]]
	
	path2 <- paste("[[",path,"]]",sep="")
	eval(parse(text=paste(c("lst",path2),collapse="")))
}


apa.names$hacks <- c(apa.names$hacks, "intersect2")
intersect2 <- function(..., method=c("all","any")) {
	
	## N-way intersection, instead of intersect() with is strictly 2-way
	
	method <- match.arg(method)
	if (method == "all") {
		Reduce("intersect", list(...))
	} else if (method == "any") {
		x <- unlist(list(...))
		t <- table(x)
		i <- names(t)[t>1]
		mode(i) <- mode(x)
		i
	}
}


apa.names$hacks <- c(apa.names$hacks, "disjunc2")
disjunc2 <- function(...) {
	
	## N-way disjunction, i.e. returns all elements found in only one set
	
	x <- unlist(list(...))
	t <- table(x)
	d <- names(t)[t==1]
	mode(d) <- mode(x)
	d
}


apa.names$hacks <- c(apa.names$hacks, "setdiff2")
setdiff2 <- function(...) {
	
	## N-way setdiff, instead of setdiff() with is strictly 2-way
	
	x <- list(...)
	setdiff(x[[1]], unlist(x[2:length(x)]))
}


apa.names$hacks <- c(apa.names$hacks, "union2")
union2 <- function(...) {
	
	## N-way union, unstead of union() which is strictly 2-way
	
	unique(unlist(list(...)))
}


apa.names$hacks <- c(apa.names$hacks, "now.seed")
now.seed <- function() {
	
	## Creates a unique random seed from the current date and time
	
    x <- strsplit(gsub("[A-Z: -]", "", Sys.time()), "")[[1]]
    y <- as.numeric(paste(sample(rev(x), 8), collapse = ""))
	z <- y * sample(c(-1,1), 1)
    return(z)
}
