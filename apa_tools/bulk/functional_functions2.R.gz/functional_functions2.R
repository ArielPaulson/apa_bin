

apa.names$dev <- c(apa.names$dev, "FatiClone")
FatiClone <- function(map, db, taxon, bkg.model="genome", levels=c(3,9), alpha=0.05, p.adjust="BH", tails=2, Fclev=0.95, 
	no.dups=FALSE, no.under=FALSE, no.over=FALSE, adjust.all=FALSE, flag.sig.parents=FALSE, flag.sig.children=FALSE, no.sig.parents=FALSE, no.sig.children=FALSE, 
	show.dbs=FALSE, show.taxa=FALSE, intermediate=TRUE, remove.temp=TRUE, genome=NULL, other.annot=NULL, host=NULL, term.OD=NULL, use.DB=NULL, write.dir=NULL) {
	
	## THIS FUNCTION ONLY RUNS ON LINUX SERVERS
	## An interface to /home/apa/local/bin/FatiClone; call with --help to see description of parameters.
	## 'showDBs' and 'showtaxa' override all other arguments and return lists of GO DBs and major taxa.
	## 'intermediate' and 'remove.temp' are not a FatiClone argument:
	##	- 'intermediate' specifies whether to read in FC intermediate data as well as final data (= numbers for all terms)
	##	- 'remove.temp' deletes temp directory after function completes
	
	if (Sys.info()[["sysname"]] != "Linux") { stop("This function can only be run on the Linux servers!\n") }
	if (show.dbs) {
		msg <- system("/home/apa/local/bin/FatiClone --showdbs", intern=TRUE)
		for (i in 1:length(msg)) { IM(msg[i]) }
	} else if (show.taxa) {
		msg <- system("/home/apa/local/bin/FatiClone --showtaxa", intern=TRUE)
		for (i in 1:length(msg)) { IM(msg[i]) }
	} else {
		FC.temp <- tempfile("FatiCloneR")
		system(paste("mkdir -p",FC.temp))
		write.table(map, paste(FC.temp,"map.txt",sep="/"), sep="\t", quote=FALSE, row.names=TRUE, col.names=c(paste("GENE",colnames(map)[1],sep="\t"),colnames(map)[2:ncol(map)]))
		if (length(genome)>0) {
			gfile <- paste(FC.temp,"genome.txt",sep="/")
			write.vector(genome, gfile, sep="\t", quote=FALSE, row.names=FALSE, col.names=FALSE)
			genome <- gfile
		}
		if (length(other.annot)>0) {
			ofile <- paste(FC.temp,"other.annot.txt",sep="/")
			write.table(other.annot, ofile, sep="\t", quote=FALSE, row.names=FALSE, col.names=TRUE)
			other.annot <- ofile
		}
		if (is.null(write.dir)) {
			write.dir <- paste(FC.temp,"output",sep="/")
			system(paste("mkdir -p",write.dir))
		}
		
		params1 <- list(
			levels=list("-l", ternary(all(levels%in%c(3,9)), NULL, paste(levels, collapse="-"))), 
			alpha=list("-a", ternary(alpha == 0.05, NULL, alpha)), 
			p.adjust=list("-j", ternary(p.adjust == "BH", NULL, p.adjust)), 
			tails=list("-t", ternary(tails == 2, NULL, tails)), 
			Fclev=list("-v", ternary(Fclev == 0.95, NULL, Fclev)), 
			genome=list("-g", genome), 
			other.annot=list("-o", other.annot), 
			host=list("-h", host), 
			term.OD=list("-r", term.OD), 
			use.DB=list("-u", use.DB)
		)
		params2 <- list(
			no.dups=list("--nodups", no.dups), 
			no.under=list("--nounder", no.under), 
			no.over=list("--noover", no.over), 
			adjust.all=list("--adjustall", adjust.all), 
			flag.sig.parents=list("--flag_sig_parents", flag.sig.parents), 
			flag.sig.children=list("--flag_sig_children", flag.sig.children), 
			no.sig.parents=list("--no_sig_parents", no.sig.parents), 
			no.sig.children=list("--no_sig_children", no.sig.children)
		)
		
		FC.call <- paste("/home/apa/local/bin/FatiClone -f ",FC.temp,"/map.txt"," -b ",bkg.model," -d ",db," -x ",taxon," -w ",write.dir,sep="")
		for (i in 1:length(params1)) {
			if (length(params1[[i]][[2]])>0) {
				FC.call <- paste(FC.call, params1[[i]][[1]], params1[[i]][[2]])
			}
		}
		for (i in 1:length(params2)) {
			if (params2[[i]][[2]]) {
				FC.call <- paste(FC.call, params2[[i]][[1]])
			}
		}
		
		msg <- system(FC.call, intern=TRUE)
		terms.file <- dir(FC.temp, patt="significant_terms.txt$")[1]    # had better only be one! (or perhaps none)
		genes.file <- dir(FC.temp, patt="significant_genelist.txt$")[1]
		plot.file <- dir(FC.temp, patt="Plot_Table.txt$")[1]
		terms <- read.delim(paste(FC.temp, terms.file, sep="/"))
		genes <- read.delim(paste(FC.temp, genes.file, sep="/"))
		if (intermediate) {
			inter.table <- read.delim(paste(FC.temp,"FatiClone_Fishers_input.txt",sep="/"), header=FALSE)
			colnames(inter.table) <- qw(MAP,CLUST,DB,LEVEL,TERM,FG.W,FG.WO,BG.W,BG.WO,FG.PCT,BG.PCT,LOG2FC,TERM.W,TERM.PCT,ENRICH)
			term.table <- read.delim(paste(FC.temp,"FatiClone_term_table.txt",sep="/"))
			FC.dat <- list(terms=terms, genes=genes, msg=msg, intermediate=inter.table, term.table=term.table)
		} else {
			FC.dat <- list(terms=terms, genes=genes, msg=msg)
		}
		if (ncol(map)>1) {	# will have generated plot data
			FC.dat$plot.file <- read.delim(paste(FC.temp,plot.file,sep="/"))
		}
		if (remove.temp) {
			system("rm -Rf FC.temp")
		}
		return(FC.dat)
	}
}


apa.names$dev <- c(apa.names$dev, "GO.heatmap")
GO.heatmap <- function(fc, clust=NULL, opp=FALSE, terms=NULL, col.hc=FALSE, row.hc=FALSE, nlog10=FALSE, merge.maps=FALSE, ret.data=FALSE) {
	
	## Returns your GO metrics as a plot-ready matrix 
	## Defaults designed for current (v1.5) FatiClone output
	## fc: data.frame = four columns from the GO significant terms file contents: 
	## 		col 1 = map name, col 2 = cluster ID, col 3 = term, col 4 = metric (e.g. adj.p.value) AND POSSIBLY COL 5 = enrichment, if 'opp=TRUE'.
	##		in the default FatiClone sig terms table, these are columns 1, 2, 5 (for term IDs, or 6 if you want term names), and 13, respectively.
	## clust: the clustermap sent to GO analysis; expecting colnames = clustering IDs (map names), col 1 = gene IDs, cols 2-N = cluster mappings
	## 		if NULL, then missing clusters will not be represented in the heatmap
	## opp: was the background model 'opposite'? (i.e., up vs down lists?)
	##      IF TRUE, 'fc' MUST HAVE A 5TH COLUMN: enrichment, values being 'OVER' or 'UNDER'
	## terms: the complete list of terms to heatmap (= 1 row each), if not merely those terms which came back significant.
	## col.hc / row.hc: use hclust to reorder heatmap rows and cols?  Default binary distance / average linkage
	## nlog10: if TRUE, will take -log10(metric column) instead of using the metric directly
	## merge.maps: if TRUE, and 'fc' contains > 1 mapping, all mappings will be put in one matrix (instead of split out into a list of matrices, one per map)
	## ret.data: if TRUE, return a list of data.frames (subsets of 'fc'), one for each heatmap
	
	if (nlog10) fc[,4] <- -log10(fc[,4])
	if (length(clust)>0) {
		genes <- clust[,1]   # remove gene ID column
		clust <- clust[,2:ncol(clust),drop=FALSE]   # replace 'clust' with cluster mappings only
		mapnames <- colnames(clust)
		mapcols <- 1:ncol(clust)
		IM(mapnames,mapcols)
		if (length(mapnames)==0) stop("If specified, 'clust' must have the column names it had when it was sent to GO analysis!\n")
	} else {
		genes <- c()
		mapnames <- sort(unique(fc[,1]))  # first one just a placeholder
		mapcols <- 1:length(mapnames)
	}
	
	HMs <- DSs <- list()
	for (i in mapcols) {  # ignore gene column: mappings only
		uc <- ternary ( length(clust)>0, sort(unique(clust[,i])), sort(unique(fc[fc[,1]==mapnames[i],2])) )
		fc1 <- fc[fc[,1]==mapnames[i],]
		if (opp) over <- grep("^OVER",fc1[,5],ignore.case=TRUE)
		if (nrow(fc1)==0) {
			IM(paste("Warning: map '",mapnames[i],"' has no data!"))
		} else {
			terms2 <- ternary(length(terms)==0, suniq(fc1[,3]), terms)
			mat <- matrix(0, length(terms2), length(uc), F, list(terms2, uc))
			if (opp) {
				for (j in 1:nrow(fc1)) {
					if (j %in% over) {  # over-enriched: assign to positive cluster
						mat[match(fc1[j,3],terms2), match(fc1[j,2],uc)] <- fc1[j,4]
					} else {  # under-enriched: assign to negative cluster
						mat[match(fc1[j,3],terms2), match(-fc1[j,2],uc)] <- fc1[j,4]
					}
				}
			} else {
				for (j in 1:nrow(fc1)) mat[match(fc1[j,3],terms2), match(fc1[j,2],uc)] <- fc1[j,4]
			}
			HMs[[i]] <- mat
			fc2 <- fc1[,1:3]
			lost <- setdiff(uc,fc1[,2])
			if (length(lost) > 0) {
				extra <- fc2[rep(1,length(lost)),]
				extra[,2] <- lost
				extra[,3] <- ""
				fc2 <- rownameless(rbind(fc2, extra))
				fc2 <- fc2[order(fc2[,2]),]
			}
			DSs[[i]] <- fc2
		}
	}
	
	cluster.this <- function(x) {
		ord.c <- ternary(col.hc, hclust(dist(t(x),"binary"),"average")$order, 1:ncol(x))
		ord.r <- ternary(row.hc, hclust(dist(x,"binary"),"average")$order, 1:nrow(x))
		x[x==0] <- NA
		x[ord.r,ord.c]
	}
	
	names(HMs) <- mapnames
	if (length(HMs)==1) {
		HMs <- cluster.this(HMs[[1]])
		DSs <- DSs[[1]]
		DSs <- DSs[,c(1:2,1:3)]
		colnames(DSs)[1:2] <- qw(NEWMAP,NEWCLUST)
	} else if (merge.maps) {
		newnames <- lapply(1:length(HMs), function(i){paste(names(HMs)[i],colnames(HMs[[i]]),sep=":")})
		DSs <- data.frame(NEWMAP="ALL",NEWCLUST="",do.call(rbind,DSs), stringsAsFactors=FALSE)
		allrows <- sort(unique(unlist(lapply(HMs,rownames))))
		allcols <- matrix(c(
			MAP=rep(names(HMs), times=sapply(HMs,ncol)),
			CLUST=unlist(lapply(HMs,colnames)),
			NAME=unlist(newnames)
			), nrow=3, byrow=TRUE)
		alldata <- matrix(0, length(allrows), ncol(allcols), F, list(allrows, allcols[3,]))
		for (i in 1:length(HMs)) {
			w <- which(allcols[1,]==names(HMs)[i])
			alldata[match(rownames(HMs[[i]]),allrows),w[match(colnames(HMs[[i]]),allcols[2,w])]] <- HMs[[i]]
			for (j in 1:ncol(HMs[[i]])) DSs[DSs[,3]==names(HMs)[i] & DSs[,4]==colnames(HMs[[i]])[j],2] <- newnames[[i]][j]
		}
		HMs <- cluster.this(alldata)
	} else {
		for (i in 1:length(HMs)) {
			HMs[[i]] <- cluster.this(HMs[[i]])
			DSs[[i]] <- DSs[[i]][,c(1:2,1:3)]
			colnames(DSs[[i]])[1:2] <- qw(NEWMAP,NEWCLUST)
		}
	}
	
	if (ret.data) {
		list(HEATMAPS=HMs, DATASETS=DSs)
	} else {
		HMs
	}
}


apa.names$dev <- c(apa.names$dev, "GO.heatmap.plus")
GO.heatmap.plus <- function(fcfile, prefix, clust=NULL, terms=NULL, opp=FALSE, merge.maps=FALSE, metric=c("adj.p","raw.p","fg.pct","pct.lfc"), col.hc=FALSE, row.hc=TRUE, 
							term.x=c("all","multi","mono"), main=NULL, sig.par=TRUE, min.genes=1, ens2symb=NULL, las=2, cex=1.4, bkg=0.75, aspect=c(2,1,10), grid=TRUE, view=FALSE) {
	
	## GO.heatmap wrapper that also generates a clickable HTML imagemap.  Only runs on Linux.
	## REQUIRED PARAMETERS:
	## 'fcfile' is -EITHER- a path to a FatiClone "sig terms" file -OR- a data.frame with the UNALTERED contents of said file.
	## 'prefix' is the output prefix of the heatmap PNG that will be produced, which may include a path.  Do not add an extension.  All output images will be PNG.
	## INPUT OPTIONS:
	## 'clust' is a data.frame with col 1 = gene IDs and cols 2-N = mappings; basically what you printed out and sent to FatiClone, to generated 'fcfile'.
	##   If unspecified, any clusters not represented in 'fcfile' will also be missing in the heatmap.  If specified, they each get a blank column.
	## 'terms' gives the complete term set to consider, if all terms not present in 'fcfile'.  Typically used for slim lists.  Missing terms get a blank row each.
	## 'opp' specifies if the FatiClone run used the "opposite" background model (i.e. each cluster can be represented twice: under- and over-enriched)
	## DATA SELECTION AND HANDLING OPTIONS:
	## 'metric' indicates the score to use for the heatmap:
	##   "raw.p", "adj.p" use these p-values.  Will automatically be converted to -log10.
	##   "fg.pct", "pct.lfc" use foreground enrichment percent, or log2(fg.pct/bg.pct), respectively.
	## 'merge.maps': often, FatiClone runs will analyze multiple mappings in one run.  IF FALSE, one heatmap is generated per mapping; if TRUE, all mappings will appear in one heatmap.
	## 'sig.par': if FALSE, ignore "significant parent" entries (those with enrichment labels marked by '*').
	## 'min.genes': ignore terms with fewer than this number of genes in foreground.
	## 'term.x': require that terms in heatmap be found in this many clusters:
	##   "all" = no restrictions; "multi" = 2+ clusters; "mono" = only 1 cluster
	##   This helps to split giant heatmaps (like GO BP results) into "terms with 2+ clusters" and "singleton term" heatmaps.
	## 'ens2symb': Is a data.frame or matrix with col 1 = Ensembl ID and col 2 = symbol. The gene symbols in 'fcfile' will be missing if KEGG was used; this restores them.
	## HEATMAP OPTIONS:
	## 'col.hc': if TRUE, reorders heatmap columns by hclust, dist=binary, linkage=average.
	## 'row.hc': if TRUE, reorders heatmap rows by hclust, dist=binary, linkage=average.
	## 'aspect': given as c(x,y), specifies x:y ratio per heatmap cell.
	## 'ppa': Pixels Per Aspect.  If ppa=10 and aspect=c(2,1), then each heatmap cell will be 20px wide and 10px high.
	## las, cex, main: as usual.
	## HEATMAP2IMAGEMAP SCRIPT OPTIONS:
	## 'bkg': background-color (white) percent value for pixel rows/columns which are NOT in the heatmap body.  If heatmap boundaries don't detect properly, may have to raise this.
	## 'grid': if TRUE, heatmap will have gridlines, and the imagemap script will be informed of this.  Gridline color is hardcoded and expected by downstream scripts.
	## 'view': if TRUE, pops up a window with the cell-detection QC PNG.
	
	if (Sys.info()[["sysname"]] != "Linux") stop("This function can only be run on the Linux servers!\n")
	
	metric <- match.arg(metric)
	term.x <- match.arg(term.x)
	
	if (length(fcfile)>1) {
		fcdat <- fcfile  # assuming data.frame read from file
	} else {
		fcdat <- read.delim(fcfile, stringsAsFactors=FALSE)  # assuming filename
	}
	IM(nrow(fcdat)-1,"FatiClone entries")
	
	if (min.genes > 1) {
		fcdat <- fcdat[fcdat[,17]>=min.genes,]  # must have >= 'min.genes' genes to be considered
		IM(nrow(fcdat)-1,"entries >= min genes")
	}
	
	if (!sig.par) {
		fc <- fc[!grepl("\\*$",fc[,11]),]   # remove sig parent entries
		IM(nrow(fcdat)-1,"non-sig-parent entries")
	}
	
	if (length(ens2symb)>0) {
		if (falsify(all(is.na(fcdat[,25])))) fcdat[,25] <- FatiClone.KEGG.convert(ens2symb[,1:2], fcdat[,24])  # add missing symbols
	}
	
	metric.col <- switch(metric, "raw.p"=12, "adj.p"=13, "fg.pct"=7, "pct.lfc"=9)
	if (opp) {
		fc2hm <- fcdat[,c(1,2,6,metric.col,11)]
	} else {
		fc2hm <- fcdat[,c(1,2,6,metric.col)]
	}
	
	maps <- GO.heatmap(fc2hm, clust=clust, opp=opp, terms=terms, col.hc=col.hc, row.hc=row.hc, nlog10=TRUE, merge.maps=merge.maps, ret.data=TRUE)
#	return(maps)
	if (is.list(maps[[1]])) {
		datasets <- maps[[2]]
		maps <- maps[[1]]
	} else {
		datasets <- list(maps[[2]])
		maps <- list(maps[[1]])   # recast as list
	}
#	return(maps)
#	return(datasets)
	
	prefix <- sub("\\.png$","",prefix)   # just in case
	prefix <- sub("\\.PNG$","",prefix)   # just in case
	grid.col <- ifelse(grid, "grey60", 0)
	grid.flag <- ifelse(grid, "--grid", "")
	
	for (i in 1:length(maps)) {
		mapname <- ifelse (length(names(maps))==0, "ALL", names(maps)[i])
		if (term.x != "all") {
			nrm <- nrow(maps[[i]])
			if (term.x == "multi") {
				maps[[i]] <- maps[[i]][rowSums(!is.na(maps[[i]]))>1,]
				IM("Map",i,":",nrow(maps[[i]]),"/",nrm,"are 'multi' terms")
			} else if (term.x == "mono") {
				maps[[i]] <- maps[[i]][rowSums(!is.na(maps[[i]]))==1,]
				IM("Map",i,":",nrow(maps[[i]]),"/",nrm,"are 'mono' terms")
			}
		}
		if (nrow(maps[[i]])==0 | ncol(maps[[i]])==0) {   # failsafe
			IM("Map",i,"has no data left!!  Skipping.")
			next
		}
		this.imgname <- ifelse (length(maps)==1, paste(prefix,"png",sep="."), paste(prefix,mapname,"png",sep="."))
		IM(this.imgname)
		heat.map(maps[[i]], family="mono", pal="Reds", label.pix=c(NA,NA), aspect=aspect, las=las, cex=cex, main=main, grid.col=grid.col, imgname=this.imgname)
		tempnames <- paste(this.imgname,".names",sep="")
		tempdata <- paste(this.imgname,".data",sep="")
		tempscript <- paste(this.imgname,".sh",sep="")
		IM(tempnames, tempdata, tempscript)
		write.vector(c(	paste(c("ROWS",rownames(maps[[i]])), collapse="\t"), paste(c("COLS",colnames(maps[[i]])), collapse="\t") ), tempnames)
		newnames <- unique(datasets[[i]][,1:4])
		x <- fcdat[which(fcdat[,1]%in%newnames[,3] & fcdat[,2]%in%newnames[,4] & fcdat[,6]%in%datasets[[i]][,5]),]    # & fcdat[,6] %in% datasets[[i]][,4]
		for (j in 1:nrow(newnames)) {
			w <- which(x[,1]==newnames[j,3] & x[,2]==newnames[j,4])
			if (length(w)==0) next
			x[w,1] <- newnames[j,1]
			x[w,2] <- newnames[j,2]
		}
		write.table(x, tempdata, sep="\t", quote=FALSE, row.names=FALSE)
		write.vector(paste("/home/apa/local/bin/heatmap2imagemap -h",this.imgname,"-d",tempdata,"-n",tempnames,"-b",bkg,grid.flag), tempscript)
		cmd <- paste("./",tempscript,sep="")
		IM(cmd)
		system(cmd)
		if (view) view.image(sub("png$","imagemap.png",this.imgname))
	}
}


apa.names$microarray <- c(apa.names$microarray, "va2GO")
va2GO <- function(va, filename=NULL, no.univ=TRUE) { 
    
    ## Takes a venn.areas object and converts it to a FatiClone-ready list.
    ## Writes it to file if 'filename' specified.
    
    gnames <- rep(names(va), times=listLengths(va))
    tab <- nameless(cbind(unlist(va), gnames))
    colnames(tab) <- c("Gene","Group")
    if (no.univ) { tab <- tab[tab[,2]!="Excluded",] }
    if (is.null(filename)) {
        return(tab)
    } else {
        write.table(tab, filename, sep="\t", quote=FALSE, row.names=FALSE)
    }
}


apa.names$bio.seq <- c(apa.names$bio.seq, "gox.barplot")
gox.barplot <- function(gox, imgname, grp, genes=NULL, style=NULL, colors=NULL, N=TRUE, Pct=FALSE, imgdim=NA) {
    
    ## UNDER CONSTRUCTION
    
    ## 'go' is a FatiClone sig terms table, or something with near-identical format, sp. colnames (see definition of 't.cols' and 'style').
    ## 'grp' is a column number in 'go' which will act as the grouping vector, i.e. each unique value of this column will get its own set of bars with its own color.
    ##  -OR- grp is a list, elem 1 is the column num, elem 2 is a list (names=group names, elems=strings in that column to be assigned to this group).
    ## 'style' is a list, and indicates if one-way or butterflied plot.  Butterflied plots require under- and over-enriched terms, OR, two groups to compare.  Examples below.
    ##  - example 'style' for a one-way, overenriched plot:  style=list(OVER=NA)     ##  OVER indicates overenriched terms (right-pointing bars), NA indicates no term selection.
    ##  - example 'style' for a one-way, underenriched plot: style=list(UNDER=NA)    ## UNDER indicates underenriched terms (left-pointing bars), NA indicates no term selection.
    ##  - example 'style' for a butterflied plot: style=list(OVER=10,UNDER=10)       ## Both over and under, using column 10 to select terms (by default, looks for "OVER" amnd "UNDER")
    ##  - example 'style' for a butterflied plot: style=list(OVER=c(1,"Up"),UNDER=c(1,"Down"))  ## As above, but using column 1 to select terms, where "Up" terms go right and "Down", left.
    ##  - if unspecified, the default style is "style=list(OVER=NA)"
    ## 'genes' indicates the column number where gene IDs exist.  Expected format per cell is a semicolon-delimited list of IDs.  If supplied, will report N unique genes per term group.
    ## 'N=TRUE' plots N genes with term on the term bar.
    ## 'Pct=TRUE' plots term saturation percent (pct of enriched gene set with term) on the term bar.
    
    if (length(style)==0) style <- list(OVER=NA)
    do.genes <- length(genes)>0
    term.name <- grep("^Term.Name$",colnames(gox))
    if (length(term.name)==0) stop("Could not identify term name column!\n")
    rownames(gox) <- gox[,term.name]
    if (is.list(grp)) {
        group <- rep("",nrow(gox))
        g0 <- breakout(grp[[2]], rev=TRUE)
        g1 <- gox[,grp[[1]]]
        for (i in 1:nrow(g0)) {
            group[which(g1==g0[i,2])] <- g0[i,1]
        }
    } else {
        group <- gox[,grp]
    }
    t.cols <- mgrep(c("^Term.Acc","^(Adj.P|FDR)","^Clust.Term","^Clust.With$"), colnames(gox))
    if (length(t.cols)>4) stop("Ambiguous column names: cannot uniquely identify key columns!\n")
    if (do.genes) {
        gox <- gox[,c(t.cols,genes)]
    } else {
        gox <- gox[,t.cols]
    }
    colnames(gox) <- c("Accession","nLogFDR","PercentWithTerm","GenesWithTerm")
    gox <- cbind(Group=group, I=0, gox)
    nc <- ncol(gox)
    gox.m <- lapply(mat.split(gox,group), function(x) x[order(x[,3]),] )
    gox.m <- gox.m[real(match(names(colors),names(gox.m)))]
    for (i in 1:length(gox.m)) gox.m[[i]]$I <- i
    M <- length(gox.m)
    if (do.genes) {
        gox.mG <- gox.mGu <- lapply(gox.m, function(x) lapply(named.list(strsplit(x[,nc],";"),rownames(x)), function(y) sub("^ +","",sub(" +$","",y)) ))
        gox.mGt <- lapply(gox.mG, function(x) table(unlist(x)) )
        for (i in 1:M) {
            for (j in 1:length(gox.mG[[i]])) gox.mGu[[i]][[j]] <- intersect(gox.mG[[i]][[j]], names(gox.mGt[[i]])[c(gox.mGt[[i]])==1])  # N genes UNIQUE TO THIS TERM, if any
            gox.m[[i]] <- cbind(gox.m[[i]], ExclusiveToTerm=listLengths(gox.mGu[[i]]))[,c(1:(nc-1),nc+1,nc)]  # keep Xrefs last
        }
    }
    group.G <- cbind(
        Tot=sapply(gox.mG, function(x) luniq(unlist(x)) ),                             # for each group in gox.m, N unique genes across all terms
        Excl=sapply(1:M, function(i) lsetd(unlist(gox.mG[[i]]),unlist(gox.mG[-i])) )   # for each group in gox.m, N unique genes across all terms, which are NOT found in the other groups
    )
    dimnames(group.G) <- list(names(gox.m),c("Total","Exclusive"))
    
    gm <- do.call(rbind, lapply(1:length(gox.m), function(i) {
        x <- gox.m[[i]]
        x[,4] <- -log10(x[,4])
        if (length(style)>1) {
###############  *ifelse(x[1,2]=="Young",1,-1);     ## MAKE SOME BARS GO NEGATIVE
        }
        x[rev(order(x[,4])),c(1,2,4,6,7)]
    }))
    gm <- cbind(gm, Color=colors[match(gm[,1],names(colors))])
    
    ## PLOT CODE NOT READY YET
    ## EXAMPLE BELOW
    
    if (FALSE) {
        ## imgdim=NA: auto-decide dims
        ## ensure imgname ends with ".pdf"!
        ## if one-way (or even if two), ensure back-side of bars has enough room to plot labels
        
        imgw <- 15
        imgh <- 7
        
        pdf(imgname, imgw, imgh)
        par(mar=c(5,1,4,1), family="mono", yaxs="i", cex=0.8)
        ##, xlim=c(-3.6,5.5), ylim=c(0,33.5), xaxt="n"
        b <- barplot(rev(gm[,3]), horiz=T, col=rev(gm$Col), bord=rev(gm$Col), xlab="-Log10 FDR", main="Significant GO Terms")
        bmax <- max(b)
        axis(1, -2:3, c(2:0,1:3))  #; abline(v=0)
        typos <- rep(4,nrow(gm)); typos[gm[,3]<0] <- 2
        txpos <- sapply(gm[,3], function(x) ifelse(x<0, -2, 3.5))
        txpos <- gm[,3]
        text(rev(txpos), b, rev(rownames(gm)), pos=rev(typos), cex=0.8)
        text(0, b-0.1, rev(format(gm[,4])), pos=rev(c(2,NA,4)[sign(gm[,3])+2]), cex=1)  # x=rev(c(0.1,NA,-0.1)[sign(gm[,3])+2])
        text(-0.1, bmax-mean(b[gm$I==1]), paste("Proteins (Young),",group.G[[1]],"genes"), cex=1.2, pos=2, font=2, col=unique(gm$Col)[1])
        text(-0.1, bmax-mean(b[gm$I==3])+0.7, paste("Chromo (Young),",group.G[[3]],"genes"), cex=1.2, pos=2, font=2, col=unique(gm$Col)[2])
        text(0.1, bmax-mean(b[gm$I==4]), paste("Chromo (Old),",group.G[[5]],"genes"), cex=1.2, pos=4, font=2, col=unique(gm$Col)[2])
        text(0.1, bmax-mean(b[gm$I==5]), paste("Immune (Old),",group.G[[4]],"genes"), cex=1.2, pos=4, font=2, col=unique(gm$Col)[3])
        text(-0.05, bmax+diff(b[1:2])-0.1, "N Genes", pos=4, cex=1)
        dev.off(); system(paste("evince",imgname))
        
    }
    
   list(data=gm, genes=group.G)
}


apa.names$dev <- c(apa.names$dev, "chrom.DE.density")
chrom.DE.density <- function(n, L, genes, gene.p=0.05, bin.p=0.02, min.genes=2, plot=TRUE, ymax=NULL, sig=TRUE, aspect=NULL, xticks=15) {
    
    ## 'n' is a chromosome name
    ## 'L' is that chromosome's length
    ## 'genes' is a matrix/data.frame with rows = genes on that chromosome, rownames = gene IDs, and 4 columns = logFC, p-value, start.coord, end.coord
    ## 'gene.p' and 'bin.p' are p-value cutoffs to determine DE genes, and DE-enriched bins, respectively
    ## 'min.genes' will not test a window for significance unless it contains at least this many genes
    
#    require(GenomicRanges)
    
    message(paste("Processing",n))
    genes <- genes[order(genes[,3]),,drop=FALSE]  # order by start
    which.DE <- which(genes[,2]<=gene.p)
    genes.DE <- genes[which.DE,,drop=FALSE]  # DE-only
    gene.ids <- rownames(genes)
    gene.ids.DE <- rownames(genes.DE)
    mid.TOT <- rowMeans(genes[,3:4])
    mid.DE <- rowMeans(genes.DE[,3:4])
    pos <- which(genes.DE[,1]>0)
    neg <- which(genes.DE[,1]<0)
    NP <- length(pos)
    NN <- length(neg)
    NDE <- NN+NP
    NTOT <- nrow(genes)
    scale <- ifelse(L>1E7, 1E6, 1E4)
    bin.size <- 5*L/NTOT
    half.size <- trunc(bin.size/2)+1
    dhist.args <- list(vecs=list(UP=mid.DE[pos],DOWN=mid.DE[neg]), dens.n=2^12, adjust=1, bw=bin.size, denorm=TRUE, ylab="")
    
    if (plot) {
        dhist.args <- c(dhist.args, list(col=c(2,4), points=TRUE, xlim=c(0,L), main=paste("Sig DE Gene Density Along",n), xaxt="n"))
        if (length(ymax)>0) dhist.args <- c(dhist.args, list(ylim=c(0,ymax)))
        par(las=1, xaxs="i")
        if (NP>2|NN>2) {
            d <- do.call(dhist, dhist.args)
        } else {
            null.plot(main=paste("Sig DE Gene Density Along",n))
        }
        axmax <- round(trunc(L/scale),-1)
        axlab <- seq(0, axmax, xticks)
        axis(1, at=axlab*scale, labels=paste0(axlab,ifelse(scale==1E6,"M","K")))
    } else {
        if (NP>2|NN>2) {
            d <- do.call(dhist, c(dhist.args, list(plot=FALSE)))
        } else {
            d <- list(ylim=c(0,0))
        }
    }
    
    if (sig) {
        message(" Calculating bin gene counts...")
        
        bin.mids <- lapply(d$density, "[[", "x")
        bin.genes <- lapply(bin.mids, function(x) lapply(x, function(i) {
            list(
                TOT=which(mid.TOT>=i-half.size & mid.TOT<=i+half.size),
                DE=which.DE[which(mid.DE>=i-half.size & mid.DE<=i+half.size)],
                POS=which.DE[pos[which(mid.DE[pos]>=i-half.size & mid.DE[pos]<=i+half.size)]],
                NEG=which.DE[neg[which(mid.DE[neg]>=i-half.size & mid.DE[neg]<=i+half.size)]]
            )
        }) )
        bin.N.genes <- lapply(bin.genes, function(x) t(sapply(x,listLengths)) )
        
        bin.winstat <- lapply(1:2, function(i){
            bmi <- bin.mids[[i]]
            data.frame(
                CHROM=n,
                START=bmi-half.size,
                END=bmi+half.size,
                NAME=paste0(names(bin.mids)[i],".",sprintf(paste0("%0",nchar(max(length(bmi))),"i"),1:length(bmi))),
                DE.GENES=bin.N.genes[[i]][,"DE"],
                STRAND="+",
                I=i,
                BIN=1:length(bmi),
                Y=d$density[[i]]$y
            )
        }); names(bin.winstat) <- names(bin.mids)
        
        message(" Calculating bin FET p-values...")
#        ## FULL VERSION -- mothballed -- rarely get sig pos-only, neg-only windows, and no provision for plotting them either
#        ## also, contingency table math is wrong...
#        bin.FET.p <- lapply(bin.N.genes, function(x) t(apply(x, 1, function(y) {  
#            c(
#                ALL=fisher.test(matrix(c(DE.IN=y[2],DE.OUT=NDE-y[2],ALL.IN=y[1],ALL.OUT=NTOT-y[1]),2))[[1]]
#                POS=fisher.test(matrix(c(DE.IN=y[3],DE.OUT=NP-y[3],ALL.IN=y[2],ALL.OUT=NDE-y[2]),2))[[1]],
#                NEG=fisher.test(matrix(c(DE.IN=y[4],DE.OUT=NN-y[4],ALL.IN=y[2],ALL.OUT=NDE-y[2]),2))[[1]]
#            )
#        })))
#        bin.sig <- lapply(bin.FET.p, function(x) apply(x, 2, function(y) which(y<=0.01) ))  # FULL VERSION -- mothballed
        
        bin.FET.p <- lapply(bin.N.genes, function(x) {
            apply(x, 1, function(y) {
                if (y[2]>=min.genes) {
                    DE.IN <- y[2]
                    DE.OUT <- NDE-DE.IN
                    NONDE.IN <- y[1]-DE.IN
                    NONDE.OUT <- NTOT-DE.IN-NONDE.IN-DE.OUT
                    m <- matrix(c(DE.IN,DE.OUT,NONDE.IN,NONDE.OUT),2)
                    if (sum(m) != NTOT) message(paste0("WARNING: FET contingency does not sum correctly!  ",paste(c(m),collapse="+"),"=",sum(m)," not ",NTOT,"!\n"))
                    fisher.test(m)[[1]]
                } else {
                    NA
                }
            })
        })
        for (i in 1:2) bin.winstat[[i]] <- cbind(bin.winstat[[i]], FET.P=bin.FET.p[[i]], SIG=falsify(bin.FET.p[[i]]<=bin.p))
        bin.sig <- lapply(bin.FET.p, function(x) which(falsify(x<=bin.p)) )
        d$significance <- list(bin.size=bin.size, bin.mids=bin.mids, bin.N.genes=bin.N.genes, bin.FET.p=bin.FET.p, bin.sig=bin.sig)
        nsig <- length(unlist(bin.sig))
        
        if (nsig>0) {
            
            bin.winstat.sig <- lapply(bin.winstat, function(x) x[x$SIG,] )
            bin.sig.truexy <- do.call(rbind, bin.winstat.sig)
            bin.sig.truexy <- bin.sig.truexy[order(bin.sig.truexy$START),]
            bin.sig.truex.merge <- find.runs(diff(bin.sig.truexy$START)<bin.size)
            bin.sig.truex.merge <- bin.sig.truex.merge[names(bin.sig.truex.merge) == "TRUE"]
            for (j in 1:length(bin.sig.truex.merge)) bin.sig.truex.merge[[j]][2] <- bin.sig.truex.merge[[j]][2]+1  # incorporate right endpoint, which was previously in a "FALSE"-named element (or missing, if last value)
            bin.sig.truex.merged <- unlist(lapply(bin.sig.truex.merge, function(x) x[1]:x[2] ))
            bin.sig.truex.singleton <- setdiff(1:nrow(bin.sig.truexy), bin.sig.truex.merged)  # any unmerged points
            if (length(bin.sig.truex.singleton)>0) for (i in 1:length(bin.sig.truex.singleton)) bin.sig.truex.merge <- c(bin.sig.truex.merge, "SINGLE"=list(rep(bin.sig.truex.singleton[i],2)))
            
            sig.win.bed <- rownameless(do.call(rbind, lapply(bin.sig.truex.merge, function(x) {
                w <- x[1]:x[2]
                winstats <- rbind(
                    bin.winstat.sig$UP[bin.winstat.sig$UP$NAME %in% bin.sig.truexy$NAME[w],],
                    bin.winstat.sig$DOWN[bin.winstat.sig$DOWN$NAME %in% bin.sig.truexy$NAME[w],]
                )
                data.frame(
                    CHROM=n,
                    START=min(winstats$START),
                    END=max(winstats$END),
                    NAME="",
                    DE.GENES=0,
                    STRAND="+",
                    MIN.Y=min(winstats$Y),
                    MAX.Y=max(winstats$Y),
                    MIN.P=min(winstats$FET.P),
                    MAX.P=max(winstats$FET.P)
                )
            })))
            sig.win.bed$NAME <- names(bin.sig.truex.merge) <- paste0("Sig.Window.",1:length(sig.win.bed))
            nwin <- nrow(sig.win.bed)
            
            sig.win.orig.bins <- lapply(bin.sig.truex.merge, function(x) lapply(bin.winstat.sig, function(y) y$BIN[y$NAME %in% bin.sig.truexy$NAME[x[1]:x[2]]] ))
            sig.win.bed.genes <- lapply(sig.win.orig.bins, function(x) {
                genes <- lapply(1:2, function(i) {
                    list(
                        TOT=sort(unique(unlist(lapply(bin.genes[[i]][min(x[[i]]):max(x[[i]])], "[[", "TOT")))),
                        DE=sort(unique(unlist(lapply(bin.genes[[i]][min(x[[i]]):max(x[[i]])], "[[", "DE"))))
                    )
                })
                list(
                    TOT=sort(unique(unlist(lapply(genes, "[[", "TOT")))),
                    DE=sort(unique(unlist(lapply(genes, "[[", "DE"))))
                )
            })
            sig.win.bed$DE.GENES <- listLengths(lapply(sig.win.bed.genes, "[[", "DE"))
            sig.win.bed$TOT.GENES <-  listLengths(lapply(sig.win.bed.genes, "[[", "TOT"))
            
            ### WORKING HERE
            ### THE ISSUE IS: density ran independently on up, down does not have same window positions.
            ###               when combining up + down windows in one sig window, gene counts can change from the original FET counts.
            ###               SOLUTIONS: 1) forget FET values once windows are merged, 2) run density on all-DE just for window calcs (preferred).
            
            sig.win.genes <- lapply(1:nwin, function(i) {
                sig.win.orig.bins
            })
            
            sig.win.genes <- lapply(1:nwin, function(i) {
                rownameless(unique(do.call(
                    rbind,
                    lapply(bin.genes, function(y) {
                        w <- sort(unique(unlist(y[x[1]:x[2]])))
                        data.frame(GeneID=gene.ids[w],genes[w,,drop=FALSE])
                    })
                )))
            })
            d$significance <- c(d$significance, list(sig.windows=rownameless(sig.win.bed), sig.window.genes=sig.win.genes))
            
            if (plot) {
                yrange.1pct <- diff(d$ylim)*0.01
                margin <- diff(range(d$point.y))/length(bin.sig)
                win.xplot.range <- sig.win.bed[,2:3]
                win.yplot.range <- rowrep(c(min(d$point.y)-margin*2, max(d$point.y)+margin*2), nrow(win.xplot.range))
                if (length(aspect)>0) {
                    margin.x <- (diff(d$xlim)*aspect[1])*margin/(diff(d$ylim)*aspect[2]) / 2
                    win.xplot.range[,1] <- win.xplot.range[,1]-margin.x
                    win.xplot.range[,2] <- win.xplot.range[,2]+margin.x
                }
                for (i in 1:length(bin.sig.truex.merge)) rect(win.xplot.range[i,1], win.yplot.range[i,1], win.xplot.range[i,2], win.yplot.range[i,2], border=3, lwd=1)
            }
        }
    }
    
    invisible(d)
}


apa.names$general <- c(apa.names$general, "fisherize")
fisherize <- function(obj, tails=2, workspace=2E05, adj="BH") {
    
    ## Given a vector = c(foreground.with, foreground.without, background.with, background.without), return a vector:
    ##  c(original vector, fg.ratio, bg.ratio, log2FC, enrichment, raw.p, NA)  where NA is the adjusted-pvalue placeholder
    ## Given a matrix/df where each row = vectors as formatted above, return a matrix/df where each row is:
    ##  c(original row, fg.ratio, bg.ratio, log2FC, enrichment, raw.p, adj.p)
    ##
    ## "tails" = 1 or 2 indicating fisher.test "alternative" values of (greater|lesser) or two-tailed, respectively.
    ##  in the 1-tailed case, the choice of tail automatically adjusts to the FG/BG ratio.  In the trivial case where FGR=BGR, tails=2.
    ## "workspace" is passed to fisher.test as is.
    ## "adj" specified p-adjustment method; only meaningful if "obj" is a matrix/df.
    
    fishers <- function(vec) {
        fgr <- vec[1]/sum(vec[1:2])
        bgr <- vec[3]/sum(vec[3:4])
        lfc <- zerofy(log2(fgr/bgr))  # occasionally, get 0/0
        enrich <- sign(lfc)
        alt <- ifelse(tails==2|lfc==0, "two.sided", ifelse(fgr>bgr, "greater", "less"))
        raw.p <- fisher.test(matrix(vec,nrow=2), alternative=alt, workspace=workspace)[[1]]
        return(c(vec,fgr,bgr,lfc,enrich,raw.p,NA))
    }
    
    if (is.nlv(obj)) {
        if (length(obj)!=4) { stop("'obj' must have length 4: c(foreground.with, foreground.without, background.with, background.without)\n") }
        return( fishers(obj) )
    } else if (is.matrix(obj) || is.data.frame(obj)) {
        if (ncol(obj)!=4) { stop("'obj' must have 4 columns: c(foreground.with, foreground.without, background.with, background.without)\n") }
        x <- t(apply(obj, 1, fishers))
        x[,10] <- p.adjust(x[,9], method=adj)
        colnames(x) <- qw(FG.W,FG.WO,BG.W,BG.WO,FG.PCT,BG.PCT,LOG2FC,ENRICH,RAW.P,ADJ.P)
        return(x)
    } else {
        stop("'obj' must be a non-list vector, matrix, or dataframe!\n")
    }
}


apa.names$bio.seq <- c(apa.names$bio.seq, "find.GO.terms")
find.GO.terms <- function(data=NULL, keywords=NULL, accessions=NULL, geneIDs=NULL, ignore=NULL, type=NULL, db=NULL, taxon=NULL, ID.conv=NULL, ancestors=FALSE) {
    
    ## 1. to initialize, run: go.dat <- find.GO.terms(db=go_DB_name, taxon=NCBI_taxon_id)  DO NOT specify 'data'; this means you have already initialized.
    ##    optionally include argument "ID.conv=cbind(from,to)" to convert from GO DB IDs to analysis IDs
    ## 2A. find GO terms like: find.GO.terms(go.dat, keywords="mitochon")
    ##    CAN ONLY USE ONE OF 'keywords', 'accessions', or 'geneIDs' PER CALL.
    ##    'keywords' can be > 1; search is "OR" not "AND".  Alternatives are in development.
    ## 2B. alternatively, filter GO terms by genes instead of by term information: use "geneIDs=c(ids)"
    ## 2C. optional 'ignore' is a list of things to filter out; list elements must be 'keywords', 'accessions' (can have both).
    ##     Example: "ignore=list( keywords=c(...), accessions=c(...) )"
    ##     also, restrict to types by adding 'type="BP"' or 'type=c("BP","CC")', etc.
    ## 3. get all progeny for selected accessions: find.GO.terms(go.dat, accessions=c("GO:0000266","GO:0008053")).  Only works with accessions.
    ## 
    ## Filters can be applied successively (crude "AND" method) e.g.: find.GO.terms(find.GO.terms(go.dat, keywords="mitochon"), keywords="biogenesis")
    ## With each search filter, output term sets and gene lists are restricted to matching terms.
    ##  - so, the initial GO object (here 'go.dat') should be left unmodified, to allow maximum queriability.
    
    kids <- NULL
    
    get.ignore.accs <- function(terms=NULL) {
        ## gets 'ignore' from parent namespace
        ignore.accs <- c()
        if (length(ignore$accessions)>0) ignore.accs <- ignore$accessions
        if (length(terms)>0) {
            if (length(ignore$keywords)>0) {
                ## ignore$keywords only converted to accessions if a 'terms' object is specified
                any.ignore <- apply(sapply(ignore$keywords,grepl,terms$Term,ignore.case=TRUE),1,any)
                ignore.accs <- c(ignore.accs, terms$Accession[any.ignore])
            }
        }
        ignore.accs
    }
    
    if (length(data)==0) {
        
        if (length(keywords)>0 | length(accessions)>0 | length(geneIDs)>0 | length(ignore)>0 | ancestors) stop("When initializing a find.GO.terms object (i.e. no 'data' object), only 'db', 'taxon' and 'ID.conv' may be specified!\n")

        datpref <- paste0("/home/apa/local/bin/GO_Tools_DBcache/find.GO.terms/",db,".",taxon,".RData")
        
        if (file.exists(datfile) & length(ID.conv)==0) {
            
            message("Loading existing datfile for db/taxon...")
            load(datfile)   # gets ready-made 'output'
            
        } else {
            
            t.cmd <- paste("/home/apa/local/bin/GO_Tools --termtable -x",taxon,"-d",db)
            message(paste0("Running: '",t.cmd,"' ..."))
            terms <- read.delim(pipe(paste(t.cmd,"2> /dev/null")),as.is=TRUE,header=TRUE)
            terms <- terms[terms$Accession!="all",]
            terms <- terms[order(terms[,3],terms[,1]),c(2:1,3:4,4:9)]
            colnames(terms)[5] <- "Min.Level"
            terms$Min.Level <- as.integer(sapply(terms$Levels, function(x) strsplit(x,",")[[1]][1] ))
            if (length(type)>0) {
                if (all(type %in% terms$Type)) {
                    terms <- terms[terms$Type %in% type,]
                } else {
                    message(paste(c("ASKED TYPES:",sort(unique(type)))))
                    message(paste(c("FOUND TYPES:",sort(unique(terms$Type)))))
                    if (!(any(type %in% terms$Type))) stop("No terms of type '",type,"' exist!\n")
                }
            }
            
            gt.cmd <- paste("/home/apa/local/bin/GO_Tools --getdbids -x",taxon,"-d",db,"--clean --long")
            message(paste0("Running: '",gt.cmd,"' ..."))
            geneterms <- read.delim(pipe(paste(gt.cmd,"2> /dev/null")),as.is=TRUE,header=TRUE)
            if (length(ID.conv)>0) {
                genes <- split(geneterms[,3], geneterms[,5])
                which.is.input <- which.max(apply(ID.conv,2,function(x) sum(x%in%geneterms[,3]) ))
                if (which.is.input==2) ID.conv <- ID.conv[,2:1]  # want input IDs in column 1, converted IDs in column 2
                genes2 <- lapply(genes, function(x) sort(unique(ID.conv[ID.conv[,1] %in% x,2])) )
                genes <- data.frame(GeneID=unlist(genes2), Accession=rep(names(genes), times=listLengths(genes2)))
            } else {
                genes <- data.frame(GeneID=geneterms[,3], Accession=geneterms[,5])
            }
            rownames(genes) <- NULL
            output <- list(db=db,taxon=taxon,terms=terms,genes=genes,children=kids)
            if (length(ID.conv)==0) save(output, file=datfile)   # SAVE ONLY NATIVE, NOT CONVERTED, OBJECTS
            
        }
        
    } else {
        
        db <- data$db
        taxon <- data$taxon
        
        ## temp data object given, mine it.
        K <- length(keywords)
        A <- length(accessions)
        G <- length(geneIDs)
        
        if (K>0) {
            
            has.key <- 
                if (K==1) {
                    grepl(keywords[1],data$terms$Term,ignore.case=TRUE)
                } else {
                    apply(sapply(keywords,grepl,data$terms$Term,ignore.case=TRUE),1,any)
                }
            is.type <-
                if (length(type)>0) {
                    data$terms$Type %in% type
                } else {
                    rep(TRUE,nrow(data$terms))
                }
            terms <- data$terms[has.key & is.type,]
            
            ignore.accs <- get.ignore.accs(terms)
            terms <- terms[!(terms$Accession %in% ignore.accs),]
            terms <- terms[order(terms$Type,terms$Min.Level),]
            genes <- data$genes[data$genes$Accession %in% terms$Accession,]
            
        } else if (A>0) {
            
            if (ancestors) {
                
                a.cmd <- paste("/home/apa/local/bin/GO_Tools --nca -a",paste(accessions,collapse=","),"-x",taxon,"-d",db)
                message(paste0("Retrieving nearest common ancestor...\nRunning: '",a.cmd,"' ..."))
                anc <- read.delim(pipe(paste(a.cmd,"2> /dev/null")), as.is=TRUE, header=FALSE)
                message(paste(c("Nearest Ancestor(s) Found:\n",anc[1,]),collapse=" "))
                w <- match(anc[1,1], data$terms$Accession)
                if (!is.na(w)) {
                    return(data$terms[w,])
                } else {
                    return(anc[1,])
                }
                
            } else {
                
                accs2 <- paste0(accessions,collapse=",")
                k.cmd <- paste("/home/apa/local/bin/GO_Tools --slimtree -a",accs2,"-x",taxon,"-d",db)
                message(paste0("Retrieving progeny for ",accs2,"\nRunning: '",k.cmd,"' ..."))
                k.raw <- as.data.frame(read.delim(pipe(paste(k.cmd,"2> /dev/null")), as.is=TRUE, header=TRUE))
                ignore.accs <- get.ignore.accs(k.raw)
                kids <- lapply(1:A, function(i) {
                    i.raw <- k.raw[k.raw$Parent==accessions[i],]
                    k.dat <- data$terms[match(i.raw$Accession,data$terms$Accession),]
                    ## some progeny accessions may not match (i.e. have no associated terms); patch up k.dat just in case
                    k.dat$Accession <- i.raw$Accession
                    k.dat$Term <- i.raw$Term
                    k.dat$Type <- data$terms$Type[data$terms$Accession==accessions[i]]
                    lok <- which(!is.na(i.raw$Level))
                    k.dat$Levels[lok] <- i.raw$Level[lok]
                    k.dat[order(k.dat$Min.Level, k.dat$Levels),]
                    if (length(ignore.accs)>0) k.dat <- k.dat[!(k.dat$Accession %in% ignore.accs),]
                    k.dat
                })
                names(kids) <- paste(accessions, data$terms$Term[match(accessions,data$terms$Accession)])
                kid.accs <- unique(unlist(lapply(kids, "[[", "Accession")))
                
                terms <- data$terms[data$terms$Accession %in% kid.accs,]
                genes <- data$genes[data$genes$Accession %in% terms$Accession,]
                
            }
            
        } else if (G>0) {
            
            has.gene <- data$terms$Accession %in% unique(data$genes$Accession[data$genes$GeneID %in% geneIDs])
            is.type <-
                if (length(type)>0) {
                    data$terms$Type %in% type
                } else {
                    rep(TRUE,nrow(data$terms))
                }
            terms <- data$terms[has.gene & is.type,]
            
            ignore.accs <- get.ignore.accs(terms)
            terms <- terms[!(terms$Accession %in% ignore.accs),]
            terms <- terms[order(terms$Type,terms$Min.Level),]
            genes <- data$genes[data$genes$GeneID %in% geneIDs & data$genes$Accession %in% terms$Accession,]
            genes 
            
        } else {
            
            stop("No query specified!  Use 'keywords' or 'accessions'\n")
            
        }
        
        rownames(genes) <- NULL
        output <- list(db=db,taxon=taxon,terms=terms,genes=genes,children=kids)
    }
    
    output
}


