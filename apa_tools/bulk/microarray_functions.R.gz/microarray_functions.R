

apa.names$microarray <- c(apa.names$microarray, "query.microarray.library")
query.microarray.library <- function(arrayID=NULL) {
	
	## Returns contents of "microarray_library.R" as a list
	## arrayID, if specified, will return only the contents for that array (if exists)
	
	path <- switch(Sys.info()[["sysname"]], 
		"Windows"="S:",
		"Linux"="/n",
		"Darwin"="/Volumes",
		NA
		)
	if (is.na(path)) stop(paste("Unknown system type '",Sys.info()[["sysname"]],"'!  Must be Windows, Linux, or Darwin\n",sep=""))
	
	libfile <- file.path(path,"Genomics","Molbio_Users","APA","R_Things","microarray_library","microarray_library.R")
	array.lib <- read.delim(libfile, sep="\t", header=FALSE, fill=TRUE, blank.lines.skip=TRUE, stringsAsFactors=FALSE, comment.char="#")
	brks <- which(array.lib[,1] == ".")	# should only be two
	headcols <- 1:5		# NOTE THAT COLUMNS ARE HARDCODED
	featcols <- 1:5		
	datacols <- 1:6		# EACH SECTION HAS DIFFERENT NCOLS
	ctrlcols <- 1:8		
	parscols <- 1:8		# BE CAREFUL WHEN ADDING NEW DATA TO LIBRARY
	lib <- list(
		head=array.lib[(brks[1]+2):(brks[2]-1),headcols],	
		feat=array.lib[(brks[2]+2):(brks[3]-1),featcols],
		data=array.lib[(brks[3]+2):(brks[4]-1),datacols],
		ctrl=array.lib[(brks[4]+2):(brks[5]-1),ctrlcols],
		pars=array.lib[(brks[5]+2):nrow(array.lib),parscols]
	)
	colnames(lib$head) <- array.lib[(brks[1]+1),headcols]
	colnames(lib$feat) <- array.lib[(brks[2]+1),featcols]
	colnames(lib$data) <- array.lib[(brks[3]+1),datacols]
	colnames(lib$ctrl) <- array.lib[(brks[4]+1),ctrlcols]
	colnames(lib$pars) <- array.lib[(brks[5]+1),parscols]
	
	if (is.null(arrayID)) {
		IDlist <- unique(lib$head[,2])
	} else {
		if (!arrayID %in% lib$head[,2]) { 
			cat("Array ID not found!  Please add it.\nReturning known arrays:\n")
			IM(paste(colnames(lib$head), collapse="\t"))
			for (i in 1:nrow(lib$head)) { IM(paste(lib$head[i,], collapse="\t")) }
			return()
		} else {
			chk <- lib$feat[which(lib$feat[,2] == arrayID),]
			if (length(chk) == 0) { stop("Array exists but no features have been entered!  Please add some to:\nlibfile\n") }
			IDlist <- arrayID
		}
	}
	
	Nids <- length(IDlist)
	data <- warns <- vector("list", length=Nids)
	names(data) <- names(warns) <- IDlist
	for (i in 1:Nids) {
		hrow <- match(IDlist[i], lib$head[,2])
		x <- c(
			which(lib$pars[,3] == lib$head[hrow,3] & lib$pars[,4] == lib$head[hrow,4]),
			which(lib$pars[,3] == "any" & lib$pars[,4] == lib$head[hrow,4]),
			which(lib$pars[,3] == lib$head[hrow,3] & lib$pars[,4] == "any"),
			which(lib$pars[,3] == "any" & lib$pars[,4] == "any")
		      )											# supported features for array type
		allow <- lib$pars[x,2]									# allowed features
		reqd <- lib$pars[x[which(lib$pars[x,5] == 1)],2]					# mandatory features
		y <- which(lib$feat[,2] == IDlist[i])							# arrayID entries in features section
		
		if (length(y) > 0) {
			given <- unique(lib$feat[y,3])							# given features for specific array
			ok1 <- reqd %in% given
			ok2 <- given %in% allow
			
			if (!all(ok1)) {	# required fields missing
				missing <- paste(reqd[!ok1], collapse=", ")
				IM(paste("The following mandatory fields for platform '", lib$head[hrow,3],"' type '", lib$head[hrow,4],"' are not present in the library: ", missing, sep=""))
				warns[[i]] <- c(warns[[i]], 1)	# missing required data flag
			}
			
			if (!all(ok2)) {	# unsupported fields exist
				oddball <- paste(given[!ok2], collapse=", ")
				IM(paste("The following fields are unknown for platform '", lib$head[hrow,3],"' type '", lib$head[hrow,4],"': ", oddball, sep=""))
				warns[[i]] <- c(warns[[i]], 2)	# unsupported data flag
			}
			
			xo <- x[match(lib$feat[y,3], lib$pars[x,2])]
			feats <- as.matrix.data.frame(join.tables(lib$feat[y,3:5], lib$pars[,c(2,6:7)], join=3))		# feat: KEY, VALUE, COMMENTS; pars: DELIMITED, MULTI
			all <- union(given, reqd)
			
			data[[i]] <- vector("list", length=nrow(feats)+1)
			names(data[[i]]) <- c("header", as.character(feats[,1]))
			data[[i]]$header <- lib$head[hrow,]
	#		data[[i]]$QC <- list(x=x, y=y, reqd=reqd, allow=allow, given=given)
			
			for (j in 1:length(all)) {
				z <- which(feats[,1] == all[j])
				if (length(z) > 1) {
					if (feats[z,5] == 1) {	# > 1 entry ok
						data[[i]][[all[j]]] <- vector("list", length=length(z))
						for (k in 1:length(z)) {
							value <- feats[z[k],2]
							data[[i]][[all[j]]][[k]] <- list(value=value, comments=feats[z[k],3])		# add value(s)
						}
					} else {
						IM(paste("Warning: Array ID '",IDlist[i],"' has more than one entry for feature '",feats[j,1],"'!  Using only the first...",sep=""))
						warns[[i]] <- c(warns[[i]], 3)		# improper duplicate data flag
						value <- feats[z[1],2]			# only taking first entry
						data[[i]][[all[j]]] <- list(value=value, comments=feats[z[1],3])		# add value(s)
					}
				} else {
					value <- feats[z,2]			# only taking first entry
					data[[i]][[all[j]]] <- value							# add value(s)
					data[[i]][[all[j]]] <- list(value=value, comments=feats[z,3])			# add value(s)
				}
			}
		} else {
			IM(paste("No features recorded for platform '", lib$head[hrow,3],"' type '", lib$head[hrow,4],"'!  Please add some to:\nlibfile\n",sep=""))
		}
	}
	
	return(data)
}


apa.names$microarray <- c(apa.names$microarray, "YOG.controls")
YOG.controls <- function(ID.vec) {
	
	## Takes RG$genes$ID from a YOG-type array and returns a logical vector indicating the controls
	
	ctls <- list(ALL=c(), ambion=c(), Alien=c(), YBOX=c(), YCONTROL=c(), EMPTY=c())
	for (i in 2:length(ctls)) { ctls[[i]] <- grep(names(ctls)[i], ID.vec) }
	ctls[[1]] <- sort(unlist(ctls)); names(ctls[[1]]) <- NULL	
	return(ctls)
}


apa.names$microarray <- c(apa.names$microarray, "parse.controls")
parse.controls <- function(idents, arrayID) {
	
	## Function to return index sets (and other data) for each control type, incl. spikes if used
	## idents = MA$genes$ID or RG$genes$ID, e.g.
	## arrayID = array ID from library file (= design number, for Agilent arrays)
	
	array.lib <- query.microarray.library(arrayID)
	if (length(array.lib) == 0) { stop("No array with that ID was found!  Please check library or add this array.\n") }
	
	pctrls <- records[which(records[,4] == "pctrls"),5]
	nctrls <- records[which(records[,4] == "nctrls"),5]
	spikes <- records[which(records[,4] == "spikes"),5]
	if (length(pctrls) == 0) { IM("No positive controls have been entered for this array!  Please add some to the library.\n") }
	if (length(nctrls) == 0) { IM("No negative controls have been entered for this array!  Please add some to the library.\n") }
	pnames <- unlist(strsplit(pctrls, ',', fixed=TRUE))
	nnames <- unlist(strsplit(nctrls, ',', fixed=TRUE))
	
	cstyles <- data.frame(
		col <- c("grey50","darkred","forestgreen","purple3","red","chartreuse","orchid","gold"),
		pch <- c( 1,       16,       7,            15,       22,   20,          21,      3    ),
		stringsAsFactors=FALSE
	)	# available control type plot styles
	spCols <- c("navy","blue","cornflowerblue")	# absolute-logratio colors for spikes, from most to least extreme (Agilent Only)
	
	x <- list()
	x$defLine <- array.lib[which(array.lib[,1] == "ARRAYDEF" & array.lib[,2] == arrayID),2:ncol(array.lib)]
	x$nonCtl <- c()		# place here, load later
	
	if (length(pnames)+length(nnames) > 0) {
		x$ctlAtt <- data.frame(
			name=c(nnames,pnames),
			dir=c( rep(-1,length(nnames)), rep(1,length(pnames)) ),
			col=cstyles$col[1:N],
			pch=cstyles$pch[1:N],
			stringsAsFactors=FALSE
		)
		
		N <- length(x$ctlAtt$name)
		x$ctlSets <- vector("list", length=N)
		names(x$ctlSets) <- x$ctlAtt$name
		for (i in 1:N) { x$ctlSets[[i]] <- grep(x$ctlAtt$name[i], idents, fixed=TRUE) }
	}
	x$nonCtl <- setdiff(1:length(idents), unlist(x$ctlSets))
	
	spikeAtt <- data.frame(
		name=paste("(+)E1A_r60",c("a22","3","a97","a104","1","a20","n11","a107","a135","n9"),sep="_"),
		ratio=c(1/10,1/3,1/3,1/3,1,1,3,3,3,10),
		col=c(spCols[1],rep(spCols[2],3),rep(spCols[3],2),rep(spCols[2],3),spCols[1]),
		pch=c(25,25,25,25,5,5,24,24,24,24),
		stringsAsFactors=FALSE
	)
	spikeSets <- vector("list", length=10)
	names(spikeSets) <- spikeAtt$name
	for (i in 1:10) { spikeSets[[i]] <- which(idents == spikeAtt$name[i]) }
	
	if (length(unlist(x$spikeSets)) == 0) {
		IM("No spike controls are known for this array.\n")
	} else {
		x$spikeAtt <- spikeAtt
		x$spikeSets <- spikeSets
		x$spikeLines <- data.frame(
			y=c(10, 3, 1, 1/3, 1/10),
			col=c(spCols[1],spCols[2],spCols[3],spCols[2],spCols[1]),
			stringsAsFactors=FALSE
		)
	}
	
	return(x)	# objects: { defLine nonCtl }, maybe { ctlAtt ctlSets }, maybe also { spikeAtt spikeSets spikeLines }
}


apa.names$microarray <- c(apa.names$microarray, "parse.controls2")
parse.controls2 <- function(idents, arrayID) {
	
	## Function to return index sets (and other data) for each control type, incl. spikes if used
	## idents = MA$genes$ID or RG$genes$ID, e.g.
	## arrayID = array ID from library file (= design number, for Agilent arrays)
	
	array.lib <- read.delim("S:/Genomics/Molbio_Users/APA/R_Things/microarray_library.R", sep="\t", header=TRUE, fill=TRUE, blank.lines.skip=TRUE, stringsAsFactors=FALSE)
	records <- array.lib[which(array.lib[,1] == "FEATURES" & array.lib[,2] == arrayID),]
	if (length(records) == 0) { stop("No array with that ID was found!  Please check library or add this array.\n") }
	
	pctrls <- records[which(records[,4] == "pctrls"),5]
	nctrls <- records[which(records[,4] == "nctrls"),5]
	spikes <- records[which(records[,4] == "spikes"),5]
	if (length(pctrls) == 0) { IM("No positive controls have been entered for this array!  Please add some to the library.\n") }
	if (length(nctrls) == 0) { IM("No negative controls have been entered for this array!  Please add some to the library.\n") }
	pnames <- unlist(strsplit(pctrls, ',', fixed=TRUE))
	nnames <- unlist(strsplit(nctrls, ',', fixed=TRUE))
	
	cstyles <- data.frame(
		col <- c("grey50","darkred","forestgreen","purple3","red","chartreuse","orchid","gold"),
		pch <- c( 1,       16,       7,            15,       22,   20,          21,      3    ),
		stringsAsFactors=FALSE
	)	# available control type plot styles
	spCols <- c("navy","blue","cornflowerblue")	# absolute-logratio colors for spikes, from most to least extreme (Agilent Only)
	
	x <- list()
#	x$defLine <- array.lib[which(array.lib[,1] == "ARRAYDEF" & array.lib[,2] == arrayID),2:ncol(array.lib)]
#	REPLACE WITH: $defline, subelements $ID, $Provider, $Assay, $Name, $Organism, $Genome, $Multislide
#	ALWAYS RETURN A FULL OBJECT WITH NON-NULL ENTRIES (e.g. ""'s or _type_(0)'s)
	
	x$nonCtl <- c()		# place here, load later
	
	if (length(pnames)+length(nnames) > 0) {
		x$ctlAtt <- data.frame(
			name=c(nnames,pnames),
			dir=c( rep(-1,length(nnames)), rep(1,length(pnames)) ),
			col=cstyles$col[1:N],
			pch=cstyles$pch[1:N],
			stringsAsFactors=FALSE
		)
		
		N <- length(x$ctlAtt$name)
		x$ctlSets <- vector("list", length=N)
		names(x$ctlSets) <- x$ctlAtt$name
		for (i in 1:N) { x$ctlSets[[i]] <- grep(x$ctlAtt$name[i], idents, fixed=TRUE) }
	}
	x$allCtl <- unlist(x$ctlSets)
	x$nonCtl <- setdiff(1:length(idents), x$allCtl)
	
	spikeAtt <- data.frame(
		name=paste("(+)E1A_r60",c("a22","3","a97","a104","1","a20","n11","a107","a135","n9"),sep="_"),
		ratio=c(1/10,1/3,1/3,1/3,1,1,3,3,3,10),
		col=c(spCols[1],rep(spCols[2],3),rep(spCols[3],2),rep(spCols[2],3),spCols[1]),
		pch=c(25,25,25,25,5,5,24,24,24,24),
		stringsAsFactors=FALSE
	)
	spikeSets <- vector("list", length=10)
	names(spikeSets) <- spikeAtt$name
	for (i in 1:10) { spikeSets[[i]] <- which(idents == spikeAtt$name[i]) }
	
	if (length(unlist(x$spikeSets)) == 0) {
		IM("No spike controls are known for this array.\n")
	} else {
		x$spikeAtt <- spikeAtt
		x$spikeSets <- spikeSets
		x$spikeLines <- data.frame(
			y=c(10, 3, 1, 1/3, 1/10),
			col=c(spCols[1],spCols[2],spCols[3],spCols[2],spCols[1]),
			stringsAsFactors=FALSE
		)
	}
	
	return(x)	# objects: { arrayDef allCtl nonCtl }, maybe { ctlAtt ctlSets }, maybe also { spikeAtt spikeSets spikeLines }
}


apa.names$microarray <- c(apa.names$microarray, "fc.sets")
fc.sets <- function(x.vec, y.vec, fc.max, slope=1, stdev=FALSE) {
	
	## Groups points from a diagonal scatterplot into absolute-fold-change bands.
	## 'x.vec' and 'y.vec' are the vectors from the scatterplot.
	## 'slope' sets the slope of the diagonal, if for some reason it is not 1 (e.g. MA plot).
    ## 'stdev', if true, uses standard deviations instead of fold-changes
	## 'fc.max' is the maximum fold-change limit to use.  Will be rounded to nearest integer if not an integer.
	##   Fold-changes will be calculated in units of 1 from 0 to fc.max.  Anything beyond fc.max is grouped into the final set.
	##   Both + and - fc groups are pooled together, e.g. all points between 1-2 FC and -1--2 FC are put into one set.
	
	ok <- intersect( which(!is.na(x.vec)), which(!is.na(y.vec)) )
	if (fc.max %% 1 != 0) { fc.max <- round(fc.max, 0) }
	bounds <- 0:fc.max
	lims <- fold.sets <- vector("list", length=length(bounds))
	
	theta <- thetacon(slope, "slope", "radians")	# from apa_functions.R
	scale <- tan(theta) / sin(theta)
	if (is.nan(scale)) { scale <- 1 }
	
	for (i in 1:fc.max) {
		p.o.lim <- sapply(x.vec[ok], FUN=function(x,m,b){ m*x+scale*b }, slope, bounds[(i+1)])
		p.i.lim <- sapply(x.vec[ok], FUN=function(x,m,b){ m*x+scale*b }, slope, bounds[i])
		n.i.lim <- sapply(x.vec[ok], FUN=function(x,m,b){ m*x-scale*b }, slope, bounds[i])
		n.o.lim <- sapply(x.vec[ok], FUN=function(x,m,b){ m*x-scale*b }, slope, bounds[(i+1)])
				
#		lims[[i]] <- cbind(p.o.lim, p.i.lim, n.i.lim, n.o.lim)
		fold.sets[[i]] <- ok[c(
			which(y.vec[ok] >= p.i.lim & y.vec[ok] < p.o.lim), 
			which(y.vec[ok] <= n.i.lim & y.vec[ok] > n.o.lim)
		)]
	}
	fold.sets[[(i+1)]] <- setdiff(ok, unlist(fold.sets))
		
	invisible(fold.sets)
}


apa.names$microarray <- c(apa.names$microarray, "get.saturation")
get.saturation <- function(RG, threshold=NULL, as.pct=FALSE) {
	
	## Gets channel saturation from an RG object and returns a matrix of dimension RG$R,
	##  with entries of "R", "G", "B", or NA indicating spot saturation in R, G, both, or neither.
	## "as.pct=T" replaces NA with 0, "R" and "G" with 0.5, and "B" with 1
	
	if (is.null(threshold)) { threshold <- 65500 }
	
	Rsat <- RG$R > threshold
	Gsat <- RG$G > threshold
	Bsat <- Rsat + Gsat == 2
	
	if (as.pct) {
		mat <- matrix(data=0, nrow=nrow(RG$R), ncol=ncol(RG$R))
		mat[Rsat] <- 0.5
		mat[Gsat] <- 0.5
		mat[Bsat] <- 1
	} else {
		mat <- matrix(data=NA, nrow=nrow(RG$R), ncol=ncol(RG$R))
		mat[Rsat] <- "R"
		mat[Gsat] <- "G"
		mat[Bsat] <- "B"
	}
	return(mat)
}


apa.names$microarray <- c(apa.names$microarray, "decideTests2")
decideTests2 <- function (object, method="separate", adjust.method="BH", p.value=0.05, lfc=0) {
	
	## Hacked version; produces a list with:
	##   element 1 = original output, 
	##   element 2 = adjusted p-value matrix behind the original output
	
	if (!require(limma)) { stop("Cannot load 'limma' package!\n") }
	if (!is(object, "MArrayLM")) { stop("Need MArrayLM object") }
	if (is.null(object$t)) { object <- eBayes(object) }
	method <- match.arg(method, c("separate", "global", "hierarchical", "nestedF"))
	adjust.method <- match.arg(adjust.method, c("none", "bonferroni", "holm", "BH", "fdr", "BY"))
	if (adjust.method == "fdr") 
		adjust.method <- "BH"
	switch(method, separate = {
		p <- as.matrix(object$p.value)
		tstat <- as.matrix(object$t)
		for (j in 1:ncol(p)) {
			o <- !is.na(p[, j])
			p[o, j] <- p.adjust(p[o, j], method = adjust.method)
		}
		val <- p
		sel <- sign(tstat) * (p < p.value)
		results <- list(new("TestResults", sel), val)
	}, global = {
		p <- as.matrix(object$p.value)
		tstat <- as.matrix(object$t)
		o <- !is.na(p)
		p[o] <- p.adjust(p[o], method = adjust.method)
		val <- p
		sel <- sign(tstat) * (p < p.value)
		results <- list(new("TestResults", sel), val)
	}, hierarchical = {
		if (any(is.na(object$F.p.value))) { stop("Can't handle NA p-values yet") }
		val <- p.adjust(object$F.p.value, method = adjust.method)
		sel <- val < p.value
		i <- sum(sel, na.rm = TRUE)
		n <- sum(!is.na(sel))
		a <- switch(adjust.method, none = 1, bonferroni = 1/n, holm = 1/(n - i + 1), BH = i/n, BY = i/n/sum(1/(1:n)))
		results1 <- new("TestResults", array(0, dim(object$t)))
		dimnames(results1) <- dimnames(object$coefficients)
		if (any(sel)) { results1[sel, ] <- classifyTestsP(object[sel, ], p.value = p.value * a, method = adjust.method) }
		results <- list(results1, val)
	}, nestedF = {
		if (any(is.na(object$F.p.value))) { stop("Can't handle NA p-values yet") }
		val <- p.adjust(object$F.p.value, method = adjust.method) 
		sel <- val < p.value
		i <- sum(sel, na.rm = TRUE)
		n <- sum(!is.na(sel))
		a <- switch(adjust.method, none = 1, bonferroni = 1/n, 
			holm = 1/(n - i + 1), BH = i/n, BY = i/n/sum(1/(1:n)))
		results1 <- new("TestResults", array(0, dim(object$t)))
		dimnames(results1) <- dimnames(object$coefficients)
		if (any(sel)) { results1[sel, ] <- classifyTestsF(object[sel, ], p.value = p.value * a) }
		results <- list(results1, val)
	})
	if (lfc > 0) {
		if (is.null(object$coefficients)) { 
			warning("lfc ignored because coefficients not found") 
		} else {
			results[[1]]@.Data <- results[[1]]@.Data * (abs(object$coefficients) > lfc)
		}
	}
	results
}


apa.names$microarray <- c(apa.names$microarray, "fix.YOG.orfnames")
fix.YOG.orfnames <- function(vec) {
	Aliens <- grep("Alien",vec)
	vec[Aliens] <- unlist(sub("_A$","",vec[Aliens]))
	vec <- unlist(sub("_[0-9_]+$","",vec))
	vec <- unlist(sub("([WC][A-Z])[0-9]{1,2}$","\\1",vec))
	vec <- unlist(sub("([WC])([A-Z])$","\\1-\\2",vec))
	return(vec)
}


apa.names$microarray <- c(apa.names$microarray, "subset.MARG")
subset.MARG <- function(obj, rows=NULL, cols=NULL, keep=TRUE) {
	
	## Removes columns and/or rows (given as vectors) from an MA or RG object
	## 'keep=T' indicates specified rows/cols are to be KEPT
	## 'keep=F' indicates specified rows/cols are to be REMOVED
	
	fit <- FALSE
	mdim <- dim(obj[[1]])	# dim of obj$R of obj$M
	
	if (is(obj, "RGList")) {
		mats <- c("R","G","Rb","Gb","weights")
	} else if (is(obj,"MAList")) {
		mats <- c("M","A","weights")
	} else {
		stop("Object must be of class 'RGList' or 'MAList'!\n")
	}
	
	if (!is.null(rows)) {
		ternary (keep, krows <- rows, krows <- c(1:mdim[1])[-rows])	# which rows get kept?
		for (i in mats) { obj[[i]] <- obj[[i]][krows,] }
		ternary ( is.null(dim(obj$genes)), obj$genes <- obj$genes[krows], obj$genes <- obj$genes[krows,] )
	}
	
	if (!is.null(cols)) {
		ternary (keep, kcols <- cols, kcols <- c(1:mdim[1])[-cols])	# which cols get kept?
		for (i in mats) { obj[[i]] <- obj[[i]][,kcols] }
		obj$targets <- as.data.frame(obj$targets[kcols,])	# columns == targets _rows_!
		rownames(obj$targets) <- colnames(obj$weights)
		colnames(obj$targets) <- "FileName"
	}
	
	return(obj)
}


apa.names$microarray <- c(apa.names$microarray, "flatten.MARG")
flatten.MARG <- function(obj, flat, merge="mean", merge.wts="max", na.rm=TRUE, transform=NULL) {
	
	## Produces a gene-flattened MA or RG object
	## Uses aggregate(), by=transform(flat), function=merge / merge.wts
	## '...' are any params passed to 'transform' function, if specified
	
	if (is(obj, "RGList")) {
		mats <- c("R","G","Rb","Gb")
	} else if (is(obj, "MAList")) {
		mats <- c("M","A")
	} else {
		stop("Object must be of class 'RGList' or 'MAList'!\n")
	}
	
	nco <- ncol(obj$weights)
	ternary (is.null(transform), g <- flat, g <- transform(flat))
	flats <- list()
	
	for (n in mats) { 
		flats[[n]] <- as.matrix(aggregate(obj[[n]], by=list(g), FUN=merge, na.rm=na.rm)[,(1:nco+1)]) 
		flats[[n]][is.nan(flats[[n]])] <- NA
	}
	W <- aggregate(obj$weights, by=list(g), FUN=merge.wts, na.rm=na.rm)
	agg <- W[,1]
	
	flats$weights <- W[,(1:nco+1)]
	flats$genes <- agg
	flats$printer <- NULL
	
	for (n in names(flats)) { obj[[n]] <- flats[[n]] }
	return(obj)
}


apa.names$microarray <- c(apa.names$microarray, "merge.MARG")
merge.MARG <- function(obj.list) {
	
	## Merges two or more RG or MA objects into one (e.g. for multislide array sets)
	
	merged <- obj.list[[1]]
	targets <- vector("list", length=length(obj.list))
	ncols <- prints <- sources <- rep("", length(obj.list))
	
	for (i in 1:length(obj.list)) {
		sources[i] <- obj.list[[i]]$source
		prints[i] <- paste(unlist(obj.list[[i]]$printer), collapse=".")
	}
	
	if (length(unique(sources)) > 1) { stop("Cannot merge objects from different sources!\n") }	# really just for data quality reasons -- be consistent!
	
	if (is(merged, "RGList")) {
		
		## RG-specific QC
		if (length(unique(prints)) > 1) { stop("Cannot merge RG objects with different print dimensions!\n") }
		for (i in 1:length(obj.list)) { ncols <- ncol(obj.list[[i]]$R) }
		if (length(unique(ncols)) > 1) { stop("Cannot merge objects with differing numbers of columns!\n") }
		
		## Merge
		for (i in 2:length(obj.list)) {
			merged$R <- rbind(merged$R, obj.list[[i]]$R)
			merged$Rb <- rbind(merged$Rb, obj.list[[i]]$Rb)
			merged$G <- rbind(merged$G, obj.list[[i]]$G)
			merged$Gb <- rbind(merged$Gb, obj.list[[i]]$Gb)
			merged$genes <- rbind(merged$genes, obj.list[[i]]$genes)
			merged$weights <- rbind(merged$weights, obj.list[[i]]$weights)
		}
		
	} else if (is(merged, "MAList")) {
		
		## MA-specific QC
		for (i in 1:length(obj.list)) { ncols <- ncol(obj.list[[i]]$M) }
		if (length(unique(ncols)) > 1) { stop("Cannot merge objects with differing numbers of columns!\n") }
		
		## Merge
		for (i in 2:length(obj.list)) {
			merged$M <- rbind(merged$M, obj.list[[i]]$M)
			merged$A <- rbind(merged$A, obj.list[[i]]$A)
			merged$genes <- rbind(merged$genes, obj.list[[i]]$genes)
			merged$weights <- rbind(merged$weights, obj.list[[i]]$weights)
		}
	} else if (is(merged, "MArrayLM")) {
		stop("'MArrayLM' objects cannot be merged due to the statistics they carry.  Instead, use lmFit() on the merged MA object.\n")
	} else {
		stop("Object must be of class 'RGList' or 'MAList'!\n")
	}
	
	## Update print dimensions
	merged$printer$ngrid.r <- merged$printer$ngrid.r * length(obj.list)
	
	## Merge and flatten targets
	tnames <- merged$targets <- vector("list", length=ncols[1])
	for (i in 1:length(obj.list)) {
		entries <- unlist(obj.list[[i]]$targets)
		rnames <- rownames(obj.list[[i]]$targets)
		for (j in 1:length(entries)) {
			merged$targets[[j]] <- c(merged$targets[[j]], entries[j])
			tnames[[j]] <- c(tnames[[j]], rnames[j])
		}
	}
	for (j in 1:length(merged$targets)) { 
		merged$targets[[j]] <- data.frame(A=unique(merged$targets[[j]]))
		rownames(merged$targets[[j]]) <- unique(tnames[[j]]) 
		colnames(merged$targets[[j]]) <- colnames(obj.list[[1]]$targets)
	}
	
	return(merged)
}


apa.names$microarray <- c(apa.names$microarray, "augment.fit")
augment.fit <- function(fit, input, adjust.method="BH", method="separate", merge.wts="mean", sat.RG=NULL, sat.thresh=NULL) {

	## Use input=NULL for Affy; otherwise specify input

	## augment.fit aways does:
	## Adds per-group A values (matrix, like fit$coefficients) according to embedded design matrix
	## Adds as-is stdevs for coefficients and A values
	## Adds adj.p.values object:
	##  'method' and 'adjust.method' are passed to decideTests2 to generate adjusted p-values

	## If 'input' is an MAList object:
	## Transfers weights from an MA object to a fit object, using the embedded design matrix; also adds adj p values and saturated spot percents.
	## 'merge.wts' specifies how replicate weights are merged into a single value: values can be "mean", "median", "min", "max"

	if (!is(fit, "MArrayLM")) { stop("'fit' must be an object of class 'MArrayLM'!\n") }
	
	method <- match.arg(method, c("separate", "global", "hierarchical", "nestedF"))
	adjust.method <- match.arg(adjust.method, c("bonferroni", "holm", "BH", "fdr", "BY", "none"))
     
    denoms <- rep(0, ncol(fit$design))
	sat.pct <- SD.coefficients <- SD.Ameans <- Ameans <- weights <- fit$coefficients
	
	if (is(input,"MAList")) {
		type <- 1
		merge.wts <- match.arg(merge.wts, c("mean", "median", "min", "max"))
		if (!is.null(sat.RG)) {
			sat.mat <- get.saturation(sat.RG, sat.thresh, as.pct=TRUE) 
			sat.mat <- sat.mat * 2	# convert from % channels affected to # channels affected
			sat.ok <- TRUE
		} else {
			sat.ok <- FALSE
		}
		colnames(weights) <- colnames(fit$coefficients)
	} else if (is(input,"AffyBatch") | is(input,"ExpressionSet")) {
		type <- 2
		input <- exprs(input)
	} else if (is(input,"matrix") | is(input,"data.frame")) {
		type <- 2
		input <- as.matrix(input)
	} else { 
		stop("'input' must be an object of class 'matrix', 'data.frame', 'MAList', 'AffyBatch', or 'ExpressionSet'!\n")
	}
     
	if (!is.null(fit$contrasts)) {
		cont <- TRUE
		design2 <- matrix(0, nrow=nrow(fit$design), ncol=ncol(fit$contrasts))  # cols indicate which inputs to summarize for each contrast
		for (i in 1:ncol(design2)) {
			x <- which(fit$contrasts[,i] != 0)
			design2[,i] <- rowSums(fit$design[,x])
		}
	} else {
		cont <- FALSE
		design2 <- fit$design
	}
     
	for (i in 1:ncol(design2)) {
		denoms[i] <- sum(design2[,i] != 0)
		x <- which(design2[,i] != 0)
		if (type == 1) {
			Ameans[,i] <- apply(input$A[,x], 1, mean, na.rm=TRUE)
			weights[,i] <- apply(input$weights[,x], 1, merge.wts, na.rm=TRUE)
			if (sat.ok) {
				sat.pct[,i] <- apply(sat.mat[,x], 1, sum, na.rm=TRUE)
				sat.pct[,i] <- sat.pct[,i] / denoms[i]
			}
			SD.coefficients[,i] <- apply(input$M[,x], 1, sd, na.rm=TRUE)
			SD.Ameans[,i] <- apply(input$A[,x], 1, sd, na.rm=TRUE)
		} else if (type == 2) {
			Ameans[,i] <- apply(input[,x], 1, mean, na.rm=TRUE)
			SD.coefficients[,i] <- apply(input[,x], 1, sd, na.rm=TRUE)
			SD.Ameans[,i] <- apply(input[,x], 1, sd, na.rm=TRUE)
		}
	}
	fit$adj.p.value <- decideTests2(fit, method=method, adjust.method=adjust.method)[[2]]
	fit$stdev.coefficients <- SD.coefficients
	fit$stdev.Ameans <- SD.Ameans
	fit$Ameans <- Ameans
    if (type == 1) {
        fit$saturation.pct <- sat.pct
        fit$weights <- weights
    }
	return(fit)
}


apa.names$microarray <- c(apa.names$microarray, "subset.augmented.fit")
subset.augmented.fit <- function(fit, vec) {
     
     ## Subsets a fit object by a row index vector
     ## Also searches for nonstandard 'fit' elements and subsets them as well
     
     orig <- nrow(fit$coefficients)
#     fit <- fit[vec,]
     x <- which(sapply(sapply(fit, nrow), length) == 1)
     y <- unlist(sapply(fit, nrow)[x])
     z <- which(y == orig)
     for (i in x[z]) { fit[[i]] <- fit[[i]][vec,] }
     return(fit)
}


apa.names$microarray <- c(apa.names$microarray, "select.genes")
select.genes <- function(fit, fixed=NULL, alpha=0.05, adj="BH", select="any", more=FALSE, preselect.F=NA, same.sign=FALSE, lfc=NA, lods=NA, ctls=NULL, as.list=FALSE, split=FALSE) {
	
	## Upgrade: add stdevs switch?
	
	## Selects genes from a fit object, based on certain criteria, and returns them topTable-style
	## 'fixed' specifies a row vector of selections; all other switches except 'adj', 'more' and 'as.list' will be ignored.
	## 'alpha' controls p-value threshold
	## 'adj' specifies what method to use for p.adjust -- if NA, then p values are not adjusted
	## 'select' controls whether a gene is required to be significant in at least one column (any) or all columns (all)
	## 'more' adds topTable columns (ONLY if fit object is augmented)
	## 'preselect.F=value' subsets the fit object based on F.p.value <= preselect.F, PRIOR TO any other selections being made.
	##  - NOTE: using 'preselect.F' will boost adjusted p values, because the number of p values decreases.
	## 'same.sign=T' ignores any genes that change sign between contrasts 
	## 'lfc' specifies a minimum absolute log-fold-change for selections
	## 'lods' specifies a minimum absolute log-odds for selections
	## 'ctls' is a logical (or binary) vector indicating which rows are controls.  If specified, controls will be dropped (BEFORE p adjustment).
	## 'as.list=T' returns results as a list of matrices; otherwise a dataframe is returned
	## 'split=T' splits results by fold-change direction (ONLY if same.sign=T)
	
	match.arg(select, c("any", "all"))
	if (is.na(adj)) { adj <- "none" }
	match.arg(adj, c("holm", "hochberg", "hommel", "bonferroni", "BH", "BY", "fdr", "none"))
	
	weights <- ifelse(is.na(match("weights", names(fit))), FALSE, TRUE)
	aug <- ifelse(is.na(match("Ameans", names(fit))), FALSE, TRUE)
	
	if (is.null(fixed)) {
		if (!is.na(preselect.F)) { 
			fit <- subset.augmented.fit(fit, which(fit$F.p.value <= preselect.F))
		}
	}
	
	fit$adj.p <- fit$p.value
	for (i in 1:ncol(fit$adj.p)) { fit$adj.p[,i] <- p.adjust(fit$p.value[,i], method=adj) }
	
	if (!is.null(fixed)) {
		same.sign <- split <- FALSE	# ignored
		fit <- subset.augmented.fit(fit, fixed)
	} else {
		selections <- list()	# these are what genes can be selected by
		if (!is.na(alpha)) { selections$adj.p=which(apply(adj.p <= alpha, 1, select) == TRUE) }		# 'select' is 'all' or 'any'
		if (same.sign) { selections$sign=which(apply(sign(fit$coef) == 1, 1, is.invariant) == TRUE) }
		if (!is.na(lfc)) { selections$lfc=which(apply(fit$lfc <= alpha, 1, select) == TRUE) }
		if (!is.na(lods)) { selections$lods=which(apply(fit$lods <= alpha, 1, select) == TRUE) }
		if (!is.null(ctls)) { selections$nonctl=which(!ctls) }
		
		x <- intersect2(selections)
		if (length(x) > 0) { 
			cat(length(x),"genes meet all criteria.\n"); flush.console()
			fit <- subset.augmented.fit(fit, x)
		} else {
			stop("Selections too stringent: no genes meet all criteria!\n") 
		}
	}
	
	if ("contrasts" %in% names(fit)) {
		contrast <- ifelse (max(colSums(fit$contrasts!=0)) > 1, TRUE, FALSE)   # contrasts fit or expression fit?
	} else {
		contrast <- FALSE
	}
	
	if (!aug) { 
		cat("Warning: Not augmented fit object, which is nicer...  See augment.fit().\n"); flush.console() 
		fit$Ameans <- cbind(fit$Amean, fit$Amean, fit$Amean)
		colnames(fit$Ameans) <- colnames(fit$coefficients)
	}
	
	if (aug && more) { 
		if (contrast) {
			tnames <- c("logFC","sd.logFC","AveExpr","sd.AveExpr","t","P.Value","adj.P.Val","logOdds")
		} else {
			tnames <- c("AveExpr","sd.AveExpr","t","P.Value","adj.P.Val","logOdds")
		}
		if (weights) { tnames <- c(tnames,"AvgWts") }
	} else {
		if (contrast) {
			tnames <- c("logFC","AveExpr","t","P.Value","adj.P.Val","logOdds")
		} else {
			tnames <- c("AveExpr","t","P.Value","adj.P.Val","logOdds")
		}
	}
     
	if (as.list) {
		if (aug && more) { 
			if (contrast) {
				top <- list(fit$genes, fit$coef, fit$stdev.coefficients, fit$Ameans, fit$stdev.Ameans, fit$t, fit$p.value, fit$adj.p, fit$lods)
			} else {
				top <- list(fit$genes, fit$coef, fit$stdev.coefficients, fit$t, fit$p.value, fit$adj.p, fit$lods)
			}
			if (weights) { top <- c(top, fit$weights) }
		} else {
			if (contrast) {
				top <- list(fit$genes, fit$coef, fit$Ameans, fit$t, fit$p.value, fit$adj.p, fit$lods)
			} else {
				top <- list(fit$genes, fit$coef, fit$t, fit$p.value, fit$adj.p, fit$lods)
			}
		}
		names(top) <- c("Genes",tnames)
	} else {
		cnames <- colnames(fit$coefficients)
 		ternary ( is.null(names(fit$genes)), xnames <- "Gene", xnames <- names(fit$genes) )	# flattened MA objects cause nameless fit$genes
 		for (i in tnames) { xnames <- gsub(" ","",c(xnames, paste(cnames, i, sep="_"))) }
 		if (aug && more) { 
			if (contrast) {
				if (weights) {
					top <- data.frame(fit$genes, fit$coef, fit$stdev.coefficients, fit$Ameans, fit$stdev.Ameans, fit$t, fit$p.value, fit$adj.p, fit$lods, fit$weights, stringsAsFactors=FALSE)
				} else {
					top <- data.frame(fit$genes, fit$coef, fit$stdev.coefficients, fit$Ameans, fit$stdev.Ameans, fit$t, fit$p.value, fit$adj.p, fit$lods, stringsAsFactors=FALSE)
				}
			} else {
				if (weights) {
					top <- data.frame(fit$genes, fit$coef, fit$stdev.coefficients, fit$t, fit$p.value, fit$adj.p, fit$lods, fit$weights, stringsAsFactors=FALSE)
				} else {
					top <- data.frame(fit$genes, fit$coef, fit$stdev.coefficients, fit$t, fit$p.value, fit$adj.p, fit$lods, stringsAsFactors=FALSE)
				}
			}
		} else {
 			top <- data.frame(fit$genes, fit$coef, fit$Ameans, fit$t, fit$p.value, fit$adj.p, fit$lods, stringsAsFactors=FALSE)
		}
		colnames(top) <- xnames
	}
	
	if (same.sign & split) {
		signs <- rowMeans(sign(fit$coef))
		up <- which(signs > 0)	# ignore any zeroes
		dn <- which(signs < 0)
		top2 <- list(UP=top, DOWN=top)
		if (as.list) {
			for (i in 1:length(top)) { 
				top2$UP[[i]] <- top[[i]][up,] 
				top2$DOWN[[i]] <- top[[i]][dn,] 
			}
		} else {
			top2$UP <- top[up,] 
			top2$DOWN <- top[dn,] 
		}
		return(top2)
	} else {
		return(top)
	}
}


apa.names$microarray <- c(apa.names$microarray, "plot.norm.QC")
plot.norm.QC <- function(raw, norm, names=NULL, special=NULL, bx.mar=7, bx.las=3, filename=NULL) {
	
	## raw, norm are expression-value matrices OF THE SAME CLASS (see below)
	## 'special' is an optional dataframe with targets$Alias, plot chars, line types, and colors in cols 1,2,3,4-5
	##   all colors in col 4 if Affy; else col 4 = red channel colors, col 5 = green channel colors
	
	if (is(raw, "RGList")) {
		if (!is.null(names)) { colnames(raw$R) <- colnames(raw$G) <- colnames(norm$R) <- colnames(norm$G) <- names }
		bp.raw <- bp.norm <- vector("list", length=ncol(raw$R)*2)
		for (i in 1:ncol(raw$R)) {
			j <- (i-1)*2+1
			bp.raw[[j]] <- log2(raw$R[,i])
			bp.raw[[(j+1)]] <- log2(raw$G[,i])
			bp.norm[[j]] <- log2(norm$R[,i])
			bp.norm[[(j+1)]] <- log2(norm$G[,i])
		}
          samplenames <- colnames(raw$R)
		if (is.null(special)) {
			cols <- rep(c(2,3), ncol(raw$R))
			ltys <- rep(1, ncol(raw$R))
		} else {
			if (ncol(special) != 5) { stop("'special' data frame must have 5 columns for 2-channel array data!\n") }
			cols <- ltys <- pchs <- c()
			for (i in 1:nrow(special)) { 
				cols <- c( cols, as.character(special[i,4]), as.character(special[i,5]) )
				ltys <- c( ltys, as.numeric(special[i,3]), as.numeric(special[i,3]) )
				pchs <- c( pchs, as.numeric(special[i,2]), as.numeric(special[i,2]) )
			}
		}
	} else if (is(raw, "AffyBatch")) {
          if (is(norm, "ExpressionSet")) {
               raw <- log2(exprs(raw))
               norm <- exprs(norm)
               if (!is.null(names)) { colnames(raw) <- colnames(norm) <- names }
               samplenames <- colnames(raw)
          } else {
               stop("If 'raw' is 'AffyBatch' then 'norm' must be 'ExpressionSet'!\n")
          }
		if (!is.null(names)) { colnames(raw) <- colnames(norm) <- names }
		bp.raw <- as.list(as.data.frame(raw))
		bp.norm <- as.list(as.data.frame(norm))
		if (is.null(special)) {
			cols <- rainbow(length(bp.raw))
			ltys <- rep(1, length(bp.raw))
			pchs <- rep(1, length(bp.raw))
		} else {
			if (ncol(special) != 4) { stop("'special' data frame must have 4 columns for Affy data!\n") }
			cols <- as.character(special[i,4])
			ltys <- as.numeric(special[,3])
			pchs <- as.numeric(special[,2])
		}
	} else {
		stop (paste("Unsupported object class '",class(raw),"' for raw object!\n",sep=""))
	}
	
	if (class(raw)[[1]] != class(norm)[[1]]) { stop("'raw' and 'norm' objects must be of same class!\n") }
     
	alldens.r <- alldens.n <- c()
	for (i in 1:length(bp.raw)) { alldens.r <- c(alldens.r, density(bp.raw[[i]], na.rm=TRUE)$y) }
	for (i in 1:length(bp.norm)) { alldens.n <- c(alldens.n, density(bp.norm[[i]], na.rm=TRUE)$y) }

	rmax <- max(alldens.r, na.rm=TRUE)
	nmax <- max(alldens.n, na.rm=TRUE) 
	
	if (!is.null(filename)) { 
		png(filename, height=1200, width=1800) 
          par(mfrow=c(2,2), mar=c(bx.mar,4,4,2), cex=1.2)
	} else {
		par(mfrow=c(2,2), mar=c(bx.mar,4,4,2))
	}

	hist(bp.raw[[1]], ylim=c(0,rmax), col=0, border=0, freq=FALSE, xlab="Log2 Intensity", main="Raw Signal Density", las=1)
	for (i in 1:length(bp.raw)) { lines(density(bp.raw[[i]], na.rm=TRUE), col=cols[i], lty=ltys[i]) }
	legend(x="topright", lty=1, col=cols, bty="n", legend=samplenames)

	hist(bp.norm[[1]], ylim=c(0,nmax), col=0, border=0, freq=FALSE, xlab="Log2 Intensity", main="Norm Signal Density", las=1)
	for (i in 1:length(bp.norm)) { lines(density(bp.norm[[i]], na.rm=TRUE), col=cols[i], lty=ltys[i]) }
	legend(x="topright", lty=1, col=cols, bty="n", legend=samplenames)

	bp.dec <- function() {	# get stuff from main function namespace
		abline(v=seq(2.5,22.5,2), col=4)
		axis(1, at=seq(1.5,length(bp.raw),2), tick=TRUE, las=bx.las, labels=samplenames)
	}

	boxplot(bp.raw, col=cols, pch=pchs, xlab="", ylab="Log2 Intensity", main="Raw Signal Boxplots", las=2)
#	bp.dec()
	boxplot(bp.norm, col=cols, pch=pchs, xlab="", ylab="Log2 Intensity", main="Norm Signal Boxplots", las=2)
#	bp.dec()

	if (!is.null(filename)) { dev.off() }
}


apa.names$microarray <- c(apa.names$microarray, "plot.ratio.QC")
plot.ratio.QC <- function(obj, type="M", names=NULL, special=NULL, groups=NULL, bx.mar=7, bx.las=3, filename=NULL) {
	
	## input is any expression-value matrix

	if (is(obj, "MAList")) {
		ternary (type == "M", mat <- obj$M, mat <- obj$A)
	} else if (is(obj, "MArrayLM")) {
		ternary (type == "M", mat <- obj$coefficients, stop("A-value comparisons not possible for class MArrayLM!\n"))
		type <- "Limma"
	} else if (is.matrix(obj) & mode(obj) == "numeric") {
		mat <- obj
	} else {
		stop("Object must be a numeric matrix, or of classes MAList or MArrayLM!\n")
	}
	
	if (!is.null(names)) { colnames(mat) <- names }
	if (is.null(groups)) { groups <- list(c(1:ncol(mat))) }
	irows <- length(groups)
	
	if (!is.null(filename)) { 
		png(filename, height=irows*600, width=1200) 
		par(mfrow=c(irows,2), mar=c(bx.mar,4,4,2), cex=1.2)
	} else {
		par(mfrow=c(irows,2), mar=c(bx.mar,4,4,2))
	}
	
	for (i in 1:length(groups)) {
		x <- groups[[i]]
		cols <- rainbow(length(x))
		alldens <- c()
		for (j in 1:length(x)) { alldens <- c(alldens, density(mat[,x[j]], na.rm=TRUE)$y) }
		ymax <- max(alldens)

		hist(mat[,x[1]], ylim=c(0,ymax), col=0, border=0, freq=FALSE, xlab=paste(type,"Values"), main="Signal Ratio Density")
		for (j in 1:length(x)) { lines(density(mat[,x[j]], na.rm=TRUE), col=cols[j]) }
#		legend(x="topright", lty=1, col=cols, bty="n", legend=c())

		boxplot(mat[,x], col=cols, las=bx.las, xlab="", ylab=paste(type,"Values"), main="Signal Ratio Boxplots")
	}
	
	if (!is.null(filename)) { dev.off() }
}


apa.names$microarray <- c(apa.names$microarray, "Affy.QC.plots")
Affy.QC.plots <- function(ab.raw, ab.norm, fit=NULL, cfit=NULL, names=NULL, compares=NULL, smooth=FALSE, ...) {
	
	# norm densities/boxplots, ratio densities/boxplots, corr mat, MA plots
	# If 'compares' specified, make sure that it is correct per the col structure of your input object
	
	raw <- exprs(ab.raw)
	norm <- exprs(ab.norm)
	if (!is.null(names)) { colnames(norm) <- colnames(raw) <- names }
	
	if (require("affyQCReport")) {
		QCReport(ab.norm, filename="Affy_QCReport.pdf")
		affyQAReport(ab.norm, output="pdf", outdir=file.path(getwd(),"affyQA"), overwrite=TRUE, repname=Sys.Date())
	} else {
		cat("affyQCReport did not load (is it installed?), so these reports will be unavailable\n"); flush.console()
	}

	corr.mat(norm, plot=TRUE, filename="Norm_Corrs.png")
	plot.norm.QC (raw, norm, filename="Norm_Effect.png")	
#	MA.plot(obj, smooth=FALSE, fc.lines=NULL, foldcolor=FALSE, monoscale=FALSE, names=NULL, controls=NULL, filename=NULL)

	if (!is.null(fit)) {
		corr.mat(fit$coef, plot=TRUE, filename="Coef_Corrs.png")
		plot.ratio.QC(fit$coef, filename="Coef_Signal.png")	
	}
	if (!is.null(cfit)) {
		plot.ratio.QC(cfit$coef, filename="Ratio_Signal.png")	
	}
	if (!is.null(compares)) {
		plot.ratio.QC(norm, names, compares, filename=)
		plot.sample.scatter(norm, compares, smooth=smooth, filename=)
#		scatter.plot <- function(obj, type="M", smooth=FALSE, fc.lines=c(-2:2), foldcolor=FALSE, monoscale=FALSE, compares=NULL, names=NULL, controls=NULL, filename=NULL)
	}
}


apa.names$microarray <- c(apa.names$microarray, "Agilent.QC.plots")
Agilent.QC.plots <- function(RG, MA, array=NULL, slides=NULL, names=NULL, compares=NULL, smooth=FALSE, ...) {
	
	# norm densities/boxplots, ratio densities/boxplots, corr mat, MA plots 

	if (!require(limma)) { cat("Cannot load limma: control-scatter and 2-slide QC plots will be unavailable!\n"); flush.console() }
	if (!is.null(names)) { colnames(RG) <- colnames(MA) <- names }
	RG2 <- RG.MA(MA)
	
	corr.mat(MA$M, plot=TRUE, filename="Norm_Corrs.png")
	plot.norm.QC(RG, RG2, filename="Norm_Effect.png")	
#	MA.plot(obj, smooth=FALSE, fc.lines=NULL, foldcolor=FALSE, monoscale=FALSE, names=NULL, controls=NULL, filename=NULL)

	if (!is.null(compares)) {
		plot.ratio.QC(MA, names, compares, filename=)
		plot.sample.scatter(MA, compares, smooth=smooth, filename=)
#		scatter.plot <- function(obj, type="M", smooth=FALSE, fc.lines=c(-2:2), foldcolor=FALSE, monoscale=FALSE, compares=NULL, names=NULL, controls=NULL, filename=NULL)
	}

#	Agilent.control.scatters <- function(MA, names, array, ...) 
	
	# inter- and intra- array scatter

	RG <- RG.MA(MA)
	
#	Agilent.2slide.QC <- function(MA, names, array, ...) 
	
	# inter- and intra- array scatter

	RG <- RG.MA(MA)
	
}


apa.names$microarray <- c(apa.names$microarray, "Inhouse.QC.plots")
Inhouse.QC.plots <- function(RG, MA, names, array, ...) {
	
}


apa.names$microarray <- c(apa.names$microarray, "Agilent.wigify")
Agilent.wigify <- function(obj, des.no, smooth=NULL, flat=TRUE, max.aligns=1, remap=NULL, chr.conv=NULL, wig.mat=FALSE) {
	
	## mat is any expression-ratio matrix
	## des.no is the design number of the Agilent array
	## "flat=T" resolves probe overlaps
	
	if (is(obj, "MAList")) {
		values <- obj$M
		precoords <- obj$genes$SystematicName
	} else if (is(obj, "MArrayLM")) {
		values <- obj$coefficients
		precoords <- obj$genes$SystematicName
	} else if (is.matrix(obj) & is.numeric(obj) & !is.null(rownames(obj))) {
		values <- obj
		precoords <- rownames(obj)
	}
	
	## get controls
	ctldata <- parse.controls(idents, arrayID)	# objects: { defLine nonCtl }, maybe { ctlAtt ctlSets }, maybe also { spikeAtt spikeSets spikeLines }
	nonCtl <- ctldata$nonCtl
	
	## parse coords
	if (remap) {
		
		
		## Identify over-aligned probes (since Agilent arrays already come with coordinates, multiple-aligning probes can only be detected by realignment)
		if (is.na(max.aligns)) {
			ok <- nonCtl
		} else {
			ok <- nonCtl[x]
		}
		coords <- ""
	} else {
		coords <- t(sapply(strsplit(precoords[ok], "[:-]"), simplify=TRUE, FUN=function(x){x}))	# 3-col df: chr, start, end
	}
	N <- nrow(coords)
	
	## apply values
	mwig <- data.frame(CHR=coords[,1], START=coords[,2], END=coords[,3], VALUE=values)	# factorize CHR to lower memory
	if (length(unique(mwig$start)) < N) {	# redundant coords
		
		############### will this method work ????
		
		temp <- aggregate(mwig, by=list(mwig[,1], mwig[,2], mwig[,3]), mean)
		mwig <- as.data.frame(temp[,c(1:3,7)])
	}
	
	## resolve overlaps
	if (flat) {
		overlapped <- which(apply(cbind(mwig[1:(N-1),2], mwig[2:N,1]), 1, FUN=function(x){x[2]-x[1]}) < 0)	# probes whose ends overlap their 3' neighbors' starts
		
	}
	
	## smooth
	if (!is.null(smooth)) {
		flank <- ceiling(smooth/2)
		smoothed <- matrix()
	}
	
	if (wig.mat) {
		return(mwig)	# wig matrix
	} else {
		header <- paste("track name=", colnames(mwig), ", description=\"", colnames(mwig), "\", visibility=full, graphType=bar, autoscale=on", sep="")
		tracklist <- vector("list", length=ncol(mwig))
		for (i in 1:ncol(mwig)) { tracklist[[i]] <- c(header[i], paste(rownames(mwig), mwig[,i], sep="\t")) }
		return(tracklist)	# list containing complete, headered wig files
	}
}


apa.names$microarray <- c(apa.names$microarray, "Affy.wigify")
Affy.wigify <- function(mat, bpmap, smooth=1, flat=TRUE, max.aligns=1, remap=NULL, mapfile=NULL, chr.conv=NULL, wig.mat=FALSE) {
	
	## RECOMMENDED TO RUN THIS SERVERSIDE DUE TO HIGH MEM, RUNTIME
# ?	## 'mat' is any expression-ratio matrix
	## 'bpmap=file' points to the appropriate bpmap file
	## 'smooth=N' applies an N-bp smoothing window to output
	## 'flat=T' merges regions of probe overlap into new probes with averaged values
	## 'max.aligns' specifies how many different genomic alignments a probe may have before being dropped.  Value of NA removes the limit.
	## 'remap=genomefastapath' remaps probes using Starr
	## - OR - use 'mapfile=file' to specify an existing Starr remapping file for this array/genome combo
	## 'chr.conv=pairlist' applies old chr name => new chr name conversion
	## 'wig.mat=T' returns a wig matrix, not a list of wigs
	
	if (!require("Starr")) { stop("Cannot load Starr library: unable to continue!\n") }
	
	data <- cbind(data.frame(chr=, start=, end=), as.data.frame(MA$M))
	
	if (wig.mat) {
		return(mwig)	# wig matrix
	} else {
		header <- paste("track name=", colnames(mwig), ", description=\"", colnames(mwig), "\", visibility=full, graphType=bar, autoscale=on", sep="")
		tracklist <- vector("list", length=ncol(mwig))
		for (i in 1:ncol(mwig)) { tracklist[[i]] <- c(header[i], paste(rownames(mwig), mwig[,i], sep="\t")) }
		return(tracklist)	# list containing complete, headered wig files
	}
}
