

apa.names$bio.seq <- c(apa.names$bio.seq, "read.vcf")
read.vcf <- function(file) {
    ## reads a VCF file into a data.frame, with the entire header as an attribute.
    hfile <- tempfile()
    if (grepl("\\.gz$",file)) {
        x <- read.delim(gzfile(file), header=FALSE, as.is=TRUE, comment.char="#")
        system(paste("zcat",file,"| grep \"^#\" >",hfile))
    } else {
        x <- read.delim(file, header=FALSE, as.is=TRUE, comment.char="#")
        system(paste("cat",file,"| grep \"^#\" >",hfile))
    }
    message("FS: ",file.size(hfile))
    if (file.size(hfile)>0) {
        header <- scan(hfile, what="", sep="\n")
        attributes(x)$header <- header
        cn <- header[length(header)]
        colnames(x) <- unlist(strsplit(sub("^#","",cn),"\t"))
    } else {
        attributes(x)$header <- character(0)
        cn <- c("#CHROM","POS","ID","REF","ALT","QUAL","FILTER","INFO")
        if (ncol(x)>=8) {
            colnames(x)[1:8] <- cn
            if (ncol(x)>8) colnames(x)[9:ncol(x)] <- paste0("COLUMN",9:ncol(x))
        } else {
            colnames(x) <- cn[1:ncol(x)]
        }
    }
    x
}


apa.names$bio.seq <- c(apa.names$bio.seq, "write.vcf")
write.vcf <- function(x, filename, header=NULL, tabix=FALSE) {
    ## the reverse function for read.vcf()
    ## generates empty header if no header attribute exists
    gzip <- ifelse(grepl("\\.gz$",filename) | tabix, TRUE, FALSE)
    if (gzip) filename <- sub("\\.gz$","",filename)	
    if (length(header)!=0) attributes(x)$header <- header
    if (length(attributes(x)$header)==0) attributes(x)$header <- "##fileformat=VCFv4.1"  # have to have something, anyway
    con <- file(description=filename, open="w")
    writeLines(attributes(x)$header, con, sep="\n")
    write.table(x, con, sep="\t", quote=FALSE, row.names=FALSE, col.names=FALSE)
    close(con)
    if (gzip) system(paste("bgzip -f",filename))
    if (tabix) system(paste0("tabix -f ",filename,".gz"))
}


apa.names$bio.seq <- c(apa.names$bio.seq, "split.vcf.info")
split.vcf.info <- function(vcf) {
    ## tabularizes the info column from a VCF file
    ## output rows = input rows; output columns = unique keys observed across all rows.
    nr <- nrow(vcf)
    pre <- lapply(vcf$INFO, function(x){ lapply(unlist(strsplit(x,";")), function(y){unlist(strsplit(y,"="))}) })
    nam <- unique(unlist(lapply(pre, function(x){ lapply(x, function(y){y[[1]]}) })))
    if ("I16" %in% nam) {
        nam <- sort(setdiff(nam, "I16"))
        i16 <- t(sapply(pre, function(x){i<-which(slice.list(x,1)=="I16");unlist(strsplit(x[[i]][[2]],","))}))
        mode(i16) <- "numeric"
        colnames(i16) <- paste("I",1:16,sep="")
    } else {
        i16 <- NULL
    }
    dat <- matrix(NA, nrow=nr, length(nam), F, list(c(),nam))
    for (i in 1:nr) {
        x <- unlist(slice.list(pre[[i]],1))
        ok <- which(x!="I16")
        y <- unlist(slice.list(pre[[i]],2))[ok]
        y[is.na(y)] <- 1
        dat[i,match(x[ok],nam)] <- y
    }
    w.indel <- match("INDEL",colnames(dat))
    if (length(w.indel)>0) dat[is.na(dat[,w.indel]),w.indel] <- 0
    mode(dat) <- "numeric"
    data.frame(dat,i16,stringsAsFactors=FALSE)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "split.vcf.geno")
split.vcf.geno <- function(vcf) {
    
    ## This may be redundant -- check GATK pipeline codebase
    ## Tabularizes the VCF genotype column into a data.frame (typically 5 columns, GT GQ DP AD PL etc)
    
    dat <- rownameless(as.data.frame(do.call(rbind, strsplit(vcf[,10],"[:,/]")),stringsAsFactors=FALSE))
    samp <- dat[1,]
    suppressWarnings( samp.n <- as.numeric(samp) )  # get NA if not numeric-convertable
    for (i in 1:ncol(dat)) if (!is.na(samp.n[i])) dat[,i] <- as.numeric(dat[,i])
    
    types <- unlist(strsplit(vcf[1,9],":"))
    
    amp.x <- list(GT=2,AD=2,PL=3)
    AMPLIFY <- function(x,label) {
        LX <- length(x)
        LAB <- which(x == label)
        LL <- length(LAB)
        N <- amp.x[[label]]
        if (LL > 0) {
            if (LAB == 1) {
                x <- x[c(rep(1,N),2:LX)]
            } else if (LAB == LX) {
                x <- x[c(1:(LX-1),rep(LX,N))]
            } else {
                x <- x[c(1:(LAB-1),rep(LAB,N),(LAB+1):LX)]
            }
            LAB2 <- which(x == label)
            LL2 <- length(LAB2)
            x[LAB2] <- paste(label,1:LL2,sep=".")
        }
        x
    }
    
    for (i in 1:length(amp.x)) types <- AMPLIFY(types,names(amp.x)[i])
    ##IM(types)
    colnames(dat) <- types
    dat
}


apa.names$bio.seq <- c(apa.names$bio.seq, "vcf.geno.dist")
vcf.geno.dist <- function(x, adjust.zero=TRUE) {
    
    ## Takes a 2-column matrix/df of VCF genotype frequency strings (e.g. "18,1", "2,5")
    ##   and returns a vector of genotype distance scores.
    ## Strings can be passed in as 'x' and 'y', or 'x' can hold both.
    ## Strings are converted to numeric vectors before distance is measured:
    ##  - Result vectors of length 0 or 1 are converted to NA (from "./." genotypes).
    ##  - if "adjust.zero=T", 0 values are converted to 0.5, which keeps low-depth scores conservative. 
    ##  - values are converted to percents, so that "4,8" and "40,80" are considered equal.

    x <- as.matrix(x)
    y <- suppressWarnings(sapply(x[,1], function(v) as.numeric(unlist(strsplit(v,",")))))
    z <- suppressWarnings(sapply(x[,2], function(v) as.numeric(unlist(strsplit(v,",")))))
    for (i in which(listLengths(y)<2)) y[[i]] <- rep(NA,length(z[[i]]))
    for (i in which(listLengths(z)<2)) z[[i]] <- rep(NA,length(y[[i]]))
    if (adjust.zero) {
        for (i in 1:length(y)) y[[i]][y[[i]]==0] <- 0.5
        for (i in 1:length(z)) z[[i]][z[[i]]==0] <- 0.5
    }
    y <- lapply(y, function(v) 100*v/sum(v))
    z <- lapply(z, function(v) 100*v/sum(v))
    d <- sapply(1:nrow(x), function(i) c(dist(rbind(y[[i]],z[[i]]))) )
    df <- data.frame(
        sapply(y, function(v) paste(round(v,0),collapse=",") ),
        sapply(z, function(v) paste(round(v,0),collapse=",") ),
        d
    )
    colnames(df) <- c(paste0(colnames(x),"N"),"DIST")
    df
}


apa.names$dev <- c(apa.names$dev, "GATK.hh.analyze")
GATK.hh.analyze <- function(x, major, minor, groups=NULL) {
    
    ## UNDER CONSTRUCTION
    
    ## Analyze trends in GATK AD, DP and GT fields
    ## 
    ## 'x' is a list of 1 or more matrices which have been extracted from a single VCF file:
    ##   Each matrix must have columns GT,DP,AD for one sample, in that order.
    ##   If 'x' has > 1 matrix, these must all be single-sample matrices from one multisample VCF, because they will be compared to each other.
    
    ## txt.raw[[i]] cols: 7,8 GT "0/1"; 9,10 DP "5"; 11,12 AD "10,5"
    
    rescore <- function(i, j, gt, dp, ad) {
        gt <- GT[[i]][[j]]
        dp <- DP[[i]][j]
        ad <- AD[[i]][[j]]
        lgt <- length(gt)
        lad <- length(ad)
        if (lad>1) {
            sad <- sum(ad)
            alost <- max(gt)-lad  # >0 means depths not reported for all alleles
            dlost <- dp-sum(ad)  # >0 means depths not reported for all alleles
            if (alost > 0 | dlost > 0) {
                message(paste("Lost depths for",i,j))
            } else {
                ap <- ad/dp  # depth percent per allele
                lfc <- ad[1]/sum(ad[2:lad])
                if (blah) {
                    
                } else {
                    
                }
            }
        }
    }
    
    if (is.data.frame(x) | !is.list(x)) x <- list(x)
    
    X <- length(x)
    NR <- sapply(x,nrow)
    GT <- lapply(x, function(y) lapply(strsplit("/",y[,1]), as.numeric) )
    DP <- lapply(x, function(y) as.numeric(y[,2]) )
    AD <- lapply(x, function(y) lapply(strsplit(",",y[,3]), as.numeric) )
    
    stats <- lapply(1:X, function(i) do.call(rbind, lapply(1:NR, function(j) rescore(i, j) )))
    
    
    
    
    
    
    
    ## further filters, like requiring sib geno call, min sib het ratio, depth, etc.
    bad1[[i]][which(txt.raw[[i]][,11]==txt.raw[[i]][,12])] <- TRUE   # exact same genotype call
    txt.flt1[[i]] <- txt.raw[[i]][txt.raw[[i]][,11]!=txt.raw[[i]][,12],]  # different genotype calls
    txt.flt1[[i]] <- txt.flt1[[i]][falsify(txt.flt1[[i]][,9]>=2) & falsify(txt.flt1[[i]][,10]>=2),]  # both depths > 2
    txt.flt1[[i]] <- txt.flt1[[i]][txt.flt1[[i]][,7] != "./." & txt.flt1[[i]][,8] != "./.",]  # both genotypes not "./."
    bad2[[i]] <- rep(FALSE,nrow(txt.flt1[[i]]))  # initialize bi/tri test-pass vector
    biallelic <- which(!grepl(2,txt.flt1[[i]][,7]) & !grepl(2,txt.flt1[[i]][,8]))  # 2 alleles called
    triallelic <- which(grepl(2,txt.flt1[[i]][,7]) | grepl(2,txt.flt1[[i]][,8]))  # > 2 alleles called (so 3; never observed 4...)
    
    sib.max2 <- nameless(sapply(txt.flt1[[i]][biallelic,11], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
    mut.max2 <- nameless(sapply(txt.flt1[[i]][biallelic,12], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
    sib.max3 <- nameless(sapply(txt.flt1[[i]][triallelic,11], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
    mut.max3 <- nameless(sapply(txt.flt1[[i]][triallelic,12], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
#    cbind(sib.max2,mut.max2,sib.max2==mut.max2)
#    cbind(sib.max3,mut.max3,sib.max3==mut.max3)
    
    ## Allele frequency filter, mutant   ## NOTE: GATK fails to call HET/HOM properly.  E.g. 2,2 is not HOM, neither is 10,1 HET.
    AB <- t(apply(txt.flt1[[i]][biallelic,11:12], 1, function(s)
                   c( sort(as.numeric(unlist(strsplit(s[1],",")))), sort(as.numeric(unlist(strsplit(s[2],","))))) ))
    biallelic.ok <- sib.max2!=mut.max2 & AB[,1]/rowSums(AB[,1:2])<=0.4 & AB[,3]/rowSums(AB[,3:4])<=0.1  # sib: minor <= 40%; mut: minor <= 10%
    triallelic.ok <- NA
    if (length(triallelic)>0) {
        ABC <- t(apply(txt.flt1[[i]][triallelic,11:12], 1, function(s)
                       c( sort(as.numeric(unlist(strsplit(s[1],",")))), sort(as.numeric(unlist(strsplit(s[2],","))))) ))
        triallelic.ok <- sib.max3!=mut.max3 & ABC[,2]/rowSums(ABC[,1:3])<=0.4 & ABC[,5]/rowSums(ABC[,4:6])<=0.1  # as above, but minor is second-largest, not smallest
    }
    
#    ## genotype-distinctiveness field
#    txt[[i]] <- txt[[i]][,c(1:12,9,9,9,13:14)]
#    colnames(txt[[i]])[13:15] <- c("GEN[1].AD","GEN[0].AD","GEN.DIST")
#    txt[[i]][,13:14] <- sapply(11:12, function(j) {
#        x <- t(sapply(txt[[i]][,j], function(s) as.numeric(unlist(strsplit(s,","))) ))
#        y <- rowMax(x)/txt[[i]][,j-2]
#        z <- y*sign(log(apply(x,1,quot)))
#    })
#    txt[[i]][,15] <- round(100*abs(txt[[i]][,13]-txt[[i]][,14])/2,1)

    bad2[[i]][biallelic[which(!biallelic.ok)]] <- TRUE
    bad2[[i]][triallelic[which(!triallelic.ok)]] <- TRUE
    
    allele.diff <- sort(c( biallelic[biallelic.ok], triallelic[triallelic.ok] ))
    txt.flt2[[i]] <- txt.flt1[[i]][allele.diff,]

    
#    txt.flt2[[i]][,7] <- sub("0/0","HOM",sub("1/1","HOM",sub("2/2","HOM",sub("1/2","HET",sub("0/1","HET",txt.flt2[[i]][,7])))))
#    txt.flt2[[i]][,8] <- sub("0/0","HOM",sub("1/1","HOM",sub("2/2","HOM",sub("1/2","HET",sub("0/1","HET",txt.flt2[[i]][,8])))))
    
    
}


apa.names$dev <- c(apa.names$dev, "GATK.hh.recall")
GATK.hh.recall <- function(x, major, minor, groups=NULL) {
    
    ## UNDER CONSTRUCTION
    
    ## Combines GATK AD and DP fields and compares to GT field; reclassifies HET/HOM.
    ## 
    ## 'x' is a list of 1 or more matrices which have been extracted from a single VCF file:
    ##   Each matrix must have columns GT,DP,AD for one sample, in that order.
    ##   If 'x' has > 1 matrix, these must all be single-sample matrices from one multisample VCF, because they will be compared to each other.
    ## 'groups' is an optional grouping vector if length(x)>1.  These indicate which matrices in 'x' should be grouped for comparisons (e.g. which are MUT vs WT).
    ##   Same principle as 'group' factor in EdgeR.  Example: length(x) = 6; groups = c("MUT","MUT","MUT","WT","WT","WT").
    ##   All pairwise tests between factor levels will be carried out, so plan function call accordingly!
    ##   Consistency tests are also carried out within each factor level.
    ## Returns HET/HOM calls, GATK-call-was T/F value, genotype distinctiveness scores
    
    ## txt.raw[[i]] cols: 7,8 GT "0/1"; 9,10 DP "5"; 11,12 AD "10,5"
    
    rescore <- function(i, j, gt, dp, ad) {
        gt <- GT[[i]][[j]]
        dp <- DP[[i]][j]
        ad <- AD[[i]][[j]]
        lgt <- length(gt)
        lad <- length(ad)
        if (lad>1) {
            sad <- sum(ad)
            alost <- max(gt)-lad  # >0 means depths not reported for all alleles
            dlost <- dp-sum(ad)  # >0 means depths not reported for all alleles
            if (alost > 0 | dlost > 0) {
                message(paste("Lost depths for",i,j))
            } else {
                ap <- ad/dp  # depth percent per allele
                lfc <- ad[1]/sum(ad[2:lad])
                if (blah) {
                    
                } else {
                    
                }
            }
        }
    }
    
    if (is.data.frame(x) | !is.list(x)) x <- list(x)
    
    X <- length(x)
    NR <- sapply(x,nrow)
    GT <- lapply(x, function(y) lapply(strsplit("/",y[,1]), as.numeric) )
    DP <- lapply(x, function(y) as.numeric(y[,2]) )
    AD <- lapply(x, function(y) lapply(strsplit(",",y[,3]), as.numeric) )
    
    stats <- lapply(1:X, function(i) do.call(rbind, lapply(1:NR, function(j) rescore(i, j) )))
    
    
    
    
    
    
    
    ## further filters, like requiring sib geno call, min sib het ratio, depth, etc.
    bad1[[i]][which(txt.raw[[i]][,11]==txt.raw[[i]][,12])] <- TRUE   # exact same genotype call
    txt.flt1[[i]] <- txt.raw[[i]][txt.raw[[i]][,11]!=txt.raw[[i]][,12],]  # different genotype calls
    txt.flt1[[i]] <- txt.flt1[[i]][falsify(txt.flt1[[i]][,9]>=2) & falsify(txt.flt1[[i]][,10]>=2),]  # both depths > 2
    txt.flt1[[i]] <- txt.flt1[[i]][txt.flt1[[i]][,7] != "./." & txt.flt1[[i]][,8] != "./.",]  # both genotypes not "./."
    bad2[[i]] <- rep(FALSE,nrow(txt.flt1[[i]]))  # initialize bi/tri test-pass vector
    biallelic <- which(!grepl(2,txt.flt1[[i]][,7]) & !grepl(2,txt.flt1[[i]][,8]))  # 2 alleles called
    triallelic <- which(grepl(2,txt.flt1[[i]][,7]) | grepl(2,txt.flt1[[i]][,8]))  # > 2 alleles called (so 3; never observed 4...)
    
    sib.max2 <- nameless(sapply(txt.flt1[[i]][biallelic,11], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
    mut.max2 <- nameless(sapply(txt.flt1[[i]][biallelic,12], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
    sib.max3 <- nameless(sapply(txt.flt1[[i]][triallelic,11], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
    mut.max3 <- nameless(sapply(txt.flt1[[i]][triallelic,12], function(s) which.max(as.numeric(unlist(strsplit(s,",")))) ))
#    cbind(sib.max2,mut.max2,sib.max2==mut.max2)
#    cbind(sib.max3,mut.max3,sib.max3==mut.max3)
    
    ## Allele frequency filter, mutant   ## NOTE: GATK fails to call HET/HOM properly.  E.g. 2,2 is not HOM, neither is 10,1 HET.
    AB <- t(apply(txt.flt1[[i]][biallelic,11:12], 1, function(s)
                   c( sort(as.numeric(unlist(strsplit(s[1],",")))), sort(as.numeric(unlist(strsplit(s[2],","))))) ))
    biallelic.ok <- sib.max2!=mut.max2 & AB[,1]/rowSums(AB[,1:2])<=0.4 & AB[,3]/rowSums(AB[,3:4])<=0.1  # sib: minor <= 40%; mut: minor <= 10%
    triallelic.ok <- NA
    if (length(triallelic)>0) {
        ABC <- t(apply(txt.flt1[[i]][triallelic,11:12], 1, function(s)
                       c( sort(as.numeric(unlist(strsplit(s[1],",")))), sort(as.numeric(unlist(strsplit(s[2],","))))) ))
        triallelic.ok <- sib.max3!=mut.max3 & ABC[,2]/rowSums(ABC[,1:3])<=0.4 & ABC[,5]/rowSums(ABC[,4:6])<=0.1  # as above, but minor is second-largest, not smallest
    }
    
#    ## genotype-distinctiveness field
#    txt[[i]] <- txt[[i]][,c(1:12,9,9,9,13:14)]
#    colnames(txt[[i]])[13:15] <- c("GEN[1].AD","GEN[0].AD","GEN.DIST")
#    txt[[i]][,13:14] <- sapply(11:12, function(j) {
#        x <- t(sapply(txt[[i]][,j], function(s) as.numeric(unlist(strsplit(s,","))) ))
#        y <- rowMax(x)/txt[[i]][,j-2]
#        z <- y*sign(log(apply(x,1,quot)))
#    })
#    txt[[i]][,15] <- round(100*abs(txt[[i]][,13]-txt[[i]][,14])/2,1)

    bad2[[i]][biallelic[which(!biallelic.ok)]] <- TRUE
    bad2[[i]][triallelic[which(!triallelic.ok)]] <- TRUE
    
    allele.diff <- sort(c( biallelic[biallelic.ok], triallelic[triallelic.ok] ))
    txt.flt2[[i]] <- txt.flt1[[i]][allele.diff,]

    
#    txt.flt2[[i]][,7] <- sub("0/0","HOM",sub("1/1","HOM",sub("2/2","HOM",sub("1/2","HET",sub("0/1","HET",txt.flt2[[i]][,7])))))
#    txt.flt2[[i]][,8] <- sub("0/0","HOM",sub("1/1","HOM",sub("2/2","HOM",sub("1/2","HET",sub("0/1","HET",txt.flt2[[i]][,8])))))
    
    
}


