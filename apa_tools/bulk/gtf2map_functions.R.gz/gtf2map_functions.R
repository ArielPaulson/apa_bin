

apa.names$bio.seq <- c(apa.names$bio.seq, "gtf2map")
gtf2map <- function(gtf.idx, remap.samheader, remap.samPG=NULL, funcRNA=NULL, outprefix=NULL) {
    
    ## 'gtf.idx' is preferably a Tophat GTF index directory, but a single GTF file should also work.
    ## DO NOT give the GTF file if a Tophat index has been made; the map will NOT work for bams aligned to the index.
    ## Converts a GTF file into a exon-level transcript->genome mapping file
    ## Writes two versions, "outprefix.txt" and "outprefix.RData"
    
    ## FUTURE: This will become the transcriptome-build exondata.txt; add peptide coords, phase, Ensembl Gene/Exon ID

    is.funcRNA <- length(funcRNA)>0
    func.pref <- paste0("/n/projects/apa/stuff/bowtie_building/builds/",funcRNA[1],"/",funcRNA[2],"/funcRNA/",funcRNA[1],".",funcRNA[2],".funcRNA.")
    if (grepl("\\.index$",gtf.idx)) {
        if (is.funcRNA & length(outprefix)==0) stop("Will not auto-create output prefix if mixing Tophat indexes with funcRNA builds!  Please specify 'outprefix'\n")
        is.index <- TRUE
        gtf.file <- sub(".index$","",gtf.idx)
        tlst.file <- system(paste0("ls ",gtf.idx,"/*.tlst | head -1"), intern=TRUE)
        message("Parsing index transcript list...")
        tlst <- read.delim(tlst.file, sep=" ", as.is=TRUE, header=FALSE)
        if (is.null(outprefix)) outprefix <- sub("\\.fa\\.tlst$",".gtf2map.",tlst.file)
    } else {
        is.index <- FALSE
        gtf.file <- gtf.idx
        if (is.null(outprefix)) outprefix <- ifelse(is.funcRNA, paste0(func.pref,"gtf2map."), paste0(gtf.file,".gtf2map."))
    }
    if (!grepl("\\.$",outprefix)) outprefix <- paste0(outprefix,".")
    message(paste0("Outprefix:",outprefix))
    message("Parsing remap header...")
    rmsh <- system(paste("samtools view -H",remap.samheader), intern=TRUE)
    rmsh[1] <- sub("SO:.*","SO:unsorted",rmsh[1])  # just in case it wasn't already -- remapped output will generally lose its sort order, so new header must agree
    if (length(remap.samPG)>0) remap.samPG <- paste0("@PG\tID:gtf2map\tVN:1.0\tCL:\"",remap.samPG,"\"")  # convert remap.samPG to sam-header PG line format
    message("Parsing GTF...")
    gtf <- read.delim(gtf.file, comment="#", header=FALSE, as.is=TRUE)
    gtf <- gtf[c(which(gtf[,3]=="exon"),which(gtf[,3]=="CDS")),]  # ORDER THIS WAY FIRST -- CRUCIAL FOR CDS->EXON PLACEMENT STRATEGY LATER
    gtf <- gtf[gtf[,3] %in% c("exon","CDS"),]
    gene <- sub(";.*$","",sub("^.*gene_id ","",gtf[,9]))
    trans <- sub(";.*$","",sub("^.*transcript_id ","",gtf[,9]))
    exon <- as.numeric(sub(";.*$","",sub("^.*exon_number ","",gtf[,9])))
    gtf <- cbind(gtf[,c(1,4:5,4:5,4:5,4:5,4:5)], exon, gtf[,7], gene, gtf[,3], trans)
    colnames(gtf) <- c("chr","tstart","tend","gstart","gend","cstart","cend","tcstart","tcend","gcstart","gcend","exon","strand","gene","feat","trans")
    if (is.funcRNA) {
        ## funcRNA=c(geno,anno)
        gdat <- read.delim(paste0(func.pref,"genedata.txt"), as.is=TRUE)
        gdat <- gdat[,c("Fasta.Header","Trans.ID")]
        trans.list <- unique(gdat[,2])
        message("Parsing transcript restriction list...")  # expecting vector
        m.trans <- trans.list %in% gtf$trans
        if (!all(m.trans)) stop(paste0("Only ",sum(m.trans),"/",length(trans.list)," transcript IDs were matched in this GTF!  List appears mismatched; will not proceed\n"))
        w.trans <- gtf$trans %in% trans.list
        message(paste0("Retaining ",luniq(gtf$trans[w.trans]),"/",length(trans.list)," transcripts\n"))
        gtf <- gtf[w.trans,]
    }
    gtf <- gtf[order(gtf$trans,gtf$gstart),]
    gtf2 <- gtf[gtf$feat=="exon",]
    utrans <- sort(unique(gtf$trans))
    U <- length(utrans)
    
    message("Calculating transcript mappings...")
    st <- system.time ({
        for (u in 1:U) {
            report.index(u,100,U)
            ut <- utrans[u]
            x <- gtf[gtf$trans==ut,]
            nx <- sum(x$feat=="exon")
            CDS <- any(x$feat=="CDS")
            neg <- x$strand[1]=="-"
            if (CDS) {
                wc <- which(x$feat=="CDS")
                x[wc-1,6:11] <- x[wc,6:11]
                x[setdiff(1:nrow(x),c(wc,wc-1)),6:11] <- NA
                x <- x[x$feat=="exon",]
            } else {
                x[,6:11] <- NA
            }
            if (neg) {
                x <- x[nx:1,]
                if (any(is.na(x$exon))) x$exon <- nx:1
                x[,4:5] <- x[,5:4]
                x[,10:11] <- x[,11:10]
                if (CDS) {
                    cds1 <- which(!is.na(x[,10]))[1]
                    co <- x[cds1,4]-x[cds1,10]
                    if (cds1>1) co <- co+sum(x[1:(cds1-1),3]-x[1:(cds1-1),2]+1)
                }
            } else {
                if (any(is.na(x$exon))) x$exon <- 1:nx
                if (CDS) {
                    cds1 <- which(!is.na(x[,10]))[1]
                    co <- x[cds1,10]-x[cds1,4]
                    if (cds1>1) co <- co+sum(x[1:(cds1-1),3]-x[1:(cds1-1),2]+1)
                }
            }
            xl <- x[,3]-x[,2]+1
            x[,2:3] <- cbind(cumsum(xl)-xl+1,cumsum(xl))
            if (CDS) {
                cl <- x[cds1:nx,9]-x[cds1:nx,8]+1
                x[cds1:nx,8:9] <- cbind(cumsum(cl)-cl+1,cumsum(cl))+co
                x[,6:7] <- x[,8:9]-min(x[cds1,8])+1
            }
            gtf2[gtf2$trans==ut,] <- x
        }
    })
    print(st)
    
    message("Preparing txt form...")
    gtfx <- gtf2[,c(16,16,1,13,2:11)]
    for (i in 1:ncol(gtfx)) {
        gtfx[[i]][is.na(gtfx[[i]])] <- ""
        mode(gtfx[[i]]) <- "character"
        if (i>4) gtfx[[i]] <- gsub(" ","",format(gtfx[[i]]))
    }
    if (is.index) {
        gtfx[,1] <- tlst[match(gtfx[,2],tlst[,2]),1]  # transcript IDs -> numbers
        mode(gtfx[,1]) <- "numeric"
    } else if (is.funcRNA) {
        gtfx[,1] <- gdat[match(gtfx[,2],gdat[,2]),1]  # transcript IDs -> fasta headers
    }
    
    message("Preparing RData form...")
    st <- system.time({
        map <- mat.split(gtf2,gtf2$trans) 
        for (u in 1:U) {
            x <- map[[u]]
            x <- list(chr=x$chr[1], strand=x$strand[1], transcript=utrans[u], gene=x$gene[1], exon=x[,2:5], cds=x[,6:11])
            rownames(x$exon) <- rownames(x$cds) <- map[[u]]$exon
            colnames(x$cds) <- sub("c","",colnames(x$cds))
            ## RDATA OBJECT USES 0-BASED COORDS
            x$exon[,1] <- x$exon[,1]-1
            for (i in c(1,3)) x$cds[,i] <- x$cds[,i]-1
            ## OBJECTS ON (-) STRAND MUST HAVE GENOMIC END-COORD CORRECTED, NOT GENOMIC START-COORD, SINCE GENOMIC COORDS RUN BACKWARDS
            if (x$strand[1]=="+") {
                x$exon[,3] <- x$exon[,3]-1  # CORRECT GENOMIC START IF (+) STRAND
                x$cds[,5] <- x$cds[,5]-1
            } else {
                x$exon[,4] <- x$exon[,4]-1  # CORRECT GENOMIC END (-) STRAND
                x$cds[,6] <- x$cds[,6]-1
            }
            map[[u]] <- x
        }
    })
    print(st)
    names(map) <- utrans
    if (is.index) {
        convert <- data.frame(InputID=tlst[match(names(map),tlst[,2]),1], MapID=utrans)
    } else if (is.funcRNA) {
        convert <- data.frame(InputID=gdat[,1], MapID=gdat[,2])
    } else {
        convert <- data.frame(InputID=utrans, MapID=utrans)
    }
    map <- list(header=rmsh, header.PG=remap.samPG, convert=convert, data=map)
    
    if (!is.funcRNA & luniq(convert[,1])<length(convert[,1])) {
        message("ERROR: some input IDs have more than one copy!\n")
        ## NO OUTPUT (but return 'map' invisibly for troubleshooting)
    } else {
        message("Writing outputs...")
        write.table(gtfx, paste0(outprefix,"txt"), sep="\t", quote=FALSE, row.names=FALSE, col.names=c("InputID","MapID","Chr","Strand","Exon_Trans_Start","Exon_Trans_End","Exon_Geno_Start","Exon_Geno_End","CDS_Start","CDS_End","CDS_Trans_Start","CDS_Trans_End","CDS_Geno_Start","CDS_Geno_End"))
        save(map, file=paste0(outprefix,"RData"))
    }
    invisible(map)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "gtfremap.sam")
gtfremap.sam <- function(sam, map, multi=c("random","all","none"), primary.reset=FALSE) {
    
    ## takes a read.as.sam() sam object and a gtf2map() map object, and returns the sam object with remapped chrom and start fields, and possibly-altered cigars and bitflags.
    ## tags are not altered, as these are generally aligner-specific; output may be inconsistent with original tags...
    ## sam[3] (reference seq) MUST exist in names(map).
    ## sam[4] (start pos) MUST be within the range of min(map[[sam[1]]]$exons$tstart) to max(map[[sam[1]]]$exons$tend).
    ## 
    ## for map: load("/n/data1/genomes/indexes/dm6/Ens_84/dm6.Ens_84.cuff.gtf.index/dm6.Ens_84.cuff.gtf2map.RData"), e.g.
    
    multi <- match.arg(multi)
    if (multi=="all" & !primary.reset) {
        message("If multi=all then primary.reset=TRUE is required; changing to TRUE...\n")
        primary.reset=TRUE
    }
    if (is.ndfl(sam) & "header" %in% names(sam)) {
        ## 'sam' in read.as.sam() format; OK
    } else if (is.data.frame(sam)) {  # headerless?
        sam <- list(header=c(), data=sam)  # mimic read.as.sam() format
    } else {
        stop("'sam' object not in a recognized format!\n")
    }
    sam.spliced <- grepl("N",sam$data[,6])
    if (any(sam.spliced)) {
        message(paste("Unable to remap sam-spliced alignments: dropping",sum(sam.spliced),"records!"))
        sam$data <- sam$data[!sam.spliced,]
    }
    N <- nrow(sam$data)  # original (after dropping any spliced records)
    conv2data <- match(map$convert$MapID, names(map$data))  # hopefully in same order, but just in case...
    conv <- split(conv2data, map$convert$InputID)           # elements of map$data list which are mappable to each unique InputID
    in.conv <- conv[match(sam$data[,3], names(conv))]       # elements of map$data list which are mappable to each row of sam$data
    n.conv <- listLengths(in.conv)
    if (any(n.conv==0)) stop(paste(sum(n.conv==0),"records have unmappable references!  Halting.\n"))
    primary <- as.list(rep(1,N))  # initially: number of output alignment (per input) that will be flagged as primary
    expand <- as.list(1:N)        # initially: each row number in its own list element
    if (any(n.conv>1)) {
        in.multi <- which(n.conv>1)
        nmul <- length(in.multi)
        ncon <- n.conv[i]
        message(paste(nmul,"alignments on",luniq(sam$data[in.multi,3]),"old references are multi-mappable to new references."))
        if (multi=="random") {
            for (i in in.multi) {
                in.conv[[i]] <- sample(in.conv[[i]],1)  # pick 1 at random to get the alignment
                ## do not modify 'primary' or 'expand'; output rows are still 1:1
            }
        } else if (multi=="all") {
            for (i in in.multi) {
                primary[[i]] <- rep(0,ncon)          # reboot: none are primary
                primary[[i]][sample(1:ncon,1)] <- 1  # pick 1 at random to be the primary alignment
                expand[[i]] <- rep(i,ncon)           # expansion will replicate this row n.conv[i] times, one for each new mapping
                ## no need to modify 'in.conv'
            }
        } else if (multi=="drop") {
            for (i in in.multi) {
                primary[[i]] <- expand[[i]] <- in.conv[[i]] <- numeric(0)  # empty the elements -- expansion will remove these rows
            }
        }
        ## Expand (or contract..) sam$data into correct number of output rows, according to multi-mapping method
        if (multi!="random") sam$data <- sam$data[unlist(expand),]     # will duplicate or delete various rows to match M output lines
        if (multi=="drop") {
            in.conv <- in.conv[listLengths(in.conv)>0]  # remove dropped inputs from the converter
            primary <- primary[listLengths(primary)>0]  # nothing to flag as primary
        }
    }
    M <- nrow(sam$data)  # final
    in.conv <- unlist(in.conv)  # now 1:1 with sam$data (if it wasn't already)
    primary <- unlist(primary)  # "
    nre <- nameless(sapply(lapply(map$data,"[[","exon"),nrow))[in.conv]  # 1:1 with sam$data: number of exons in target transcript
    ##IM(N,M,length(in.conv),length(primary),length(nre))
    flags <- sam$data[,2]
    pos <- sam$data[,4]-1  # 0-BASED
    cigar <- sam$data[,6]
    rlen <- nchar(sam$data[,10])
    #M <- 5000   ######### TESTING
    message(paste("Remapping",format(N,big.mark=","),"input records to",format(M,big.mark=","),"output records..."))
    system.time({
        report.index(0,1E5,M,time=TRUE)
        x <- do.call(rbind, lapply(1:M, function(i) {
            report.index(i,1E5,M,time=TRUE)
            e <- map$data[[in.conv[i]]]$exon
            nr <- nre[i]
            xd <- e[,1]-pos[i]
            e1 <- which(xd-1      >=0)[1]-1  # exon of read start (initially)
            e2 <- which(xd-rlen[i]>=0)[1]-1  # exon of read end   (initially)
            #IM("SAM:",sam$data[i,]); IM("START0:",pos[i]); IM("END:",pos[i]+rlen[i]); IM("RLEN:",rlen[i]); IM("EXONS:",nr); IM("EX1:",e1); IM("EX2:",e2); e; xd; xd-rlen[i]  ## DEBUGGING
            if (is.na(e1)) e1 <- nr
            if (is.na(e2)) e2 <- nr
            intron <- ifelse(e1==e2, 0, abs(e$gstart[e2]-e$gend[e1]))  # size of intron between two exons
            tgstr <- sign(e$gend[e1]-e$gstart[e1])
            c(exon1=e1, exon2=e2, exgap=e2-e1, tend1=e$tend[e1], tstart2=e$tstart[e2], gend1=ifelse(tgstr==1,e$gend[e1],e$gstart[e1]), gstart2=ifelse(tgstr==1,e$gstart[e2],e$gend[e2]), intron=intron, tgstr=tgstr)
        }))
        x <- data.frame(x, rtstr=c(-1,1)[(bitwAnd(flags[1:M],16)==0)+1], rgstr=0, pre.splice=0, post.splice=0, rtstart=pos[1:M], rtend=pos[1:M]+rlen[1:M], rgstart=0, rgend=0, tcigar=cigar[1:M], gcigar="")  ## KEEP 0-BASED
        x$rgstr <- x$tgstr*x$rtstr
        report.index(M,1E5,M,time=TRUE)
    })
    
    spliced <- x$exon1 != x$exon2
    pstr <- x$tgstr==1
    psplice <- which( spliced &  pstr)
    nsplice <- which( spliced & !pstr)
    
    ##x$pre.splice[spliced] <- x$tend1[spliced]-x$rtstart[spliced]
    ##x$post.splice[spliced] <- x$rtend[spliced]-x$tstart2[spliced]
    x$pre.splice <- x$tend1-x$rtstart
    x$post.splice <- x$rtend-x$tstart2
    
    x$rgstart[psplice] <- x$gend1[psplice]-x$pre.splice[psplice]
    x$rgend[psplice] <- x$gstart2[psplice]+x$post.splice[psplice]
    x$rgstart[nsplice] <- x$gstart2[nsplice]+x$post.splice[nsplice]
    x$rgend[nsplice] <- x$gend1[nsplice]-x$pre.splice[nsplice]
    x$rgstart[!spliced] <- x$gend1[!spliced]-x$pre.splice[!spliced]    ###### FIXME
    x$rgend[!spliced] <- x$gstart2[!spliced]+x$post.splice[!spliced]   ###### ARE THESE STILL CORRECT?
    
    x$gcigar[!spliced] <- x$tcigar[!spliced]
    x$gcigar[psplice] <- paste0(x$pre.splice[psplice],"M",abs(x$intron[psplice]),"N",x$post.splice[psplice],"M")
    x$gcigar[nsplice] <- paste0(x$post.splice[nsplice],"M",abs(x$intron[nsplice]),"N",x$pre.splice[nsplice],"M")
    
    #x[spliced,]   ## DEBUGGING
    msplice <- x$exgap>1
    message(paste(sum(spliced),"spliced alignments |",sum(x$exon1>x$exon2),"exon1>exon2 |",sum(x$pre.splice[spliced]<=0),"bad pre-splice |",sum(x$post.splice[spliced]<=0),"bad post-splice |",sum(msplice),"multi-spliced"))
    if (any(msplice)) {
        for (i in which(msplice)) {
            e <- map$data[[in.conv[i]]]$exon
            ex1 <- x$exon1[i]
            ex2 <- x$exon2[i]
            gc <- rep("", 1+2*x$exgap[i])
            gc[1] <- paste0(x$pre.splice[i],"M")
            j <- 1
            for (k in (ex1+1):ex2) {
                intron <- abs(e$gstart[k]-e$gend[k-1])
                if (k==ex2) {
                    #IM(i, j, "EQ:", ex1+1, ex2, k, ":", e$gstart[k], e$gend[k-1], intron, ":", x$post.splice[i])   ## DEBUGGING
                    gc[(j+1):(j+2)] <- c( paste0(intron,"N"), paste0(x$post.splice[i],"M") )
                } else {
                    xsize <- abs(e$gend[k]-e$gstart[k])
                    #IM(i, j, "NEQ:", ex1+1, ex2, k, ":", e$gstart[k], e$gend[k-1], intron, ":", e$gend[k], e$gstart[k], xsize)   ## DEBUGGING
                    gc[(j+1):(j+2)] <- c( paste0(intron,"N"), paste0(xsize,"M") )
                }
                j <- j+2
            }
            if (x$tgstr[i]==-1) gc <- rev(gc)
            x$gcigar[i] <- paste(gc,collapse="")
        }
        ## DEBUGGING
        #tcl=as.numeric(sub("M","",x$tcigar[msplice]))  # transcriptomic cigar len
        #gcl=sapply(x$gcigar[msplice], function(y) sum(as.numeric(unlist(strsplit(gsub("[0-9]+N","",y),"M")))) )  # genomic cigar len
        #cbind(tcl,gcl,lost=tcl-gcl,x[msplice,])
        #which(tcl!=gcl); which(msplice)[tcl!=gcl]
    }
    
    #xstr <- cbind(unique(x[,9:11]),N=0); for (i in 1:nrow(xstr)) { xstr[i,4] <- sum(x[,9]==xstr[i,1] & x[,10]==xstr[i,2] & x[,11]==xstr[i,3]) }; xstr   ## DEBUGGING

    if (primary.reset) {
        ## Full reset of flag 256
        sam.secondary <- bitwAnd(flags[1:M],256)==256
        flags[sam.secondary] <- flags[sam.secondary]-256      # remove secondary flag (all become primary)
        remap.secondary <- primary[1:M]==0
        flags[remap.secondary] <- flags[remap.secondary]+256  # replace secondary flag on qualifying remapped alignments
    } else {
        ## Partial reset of flag 256 only if multi=="all"; newly-secondary alignments must be flagged as such
        sam.primary <- bitwAnd(flags[1:M],256)==0
        remap.secondary <- primary[1:M]==0
        new.secondary <- sam.primary & remap.secondary
        flags[new.secondary] <- flags[new.secondary]+256      # add new secondary flag on qualifying remapped alignments
    }
    
    sam.nstr <- bitwAnd(flags[1:M],16)==16
    flags[sam.nstr] <- flags[sam.nstr]-16        # remove transcriptomic strandedness
    remap.nstr <- x$rgstr==-1
    flags[remap.nstr] <- flags[remap.nstr]+16    # replace with genomic strandedness
    
    ## VERY LAST: REPLACE DATA COLUMNS IN SAM OBJECT
    sam$data[1:M,2] <- flags  # new bit flags (strand and secondary-ness may be altered)
    sam$data[1:M,3] <- sapply(map$data[in.conv],"[[","chr")  # transcript->chromosome
    sam$data[1:M,4] <- x$rgstart+1   # 1-BASED chromosome start pos
    sam$data[1:M,6] <- x$gcigar   # cigar modified for genomic alignment (may have been spliced)
    
    sam$header <- c(map$header, sam$header[!grepl("^@(HD|SQ)",sam$header)])
    if (length(map$header.PG)>0) sam$header <- c(sam$header, map$header.PG)
    
    sam
}
