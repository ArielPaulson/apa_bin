

apa.names$general <- c(apa.names$general, "err.ord")
err.ord <- function(vec, zap=NA) { 
	
	## Returns orders-of-magnitude of measurement error (i.e. min, max number of decimals for any number in a vector)
	## "zap": curb error magnitude by rounding at 'zap' decimals
	
	if (!is.nlv(vec)) { stop("Input must be a non-list vector!\n") }
	errs <- as.numeric(sapply(as.character(vec), simplify=TRUE, FUN=function(x){strsplit(x,".",fixed=TRUE)[[1]][2]}))	# getting decimals this way controls arithmetical error
	errs[is.na(errs)] <- 0	# these were integers
	if (!is.na(zap)) { errs <- round(errs, zap) }
	is.dec <- errs != 0
	if (any(is.dec)) {	# some decimals
		ndec <- sapply(errs, simplify=TRUE, nchar)
		ord.min <- ifelse(sum(is.dec) == length(is.dec), min(ndec), 0)	# if any integers, min ord = 0
		ord.max <- max(ndec)
		return( c(ord.min, ord.max) )
	} else {		# all integers
		return( c(0,0) )
	}
}


apa.names$general <- c(apa.names$general, "factorize")
factorize <- function(N, flag.primes=FALSE, primes.only=FALSE, extended=FALSE) {
	
	## Returns the modulus space for number N, i.e., all numbers that evenly divide N.
	## 'flag.primes=T' adds a logical column indicating prime factors.
	## 'primes.only=T' goes one step further and returns ONLY the prime factors.
	##	PRIME OPTIONS GET TIME-EXPENSIVE FOR LARGE N!
	## 'extended=T' returns not only the value of N/factor, but the power of the factor (# successive divisions) + remainder
	##	'extended' was developed for use by LCD()
	
	all.names <- c("factor","times","div.pwr","div.pwr.rem")
	prime.name <- "is.prime"
	
	division.power <- function(fac, N) {
		if (is.na(fac)) {
			return(c(NA, NA))
		} else if (fac == 0) {
			return(c(NA, NA))
		} else if (fac == 1) {
			return(c(NA, NA))
		} else if (fac > N) {
			return(c(0,N))
		} else if (fac == N) {
			return(c(1,0))
		} else {
			rem <- NA
			pwr <- 0
			current <- N
			while (is.na(rem)) {
				val <- current / fac
				if (is.decimal(val)) {
					rem <- current
				} else {
					pwr <- pwr + 1
					current <- val
				}
			}
			return(c(pwr,rem))
		}
	}
	
	if (is.na(N) | is.infinite(N)) {
		stop("Cannot factor NA or Inf entries!\n")
	} else if (N == 0) {
		if (extended) {
			y <- matrix(NA, ncol=2)
			names(y) <- all.names[1:2]
		} else {
			y <- matrix(NA, ncol=4)
			names(y)[1:4] <- all.names
		}
	} else {
		x <- which(sapply(1:N, FUN=function(x,i){i%%x==0},N))
		y <- as.data.frame(cbind(x,rev(x)))
		names(y) <- all.names[1:2]
		if (flag.primes | primes.only) { prime.col <- sapply(y[,1], is.prime) }
		if (flag.primes) {
			if (extended) {
				y <- cbind(y, t(sapply(y[,1], division.power, N)), prime.col)
				names(y) <- c(all.names[1:4], prime.name)
			} else {
				y <- cbind(y, prime.col)
				names(y) <- c(all.names[1:2], prime.name)
			}
		} else {
			if (primes.only) { y <- y[prime.col,] }
			if (extended) {
				y <- cbind(y, t(sapply(y[,1], division.power, N)))
				names(y) <- all.names[1:4]
			} else {
				names(y) <- all.names[1:2]
			}
		}
	}
	return(y)
}


apa.names$general <- c(apa.names$general, "is.prime")
is.prime <- function(vec, brute=FALSE, negatives=FALSE) {
    
    ## returns T/F for primeness.
    ## it is slow, due to "%in%" lookups.  The required prime list is loaded only once per R session.
    ## one prime list is used, taken from: http://primes.utm.edu/lists/small/
    ##	1. all primes <= 100K (    9,592 total,  65 Kb)		## DEPRECATED.
    ##	2. all primes <=   1M (   78,498 total, 603 Kb)		## DEPRECATED.
    ##	3. all primes <=  10M (  664,578 total,   6 Mb)		## DEPRECATED.
    ##	4. all primes <= 100M (5,761,456 total,  55 Mb)		## For simplicity only the largest list is loaded -> logical vector of length 1E8 @ 400MB, FYI.
    ## 
    ## The below used to be true, but then I converted to one master primes list and abolished stepped lookups:
    ##  "stepped lookup is used to keep runtimes short; longer lists loaded only if required.
    ##  N > 100M gets factorized by brute force if 'brute=TRUE', watch out!!!!!!!!!!!!!!!
    ##    otherwise, testing N > 100M fails: too large to bother with in this tool kit."
    
    if (!exists("apa_tools.primes.upto.100M")) {
        IM("One-time loading of primes list <= 1E8 @ 55MB...\n (into global object 'apa_tools.primes.upto.100M')")
        temp <- rep(F, 1E8)
        temp[as.numeric(scan(paste(data.path,"primes/primes_up_to_100M.txt",sep="/"), what=0))] <- TRUE
        apa_tools.primes.upto.100M <<- temp    #####  GLOBAL  !!!!!
        attr(apa_tools.primes.upto.100M,"source") <<- "apa_tools"
        apa.names$data <<- unique(c(apa.names$data,"apa_tools.primes.upto.100M"))    #####  GLOBAL  !!!!!
    } else {
        src <- attributes(apa_tools.primes.upto.100M)$source
        fail <- FALSE
        if (length(src)==0) {
            fail <- TRUE
        } else if (src != "apa_tools") {
            fail <- TRUE
        }
        if (fail) {
            ## not the bona fide object, apparently
            ## somehow this name was chosen for an object already??
            ## will not overwrite someone else's object
            stop("Sorry, but somehow a different object named 'apa_tools.primes.upto.100M' already exists!  Will not overwrite.")
        }
    }
    
    brute.factor <- function(i)	{
        ## *Try hard to avoid using this*, since it isn't in C or Fortran (and even if it was...)
        ## Test for primeness via full factorization of number
        ## Only used if number exceeds 100M, since lookup table runs from 1-100M.
        ##  Arguably, this is the worst use case for this function.
        ## Insanely slow with very large numbers, but otherwise works well
        ms <- factorize(i)
        ifelse (nrow(ms) - 2 == 0, TRUE, FALSE)  # no divisors besides i and 1?
    }

    neg <- vec<0
    zero <- vec==0
    over <- vec>1E8
    float <- zapsmall(vec)!=as.integer(vec)
    posint <- !float&!neg&!zero&!over
    negint <- !float&neg
    is.p <- rep(FALSE, length(vec))
    is.p[posint] <- apa_tools.primes.upto.100M[vec[posint]]
    if (negatives) is.p[negint] <- apa_tools.primes.upto.100M[abs(vec[negint])]
    is.p[over] <- NA
    
    if (sum(over)>0) {
        if (brute) {
            is.p[over] <- sapply(vec[over], brute.factor)
        } else {
            IM("At least one number exceeded 1E8: will not test these unless 'brute=TRUE'!\n")
        }
    }
    
    names(is.p) <- vec
    is.p
}


apa.names$general <- c(apa.names$general, "LCD")
LCD <- function(vec, nmax=1E7) {
	
	## returns lowest common denominator for a vector of numbers (fractions of course...  but integers won't break it)
	## nmax = max allowed denominator when converting floats to fractions; passed to fractions() as max.denominator;
	##   if 'nmax' too low, sequence set will have lower granularity than given fractions in 'vec',
	##   if 'nmax' too high, algo adjusts to max 'nmax' required for representative granularity, so GENERALLY the runtime will not blow up
	##   but: beware float issues with R -- VERY high nmax (> 1E8) might get a denom size capable of resolving spurious float errors...
	##        this will definitely make your runtime explode!
	
	vec <- real(vec)		# no NA, Inf
	denoms <- unique(as.numeric(sapply(vec, FUN=function(x){ strsplit(attr(fractions(x, cycles=1000, max.denominator=nmax), 'frac'), '/')[[1]][2] })))
	denoms <- denoms[!is.na(denoms)]  # these NAs from integers, which all get denom 1 -- contribute nothing to calculation
	if (length(denoms) == 1) {
		lcd <- denoms[1]
	} else {
		facs <- vector("list", length=length(denoms))
		for (i in 1:length(denoms)) { facs[[i]] <- factorize(denoms[i], primes.only=TRUE, extended=TRUE)[,c(1,3)] }
		facs <- do.call(rbind, facs)   		# all factors w/ powers for all Ns in vec
		uf <- unique(facs[,1])
		ufacs <- cbind(uf, rep(0, length(uf)))	# unique factors with max powers observed for any N
		for (u in 1:length(uf)) { ufacs[u,2] <- max(facs[facs[,1]==ufacs[u],2]) }
		lcd <- prod(ufacs[,1] ^ ufacs[,2])	# product of unique factors raised to max powers
	}	
	return(lcd)
}


apa.names$general <- c(apa.names$general, "GCF")
GCF <- function(vec) {
	
	## returns greatest common factor for a vector of integers
	
	if (any(sapply(vec,is.decimal))) { stop("All values must be integers!\n") }
	facs <- vector("list", length=length(vec))
	for (i in 1:length(vec)) { facs[[i]] <- factorize(vec[i])[,1] }
	gcf <- max(intersect2(facs))
	return(gcf)
}


apa.names$general <- c(apa.names$general, "nCr")
nCr <- function(n, r) {
	
	if (r > n) { stop("r must be <= n!\n") }
	total <- factorial(n) / ( factorial(r)*factorial(n-r) )
	return(total)
}


apa.names$general <- c(apa.names$general, "nPr")
nPr <- function(n, r) {
	
	if (r > n) { stop("r must be <= n!\n") }
	total <- factorial(n) / factorial(n-r)
	return(total)
}


apa.names$hacks <- c(apa.names$hacks, "permn2")
permn2 <- function(n, r, replacement=FALSE) {
    
    ## Provides all n-permute-r sets, with or without replacement
    
	pass <- require("combinat")
	if (!pass) { stop("Cannot load required library 'combinat'!\n") }
	
	if (r == 1) {
		perms2 <- 
			if (length(n)>1) {
				as.matrix(sort(n))
			} else {
				as.matrix(1:n)
			}
	} else {
		revalue <- FALSE
		if (length(n)>1) {   # a custom distribution
			basis <- sort(n)
			n <- length(n)   # REPLACE 'n'
			revalue <- TRUE
		}
		if (r > n & !replacement) stop("Cannot have r > n unless replacement=TRUE!\n")
		
		if (replacement) {
			distrib <- rep(1:n, each=r)
			combs <- unique(t(apply(t(combn(n*r, r)), 1, function(x){distrib[x]})))
			perms <- unique(do.call(rbind,lapply(1:nrow(combs), function(i){do.call(rbind,permn(combs[i,]))})))
		} else {
			combs <- t(combn(n, r))   # first get unique combinations to permute
			perms <- do.call(rbind,lapply(1:nrow(combs), function(i){do.call(rbind,permn(combs[i,]))}))
		}
		if (revalue) {
			perms2 <- t(apply(perms, 1, function(x){basis[x]}))
		} else {
			perms2 <- perms
		}
		perms2 <- perms2[do.call(order,as.list(as.data.frame(perms2))),]
	}
	return(perms2)
}


apa.names$hacks <- c(apa.names$hacks, "combn2")
combn2 <- function(n, r, replacement=FALSE) {
    
	## Provides all n-choose-r sets, with or without replacement
     
	revalue <- FALSE
	if (length(n)>1) {  # a custom distribution
		basis <- sort(n)
		n <- length(n)
		revalue <- TRUE
	}
	if (r > n) { replacement <- TRUE }  # requires replacement, so ignores value of 'replacement' arg
	
	if (replacement) {
		combs <- unique(t(apply(permn2(n,r), 1, function(y){sort(y)})))  # unique sorted permutations = unique combinations
	} else {
		combs <- t(combn(n,r))
	}
	if (revalue) {
		combs2 <- t(apply(combs, 1, function(x){basis[x]}))
	} else {
		combs2 <- combs
	}
	return(combs2)
}


apa.names$general <- c(apa.names$general, "shannon.weaver")
shannon.weaver <- function(x) {
	
	## Shannon-Weaver Index (complexity) for a character vector
	
	-sum(sapply(unique(x), function(i){ p=sum(x==i)/length(x); p*log(p) }))
}


apa.names$general <- c(apa.names$general, "dot.product")
dot.product <- function(x, y) {
    
    ## http://stackoverflow.com/questions/15162741/what-is-rs-crossproduct-function
    
    x[1]*y[1] + x[2]*y[2]
}


apa.names$general <- c(apa.names$general, "cross.product")
cross.product <- function(x, y) {
    
    ## http://stackoverflow.com/questions/15162741/what-is-rs-crossproduct-function
    
    x[1]*y[2] - x[2]*y[1]
}


apa.names$general <- c(apa.names$general, "intersect.lines")
intersect.lines <- function(m1, b1, m2, b2) {
    
    ## point of intersection of two lines.
    ## lines 1 and 2 are indicated by their m (slope) and b (intercept) values.
    
    x <- (b2-b1)/(m1-m2)
    y <- m1*x+b1
    c(x,y)
}


apa.names$dev <- c(apa.names$dev, "hull.stats")
hull.stats <- function(x, y, col=1, lty=1, vertices=NULL, formulae=NULL, tolerance=1, plot.tolerance=NULL) {
    
    ## ADDS TO AN EXISTING PLOT ONLY
    ## plots and returns the convex hull, with a bunch of edge/vertex stats.
    ## 'vertices' toggles plotting numbered vertices; value is a color.
    ## 'formulae' toggles plotting of line formulae for each edge, as a legend.
    ##   value of 'formulae' is an 'x' position argument from legend() (e.g. "topleft", "bottomright", etc.)
    ##   ** edge formulae will be in the output data.frame regardless.
    ## 'tolerance' allows edge-point detection to be more flexible, as a scalar multiple of the empirical base tolerance 0.002203.
    ##   'tolerance=0' turns it off, requiring exact value matching (not recommended due to floating point issues).
    ## 'plot.tolerance' is a color value; if given, edge-matching points will be replotted in this color.
    ## output is  alist with vertex data and edge data.
    ##   vertex data contains the hull point indexes, x and y coords.
    ##   edge data contains from and to vertices and three other stats:
    ##    'density': the number of points that lie on the edge from vertex N to N+1.
    ##    'm', 'b': the slope and intercept of the edge from vertex N to N+1.
    
    x <- signif(real(x),8)  # remove NAs, infinites, and strip (most) floating-point issues
    y <- signif(real(y),8)  # "
    hull <- chull(x,y)
    H <- length(hull)
    I <- 1:H
    J <- c(2:H,1)
    titles <- rep("", H)
    out <- list(
        vertices=data.frame(pos=hull, x=x[hull], y=y[hull], density=0),
        edges=data.frame(from=I, to=J, m=0, b=0, density=0, tolerance=0)
    )
    ## 'tolerance' value allows you to scale how tolerant you want things to be, starting with the empirical base value of 0.002205
    ## for points "on an edge" the distance from the strict edge must not exceed 'tolerance' * 0.002205 * longest perpendicular line visual length (as a normalizer for the scale of the data)
    ## Example: tolerance on the plot diagonal: if x,y ranges are equal and diagonal length is 5, then tolerance will be ~0.01, so points must be this close to the diagonal to be considered "on" it.
    tscale <- 0.002205 * tolerance
    
    ## plot polygon
    for (i in I) {
        j <- J[i]
        segments(x[hull[i]], y[hull[i]], x[hull[j]], y[hull[j]], col=col, lty=lty)
    }
    ## calculate edge formulae (even if not plotted)
    ## also calculate point density per edge
    edge.points <- vertex.points <- list()
    for (i in I) {
        j <- J[i]
        xi <- x[hull[i]]; xj <- x[hull[j]]; yi <- y[hull[i]]; yj <- y[hull[j]]
        out$edges$m[i] <- m <- (yj-yi)/(xj-xi)
        out$edges$b[i] <- b <- yi-m*xi
        if (m==0) {
            titles[i] <- paste0("E",i,"-",j,":       horizontal at y=",ifelse(yi<0,"-"," "),abs(signif(yi,4)))
            out$edges$tolerance[i] <- tol <- tscale * diff(range(y))
            edge.points[[i]] <- which( abs(y-yi) <= tol )
        } else if (is.infinite(m)) {
            titles[i] <- paste0("E",i,"-",j,":       vertical at x=",ifelse(xi<0,"-"," "),abs(signif(xi,4)))
            out$edges$tolerance[i] <- tol <- tscale * diff(range(x))
            edge.points[[i]] <- which( abs(x-xi) <= tol )
        } else {
            titles[i] <- paste0("E",i,"-",j,": y=",ifelse(m<0,"-"," "),abs(signif(m,4)),"x",ifelse(b<0,"-","+"),abs(signif(b,4)))
            perpm <- -1/m
            perpb <- mean(c(yi,yj))-perpm*mean(c(xi,xj))  # perpendicular line running through midpoint of edge
            out$edges$tolerance[i] <- tol <- tscale * visible.segment(perpm, perpb, range(x), range(y))[5]   # tolerance perpendicular to edge
            edge.points[[i]] <- which( abs(y-signif(m*x+b,8)) <= tol )
        }
    }
    ## AFTER all edge points have been celculated, intersect them to get vertex points
    for (i in I) {
        j <- J[i]
        vertex.points[[i]] <- intersect( edge.points[[i]], edge.points[[j]] )
        out$vertices$density[i] <- length(vertex.points[[i]])
        ## not plotting vertex points, yet
    }
    ## then subtract vertex points from edges
    for (i in I) {
        j <- J[i]
        edge.points[[i]] <- setdiff( edge.points[[i]], c(vertex.points[[i]], vertex.points[[j]]) )
        out$edges$density[i] <- length(edge.points[[i]])
        if (plot.tolerance) points(x[edge.points[[i]]], y[edge.points[[i]]], pch=1, cex=1, col=plot.tolerance)
    }
    ## plot formulae if requested
    if (length(formulae)>0) legend(formulae, bty="n", legend=titles)
    ## number vertices LAST
    if (length(vertices)>0) for (i in 1:H) points(x[hull[i]], y[hull[i]], pch=paste0(i,""), col=vertices)
    ## last reporting blurb
    nV <- length(unlist(vertex.points))
    nE <- length(unlist(edge.points))
    message(paste0(nV," vertex points | ",nE," edge points | ",nV+nE," combined (",round(100*(nV+nE)/length(x),2),"% total)"))
    
    invisible(out)
}


apa.names$general <- c(apa.names$general, "winding")
winding <- function(pts, hull) {
    
    ## tests points for containment by a convex hull
    ## 'pts'=test point, 'hull'=ORDERED polygon, e.g. from perimiterize() or chull().  Ordering can be clockwise or counter.
    ##  for the above, rows are points, and columns are dimensions of measurement
    ## returns 1|0|-1; 1=contained, 0=on perimiter, -1=outside
    ## based on: https://www.engr.colostate.edu/~dga/dga/papers/point_in_polygon.pdf
    
    if (!is.matrix(pts)) pts <- matrix(pts, nrow=1)
    if (ncol(pts) != ncol(hull)) stop("'pts' and 'hull' have differing numbers of columns!\n")
    K <- ncol(pts)
    if (K != 2) stop("This algorithm can only handle 2D points and polygons!\n")
    
    wnum <- data.frame("Containment"=rep(NaN,nrow(hull)), "WindingNumber"=rep(NaN,nrow(hull)), "Path"=rep("",nrow(hull)))
    for (i in 1:nrow(pts)) {
        x <- pts[i,]
        path <- c()
        if (any(apply(hull, 1, function(x) all(x==pts[i,]) ))) {
            ## pts[i,] is also a vertex of 'hull'
            num <- NA
            path <- c(NA)
        } else {
            ihull <- hull
            for (k in 1:K) ihull[,k] <- ihull[,k]-x[k]  # translate ihull such that point x is the origin
            x <- rep(0,K)  # point x is now the origin
            num <- 0
            for (j1 in 1:nrow(ihull)) {
                j2 <- ifelse(j1==nrow(ihull),1,j1+1)
                rise <- ihull[j2,2]-ihull[j1,2]
                rising.sign <- sign(rise)
                run <- ihull[j2,1]-ihull[j1,1]
                
                increment <- NA  # the default increment, in case loop is broken
                
                if (rise==0) {
                    ## edge is parallel to x-axis
                    if (ihull[j1,2]==0) {
                        ## current edge contained by x-axis, but not necessarily the positive side
                        if (sign(ihull[j1,1]) + sign(ihull[j2,1]) == 0) {
                            ## edge crosses origin, thus pts[i,] is contained by edge; we are done
                            break
                        } else {
                            ## edge did not cross origin; ignore
                            increment <- 0
                        }
                    } else {
                        ## did not interact with x-axis at all
                        increment <- 0
                    }
                } else if (ihull[j1,2] == 0) {
                    ## leaving x-axis, but not necessarily the positive side
                    if (ihull[j1,1]>0) {
                        ## it was the positive side
                        increment <- rising.sign/2
                    } else {
                        ## not the positive side
                        increment <- 0
                    }
                } else if (ihull[j2,2] == 0) {
                    ## landing on x-axis, but not necessarily the positive side
                    if (ihull[j2,1]>0) {
                        ## it was the positive side
                        increment <- rising.sign/2
                    } else {
                        ## not the positive side
                        increment <- 0
                    }
                } else if (sign(ihull[j1,2]) + sign(ihull[j2,2]) == 0) {
                    ## x-axis was crossed, but not necessarily the positive side
                    if (run==0) {
                        ## edge parallel to y-axis
                        if (ihull[j1,1]==0) {
                            ## current edge sits on the y-axis, thus crosses origin, thus pts[i,] is contained by edge; we are done
                            break
                        } else if (ihull[j1,1]>0 & ihull[j2,1]>0) {
                            ## on positive side
                            increment <- rising.sign
                        } else {
                            ## not the positive side
                            increment <- 0
                        }
                    } else {
                        ## do the -b/m test, which resolves all other cases
                        m <- rise/run
                        b <- ihull[j1,2]-m*ihull[j1,1]
                        if (b==0) {
                            ## passed through origin, thus pts[i,] is contained by edge; we are done
                            break
                        } else if (-b/m>0) {
                            ## we crossed + side
                            increment <- rising.sign
                        } else {
                            ## we crossed - side
                            increment <- 0
                        }
                    }
                } else {
                    ## x-axis was not interacted with in any way
                    increment <- 0
                }
                num <- num + increment
                path <- c(path,increment)
            }
            if (is.na(increment)) {
                ## loop was broken; point was contained by edge
                num <- NA
                path <- c(path,NA)
            }
        }
        wnum[i,] <- list(ifelse(is.na(num),0,ifelse(num==0,-1,1)), num, paste(path,collapse=","))
    }
    wnum
}


apa.names$general <- c(apa.names$general, "polygon.overlap")
polygon.overlap <- function(x, detail=FALSE, strict=FALSE) {
    
    ## 'x' is a list of numeric matrices, each with 2 columns, containing 2D polygon coordinates.
    ## in each, rows represent points in 2D space.
    ## returns a square matrix of dimension=length(x), with values 1|0|-1 indicating polygons i,j intersect|touch|do not intersect

    ## FUNCTION 1
    vertex.containment.separating <- function(hull1, hull2) {
        ## separating axis method: http://content.gpwiki.org/index.php/Polygon_Collision#Separating_Axis
        ## ######### does not appear to be working completely right...
        if (nrow(hull1) <= nrow(hull2)) {
            ref <- hull1
            non <- hull2
        } else {
            ref <- hull2
            non <- hull1
        }
        V <- nrow(ref)
        cross <- new.list(1:V)
        tests <- rep(1,V)  # init all as non-intersecting
        for (v1 in 1:V) {
            v2 <- ifelse (v1<V, v1+1, 1)
            edge <- ref[v2,]-ref[v1,]  # edge vector
            perp <- c(-edge[2],edge[1])  # perpendicular vector
            perp <- perp/c(dist(rbind(c(0,0),perp)))  # unit length
#            IM(i,j,v); IM(edge); IM(perp)
            ref.proj <- ref %*% perp
            non.proj <- non %*% perp
#            segments(ref[v2,1],ref[v2,2], ref[v1,1],ref[v1,2], col=i+1, lty=v1)
#            segments(0,0, perp[1],perp[2], col=i+4, lty=v)
            cross[[v]] <-
                if (mean(ref.proj)<mean(non.proj)) {
                    outer(c(non.proj),c(ref.proj),"-")
                } else {
                    outer(c(ref.proj),c(non.proj),"-")
                }
            tests[v1] <- sign(min(cross[[v1]]))
        }
        tests  # -1, 0, or 1
    }
    
    ## FUNCTION 2
    vertex.containment.winding <- function(hull1, hull2) winding(hull1, hull2)  # -1, 0, or 1
    
    ## FUNCTION 3
    edge.intersection <- function(hull1, hull2, strict=FALSE) {
        ## edge intersection: http://stackoverflow.com/questions/563198/how-do-you-detect-where-two-line-segments-intersect
        ## point-line distance: https://en.wikipedia.org/wiki/Distance_from_a_point_to_a_line
        ## if 'strict=TRUE': touching edges or vertices are considered intersecting (1).  Otherwise, 'touching' (0).
        nr1 <- nrow(hull1)
        nr2 <- nrow(hull2)
        test <- class <- matrix(NA, nr1, nr2)
        for (v1 in 1:nr1) {
            v2 <- ifelse(v1<nr1, v1+1, 1)
            p <- hull1[v1,]
            p2 <- hull1[v2,]
            r <- p2-p
            for (w1 in 1:nr2) {
                w2 <- ifelse(w1<nr2, w1+1, 1)
                q <- hull2[w1,]
                q2 <- hull2[w2,]
                s <- q2-q
                coterminal <- all(p==q) | all(p==q2) | all(p2==q) | all(p2==q2)
                rxs <- cross.product(r, s)
                t <- cross.product(q-p, s/rxs)
                u <- cross.product(q-p, r/rxs)
                if (rxs==0) {
                    ## parallel
                    if (cross.product(q-p, r)==0) {
                        ## parallel collinear
                        ## NOW MUST TEST IF SEGMENTS OVERLAP OR NOT
                        rdr <- dot.product(r, r)
                        sdr <- dot.product(r, r)
                        t0 = dot.product(q-p, r/rdr)
                        t1 = dot.product(q+s-p, r/rdr)
                        t.overlap <- ifelse( (t0>0&t0<1) | (t1>0&t1<1), TRUE, FALSE )  # RETURNS FALSE IF ONLY COTERMINAL
                        if (t.overlap) {
                            ## parallel collinear, overlapping
                            test.value <- ifelse(strict, 1, 0)
                            class.value <- 0
                        } else if (coterminal) {
                            ## parallel collinear, coterminal (one segments ends where the other begins)
                            test.value <- ifelse(strict, 1, 0)
                            class.value <- 1
                        } else {
                            ## parallel collinear, disjoint
                            test.value <- -1
                            class.value <- 2
                        }
                    } else {
                        ## parallel non-collinear
                        test.value <- -1
                        class.value <- 3
                    }
                } else {
                    ## non-parallel
                    if (coterminal) {
                        ## non-parallel, but share a vertex
                        test.value <- ifelse(strict, 1, 0)
                        class.value <- 4
                    } else if (t>=0 & t<=1 & u>=0 & u<=1) {
                        ## non-parallel intersecting
                        ## NOW MUST TEST IF LINE 1 ENDS AT LINE 2, OR IF LINE 1 ACTUALLY CROSSES LINE 2
                        ## problem: using below point-line distance model, all values are identical...  (was this fixed?)
                        v1d <- abs((q2[2]-q[2])*p[1]-(q2[1]-q[1])*p[2]+q2[1]*q[2]-q2[2]*q[1])/sqrt((q2[2]-q[2])^2+(q2[1]-q[1])^2)    # v1 dist from w1->w2
                        v2d <- abs((q2[2]-q[2])*p2[1]-(q2[1]-q[1])*p2[2]+q2[1]*q[2]-q2[2]*q[1])/sqrt((q2[2]-q[2])^2+(q2[1]-q[1])^2)  # v2 dist from w1->w2
                        w1d <- abs((p2[2]-p[2])*q[1]-(p2[1]-p[1])*q[2]+p2[1]*p[2]-p2[2]*p[1])/sqrt((p2[2]-p[2])^2+(p2[1]-p[1])^2)    # w1 dist from v1->v2
                        w2d <- abs((p2[2]-p[2])*q2[1]-(p2[1]-p[1])*q2[2]+p2[1]*p[2]-p2[2]*p[1])/sqrt((p2[2]-p[2])^2+(p2[1]-p[1])^2)  # w2 dist from v1->v2
                        test.value <- ifelse(any(c(v1d,v2d,w1d,w2d)==0), ifelse(strict, 1, 0), 1)
                        class.value <- 5
                    } else {
                        ## non-parallel non-intersecting
                        test.value <- -1
                        class.value <- 6
                    }
                }
                test[v1,w1] <- test.value
                class[v1,w1] <- class.value
            }
        }
        list(test=test, class=class)
    }
    
    hulls <- lapply(x, function(y) y[chull(y),] )
    H <- length(hulls)
    
    v.test <- e.test <- combo <- matrix(NA,H,H,FALSE,list(names(hulls),names(hulls)))  # vertex-containment, edge-intersection tests; 'combo' is combination
    v.det <- e.det <- new.list(names(hulls), elem=new.list(names(hulls)))
    for (i in 1:H) {
        for (j in 1:H) {
            ##v.cont[i,j] <- vertex.containment.separating(hulls[[i]], hulls[[j]])
            e.det[[i]][[j]] <- edge.intersection(hulls[[i]], hulls[[j]], strict=strict)
            v.det[[i]][[j]] <- vertex.containment.winding(hulls[[i]], hulls[[j]])
            if (strict) v.det[[i]][[j]][v.det[[i]][[j]]==0] <- 1
            e.test[i,j] <- ifelse(all(e.det[[i]][[j]]$test==0), 1, max(e.det[[i]][[j]]$test))  # if all == 0, then polygon is identical to hull (so = 1)
            v.test[i,j] <- ifelse(all(v.det[[i]][[j]][,1]==0), 1, max(v.det[[i]][[j]][,1]))  # if all == 0, then polygon is embedded in hull (so = 1)
        }
    }
    for (i in 1:H) {
        for (j in 1:H) {
            combo[i,j] <- max(c(e.test[i,j],v.test[i,j],e.test[j,i],v.test[j,i]), na.rm=TRUE)  # make 'combo' symmetric
        }
    }
    
    output <- list(combined=combo, edge.summary=e.test, vertex.summary=v.test)
    if (detail) output <- c(output, list(edge.detail=e.det, vertex.detail=v.det))
    output
}


apa.names$general <- c(apa.names$general, "NA.interpolate")
NA.interpolate <- function(v) {
    ## v is a vector with NAs
    ## interpolates NA values from non-NA neighbors of NA positions
    ## terminal NAs are handled by taking the slope of the two non-NA neighbors and continuing that slope through the terminal NAs
    ## runs of single or 2+ NAs are all given same value (mean of non-NA neighbors)
    
    if (any(is.na(v))) {
        nav <- find.runs(is.na(v), terminal=FALSE)
        nav <- nav[names(nav)=="TRUE"]
        nav1 <- nav[listLengths(nav)==1]
        navM <- nav[listLengths(nav)>1]
        v2 <- v
        for (n in 1:length(nav)) {
            is <- nav[[n]]
            ir <- range(is)
            if (ir[1]==1 & ir[2]==length(v)) {
                ## entire vector was NA; nothing to do
            } else if (ir[1]==1) {
                m <- diff(v2[c(ir[2]+1,ir[2]+2)])
                for (j in rev(is)) v2[j] <- v2[j+1] - m
            } else if (ir[2]==length(v)) {
                m <- diff(v2[c(ir[1]-1,ir[1]-2)])
                for (j in is) v2[j] <- v2[j-1] - m
            } else {
                v2[is] <- mean(v2[c(ir[1]-1,ir[2]+1)])
            }
        }
        v2
    } else {
        v
    }
}


apa.names$general <- c(apa.names$general, "mov.avg")
mov.avg <- function(vec, win, func=mean, loop=FALSE, na.rm=FALSE, interpolate=FALSE) {
    
    ## takes a moving average of a vector, given a window size
    ## does this using apply() and not a loop -- may overrun mem limits for very large window size
    ## "loop=TRUE" makes it loop instead -- trades low mem for high runtime
    
    MA <- rep(NA, length(vec))
    len <- length(vec)-win
    start <- round(win/2,0)
    end <- start+len
    if (loop) {
        MA <- sapply(start:end, function(i){ func(vec[(i-start+1):(i-start+win)]) })  # actually, avoided the loop -- is this faster than loop=FALSE?
    } else {
        mat <- matrix(0, ncol=win, nrow=len+1)
        for (i in 1:win) mat[,i] <- vec[i:(len+i)]
        MA[start:end] <- apply(mat, 1, func, na.rm=na.rm)
    }
    if (interpolate) {
        NA.interpolate(MA)
    } else {
        MA
    }
}


apa.names$general <- c(apa.names$general, "lowess2")
lowess2 <- function(x, y=NULL, f=2/3, iter=3, delta=0.01*diff(range(x,na.rm=na.rm)), na.rm=FALSE) {
    
    ## same as lowess(), but allows for na.rm.  Lowesses non-NA values, then interpolates values for NA positions.
    
    nz <- is.na(x)
    if (length(y)>0) nz <- nz|is.na(y)
    
    if (na.rm & any(nz)) {
        x2 <- x[!nz]
        if (length(y)>0) {
            y2 <- y[!nz]
            ## Lowess with 'y'
            z <- lowess(x=x[!nz], y=y[!nz], f=f, iter=iter, delta=delta)
            ## Put 'x' values back in place (re-introduce NAs)
            z$x <- z$x[match(1:length(x),which(!nz))]
            ## Interpolate 'x' values
            z$x <- NA.interpolate(z$x)
        } else {
            ## Lowess with no 'y'
            z <- lowess(x=x[!nz], f=f, iter=iter, delta=delta)
            ## Replace 'x' values
            z$x <- 1:length(x)
        }
        ## put 'y' values back in place (re-introduce NAs)
        z$y <- z$y[match(1:length(x),which(!nz))]
        ## Interpolate 'y' values
        z$y <- NA.interpolate(z$y)
        z
    } else {
        lowess(x=x, y=y, f=f, iter=iter, delta=delta)
    }
}


apa.names$general <- c(apa.names$general, "thetacon")
thetacon <- function(vec, input, output) {
		
    ## converts between "thetas": slopes, degrees, and radians (= 'input' and 'output' types)
    ## 'input' is automatically converted to radians, then to 'output' value
    
    input <- tolower(input)
    output <- tolower(output)
    
    conv.fun <- function(x, input, output) {
        temp <- switch(input, deg=, degree=, degrees=x*pi/180, rad=, radian=, radians=x, m=, slope=atan(x))
        if (is.null(temp)) { stop("Unrecognized type for 'input'!\n") }
        
        if (round(temp,16)==pi/2 & output %in% c("m","slope")) {
            out <- Inf    # because R's tan() interpolates and doesn't get it quite right
        } else if (round(temp,16)==3*pi/2 & output %in% c("m","slope")) {
            out <- -Inf   # because R's tan() interpolates and doesn't get it quite right
        } else {
            out <- switch(output, deg=, degree=, degrees=temp*180/pi, rad=, radian=, radians=temp, m=, slope=tan(temp))
            if (is.null(out)) { stop("Unrecognized type for 'output'!\n") }
            if (out < 0) { out <- switch(output, deg=, degree=, degrees=360+out, rad=, radian=, radians=2*pi+out, m=, slope=out) }
        }
        return(out)
    }
    
    sapply(vec, conv.fun, input, output)
}


apa.names$general <- c(apa.names$general, "xy2polar")
xy2polar <- function(x) {
    
    ## Takes 'x' = cartesian (x,y) pair and returns polar (r,theta) pair
    
    r <- sqrt(x[1]^2+x[2]^2)
    if (x[1]>=0&x[2]>=0) {         # Q1
        th <- atan(x[2]/x[1])
    } else if (x[1]<0&x[2]>0) {    # Q2
        th <- pi - abs(atan(x[2]/x[1]))  # atan < 0
    } else if (x[1]<=0&x[2]<=0) {  # Q3
        th <- pi + abs(atan(x[2]/x[1]))  # abs to catch points where x=0 & y<0
    } else {                       # Q4
        th <- 2*pi - abs(atan(x[2]/x[1]))  # atan < 0
    }
    return(c(r=r,theta=th))
}


apa.names$general <- c(apa.names$general, "rebase")
rebase <- function(x, base=10, inbase=NULL, verbose=FALSE) {
	
	## converts a number x from one base to another
	## input base 'inbase' is decimal if x is numeric; else tries to guess binary or hex, else fails.
	## output base is 'base'
	## will return in charset [0-9] if b < 10; else uses [0-F] or [0-?] a la hex.  E.g. base 36 uses [0-Z]
	
	convert.base <- function(x, base, inbase, verbose) {
		extended <- data.frame(extended=LETTERS,decimal=10:35,stringsAsFactors=FALSE)
		digits <- unlist(strsplit(as.character(x), ''))
		lower <- which(digits %in% letters)
		if (length(lower)>0) { digits[lower] <- toupper(digits[lower]) }
		if (is.null(inbase)) {
			if (is.numeric(x)) { 
				inbase <- 10
			} else if (any(LETTERS[1:6] %in% digits)) {
				inbase <- 16
			} else if (any(LETTERS %in% digits)) {
				stop("Supradecimal digits in excess of 'F' detected, but 'inbase' has not been specified!\n")
			} else {
				stop("Number with base < 10 detected, but 'inbase' has not been specified!\n")
			}
		}
		baserange <- 2:36
		if (!(base %in% baserange & inbase %in% baserange)) { stop("'base' and 'inbase' must be between 2-36!\n") }
		extra <- inbase - 10
		
		if (verbose) { IM(digits) }
		if (inbase != 10) {
			if (inbase > 10) {
				for (i in 1:extra) {
					digits[digits==extended[i,1]] <- extended[i,2]
				}
			}
			if (verbose) { IM("Digits:",digits) }
			digits <- as.numeric(digits)
			places <- inbase ^ c((nchar(x)-1):0)
			if (verbose) { IM("Places:",places) }
			values <- digits * places
			if (verbose) { IM("Values:",values) }
			decimal <- sum(values)
			if (verbose) { IM("Decimal:",decimal) }
		} else {
			decimal <- x
			values <- as.numeric(digits)
		}
		
		maxdig <- min(c(base, 9))  # largest numerical digit useable
		if (verbose) { IM("maxdig = ",maxdig) }
		if (base == 10) {
			return(decimal)
		} else {
			newdigits <- rep(NA, floor(log(decimal)/log(base))+1)
			for (i in 1:length(newdigits)) {
				rem <- decimal %% base
				if (decimal < maxdig) { 
					newdigits[i] <- decimal
					if (verbose) { IM(i, decimal, rem, ":", 1, ":", newdigits[i]) }
				} else if (decimal < base) {
					newdigits[i] <- extended[extended[,2]==decimal,1] 
					if (verbose) { IM(i, decimal, rem, ":", 2, ":", newdigits[i]) }
				} else if (rem < maxdig) {
					newdigits[i] <- rem
					if (verbose) { IM(i, decimal, rem, ":", 3, ":", newdigits[i]) }
				} else if (rem < base) {
					newdigits[i] <- extended[extended[,2]==rem,1]
					if (verbose) { IM(i, decimal, rem, ":", 4, ":", newdigits[i]) }
				}
				decimal <- trunc(decimal/base)
			}
			newdigits <- rev(newdigits)
		}
		
		return(paste(newdigits,collapse=''))
	}
	
	if (length(x)>1 & is.null(inbase)) {
		stop("'inbase' must be specified if converting vectors!\n")
	}
	sapply(x, convert.base, base, inbase, verbose)
}


# apa.names$general <- c(apa.names$general, "find.quantile")
# find.quantile <- function(x, distrib, accuracy=.Options$digits, max.iter=100) {
    
    # ## inverse of the quantile() function: find the quantile for a given value 'x' in the distribution 'dist'
	# ## returns -Inf if quantile < 0 or Inf if quantile > 1.
    # ## "accuracy" indicates how many significant decimal places to calculate accuracy to.  May exceed ".Options$digits", but your return value won't.  "NA" deactivates (requires maximal accuracy)
	
	# zap <- ifelse(is.na(accuracy), FALSE, TRUE)
    # recurse <- function(target, distrib, iter, breaks) {
		# iter <- iter + 1
        # for (i in 1:length(breaks)) {
            # q <- quantile(distrib, breaks[i])[[1]]
# #			IM(iter,"i",i,"lb",length(breaks),"b-1",breaks[i-1],"b",breaks[i],"t",target,"q",q)
			# if (zap) q <- round(q, accuracy)
            # if (q == target) {    # direct hit
                # return(breaks[i])
            # } else if (q > target) {  # gone too far; backtrack
				# breaks2 <- seq(breaks[i-1], breaks[i], length=11)   # divide up current quantile window
				# y <- recurse(target, distrib, iter, breaks2)
				# return(y)
            # } else if (iter == max.iter) { 
				# message("Warning: failed to converge in ",max.iter," iterations!")
				# return(breaks[i])
            # } else { 
                # # q < target; continue
            # }
        # }
    # }
	
	# y <- x
	# y[x>max(distrib)] <- Inf
	# y[x<min(distrib)] <- -Inf
	# test <- which(!is.infinite(y))
	# y[test] <- sapply(x[test], function(i){ recurse(i, distrib, 0, seq(0,1,length=11)) })   # divide up full quantile range 
	# return(y)
# }


apa.names$general <- c(apa.names$general, "find.quantile")
find.quantile <- function(x, distrib) {
    
    ## inverse of the quantile() function: find the quantile for a given value 'x' in the distribution 'dist'
	
	ecdf(distrib)(x)
}


apa.names$general <- c(apa.names$general, "quantize")
quantize <- function (input, levels, tiebreak=c("random","up","down"), breaks=FALSE, na.rm=FALSE, indices=FALSE) {
	
	## Converts elements in the 'input' vector to their nearest values from the 'levels' vector.
	## i.e. vector-quantizes signal 'input' per codebook 'levels'.
	## "tiebreak" controls tie breaking; values can be "up", "down", or "random".
	## "breaks=T" treats 'levels' as a vector of bin breaks, and assigns 'input' values to one of these bins.
	##            Return vector contains values from 0:N (where N = length(levels)) indicating bin assignment (0 and N are flanks).
	##            'tiebreak' also acts on values which match bin breakpoints.
	## NOTE: infinites are quantized to the terminal values! (or flank bins)
	## 'indices=TRUE' returns the positions of matching elements in 'levels', not the actual quantized values.
	
	tiebreak <- match.arg(tiebreak)
	
	distfun <- function(x, ulev) {			# finds nearest level for value x
		if (is.na(x)) { 
			return(NA) 
		} else if (x == -Inf) {
			return(ulev[1])
		} else if (x == Inf) {
			return(ulev[length(ulev)])
		}

		dists <- abs(ulev - x)
		d <- which(dists == min(dists))		# cannot exceed 2 results (in case of tie)
		if (length(d) > 1) {			# multiple closest; pick one at random
			d <- switch(tiebreak,
				"random" = sample(d, 1),
				"up" = d[2],
				"down" = d[1]
			)
		}
		if (indices) {
			return(d)
		} else {
			return(ulev[d])
		}
	}
	
	binfun <- function(x, ulev) {			# finds the bin for value x
		if (is.na(x)) { 
			return(NA) 
		} else if (x == -Inf) {
			return(0)
		} else if (x == Inf) {
			return(length(ulev))
		}

		dists <- x - ulev
		if (any(dists == 0)) {			# breakpoint match
			d <- which(dists == 0)
			d <- switch(tiebreak,
				"random" = sample(c(d, d-1), 1),
				"up" = d,
				"down" = d-1
			)
		} else {
			if (all(dists < 0)) {		# left flank value (outside bins)
				d <- 0
			} else if (all(dists > 0)) {	# right flank value (outside bins)
				d <- length(ulev)
			} else {			# we are assuming not all NAs (broken input)
				d <- which(dists == min(dists[dists >= 0]))
			}
		}
		return(d)
	}
	
	dims <- dim(input)
	func <- ternary (breaks, binfun, distfun)
	x <- sapply(input, simplify=TRUE, func, unique(levels))
	y <- ternary (na.rm, x[!is.na(x)], x)
	if (is.null(dims)) {
		return(y)
	} else {
		z <- matrix(y, dims[1], dims[2])
		dimnames(z) <- dimnames(input)
		return(z)
	}
}


apa.names$dev <- c(apa.names$dev, "disgregation")
disgregation <- function(vec, binary=FALSE) {
    
    ## Measures the disgregation of a factor or vector
    ## For a factor of length N there are N-1 unit scores.
    ## For 'binary=F', the true spatial disgregation degree is calculated.  Final score is a percent of maximum possible disgregation. 
    ## ** NOT READY ** For 'binary=T' each score is either perfect or not.  Final score is the percent of perfect unit scores.
    
    if (is.factor(vec)) { vec <- as.numeric(vec) }

    ## maximum possible disgregation value
    N <- length(vec)
    tab <- table(vec)
    Ngrps <- length(tab)
	largest <- which(tab==max(tab))
	Nlargest <- tab[largest]
	Nwith2 <- sum(tab>=2)
	if (Nlargest >= 2) { Nwith2 <- Nwith2 - 1 }
	Nothers <- sum(tab[-largest])
#	IM(names(tab), ":", tab, ":", largest, Nlargest, Nwith2, Nothers)
#    offset <- N - Ngrps
	max.dis <- Nlargest * Nwith2 + Nothers

    scores <- c()
	for (i in 1:max(vec)) { scores <- c(scores, diff(which(vec==i))) }
	(max.dis-sum(scores)) / max.dis

    
}


apa.names$dev <- c(apa.names$dev, "is.invariant")
is.invariant <- function(vec, tolerance=0, as=NULL, of=NULL) {
	
	## Returns T/F for whether a vector is "invariant", within limits
	## "tolerance" is the variance limit: give either a fixed number something else (see below)
	## "as" can be either: 
	##   "pct", meaning interpret tolerance as a percent of the "of" value
	##      1. value on [0,1]
	##      2. REQUIRES USE OF 'of'
	##   "fold", meaning interpret tolerance as the max(vec)/min(vec) fold-change
	##      1. only values > 1 make sense, since if max(vec)/min(vec)==1 then perfect invariance.  Values < 1 are impossible.
	## "of" is used only if "as" = "pct" and can be one of:
	##   "mean":      all values must lie within mean +/- mean*tolerance 
	##   "median":    all values must lie within median +/- median*tolerance
	##   "mean.sd":   all values must lie within mean +/- sd*tolerance
	##   "median.sd": all values must lie within median +/- sd*tolerance
	
	if ( !is.na(tolerance) & !is.numeric(tolerance) ) { stop ("Non-numeric input for 'tolerance' parameter!\n") }
	type <- "numeric"
	if (is.nlv(vec)) { 
		if (mode(vec) %in% c("character","logical")) {
			type <- mode(vec)
		}
	} else {
		stop ("Input must be a non-list vector!\n")
	}
	if (length(as)==0) as <- "fold"
	if (length(of)==0) of <- ""
	
	fail <- 0
	if (type == "character") {
		if (length(unique(vec)) > 1) { fail <- 1 }	# > 1 unique value: not invariant
	} else if (type == "logical") {
		if (!all(vec)) {					# not all TRUE...
			if (!all(!vec)) { fail <- 1 }	# but not all FALSE either: not invariant
		}
	} else if (as=="fold") {
		if ( max(vec)/min(vec)>tolerance ) { fail <- 1 }
	} else if (as=="pct") {
		if (of == "mean") {
			reference <- mean(vec)
			tolerance <- tolerance * reference
		} else if (of == "median") { 
			reference <- median(vec)
			tolerance <- tolerance * reference
		} else if (of == "mean.sd") { 
			reference <- mean(vec)
			tolerance <- tolerance * sd(vec)
		} else if (of == "median.sd") { 
			reference <- median(vec)
			tolerance <- tolerance * sd(vec)
		} else {
			stop ("If 'as' is 'pct', 'of' parameter must be one of 'mean', 'median', 'mean.sd', or 'median.sd'!\n") 
		}
		if (any(abs(vec-reference)>tolerance)) { fail <- 1 }
	}
	
	ternary (fail == 0, return(TRUE), return(FALSE))
}


apa.names$general <- c(apa.names$general, "modes")
modes <- function(vec, dir="pos", inflections=FALSE, infer=TRUE, use.density=TRUE, strict=FALSE, error="plus1", global=FALSE, merge.adjacent=TRUE, plot=FALSE, na.zero=FALSE, na.rm=TRUE, dens.n=512, main=NULL, ...) {
    
    ## Returns positions and heights of all modes (or inflection points) from a vector, given the conditions below:
    ## "dir": what direction to look for modes.  Can be "pos", "neg", or "both".
    ## "inflections=T" will look for inflection points INSTEAD OF minima/maxima. 
    ## "infer": if TRUE, modes will be inferred (e.g. by density).  If FALSE, exact modes (numbers present > 1 times) will be returned.  Automatically TRUE if "inflections=T".
    ## "use.density": control how modes/inflection points are found (not used if "infer=F"):
    ##	    TRUE means, input is any old vector of values; infer modes using density().
    ##	    FALSE means, input is an ordered numerical series representing a function output (e.g. sine, polynomial); infer modes WITHOUT using density().
    ## "strict": TRUE returns nearest values from the input vector; FALSE returns "true" values.
    ##	     If "kernel=F" or "use.density=T" then strict=T automatically, unless adjacent modes are found.
    ##	     "strict=T" also affects the position of the mode if "merge.adjacent=T".
    ## "error": if strict=F, how much measurement error in the estimate of the mode to allow?
    ##	    Values: "plus1" (round to 1 greater than input error), "same" (round to input error), "none" (round to integer), "any" (raw estimate).
    ## "global=T" returns only the extremum (unless > 1 at most extreme height).  Not used if "inflections=T".
    ## "merge.adjacent=T" will merge N adjacent modes (if any adjacencies found; think step functions) by taking their midpoint.
    ## "plot=T" plots the input vector (or its density, if "use.density=T"), along with mode position(s).
    ## "na.zero" converts NAs to zeroes.
    ## "na.rm" operates as usual AND TAKES PRECEDENCE OVER "na.zero".
    ## "main" is for the plot, if plot=TRUE.  It does have defaults chosen internally.
    ## "...": other arguments passed to density(), like 'kernel' or 'adjust'.
    
    
    ## You Can:
    ## Infer modes without density (sine, polynomial)
    ## Infer inflection points without density (ditto)
    ## Infer modes with density (any old vector)
    ## Infer inflection points with density (ditto)
    ## Get "true" modes (inference disallowed), i.e.: which(table(x) > 1)
    
    if (length(vec)<3) stop("Cannot process vector with < 3 elements!\n")
    xname <- deparse(substitute(vec))
    match.arg(dir, c("pos", "neg", "both"))
    match.arg(error, c("plus1", "same", "any", "none"))
    if (na.rm) vec <- vec[which(!is.na(vec))]
    if (na.zero) vec[which(is.na(vec))] <- 0
    
    strict.w <- table(vec)
    strict.y.vals <- as.vector(strict.w)
    strict.x.vals <- as.numeric(names(strict.w))
    
    if (inflections) {
        if (global) {
            IM("'global' and 'inflections' cannot both be TRUE.  Setting 'global' to FALSE.") 
            global <- FALSE
        }
        if (!infer) {
            IM("Use of 'inflections' requires inference.  Setting 'infer' to TRUE.") 
            infer <- TRUE
        }
    }
    
    if (infer) {
        if (use.density) {
            dens.args <- list(...)
            dens.args$x <- vec
            dens.args$n <- dens.n
            dens <- do.call(density, dens.args)
            y.vals <- zapsmall(dens$y)
            x.vals <- dens$x
        } else {
            x.vals <- 1:length(vec)
            y.vals <- vec
        }
    } else {
        kernel <- NULL
        w <- table(vec)
        y.vals <- as.vector(w)
        x.vals <- as.numeric(names(w))
    }
    
    results <- list(pos=c(), neg=c())
    
    export <- function(pos) {	# get { x.vals, y.vals, strict } from parent namespace
        if (length(pos) > 1) {
            ternary (merge.adjacent, pos1 <- (pos[1]+pos[length(pos)])/2, pos1 <- pos)	# if interp required, take mean position of run
        } else {
            pos1 <- pos
        }
        if (strict) {
            pos2 <- quantize(x.vals[pos1], strict.x.vals)
            return(list( matrix(c(pos2, strict.y.vals[which(strict.x.vals==pos2)]), 1, 2, F, list(c(),c("Mode","Height"))) ))
        } else {
            return(list( matrix(c(x.vals[pos1], y.vals[pos1]), 1, 2, F, list(c(),c("Mode","Height"))) ))
        }
    }
    
    signswitch <- function(signs) {
        temp <- list(pos=c(), neg=c())
        last_sign <- 0
        skip <- c()
        for (i in 2:length(signs)-1) {
            if (i %in% skip) next				# this base is part of an already-analyzed mode run
            if (falsify(signs[i] == 0)) {		# zero slope (extended max or min)
                j <- chase(i, signs, 0)
                skip <- c(skip, i:j)			# handling the run here -- do not re-analyze further bases in this mode run
                if (last_sign == 1) {			# extended maximum
                    temp$pos <- c(temp$pos, export(pos))
                } else if (last_sign == -1) {		# extended minimum
                    temp$neg <- c(temp$neg, export(pos))
                }
            } else {
                last_sign <- signs[i]
                pos <- i + 1
                if (falsify(signs[i] == 1) & falsify(signs[(i+1)] == -1)) {		# sign switch (maximum)
                    temp$pos <- c(temp$pos, export(pos))
                } else if (falsify(signs[i] == -1) & falsify(signs[(i+1)] == 1)) {	# sign switch (minimum)
                    temp$neg <- c(temp$neg, export(pos))
                }
            }
        }
        if (length(temp$pos)>0) {
            temp$pos <- do.call(rbind, temp$pos)
        } else {
            temp$pos <- c()
        }
        if (length(temp$neg)>0) {
            temp$neg <- do.call(rbind, temp$neg)
        } else {
            temp$neg <- c()
        }
        return(temp)
    }
    
    if (infer) {
        if (global) {
            if (dir == "pos") {
                pos <- which(y.vals == max(y.vals))
                results$pos <- matrix(export(pos)[[1]], 1, 2, F, list(c(),c("Mode","Height")))
            }
            if (dir == "neg") {
                pos <- which(y.vals == min(y.vals))
                results$neg <- matrix(export(pos)[[1]], 1, 2, F, list(c(),c("Mode","Height")))
            }
        } else if (inflections) {	# get inflection points
            temp <- signswitch(sign(diff(diff(y.vals))))
            results$pos <- temp$neg
            results$neg <- temp$pos
        } else {			# get minima/maxima
            results <- signswitch(sign(diff(y.vals)))
        }
    } else {
        hi.y.vals <- which(y.vals > 1)
        if (length(hi.y.vals) == 0) {
            IM("No modes!\n")
            return(results)
        } else {
            ternary ( global, pos <- which(y.vals == max(y.vals)), pos <- hi.y.vals )
            results$pos <- export(pos)[[1]]
        }
    }
    
    if (!strict) {
        eov <- err.ord(vec)
        eoe <- err.ord(unlist(results))
        decs <- switch(error, "plus1" = eov[2]+1, "same" = eov[2], "any" = eoe[2], "none" = 0)
        if (!is.null(results$pos)) {
            results$pos[,1] <- round(results$pos[,1], decs)
        }
        if (!is.null(results$neg)) {
            results$neg[,1] <- round(results$neg[,1], decs)
        }
    }
    
    if (plot) {
        if (is.null(main)) {
            main <- ifelse(inflections, "Inflection Points", "Maxima and Minima")
        }
        ymin <- ifelse (use.density, 0, min(real(y.vals)))
        hist(x.vals, col=0, bord=0, freq=FALSE, ylim=c(ymin, max(y.vals)), xlab=xname, main=main)
        lines(x.vals, y.vals)
        if (length(results$pos) > 0) abline(v=results$pos[,1], col=2)
        if (length(results$neg) > 0) abline(v=results$neg[,1], col=4)
    }
    
    return(lapply(results,as.data.frame))
}


apa.names$general <- c(apa.names$general, "saddlepoint")
saddlepoint <- function(vec, plot=FALSE) {
    
    ## An add-on to modes() above, looking for A SINGLE "optimal" saddle-point.
    ## Assumes a generally bimodal distribution...
    ## General strategy: find two highest "separate" modes, then find lowest antimode between them.
    ## What makes positive modes "separate"?  The density() 'adjust' param, see below.
    
    ## 1. if only 1 mode, fail
    ## 2. if exactly 2 modes, find lowest anti; done
    ## 3. if > 2 modes, winnow:
    ##    A. restrict to modes > median
    
    adj <- 1
    m <- modes(vec)  # initial test
    if (nrow(m$pos)==1) {
        stop("Distribution is unimodal: no obvious saddlepoints here!\n")
    } else if (nrow(m$pos)==2) {
        ## ok, continue
    } else {
        ## too many modes; ratchet up density() 'adjust' param until only two remain
        message("Smoothing distribution down to two modes, please stand by...")
        m.adj <- c()
        while (length(m.adj)==0) {
            adj <- adj+0.1
            ##if (round(adj,1)==adj) message(paste(" Adjust =",adj))
            m.adj <- modes(vec, adjust=adj)
            if (nrow(m.adj$pos)!=2) m.adj <- c()  ## only retain value if exactly two modes
        }
        ## final modes will not be the same as initial modes; find nearest initial modes to final modes
        p1 <- nearest(m.adj$pos$Mode[1], m$pos$Mode, index=TRUE)
        p2 <- nearest(m.adj$pos$Mode[2], m$pos$Mode, index=TRUE)
        n1 <- nearest(m.adj$neg$Mode, m$neg$Mode, index=TRUE)
        m$pos <- m$pos[c(p1,p2),]  # keep only nearest initial modes
        m$neg <- m$neg[n1,]        # keep only nearest initial antimode
    }
    
    if (plot) {
        mcols <- ifelse(adj>1,3,2)
        par(mfrow=c(1,mcols), las=1)
        ignore <- modes(vec, plot=TRUE, main="Initial Modes")
        if (adj>1) ignore <- modes(vec, adjust=adj, plot=TRUE, main=paste0("Smoothed Modes, adjust=",adj))
        dhist(vec, main="Saddle Point (Blue)", legend=NA)
        abline(v=c(m$pos$Mode,m$neg$Mode), lty=c(3,3,1), col=c(2,2,4))
    }
    m$neg$Mode
}
##Saddlepoint testing...
##x=c(rnorm(1E4,1,2),rnorm(1E4,10,2),runif(1E3,0,4),runif(1E3,6,9),rbeta(1E3,1,2,0)); dhist(x)   # cleanly bimodal
##x=c(x,rnorm(2E3,-2,0.5),rnorm(2E3,14,0.7)); dhist(x)                                           # uncleanly bimodal
##x=c(x, rnorm(1E3,-1,0.3),rnorm(5E3,4,0.5),rnorm(5E2,8,0.4),rnorm(1E3,14,0.5),rep(c(-8,-6),each=50)); dhist(x)  # uglimodal  
##modes(x,plot=TRUE)
##saddlepoint(x,plot=TRUE)


apa.names$general <- c(apa.names$general, "is.monotonic")
is.monotonic <- function(vec, decreasing=FALSE, tolerance=NA, t.pct=NA, gain=NA, g.pct=NA) {
	
	## Returns T/F for whether a vector is monotonically increasing
	## "decreasing=T" tests for monotonically decreasing
	## "gain" discards 'weakly' changing vectors, judging if the absolute change from first to last element is not >= gain
	## "g.pct" causes gain values to be interpreted as a percentages.
	## g.pct="mean" causes gain value to be a percentage of the vector mean
	##  thus if vector mean = 50, gain=0.1, g.pct="mean" then if the vector does not change by at least 5 over its length, it fails.
	## g.pct="median" behaves similarly; g.pct=NA disables the parameter.
	## "tolerance" allows slopes to break the requested trend (increasing, decreasing) within a tolerance limit and still pass.
	##   "tolerance" is effectively the noise threshold, so all slopes within [-tolerance,+tolerance] will be tolerated.
	##   "tolerance=NA" deactivates, while "tolerance=0" allows invariant slopes to pass.  However, a vector will still fail if all slopes == 0.
	## "t.pct" is identical to "g.pct" but applies to "tolerance", not "gain".
	
## OLD TOLERANCE DEF
##	## "tolerance" behaves like "gain" and allows for flexibility in calling a increase.
##	##   if the vector actually decreases between points n and n+1, the "tolerance" parameter can rescue it if the absolute decrease is less than "tolerance".
##	##   "tolerance=NA" deactivates, while "tolerance=0" sets tolerance to the minimum passing slope: 
##	##   thus if decreasing=F and minimum increasing slope = 0.1, then decreasing slopes >= -0.1 will be tolerated.
##	##   this because the minimum passing slope will be interpreset as the noise threshold, so all slopes within [-noise,+noise] will be tolerated
	
	if (any(is.na(vec))|length(vec)<2) return(NA)  # can't evaluate vectors with NAs, or less than two elements
	
	## Survived to reach the gain filter, if any
	if (!is.na(gain)) {
		if (!is.na(g.pct)) g.pct <- get(g.pct)  # convert to function
		min.gain <- abs(gain) * ifelse(is.function(g.pct), get(g.pct)(vec), 1)  # convert relative gain to minimum required gain for this particular vector
		max.gain <- abs(diff(range(vec)))  # actual gain for this vector (max gain between any two points)
		if (max.gain < min.gain) return(FALSE)  # failed gain filter, regardless of direction
	}
	
	## Survived to reach the tolerance filter, if any
	slopes <- diff(vec)
	if (is.na(tolerance)|is.infinite(tolerance)|tolerance==0) {
		if (decreasing) {
			tol.pass <- ifelse(falsify(tolerance==0), all(slopes<=0)&any(slopes<0), all(slopes<0))
		} else {
			tol.pass <- ifelse(falsify(tolerance==0), all(slopes>=0)&any(slopes>0), all(slopes>0))
		}
	} else {
		if (!is.na(t.pct)) t.pct <- get(t.pct)  # convert to function
		tolerance <- abs(tolerance) * ifelse(is.function(t.pct), get(t.pct)(vec), 1)  # convert relative tolerance to absolute tolerance for this particular vector
		tol.pass <- ifelse(decreasing, max(slopes)<=tolerance, min(slopes)>=tolerance)
## OLD TOLERANCE DEFINITION
##		if (tolerance == 0) {
##			tolerance <- ifelse(decreasing, max(slopes[slopes<0]),  min(slopes[slopes>0]))  # t.pct ignored; get largest negative or smallest positive slope
##		} else {
##			tolerance <- abs(tolerance) * ifelse(is.function(t.pct), get(t.pct)(vec), 1)  # convert relative tolerance to absolute tolerance for this particular vector
##		}
	}
	return(tol.pass)
}


apa.names$general <- c(apa.names$general, "conn.mat.subgraphs")
conn.mat.subgraphs <- function(obj, threshold=1, remove="lt") {
	
	## Extracts all distinct subgraphs from a connectivity matrix.
    ## A wrapper for pairs2subgraphs().
    ## "threshold" can be used to remove entries prior to subgraph identification, provided a "remove" criterion.
    ## "remove" sets the removal criterion relative to "threshold"; these are same as Perl's string equalities:
    ##  "ge" = greater than or equal to (threshold),
    ##  "gt" = greater than,
    ##  "le" = less than or equal to,
    ##  "lt" = less than,
    ##  "eq" = equal to.
    
	if (is.matrix(obj)) {
        # ok
	} else if (is.data.frame(obj)) {
        obj <- as.matrix(obj)
	} else if (is(obj, "dist")) {
        obj <- as.matrix(obj)
    } else {
        stop ("Object must be a matrix or dataframe!\n")
    }
    if (!is.numeric(threshold) & !is.infinite(threshold)) { stop("'threshold' must be a number (infinity inclusive)\n") }
    match.arg(remove, c("gt","ge","lt","le","eq"))
    if (length(obj)<=1) { IM("Object has no data!\n"); return() }

    switch(remove,
        gt={ obj[obj>threshold] <- NA },
        ge={ obj[obj>=threshold] <- NA },
        lt={ obj[obj<threshold] <- NA },
        le={ obj[obj<=threshold] <- NA },
        eq={ obj[obj==threshold] <- NA }
    )
    
    nr <- nrow(obj)
    nc <- ncol(obj)
    pairs <- vector("list", length=length(obj))
    n <- 0
    for (i in 1:nr) {
        for (j in 1:nc) {
            n <- n + 1
            if (i < j) {   # only need to process one triangle
                if (!is.na(obj[i,j])) {
                    pairs[[n]] <- c(i,j)
                }
            }
        }
    }
    pairs <- pairs[listLengths(pairs)>0]
    if (length(pairs) > 0) {
        return(pairs2subgraphs(pairs))
    } else {
        IM("No connected pairs at given thresholds!\n"); return()
    }
}


apa.names$general <- c(apa.names$general, "pairs2subgraphs")
pairs2subgraphs <- function(obj) {
	
	## Extracts all distinct subgraphs from a collection of paired elements (either as a list or a matrix)
	
	if (is.list(obj)) {
		x <- listLengths(obj) != 2
		if (any(x)) { stop("Each list element must be a vector of length 2!\n") }
	} else if (is.matrix(obj)) {
		if (ncol(obj) != 2) { stop("Matrix must have two columns!\n") }
		y <- apply(obj, 1, FUN=function(x){list(x[1],x[2])})
		obj <- lapply(y, unlist)	# replace matrix with list
	} else {
		stop("Object must be a 2-column matrix or a list of length-2 vectors!\n")
	}
	
	all <- sort(unique(unlist(obj)))
	N <- length(all)
	connect <- vector("list", length=N)
	names(connect) <- all
	
	for (i in 1:length(obj)) {
		xo <- match(obj[[i]], all)
		connect[[xo[1]]] <- c(connect[[xo[1]]], obj[[i]][2])
		connect[[xo[2]]] <- c(connect[[xo[2]]], obj[[i]][1])
	}
	
	for (i in 1:N) { connect[[i]] <- unique(c(all[i],connect[[i]])) }
	
	cdata <- list(i=all[1], root=all[1], already=c(), subgraphs=vector("list", length=N))	# i=pending element, root=originating element.
	conn.path <- function(cdata) {		
		R <- which(all == cdata$root)						# find index for root element
		I <- which(all == cdata$i)						# find index for pending element
#		cat("Root:",R," I:",I,"\nA:",cdata$already,"\n"); flush.console()	### reporter
		if (!I %in% cdata$already) {						# ignore if already analyzed
			cdata$already <- c(cdata$already, I)				# add this row to the already-analyzed set
			cdata$subgraphs[[R]] <- c(cdata$subgraphs[[R]], connect[[I]])		# add connectivity to pool for the originating row
			for (j in connect[[I]]) {					# for each connected sub-element: 
				J <- which(all == j)					# find index for upcoming element
				if (J != I) {						#   don't repeat the pending step
					if (!J %in% cdata$already) { 			#   don't repeat a previous analysis
#						cat("Root:",R," I:",I," J:",J,"\nA:",cdata$already,"\nP:",cdata$subgraphs[[R]],"\n\n"); flush.console()	### reporter
						cdata$i <- j				#   j becomes new pending element
						cdata <- conn.path(conn.path(cdata)) 	#   repeat process with the sub-element as a new row (recursively)
					}
				}
			}
			return(cdata)
		} else {
			return(cdata)
		}
	}
	
	for (i in 1:N) {
		cdata$i <- cdata$root <- all[i]
		cdata <- conn.path(cdata)
#		cat("\nFinished:",i,all[i],"\n\n"); flush.console()	### reporter
	}
	
	subgraphs <- vector("list", length=length(!is.null(cdata$subgraphs)))
	p <- 0
	for (i in 1:N) {
		if (!is.null(cdata$subgraphs[[i]])) { 
			p <- p + 1
			subgraphs[[p]] <- sort(unique(cdata$subgraphs[[i]])) 
		}
	}
	subgraphs <- subgraphs[order(listLengths(subgraphs),decreasing=TRUE)]  # largest subgraphs first
	
	return(subgraphs)
}


apa.names$general <- c(apa.names$general, "sets2subgraphs")
sets2subgraphs <- function(x) {
    
    ## Extracts all distinct subgraphs from a collection ('x', a list) of sets (elements of 'x'), where each set should be 2+ elements long
    ## Any two sets with at least one element in common will be merged
    ## Output is a list of final merged sets
    
    ## First pass: merge elements into initial subgraphs
    x <- x[listLengths(x)>0]  # drop empty sets
    ##IM(length(x))
    subgraphs <- x[1]  # initialize with first set
    x <- x[-1]
    while (length(x)>0) {
        for (i in 1:length(subgraphs)) {   # SUBGRAPHS FIRST
            lx <- length(x)
            keep <- rep(TRUE, lx)
            for (j in 1:lx) {   # REMAINING SETS SECOND
                if (any(x[[j]] %in% subgraphs[[i]])) {
                    subgraphs[[i]] <- unique(c(subgraphs[[i]], x[[j]]))
                    keep[j] <- FALSE
                }
            }
            x <- x[keep]  # remaining unmerged
        }
        subgraphs <- c(subgraphs, x[1])  # after each merging pass, start new subgraph with next unmerged set
    }
    ## Second pass: merge any overlapping subgraphs
    subgraphs <- lapply(subgraphs[rev(order(sapply(subgraphs,length)))], sort)
    S <- length(subgraphs)
    for (i in 1:S) names(subgraphs[[i]]) <- NULL
    S1 <- 0  # init
    ##IM(S); print(table(listLengths(subgraphs)))
    while (S!=S1) {
        S <- length(subgraphs)  # BEFORE
        for (i in 1:(S-1)) {
            if (length(subgraphs[[i]])==0) next
            for (j in (i+1):S) {
                if (length(subgraphs[[j]])==0) next
                li <- length(intersect(subgraphs[[i]],subgraphs[[j]]))
                ##IM(i,j,length(subgraphs[[i]]),length(subgraphs[[j]]),li)
                if (li>0) {
                    subgraphs[[i]] <- unique(c(subgraphs[[i]],subgraphs[[j]]))
                    subgraphs[j] <- list(c())
                }
            }
        }
        subgraphs <- subgraphs[listLengths(subgraphs)>0]
        S1 <- length(subgraphs)  # AFTER
        ##IM(S1); if (S1>0) print(table(listLengths(subgraphs)))
    }
    lapply(subgraphs[rev(order(sapply(subgraphs,length)))], sort)
}


apa.names$general <- c(apa.names$general, "get.killcurve.cdf")
get.killcurve.cdf <- function(fg.p, bg.p, N=1000) {
	
	## for use in 'motif.killcurve', 'peak.killcurve'
	## 'N' specifies the sampling for the p-value CDF (N bins to break p-value range into)
	
	F <- length(fg.p)
	B <- length(bg.p)
	p.bins <- seq(min(c(fg.p,bg.p)), max(c(fg.p,bg.p)), length=N)
	p.cdf <- matrix(0, 3, N, F, list(qw(P.VALUE,FG.RATE,BG.RATE),1:N))
	for (i in 1:N) p.cdf[,i] <- c( p.bins[i], sum(fg.p >= p.bins[i]), sum(bg.p >= p.bins[i]) )
	axseq <- seq(p.bins[1], p.bins[N], length=10)
	list(cdf=p.cdf, axis.lab=format(axseq,digits=3), axis.seq=rescale(axseq,to=c(1,N)))
}


