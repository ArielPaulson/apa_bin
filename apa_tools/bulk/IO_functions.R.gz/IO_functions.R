

apa.names$general <- c(apa.names$general, "files.access")
files.access <- function(vec, bin=FALSE) {
	
	## Takes a vector of files and returns tabulated file.access() results for all 4 modes
	## "bin=T" converts 0 => 1 and -1 => 0
	
	mat <- matrix(data=NA, nrow=length(vec), ncol=4)
	rownames(mat) <- vec
	colnames(mat) <- c("Exist","Execute","Write","Read")
	j <- 0
	for (i in c(0,1,2,4)) { j <- j+1; mat[,j] <- file.access(vec, i) }
	if (bin == TRUE) {
		mat[mat == 0] <- 1
		mat[mat == -1] <- 0
	}
	print(return(mat))
}


apa.names$hacks <- c(apa.names$hacks, "write.vector")
write.vector <- function(x, file, sep="\t", quote=FALSE, names=FALSE, ...) {
	
	## wrapper for write.table() with defaults set for vector (not table) writing
	
	write.table(x, file=file, sep=sep, quote=quote, row.names=ternary(names, names(x), FALSE), col.names=FALSE, ...)
}


apa.names$hacks <- c(apa.names$hacks, "write.table2")
write.table2 <- function (x, file="", quote=FALSE, sep="\t", row.head=NULL, col.names=TRUE, row.names=FALSE, ...) {
    
    ## Wrapper that tabs colnames over properly if rownames are being printed,
    ##  and prints a colname for the rownames column (given by 'row.head')
    
    write.table.args <- c(list(file=file, quote=quote, sep=sep), list(...))

    if (length(row.names)==0) row.names <- rownames(x)
    if (length(col.names)==0) col.names <- colnames(x)
    
    if (identical(row.names[1],TRUE)) {
        use.row.names <- TRUE
        row.names <- rownames(x)
    } else if (identical(row.names[1],FALSE)) {
        use.row.names <- ifelse(length(row.head)>0, TRUE, FALSE)
        if (use.row.names) row.names <- rownames(x)
    } else if (length(row.names)==0) {
        use.row.names <- FALSE
    } else if (length(row.names)!=nrow(x)) {
        stop("Length of row.names is not equal to rows of 'x'!")
    } else {
        use.row.names <- TRUE
        if (length(row.names)==0) row.names <- rownames(x)
    }
    
    if (identical(col.names[1],FALSE) | length(col.names)==0) {
        use.col.names <- FALSE
    } else if (identical(col.names[1],TRUE)) {
        use.col.names <- TRUE
        col.names <- colnames(x)
    } else if (length(col.names)!=ncol(x)) {
        stop("Length of col.names is not equal to cols of 'x'!")
    } else {
        use.col.names <- TRUE
        if (length(col.names)==0) col.names <- colnames(x)
    }
    
    if (use.row.names) {
        write.table.args <- c(write.table.args, list(row.names=row.names))
        if (length(row.head)==0) row.head <- ""
    } else {
        write.table.args <- c(write.table.args, row.names=FALSE)
    }
    
    if (use.col.names) {
        if (length(row.head)>0) {
            if (quote) {
                col.names[1] <- paste("\"", row.head, "\"", sep, col.names[1], sep="")
            } else {
                col.names[1] <- paste(row.head, col.names[1], sep=sep) 
            }
        }
        write.table.args <- c(write.table.args, list(col.names=col.names))
    } else {
        write.table.args <- c(write.table.args, col.names=FALSE)
    }
    
    do.call(write.table, c(list(x=x), write.table.args))
}


apa.names$general <- c(apa.names$general, "read.bed")
read.bed <- function(x, bed6=FALSE) {
    
    ## reads BED format, and can force bed6
    
    bed <- read.delim(x, as.is=TRUE, header=FALSE)
    NC <- ncol(bed)
    if (NC==1) {
        stop("Supplied BED data has only one column!  Cannot proceed.\n")
    } else if (NC==2) {
        message("Supplied BED data has less than the minimum of 3 columns!  Assuming one-based single-bp data.\n")
        bed <- bed[,c(1,2,2)]
        bed[,2] <- bed[,2]-1
    }
    if (bed6) {
        if (NC==3) {
            bed <- cbind(bed,1:nrow(bed),1,"+")
        } else if (NC==4) {
            bed <- cbind(bed,1,"+")
        } else if (NC==5) {
            bed <- cbind(bed,"+")
        } else if (NC==6) {
            ## nothing to do
        } else if (NC>6) {
            message(paste("Supplied BED data has",NC,"columns: truncating to 6."))
            bed <- bed[,1:6]
        }
        colnames(bed) <- qw(Chrom,Start,End,Name,Score,Strand)
    }
    bed
}


apa.names$general <- c(apa.names$general, "write.bed")
write.bed <- function(x, file, score1=FALSE, bed6=FALSE, one.based=FALSE) {
	
    ## ensures that start, end positions are written as integers, not "6e+05" stuff
    ## also can auto-fill columns 5 & 6 as needed, and correct 1-based starts
    
    NC <- ncol(x)
    if (NC<3) stop("Supplied data has less than the minimum of 3 columns: cannot proceed!\n")
    if (one.based) x[,2] <- x[,2]-1
    if (score1 & NC>=5) x[,5] <- 1
    if (bed6) {
        if (NC==3) {
            x <- cbind(x,1:nrow(x),1,"+")
        } else if (NC==4) {
            x <- cbind(x,1,"+")
        } else if (NC==5) {
            x <- cbind(x,"+")
        } else if (NC==6) {
            ## nothing to do
        } else if (NC>6) {
            message(paste("Supplied data has",NC,"columns: truncating to 6"))
            x <- x[,1:6]
        }
    }
    
    y <- x
    for (i in c(2,3,5)) y[,i] <- stabilize.integer(y[,i])  # becomes character
    write.table(y, file=file, sep="\t", quote=FALSE, row.names=FALSE, col.names=FALSE)
    
    invisible(x)  # return version with numeric coords, not char
}


apa.names$general <- c(apa.names$general, "write.heatmap.bed")
write.heatmap.bed <- function(x, file, geno, window=10000, bad.win=c("drop","crop"), summits=NULL, no.mito=FALSE, debug=FALSE, one.based=FALSE) {
    
    ## Takes an input bed 'x' and modifies it to be used with coverageView()
    ## Basically, converts coords to windows of width 'window', centered at peak midpoint, and writes as new bed.
    ## x: bed data.frame
    ## file: output filename
    ## geno: /n/data1/genomes/indexes genome name
    ## window: window bp; will be centered on peak midpoint
    ## bad.win: if window start < 0, or end > chrlen, do what?  "drop"=remove region, "crop"=cut back to fit on chrom
    ## summits: optional vector of 0-BASED GENOMIC POSITIONS for peak summits, SAME ORDER AS 'x'.  Will center windows on summits, instead of peak midpoints.
    ## no.mito: exclude known mitochondrial chromosomes?
    ## debug: return intermediate data columns?  (for debugging 'bad.win' coords)
    ## one.based: input coords are 1-based?
    
    bad.win <- match.arg(bad.win)
    if (window %% 2 == 1) {
        message(paste0("Window size '",window,"' is not even!  Reducing to '",window-1,"' bp"))
        window <- window - 1
    }
    chrsz <- paste0("/n/data1/genomes/indexes/",geno,"/",geno,".chrom.sizes")
    if (file.exists(chrsz)) {
        chrsz <- read.delim(chrsz,as.is=TRUE,header=FALSE)
        ectopic <- sort(setdiff(x[,1],chrsz[,1]))
        if (length(ectopic)>0) stop(paste0("Bed data contains chromosomes which are not from '",geno,"'!  ",paste(ectopic,collapse=", "),"\n"))
        if (no.mito) {
            chrdat <- paste0("/n/data1/genomes/indexes/",geno,"/",geno,".chrom_data.txt")
            if (file.exists(chrdat)) {
                chrdat <- read.delim(chrdat,as.is=TRUE)
                mito <- chrdat[chrdat$Content=="mitochondrion",1]
                message("Excluding mitochondrial chroms: ",paste(mito,collapse=" "))
            } else {
                stop(paste0("Genome '",geno,"' has not chrom_data.txt file!  Cannot determine mitochondrial chroms."))
            }
        } else {
            mito <- c()
        }
    } else {
        stop(paste0("Genome name '",geno,"' does not exist in /n/data1/genomes/indexes!"))
    }
    if (length(x)==1) {
        if (file.exists(x)) {
            x <- read.bed(x)
        } else {
            stop(paste0("Argument x '",x,"' looks like a filename but no such file exists!"))
        }
    }
    y <- mat.split(x, x[,1])  # split on chrom
    y <- do.call(rbind, y[real(match(chrsz[,1],names(y)))])  # 'y' is now 'x', with chroms in 'chrsz' order
    if (ncol(y)<4) y <- data.frame(y,paste0("Coord",1:nrow(y)))
    if (ncol(y)<5) y <- data.frame(y,1)
    if (ncol(y)<6) y <- data.frame(y,"+")
    colnames(y) <- c("chrom","start","end","name","score","strand")
    y <- cbind(y, OK=TRUE, chrlen=chrsz[match(y[,1],chrsz[,1]),2], overshoot=0, orig.start=y[,2], orig.end=y[,3])  # extended intermediate dataset BEFORE altering coords: must retain originals
    rownames(y) <- NULL
    if (one.based) y[,2] <- y[,2]-1
    if (length(summits)==0) summits <- trunc(rowMeans(y[,2:3]))  # substitute peak midpoints
    y[,2:3] <- cbind(summits-window/2, summits+window/2)
    y$overshoot[which(y[,2]<0)] <- y[which(y[,2]<0),2]                               ## It is expected that a single coord will either
    y$overshoot[which(y[,3]>y$chrlen)] <- c(y[,3]-y$chrlen)[which(y[,3]>y$chrlen)]   ##   have start<0 OR end>chrlen, but not both.
    y$OK <- y$overshoot==0
    is.mito <- y[,1] %in% mito
    y$OK[is.mito] <- FALSE
    msg <- paste(sum(y$OK),"ok,",sum(!y$OK),"not")
    
    if (any(!y$OK)) {
        worst.n <- min(y$overshoot)
        worst.p <- max(y$overshoot)
        worst.n.msg <- ifelse( worst.n==0, "", paste0(" (worst=",worst.n," under)") )
        worst.p.msg <- ifelse( worst.p==0, "", paste0(" (worst=",worst.p," over)") )
        mito.msg <- ifelse( no.mito & any(is.mito), paste0(", ",sum(is.mito)," mitochondrial"), "" )
        msg <- paste0(msg,": ",sum(y[,2]<0)," < 0",worst.n.msg,", ",sum(y[,3]>y$chrlen)," > max",worst.p.msg,mito.msg)
        message(msg)
        if (bad.win=="drop") {
            write.bed(y[y$OK,1:6], file)
        } else if (bad.win=="crop") {
            y2 <- y[,1:6]
            y2[y[,2]<0,2] <- 0
            y2[y[,3]>y$chrlen,3] <- y$chrlen[y[,3]>y$chrlen]
            write.bed(y2, file)
        }
    } else {
        message(msg)
        write.bed(y[,1:6], file)
    }
    if (debug) {
        invisible(y)
    } else {
        invisible(y[,1:7])  # only retaining extra "OK" column
    }
}


apa.names$general <- c(apa.names$general, "sort.bed")
sort.bed <- function(x, method=c("lexicographic","UCSC","Ensembl")) {

    method <- match.arg(method)
    if (method=="lexicographic") {
        to.ord <- list(x[,1], x[,2], x[,3])
    } else if (method=="UCSC") {
        A <- grep("^chr[0-9]",x[,1])   # numeric chrs
        As <- A[grep("_",x[A,1])]      # numeric chrs, with suffixes
        A <- setdiff(A,As)
        B <- grep("^chr[^0-9U]",x[,1]) # character chrs, not "Un"
        Bs <- B[grep("_",x[B,1])]      # character chrs, not "Un", with suffixes
        B <- setdiff(B,Bs)
        C <- grep("^chrU",x[,1])       # chrU[n]-type "chrs"
        D <- grep("^chr",x[,1],invert=TRUE) # non-chrs
        ABAsAs2BsCD <- rep(c("A","As","B","Bs","C","D"),times=c(length(A),length(B),length(As),length(Bs),length(C),length(D)))
        chrA <- chrB <- chrC <- chrD <- chrAs <- chrAs2 <- chrBs <- rep(NA,nrow(x))
        chrA[A] <- as.numeric(sub("^chr","",x[A,1]))
        chrB[B] <- x[B,1]
        chrC[C] <- x[C,1]
        chrD[D] <- x[D,1]
        chrAs[As] <- as.numeric(sub("_.*$","",sub("^chr","",x[As,1])))  # numeric portion
        chrAs2[As] <- sub("^chr[0-9]+","",x[As,1])  # non-numeric suffixes
        chrBs[Bs] <- x[Bs,1]
        to.ord <- list(ABAsAs2BsCD, chrA, chrB, chrAs, chrAs2, chrBs, chrC, chrD, x[,2], x[,3])
    } else if (method=="Ensembl") {
        A <- grep("^[0-9]+$",x[,1])           # all-numeric chr names
        B <- grep("[0-9]",x[,1],invert=TRUE)  # all-character chr names
        C <- setdiff(1:nrow(x), c(A,B))       # mixed chr names
        ABC <- rep(c("A","B","C"),times=c(length(A),length(B),length(C)))
        chrA <- chrB <- chrC <- rep(NA,nrow(x))
        chrA[A] <- as.numeric(x[A,1])
        chrB[B] <- x[B,1]
        chrC[B] <- x[C,1]
        to.ord <- list(ABC, chrA, chrB, chrC, x[,2], x[,3])
    }
    if (ncol(x)>=6) to.ord <- c(to.ord, list(x[,6]))
    to.ord <- c(to.ord, na.last=TRUE, decreasing=FALSE)
    x[do.call(order,to.ord),]
}


apa.names$general <- c(apa.names$general, "read.xlsx.simple")
read.xlsx.simple <- function (file, header=TRUE, silent=TRUE) {
    
    require("XLConnect")
    conn <- loadWorkbook(file)
    xlsx <- new.list(getSheets(conn))
    for (i in 1:length(xlsx)) {
        x <- try(readWorksheet(conn, i, startCol=1, header=header), silent=silent)
        if (grepl("^Error : IllegalArgumentException (Java):",x[1]) | grepl("does not contain any data!\n$",x[1])) { 
                                        # blank sheet -- ignore
        } else {
            xlsx[[i]] <- x
        }
    }
    xlsx
}


apa.names$hacks <- c(apa.names$hacks, "WriteXLS2")
WriteXLS2 <- function (x, ExcelFileName = "R.xls", SheetNames = NULL, perl = "perl", 
                       verbose = FALSE, Encoding = c("UTF-8", "latin1"), row.names = FALSE, 
                       AdjWidth = FALSE, AutoFilter = FALSE, BoldHeaderRow = FALSE, 
                       FreezeRow = 0, FreezeCol = 0, envir = parent.frame(), nolim=FALSE,
                       CopyFormat = FALSE) {   # last arg is hacked in
    
    ## WriteXLS (requires package of same name be loaded)
    ## hacked to take a list of *actual dataframes*, not a (pathetic) length-1 list of dataframe NAMES
    ## also added: 'nolim' which prevents old-excel row/col number checks (i.e. allows writes of tables exceeding 65535 x 256)
    ## also added ability to write as xlsx
    
    ## ## BEGIN HACK 1
    require("WriteXLS")
    ExcelFileTmp <- paste0(tempdir(),"/out.xls")
    if (is.data.frame(x) | is.matrix(x)) {
        DF.LIST <- list(x)
        names(DF.LIST) <- deparse(substitute(x))
    } else if (is.list(x)) {
        DF.LIST <- x
        if (is.null(names(DF.LIST))) { names(DF.LIST) <- paste("Sheet",1:length(x),sep="") }
        ## ## END HACK 1
    } else if (length(x) == 1) {
        TMP <- get(as.character(x), envir = envir)
        if ((is.list(TMP)) & (!is.data.frame(TMP))) {
            DF.LIST <- TMP
        } else {
            DF.LIST <- list(TMP)
            names(DF.LIST) <- x
        }
    } else {
        DF.LIST <- sapply(as.character(x), function(x) get(x, envir = envir), simplify = FALSE)
        names(DF.LIST) <- x
    }
#    if (!all(sapply(DF.LIST, is.data.frame))) { stop("One or more of the objects named in 'x' is not a data frame or does not exist") }
    if (!nolim) {
        if (!falsify(all(sapply(DF.LIST, function(x) (nrow(x) <= 65535) & (ncol(x) <= 256))))) { stop("One or more of the data frames named in 'x' exceeds 65535 rows or 256 columns") }
    }
    Encoding <- match.arg(Encoding)
    if (!is.null(SheetNames)) {
        if (any(duplicated(SheetNames))) {
            message("At least one entry in 'SheetNames' is duplicated. Excel worksheets must have unique names.")
            return(invisible(FALSE))
        }
        if (length(DF.LIST) != length(SheetNames)) {
            message("The number of 'SheetNames' specified does not equal the number of data frames in 'x'")
            return(invisible(FALSE))
        }
        if (any(nchar(SheetNames) > 31)) {
            message("At least one of 'SheetNames' is > 31 characters, which is the Excel limit")
            return(invisible(FALSE))
        }
        if (any(grep("\\[|\\]|\\*|\\?|:|/|\\\\", SheetNames))) {
            message("Invalid characters found in at least one entry in 'SheetNames'. Invalid characters are: []:*?/\\")
            return(invisible(FALSE))
        }
        names(DF.LIST) <- SheetNames
    } else {
        if (any(duplicated(substr(names(DF.LIST), 1, 31)))) {
            message("At least one data frame name in 'x' is duplicated up to the first 31 characters. Excel worksheets must have unique names.")
            return(invisible(FALSE))
        }
        if (any(grep("\\[|\\]|\\*|\\?|:|/|\\\\", names(DF.LIST)))) {
            message("Invalid characters found in at least one data frame name in 'x'. Invalid characters are: []:*?/\\")
            return(invisible(FALSE))
        }
    }
    Perl.Path <- file.path(path.package("WriteXLS"), "Perl")
    Fn.Path <- file.path(Perl.Path, "WriteXLS.pl")
    Tmp.Dir <- file.path(tempdir(), "WriteXLS")
    clean.up <- function() {
        if (verbose) { cat("Cleaning Up Temporary Files and Directory\n\n") }
        unlink(Tmp.Dir, recursive = TRUE)
    }
    on.exit(clean.up())
    if (file.exists(Tmp.Dir)) {
        if (verbose) { cat("Cleaning Up Temporary Files and Directory From Prior Run\n\n") }
        unlink(Tmp.Dir, recursive = TRUE)
    }
    if (verbose) { cat("Creating Temporary Directory for CSV Files: ", Tmp.Dir, "\n\n") }
    dir.create(Tmp.Dir, recursive = TRUE)
    for (i in seq(along = DF.LIST)) {
        if (verbose) { cat("Creating CSV File: ", i, ".csv", "\n", sep = "") }
        if (row.names) {
            write.table(DF.LIST[[i]], file = paste(Tmp.Dir, "/", 
                                          i, ".csv", sep = ""), sep = ",", quote = TRUE, 
                        na = "", row.names = TRUE, col.names = NA)
        } else {
            write.table(DF.LIST[[i]], file = paste(Tmp.Dir, "/", 
                                          i, ".csv", sep = ""), sep = ",", quote = TRUE, 
                        na = "", row.names = FALSE)
        }
    }
    x <- paste(Tmp.Dir, "/", seq(length(DF.LIST)), ".csv", sep = "")
    write(as.matrix(x), file = paste(Tmp.Dir, "/FileNames.txt", sep = ""))
    if (verbose) { cat("Creating SheetNames.txt\n") }
    namesfile <- paste(Tmp.Dir, "/SheetNames.txt", sep = "")   ##### HACK: trackable sheet names file
    write(as.matrix(names(DF.LIST)), file = namesfile)
    if (verbose) { cat("\n") }
    message("Writing...")
    ## ## BEGIN HACK 2
    if (verbose) print(listLengths(DF.LIST))
    if (verbose) print(x)
    if (verbose) print(namesfile)
    if ( any(listLengths(DF.LIST,nrow)>=65534) | any(listLengths(DF.LIST,ncol)>=255) ) {
        already.xlsx <- TRUE
        ExcelFileTmp <- paste0(ExcelFileTmp,"x")  # ExcelFileTmp is .xlsx this time
        cmd <- paste("/home/apa/local/bin/txt2xlsx",shQuote(ExcelFileTmp),paste(x,collapse=" "),"--csv -n",namesfile)
        if (FreezeRow>0|FreezeCol>0) {
            freeze <- c(0,0)
            if (FreezeRow>0) freeze[1] <- FreezeRow
            if (FreezeCol>0) freeze[2] <- FreezeCol
            freeze <- paste(freeze,collapse=",")
            cmd <- paste(cmd,"-f",freeze)
        }
        if (AdjWidth) cmd <- paste(cmd,"--adjust")
        if (BoldHeaderRow) cmd <- paste(cmd,"--bold-header")
        if (AutoFilter) message("WARNING: AutoFilter is TRUE, but sheets too large to use default WriteXLS methods: ignoring AutoFilter")
        if (Encoding!="UTF-8") message("WARNING: Encoding is not UTF-8, but sheets too large to use default WriteXLS methods: Encoding will become UTF-8")
    } else {
        already.xlsx <- FALSE
        ## this was the original function
        cmd <- paste(perl, " -I", shQuote(Perl.Path), " ", shQuote(Fn.Path), 
                     " --CSVPath ", shQuote(Tmp.Dir), " --verbose ", verbose, 
                     " --AdjWidth ", AdjWidth, " --AutoFilter ", AutoFilter, 
                     " --BoldHeaderRow ", BoldHeaderRow, " --FreezeRow ", 
                     FreezeRow, " --FreezeCol ", FreezeCol, " --Encoding ", 
                     Encoding, " ", shQuote(ExcelFileTmp), sep = "")  ##### HACK: exchanged ExcelFileName for ExcelFileTmp
    }
    ## ## END HACK 2
    if (verbose) print(cmd)
    Result <- system(cmd)
    if (Result != 0) {
        if (already.xlsx) {
            message("The Perl script 'txt2xlsx' failed to run successfully.")
        } else {
            message("The Perl script 'WriteXLS.pl' failed to run successfully.")
        }
        return(invisible(FALSE))
    } else {
        ## ## BEGIN HACK 3
        if (grepl("\\.xlsx",ExcelFileName)) {
            if (already.xlsx) {
                system(paste("mv -f",ExcelFileTmp,ExcelFileName))
            } else {
                xlsx.cmd <- paste("/home/apa/local/bin/xls2xlsx -i",ExcelFileTmp)
                freeze <- c( ifelse(FreezeRow>0,FreezeRow,''), ifelse(FreezeCol>0,FreezeCol,'') )
                if (FreezeRow>0||FreezeCol>0) xlsx.cmd <- paste0(xlsx.cmd," -f ",freeze[1],",",freeze[2])
                if (!CopyFormat) xlsx.cmd <- paste(xlsx.cmd,"--no-cell-formatting")
                Result2 <- system(xlsx.cmd)
                if (Result2 != 0) {
                    message("The Perl script 'xls2xlsx' failed to run successfully.")
                    return(invisible(FALSE))
                } else {
                    system(paste0("mv -f ",ExcelFileTmp,"x ",ExcelFileName))
                }
            }
        } else {
            system(paste("mv -f",ExcelFileTmp,ExcelFileName))
        }
        system(paste0("chmod a+x ",ExcelFileName))  # in keeping with our FS defaults
        ## ## END HACK 3
        return(invisible(TRUE))
    }
}


apa.names$general <- c(apa.names$general, "export.columns")
export.columns <- function(x, row.names=TRUE, col.names=TRUE, file.names=NULL, prefix=NULL, delim="_") {
	
	## Write all columns from a dataset as individual files
	
    if (!is.matrix(x) & !is.data.frame(x)) { stop("Input must be a matrix or data frame!\n") }
	
	if (length(file.names)==0) {
		if (length(colnames(x))==0) { 
			file.names <- paste("Column",1:ncol(x),sep="")
		} else {
			file.names <- colnames(x)
		}
	} else if (length(file.names)!=ncol(x)) { 
		stop("length(file.names) != ncol(x)\n") 
	}
	
	if (is.null(prefix)) { 
		file.names <- file.names
	} else if (length(prefix) == 1) {
		file.names <- paste(prefix, file.names, sep=delim)
	} else {
		stop("If specified, 'prefix' must have length=1 or length=ncol(x)!\n")
	}
	
	for (i in 1:ncol(x)) {
		if (row.names) {
			df <- data.frame(rownames(x), x[,i])
			if (col.names) { colnames(df) <- c("Row",colnames(x)[i]) }
		} else {
			df <- data.frame(x[,i])
			if (col.names) { colnames(df) <- colnames(x)[i] }
		}
		write.table(df, file=paste(file.names[i],"txt",sep="."), sep="\t", quote=FALSE, row.names=FALSE, col.names=col.names)
	}
}


apa.names$general <- c(apa.names$general, "as.fasta")
as.fasta <- function(x, vectors=FALSE, upper=TRUE, comments=c("#")) {
    
    ## converts the contents of a fasta file, as a character vector output from 'scan', broken on newlines, into "fasta" format.
    ##  - "fasta" format is a named character vector, names = fasta headers, values = single strings representing newline-free sequence.
    ## 'vectors' controls whether the sequence is recorded as a vector of separate characters (TRUE) 
    ##   or a length-1 vector with the whole sequence (FALSE)
    ## 'comments' is a vector of characters which, if found at line starts, cause those lines to be skipped
    
    x <- gsub("\r","",x)   # in case windows newlines
    comm <- c()
    if (length(comments)>0) for (i in 1:length(comments)) comm <- c(comm, grep(paste0("^",comments[i]), x))
    if (length(comm) > 0) x <- x[-comm]
    y <- rep(0, length(x))
    heads <- grep("^>", x)
    y[heads] <- 1:length(heads)
    noseq <- which(diff(heads)==1)
    blocks <- find.runs(y)
    B <- length(blocks)
    if (length(blocks[[B]])==0) blocks <- blocks[1:(B-1)]  # sometimes gets null last element
    blocks <- do.call(rbind, blocks)
    if (length(noseq)>0) {
        noseq.y <- which(y %in% noseq)
        noseq.b <- which(blocks[,1] %in% noseq.y)
        for (b in rev(noseq.b)) {  # MUST OPERATE BACKWARDS to preserve positions in noseq.b
            blocks <- blocks[c(1:b,b:nrow(blocks)),]
            blocks[b+1,] <- c(0,0)  # there is no sequence, so not 'x' positions
            rownames(blocks)[b+1] <- 0  # but we pretend there is, so 'fasta' will get an empty element here
        }
    }
    z <- which(rownames(blocks) == 0)
#    return(list(blocks,z))
    fasta <- apply(blocks[z,], 1, function(i) paste(x[i[1]:i[2]],collapse="") )
    if (vectors) fasta <- strsplit(fasta,"")
    names(fasta) <- sub("^>","",x[heads])
    if (upper) fasta <- toupper(fasta)
    return(fasta)
}


apa.names$general <- c(apa.names$general, "read.fasta")
read.fasta <- function(file, vectors=FALSE, upper=TRUE, comments="#") {
    
    ## *Actually* reads a fasta file into a named vector format, unlike ape's read.dna() which only claims to.
    ## arguments are passed to 'as.fasta' as-is.
    
    if (grepl("\\.gz$",file)) {
        gzf <- gzfile(file, open="R")
        x <- as.fasta(scan(gzf, what="", sep="\n"), vectors=vectors, upper=upper, comments=comments)
        close(gzf)
    } else {
        x <- as.fasta(scan(file, what="", sep="\n"), vectors=vectors, upper=upper, comments=comments)
    }
    x
}


apa.names$general <- c(apa.names$general, "write.fasta")
write.fasta <- function(vec, filename, names=NULL, linewidth=50, na.rm=FALSE) {
    
    ## Writes a fasta in named-vector format (e.g. from read.fasta() above) to file
    ## 'filename' is the file name to write to: if ends in '.gz', writes to compressed file
    ## 'names', if not null, will become fasta headers, regardless of 'vec' names
    ## 'linewidth' sets # characters per line
    ## 'na.rm', if TRUE, will omit any NA, length-0, or otherwise empty sequences
    
    vec[listLengths(vec)==0] <- ""  # convert NULL entries to prevent sapplies below from complaining
    empty <- is.na(vec) | nchar(vec)==0 | !grepl("[[:alpha:]]",vec) | grepl("^Sequence ?U",vec,ignore.case=TRUE)  # last one targets "Sequence Unavailable"
    if (na.rm) { vec <- vec[!empty] }
    
    if (is.null(names(vec))) { 
        if (is.null(names)) {
            headers <- paste(">", 1:length(vec), sep="")   # generic names: "1"-"N"
        } else {
            headers <- paste(">", names, sep="")
        }
    } else if (is.null(names)) {
        headers <- paste(">", names(vec), sep="")
    } else {
        headers <- paste(">", names, sep="")
    }
    
    blockify <- function(x, w) {
        N <- nchar(x)
        if (N > w) {
            chars <- unlist(strsplit(x,''))
            cmax <- w*trunc(N/w)
            lines <- apply(matrix(chars[1:cmax], ncol=w, byrow=TRUE), 1, paste, collapse="")
            if (cmax < N) {
                last <- paste(chars[(cmax+1):N], collapse="")
                return(c("",lines,last))
            } else {
                return(c("",lines))
            }
        } else {
            return(c("",x))
        }
    }
    
    blocks <- lapply(vec, blockify, linewidth)
    for (i in 1:length(blocks)) {
    	blocks[[i]][1] <- headers[i]  # first slot in each block is left open for header
    }
    
    if (grepl("\\.gz$",filename)) {
        gzf <- gzfile(filename, open="W")
        write.table(unlist(blocks), gzf, sep="\n", quote=FALSE, row.names=FALSE, col.names=FALSE)
        close(gzf)
    } else {
        write.table(unlist(blocks), filename, sep="\n", quote=FALSE, row.names=FALSE, col.names=FALSE)
    }
}


apa.names$general <- c(apa.names$general, "read.fastq")
read.fastq <- function(file) {
    
    ## reads in a fastq file into a 3-col matrix: header, seq, qual
    
    x <- scan(file, what="", sep="\n")
    headers1 <- seq(1, length(x)-3, 4)
    sequence <- seq(2, length(x)-2, 4)
#    headers2 <- seq(3, length(x)-1, 4)
    quality <- seq(4, length(x), 4)
    return(matrix(c(sub("^@","",x[headers1]),x[sequence],x[quality]), ncol=3))
}


apa.names$general <- c(apa.names$general, "write.fastq")
write.fastq <- function(fq.mat, filename) {
    
    ## writes a 3-col matrix (e.g. from read.fastq()) to file
    ## if 'filename' ends in '.gz', writes to compressed file
    
    header.at <- grepl("^@",fq.mat[1,1])  # do headers appear to have "@" prefixes already?
    if (!header.at) fq.mat[,1] <- paste0("@",fq.mat[,1])  # add if not
    
    if (FALSE) {
        vec <- rep("", nrow(fq.mat)*4)
        headers <- seq(1, length(vec)-3, 4)
        sequence <- seq(2, length(vec)-2, 4)
        headers2 <- seq(3, length(vec)-1, 4)
        quality <- seq(4, length(vec), 4)
        
        vec[headers] <- fq.mat[,1]
        vec[sequence] <- fq.mat[,2]
        vec[headers2] <- "+"
        vec[quality] <- fq.mat[,3]
    }
    
    fq.mat <- fq.mat[,c(1:3,3)]
    fq.mat[,3] <- "+"
    
    if (grepl("\\.gz$",filename)) {
        gzf <- gzfile(filename, open="W")
        write.table(c(t(fq.mat)), gzf, sep="\n", quote=FALSE, row.names=FALSE, col.names=FALSE)
        close(gzf)
    } else {
        write.table(c(t(fq.mat)), filename, sep="\n", quote=FALSE, row.names=FALSE, col.names=FALSE)
    }
}


apa.names$general <- c(apa.names$general, "read.sff.quals")
read.sff.quals <- function(file) {
    
    ## Reads an sff quality "fasta" file into a list of quality-score vectors
    
    x <- sub("\r","",scan(file, what="", sep="\n"))  # in case windows newlines
    y <- rep(0, length(x))
    heads <- grep("^>", x)
    y[heads] <- 1:length(heads)
    blocks <- find.runs(y)
    z <- which(names(blocks) == 0)
    fasta <- sapply(blocks[z], FUN=function(i){ as.numeric(unlist(strsplit(paste(x[i[1]:i[2]], collapse=" ")," "))) })
    names(fasta) <- sub("^>","",x[heads])
    return(fasta)    
}


apa.names$general <- c(apa.names$general, "qual2int")
qual2int <- function(qual, encoding=c("Sanger","Illumina-1.3","Illumina-1.0")) {
	
	## converts quality ASCII strings into integer vectors
	## ascii.lookup <- as.matrix(sfsmisc:::chars8bit(1:255))
	
	encoding <- match.arg(encoding)
    encdat <- switch(encoding, `Sanger`=c(33,126,0,93), `Illumina-1.3`=c(64,126,0,62), `Illumina-1.0`=c(59,126,-5,62))  # ascii min, ascii max, score min, score max
	
	to.int <- function(x) {
		y <- unlist(strsplit(x,""))
		z <- match(y, ascii.lookup[,1])-encdat[1]
		if (any(z<encdat[3])) warning("Some qualities are below the minimum quality",encdat[3],"!")
		if (any(z>encdat[4])) warning("Some qualities exceed the maximum quality",encdat[4],"!")
		return(z)
	}
	
	if (length(qual)==1) {
		scores <- to.int(qual)
	} else {
		scores <- lapply(qual, to.int)
	}
	return(scores)
}
	


apa.names$general <- c(apa.names$general, "read.gmt")
read.gmt <- function(file) { 
	
	## reads a GMT (Gene Matrix Transposed) format file (e.g. exported GSEA gene sets from Broad's MSigDB)
	
	x <- scan(file, what="", sep="\n")
	com <- grep("^#",x)
	if (length(com)>0) x <- x[-com]  # don't do this with length-0 index vectors: deletes all data
	y <- lapply(x, function(i){unlist(strsplit(i,"\t"))})
	name <- sapply(y, function(i){i[1]})
	desc <- sub("> ","",sapply(y, function(i){i[2]}))
	genes <- lapply(y, function(i){i[3:length(i)]})
	return(list(name=name,desc=desc,genes=genes))
}
	


apa.names$general <- c(apa.names$general, "write.gmt")
write.gmt <- function(x, filename) { 
	
	## writes a GMT (Gene Matrix Transposed) format file
	## requires an object with same format as read.gmt() output
	
	subs <- !grepl("^> ",x$desc)
	x$desc[subs] <- paste("> ", x$desc[subs])
	y <- sapply(1:length(x), function(i){paste(x$name[i], x$desc[i], x$genes[[i]], sep="\t")})
	write.vector(y, filename)
}


apa.names$general <- c(apa.names$general, "read.psl")
read.psl <- function(file, header=TRUE) {

    ## Assumes standard 5-row PSL header
    
    if (header) {
        x <- read.delim(file, as.is=TRUE, header=FALSE, skip=5)
        h <- read.delim(file, as.is=TRUE, header=FALSE, skip=2)[1:2,]
        colnames(x) <- gsub(" ","",apply(h,2,paste,collapse=""))
        x
    } else {
        read.delim(file, as.is=TRUE, header=FALSE)
    }
}


apa.names$general <- c(apa.names$general, "write.psl")
write.psl <- function(x, file, blockSizes=NULL, qStarts=NULL, tStarts=NULL, custom.header=FALSE) {
    
    ## 'x' is a dataframe with PSL data; may have extra columns (i.e. cols 22-N)
    ## blockSizes, qStart, tStarts are optional lists-of-vectors which will be properly formatted and added/replaced to 'x'
    
    numerics <- c(1:8,11:13,15:18)
    for (n in numerics) x[[n]] <- gsub(" ","",format(x[[n]],scientific=FALSE))
    
    if (length(blockSizes)>0) x[[19]] <- sapply(blockSizes, function(z) paste0(paste(gsub(" ","",format(z,scientific=FALSE)),collapse=","),",") )
    if (length(qStarts)>0) x[[20]] <- sapply(qStarts, function(z) paste0(paste(gsub(" ","",format(z,scientific=FALSE)),collapse=","),",") )
    if (length(tStarts)>0) x[[21]] <- sapply(tStarts, function(z) paste0(paste(gsub(" ","",format(z,scientific=FALSE)),collapse=","),",") )
    
    header <- c("psLayout version 3","")
    if (custom.header) {
        ## row 3 = custom colnames; row 4 = blank
        header <- c(header, paste(colnames(x),collapse="\t"), "")
    } else {
        ## rows 3 and 4 as usual
        header <-
            c(
                header,
                "match\tmis- \trep. \tN's\tQ gap\tQ gap\tT gap\tT gap\tstrand\tQ        \tQ   \tQ    \tQ  \tT        \tT   \tT    \tT  \tblock\tblockSizes \tqStarts\t tStarts",
                "     \tmatch\tmatch\t   \tcount\tbases\tcount\tbases\t      \tname     \tsize\tstart\tend\tname     \tsize\tstart\tend\tcount"
            )
    }
    header <-
        c(
            header,
            "---------------------------------------------------------------------------------------------------------------------------------------------------------------"
        )

    y <- c(header, apply(x, 1, paste, collapse="\t"))
    write.vector(
        y,
        file
    )
    invisible(x)
}


apa.names$graphics <- c(apa.names$graphics, "view.image")
view.image <- function(imgfile) {
    com <- switch(
        Sys.info()[["sysname"]], 
        "Windows"=paste(Sys.getenv("COMSPEC"), "/c", imgfile),
        "Linux"=paste("gthumb", imgfile, "&"),
        "Darwin"=paste("open", imgfile, "&"),
        NA
    )
    if (is.na(imgfile)) {
        stop(paste("Image file '",imgfile,"' not valid!\n",sep=""))
    } else if (is.na(com)) {
        stop(paste("Unknown system type '",Sys.info()[["sysname"]],"'!  Must be Windows, Linux, or Darwin\n",sep=""))
    } else {
        system(com)
    }
}


apa.names$hacks <- c(apa.names$hacks, "xemacs")
xemacs <- function(file) {
    
    ## Base emacs() does not run emacs in bkg; R session hangs in the meantime.
    ## xemacs() expects X window env and runs in bkg.
    
    system(paste("emacs",file,"&"))
}


apa.names$hacks <- c(apa.names$hacks, "gthumb")
gthumb <- function(file) {
    
    ## Expects X / Gnome; view image

    if (grepl("\\.pdf$",file,TRUE)) {
        system(paste("evince",file,"&"))
    } else {
        if (.HOSTNAME %in% qw(rho,aspen,aspen-0,lepus)) {  # hosts currently running CentOS6
            system(paste("gthumb",file,"&"))
        } else {  # else assumed to be a CentOS7 host
            system(paste("gwenview",file,"2>/dev/null &"))
        }
    }
}


apa.names$hacks <- c(apa.names$hacks, "stabilize.integer")
stabilize.integer <- function(x) {
    
    ## prevents certain integers from writing to file in scientific format
    ## i.e., written value is "1000000" not "1e+06"
    ## values in sci format will break bedtools, samtools, etc.
    ## WARNING: values become character, not numeric.  Use ONLY for writing to file.
    
    gsub(" ","",format(x,scientific=FALSE))  ### numbers have now become character strings!!!
}


apa.names$dev <- c(apa.names$dev, "Excel.column.extract")
Excel.column.extract <- function(data, from="clipboard") {
    
    ## WINDOWS ONLY
    ## Produce N new data columns for an existing Excel file, based on an ID column.
    ## The 'data' object must have N+1 columns; col 1 is the IDs and the other N columns are the data to be transferred.
    ## 1. In the Excel file, insert N new columns where you want the new data to reside.
    ## 2. In R, paste string "Excel.column.extract(myDataFrame)" onto command line -- DO NOT EXECUTE.
    ## 3. In the Excel file, select all desired ID cells from the ID column (must be a contiguous range of cells)
    ## 4. Hit CTRL-C to send gene IDs to clipboard.
    ## 5. Back to R, hit <Enter> (run "Excel.column.extract(myDataFrame)").
    ## 6. In Excel, select upper-left corner of the empty column range.
    ## 7. Hit CTRL-V to paste in new data.
    
    clipboard <- ifelse(length(from)==1 & from[1]=="clipboard", TRUE, FALSE)
    if (clipboard & .Platform$OS.type != "windows") stop("Clipboard mode only works on Windows!\n")
    
    if (clipboard) {
        x <- readClipboard()
    } else {
        if (length(from)==0) message("'from' has no data!\n")
        x <- from
    }
    y <- data[match(x,data[,1]),2:ncol(data)]
    if (clipboard) {
        out <- c(
            paste(colnames(data)[2:ncol(data)],collapse="\t"),
            apply(y,1,paste,collapse="\t")
        )
        writeClipboard(out)
    } else {
        y
    }
    
}


apa.names$dev <- c(apa.names$dev, "FatiClone.KEGG.convert")
FatiClone.KEGG.convert <- function(key, from="clipboard") {

    ## WINDOWS ONLY
    ## Filling in gene names for FatiClone KEGG results:
    ## 1. In R, paste string "FatiClone.KEGG.convert(myKeyObject)" onto command line -- DO NOT EXECUTE.
    ## 2. In FatiClone sig KEGG terms file, select all non-header cells of column X ("Input_Xrefs") and CTRL-C to send gene IDs to clipboard.
    ## 3. Back to R, hit <Enter> (run "FatiClone.KEGG.convert()").
    ## 4. Select cell Y2 from sig terms file (first non-header cell of column "Mapped_Symbols") and CTRL-V to paste new data from clipboard.
    ## 5. Save sig terms file.
    ##
    ## 'key' is a 2-col object; col 1 = Ensembl IDs (or Entrez, or whatever KEGG DB IDs were used), col 2 = symbols
    
    clipboard <- ifelse(length(from)==1 & from[1]=="clipboard", TRUE, FALSE)
    if (clipboard & .Platform$OS.type != "windows") stop("Clipboard mode only works on Windows!\n")
    
    if (clipboard) {
        x <- lapply(readClipboard(), function(i) unlist(strsplit(i,"; ")) )
    } else {
        if (length(from)==0) message("'from' has no data!\n")
        x <- lapply(from, function(i) unlist(strsplit(i,"; ")) )
    }
    y <- lapply(x, function(i) key[match(i,key[,1]),2] )
    z <- sapply(y, function(i) paste(i,collapse="; ") )
    if (clipboard) {
        writeClipboard(z)
    } else {
        z
    }
}


apa.names$bio.seq <- c(apa.names$bio.seq, "read.meme.txt")
read.meme.txt <- function(file) {
    
    ## Reads a meme.txt file into minimal-meme format
    
    ## get data, find key record starts, etc.
    dat <- scan(file, what="", sep="\n", blank.lines.skip=TRUE)
    
    M <- grep("^MOTIF",dat)               # MOTIF  1	width =   19   sites =  50   llr = 764   E-value = 4.5e-096
    N <- length(M)
    O <- grep("^log-odds matrix:",dat)    # log-odds matrix: alength= 4 w= 19 n= 60743 bayes= 10.7358 E= 4.5e-096 
    P <- grep("^letter-probability matrix:",dat)  # letter-probability matrix: alength= 4 w= 19 nsites= 50 E= 4.5e-096 
    
    ## define some sub-functions
    parse.title <- function(x) {
        unlist(strsplit(x,"[[:space:]]+"))[2]     # select number only
    }
    lods.line <- function(x) {
        fields <- as.numeric(unlist(strsplit(x,"[[:space:]]+"))[c(4,6,12)])
        list(alength=fields[1], w=fields[2], nsites=NA, E=fields[3])
    }
    prob.line <- function(x) {
        fields <- as.numeric(unlist(strsplit(x,"[[:space:]]+"))[c(4,6,8,10)])
        list(alength=fields[1], w=fields[2], nsites=fields[3], E=fields[4])
    }
    matrix.line <- function(x, maxcol) {
        y <- unlist(strsplit(x, "[[:space:]]+"))
        if (y[1]=="")  y <- y[2:maxcol]   # 'maxcol' is alphabet length + 1 (since first field is empty -- length(2:maxcol) == length(alphabet)
        as.numeric(y)
    }
    
    ## create motifwise matrix of motif-record components
    records <- cbind(M=M,O=O,P=P) 
    
    ## begin construction of motif-data object
    mtitles <- nameless(sapply(dat[M], parse.title))
    obj <- new.list(mtitles)
    
    ## parse header
    ver <- grep("^MEME version", dat)[1]
    alpha <- grep("^ALPHABET=", dat)[1]
    strands <- grep("^strands:", dat)[1]
    freq <- grep("^Background letter frequencies", dat)[1]
    header <- list(
        source.file=file,
        MEME.ver=as.numeric(sub("^MEME version ","",dat[ver])),
        alphabet=unlist(strsplit(sub("^ALPHABET= ","",dat[alpha]),"")),
        strands=unlist(strsplit(sub("^strands: ","",dat[strands])," ")),
        bkg.freq=as.data.frame(matrix(sapply(dat[freq+1], function(x) unlist(strsplit(x," ")) ), ncol=2, byrow=TRUE), stringsAsFactors=FALSE)
    )
    header$bkg.freq[,2] <- as.numeric(header$bkg.freq[,2])
    
    ## loop through records and transfer data to object
    for (i in 1:N) {
        obj[[i]] <- new.list(qw(id,alength,w,nsites,E,lods,pwm))
        obj[[i]][1:5] <- c(list(id=mtitles[i]), prob.line(dat[records[i,3]]))
        mat.start <- records[i,3]+1
        mat.end <- records[i,3]+obj[[i]]$w
        obj[[i]]$pwm <- nameless(sapply(dat[mat.start:mat.end], matrix.line, length(header$alpha)+1))
        dimnames(obj[[i]]$pwm) <- list(header$alpha, 1:ncol(obj[[i]]$pwm))
        mat.start <- records[i,2]+1
        mat.end <- records[i,2]+obj[[i]]$w
        obj[[i]]$lods <- nameless(sapply(dat[mat.start:mat.end], matrix.line, length(header$alpha)+1))
        dimnames(obj[[i]]$lods) <- list(header$alpha, 1:ncol(obj[[i]]$lods))
        
    }
    
    list(HEADER=header,MOTIFS=obj)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "read.minimal.meme")
read.minimal.meme <- function(file, title.fmt=c("ID name","name")) {
    
    ## Reads a motif definition file in generic meme (text) format
    ## 'title' indicates structure of motif title line (i.e. parse "^MOTIF ID name" or just "^MOTIF name")
    
    ## get data, find key record starts, etc.
    title.fmt <- match.arg(title.fmt)
    dat <- scan(file, what="", sep="\n", blank.lines.skip=TRUE)
    M <- grep("^MOTIF",dat)
    N <- length(M)
    O <- grep("^log-odds matrix", dat)
    P <- grep("^letter-probability matrix", dat)
    U <- grep("^URL", dat)
    if (length(O)==0) O <- rep(NA, N)
    if (length(P)==0) P <- rep(NA, N)
    if (length(U)==0) U <- rep(NA, N)
    
    ## define some sub-functions
    parse.title <- function(x, n) {
        fields <- unlist(strsplit(x," "))[-1]  # drop "MOTIF"
        final <- fields[1:n]
        if (length(fields) > n) {
            final[n] <- paste(fields[n:length(fields)], collapse=" ")
        }
        final
    }
    lods.line <- function(x) {
        fields <- as.numeric(unlist(strsplit(x," "))[c(4,6,8)])
        list(alength=fields[1], w=fields[2], nsites=NA, E=fields[3])
    }
    prob.line <- function(x) {
        fields <- as.numeric(unlist(strsplit(x," "))[c(4,6,8,10)])
        list(alength=fields[1], w=fields[2], nsites=fields[3], E=fields[4])
    }
    matrix.line <- function(x, maxcol) {
        y <- unlist(strsplit(x, "[[:space:]]+"))
        if (y[1]=="") y <- y[2:maxcol]  # 'maxcol' is alphabet length + 1 (since first field is empty -- length(2:maxcol) == length(alphabet)
        as.numeric(y)
    }
    
    ## test record homogeneity; create motifwise matrix of motif-record components
    tl <- listLengths(list(O,P,U))
    if (max(tl) > N) stop("Motif file is malformed: there are more matrices (or URLs) than 'MOTIF' header lines!\n")
    if (luniq(tl)==1) { 
        records <- cbind(M=M,O=O,P=P,U=U)  # all same length; each record has all 4 entries
    } else {  
        records <- matrix(NA, N, 4)
        colnames(records) <- qw(M,O,P,U)
        records[,1] <- M      # ALWAYS
        if (length(O) == N) { 
            records[,2] <- O		# every motif has a log-odds matrix
        } else {
            records[match(sapply(O,nearest,M,-1),M),2] <- O   # not all motifs have them; associate O starts with nearest upstream record headers
        }
        if (length(P) == N) {
            records[,3] <- P		# every motif has a letter-probability matrix
        } else {
            records[match(sapply(P,nearest,M,-1),M),3] <- P   # not all motifs have them; associate P starts with nearest upstream record headers
        }
        if (length(U) == N) {
            records[,4] <- U		# every motif has a URL
        } else { 
            records[match(sapply(U,nearest,M,-1),M),4] <- U   # not all motifs have them; associate U starts with nearest upstream record headers
        }
    }
    
    ## begin construction of motif-data object
    nfields <- length(unlist(strsplit(title.fmt," ")))
    if (nfields == 2) {
        mtitles <- t(as.matrix(nameless(sapply(dat[M], parse.title, 2))))
        obj <- new.list(apply(mtitles,1,paste,collapse=" "))
    } else {
        mtitles <- nameless(sapply(dat[M], parse.title, 1))
        obj <- new.list(mtitles)
        mtitles <- nameless(cbind(NA, mtitles))  # fill in NA for ID, after list naming
    }
    
    ## parse header
    ver <- grep("^MEME version", dat[1:100])  # using '100' as arbitrary blue-sky max line for first record, so we allow imprecise line numbers while not grepping whole file
    alpha <- grep("^ALPHABET=", dat[1:100])
    strands <- grep("^strands:", dat[1:100])
    freq <- grep("^Background letter frequencies", dat[1:100])
    header <- list(
        source.file=file,
        MEME.ver=as.numeric(sub("^MEME version ","",dat[ver])),
        alphabet=unlist(strsplit(sub("^ALPHABET= ","",dat[alpha]),"")),
        strands=unlist(strsplit(sub("^strands: ","",dat[strands])," ")),
        bkg.freq=as.data.frame(matrix(sapply(dat[freq+1], function(x) unlist(strsplit(x," ")) ), ncol=2, byrow=TRUE), stringsAsFactors=FALSE)
    )
    header$bkg.freq[,2] <- as.numeric(header$bkg.freq[,2])
    
    ## loop through records and transfer data to object
    for (i in 1:N) {
        obj[[i]] <- new.list(qw(id,name,alength,w,nsites,E,lods,pwm,url))
        go.spec <- TRUE
        if (!is.na(records[i,3])) {   # has letter-probability matrix
            obj[[i]][1:6] <- c(list(id=mtitles[i,1], name=mtitles[i,2]), prob.line(dat[records[i,3]]))
            go.spec <- FALSE
            mat.start <- records[i,3]+1
            mat.end <- records[i,3]+obj[[i]]$w
            obj[[i]]$pwm <- nameless(sapply(dat[mat.start:mat.end], matrix.line, length(header$alpha)+1))
            dimnames(obj[[i]]$pwm) <- list(header$alpha, 1:ncol(obj[[i]]$pwm))
        }
        if (!is.na(records[i,2])) {   # has log-odds matrix
            if (go.spec) {  # didn't get it from letter-probability matrix
                obj[[i]][1:6] <- c(list(id=mtitles[i,1], name=mtitles[i,2]), prob.line(dat[records[i,3]]))
            }
            mat.start <- records[i,2]+1
            mat.end <- records[i,2]+obj[[i]]$w
            obj[[i]]$lods <- nameless(sapply(dat[mat.start:mat.end], matrix.line, length(header$alpha)+1))
            dimnames(obj[[i]]$lods) <- list(header$alpha, 1:ncol(obj[[i]]$lods))
        }
        if (!is.na(records[i,4])) {   # has URL
            obj[[i]]$url <- dat[records[i,4]]
        }
    }
    
    list(HEADER=header,MOTIFS=obj)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "write.minimal.meme")
write.minimal.meme <- function(pwms, file, mnames=NULL, meme.ver=4, alpha=c("DNA","AA"), strands=c("both","+","-"), freq=NULL, nsites=20, E=0, urls=NULL) {
    
    ## Writes a subset of "read.meme.motifdef' results, or any named list of PWMs (seqLogo-ready), to a file in generic meme format
    ## 'meme.ver', 'alpha', 'strands', and 'freq' are for the format's 4 header fields
    ## 'nsites' and 'E' are single values, or vectors with length = # motifs
    ## 'urls', if specified, is a vector with length = # motifs
    ## 'mnames' allows alternative names for 'pwms' without having to create a separate object and then change its names().
    
    ## Data check
    if (!is.ndfl(pwms)) stop("'pwms' must be a non-data-frame list!\n")
    meme <- FALSE
    if (length(names(pwms))>0) {
        if(all(names(pwms) %in% qw(HEADER,MOTIFS))) meme <- TRUE
    }
    
    ## Matrix row print functions
    sprintf.lods.matrix <- function(mat) {
        spmat <- apply(mat, 1, function(x) sapply(x, function(y) sprintf("%6s",y) ))
        rows <- apply(spmat, 1, paste, collapse="\t")
        paste(paste(rows,"\t",sep=""), collapse="\n")
    }
    sprintf.pwm.matrix <- function(mat) {
        spmat <- apply(mat, 1, function(x) sapply(x, function(y) sprintf("  %7.6f",y) ))
        rows <- apply(spmat, 1, paste, collapse="\t")
        paste(paste(rows,"\t",sep=""), collapse="\n")
    }
    
    ## Set up header values
    if (meme) {
        meme.ver <- pwms$HEADER$MEME.ver
        strands <- paste(pwms$HEADER$strands, collapse=" ")
        alpha.str <- paste(pwms$HEADER$alphabet, collapse="")
        alpha.n <- nchar(alpha.str)
        freq <- pwms$HEADER$bkg.freq[,2]
        pfreq <- sapply(freq, function(x) sprintf("%0.5f",x) )
        alpha.f <- apply(cbind(pwms$HEADER$bkg.freq[,1],pfreq), 1, paste, collapse=" ")
        pwms <- pwms$MOTIFS   #### A LIST WITH ELEMENTS: meta, lods, pwm, url
        urls <- slice.list(pwms, "url")
        IM("MEME")
    } else {
        strands <- match.arg(strands)
        if (strands == "both") strands <- paste(c("+","-"), collapse=" ")
        
        alpha <- match.arg(alpha)
        if (alpha == "DNA") {
            alpha = qw(A,C,G,T)
        } else if (alpha == "AA") {
            alpha = qw(A,C,D,E,F,G,H,I,K,L,M,N,P,Q,R,S,T,V,W,Y)
        }
        alpha.n <- length(alpha)
        
        if (length(freq)==0) {
            freq <- rep(1/alpha.n, alpha.n)
        } else if (length(freq) != alpha.n) {
            stop("'freq' must have length = length of alphabet, or be NULL!\n")
        } else {
            if (zapsmall(1-sum(freq)) != 0) stop("'freq' must sum to 1!\n")
        }
        alpha.str <- paste(alpha, collapse="")
        alpha.f <- c()
        for (i in 1:alpha.n) alpha.f[i] <- paste(alpha[i],sprintf("%0.5f",freq[i]))
    }
    bkg.blurb <- ifelse(all(freq==0.25), "\nBackground letter frequencies (from uniform background):", "\nBackground letter frequencies:")
    
    ## Aux. data check
    N <- length(pwms)
    if (length(mnames)>0) names(pwms) <- mnames
    if (length(names(pwms))==0) stop("'pwms' must have names!\n")
    if (length(unique(names(pwms))) < N) stop("'pwms' names must be unique!\n")
    if (length(nsites)==1) {
        nsites <- rep(nsites, N)
    } else if (length(nsites)!=N) {
        stop("'nsites' must have length = 1 or length = N motifs!\n")
    }
    nsites[nsites==0] <- 20  # "the default", according to MEME documentation @ http://meme.sdsc.edu/meme/doc/meme-format.html#min-motif-pspm
    if (length(E)==1) {
        E <- rep(E, N)
    } else if (length(E)!=N) {
        stop("'E' must have length = 1 or length = N motifs!\n")
    }
    
    ## Initialize output
    tot.len <- 4   # header
    if (meme) {
        records <- matrix(FALSE, N, 3)
        for (i in 1:N) {
            lpwm <- llods <- lurl <- 0
            if (length(pwms[[i]]$lods) > 0) {
                llods <- 2
                records[i,1] <- TRUE
            }
            if (length(pwms[[i]]$pwm) > 0) {
                lpwm <- 2
                records[i,2] <- TRUE
            }
            if (length(pwms[[i]]$url) > 0) {
                lurl <- 1
                records[i,3] <- TRUE
            }
            tot.len <- tot.len + lpwm + llods + lurl + 1
        }
    } else {
        do.urls <- ifelse(length(urls)>0, TRUE, FALSE)
        n <- ifelse(do.urls, 4, 3)
        tot.len <- tot.len + N * n
    }
    out.vec <- rep("", tot.len)
    out.vec[1:4] <- c(
        paste("MEME version", meme.ver),
        paste("\nALPHABET=", alpha.str),
        paste("\nstrands:", strands),
        paste(bkg.blurb, paste(alpha.f,collapse=" "), sep="\n")
    )
    
    ## Process PWMs, etc.
    o <- 4
    if (meme) {
        for (i in 1:N) {
            meta <- pwms[[i]][1:6]
            L <- 1+sum(c(2,2,1)*(records[i,]))  # 1 element for header, 2 for lods, 2 for pwm, 1 for url; where any exist
            pwm.block <- rep("", L)
            pwm.block[1] <- paste(c("\nMOTIF",meta[1:2]),collapse=" ")
            j <- 1
            if (records[i,1]) {  # lods OK
                pwm.block[j+1] <- paste("\nlog-odds matrix: alength=",meta[3],"w=",meta[4],"E=",meta[6])
                pwm.block[j+2] <- paste(sprintf.lods.matrix(pwms[[i]]$lods), collapse="\n")
                j <- j + 2
            }
            if (records[i,2]) {  # pwm OK
                pwm.block[j+1] <- paste("\nletter-probability matrix: alength=",meta[3],"w=",meta[4],"nsites=",meta[5],"E=",meta[6])
                pwm.block[j+2] <- paste(sprintf.pwm.matrix(pwms[[i]]$pwm), collapse="\n")
                j <- j + 2
            }
            if (records[i,2]) {  # url OK
                pwm.block[j+1] <- paste("\n",pwms[[i]]$url,sep="")
            }
            ##IM(i, o, L, length(pwm.block))
            out.vec[(o+1):(o+L)] <- pwm.block
            o <- o + L
        }
    } else {
        for (i in 1:N) {
            pwm.block <- c(
                paste("\nMOTIF",names(pwms)[i]),
                paste("\nletter-probability matrix: alength=",alpha.n,"w=",ncol(pwms[[i]]),"nsites=",nsites[i],"E=",E[i]),
                paste(sprintf.pwm.matrix(pwms[[i]]), collapse="\n")
            )
            if (do.urls) {
                pwm.block <- c(pwm.block, paste("\nurl",urls[i]))
            }
            out.vec[(o+1):(o+n)] <- pwm.block
            o <- o + n
        }
    }
    
    write.vector(out.vec, file)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "write.cismodscan.motif")
write.cismodscan.motif <- function(pwms, file.prefix) {
    
    ## writes a list of PWMs to CisModScan-formatted files.
    ## outputs are 'file.prefix'_pwms.txt and a key file (N = name) to 'file.prefix'_names.txt
    
    N <- length(pwms)
    if (is.ndfl(pwms[[1]])) {  # 'pwms' is a minimal-meme format list, or something like it
        inp <- pwms
        if (length(names(inp))==0) names(inp) <- 1:N
        pwms <- new.list(names(inp))
        for (i in 1:N) pwms[[i]] <- inp[[i]]$pwms
    }
    key <- cbind(1:N, names(pwms))
    out.vec <- rep("", N+sum(listLengths(pwms, "ncol")))
    j <- 0
    for (i in 1:N) {
        PWM <- pwms[[i]]
        nc <- ncol(PWM)
        out.vec[j+1] <- paste(">",nc,sep="")
        out.vec[(j+2):(j+nc+1)] <- apply(PWM, 2, paste, collapse="\t")
        j <- j + nc + 1
    }
    write.vector(out.vec, paste(file.prefix,"pwms.txt",sep="_"))
    write.table(key, paste(file.prefix,"names.txt",sep="_"), sep="\t", quote=FALSE, row.names=FALSE, col.names=FALSE)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "read.annotations")
read.annotations <- function(geno, anno, set=c("gene","transcript","exon","peptide","all"), sort=FALSE) {
    
    ## Reads in metadata from a geno/anno build
    
    set <- match.arg(set)
    prefix <- paste0("/n/data1/genomes/indexes/",geno,"/",anno,"/",geno,".",anno,".")
    
    if (set == "all") {
        x <- list(
            gene=read.delim(paste0(prefix,"genedata.txt"), as.is=TRUE),
            transcript=read.delim(paste0(prefix,"transdata.txt"), as.is=TRUE),
            exon=read.delim(paste0(prefix,"exondata.txt"), as.is=TRUE),
            peptide=read.delim(paste0(prefix,"pepdata.txt"), as.is=TRUE)
        )
        if (sort) x <- lapply(x, function(y) y[order(y[,1]),] )
    } else {
        label <- sub("(cript|tide)","",set)
        x <- read.delim(paste0(prefix,label,"data.txt"), as.is=TRUE)
        if (sort) x <- x[order(x[,1]),]
    }
    
    x
}


apa.names$bio.seq <- c(apa.names$bio.seq, "read.cufflinks.fpkms")
read.cufflinks.fpkms <- function(file, fpkm=10, id=1, genes=NULL) {
    ## Given a cufflinks gene.fpkms_tracking file, returns a 1-col matrix of FPKMs, rownames = gene IDs.
    ## 'fpkm' and 'id' incidate critical columns in file.
    ## Only one row per gene is returned, even if Cufflinks generated 2 or more rows for a given gene.  Multiple FPKM values per gene get summed.
    ## Providing 'genes' will ensure returned matrix has one row for each such gene, even if absent from FPKMs file.
    x <- read.delim(file, as.is=TRUE)[,c(id,fpkm)]
    y <- aggregate(x[,2], list(x[,1]), sum)
    if (length(genes)>0) {
        lost <- !(y[,1] %in% genes)
        if (any(lost)) stop(paste0(sum(lost)," IDs in the cufflinks file are not found in 'genes': wrong 'genes' list provided!\n"))
        z <- y[match(genes,y[,1]),2]
        names(z) <- genes
    } else {
        z <- y[,2]
        names(z) <- y[,1]
    }
    z
}


apa.names$bio.seq <- c(apa.names$bio.seq, "read.sam.header")
read.sam.header <- function(file) {
    ## reads a sam header into a data.frame
    x <- strsplit(system(paste("samtools view -H",file),intern=TRUE), "\t")
    l <- sapply(x,length)
    m <- max(l)
    for (i in 1:length(x)) if (l[i]<m) x[[i]] <- c(x[[i]],rep("",m-l[i]))
    do.call(rbind,x)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "write.sam.header")
write.sam.header <- function(header, file) {
    ## reverse function for read.sam.header()
    x <- as.list(as.data.frame(t(as.matrix(header))))
    x <- lapply(x, function(y) paste(y[y!=""],collapse="\t") )
    write.vector(x, file)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "read.as.sam")
read.as.sam <- function(bam, no.unaligned=FALSE) {
    ## reads a BAM or SAM file, in full SAM format
    sam <- list()
    sam$header <- system(paste("samtools view -H",bam),intern=TRUE)
    x <- tempfile()
    if (no.unaligned) {
        system(paste("samtools view -F 4",bam,">",x))
    } else {
        system(paste("samtools view ",bam,">",x))
    }
    st <- system.time({ sam$data <- read.delim(x, as.is=TRUE, header=FALSE) })
    system(paste("rm -f",x))
    message(format(nrow(sam$data),big.mark=",")," lines read")
    print(st)
    sam
}


apa.names$bio.seq <- c(apa.names$bio.seq, "write.as.sam")
write.as.sam <- function(sam, filename, bam=TRUE, resources=c(1,1), keep.sam=FALSE) {
    
    ## writes a list with "header" and "data" objects (i.e. read.as.sam() output) as a BAM or SAM file.
    ## resources=c(cores,ram) for samtools sort; ram=gigs of ram, as an integer (i.e. '1' will become '1G')
    
    if (length(resources)!=2) stop("'resources' argument must be a length-2 vector! (cores,gigs)")
    temp <- paste0(filename,".tmp")
    s <- paste0(temp,".sam")
    b <- paste0(temp,".bam")
    NL <- length(sam$header) + nrow(sam$data)
    message("Stabilizing integer values for writing...")
    st0 <- system.time({ 
        for (i in c(2,4,5,8,9)) sam$data[[i]] <- stabilize.integer(sam$data[[i]])  # flags, pos, mapq, mate pos, frag len
    })
    print(st0)
    message("Done.")
    st1 <- system.time({ 
        write.vector(sam$header, s)
        write.table(sam$data, s, TRUE, FALSE, "\t", row.names=FALSE, col.names=FALSE)
    })
    print(st1)
    message(format(NL,big.mark=",")," lines written.\nCompleteness check...")
    wc <- as.numeric(system(paste("cat",s,"| wc -l"),intern=TRUE))
    if (wc == NL) {
        message("All lines written.")
    } else {
        stop(paste0("Only ",wc,"/",NL," lines written!  Halting.\n"))
    }
    
    if (bam) {
        st2 <- system.time({ 
            execute(paste("samtools view -h -bS",s,">",b))
            resources[2] <- paste0(resources[2],'G')
            execute(paste("samtools sort -@",resources[1],"-m",resources[2],"-o",filename,b))
            system(paste("rm -f",b))
            execute(paste("samtools index",filename))
            if (keep.sam) {
                system(paste("mv -f",s,paste0(filename,".sam")))
            } else {
                system(paste("rm -f",s))
            }
        })
        print(st2)
        message(format(NL,big.mark=",")," lines converted.")
    } else {
        system(paste("mv -f",s,filename))
    }
}


