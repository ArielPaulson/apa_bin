

apa.names$general <- c(apa.names$general, "show.funcs")
show.funcs <- function(func, missing.only=FALSE) {
	
	## shows all functions called within the function 'func'
	## TO-DO: detect and remove any locally-defined functions
	
    x <- unlist(lapply(as.character(body(func)), function(w){ gsub(" ?\\(","(",w) }))
    y <- unlist(lapply(x, function(w){ unlist(strsplit(w,"[[:space:]]+")) }))
    y2 <- mgrepf("\\(",y)
    z <- unlist(lapply(y2, function(w){ unlist(strsplit(sub("\\([^\\(]*$","(",w),"\\(")) }))
    calls <- real(sapply(z, function(w){ sub("^.*[^[:alpha:]._]+","",w) }))
    if (missing.only) calls <- calls[!sapply(calls,existsFunction)]
    suniq(calls)
}


apa.names$general <- c(apa.names$general, "draw.pairs.graph")
draw.pairs.graph <- function (mat, type, title="Graph1", geometry="ellipse", overlap=FALSE, directional=FALSE, redundant=TRUE, image.prefix=NULL) {
	
	# "type" is one of:
	#   "cm" for square connectivity matrix;
	#   "2m" for 2-col matrix (nodeA, NodeB), rows imply connectivity;
	#   "4m" for 4-col matrix (clusterA, nodeA, clusterB, nodeB), rows imply connectivity;
	# connectivity in connectivity matrices is represented by nonzero, non-NA values
	# "title" is a graph title
	# "geometry" = { box, circle, diamond, plaintext } indicating node shape
	# "directional" specifies dir or undir graph
	# "redundant=T" allows > 1 edge per node pair.  If FALSE, get only one edge
	# "image.prefix" specifes a filename prefix to write "prefix.graph" and "prefix.png" files
	
	# mention directionality assumptions in matrix encoding
	
	if (directional) {
		arrow <- "normal"
	} else {
		arrow <- "none"
	}
	
	if (type == "cm") {
		mat[is.na(mat)] <- 0
		if (is.null(dimnames(mat))) { dimnames(mat) <- list(1:nrow(mat), 1:ncol(mat)) }
		nodes <- unique(unlist(dimnames(mat)))
		edges <- rep("",sum(mat!=0))
		E <- 0
		for (i in 1:nrow(mat)) {
			for (j in 1:ncol(mat)) {
				if (mat[i,j] != 0) {
					E <- E + 1
					if (directional) {   # preserve order
						nodeA <- nodes[i]
						nodeB <- nodes[j]
					} else {   # homogenize order to prevent duplicate edges (so, no A->B AND B->A)
						snodes <- sort(nodes[c(i,j)])
						nodeA <- snodes[1]
						nodeB <- snodes[2]
					}
					edges[E] <- paste("\t",nodeA,esymb,nodeB,";",sep="")
				}
			}
		}
	} else if (type == "2m") {
		edges <- rep("",nrow(mat))
		for (i in 1:nrow(mat)) {
			if (directional) {   # preserve order
				nodeA <- mat[i,1]
				nodeB <- mat[i,2]
			} else {   # homogenize order to prevent duplicate edges (so, no A->B AND B->A)
				snodes <- sort(mat[i,])
				nodeA <- snodes[1]
				nodeB <- snodes[2]
			}
			edges[i] <- paste("\t",nodeA,esymb,nodeB,";",sep="")
		}
	} else if (type == "4m") {
		edges <- rep("",nrow(mat))
		nodes <- rep("", nrow(mat)*2)
		subs.1 <- sort(unique(c(mat[,c(1,3)])))
		subs <- vector("list", length=length(subs.1))  # can use "color=", "label=" for "subgraph clusterX { }" blocks
		for (i in 1:nrow(mat)) {
			if (directional) {   # preserve order
				clustA <- mat[i,1]
				nodeA <- mat[i,2]
				clustB <- mat[i,3]
				nodeB <- mat[i,4]
#				ord <- order(mat[i,c(1,3)])   # sort on node name
#				nodeA <- mat[i,c(2,4)[ord[1]]]
#				clustA <- mat[i,c(1,3)[ord[1]]]
#				nodeB <- mat[i,c(2,4)[ord[2]]]
#				clustB <- mat[i,c(1,3)[ord[2]]]
			} else {   # homogenize order to prevent duplicate edges (so, no A->B AND B->A)
				ord <- order(mat[i,c(2,4)])   # sort on node name
				nodeA <- mat[i,c(2,4)[ord[1]]]
				clustA <- mat[i,c(1,3)[ord[1]]]
				nodeB <- mat[i,c(2,4)[ord[2]]]
				clustB <- mat[i,c(1,3)[ord[2]]]
			}
			nodes[i] <- paste("\t",nodeA," [];",sep="")
			edges[i] <- paste("\t",nodeA,esymb,nodeB,";",sep="")
#			edges[i] <- paste( paste("\t",clustA,esymb,nodeA,";",sep=""), paste("\t",nodeA,esymb,nodeB,";",sep=""), paste("\t",nodeB,esymb,clustB,";",sep=""), collapse="\n")
		}
	}
	graph <- c(paste("digraph",title,"{"), float, paste("\tnode [shape=",geometry,"];",sep=""), edges, "}")
	if (!redundant) { graph <- unique(graph) }
	if (is.null(image.prefix)) {
		return(graph)
	} else {
		graphfile <- paste(image.prefix,"graph",sep=".")
		pngfile <- paste(image.prefix,"png",sep=".")
		write.vector(graph, graphfile)
		if (grepl(.Platform$OS.type,"unix")) { 
			system(paste("dot -Tpng -o",pngfile,graphfile));
		} else {
			IM("Cannot create png image on Windows, sorry.  But we wrote the graph file.\n")
		}
	}
}


apa.names$general <- c(apa.names$general, "draw.cell.graph")
draw.cell.graph <- function (mat, type, title="Graph1", geometry="ellipse", overlap=FALSE, directional=FALSE, redundant=TRUE, image.prefix=NULL) {
	
	# "mat" must be a 4-col matrix (clusterA, nodeA, clusterB, nodeB), rows imply connectivity;
	# connectivity in connectivity matrices is represented by nonzero, non-NA values
	# "title" is a graph title
	# "geometry" = { box, circle, diamond, plaintext } indicating node shape
	# "directional" specifies dir or undir graph
	# "redundant=T" allows > 1 edge per node pair.  If FALSE, get only one edge
	# "image.prefix" specifes a filename prefix to write "prefix.graph" and "prefix.png" files
	
	# mention directionality assumptions in matrix encoding
	
	prog <- "dot"
	gtype <- "digraph"
	float <- ifelse(overlap, "\tlabelfloat=true", "\tlabelfloat=false")
	if (directional) {
#		esymb <- "->"
#		prog <- "dot"
#		gtype <- "digraph"
		arrow <- "normal"
	} else {
#		esymb <- "--"
#		prog <- "neato"
#		gtype <- "graph"
#		float <- ifelse(overlap, "\toverlap=true", "\toverlap=scale")
		arrow <- "none"
	}
	
	if (type == "cm") {
		mat[is.na(mat)] <- 0
		if (is.null(dimnames(mat))) { dimnames(mat) <- list(1:nrow(mat), 1:ncol(mat)) }
		nodes <- unique(unlist(dimnames(mat)))
		edges <- rep("",sum(mat!=0))
		E <- 0
		for (i in 1:nrow(mat)) {
			for (j in 1:ncol(mat)) {
				if (mat[i,j] != 0) {
					E <- E + 1
					if (directional) {   # preserve order
						nodeA <- nodes[i]
						nodeB <- nodes[j]
					} else {   # homogenize order to prevent duplicate edges (so, no A->B AND B->A)
						snodes <- sort(nodes[c(i,j)])
						nodeA <- snodes[1]
						nodeB <- snodes[2]
					}
					edges[E] <- paste("\t",nodeA,esymb,nodeB,";",sep="")
				}
			}
		}
	} else if (type == "2m") {
		edges <- rep("",nrow(mat))
		for (i in 1:nrow(mat)) {
			if (directional) {   # preserve order
				nodeA <- mat[i,1]
				nodeB <- mat[i,2]
			} else {   # homogenize order to prevent duplicate edges (so, no A->B AND B->A)
				snodes <- sort(mat[i,])
				nodeA <- snodes[1]
				nodeB <- snodes[2]
			}
			edges[i] <- paste("\t",nodeA,esymb,nodeB,";",sep="")
		}
	} else if (type == "4m") {
		edges <- rep("",nrow(mat))
		subs.1 <- sort(unique(c(mat[,c(1,3)])))
		subs <- vector("list", length=length(subs.1))  # can use "color=", "label=" for "subgraph clusterX { }" blocks
		for (i in 1:nrow(mat)) {
			if (directional) {   # preserve order
#				clustA <- mat[i,1]
#				nodeA <- mat[i,2]
#				clustB <- mat[i,3]
#				nodeB <- mat[i,4]
				ord <- order(mat[i,c(1,3)])   # sort on node name
				nodeA <- mat[i,c(2,4)[ord[1]]]
				clustA <- mat[i,c(1,3)[ord[1]]]
				nodeB <- mat[i,c(2,4)[ord[2]]]
				clustB <- mat[i,c(1,3)[ord[2]]]
			} else {   # homogenize order to prevent duplicate edges (so, no A->B AND B->A)
				ord <- order(mat[i,c(2,4)])   # sort on node name
				nodeA <- mat[i,c(2,4)[ord[1]]]
				clustA <- mat[i,c(1,3)[ord[1]]]
				nodeB <- mat[i,c(2,4)[ord[2]]]
				clustB <- mat[i,c(1,3)[ord[2]]]
			}
#			edges[i] <- paste("\t",nodeA,esymb,nodeB,";",sep="")
			edges[i] <- paste( paste("\t",clustA,esymb,nodeA,";",sep=""), paste("\t",nodeA,esymb,nodeB,";",sep=""), paste("\t",nodeB,esymb,clustB,";",sep=""), collapse="\n")
		}
	}
	graph <- c(paste(gtype,title,"{"), float, paste("\tnode [shape=",geometry,"];",sep=""), edges, "}")
	if (!redundant) { graph <- unique(graph) }
	if (is.null(image.prefix)) {
		return(graph)
	} else {
		graphfile <- paste(image.prefix,"graph",sep=".")
		pngfile <- paste(image.prefix,"png",sep=".")
		write.vector(graph, graphfile)
		if (grepl(.Platform$OS.type,"unix")) { 
			system(paste(prog,"-Tpng -o",pngfile,graphfile));
		} else {
			IM("Cannot create png image on Windows, sorry.  But we wrote the graph file.\n")
		}
	}
}


apa.names$general <- c(apa.names$general, "squeeze")
squeeze <- function (obj, independent=FALSE, recursive=FALSE) {
	 
	## "squeeze" (a la matlab) removes unnecessary dimensions, i.e.:
	##	Lists: sublists of length 1 are converted into vectors (main objective of this function).
	##	Arrays / Matrixes: empty dimensions are dropped.
	## If 'obj' is a list:
	##  "independent": should empty list dimensions be dropped on an element-by-element basis (T) or only if ALL elements have the same empty dimension (F) ?
	##  "recursive": should 'squeeze' descend into list structure?  Otherwise, only squeezes first level.
	
	if (is.list(obj)) {
		if (length(obj) == 1 && !is.ndfl(obj[[1]])) {
			squeezed <- obj[[1]]
		} else {
			if (!independent) { obj2 <- obj }
			nulls <- rep(0, length(obj))
			for (i in 1:length(obj)) {
				if (is.ndfl(obj[[i]]) & length(obj[[i]]) == 1) {
					if (independent) {
						if (recursive & is.ndfl(obj[[i]])) { obj[[i]] <- squeeze(obj[[i]], recursive=recursive, independent=independent) }
						if (is.ndfl(obj[[i]]) & length(obj[[i]]) == 1) { obj[[i]] <- obj[[i]][[1]] }	# post-recursion squeeze
					} else {
						nulls[i] <- 1
						if (recursive & is.ndfl(obj2[[i]])) { obj2[[i]] <- squeeze(obj2[[i]], recursive=recursive, independent=independent) }
						if (is.ndfl(obj2[[i]]) & length(obj2[[i]]) == 1) { obj2[[i]] <- obj2[[i]][[1]] }	# post-recursion squeeze
					}
				}
			}
			ternary (!independent & sum(nulls) == length(nulls), squeezed <- obj2, squeezed <- obj)
		}
	} else if (is.array(obj)) { 
		x <- dim(obj)
		if (any(x == 1)) {		# empty dimensions
			y <- which(x == 1)
			z <- x[which(x != 1)]
			if (length(z) > 2) {			# remain array
				squeezed <- array(obj, dim=z)
			} else if (length(z) == 2) {		# reduce to matrix
				squeezed <- matrix(obj, dim=z)
			} else if (length(z) < 2) {		# reduce to vector
				squeezed <- as.vector(obj)
			}
		} else {
			if (length(x) == 2) {			# reduce to matrix
				squeezed <- matrix(obj, dim=z)
			} else if (length(x) < 2) {		# reduce to vector
				squeezed <- as.vector(obj)
			}
		}
	} else if (is.matrix(obj)) { 
		x <- dim(obj)
		if (any(x == 1)) {
			y <- which(x == 1)
			z <- x[which(x != 1)]
			if (length(z) < 2) {			# reduce to vector
				squeezed <- as.vector(obj)
			}
		} else {
			if (length(x) < 2) {			# reduce to vector
				squeezed <- as.vector(obj)
			}
		}
	} else {
		stop("Only lists, arrays and matrixes accepted!\n") 
	}
	
	if (length(squeezed) == 0) {		# no data?
		squeezed <- new(class(obj))
	}
	
	return(squeezed)
}


apa.names$general <- c(apa.names$general, "wring")
wring <- function(obj, rmv=0) {
	
	## Removes empty rows/cols from a matrix or array
	## "empty" can be defined as all-zero, all-NA, all-"", etc,.
	## put "empty" value(s) into the 'rmv' vector.
	
	if (length(rmv)==0) {
		message("'rmv' empty: nothing to remove")
		return(obj)
	} else if (is.matrix(obj)) {
		dim.rmv <- list()
		for (i in 1:nrow(obj)) {
			if (all(obj[i,]) %in% rmv) dim.rmv[[1]] <- c(dim.rmv[[1]], i)
		}
		for (j in 1:ncol(obj)) {
			if (all(obj[,j]) %in% rmv)  dim.rmv[[2]] <- c(dim.rmv[[2]], j)
		}
		if (length(dim.rmv[[1]])>0) {
			obj <- obj[-dim.rmv[[1]],]
		}
		if (length(dim.rmv[[2]])>0) {
			obj <- obj[,-dim.rmv[[2]]]
		}
	} else if (is.array(obj)) {
		d <- dim(obj)
		interp <- rep("",2*d-1)
		interp[seq(2,d-1,2)] <- ","
		dim.j <- seq(1,d,2)
		for (i in 1:length(d)) {  # for each dimension i
			rmv.j <- c()
			for (j in 1:d[i]) {  # for each j in dimension i
				interp.j <- interp
				interp.j[dim.j[i]] <- j   # to index
				dimstr <- paste(interp.j,collapse="")  # creates dim string for array, e.g. ",,3,"
				if (all(eval(parse(text=paste("obj[",dimstr,"]",sep=""))) %in% rmv)) rmv.j <- c(rmv.j, j)
			}
			if (length(rmv.j)>0) {
				interp.j2 <- interp
				interp.j2[dim.j[i]] <- paste("-c(",paste(rmv.j,collapse=","),")",sep="")  # vector of removals for this dim
				rmvstr <- paste(interp.j2,collapse="") # creates dim anti-selection string for array, e.g. ",,-c(1,3,4),"
				obj <- eval(parse(text=paste("obj[",rmvstr,"]",sep="")))
			}
		}
	}
	obj
}


apa.names$general <- c(apa.names$general, "extract.calls")
extract.calls <- function(func, full=TRUE, max.depth=NA) {
	
	## Extracts all function calls used by the function
	## DOES NOT WORK ON INTERNALS OR PRIMITIVES
	## 'func' is either the function or the function name
	## 'full=T' returns the entire call; 'full=F' returns only the names of the functions
	
	stop("UNDER CONSTRUCTION")  ##### critical problem: functions defined within functions are represented as integer vectors, not actual source code
	
	if (is.character(func)) func <- get(func)
	if (is.na(max.depth)) max.depth <- .Options$expressions	# current recursion limit
	
	recurse <- function(x, j) {
		IM(j, length(x))
		y <- vector("list", length=length(x))
		for (i in 1:length(x)) {
			if (length(x[[i]])>1) {
				if (all(sapply(x[[i]],length)==1)) {
					IM(i, x[[i]])
					y[[i]] <- x[[i]][[1]]
				} else {
					y[[i]] <- recurse(x[[i]], j+1)
				}
			}
		}
		y
	}
	
	if (length(body(func))==0) {
		NA
	} else {
		calls <- unique(unlist(recurse(as.list(body(func)),0)))
		return(calls)
		if (full) {
			calls2 <- sort(calls)
		} else {
			calls2 <- sort(unique(sapply(calls), function(x) sub("\\(.*","",x) ))
		}
		setdiff(calls2, c("+","=","==","!=","-","/",">","<","<-","<<-","*","%%","%in%","%*%","%/%","^"))
	}
}


apa.names$general <- c(apa.names$general, "grok")
grok <- function(obj, max.depth=0, trace=FALSE) {
	
	## Attempts to deparse all useful information about an object into a list, which can also become a list representation of the object.
	## "max.depth" sets max recursion depth.  "0" prevents recursion.  "NA" allows unlimited recursion.
	## "trace" reports a bunch of messages which track the current (recursion) position in the object
	
	listCapture <- function(lst) {
		cap <- vector("list", length=length(lst))
		names(cap) <- names(lst)
		for (i in 1:length(lst)) { cap[[i]] <- capture.output(lst[[i]]) }
		return(cap)
	}
	
	getBasic <- function(x) {
		basic <- list()
		basic$length <- ifelse(is.null(length(x)), NA, length(x))
		ternary (is.null(dim(x)), basic$dim <- NA, basic$dim <- dim(x))
		ternary (is.null(names(x)), basic$names <- NA, basic$names <- names(x))
		ternary (is.null(dimnames(x)), basic$dimnames <- NA, basic$dimnames <- dimnames(x))
		basic$typeof <- typeof(x)
		basic$storage.mode <- storage.mode(x)
		basic$mode <- mode(x)
		basic$class <- class(x)
		basic$is.vector <- is.vector(x)
		basic$is.atomic <- is.atomic(x)
		basic$is.S4 <- isS4(x)
		if (class(x) == "data.frame") {
			if (ncol(x) > 0) {
				basic$column.types <- matrix("", nrow=3, ncol=ncol(x))
				colnames(basic$column.types) <- colnames(x)
				rownames(basic$column.types) <- c("storage.mode","mode","class")
				for (i in 1:ncol(x)) { 
					basic$column.types[1,i] <- storage.mode(x[,i])
					basic$column.types[2,i] <- mode(x[,i])
					basic$column.types[3,i] <- class(x[,i])
				}
			}
		}
		basic$object.size <- object.size(x)
		basic$env.size <- 0			# fill later (maybe)
		basic$total.size <- object.size(x)	# increase later (maybe)
		basic$depth <- 1			# increase later (maybe)
		basic$classRepresentation <- getClass(class(x))
		basic$.NAMES <- c(".NAMES", names(basic), "this.depth")	# last gets added later
		basic <- basic[c(length(basic),2:length(basic)-1)]	# put .NAMES in front
		return(basic)
	}
	
	getAdvanced <- function(x) {
		advanced <- slot.attributes <- list()
		advanced$.NAMES <- c()			# fill later
		
		y <- getClass(class(x))
		z <- attributes(x)
		advanced$"@access "<- y@access
		advanced$"@className" <- y@className
		advanced$"@package" <- y@package
		advanced$"@contains" <- y@contains
		advanced$"@slots" <- y@slots
		advanced$"@prototype" <- y@prototype
		advanced$"@subclasses" <- y@subclasses
		advanced$"@virtual" <- y@virtual
		advanced$slotsFromS3 <- slotsFromS3(x)
		if (length(z) > 0) { advanced$attributes <- listCapture(z) }
		
		if (length(y@slots) > 0) {
			z1 <- y@slots
			zn <- intersect(names(z1), names(z))	# class attributes (slots)
			if (length(zn) > 0) {
				z1 <- z1[match(zn, names(z1))]
				z1 <- z1[order(names(z1))]
				z <- z[match(zn, names(z))]
				z <- z[order(names(z))]
				
				slot.attributes <- vector("list", length=length(zn))	# redefine, if actually being used
				names(slot.attributes) <- zn
				for (i in 1:length(zn)) {
					slot.attributes[[i]]$class <- z1[[i]]
					slot.attributes[[i]]$data <- capture.output(z[[i]])
				}
			}		
		}
		
# ??		advanced$methods <- (x)
# !		advanced$labels <- labels(x)	# reclass (?) these things so it only shows head (initially) and not all?
		advanced$.NAMES <- c(".NAMES", names(advanced))
		advanced <- advanced[c(length(advanced),2:length(advanced)-1)]	# put .NAMES in front
		return( list(advanced, slot.attributes) )
	}
	
	getEnvironment <- function(x) {
		envir <- list()
		envir$.NAMES <- c()			# fill later
		envir$name <-  environmentName(x)
		envir$address <- x
		envir$object.size <- object.size(as.list.environment(x))
		envir$ls <- ls(envir=x)
		envir$env.profile <- env.profile(x)
		envir$.NAMES <- c(".NAMES", names(envir))
		envir <- envir[c(length(envir),2:length(envir)-1)]	# put .NAMES in front
		return(envir)
	}
	
	investigate <- function(obj, depth.now, max.depth) {
		
		# recurses to max object depth and constructs list representation of the object
		
		depth.now <- depth.now + 1
		if (trace) { IM(depth.now, ":Start") }
		temp.depth <- env.size <- 0
		this <- list()
		if (trace) { IM(depth.now, ":Basic") }
		this$basic <- getBasic(obj)
		if (trace) { IM(depth.now, ":Adv") }
		adv <- getAdvanced(obj)
		if (trace) { IM(depth.now, ":Post") }
		this$class <- adv[[1]]
		if (length(adv[[2]]) > 0) { this$slot.attributes <- adv[[2]] }
		if (is.environment(obj)) { 
			if (trace) { IM(depth.now,":Env") }
			this$environment <- getEnvironment(obj)
			env.size <- this$environment$object.size
		} else {
			if (is.ndfl(obj) & length(obj) > 0) {			# recurse through subelements
				if (trace) { IM(depth.now,":ndfl") }
				this$elems <- vector("list", length=length(obj))
				names(this$elems) <- names(obj)
				if (depth.now < max.depth) {	# then we can go one more level
					for (i in 1:length(obj)) {
						if (trace) { IM(depth.now, names(obj)[i]) }
						result <- investigate(obj[[i]], depth.now, max.depth)
						this$elems[[i]] <- result[[1]]					# Returned subdata
						env.size <- env.size + result[[2]]				# Returned env.size
						if (result[[3]] > temp.depth) { temp.depth <- result[[3]] }	# Returned depth
					}
				}
			}
			if (length(this$class$"@slots") > 0) {	# recurse through slots
				if (trace) { IM(depth.now,":slots") }
				this$slots <- vector("list", length=length(this$class$"@slots"))
				names(this$slots) <- names(this$class$"@slots")
				if (depth.now < max.depth) {	# then we can go one more level
					z <- attributes(obj)
					for (i in 1:length(z)) {
						if (names(z)[i] != "class") {	# redundant
							if (trace) IM(depth.now, names(z)[i])
							result <- investigate(z[[i]], depth.now, max.depth)
							this$slots[[i]] <- result[[1]]					# Returned subdata
							env.size <- env.size + result[[2]]				# Returned env.size
							if (result[[3]] > temp.depth) temp.depth <- result[[3]]	# Returned depth
						}
					}
				}
			}
		}
		if (trace) IM(depth.now,":End")
		temp.depth <- temp.depth + 1	# account for 'this' itself (thus min depth always = 1)
		this$basic$this.depth <- depth.now
		this$basic$depth <- temp.depth
		this$basic$env.size <- env.size
		return ( list(this, env.size, temp.depth) )
	}
	
	if (is.na(max.depth)) max.depth <- .Options$expressions	# current recursion limit
	data <- investigate(obj, 0, max.depth)
	return( data[[1]] )
}


apa.names$plots <- c(apa.names$plots, "plot.lastz.pairs")
plot.lastz.pairs <- function(x, maxgap=100, query.name=NULL, subject.name=NULL) {
	
	## where 'x' is the output of /home/apa/local/bin/runLastz in 'pairwise' mode, an 8-column tab-separated text file where columns 1-8 are:
	##  Query Start, Query End, Subject Start, Subject End, Block Length, Block Identity %, Query Gap (Preceding Block), Subject Gap (Preceding Block).
	## 'maxgap' sets the maximum gap size (i.e. 0 <= this_gap <= maxgap) to ignore.  Gaps > maxgap or gaps < 0 will "break" the current plot-block and start a new one.
        ## 'query.name', 'subject.name' are for the plot
        
        qcols <- 2:4
        scols <- 5:7
        ecols <- c(8,"darkorange","purple3")
    
	q.runs <- find.runs((x[,7] >= 0 & x[,7] <= maxgap)+0)
        if (length(q.runs[[length(q.runs)]])==0) q.runs[[length(q.runs)]] <- c()  # remove any NULL final element
        q.runs.0 <- q.runs[names(q.runs)==0]
        q.runs.1 <- q.runs[names(q.runs)==1]
        q.runs.x <- c(list(q.runs.1[[1]][1]:q.runs.1[[1]][2]), lapply(q.runs.1[2:length(q.runs.1)], function(y){ (y[1]-1):y[2] }))
        lost <- setdiff(1:nrow(x), unlist(q.runs.x))
        if (length(lost)>0) message(paste("Warning: some blocks were lost:",paste(lost,collapse=',')))
 	qN <- length(q.runs.x)
        
	s.runs <- find.runs((x[,8] >= 0 & x[,8] <= maxgap)+0)
        if (length(s.runs[[length(s.runs)]])==0) s.runs[[length(s.runs)]] <- c()  # remove any NULL final element
        s.runs.0 <- s.runs[names(s.runs)==0]
        s.runs.1 <- s.runs[names(s.runs)==1]
        s.runs.x <- c(list(s.runs.1[[1]][1]:s.runs.1[[1]][2]), lapply(s.runs.1[2:length(s.runs.1)], function(y){ (y[1]-1):y[2] }))
        lost <- setdiff(1:nrow(x), unlist(s.runs.x))
        if (length(lost)>0) message(paste("Warning: some blocks were lost:",paste(lost,collapse=',')))
 	sN <- length(s.runs.x)
        
        edges <- qblocks <- sblocks <- list()
        for (i in 1:qN) {
            start <- q.runs.x[[i]][1]
            end <- q.runs.x[[i]][length(q.runs.x[[i]])]
            qblocks[[i]] <- c(x[start,1], x[end,2])
            edges[[i]] <- c(x[start,1], x[end,2], x[start,3], x[end,4], mean(c(x[start,1],x[end,2])), mean(c(x[start,3],x[end,4])))  # for block: q start, q end, s start, s end, q mid, s mid
        }
        for (i in 1:sN) {
            start <- s.runs.x[[i]][1]
            end <- s.runs.x[[i]][length(q.runs.x[[i]])]
            sblocks[[i]] <- c(x[start,3], x[end,4])
            edges[[qN+i]] <- c(x[start,1], x[end,2], x[start,3], x[end,4], mean(c(x[start,1],x[end,2])), mean(c(x[start,3],x[end,4])))  # for block: q start, q end, s start, s end, q mid, s mid
        }
        edges <- unique(do.call(rbind,edges))
        qblocks <- do.call(rbind,qblocks)
        qblocks <- cbind(qblocks[order(qblocks[,1]),], 1:qN)
        sblocks <- do.call(rbind,sblocks)
        sblocks <- cbind(sblocks[order(sblocks[,1]),], (qN+2):(qN+sN+1))
        
        xlim <- c(min(x[1,c(1,3)]), max(x[nrow(x),c(2,4)]))
        ylim <- c(0, qN+sN+3)
        q.ymid <- mean(qblocks[,3])
        s.ymid <- mean(sblocks[,3])

        par(mfrow=c(1,2))

        # plot 1: query -> subject
        plot(0, 0, col=0, axes=FALSE, ann=FALSE, xlim=xlim, ylim=ylim)
        rect(x[1,1], ylim[1], x[nrow(x),2], ylim[1]+0.5, col=0, border=1)  # query coverage bar
        
        for (i in 1:qN) {
            rect(qblocks[i,1], qblocks[i,3], qblocks[i,2], qblocks[i,3]+1, col=qcols[i%%3+1], border=qcols[i%%3+1])
            rect(qblocks[i,1], ylim[1], qblocks[i,2], ylim[1]+0.5, col="#00000044", border=NA)
        }
        for (i in 1:sN) {
            rect(sblocks[i,1], sblocks[i,3], sblocks[i,2], sblocks[i,3]+1, col=scols[i%%3+1], border=scols[i%%3+1])
            rect(sblocks[i,1], ylim[2]-0.5, sblocks[i,2], ylim[2], col="#00000044", border=NA)
        }
        for (i in 1:qN) {
            j <- which(edges[,1]==qblocks[i,1] & edges[,2]==qblocks[i,2])
            k <- which(sblocks[,1]==edges[j,3] & sblocks[,2]==edges[j,4])
            segments(edges[j,5], qblocks[i,3]+1, edges[j,6], sblocks[k,3], col=ecols[i%%3+1])
        }
        mtext(paste(query.name,"coverage on",subject.name), 1, 0)
        mtext(paste(subject.name,"coverage on",query.name), 3, 0)
        mtext(query.name, 2, 0, at=q.ymid)
        mtext(subject.name, 2, 0, at=s.ymid)

        
        # plot 2: subject -> query
        plot(0, 0, col=0, axes=FALSE, ann=FALSE, xlim=xlim, ylim=ylim)
        rect(x[1,1], ylim[1], x[nrow(x),2], ylim[1]+0.5, col=0, border=1)  # query coverage bar
 #       rect(x[1,3], ylim[2]-0.5, x[nrow(x),4], ylim[2], col=0, border=1)  # subject coverage bar
        
        for (i in 1:qN) {
            rect(qblocks[i,1], qblocks[i,3], qblocks[i,2], qblocks[i,3]+1, col=qcols[i%%3+1], border=qcols[i%%3+1])
            rect(qblocks[i,1], ylim[1], qblocks[i,2], ylim[1]+0.5, col="#00000044", border=NA)
        }
        for (i in 1:sN) {
            rect(sblocks[i,1], sblocks[i,3], sblocks[i,2], sblocks[i,3]+1, col=scols[i%%3+1], border=scols[i%%3+1])
            rect(sblocks[i,1], ylim[2]-0.5, sblocks[i,2], ylim[2], col="#00000044", border=NA)
        }
        for (i in 1:qN) {
            j <- which(edges[,1]==qblocks[i,1] & edges[,2]==qblocks[i,2])
            k <- which(sblocks[,1]==edges[j,3] & sblocks[,2]==edges[j,4])
            segments(edges[j,5], qblocks[i,3]+1, edges[j,6], sblocks[k,3], col=ecols[i%%3+1])
        }
        mtext(paste(query.name,"coverage on",subject.name), 1, 0)
        mtext(paste(subject.name,"coverage on",query.name), 3, 0)
        mtext(query.name, 2, 0, at=q.ymid)
        mtext(subject.name, 2, 0, at=s.ymid)
        
}


apa.names$dev <- c(apa.names$dev, "empty.list")
empty.list <- function(lst) { 
	
	recurse <- function(obj, depth.now, max.depth) {
		
		# recurses through input list and destroys data, but not list structure or names
		
		depth.now <- depth.now + 1
		if (trace) { IM(depth.now, ":Start") }
		temp.depth <- env.size <- 0
		this <- list()
		if (trace) { IM(depth.now, ":Basic") }
		this$basic <- getBasic(obj)
		if (trace) { IM(depth.now, ":Adv") }
		adv <- getAdvanced(obj)
		if (trace) { IM(depth.now, ":Post") }
		this$class <- adv[[1]]
		if (length(adv[[2]]) > 0) { this$slot.attributes <- adv[[2]] }
		if (is.ndfl(obj) & length(obj) > 0) {			# recurse through subelements
			if (trace) { IM(depth.now,":ndfl") }
			this$elems <- vector("list", length=length(obj))
			names(this$elems) <- names(obj)
			if (depth.now < max.depth) {	# then we can go one more level
				for (i in 1:length(obj)) {
					if (trace) { IM(depth.now, names(obj)[i]) }
					result <- recurse(obj[[i]], depth.now, max.depth)
					this$elems[[i]] <- result[[1]]					# Returned subdata
					env.size <- env.size + result[[2]]				# Returned env.size
					if (result[[3]] > temp.depth) { temp.depth <- result[[3]] }	# Returned depth
				}
			}
		} else {
			m <- mode(obj)
			obj <- vector(mode, length=0)    ### WILL NOT WORK LIKE THIS
		}
		if (trace) { IM(depth.now,":End") }
		temp.depth <- temp.depth + 1	# account for 'this' itself (thus min depth always = 1)
		this$basic$this.depth <- depth.now
		this$basic$depth <- temp.depth
		this$basic$env.size <- env.size
		return ( list(this, env.size, temp.depth) )
	}
	
	emptied <- recurse(lst)
	return(emptied)
}


#####  THE FUNCTIONS BELOW ARE STILL UNDER CONSTRUCTION  #####

# source("S:/Genomics/Molbio_Users/APA/R_Things/cluster_kit.R")

apa.names$dev <- c(apa.names$dev, "tables2faticlone")
tables2faticlone <- function(lst, column=1, na.rm=FALSE, names=NULL, id.conv=NULL) {
	
	## assumes excel-ready list of tables, with gene IDs consistently in column 'column'
	## extracts all ids into 2-col matrix; col1 = id col2 = table name (from names(lst))
	## ready for use in /home/apa/local/bin/FatiClone
	## 'column' can also be "rownames"
	## 'na.rm' removes not only NA but also entries with no ID (including post-conversion, if converting IDs)
	## if 'names' is specified it will supplant names(lst)
	## if 'id.conv' is specified, must be 2-col matrix/df with incoming ids in col1 and outgoing ids in col2.  Outgoing IDs should be FatiClone-compatible.
	
	if (is.null(names)) { names <- names(lst) }
	if (column == "rownames") {
		fc <- sapply(1:length(lst), function(x){cbind(rownames(lst[[x]]),names[x])})
	} else {
		fc <- sapply(1:length(lst), function(x){cbind(lst[[x]][,column],names[x])})
	}
	fc <- do.call(rbind, fc)
	if (!is.null(id.conv)) {
		fc[,1] <- id.conv[match(fc[,1],id.conv[,1]),2]
	}
	if (na.rm) { fc <- fc[real(fc[,1],logical=TRUE),] }
	fc
}


apa.names$dev <- c(apa.names$dev, "generate.GO.lists")
generate.GO.lists <- function(mat, conditions_MAYBE, present=NULL, bkg="") {

}


apa.names$general <- c(apa.names$general, "listDims")
listDims <- function(obj, dim.int=TRUE, max.depth=NA) {
	
	## Provides a view of the dimensions of a list object.
	## "internal.dims=T" show dimensions of non-list objects in the list structure.
	## "max.depth" sets max recursion depth.  "0" prevents recursion.  "NA" allows unlimited recursion.
	
	investigate <- function(obj, depth.now, max.depth) {
		
		# recurses to max list depth and constructs list representation of the list
		depth.now <- depth.now + 1
		
		dims <- vector("list", length=length(obj))
		for (i in 1:length(obj)) {
			if (is.nlv(obj[[i]])) {
				if (dim.int) {
					dims[[i]] <- length(obj[[i]])
					names(dims)[i] <- "vector"
				}
			} else if (is.matrix(obj[[i]])) {
				if (dim.int) {
					dims[[i]] <- dim(obj[[i]])
					names(dims)[i] <- "matrix"
				}
			} else if (is.array(obj[[i]])) {
				if (dim.int) {
					dims[[i]] <- dim(obj[[i]])
					names(dims)[i] <- "array"
				}
			} else if (is.data.frame(obj[[i]])) {
				if (dim.int) {
					dims[[i]] <- dim(obj[[i]])
					names(dims)[i] <- "data.frame"
				}
			} else if (is.list(obj[[i]])) {			# recurse through subelements
				if (depth.now < max.depth) {	# then we can go one more level
					dims[[i]] <- investigate(obj[[i]], depth.now, max.depth)
				} else {
					IM("Max recurson depth",max.depth,"reached!")
				}
				names(dims)[i] <- paste("list", length(obj[[i]]))
			} else {	# some custom class?
				if (dim.int) {
					dims[[i]] <- ternary(is.null(dim(obj[[i]])), length(obj[[i]]), dim(obj[[i]]))
					names(dims)[i] <- class(obj[[i]])
				}
			}
		}
		return (dims)
	}
	
	if (is.na(max.depth)) { max.depth <- .Options$expressions }	# current recursion limit
	dims <- investigate(obj, 0, max.depth)
	return(dims)
}


apa.names$general <- c(apa.names$general, "aggregate.list")
aggregate.list <- function(lst, FUN, max.depth=NA) {
	
	## aggregate() for use with lists.  At this time, list elements may ONLY be vectors (including other lists).
	## FUN is the merging function, e.g. sum, mean, min, etc.  DO NOT QUOTE.
	## "max.depth" sets max recursion depth.  "0" prevents recursion.  "NA" allows unlimited recursion.
	
	recurse <- function(lst, depth.now, max.depth) {
		depth.now = depth.now + 1
		
		## Merge namespace redundancies at this level
		x <- which(!duplicated(names(lst)))
		y <- which(duplicated(names(lst)))
		if (length(y) > 0) {	# named elements exist to be combined
			for (i in 1:length(y)) {
				first <- which(names(lst)[x] == names(lst)[y[i]])
				lst[[first]] <- c(lst[[first]], lst[[y[i]]])	# add to first element having same name
			}
			lst <- lst[-y]	# remove duplicates
		}
		
		## Descend to deeper levels (if any)
		for (i in 1:length(lst)) { 
			if (is.ndfl(lst[[i]])) {
				if (depth.now < max.depth) {	# then we can go one more level
					recurse(lst[[i]], depth.now, max.depth)
				} else {
					IM("Max recurson depth",max.depth,"reached!")
				}
			} else {	# hopefully a vector??
				x <- which(!duplicated(names(lst[[i]])))
				y <- which(duplicated(names(lst[[i]])))
				z <- unique(names(lst[[i]][y]))
				if (length(z) > 0) {	# named elements exist to be combined
					for (i in 1:length(z)) {
						w <- which(names(lst[[i]])[y] == z[i])
						first <- which(names(lst[[i]])[x] == z[i])
						lst[[i]][first] <- FUN(c(lst[[i]][first], lst[[i]][w]))	# merge (by FUN) with first element having same name
					}
					lst <- lst[[i]][-y]	# remove duplicates
				}
			}
		}
	}
	
	if (is.na(max.depth)) { max.depth <- .Options$expressions }	# current recursion limit
	heads <- recurse(lst, 0, max.depth)
	print(heads, quote=FALSE)
}


apa.names$general <- c(apa.names$general, "invert.list2")
invert.list2 <- function(list1, dup.rm=TRUE, empty.rm=TRUE, na.rm=FALSE, ignore.names=FALSE, verbose=FALSE) { 
	
	## Inverts a list. The list must have names.  Each element in the list must be:
	##	1. A named list,
	##	2. A named vector of any type (then specify "named=T"),
	##	3. An unnamed character vector.
	## Inverted list will have one element for each unique sublist name found in the original list (or vector element).
	## Inverted list sublists will have length = length input list.
	## "dup.rm" controls removal of duplicate elements in the inverted list, if the inverted list elements are vectors of length > 1.
	## "empty.rm" controls removal of empty elements in the inverted list.  Unnecessary if elements are vectors.
	## "na.rm" controls removal of NA elements in the inverted list or sublists.
	## "ignore.names=T" will ignore any vector names and invert by vector values instead.  Irrelevant if list elements are lists or unnamed vectors.
	## "verbose=T" reports what the function is doing from step to step (for off-the-cuff timing of large list processing)
	## 
	## Example 1:
	##	list( X=list(A=1, B=2, C=3), Y=list(A=4, B=5, C=6), Z=list(A=7, B=8, C=9) )
	## becomes
	##	list( A=list(X=1, Y=4, Z=7), B=list(X=2, Y=5, Z=8), C=list(X=3, Y=6, Z=9) )
	## 
	## Example 2:
	##	list( X=c(1, 2, 3), Y=c(4, 5, 6), Z=c(7, 8, 9) )	: all vectors having the names c("A","B","C")
	## becomes
	##	list( A=c(1, 4, 7), B=c(2, 5, 8), C=c(3, 6, 9) ) : all vectors having the names c("X","Y","Z")
	## 
	## Example 3:
	##	list( X=c("A", "B", "C"), Y=c("A", "B", "D"), Z=c("A", "C", "E") )
	## becomes
	##	list( A=c("X", "Y", "Z"), B=c("X", "Y"), C=c("X", "Z"), D=c("Y"), E=c("Z") )
	
	# prefilter list1 (get rid of uninformative elements prior to anything else)
	if (verbose) { IM("Prefiltering...\n") }
	list1 <- list1[which(listLengths(list1) > 0)]
	if (na.rm) {
		drop1 <- which(is.na(names1))
		if (length(drop1) > 0) { list1 <- list1[-drop1] }
	}
	if (empty.rm) {
		empties1 <- which(listLengths(list1) == 0)
		if (length(empties1) > 0) { list1 <- list1[-empties1] }
	}
	
	# list names
	if (verbose) { IM("Testing list...\n") }
	names1 <- sort(unique(names(list1)))
	if (is.null(names1)) { 
		stop("Input list must be named!\n") 
	} else if (any(names1 == "")) {			# only some list elements are named
		stop("Some input list elements are not named!  Stopping.\n")
	}
	
	# test element consistency
	nlv <- sapply(list1, simplify=TRUE, is.nlv)
	ndfl <- sapply(list1, simplify=TRUE, is.ndfl)
	
	# get names for inverted list
	if (verbose) { IM("Getting sublist names...\n") }
	if (all(nlv)) {
		go.list <- FALSE
		
		# get sublist names
		if (is.null(names(list1[[1]]))) {	# unfortunately cannot do names(unlist(list1)); that will automatically generate names
			if (!ignore.names) { IM("Some subelements do not have names!  Setting 'ignore.names = TRUE'...") }
			ignore.names=TRUE
			names2 <- as.character(sort(unique(unlist(list1))))
		} else {
			names2 <- sort(unique(names(unlist(list1))))
			if (is.null(names2)) {
				if (!ignore.names) { IM("Subelements are unnamed!  Setting 'ignore.names = TRUE'...") }
				ignore.names=TRUE
				names2 <- as.character(sort(unique(unlist(list1))))
			} else if (any(names2 == "")) {		# only some subelements are named
				if (!ignore.names) { IM("Some subelements do not have names!  Setting 'ignore.names = TRUE'...") }
				ignore.names=TRUE
				names2 <- as.character(sort(unique(unlist(list1))))
			}
		}
	} else if (all(ndfl)) {
		go.list <- TRUE
		
		# get sublist names
		names2 <- sort(unique(unlist(lapply(list1, names))))
		if (is.null(names2)) {
			stop("Sublist elements must be named!\n")
		} else if (any(names2 == "")) {			# only some sublist elements are named
			stop("Some sublist elements are not named!  Stopping.\n")
		}
	} else {
		stop("List elements of inconsistent or unsupported type: must be all (non-list) vectors or all (non-data-frame) lists!\n")
	}
	
	# create inverted list
	if (verbose) { IM("Creating inverted list frame...\n") }
	list2 <- vector("list", length=length(names2))
	names(list2) <- names2
	if (go.list) {
		for (i in 1:length(list2)) {
			list2[[i]] <- vector("list", length=length(names1))
			names(list2[[i]]) <- names1
		}
	}
	
	# fill inverted list
	if (verbose) { IM("Filling inverted list frame...\n") }
	if (go.list) {
		for (n2 in names2) {
			empties <- c()
			for (i in 1:length(list1)) {
				n1 <- names1[i]
				if (!is.null(list1[[n1]][[n2]])) { 
					list2[[n2]][[n1]] <- c(list2[[n2]][[n1]], list1[[n1]][[n2]]) 
				} else {
					empties <- c(empties, i)
				}
			}
			if (empty.rm & length(empties) > 0) { list2[[n2]] <- list2[[n2]][-empties] }
		}
	} else {
		for (i in 1:length(list1)) {
			if (ignore.names) {
				xo <- match(list1[[i]], names2)
			} else {
				xo <- match(names(list1[[i]]), names2)
			}
			if (any(is.na(xo))) { stop("Broken element assignments!\n") }
			for (x in 1:length(xo)) { list2[[xo[x]]] <- c(list2[[xo[x]]], names1[i]) }
		}
	}
	
	# postfilter list2
	if (verbose) { IM("Postfiltering...\n") }
	if (na.rm) {
		drop2 <- which(is.na(names2))
		if (length(drop2) > 0) { list2 <- list2[-drop2] }
	}
	if (empty.rm) {
		empties2 <- which(listLengths(list2) == 0)
		if (length(empties2) > 0) { list2 <- list2[-empties2] }
	}
	if (na.rm | empty.rm) {
		for (i in 1:length(list2)) {
			if (go.list) {
				
### MUST ADD SUBLIST ELEMENT HANDLING
				
				if (na.rm) {
					if (ignore.names) {
						drop <- which(is.na(list2[[i]]))
					} else {
						drop <- which(is.na(names(list2[[i]])))
					}
					if (length(drop) > 0) { list2[[i]] <- list2[[i]][-drop] }
				}
				if (empty.rm) {
					empties <- which(listLengths(list2[[i]]) == 0)
					if (length(empties) > 0) { list2[[i]] <- list2[[i]][-empties] }
				}
				if (dup.rm) { list2[[i]] <- list2[[i]][-duplicated(list2[[i]])] }
			} else {
				if (na.rm) {
					if (ignore.names) {
						drop <- which(is.na(list2[[i]]))
					} else {
						drop <- which(is.na(names(list2[[i]])))
					}
					if (length(drop) > 0) { list2[[i]] <- list2[[i]][-drop] }
				}
				if (dup.rm) { list2[[i]] <- list2[[i]][-duplicated(list2[[i]])] }
			}
		}
	}

	return(list2)
}


apa.names$general <- c(apa.names$general, "matchify")
matchify <- function(distmat, fast=TRUE, verbose=FALSE) {
	## distmat must have 4 columns = PSmGS, PSmGE, PEmGS, PEmGE
	signmat <- sign(distmat) 
    if (nrow(signmat) > 1) {
        anymatch <- apply(signmat[,2:3], 1, FUN=function(x){all(x==c(-1,1))})
    } else {
        anymatch <- all(signmat[,2:3]==c(-1,1))
    }
	results <- list(HITS=c(), NNS=c())   # at the moment, no reporting for match type, overlap bp, etc (thus "fast=TRUE" default)
    if (verbose) { IM("matchify: 1") }
    if (fast) {
        hits <- anymatch
    } else {
        if (verbose) { IM("matchify: 2") }
        exact <- apply(signmat[anymatch,c(1,4)], 1, FUN=function(x){all(x==c(0,0))})
        eclipse.p <- apply(signmat[anymatch,c(1,4)], 1, FUN=function(x){all(x[1] %in% 0:1 & x[2] %in% -1:0)})
        eclipse.g <- apply(signmat[anymatch,c(1,4)], 1, FUN=function(x){all(x[1] %in% -1:0 & x[2] %in% 0:1)})
        overlap.5 <- apply(signmat[anymatch,c(1,4)], 1, FUN=function(x){all(x==c(-1,-1))})
        overlap.3 <- apply(signmat[anymatch,c(1,4)], 1, FUN=function(x){all(x==c(1,1))})
        eclipse.p[exact] <- FALSE  # remove any exact hits
        eclipse.g[exact] <- FALSE  # remove any exact hits
        hits <- apply(cbind(eclipse.p,eclipse.g,overlap.5,overlap.3), 1, any)
    }
    if (verbose) { IM("matchify: 3") }
    if (any(hits)) {
        results$HITS <- which(hits)
    } else {
        neighbor.5 <- which(rowSums(signmat) == -4)
        neighbor.3 <- which(rowSums(signmat) == 4)
        nn.5 <- nn.3 <- c()
        if (verbose) { IM("matchify: 4") }
        if (length(neighbor.5) > 0) {
            dists.5 <- abs(distmat[neighbor.5,2])
            nn.5 <- neighbor.5[dists.5==min(dists.5)]
            nn.5 <- nameless(cbind(nn.5, rep(min(dists.5), length(nn.5))))
            if (verbose) { IM("matchify: 5") }
        }
        if (length(neighbor.3) > 0) {
            if (verbose) { IM("matchify: 6") }
            dists.3 <- distmat[neighbor.3,3]
            nn.3 <- neighbor.3[dists.3==min(dists.3)]
            nn.3 <- nameless(cbind(nn.3, rep(min(dists.3), length(nn.3))))
            if (verbose) { IM("matchify: 7") }
        }
        results$NNS <- list(NN5=nn.5, NN3=nn.3)
        if (verbose) { IM("matchify: 8") }
    }
	return(results)
}
