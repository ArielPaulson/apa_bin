

apa.names$bio.seq <- c(apa.names$bio.seq, "cisModScan")
cisModScan <- function(bed, motifsets, Nmotif=c(2,10), maxw=NULL) {
    
    stop("cisModScan() is under construction!\n")
    
    ## 'bed' is a 6-col BED file (as a data frame); scores in col 5 may be replaced by 1 unless 'interpret' is set to 'minscore' or 'maxscore'.
    ##  - each BED row corresponds to a motif position (e.g. from FIMO).
    ##  - IDs in col 4 should be as systematic wherever possible.
    ## 'motifsets' is a LIST OF LISTS, each sub-list being a list of factors for each motif in the 'bed' dataframe of the original cisModScan() call:
    ##  - thus, each sub-list must have 1 vector per unique motif ID in 'bed'.  Most vectors will probably contain only one motif name.
    ##  - vectors for variable-factor motifs, e.g. MEME motifs interpreted by Tomtom, may contain any number of motif names, including none.
    ##  - a minimum of one sub-list is required for 'motifsets'.  Additional ones may be given for alternate motif-evaluation schemes, for instance,
    ##    the first sub-list = matrix-specific ("Sox5_Q4"), the second sub-list = factor-specific ("Sox5"), and a third sub-list = family-specific ("Sox").
    ##    this enables module interpretation at varying degrees of specificity.
    ## 'Nmotif' indicates the minimum and maximum number of spatially disjoint motif instances per module (must be contained by c(1,Inf))
    ## For chipseq experiments, if peak coordinates are given instead of genomic, then scans can be run in 1-module-per-peak mode.  Otherwise, max module width 'maxw' required.
    
    if (is.null(names(motifsets))) names(motifsets) <- 1:length(motifsets)
    colnames(bed) <- qw(SEQ,START,END,ID,SCORE,STR)
    undermin <- overmax <- 0
    ncb <- ncol(bed)
    useq <- unique(bed[,1])
    byseq <- lapply(mat.split(bed[,2:ncb], bed[,1]), function(x) x[order(x[,1],x[,2]),] )
    
    if (is.null(maxw)) {   # one-module-per-sequence mode
        ok1 <- which(sapply(byseq,nrow)>=Nmotif[1])
        undermin <- undermin + (length(byseq)-length(ok1))
        byseq <- byseq[ok1]  # drop those which have < minimum motifs at all
        if (length(byseq)>0) {
            for (i in 1:length(byseq)) {
                nr <- nrow(byseq[[i]])
                separ <- outer(byseq[[i]][,2], byseq[[i]][,1], "-")
                ncs <- ncol(separ)
                block <- (ncs+1) - apply(separ[,ncs:1]>0, 1, function(x) which(x)[1] )
                ## unique values of 'block' indicate unique merged-motif footprints
                ## the 'block' vector indicates which motif instances co-occupy each footprint
                byseq[[i]] <- cbind(byseq[[i]], BLOCK=block)
            }
            ok2 <- which(sapply(byseq,function(x){luniq(x$BLOCK)>=Nmotif[1]}))
            undermin <- undermin + (length(byseq)-length(ok2))
            byseq <- byseq[ok2]  # drop those which have < minimum blocks
            ok3 <- which(sapply(byseq,function(x){luniq(x$BLOCK)<=Nmotif[2]}))
            overmax <- length(byseq)-length(ok3)
            premod <- byseq[ok3]  # drop those which have > maximum blocks
        } else {
            message("No sequences with enough motifs to form modules: ",undermin," under minimum, ",overmax,"over maximum.\n")
            return(NULL)
        }
    } else {   # sliding window mode
        premod <- c()  # pending
        
        
        
        ## ########## WORKING HERE ##########
        
        
        
    }
    
    if (length(premod)>0) {
        modules <- new.list(1:length(premod))
        for (p in 1:length(premod)) {
            block.ids <- split(premod[[p]]$ID, premod[[p]]$BLOCK)
            lbi <- length(block.ids)
            factors <- new.list(names(motifsets), elem=new.list(1:lbi))
            for (s in 1:length(motifsets)) {
                block.ids.s <- block.ids
                for (b in 1:lbi) {
                    block.ids.s <- match(block.ids[[b]], names(motifsets[[s]]))
                    f <- motifsets[[s]][block.ids.s]
                    n <- names(f)[listLengths(f)==0]
                    factors[[s]][[b]] <- sort(unique(c(n,unlist(f))))
                }
            }
            width <- premod[[p]][nr,2] - premod[[p]][1,1] + 1   # observed module width
            modules[[p]] <- list(MOD=premod[[p]], FAC=factors, WID=width)
        }
    } else {
        message("No sequences with enough motifs to form modules: ",undermin," under minimum, ",overmax,"over maximum.\n")
        return(NULL)
    }	
    
    modules
}


apa.names$bio.seq <- c(apa.names$bio.seq, "cisModScan.interpret")
cisModScan.interpret <- function(modules, interpret=c("ordered","enumerated","unique"), evaluate=c("prevalence","max.score","min.score")) {
     
    stop("cisModScan.interpret() is under construction!\n")
   
    ## 'modules' is the output of a cisModScan() run
    ## As each motif footprint in a module may be occupied by > 1 similar motifs (with differing factors), it is important to select the best interpretation for each module.
    ##  This is done by generating the set of all possible "interpretations" for each module, then "evaluating" the set of all module interpretations to find the best ones.  
    ##  Then, each module will be annotated with the globally-best interpretation from its own set.  See 'interpret' and 'evaluate' arguments below.
    ## 'interpret' controls module interpretation:
    ##  - 'ordered' retains spatial arrangement of factors (max info)
    ##  - 'enumerated' retains number but not arrangement of factors (med info)
    ##  - 'unique' retains unique factors but no enumeration or spatial arrangement (min info)
    ## 'evaluate' controls ranking of interpretations:
    ##  - 'prevalence' ranks the interpretations by prevalence.
    ##  - 'max.score' and 'min.score' ranks interpretations by median score (col 5 of 'bed' given to cisModScan()) and will prefer higher or lower scores, respectively.
    
    
    ## FIXME: where are the scores coming from???
    
    interpret <- match.arg(interpret)
    evaluate <- match.arg(evaluate)
    if (evaluate != "prevalence") stop("'evaluate' currently only supports mode 'prevalence'!\n")
    interps <- data.frame(qw(ordered,enumerated,unique),1:3)
    evals <- data.frame(qw(prevalence,max.score,min.score),1:3)
    interpret <- interps[which(interps[,1]==interpret),2]  # change to numeric
    evaluate <- evals[which(evals[,1]==evaluate),2]        # change to numeric
    
    unknown <- 0
    lmod <- length(modules[[1]]$FAC)
    
    interps <- interps2 <- interps3 <- interps.best <- mod.fet.best <- ipm <- ranked <- new.list(names(modules[[1]]$FAC))
    for (s in 1:lmod) {
        interps[[s]] <- new.list(names(modules))
        if (interpret == 1) {   # spatially-ordered factors
            for (m in 1:length(modules)) {
                if (length(modules[[m]]$FAC[[s]])>0) {
                    x <- combine.names(modules[[m]]$FAC[[s]], dataframe=TRUE)
                    interps[[s]][[m]] <- apply(x, 1, paste, collapse="--")
                } else {
                    interps[[s]][[m]] <- c()
                    unknown <- unknown + 1
                }
            }
        } else if (interpret == 2) {  # enumerated factors
            for (m in 1:length(modules)) {
                if (length(modules[[m]]$FAC[[s]])>0) {
                    x <- combine.names(modules[[m]]$FAC[[s]], dataframe=TRUE)
                    interps[[s]][[m]] <- sapply(apply(x, 1, table), function(y) paste(paste(names(y),y,sep="|"), collapse=" ") )
                } else {
                    interps[[s]][[m]] <- c()
                    unknown <- unknown + 1
                }
            }
        } else if (interpret == 3) {  # unique factors
            for (m in 1:length(modules)) {
                if (length(modules[[m]]$FAC[[s]])>0) {
                    x <- combine.names(modules[[m]]$FAC[[s]], dataframe=TRUE)
                    interps[[s]][[m]] <- apply(x, 1, function(y) paste(sort(unique(y)),collapse=",") )
                } else {
                    interps[[s]][[m]] <- c()
                    unknown <- unknown + 1
                }
            }
        }
        interps[[s]] <- interps[[s]][listLengths(interps[[s]])>0]
        interps2[[s]] <- sort(table(unlist(interps[[s]])), decreasing=T)	# modules per interpretation
        ipm[[s]] <- listLengths(interps[[s]])   # interpretations per module
        
        ranked[[s]] <- interps2[[s]]  # fix later, when we have scores figured out
        interps.best[[s]] <- new.list(names(interps[[s]]))
        
        if (evaluate == 1) {   # most-prevalent
            for (i in 1:length(interps[[s]])) {
                ranks <- match(interps[[s]][[i]], names(ranked[[s]]))
                interps.best[[s]][[i]] <- names(ranked[[s]])[min(ranks)]   # smallest index number = most-prevalent interpretation
            }
            interps.best[[s]] <- unlist(interps.best[[s]])
        } else if (evaluate == 2) {  # highest score
        } else if (evaluate == 3) {  # lowest score
        }
        interps3[[s]] <- sort(table(interps.best[[s]]), decreasing=T)	# final modules per interpretation
    }
    
    list(modules=interps.best, ipm=ipm, mpi.initial=interps2, mpi.final=interps3)
}


apa.names$bio.seq <- c(apa.names$bio.seq, "cisModScan.compare")
cisModScan.compare <- function(x1, x2) {
    
    stop("cisModScan.compare() is under construction!\n")
    
    ## where x1, x2 are outputs from two runs of cisModScan()
    
    par(mfrow=c(1,3))
    dhist(list(sapply(cmout, function(x) x$WID )))
    dhist(list(sapply(cmout, function(x) log2(length(x$FAC)) )))
    dhist(list(sapply(cmout, function(x) log2(rev(cumprod(listLengths(x$FAC)))[1]) )))

    mod.fet <- matrix(0, length(interps2[[1]]), 4, F, list(names(interps2[[1]]),qw(FG.W,FG.WO,BG.W,BG.WO)))
    for (k in 1:length(interps2[[1]])) {
        mod.fet[k,1:2] <- c( interps2[[1]][[k]], npeaks[3,1]-interps2[[1]][[k]] )
        w <- which(names(interps2[[2]])==rownames(mod.fet)[k])
        if (length(w)==1) {
            mod.fet[k,3:4] <- c( interps2[[2]][[w]], npeaks[3,2]-interps2[[2]][[w]] )
        } else {
            mod.fet[k,3:4] <- c( 0, npeaks[3,2] )
        }
    }
    mod.fet <- mod.fet[order(mod.fet[,1],decreasing=T),]
    mod.fet <- fisherize(mod.fet)
    
    ## ######## WORKING HERE ########
    
}	
