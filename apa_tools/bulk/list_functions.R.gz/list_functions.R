

apa.names$general <- c(apa.names$general, "listFilter")
listFilter <- function(list, regexp, keep=TRUE, fixed, noempty=FALSE) { 
	
	## Filters a list of atomics or vectors for anything matching a regular expression (or vector of regular expressions)
	## "regexp" is a single reg exp, or a vector of them.
	## "keep" indicates what to do with matched elements, a la grep's "invert" parameter:
	## keep = T: retains ONLY matches (default)
	## keep = F: removes matches; retains non-matches
	## "fixed" is a logical or vector of logicals, length=length(regexp), which toggles the grep "fixed" parameter for each regexp
	## "noempty" switch, if TRUE, will block removal of subelements ONLY if they are ALL flagged for removal.
	
	if (length(regexp) == 0) stop("Mandatory parameter 'regexp' must contain a regular expression!\n")
	if (length(fixed) == 0) stop("Mandatory parameter 'fixed' must contain one or more logicals!\n")
	
	filterfunc <- function(elem, expressions, fixed, keep) {
		
		# each expression gets its own element of 'matches'.  Each element contains match the indices for subelement(s) of "elem".
		# 'hits' contains all subelements that matched anything.
		
		idx <- 1:length(expressions)
		if (length(fixed == 1)) fixed <- rep(fixed, length(idx))
		
		matches <- lapply(idx, FUN=function(i,x,exp,fix){ grep(exp[i],x,fixed=fix[i]) }, elem, expressions, fixed )
		hits <- unique(unlist(matches))
		if (length(hits) == 0) {
			if (keep == T) {
				ternary ( noempty == T, results <- elem, results <- NA )
			} else {
				results <- elem
			}
		} else {
			if (keep == T) {
				results <- elem[hits]
			} else {
				ternary ( noempty == T & length(hits) == length(elem), results <- elem, results <- elem[-hits] )
			}
		}
		return(results)
	}
	
	v <- lapply(list, FUN=filterfunc, regexp, fixed, keep)
	return(v)
}


apa.names$general <- c(apa.names$general, "listMerge")
listMerge <- function(list1, list2, mode="union", na.rm=TRUE, sorting=FALSE) {
	
	## Returns a single named list which is produced from two NAMED lists.  Lists may contain ONLY vectors and atoms.
	##  List elements with the same name are operated on to produce the output element.  Operation is specified with 'mode'.
	## 'na.rm' = NA exclusion
	## 'sorting' = apply alphabetical sorting to each vector in the output list?
	## 'mode' determines the set operation to use:
	## Modes returning sets/subsets:
	## Mode = "union": nonredundant union (proper union).
	## Mode = "total": redundant union (concatenation).
	## Mode = "intersect": intersection (also nonredundant).
	## Mode = "disjunc": disjunction (union - intersection)
	## Mode = "setdiff": set diff as list1 - list2.
	## Modes returning logicals (T/F):
	## Mode = "equal": is list1 == list2 ? (redundancy ignored)
	## Mode = "requal": is list1 == list2 ? (redundancy NOT ignored)
	## Mode = "any": is intersect(list1,list2) nonzero ?
	## Mode = "subset": is list2 a proper subset of list1 ?
	
	nametest <- function(listX) { 
		x <- c(length(listX[[1]])>0, length(listX[[2]])>0)
		return( c(x, sum(x)) ) 
	}
	cleanup <- function(vecX, na.rm, sorting) {
		if (is.null(vecX) == T) { 
			return(vecX) 
		} else {
			vecY <- c()
			ternary (na.rm == TRUE, vecY <- vecX[which(!is.na(vecX))], vecY <- vecX)
			if (length(vecY) == 0) {
				return(c())
			} else {
				if (sorting == TRUE) { vecY <- sort(vecY, na.last=TRUE) }
			}
			return(vecY)
		}
	}
	
	names1 <- names(list1)
	names2 <- names(list2)
	y <- nametest(c(names1, names2))
	if (y[3] == 2) {	# both have names; intended situation
		# pass
	} else if (y[3] == 0) {	# neither have names; use indices instead (cheap/risky... but you should have named the lists!)
		names(list1) <- names1 <- 1:length(list1)
		names(list2) <- names2 <- 1:length(list2)
	} else {		# only one has names: can't connect any element of list 1 to list 2
		stop( "Only one list has names: cannot continue!" )	# die
	}
	names3 <- union(names1, names2)
	
	if (mode == "union") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) { 
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- union( list1[[name]], list2[[name]] )
			} else {
				z <- x[[which(y == 1)[1]]]	# if only one usable element, just return it
			}
			w <- cleanup(z, na.rm, sorting); return(w)
		}
		
	} else if (mode == "total") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- c( list1[[name]], list2[[name]] )
			} else {
				z <- x[[which(y == 1)[1]]]	# if only one usable element, just return it
			}
			w <- cleanup(z, na.rm, sorting); return(w)
		}
		
	} else if (mode == "intersect") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- intersect( list1[[name]], list2[[name]] )
			}
			w <- cleanup(z, na.rm, sorting); return(w)
		}
		
	} else if (mode == "disjunc") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- union( list1[[name]], list2[[name]] )[ -intersect( list1[[name]], list2[[name]] ) ]
			} else {
				z <- x[[which(y == 1)[1]]]	# if only one usable element, just return it
			}
			w <- cleanup(z, na.rm, sorting); return(w)
		}
		
	} else if (mode == "setdiff") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list(L1=list1[[name]], L2=list2[[name]])
			y <- nametest(x)
			if (y[3] == 2) {
				z <- setdiff( list1[[name]], list2[[name]] )
			} else if (y[1] == 1) {
				z <- list1[[name]]		# if list1 had the only one usable element, just return it
			} else {
				z <- c()			# if list2 had the only one usable element, return nothing
			}
			w <- cleanup(z, na.rm, sorting); return(w)
		}
		
	} else if (mode == "equal") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- setequal( list1[[name]], list2[[name]] )
			}
			return(z)
		}
		
	} else if (mode == "requal") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- setequal( list1[[name]], list2[[name]] )
			}
			if (z == TRUE) {
				ternary ( length(list1[[name]]) == length(list2[[name]]), return(TRUE), return(FALSE) )
			} else {
				return(z)
			}
		}
		
	} else if (mode == "any") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- intersect( list1[[name]], list2[[name]] )
			}
			if (is.null(z)) {
				return(z)
			} else {
				ternary (length(z) == 0, return(FALSE), return(TRUE))
			}
		}
		
	} else if (mode == "subset") {
		
		FUNC <- function(name, list1, list2, na.rm, sorting) {
			x <- list( L1=list1[[name]], L2=list2[[name]] )
			y <- nametest(x)
			if (y[3] == 2) {
				z <- setdiff( list2[[name]], list1[[name]] )
			}
			if (is.null(z)) {
				return(z)
			} else {
				ternary (length(z) == 0, return(TRUE), return(FALSE))
			}
		}
		
	} else {
		
		stop( paste("Unknown mode value '",mode,"'!  Nothing to do.",sep="") )
		
	}
	
	list3 <- lapply(names3, FUN=FUNC, list1, list2, na.rm, sorting)
	names(list3) <- names3
	return(list3)
}


apa.names$general <- c(apa.names$general, "list.concatenate")
list.concatenate <- function(list1, names.delim=".") { 
	
	## concatenates a list of lists into a single-level list
	## The list, and all sub-lists, MUST HAVE NAMES
	
	list2 <- new.list(paste(rep(names(list1),times=listLengths(list1)),unlist(lapply(list1,names)),sep=names.delim))
	k <- 0
	for (i in 1:length(list1)) {
		for (j in 1:length(list1[[i]])) {
			k <- k + 1
			list2[[k]] <- list1[[i]][[j]]
		}
	}
	list2
}


apa.names$general <- c(apa.names$general, "invert.list", "list.invert")
list.invert <- invert.list <- function(list1, null.rm=TRUE, by.names=TRUE) { 
	
	## NOT FULLY TESTED
	
	## Inverts either a list of vectors, or a list of lists of vectors.  The list must have names.
	## 
	## If 'by.names' is TRUE:
	##  The second level of the list must also have names.
	##  Inverted list will have one element for each unique sub-lists/vector name found in the original list.
	##  Example:
	##   list( X=list(A=c(1,2), B=2, C=3), Y=list(A=4, B=5, C=6), Z=list(A=7, B=8, D=0) )
	##  Inverts to:
	##   list( A=list(X=c(1,2), Y=4, Z=7), B=list(X=2, Y=5, Z=8), C=list(X=3, Y=6), D=list(Z=0) )
	## 
	## IF 'by.names' is FALSE:
	##  The second level of the list does not need names; they will be ignored anyway.
	##  The values of the second level will become new list names, while the names of the first level will become the new list values.
	##  Example:
	##   list( X=c(1,2,3), Y=5, Z=c(1,2,4) )
	##  Inverts to:
	##   list( `1`=c("X","Z"), `2`=c("X","Z"), `3`="X", `4`="Z", `5`="Y" )
	## 
	## "null.rm" controls removal of NULL elements in the inverted list.
	## 
    
    vectors <- is.atomic(list1[[1]])
    names1 <- names(list1)
    
    if (by.names) {
        names2 <- sort(unique(unlist(lapply(list1, names))))  # names from sub-lists/vectors
        if (vectors) {
            list2 <- list2names <- new.list(names2)
            for (i in 1:length(list1)) {
                if (length(list1[[i]])==0) next
                for (j in 1:length(list1[[i]])) {
                    jname <- names(list1[[i]])[j]
                    k <- match(jname, names2)
                    list2[[k]] <- c(list2[[k]], list1[[i]][j])
                    list2names[[k]] <- c(list2names[[k]], jname)
                }
            }
            for (i in 1:length(list2)) names(list2[[i]]) <- list2names[[i]]
        } else {
            list2 <- new.list(names2, elem=new.list(names1))
            for (i in 1:length(list1)) {
                if (length(list1[[i]])==0) next
                for (j in 1:length(list1[[i]])) {
                    if (length(list1[[i]][[j]])==0) next
                    k <- match(names(list1[[i]])[j], names2)
                    list2[[k]][[i]] <- c(list2[[k]][[i]], list1[[i]][[j]])
                }
            }
        }
    } else {
        if (!vectors) list1 <- lapply(list1, function(x) unique(unlist(x)) )  # since names are ignored, just dump each sub-list into a vector
        names2 <- sort(unique(unlist(list1)))
        list2 <- new.list(names2)
        for (i in 1:length(list1)) {
            if (length(list1[[i]])>0) {
                m <- match(list1[[i]], names2)
                for (j in m[!is.na(m)]) list2[[j]] <- c(list2[[j]], names(list1)[i])
            }
        }
        list2 <- lapply(list2, function(x) sort(unique(x)) )
    }
    return(list2)
}


apa.names$general <- c(apa.names$general, "breakout")
breakout <- function(object, reverse=FALSE, unique=NULL) { 
    
    ## Using reverse=F converts a matrix to a list:
    ##   Takes 2-column matrices or data frames ONLY.  Requires object[,1] be a grouping vector and object[,2] be the data points.
    ##   Returns a list with one vector for each grouping value; vector contains the data points associated with that grouping value.
    ## Using "reverse=T" reverses the above process, making a list into a 2-column matrix.  Takes lists of vectors ONLY.
    ## Using "unique" provides duplicate entry control:
    ##  "unique=local": removes duplicate entries within groups (reduced to one instance each).
    ##  "unique=global": removes ALL ENTRIES which are present > 1 times, regardless of group (no instances remain).  
    ##   - If single instances of each entry were retained, they would be arbitrarily assigned to only one group, which is probably not what you wanted.
    ##  "unique=NULL": leaves object as-is.
    
    if (is.null(unique)) { 
        unique <- ""   # testable but empty value
    } else {
        match.arg(unique, c('local','global')) 
    }
    if (!is.logical(reverse)) { stop("'reverse' must be TRUE or FALSE!\n") }
    if (is.null(names(object))) { names(object) <- 1:length(object) }
    
    if (!reverse) {	# matrix -> list
        
        if (!is.matrix(object) & !is.data.frame(object)) { stop("Error: object must be a matrix or data frame!\n") }
        if (unique == "local") { object <- unique(object) }
        if (unique == "global") { 
            x <- unique(object[duplicated(object[,2]),2])
            y <- object[,2] %in% x
            object <- object[!y,]
        }
        
        if (is.null(dim(object)) == T) { stop("Error: object must be a matrix!\n") }
        if (ncol(object) != 2) { stop("Error: matrix must have only 2 columns!\n") }
        
        func <- function (val, mat) {
            iv <- which(mat[,1] == val)
            return ( mat[iv,2] )
        }
        
        u <- sort(unique(object[,1]))
        out <- lapply(u, func, object)
        names(out) <- u
        
    } else if (reverse) {	# list -> matrix
        
        if (!is.list(object)) { stop("Error: object must be a list!\n") }
        if (unique == "local") { 
            for (i in 1:length(object)) { object[[i]] <- unique(object[[i]]) }
        }
        if (unique == "global") {
            allentries <- unlist(object)
            x <- unique(allentries[duplicated(allentries)])
            for (i in 1:length(object)) {
                y <- object[[i]] %in% x
                object[[i]] <- object[[i]][!y]
            }
        }
        
        u <- listLengths(object)
        out <- matrix(data=0, nrow=sum(u), ncol=2)
        out[,1] <- unlist(sapply(1:length(u), FUN=function(x,n,u){rep(n[x],u[x])}, names(u), u))
        x <- unlist(object)
        names(x) <- c()
        out[,2] <- x
        
    }
    
    return(out)
}
